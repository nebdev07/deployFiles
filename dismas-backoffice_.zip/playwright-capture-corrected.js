// Script Playwright corrigé - Basé sur votre retour de fonctionnement
const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');

// Configuration des utilisateurs
const users = [
  { role: 'ADMIN', login: 'admin', password: 'admin123' },
  { role: 'DAF', login: 'daf.kouame', password: 'daf123' },
  { role: 'DRENA', login: 'drena.kone', password: 'drena123' },
  { role: 'IEPP', login: 'iepp.assi', password: 'iepp123' },
  { role: 'DIRECTEUR', login: 'dir.kouadio', password: 'dir123' }
];

// Pages AUTORISÉES par rôle - Ajustements DRENA selon vos spécifications
const authorizedPages = {
  ADMIN: [
    { path: '/dashboard', name: 'Dashboard_Vue_Nationale' },
    { path: '/besoins', name: 'Besoins_Consolidation_Validation' },
    { path: '/stocks', name: 'Stocks_Vue_Complete_Entrepot' },
    { path: '/users', name: 'Users_Liste_Complete' },
    { path: '/commandes', name: 'Commandes_Acces_Autorise' },
    { path: '/admin', name: 'Admin_Monitoring_Systeme' },
    { path: '/admin/parametrages', name: 'Parametrages_Configuration' },
    { path: '/distribution', name: 'Distribution_Vue_Generale' },
    { path: '/regulation', name: 'Regulation_Vue_Generale' },
    { path: '/retours', name: 'Retours_Vue_Generale' },
    { path: '/plaintes', name: 'Plaintes_Vue_Generale' },
    { path: '/enquetes', name: 'Enquetes_Vue_Generale' },
    { path: '/rapports', name: 'Rapports_Vue_Generale' }
  ],
  
  DAF: [
    { path: '/dashboard', name: 'Dashboard_Vue_Financiere' },
    { path: '/besoins', name: 'Besoins_Consolidation_Validation' },
    { path: '/stocks', name: 'Stocks_Vue_Complete_Entrepot' },
    { path: '/users', name: 'Users_Liste_Complete' },
    { path: '/commandes', name: 'Commandes_Gestion_Financiere' },
    { path: '/admin/parametrages', name: 'Parametrages_Configuration' },
    { path: '/distribution', name: 'Distribution_Vue_Generale' },
    { path: '/regulation', name: 'Regulation_Vue_Generale' },
    { path: '/retours', name: 'Retours_Vue_Generale' },
    { path: '/plaintes', name: 'Plaintes_Vue_Generale' },
    { path: '/enquetes', name: 'Enquetes_Vue_Generale' },
    { path: '/rapports', name: 'Rapports_Vue_Generale' }
  ],
  
  // DRENA - Actions spécifiques : Régulation Externe + Rapport Fin Distribution
  DRENA: [
    { path: '/dashboard', name: 'Dashboard_Vue_Regionale' },
    { path: '/besoins', name: 'Besoins_Consolidation_DRENA' },
    { path: '/stocks', name: 'Stocks_Vue_Regionale_Filtree' },
    { path: '/users', name: 'Users_Filtrage_Regional' },
    { path: '/distribution', name: 'Distribution_Vue_Regionale' },
    { path: '/regulation', name: 'Regulation_Externe_DRENA', action: 'regulation_externe' },
    { path: '/retours', name: 'Retours_Vue_Regionale' },
    { path: '/plaintes', name: 'Plaintes_Vue_Regionale' },
    { path: '/enquetes', name: 'Enquetes_Vue_Regionale' },
    { path: '/rapports', name: 'Rapports_Fin_Distribution_DRENA', action: 'rapport_fin_distribution' }
  ],
  
  IEPP: [
    { path: '/dashboard', name: 'Dashboard_Vue_Circonscription' },
    { path: '/besoins', name: 'Besoins_Consolidation_IEPP' },
    { path: '/stocks', name: 'Stocks_Vue_Circonscription' },
    { path: '/users', name: 'Users_Filtrage_IEPP' },
    { path: '/distribution', name: 'Distribution_Validation_IEPP' },
    { path: '/regulation', name: 'Regulation_Vue_IEPP' },
    { path: '/retours', name: 'Retours_Vue_IEPP' },
    { path: '/plaintes', name: 'Plaintes_Vue_IEPP' },
    { path: '/enquetes', name: 'Enquetes_Vue_IEPP' },
    { path: '/rapports', name: 'Rapports_Vue_IEPP' }
  ],
  
  DIRECTEUR: [
    { path: '/dashboard', name: 'Dashboard_Vue_Ecole' },
    { path: '/besoins', name: 'Besoins_Saisie_EPP' },
    { path: '/stocks', name: 'Stocks_Vue_Ecole_Seule' },
    { path: '/users', name: 'Users_Profil_Personnel' },
    { path: '/distribution', name: 'Distribution_Confirmation_EPP' },
    { path: '/regulation', name: 'Regulation_Vue_EPP' },
    { path: '/retours', name: 'Retours_Vue_EPP' },
    { path: '/plaintes', name: 'Plaintes_Depot_Suivi' },
    { path: '/enquetes', name: 'Enquetes_Reponse_EPP' },
    { path: '/rapports', name: 'Rapports_Vue_EPP' }
  ]
};

class PlaywrightCaptureAdvanced {
  constructor() {
    this.browser = null;
    this.context = null;
    this.page = null;
    this.capturesDir = './captures';
    this.successCount = 0;
    this.errorCount = 0;
    this.retryLimit = 3;
  }

  async init() {
    console.log('🎭 PLAYWRIGHT CAPTURE AVANCÉ - VERSION CORRIGÉE');
    console.log('🔧 Gestion des erreurs React + Actions spécifiques DRENA');
    console.log('🚫 Ignore automatiquement les pages d\'accès restreint\n');

    // Créer dossier captures
    if (!fs.existsSync(this.capturesDir)) {
      fs.mkdirSync(this.capturesDir);
      console.log('📁 Dossier captures créé\n');
    }

    // Lancer navigateur avec options optimisées
    this.browser = await chromium.launch({ 
      headless: false,
      slowMo: 100,
      args: [
        '--no-sandbox',
        '--disable-setuid-sandbox',
        '--disable-web-security',
        '--disable-features=VizDisplayCompositor'
      ]
    });

    console.log('✅ Navigateur Playwright lancé\n');
  }

  async createNewContext() {
    if (this.context) {
      await this.context.close();
    }
    
    this.context = await this.browser.newContext({
      viewport: { width: 1920, height: 1080 },
      ignoreHTTPSErrors: true,
      // Ignorer les erreurs React/Console pour éviter les interruptions
      bypassCSP: true
    });

    this.page = await this.context.newPage();
    
    // Ignorer les erreurs React dans la console
    this.page.on('console', msg => {
      if (msg.type() === 'error' && !msg.text().includes('fatal')) {
        // Ignorer les erreurs React non-critiques
        return;
      }
    });

    // Ignorer les erreurs de page non-critiques
    this.page.on('pageerror', error => {
      if (!error.message.includes('Cannot read properties')) {
        console.log(`   ⚠️  Warning ignoré: ${error.message.substring(0, 100)}...`);
      }
    });
  }

  async smartLogin(user) {
    console.log(`🔑 Connexion Playwright pour ${user.role}...`);
    
    for (let attempt = 1; attempt <= this.retryLimit; attempt++) {
      try {
        // Navigation vers login
        await this.page.goto('http://localhost:3000', { 
          waitUntil: 'domcontentloaded',
          timeout: 20000 
        });
        
        await this.page.waitForTimeout(2000);

        // Vérifier si déjà connecté
        const currentUrl = this.page.url();
        if (currentUrl.includes('dashboard')) {
          console.log('   ✅ Déjà connecté');
          return true;
        }

        // Multiples stratégies de connexion Playwright
        const strategies = [
          // Stratégie 1: Sélecteurs directs
          async () => {
            await this.page.waitForSelector('input[type="text"]', { timeout: 5000 });
            await this.page.fill('input[type="text"]', user.login);
            await this.page.fill('input[type="password"]', user.password);
            await this.page.click('button[type="submit"]');
          },
          
          // Stratégie 2: Localisation par rôle/label
          async () => {
            const loginInput = this.page.locator('input').first();
            const passwordInput = this.page.locator('input[type="password"]');
            const submitButton = this.page.locator('button').first();
            
            await loginInput.fill(user.login);
            await passwordInput.fill(user.password);
            await submitButton.click();
          },
          
          // Stratégie 3: Par index
          async () => {
            const inputs = await this.page.$$('input');
            const buttons = await this.page.$$('button');
            
            if (inputs.length >= 2 && buttons.length >= 1) {
              await inputs[0].fill(user.login);
              await inputs[1].fill(user.password);
              await buttons[0].click();
            }
          }
        ];

        // Tester chaque stratégie
        for (const strategy of strategies) {
          try {
            await strategy();
            
            // Attendre navigation
            await this.page.waitForTimeout(4000);
            
            const newUrl = this.page.url();
            if (newUrl.includes('dashboard') || newUrl !== 'http://localhost:3000/') {
              console.log(`   ✅ Connexion réussie (tentative ${attempt})`);
              return true;
            }
          } catch (strategyError) {
            continue;
          }
        }

        console.log(`   ⚠️  Tentative ${attempt} échouée, retry...`);
        await this.page.waitForTimeout(1000);
        
      } catch (error) {
        console.log(`   ❌ Erreur tentative ${attempt}: ${error.message}`);
      }
    }

    return false;
  }

  async handleSpecialAction(user, pageConfig) {
    if (user.role !== 'DRENA' || !pageConfig.action) {
      return;
    }

    console.log(`   🎯 Action spéciale DRENA: ${pageConfig.action}`);

    try {
      if (pageConfig.action === 'regulation_externe') {
        // Aller sur la page régulation et montrer les actions externes
        await this.page.waitForTimeout(2000);
        
        // Chercher les éléments spécifiques à la régulation externe
        const externalRegulationElements = await this.page.$$('[data-testid*="externe"], [class*="externe"], button:has-text("Externe")');
        
        if (externalRegulationElements.length > 0) {
          console.log('   📸 Focus sur régulation externe détecté');
          // Capture spécifique avec focus sur les éléments externes
          await this.page.screenshot({ 
            path: path.join(this.capturesDir, `${user.role}_Regulation_Externe_Action.png`),
            fullPage: true
          });
        }
      }
      
      if (pageConfig.action === 'rapport_fin_distribution') {
        // Page rapports avec focus sur fin de distribution
        await this.page.waitForTimeout(2000);
        
        // Chercher les rapports de fin de distribution
        const reportElements = await this.page.$$('[data-testid*="distribution"], [class*="distribution"], button:has-text("Distribution"), select option:has-text("Distribution")');
        
        if (reportElements.length > 0) {
          console.log('   📊 Focus sur rapport fin distribution détecté');
          // Capture spécifique avec focus sur les rapports de distribution
          await this.page.screenshot({ 
            path: path.join(this.capturesDir, `${user.role}_Rapport_Fin_Distribution_Action.png`),
            fullPage: true
          });
        }
      }
    } catch (actionError) {
      console.log(`   ⚠️  Erreur action spéciale: ${actionError.message}`);
    }
  }

  async capturePage(user, pageConfig) {
    const maxRetries = 2;
    
    for (let attempt = 1; attempt <= maxRetries; attempt++) {
      try {
        console.log(`   📱 [${attempt}] ${pageConfig.name}...`);
        
        // Navigation avec gestion d'erreurs
        await this.page.goto(`http://localhost:3000${pageConfig.path}`, { 
          waitUntil: 'domcontentloaded',
          timeout: 15000 
        });

        await this.page.waitForTimeout(3000);

        // Vérifier accès restreint
        const content = await this.page.content();
        if (content.includes('Accès Restreint') || content.includes('Non autorisé')) {
          console.log(`   🚫 Page restreinte ignorée: ${pageConfig.path}`);
          return { success: false, reason: 'restricted' };
        }

        // Vérifier déconnexion
        const currentUrl = this.page.url();
        if (currentUrl.includes('login') || currentUrl === 'http://localhost:3000/') {
          console.log('   🔄 Déconnexion détectée, reconnexion...');
          const reconnected = await this.smartLogin(user);
          if (!reconnected) {
            throw new Error('Reconnexion échouée');
          }
          
          await this.page.goto(`http://localhost:3000${pageConfig.path}`, { 
            waitUntil: 'domcontentloaded' 
          });
          await this.page.waitForTimeout(3000);
        }

        // Scroll et capture
        await this.page.evaluate(() => window.scrollTo(0, 0));
        await this.page.waitForTimeout(1000);

        // Actions spéciales DRENA avant capture principale
        await this.handleSpecialAction(user, pageConfig);

        // Capture principale
        const filename = `${user.role}_${pageConfig.name}.png`;
        await this.page.screenshot({ 
          path: path.join(this.capturesDir, filename),
          fullPage: true
        });

        console.log(`   ✅ ${filename}`);
        this.successCount++;
        return { success: true };

      } catch (error) {
        console.log(`   ⚠️  Tentative ${attempt} échouée: ${error.message}`);
        
        if (attempt < maxRetries) {
          await this.page.waitForTimeout(2000);
          try {
            await this.smartLogin(user);
          } catch (loginError) {
            // Ignorer les erreurs de reconnexion
          }
        }
      }
    }

    console.log(`   ❌ Échec définitif pour ${pageConfig.name}`);
    this.errorCount++;
    return { success: false, reason: 'error' };
  }

  async captureUser(user) {
    console.log(`${'='.repeat(70)}`);
    console.log(`🔐 RÔLE: ${user.role} (${user.login})`);
    if (user.role === 'DRENA') {
      console.log('🎯 Actions spéciales: Régulation Externe + Rapport Fin Distribution');
    }
    console.log(`${'='.repeat(70)}`);

    await this.createNewContext();
    
    try {
      const loginSuccess = await this.smartLogin(user);
      if (!loginSuccess) {
        console.log(`❌ Impossible de connecter ${user.role}, passage au suivant\n`);
        return;
      }

      const userPages = authorizedPages[user.role] || [];
      console.log(`📸 ${userPages.length} pages autorisées à capturer\n`);

      for (let i = 0; i < userPages.length; i++) {
        const pageConfig = userPages[i];
        console.log(`[${i + 1}/${userPages.length}] ${pageConfig.path}`);
        
        await this.capturePage(user, pageConfig);
        await this.page.waitForTimeout(500);
      }

      console.log(`✅ Terminé pour ${user.role}\n`);

    } catch (error) {
      console.log(`❌ Erreur globale ${user.role}: ${error.message}\n`);
      this.errorCount++;
    }
  }

  async run() {
    try {
      await this.init();

      for (const user of users) {
        await this.captureUser(user);
      }

    } catch (error) {
      console.log(`💥 Erreur fatale: ${error.message}`);
    } finally {
      if (this.browser) {
        await this.browser.close();
        console.log('🌐 Navigateur fermé');
      }

      console.log('\n' + '='.repeat(70));
      console.log('📊 RAPPORT FINAL');
      console.log('='.repeat(70));
      console.log(`✅ Captures réussies: ${this.successCount}`);
      console.log(`❌ Erreurs/Restrictions: ${this.errorCount}`);
      console.log(`📁 Dossier: ${this.capturesDir}`);
      console.log('='.repeat(70));
    }
  }
}

// Installation vérification
console.log('🔍 Vérification Playwright...');
try {
  require('playwright');
  console.log('✅ Playwright disponible');
} catch (error) {
  console.log('❌ Playwright non installé');
  console.log('📋 Exécutez: npm install -D @playwright/test');
  console.log('📋 Puis: npx playwright install');
  process.exit(1);
}

// Lancement
console.log('🚀 Lancement dans 3 secondes...\n');
setTimeout(async () => {
  const capture = new PlaywrightCaptureAdvanced();
  await capture.run();
}, 3000);