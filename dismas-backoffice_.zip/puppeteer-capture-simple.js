// Script Puppeteer simplifié pour captures DISMAS
const puppeteer = require('puppeteer');
const fs = require('fs');

const users = [
  { role: 'ADMIN', login: 'admin', password: 'admin123' },
  { role: 'DAF', login: 'daf.kouame', password: 'daf123' },
  { role: 'DRENA', login: 'drena.kone', password: 'drena123' },
  { role: 'IEPP', login: 'iepp.assi', password: 'iepp123' },
  { role: 'DIRECTEUR', login: 'dir.kouadio', password: 'dir123' }
];

async function autoCapture() {
  console.log('🚀 Démarrage des captures automatiques...');
  
  const browser = await puppeteer.launch({ 
    headless: false,
    defaultViewport: { width: 1920, height: 1080 }
  });

  // Créer dossier
  if (!fs.existsSync('./captures')) {
    fs.mkdirSync('./captures');
  }

  for (const user of users) {
    console.log(`\n🔐 Rôle: ${user.role}`);
    
    const page = await browser.newPage();
    
    try {
      // Login
      await page.goto('http://localhost:3000');
      await page.waitForSelector('input[type="text"]', { timeout: 10000 });
      
      await page.type('input[type="text"]', user.login);
      await page.type('input[type="password"]', user.password);
      await page.click('button[type="submit"]');
      await page.waitForNavigation();
      await page.waitForTimeout(2000);

      // Dashboard
      await page.goto('http://localhost:3000/dashboard');
      await page.waitForTimeout(3000);
      await page.screenshot({ 
        path: `./captures/${user.role}_Dashboard.png`,
        fullPage: true
      });
      console.log(`  ✅ Dashboard capturé`);

      // Besoins
      await page.goto('http://localhost:3000/besoins');
      await page.waitForTimeout(3000);
      await page.screenshot({ 
        path: `./captures/${user.role}_Besoins.png`,
        fullPage: true
      });
      console.log(`  ✅ Besoins capturé`);

      // Autres pages selon le rôle
      if (['ADMIN', 'DAF'].includes(user.role)) {
        await page.goto('http://localhost:3000/commandes');
        await page.waitForTimeout(2000);
        await page.screenshot({ 
          path: `./captures/${user.role}_Commandes.png`,
          fullPage: true
        });
        console.log(`  ✅ Commandes capturé`);
      } else {
        // Page accès refusé
        await page.goto('http://localhost:3000/commandes');
        await page.waitForTimeout(2000);
        await page.screenshot({ 
          path: `./captures/${user.role}_Commandes_Refuse.png`,
          fullPage: true
        });
        console.log(`  ✅ Commandes (refusé) capturé`);
      }

    } catch (error) {
      console.log(`  ❌ Erreur: ${error.message}`);
    }
    
    await page.close();
  }

  await browser.close();
  console.log('\n🎉 Captures terminées!');
}

autoCapture().catch(console.error);