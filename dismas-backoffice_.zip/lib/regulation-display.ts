/** Affichage utilisateur des références (historique REG-V2-… → REG-…). */
export function formatRegulationReferenceForDisplay(ref?: string | null): string {
  const t = (ref ?? "").trim()
  if (!t) return ""
  return t.replace(/^REG-V2-/i, "REG-")
}
