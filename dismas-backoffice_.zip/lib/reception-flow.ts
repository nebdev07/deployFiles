/**
 * Normalise le flux métier (Livreur→IEPP vs IEPP→EPP) même si le backend envoie
 * `EPP` au lieu de `RECEPTION_EPP` (données historiques).
 */
export function normalizeReceptionFlowType(reception: {
  typeMouvement?: string
  typeReception?: string
}): "IEPP" | "EPP" | "UNKNOWN" {
  const tm = String(reception.typeMouvement ?? reception.typeReception ?? "")
    .trim()
    .toUpperCase()
  if (tm === "RECEPTION_IEPP" || tm === "IEPP") return "IEPP"
  if (tm === "RECEPTION_EPP" || tm === "EPP") return "EPP"
  if (tm.includes("RECEPTION_IEPP")) return "IEPP"
  if (tm.includes("RECEPTION_EPP")) return "EPP"
  return "UNKNOWN"
}

/**
 * Rôles avec vue synthèse sur les réceptions/distributions (regroupements IEPP, fichiers, etc.).
 * - DRENA : périmètre régional (filtré côté API).
 * - DAF : vue nationale / transverse (sans filtre structure sur les appels fusionnés).
 */
export function hasReceptionSyntheseTerritoriale(roleCode: string | undefined): boolean {
  return roleCode === "DRENA" || roleCode === "DAF" || roleCode === "CABINET"
}
