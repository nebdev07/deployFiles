/** Rôles « territoire IEPP » (intendant, CPS, etc.) — aligner sur {@code IEPP_TERRITORY_MENU_ROLE_CODES} dans role-codes. */
const IEPP_TERRITORY_ROLE_CODES_UC = new Set<string>(["IEPP", "CPPP", "CPS", "INTENDANT", "INTENDENT"])

/** Intendant / CPS / CPPP : même périmètre IEPP que l’inspecteur pour les écrans réception (saisie, pas validation définitive). */
export function isIeppTerritoryMenuRoleForReception(roleCode: string | undefined): boolean {
  const c = (roleCode || "").toUpperCase().trim()
  return IEPP_TERRITORY_ROLE_CODES_UC.has(c)
}

/** Aligné sur `components/layout/sidebar.tsx` (entrée menu Réception, `functionalityReadCode: "MOUVEMENT"`). */
export const RECEPTION_MENU_ROLE_CODES = [
  "ADMIN",
  "DAF",
  "DRENA",
  "IEPP",
  "CPPP",
  "CPS",
  "INTENDANT",
  "INTENDENT",
  "DIRECTEUR",
  "INFORMATICIEN",
  "CABINET",
] as const

const RECEPTION_MENU_ROLE_CODES_UC = RECEPTION_MENU_ROLE_CODES as readonly string[]

/** Aligné sur {@code hasFunctionalityPermission(..., "READ")} (clés session {@code CODE:READ}). */
function hasPermissionRead(permissions: string[] | undefined, fonctionaliteCode: string): boolean {
  if (!permissions?.length) return false
  const key = `${fonctionaliteCode}:READ`
  return permissions.some((p) => p.toUpperCase() === key.toUpperCase())
}

/**
 * Accès à la page `/receptions` (garde UI + cohérence menu).
 * Si la session expose des {@code functionalityPermissions}, même logique que le menu : {@code MOUVEMENT:READ}.
 */
export function canAccessReceptionsModule(
  roleCode: string | undefined,
  functionalityPermissions?: string[],
): boolean {
  if (!roleCode) return false
  const rc = roleCode.toUpperCase()
  if (!functionalityPermissions?.length) {
    return RECEPTION_MENU_ROLE_CODES_UC.includes(rc)
  }
  return hasPermissionRead(functionalityPermissions, "MOUVEMENT")
}

/**
 * Conditions de chargement initial des réceptions (hooks page).
 * DRENA/DAF : dès que l'utilisateur est connu (synthèse territoriale).
 * Autres rôles : lorsque `structure.id` est disponible.
 */
export function shouldFetchReceptionsOnUserReady(
  roleCode: string | undefined,
  structureId: number | undefined
): boolean {
  // Doit rester aligné avec `hasReceptionSyntheseTerritoriale` dans reception-flow.ts
  if (roleCode === "DRENA" || roleCode === "DAF" || roleCode === "CABINET") return true
  return structureId != null && structureId > 0
}

/**
 * Liste affichée selon le rôle (ex. directeur : flux EPP uniquement).
 */
export function filterReceptionsListForRole(roleCode: string | undefined, receptions: any[]): any[] {
  if (!receptions?.length) return []
  if (roleCode === "DIRECTEUR") {
    return receptions.filter((r: any) => r.type === "EPP")
  }
  return receptions
}

/**
 * Valeur {@code structureType} pour {@code /besoin/getForReception} (backend : IEPP ou EPP).
 * Priorité au type de structure auth ; sinon déduction par rôle (intendant / CPS = même périmètre IEPP que l'inspecteur).
 */
export function resolveStructureTypeForBesoinsApprouvesReception(
  roleCode: string | undefined,
  authStructureType: string | undefined,
): "IEPP" | "EPP" | undefined {
  const st = (authStructureType || "").trim().toUpperCase()
  if (st === "IEPP") return "IEPP"
  if (st === "EPP") return "EPP"
  const rc = (roleCode || "").trim().toUpperCase()
  if (rc === "IEPP" || isIeppTerritoryMenuRoleForReception(roleCode)) return "IEPP"
  if (rc === "DIRECTEUR" || rc === "INFORMATICIEN") return "EPP"
  return undefined
}

/**
 * Consolidation multi-EPP au chargement depuis besoin approuvé (flux IEPP).
 * Avec RBAC en session : exiger {@code BESOIN:READ} ; périmètre IEPP via structure ou rôles territoire.
 */
export function shouldLoadIeppConsolidationWhenLoadingFromApprovedBesoin(
  roleCode: string | undefined,
  functionalityPermissions: string[] | undefined,
  authStructureType: string | undefined,
): boolean {
  if (functionalityPermissions?.length && !hasPermissionRead(functionalityPermissions, "BESOIN")) {
    return false
  }
  const st = (authStructureType || "").trim().toUpperCase()
  if (st === "IEPP") return true
  return isIeppTerritoryMenuRoleForReception(roleCode)
}

/** Résultat du garde-fou « charger besoins approuvés » (aligné backend {@code VIEW_BESOIN} + périmètre IEPP/EPP). */
export type ApprovedBesoinsReceptionGateResult =
  | { ok: true; structureType: "IEPP" | "EPP" }
  | { ok: false; reason: "STRUCTURE" | "BESOIN_READ" }

/**
 * Garde-fou chargement besoins approuvés pour réception ({@code /besoin/getForReception}).
 * Si la session expose des {@code functionalityPermissions}, exiger {@code BESOIN:READ} (cohérent {@code VIEW_BESOIN}).
 */
export function gateApprovedBesoinsReceptionLoad(
  roleCode: string | undefined,
  functionalityPermissions: string[] | undefined,
  authStructureType: string | undefined,
): ApprovedBesoinsReceptionGateResult {
  const structureType = resolveStructureTypeForBesoinsApprouvesReception(roleCode, authStructureType)
  if (!structureType) return { ok: false, reason: "STRUCTURE" }
  if (functionalityPermissions?.length && !hasPermissionRead(functionalityPermissions, "BESOIN")) {
    return { ok: false, reason: "BESOIN_READ" }
  }
  return { ok: true, structureType }
}

/** @see {@link gateApprovedBesoinsReceptionLoad} */
export function canLoadApprovedBesoinsForReception(
  roleCode: string | undefined,
  functionalityPermissions: string[] | undefined,
  authStructureType: string | undefined,
): boolean {
  return gateApprovedBesoinsReceptionLoad(roleCode, functionalityPermissions, authStructureType).ok
}
