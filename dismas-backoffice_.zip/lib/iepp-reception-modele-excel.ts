/**
 * Modèle Excel vierge pour saisir une réception « Livreur → IEPP » sans passer
 * par l’expression des besoins (saisie manuelle des quantités côté établissement IEPP).
 * L’import dans l’appli n’est pas automatisé : le fichier sert de gabarit métier.
 */
import * as XLSX from "xlsx"
import { downloadWorkbookAsFile } from "./approbation-besoin-excel"

const SHEET = "Reception_IEPP_directe"
const README = "Lisez_moi"

export function buildIeppReceptionDirecteTemplateWorkbook(): XLSX.WorkBook {
  const wb = XLSX.utils.book_new()
  const rows: (string | number)[][] = [
    [
      "code_IEPP_ou_id",
      "libelle_IEPP",
      "id_catalogue_ou_annee",
      "niveau_code",
      "matiere_id",
      "matiere_libelle",
      "quantite_prevue",
      "quantite_recue",
      "bordereau_livreur",
      "observations",
    ],
    ["", "", "", "", "", "", "", "", "", ""],
    ["", "", "", "", "", "", "", "", "", ""],
  ]
  XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(rows), SHEET)
  const readme: (string | number)[][] = [
    ["Réception directe en IEPP (hors fil « expression des besoins »)"],
    [""],
    [
      "Renseignez des quantités ENTIÈRES. Colonne code_IEPP_ou_id : code interne structure ou id si connu côté DISMAS.",
    ],
    [""],
    [
      "Ce modèle sert d’aide : la validation et l’enregistrement se font dans l’écran",
    ],
    ["Nouvelle réception → type Livreur → IEPP (réception directe)."],
  ]
  XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(readme), README)
  return wb
}

export function downloadIeppReceptionDirecteModele(): void {
  const wb = buildIeppReceptionDirecteTemplateWorkbook()
  const d = new Date().toISOString().slice(0, 10)
  downloadWorkbookAsFile(wb, `modele_reception_iepp_directe_${d}.xlsx`)
}
