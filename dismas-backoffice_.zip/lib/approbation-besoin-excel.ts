/**
 * Modèle et import Excel pour l'approbation DAF des besoins (sans taux global :
 * quantités manuelles entières pour éviter les arrondis de manuels).
 */
import * as XLSX from "xlsx"
import { besoinsService, type BesoinResponse } from "./services/besoins.service"

/**
 * Télécharge le modèle d’approbation généré par l’API (en-têtes = codes métier, pas d’id en colonnes visibles).
 */
export async function downloadApprobationTemplateFromBackend(
  besoinIds: number[]
): Promise<void> {
  const r = await besoinsService.exportApprovalTemplateExcel(besoinIds)
  if (!r.success || !r.data?.fileBase64) {
    throw new Error(r.message || "Export impossible")
  }
  const bin = atob(r.data.fileBase64)
  const bytes = new Uint8Array(bin.length)
  for (let i = 0; i < bin.length; i++) {
    bytes[i] = bin.charCodeAt(i)
  }
  const blob = new Blob([bytes], {
    type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  })
  const a = document.createElement("a")
  a.href = URL.createObjectURL(blob)
  a.download = r.data.fileName || "modele_approbation_daf.xlsx"
  a.click()
  URL.revokeObjectURL(a.href)
}

/**
 * Construit les Map attendues par l’écran d’approbation / l’API à partir de la réponse d’analyse.
 */
/** Clé API/backend pour une exception EPP : "{niveauScolaireId}_{matiereId}". */
export function eppExceptionCompositeKey(
  niveauScolaireId: number | null | undefined,
  matiereId: number
): string {
  const n = niveauScolaireId != null ? niveauScolaireId : 0
  return `${n}_${matiereId}`
}

/**
 * Identifiant structure pour appels consolidation / exceptions.
 * L’API `besoin/details` renvoie souvent seulement {@link BesoinResponse.structureId} (IEPP ou EPP).
 */
export function administrativeStructureId(
  b: Pick<BesoinResponse, "structureAdministrativeId" | "structureId">
): number | undefined {
  const v = b.structureAdministrativeId ?? b.structureId
  return typeof v === "number" && v > 0 ? v : undefined
}

/**
 * Rattache les besoins EPP renvoyés par {@link besoinsService.getConsolidationDetails} au besoin IEPP affiché.
 * Filtre par année si les deux sont connues ; sur le niveau « entête » du besoin, on n’exclut que si les deux
 * IDs sont définis et différents — sinon les EPP à niveau null (détails multi-niveaux) disparaissaient du modal.
 */
export function filterEppBesoinsForIeppConsolidation(
  eppList: BesoinResponse[],
  besoinIepp: BesoinResponse
): BesoinResponse[] {
  return eppList.filter((b) => {
    if (
      besoinIepp.anneeScolaireId != null &&
      b.anneeScolaireId != null &&
      b.anneeScolaireId !== besoinIepp.anneeScolaireId
    ) {
      return false
    }
    const nI = besoinIepp.niveauScolaireId
    const nB = b.niveauScolaireId
    if (nI != null && nB != null && nI !== nB) {
      return false
    }
    return true
  })
}

export function approbationParseToMaps(data: {
  quantitesApprouvees: Record<string, number>
  exceptionsEpp: Record<string, Record<string, number>>
}): {
  quantites: Map<number, number>
  exceptions: Map<number, Map<string, number>>
} {
  const quantites = new Map<number, number>()
  for (const [k, v] of Object.entries(data.quantitesApprouvees || {})) {
    quantites.set(Number(k), Number(v))
  }
  const exceptions = new Map<number, Map<string, number>>()
  for (const [eppK, sub] of Object.entries(data.exceptionsEpp || {})) {
    const m = new Map<string, number>()
    for (const [mk, mv] of Object.entries(sub || {})) {
      const key = mk.includes("_") ? mk : eppExceptionCompositeKey(0, Number(mk))
      m.set(key, Number(mv))
    }
    exceptions.set(Number(eppK), m)
  }
  return { quantites, exceptions }
}

export const SHEET_IEPP = "IEPP_lignes"
export const SHEET_EPP = "Exceptions_EPP"
const SHEET_README = "Lisez_moi"

function toInt(n: unknown, fallback: number): number {
  if (n === "" || n === null || n === undefined) return fallback
  const v = Number(n)
  if (Number.isNaN(v)) return fallback
  return Math.max(0, Math.round(v))
}

/**
 * Génère un classeur .xlsx (2 feuilles de données + consignes).
 */
export function buildApprobationTemplateWorkbook(
  besoinsDetails: BesoinResponse[],
  eppBesoinsMap: Map<number, BesoinResponse[]>
): XLSX.WorkBook {
  const wb = XLSX.utils.book_new()

  const ieppRows: (string | number)[][] = [
    [
      "besoinId",
      "referenceBesoin",
      "besoinDetailId",
      "matiereId",
      "matiereLibelle",
      "quantiteConsolidee",
      "quantiteApprouvee",
    ],
  ]
  for (const b of besoinsDetails) {
    for (const d of b.besoinDetails || []) {
      ieppRows.push([
        b.id,
        b.reference || "",
        d.id,
        d.matiereId,
        d.matiereLibelle || d.matiereCode || "",
        d.quantiteConsolidee ?? 0,
        "",
      ])
    }
  }
  XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(ieppRows), SHEET_IEPP)

  const eppRows: (string | number)[][] = [
    [
      "ieppBesoinId",
      "eppId",
      "eppLibelle",
      "matiereId",
      "matiereLibelle",
      "quantiteNetEpp",
      "quantiteApprouvee",
    ],
  ]
  for (const [ieppId, list] of eppBesoinsMap) {
    for (const eppB of list) {
      const eppId = administrativeStructureId(eppB)
      for (const det of eppB.besoinDetails || []) {
        if (det.matiereId == null) continue
        eppRows.push([
          ieppId,
          eppId ?? "",
          eppB.structureAdministrativeLibelle || "",
          det.matiereId,
          det.matiereLibelle || det.matiereCode || "",
          det.quantiteNet ?? 0,
          "",
        ])
      }
    }
  }
  if (eppRows.length > 1) {
    XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(eppRows), SHEET_EPP)
  }

  const readme: (string | number)[][] = [
    ["Consignes d'utilisation — approbation DAF (fichier sans taux global)"],
    [""],
    [
      "• Renseignez des QUANTITÉS ENTIÈRES (manuels) dans « quantiteApprouvee ». Le taux global n'est pas importé ici (évite des quantités en décimales).",
    ],
    [""],
    [
      "• Feuille IEPP_lignes : « quantiteApprouvee » vide = conserver « quantiteConsolidee » (comportement par défaut de l'import).",
    ],
    [""],
    [
      "• Feuille Exceptions_EPP (si présente) : ajustement par EPP / matière ; « quantiteApprouvee » vide = conserver « quantiteNetEpp ».",
    ],
    [""],
    ["• Ne supprimez pas les colonnes d'identifiants (besoinDetailId, eppId, matiereId)."],
  ]
  XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(readme), SHEET_README)

  return wb
}

function collectValidIeppDetailInfo(besoinsDetails: BesoinResponse[]): {
  byDetailId: Map<
    number,
    { max: number; besoinId: number; matiereId: number }
  >
} {
  const byDetailId = new Map<
    number,
    { max: number; besoinId: number; matiereId: number }
  >()
  for (const b of besoinsDetails) {
    for (const d of b.besoinDetails || []) {
      byDetailId.set(d.id, {
        max: d.quantiteConsolidee ?? 0,
        besoinId: b.id,
        matiereId: d.matiereId,
      })
    }
  }
  return { byDetailId }
}

function collectValidEppKeys(eppBesoinsMap: Map<number, BesoinResponse[]>): {
  eppMatiereMax: Map<string, { max: number }>
} {
  const eppMatiereMax = new Map<string, { max: number }>()
  for (const [, list] of eppBesoinsMap) {
    for (const eppB of list) {
      const eid = administrativeStructureId(eppB)
      if (eid == null) continue
      for (const det of eppB.besoinDetails || []) {
        if (det.matiereId == null) continue
        const niv = det.niveauScolaireId ?? 0
        const key = `${eid}|${niv}|${det.matiereId}`
        eppMatiereMax.set(key, { max: det.quantiteNet ?? 0 })
      }
    }
  }
  return { eppMatiereMax }
}

function normKey(h: string): string {
  return h
    .trim()
    .toLowerCase()
    .replace(/\s+/g, "_")
    .replace(/[éèê]/g, "e")
    .replace(/[àâ]/g, "a")
}

/**
 * Analyse le fichier .xlsx et renvoit les Map attendues par l'API (quantités
 * entières, bornées aux max consolidé / net).
 */
export function parseApprobationImport(
  data: ArrayBuffer,
  besoinsDetails: BesoinResponse[],
  eppBesoinsMap: Map<number, BesoinResponse[]>
): {
  quantites: Map<number, number>
  exceptions: Map<number, Map<string, number>>
  warnings: string[]
  error?: string
} {
  const warnings: string[] = []
  const { byDetailId } = collectValidIeppDetailInfo(besoinsDetails)
  const { eppMatiereMax } = collectValidEppKeys(eppBesoinsMap)

  let wb: XLSX.WorkBook
  try {
    wb = XLSX.read(new Uint8Array(data), { type: "array" })
  } catch {
    return {
      quantites: new Map(),
      exceptions: new Map(),
      warnings: [],
      error: "Fichier Excel illisible ou corrompu.",
    }
  }

  const findSheet = (candidates: string[]) => {
    for (const c of candidates) {
      const s = wb.SheetNames.find((n) => n === c)
      if (s) return s
    }
    return null
  }

  const nameIepp = findSheet([SHEET_IEPP, "IEPP lignes", "iepp_lignes"])
  if (!nameIepp) {
    return {
      quantites: new Map(),
      exceptions: new Map(),
      warnings: [],
      error: `Feuille « ${SHEET_IEPP} » introuvable. Téléchargez le modèle depuis l’écran.`,
    }
  }

  const wsIepp = wb.Sheets[nameIepp]
  const rowsIepp = XLSX.utils.sheet_to_json<Record<string, unknown>>(wsIepp, {
    defval: "",
    raw: true,
  })
  if (rowsIepp.length === 0) {
    return {
      quantites: new Map(),
      exceptions: new Map(),
      warnings: [],
      error: "La feuille IEPP ne contient aucune ligne de données.",
    }
  }

  // Normaliser noms de colonnes (1ère ligne)
  const h0 = rowsIepp[0] as Record<string, unknown>
  const colMap: Record<string, string> = {}
  for (const k of Object.keys(h0)) {
    colMap[normKey(String(k))] = k
  }
  const pick = (aliases: string[]) => {
    for (const a of aliases) {
      const nk = normKey(a)
      if (colMap[nk]) return colMap[nk]
    }
    return null
  }

  const kDetail = pick(["besoindetailid", "id_detail", "iddetail", "id_ligne"])
  const kQc = pick([
    "quantiteconsolidee",
    "qte_consolidee",
    "quantite_consolidee",
  ])
  const kQa = pick([
    "quantiteapprouvee",
    "qte_approuvee",
    "quantite_approuvee",
    "approuvee",
  ])

  if (!kDetail || !kQc) {
    return {
      quantites: new Map(),
      exceptions: new Map(),
      warnings: [],
      error: "En-têtes inattendus (besoinDetailId, quantiteConsolidee requis). Téléchargez le modèle.",
    }
  }

  const qAppKey = kQa || "quantiteApprouvee"
  const quantites = new Map<number, number>()

  for (const row of rowsIepp) {
    const rawId = row[kDetail!]
    const id = Number(rawId)
    if (Number.isNaN(id) || !byDetailId.has(id)) {
      if (String(rawId).trim() !== "") {
        warnings.push(`Ligne ignorée (besoinDetailId inconnu ou vide) : ${String(rawId)}`)
      }
      continue
    }
    const ref = byDetailId.get(id)!
    const max = ref.max
    const cellQa = kQa ? row[kQa] : row[qAppKey as keyof typeof row]
    const cellQc = row[kQc!]
    const fallback = toInt(cellQc, max)
    const rawQa = cellQa
    const empty =
      rawQa === "" || rawQa === null || rawQa === undefined
    const qa = empty
      ? fallback
      : Math.min(max, toInt(rawQa, 0))
    if (!empty && toInt(rawQa, 0) > max) {
      warnings.push(
        `besoinDetailId ${id} : quantiteApprouvee ${toInt(rawQa, 0)} ramenée à ${max} (max = quantite consolidée).`
      )
    }
    quantites.set(id, qa)
  }

  const exceptions = new Map<number, Map<string, number>>()
  const nameEpp = findSheet([SHEET_EPP, "Exceptions EPP", "exceptions_epp"])
  if (nameEpp) {
    const wsEpp = wb.Sheets[nameEpp]
    const rowsEpp = XLSX.utils.sheet_to_json<Record<string, unknown>>(wsEpp, {
      defval: "",
      raw: true,
    })
    if (rowsEpp.length > 0) {
      const r0 = rowsEpp[0] as Record<string, unknown>
      const cm2: Record<string, string> = {}
      for (const k of Object.keys(r0)) {
        cm2[normKey(String(k))] = k
      }
      const p2 = (aliases: string[]) => {
        for (const a of aliases) {
          const nk = normKey(a)
          if (cm2[nk]) return cm2[nk]
        }
        return null
      }
      const ke = p2(["eppid", "id_epp", "structureepp", "stucture_administrative_id_epp"])
      const km = p2(["matiereid", "id_matiere"])
      const kNiv = p2(["codeniveau", "code_niveau", "niveauscolaireid", "niveau_scolaire_id", "id_niveau"])
      const kNet = p2(["quantitenetepp", "quantite_net_epp", "qte_net", "net"])
      const kAppE = p2([
        "quantiteapprouvee",
        "qte_approuvee",
        "approuvee",
      ])
      if (ke && km && kNet) {
        for (const row of rowsEpp) {
          const eppId = Number(row[ke!])
          const matId = Number(row[km!])
          if (Number.isNaN(eppId) || Number.isNaN(matId)) continue
          const nivRaw = kNiv ? row[kNiv] : ""
          const niv =
            nivRaw === "" || nivRaw === null || nivRaw === undefined
              ? null
              : Number(nivRaw)
          const resolveComposite = (): string | null => {
            if (niv != null && !Number.isNaN(niv)) {
              const key3 = `${eppId}|${niv}|${matId}`
              if (eppMatiereMax.has(key3)) return eppExceptionCompositeKey(niv, matId)
            }
            const hits: string[] = []
            for (const k of eppMatiereMax.keys()) {
              const parts = k.split("|")
              if (parts.length === 3 && parts[0] === String(eppId) && parts[2] === String(matId)) {
                hits.push(k)
              }
            }
            if (hits.length === 0) return null
            if (hits.length > 1) {
              warnings.push(
                `Exception EPP ignorée (eppId=${eppId}, matiereId=${matId} : plusieurs niveaux — renseignez code_niveau / id niveau).`
              )
              return null
            }
            const parts = hits[0]!.split("|")
            const n = Number(parts[1])
            return eppExceptionCompositeKey(Number.isNaN(n) ? 0 : n, matId)
          }
          const composite = resolveComposite()
          if (!composite) {
            warnings.push(
              `Exception EPP ignorée (eppId=${eppId}, matiereId=${matId} non reconnue).`
            )
            continue
          }
          const parts = composite.split("_")
          const nivId = Number(parts[0])
          const key = `${eppId}|${nivId}|${matId}`
          const meta = eppMatiereMax.get(key)
          if (!meta) {
            warnings.push(
              `Exception EPP ignorée (eppId=${eppId}, matiereId=${matId} non reconnue).`
            )
            continue
          }
          const max = meta.max
          const cellA = kAppE ? row[kAppE!] : ""
          const cellNet = row[kNet!]
          const defNet = toInt(cellNet, max)
          const emptyE =
            cellA === "" || cellA === null || cellA === undefined
          const v = emptyE
            ? defNet
            : Math.min(max, toInt(cellA, 0))
          if (!exceptions.has(eppId)) {
            exceptions.set(eppId, new Map())
          }
          exceptions.get(eppId)!.set(composite, v)
          if (
            !emptyE &&
            toInt(cellA, 0) > max
          ) {
            warnings.push(
              `EPP ${eppId} mat. ${matId} : quantité ramenée à ${max}.`
            )
          }
        }
      } else {
        warnings.push("Feuille EPP : en-têtes inattendus — import des exceptions ignoré.")
      }
    }
  }

  if (quantites.size === 0) {
    return {
      quantites: new Map(),
      exceptions: new Map(),
      warnings: [],
      error: "Aucune ligne IEPP reconnue. Vérifiez le modèle et les besoinDetailId.",
    }
  }

  return { quantites, exceptions, warnings }
}

export function downloadWorkbookAsFile(
  wb: XLSX.WorkBook,
  fileName: string
): void {
  const out = XLSX.write(wb, { bookType: "xlsx", type: "array" })
  const blob = new Blob([out], {
    type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  })
  const a = document.createElement("a")
  a.href = URL.createObjectURL(blob)
  a.download = fileName
  a.click()
  URL.revokeObjectURL(a.href)
}

/**
 * Lit la colonne besoinId de la feuille IEPP (import avant chargement API).
 */
export function extractBesoinIdsFromIeppTemplateBuffer(data: ArrayBuffer): number[] {
  let wb: XLSX.WorkBook
  try {
    wb = XLSX.read(new Uint8Array(data), { type: "array" })
  } catch {
    return []
  }
  const name =
    wb.SheetNames.find((n) => n === SHEET_IEPP) ||
    wb.SheetNames.find((n) => /iepp/i.test(n)) ||
    wb.SheetNames[0]
  if (!name) return []
  const ws = wb.Sheets[name]
  const rows = XLSX.utils.sheet_to_json<Record<string, unknown>>(ws, { defval: "" })
  const ids = new Set<number>()
  for (const row of rows) {
    const raw = row.besoinId ?? row.besoinid
    if (raw === "" || raw === "besoinId" || String(raw).toLowerCase() === "besoinid")
      continue
    const n = Number(raw)
    if (!Number.isNaN(n) && n > 0) ids.add(n)
  }
  return Array.from(ids)
}

/**
 * Charge le même contexte que le modal d’approbation (IEPP consolidés + cartographie EPP).
 */
export async function loadBesoinsApprovalTemplateContext(
  besoinIds: number[]
): Promise<{
  besoinsIepp: BesoinResponse[]
  eppBesoinsMap: Map<number, BesoinResponse[]>
}> {
  const detailsPromises = besoinIds.map((id) => besoinsService.getDetails(id))
  const results = await Promise.all(detailsPromises)
  const loadedBesoins = results
    .filter((r) => r.success && r.data)
    .map((r) => r.data!)
  const besoinsIepp = loadedBesoins.filter(
    (b) => b.structureType === "IEPP" && b.statut === "CONSOLIDE"
  )
  const eppBesoinsMap = new Map<number, BesoinResponse[]>()
  for (const besoinIepp of besoinsIepp) {
    const ieppSid = administrativeStructureId(besoinIepp)
    if (ieppSid != null) {
      const eppBesoinsResult = await besoinsService.getConsolidationDetails(ieppSid)
      if (eppBesoinsResult.success && eppBesoinsResult.data) {
        const eppBesoinsFiltered = filterEppBesoinsForIeppConsolidation(
          eppBesoinsResult.data,
          besoinIepp
        )
        if (eppBesoinsFiltered.length > 0) {
          eppBesoinsMap.set(besoinIepp.id, eppBesoinsFiltered)
        }
      }
    }
  }
  return { besoinsIepp, eppBesoinsMap }
}
