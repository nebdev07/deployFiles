/**
 * Regroupement IEPP → EPP pour les vues synthèse (DRENA / DAF) sur la page Réceptions.
 * Logique pure : testable sans React.
 */

export type DistributionSyntheseEppBlock = {
  eppKey: number
  eppLabel: string
  rows: any[]
}

export type DistributionSyntheseIeppGroup = {
  ieppId: number
  ieppLabel: string
  epps: Map<number, { eppLabel: string; rows: any[] }>
}

/**
 * @param distributions lignes `getDistributionsPaginated` (structureId, structureParentId, …)
 * @param ieppLabels libellés IEPP préchargés par id
 */
export function groupDistributionsByIeppThenEpp(
  distributions: any[],
  ieppLabels: Record<number, string>
): DistributionSyntheseIeppGroup[] {
  const byIepp = new Map<number, DistributionSyntheseIeppGroup>()
  for (const d of distributions) {
    const sid = Number(d.structureId)
    const parent = d.structureParentId != null ? Number(d.structureParentId) : NaN
    const ieppId = parent > 0 ? parent : sid
    if (!ieppId || Number.isNaN(ieppId)) continue
    const ieppLabel = ieppLabels[ieppId] || `IEPP #${ieppId}`
    if (!byIepp.has(ieppId)) {
      byIepp.set(ieppId, { ieppId, ieppLabel, epps: new Map() })
    }
    const g = byIepp.get(ieppId)!
    const eppKey = parent > 0 ? sid : 0
    const eppLabel = d.structureLibelle || (eppKey > 0 ? `EPP #${eppKey}` : "Structure")
    if (!g.epps.has(eppKey)) {
      g.epps.set(eppKey, { eppLabel, rows: [] })
    }
    g.epps.get(eppKey)!.rows.push(d)
  }
  return Array.from(byIepp.values()).sort((a, b) =>
    a.ieppLabel.localeCompare(b.ieppLabel, "fr", { sensitivity: "base" })
  )
}
