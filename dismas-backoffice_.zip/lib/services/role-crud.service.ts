/**
 * Service pour la gestion des rôles avec CRUD complet
 * Suit le même pattern que matiere.service.ts et niveau-scolaire.service.ts
 */

import { BaseApiService } from './base-api.service';
import { ApiResponse } from '@/lib/types/api';
import { Role, CreateRoleRequest, RoleFilters } from '@/lib/types/entities';

class RoleCrudService extends BaseApiService {
  private baseEndpoint = '/role';

  // Fonction utilitaire pour construire les requêtes selon le format backend
  private buildRequest(data: any, isCreateUpdate = false) {
    const userId = this.getCurrentUserId();
    const token = this.getAuthToken();
    
    // Vérifier si l'utilisateur est connecté
    if (!userId || !token) {
      console.warn('Utilisateur non connecté - impossible de charger les rôles');
      throw new Error('Utilisateur non connecté');
    }
    
    const baseRequest = {
      user: userId,
      token: token,
      isSimpleLoading: false
    };
    
    if (isCreateUpdate) {
      // Pour CREATE/UPDATE/DELETE, utiliser "datas" avec un tableau
      return {
        ...baseRequest,
        datas: [data]
      };
    } else {
      // Pour GET/SEARCH, utiliser "data" avec un objet
      return {
        ...baseRequest,
        data
      };
    }
  }

  // Récupérer tous les rôles avec filtres
  async getRoles(filters?: RoleFilters): Promise<ApiResponse<Role[]>> {
    const data = {
      id: "",
      code: filters?.code || "",
      libelle: filters?.libelle || "",
      description: filters?.description || "",
      niveauAcces: filters?.niveauAcces ? filters.niveauAcces.toString() : "",
      isactive: filters?.isActive !== undefined ? filters.isActive : "",
      createdat: "",
      createdby: "",
      updatedat: "",
      updatedby: "",
      isdeleted: filters?.isDeleted || ""
    };
    
    return this.request<Role[]>('POST', `${this.baseEndpoint}/getByCriteria`, this.buildRequest(data));
  }

  // Récupérer un rôle par ID
  async getRoleById(id: number): Promise<ApiResponse<Role[]>> {
    const data = {
      id: id.toString(),
      code: "",
      libelle: "",
      description: "",
      niveauAcces: "",
      isactive: "",
      createdat: "",
      createdby: "",
      updatedat: "",
      updatedby: "",
      isdeleted: ""
    };
    return this.request<Role[]>('POST', `${this.baseEndpoint}/getByCriteria`, this.buildRequest(data));
  }

  // Créer un nouveau rôle
  async createRole(roleData: CreateRoleRequest): Promise<ApiResponse<Role[]>> {
    // Construire la requête avec le format "datas" pour la création
    const requestData = this.buildRequest(roleData, true);
    return this.request<Role[]>('POST', `${this.baseEndpoint}/create`, requestData);
  }

  // Mettre à jour un rôle
  async updateRole(id: number, roleData: Partial<CreateRoleRequest>): Promise<ApiResponse<Role[]>> {
    const data = { id, ...roleData };
    // Construire la requête avec le format "datas" pour la mise à jour
    const requestData = this.buildRequest(data, true);
    return this.request<Role[]>('POST', `${this.baseEndpoint}/update`, requestData);
  }

  // Supprimer un rôle (soft delete)
  async deleteRole(id: number): Promise<ApiResponse<Role[]>> {
    const data = { id };
    // Construire la requête avec le format "datas" pour la suppression
    const requestData = this.buildRequest(data, true);
    return this.request<Role[]>('POST', `${this.baseEndpoint}/delete`, requestData);
  }

  // Rechercher des rôles par terme
  async searchRoles(searchTerm: string): Promise<ApiResponse<Role[]>> {
    const data = {
      id: "",
      code: searchTerm,
      libelle: searchTerm,
      description: searchTerm,
      niveauAcces: "",
      isactive: "",
      createdat: "",
      createdby: "",
      updatedat: "",
      updatedby: "",
      isdeleted: ""
    };
    
    return this.request<Role[]>('POST', `${this.baseEndpoint}/getByCriteria`, this.buildRequest(data));
  }

  // Vérifier si un code rôle existe déjà
  async checkCodeExists(code: string, excludeId?: number): Promise<boolean> {
    try {
      const data = {
        id: "",
        code: code,
        libelle: "",
        description: "",
        niveauAcces: "",
        createdat: "",
        createdby: "",
        updatedat: "",
        updatedby: "",
        isdeleted: ""
      };
      const response = await this.request<Role[]>('POST', `${this.baseEndpoint}/getByCriteria`, this.buildRequest(data));
      
      const items = (response.items ?? []) as unknown as Role[];
      if (items.length > 0) {
        // Si on exclut un ID (pour la mise à jour), vérifier que ce n'est pas le même rôle
        if (excludeId) {
          return items.some(role => role.id !== excludeId);
        }
        return true;
      }
      return false;
    } catch (error) {
      console.error('Erreur lors de la vérification du code rôle:', error);
      return false;
    }
  }

  // Vérifier si un libellé existe déjà
  async checkLibelleExists(libelle: string, excludeId?: number): Promise<boolean> {
    try {
      const data = {
        id: "",
        code: "",
        libelle: libelle,
        description: "",
        niveauAcces: "",
        createdat: "",
        createdby: "",
        updatedat: "",
        updatedby: "",
        isdeleted: ""
      };
      const response = await this.request<Role[]>('POST', `${this.baseEndpoint}/getByCriteria`, this.buildRequest(data));
      
      const items = (response.items ?? []) as unknown as Role[];
      if (items.length > 0) {
        // Si on exclut un ID (pour la mise à jour), vérifier que ce n'est pas le même rôle
        if (excludeId) {
          return items.some(role => role.id !== excludeId);
        }
        return true;
      }
      return false;
    } catch (error) {
      console.error('Erreur lors de la vérification du libellé rôle:', error);
      return false;
    }
  }

  // Récupérer les rôles triés par niveau d'accès
  async getRolesOrderedByLevel(): Promise<ApiResponse<Role[]>> {
    const data = {
      id: "",
      code: "",
      libelle: "",
      description: "",
      niveauAcces: "",
      isactive: "",
      createdat: "",
      createdby: "",
      updatedat: "",
      updatedby: "",
      isdeleted: "false"
    };
    
    const response = await this.request<Role[]>('POST', `${this.baseEndpoint}/getByCriteria`, this.buildRequest(data));
    
    // Trier par niveau d'accès côté frontend si le backend ne le fait pas
    const items = (response.items ?? []) as unknown as Role[];
    if (items.length > 0) {
      items.sort((a, b) => (b.niveau_hierarchique || 0) - (a.niveau_hierarchique || 0));
    }
    
    return { ...response, items } as unknown as ApiResponse<Role[]>;
  }
}

export const roleCrudService = new RoleCrudService();
