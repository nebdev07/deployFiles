/**
 * Service pour la gestion des catalogues avec CRUD complet et gestion des matières associées
 * Suit le même pattern que matiere.service.ts et niveau-scolaire.service.ts
 */

import { BaseApiService } from './base-api.service';
import { ApiResponse } from '@/lib/types/api';
import { 
  Catalogue, 
  CatalogueMatiere, 
  CreateCatalogueRequest, 
  CreateCatalogueMatiereRequest,
  CatalogueFilters 
} from '@/lib/types/entities';

class CatalogueService extends BaseApiService {
  private baseEndpoint = '/catalogue';
  private catalogueMatiereEndpoint = '/catalogueMatiere';

  // Fonction utilitaire pour construire les requêtes selon le format backend
  private buildRequest(data: any, isCreateUpdate = false) {
    const userId = this.getCurrentUserId();
    const token = this.getAuthToken();
    
    // Vérifier si l'utilisateur est connecté
    if (!userId || !token) {
      console.warn('Utilisateur non connecté - impossible de charger les catalogues');
      throw new Error('Utilisateur non connecté');
    }
    
    const baseRequest = {
      user: userId,
      token: token,
      isSimpleLoading: false
    };
    
    if (isCreateUpdate) {
      // Pour CREATE/UPDATE/DELETE, utiliser "datas" avec un tableau
      return {
        ...baseRequest,
        datas: [data]
      };
    } else {
      // Pour GET/SEARCH, utiliser "data" avec un objet
      return {
        ...baseRequest,
        data
      };
    }
  }

  // ============ GESTION DES CATALOGUES ============

  // Récupérer tous les catalogues avec filtres
  async getCatalogues(filters?: CatalogueFilters): Promise<ApiResponse<Catalogue[]>> {
    const data = {
      id: "",
      code: filters?.code || "",
      libelle: filters?.libelle || "",
      niveauScolaireId: filters?.niveauScolaireId ? filters.niveauScolaireId.toString() : "",
      anneeScolaireId: filters?.anneeScolaireId ? filters.anneeScolaireId.toString() : "",
      active: filters?.active !== undefined ? filters.active : "",
      createdat: "",
      createdby: "",
      updatedat: "",
      updatedby: "",
      isdeleted: filters?.isDeleted !== undefined ? filters.isDeleted.toString() : ""
    };
    
    return this.request<Catalogue[]>('POST', `${this.baseEndpoint}/getByCriteria`, this.buildRequest(data));
  }

  // Récupérer un catalogue par ID
  async getCatalogueById(id: number): Promise<ApiResponse<Catalogue[]>> {
    const data = {
      id: id.toString(),
      code: "",
      libelle: "",
      niveauScolaireId: "",
      anneeScolaireId: "",
      createdat: "",
      createdby: "",
      updatedat: "",
      updatedby: "",
      isdeleted: ""
    };
    return this.request<Catalogue[]>('POST', `${this.baseEndpoint}/getByCriteria`, this.buildRequest(data));
  }

  // Créer un nouveau catalogue
  async createCatalogue(catalogueData: CreateCatalogueRequest): Promise<ApiResponse<Catalogue[]>> {
    // Construire la requête avec le format "datas" pour la création
    const requestData = this.buildRequest(catalogueData, true);
    return this.request<Catalogue[]>('POST', `${this.baseEndpoint}/create`, requestData);
  }

  // Mettre à jour un catalogue
  async updateCatalogue(id: number, catalogueData: Partial<CreateCatalogueRequest>): Promise<ApiResponse<Catalogue[]>> {
    const data = { id, ...catalogueData };
    // Construire la requête avec le format "datas" pour la mise à jour
    const requestData = this.buildRequest(data, true);
    return this.request<Catalogue[]>('POST', `${this.baseEndpoint}/update`, requestData);
  }

  // Supprimer un catalogue (soft delete)
  async deleteCatalogue(id: number): Promise<ApiResponse<Catalogue[]>> {
    const data = { id };
    // Construire la requête avec le format "datas" pour la suppression
    const requestData = this.buildRequest(data, true);
    return this.request<Catalogue[]>('POST', `${this.baseEndpoint}/delete`, requestData);
  }

  // Rechercher des catalogues par terme
  async searchCatalogues(searchTerm: string): Promise<ApiResponse<Catalogue[]>> {
    const data = {
      id: "",
      code: searchTerm,
      libelle: searchTerm,
      niveauScolaireId: "",
      anneeScolaireId: "",
      active: "",
      createdat: "",
      createdby: "",
      updatedat: "",
      updatedby: "",
      isdeleted: ""
    };
    
    return this.request<Catalogue[]>('POST', `${this.baseEndpoint}/getByCriteria`, this.buildRequest(data));
  }

  // Vérifier si un code catalogue existe déjà
  async checkCodeExists(code: string, excludeId?: number): Promise<boolean> {
    try {
      const data = {
        id: "",
        code: code,
        libelle: "",
        niveauScolaireId: "",
        anneeScolaireId: "",
        createdat: "",
        createdby: "",
        updatedat: "",
        updatedby: "",
        isdeleted: ""
      };
      const response = await this.request<Catalogue[]>('POST', `${this.baseEndpoint}/getByCriteria`, this.buildRequest(data));
      const items = (response.items ?? []) as unknown as Catalogue[];
      if (items.length > 0) {
        // Si on exclut un ID (pour la mise à jour), vérifier que ce n'est pas le même catalogue
        if (excludeId) {
          return items.some(catalogue => catalogue.id !== excludeId);
        }
        return true;
      }
      return false;
    } catch (error) {
      console.error('Erreur lors de la vérification du code catalogue:', error);
      return false;
    }
  }

  // Vérifier si un libellé existe déjà
  async checkLibelleExists(libelle: string, excludeId?: number, anneeScolaireId?: number): Promise<boolean> {
    try {
      const data = {
        id: "",
        code: "",
        libelle: libelle,
        niveauScolaireId: "",
        anneeScolaireId: anneeScolaireId ? anneeScolaireId.toString() : "",
        createdat: "",
        createdby: "",
        updatedat: "",
        updatedby: "",
        isdeleted: ""
      };
      const response = await this.request<Catalogue[]>('POST', `${this.baseEndpoint}/getByCriteria`, this.buildRequest(data));
      const items = (response.items ?? []) as unknown as Catalogue[];
      if (items.length > 0) {
        // Si on exclut un ID (pour la mise à jour), vérifier que ce n'est pas le même catalogue
        if (excludeId) {
          return items.some(catalogue => catalogue.id !== excludeId);
        }
        return true;
      }
      return false;
    } catch (error) {
      console.error('Erreur lors de la vérification du libellé catalogue:', error);
      return false;
    }
  }

  // Récupérer les catalogues actifs (non supprimés), optionnellement filtrés par année scolaire (côté backend).
  async getCataloguesActifs(anneeScolaireId?: number): Promise<ApiResponse<Catalogue[]>> {
    try {
      const data = {
        id: "",
        code: "",
        libelle: "",
        niveauScolaireId: "",
        anneeScolaireId:
          anneeScolaireId != null && anneeScolaireId > 0 ? String(anneeScolaireId) : "",
        active: true, // Filtrer uniquement les catalogues actifs
        createdat: "",
        createdby: "",
        updatedat: "",
        updatedby: "",
        isdeleted: "false"
      };
      
      return await this.request<Catalogue[]>('POST', `${this.baseEndpoint}/getByCriteria`, this.buildRequest(data));
    } catch (error) {
      console.error('Erreur lors de la récupération des catalogues actifs:', error);
      
      // Gérer les erreurs backend spécifiques
      if (error && typeof error === 'object' && 'code' in error) {
        throw error; // Propager l'erreur backend avec le message original
      }
      
      throw new Error('Erreur lors de la récupération des catalogues actifs');
    }
  }

  // ============ GESTION DES MATIÈRES ASSOCIÉES ============

  // Récupérer les matières d'un catalogue
  async getMatieresByCatalogue(catalogueId: number): Promise<ApiResponse<CatalogueMatiere[]>> {
    const data = {
      id: "",
      catalogueId: catalogueId.toString(),
      matiereId: "",
      createdat: "",
      createdby: "",
      updatedat: "",
      updatedby: "",
      isdeleted: "false"
    };
    
    return this.request<CatalogueMatiere[]>('POST', `${this.catalogueMatiereEndpoint}/getByCriteria`, this.buildRequest(data));
  }

  // Associer une matière à un catalogue
  async associateMatiereToCatalogue(catalogueId: number, matiereId: number, niveauScolaireId?: number): Promise<ApiResponse<CatalogueMatiere[]>> {
    const data: CreateCatalogueMatiereRequest = {
      catalogueId,
      matiereId,
      idNiveauScolaire: niveauScolaireId // 🎯 Ajout du niveau scolaire
    };
    
    const requestData = this.buildRequest(data, true);
    return this.request<CatalogueMatiere[]>('POST', `${this.catalogueMatiereEndpoint}/create`, requestData);
  }

  // Dissocier une matière d'un catalogue
  async dissociateMatiereFromCatalogue(catalogueMatiereId: number): Promise<ApiResponse<CatalogueMatiere[]>> {
    const data = { id: catalogueMatiereId };
    const requestData = this.buildRequest(data, true);
    return this.request<CatalogueMatiere[]>('POST', `${this.catalogueMatiereEndpoint}/delete`, requestData);
  }

  // Associer plusieurs matières à un catalogue
  async associateMatieresToCatalogue(catalogueId: number, matiereIds: number[], niveauScolaireId?: number): Promise<ApiResponse<CatalogueMatiere[]>> {
    const promises = matiereIds.map(matiereId => 
      this.associateMatiereToCatalogue(catalogueId, matiereId, niveauScolaireId) // 🎯 Passer le niveau à chaque association
    );
    
    try {
      const results = await Promise.all(promises);
      // Retourner le premier résultat pour la cohérence de l'API
      return results[0];
    } catch (error) {
      console.error('Erreur lors de l\'association des matières:', error);
      throw error;
    }
  }

  // Mettre à jour les matières d'un catalogue (remplace toutes les associations)
  async updateCatalogueMatieres(catalogueId: number, matiereIds: number[], niveauScolaireId?: number): Promise<ApiResponse<CatalogueMatiere[]>> {
    try {
      // 1. Récupérer les matières actuelles
      const currentMatieres = await this.getMatieresByCatalogue(catalogueId);
      
      // 2. Supprimer les associations actuelles
      const currentItems = (currentMatieres.items ?? []) as unknown as CatalogueMatiere[];
      if (currentItems.length > 0) {
        const deletePromises = currentItems.map(catalogueMatiere =>
          this.dissociateMatiereFromCatalogue(catalogueMatiere.id!)
        );
        await Promise.all(deletePromises);
      }
      
      // 3. Créer les nouvelles associations avec le niveau
      if (matiereIds.length > 0) {
        return await this.associateMatieresToCatalogue(catalogueId, matiereIds, niveauScolaireId); // 🎯 Passer le niveau
      }
      
      return { hasError: false, items: [], status: { code: 'OK', message: 'Matières mises à jour avec succès' }, actionEffectue: 'Matières mises à jour avec succès' };
    } catch (error) {
      console.error('Erreur lors de la mise à jour des matières du catalogue:', error);
      throw error;
    }
  }

  // Vérifier si une matière est déjà associée à un catalogue
  async isMatiereAssociatedToCatalogue(catalogueId: number, matiereId: number): Promise<boolean> {
    try {
      const data = {
        id: "",
        catalogueId: catalogueId.toString(),
        matiereId: matiereId.toString(),
        createdat: "",
        createdby: "",
        updatedat: "",
        updatedby: "",
        isdeleted: "false"
      };
      
      const response = await this.request<CatalogueMatiere[]>('POST', `${this.catalogueMatiereEndpoint}/getByCriteria`, this.buildRequest(data));
      
      return response.items && response.items.length > 0;
    } catch (error) {
      console.error('Erreur lors de la vérification de l\'association matière-catalogue:', error);
      return false;
    }
  }
}

export const catalogueService = new CatalogueService();
