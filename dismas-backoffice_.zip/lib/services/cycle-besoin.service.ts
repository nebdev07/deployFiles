/**
 * Paramétrage du calendrier cycle expression / consolidation / approbation (IEPP, DAF) et contexte EPP.
 */

import { BaseApiService } from "./base-api.service"
import type { ApiResponse } from "@/lib/types/api"

export type CycleBesoinContext = {
  role?: string
  anneeScolaireId?: number
  structureLibelle?: string
  ieppLibelle?: string | null
  datePrevue?: string | null
  expressionEppFermeeAt?: string | null
  secondsUntilDatePrevue?: number | null
  expressionBesoinAutorisee?: boolean
  motifBlocage?: string | null
}

class CycleBesoinService extends BaseApiService {
  private base = "/parametrageCycleBesoin"

  private buildDataRequest(data: Record<string, unknown>) {
    const userId = this.getCurrentUserId()
    const token = this.getAuthToken()
    if (!userId || !token) throw new Error("Utilisateur non connecté")
    return { user: userId, token, isSimpleLoading: false, data }
  }

  async getContext(anneeScolaireId: number): Promise<ApiResponse<CycleBesoinContext>> {
    return this.request<CycleBesoinContext>("POST", `${this.base}/getContext`, this.buildDataRequest({ anneeScolaireId }))
  }

  async saveDatePrevue(anneeScolaireId: number, datePrevue: string | null): Promise<ApiResponse<CycleBesoinContext>> {
    return this.request<CycleBesoinContext>("POST", `${this.base}/saveDatePrevue`, this.buildDataRequest({ anneeScolaireId, datePrevue }))
  }
}

export const cycleBesoinService = new CycleBesoinService()
