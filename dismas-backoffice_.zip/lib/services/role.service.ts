/**
 * Service pour la gestion des rôles
 * Intègre avec l'API backend RoleController
 */

import { BaseApiService } from './base-api.service';
import { API_ENDPOINTS } from '@/lib/config/api';
import { ApiResponse } from '@/lib/types/api';
import { Role } from '@/lib/types/entities';

export interface RoleFilters {
  code?: string;
  name?: string;
  description?: string;
  isActive?: boolean;
  isDeleted?: boolean;
}

export class RoleService extends BaseApiService {
  
  /**
   * Créer un nouveau rôle
   * Endpoint: POST /role/create
   */
  async create(role: Role): Promise<ApiResponse<Role>> {
    const request = this.buildCreateRequest(role);
    return this.post<Role>(API_ENDPOINTS.ROLES + '/create', request);
  }

  /**
   * Mettre à jour un rôle
   * Endpoint: POST /role/update
   */
  async update(role: Role): Promise<ApiResponse<Role>> {
    const request = this.buildUpdateRequest(role);
    return this.post<Role>(API_ENDPOINTS.ROLES + '/update', request);
  }

  /**
   * Supprimer un rôle
   * Endpoint: POST /role/delete
   *
   * On évite d'écraser la méthode delete() générique de BaseApiService.
   */
  async deleteRole(roleId: number): Promise<ApiResponse<Role>> {
    const request = this.buildApiRequest({ id: roleId });
    return this.post<Role>(API_ENDPOINTS.ROLES + '/delete', request);
  }

  /**
   * Récupérer les rôles par critères
   * Endpoint: POST /role/getByCriteria
   */
  async getByCriteria(
    filters?: RoleFilters,
    pagination?: { index: number; size: number }
  ): Promise<ApiResponse<Role>> {
    const request = this.buildApiRequest(undefined, filters, pagination);
    return this.post<Role>(API_ENDPOINTS.ROLES + '/getByCriteria', request);
  }

  /**
   * Récupérer tous les rôles actifs
   */
  async getAllRoles(): Promise<ApiResponse<Role>> {
    const filters: RoleFilters = {
      isActive: true,
      isDeleted: false,
    };
    return this.getByCriteria(filters);
  }

  /**
   * Rechercher un rôle par code
   */
  async getRoleByCode(code: string): Promise<ApiResponse<Role>> {
    const filters: RoleFilters = {
      code: code,
    };
    return this.getByCriteria(filters);
  }
}