import { BaseApiService } from "./base-api.service"
import type { ApiResponse } from "@/lib/types/api"

export type CoherenceKpi = {
  totalEleves: number
  totalManuelsRequis: number
  totalManuelsCommandes: number
  totalManuelsDistribues: number
  couvertureGlobale: number
  stockDisponibleTotal: number
  stocksEnRuptureCount: number
  anomaliesCount: number
}

export type CoherenceScopeItem = {
  id: number
  code: string
  libelle: string
  type: string
  kpis: CoherenceKpi
}

export type CoherenceAnomaly = {
  code: string
  severity: string
  message: string
  structureId?: number
  structureCode?: string
  structureLibelle?: string
  matiereCode?: string
  matiereLibelle?: string
  niveauCode?: string
}

export type CoherenceDashboard = {
  anneeScolaireId: number
  roleCode: string
  scopeId: number
  scopeType: string
  scopeCode: string
  scopeLibelle: string
  kpis: CoherenceKpi
  besoins?: {
    total: number
    partA: number
    partB: number
    ecart: number
    anomalies: number
  }
  stocks?: {
    total: number
    partA: number
    partB: number
    ecart: number
    anomalies: number
  }
  distribution?: {
    total: number
    partA: number
    partB: number
    ecart: number
    anomalies: number
  }
  retours?: {
    total: number
    partA: number
    partB: number
    ecart: number
    anomalies: number
  }
  scopes: CoherenceScopeItem[]
  anomalies: CoherenceAnomaly[]
}

type CoherenceRequest = {
  anneeScolaireId: number
  roleCode: string
  structureId?: number
  drenaId?: number
  ieppId?: number
  includeDetails?: boolean
}

class CoherenceService extends BaseApiService {
  private baseEndpoint = "/dashboard"

  private buildRequest(data: CoherenceRequest) {
    const userId = this.getCurrentUserId()
    const token = this.getAuthToken()
    if (!userId || !token) throw new Error("Utilisateur non connecté")
    return { user: userId, token, isSimpleLoading: false, data }
  }

  async getDashboard(params: CoherenceRequest): Promise<ApiResponse<CoherenceDashboard>> {
    return this.request<CoherenceDashboard>(
      "POST",
      `${this.baseEndpoint}/coherence`,
      this.buildRequest(params)
    )
  }
}

export const coherenceService = new CoherenceService()

