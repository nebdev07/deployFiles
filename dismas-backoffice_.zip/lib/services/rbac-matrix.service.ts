/**
 * Matrice RBAC : chargement / enregistrement des permissions par rôle (backend /rbac/matrix).
 */

import { BaseApiService } from "./base-api.service"
import { API_ENDPOINTS } from "@/lib/config/api"
import type { ApiResponse } from "@/lib/types/api"

const BASE = API_ENDPOINTS.RBAC_MATRIX

export const RBAC_PERMISSION_TYPES = [
  "CREATE",
  "READ",
  "UPDATE",
  "DELETE",
  "EXPORT",
  "APPROVE",
  "VALIDATE",
  "CONSOLIDATE",
] as const

export type RbacPermissionType = (typeof RBAC_PERMISSION_TYPES)[number]

export interface RbacMatrixRow {
  fonctionnaliteId: number
  code?: string
  libelle?: string
  roleFonctionaliteId?: number | null
  grantedPermissionTypes: string[]
}

export interface RbacMatrixSnapshot {
  roleId: number
  roleCode?: string
  roleLibelle?: string
  rows: RbacMatrixRow[]
}

export interface RbacMatrixSaveBody {
  roleId: number
  rows: { fonctionnaliteId: number; grantedPermissionTypes: string[] }[]
}

export class RbacMatrixService extends BaseApiService {
  private buildDataRequest<T>(data: T) {
    const userId = this.getCurrentUserId()
    const token = this.getAuthToken()
    if (!userId || !token) {
      throw new Error("Utilisateur non connecté")
    }
    return {
      user: userId,
      token,
      isSimpleLoading: false,
      data,
    }
  }

  async loadMatrix(roleId: number): Promise<ApiResponse<RbacMatrixSnapshot>> {
    return this.request<RbacMatrixSnapshot>("POST", `${BASE}/load`, this.buildDataRequest({ roleId }))
  }

  async saveMatrix(body: RbacMatrixSaveBody): Promise<ApiResponse<unknown>> {
    return this.request("POST", `${BASE}/save`, this.buildDataRequest(body))
  }
}
