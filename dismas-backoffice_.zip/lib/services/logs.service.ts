/**
 * Journal d’audit / logs applicatifs — liste paginée côté backend si exposé.
 * `ApiResponse<T>` : un élément de liste = `T` (pas `T[]`, sinon `items` est typé `T[][]`).
 */

import { BaseApiService } from './base-api.service';
import type { ApiResponse } from '@/lib/types/api';

export type LogRow = {
  id?: number;
  action?: string;
  entity?: string;
  details?: string;
  userId?: number;
  login?: string;
  structureId?: number;
  dateAction?: string;
  createdat?: string;
  ip?: string;
  [key: string]: unknown;
};

class LogsService extends BaseApiService {
  /** Aligné sur `JournalActiviteController` (/journalActivite/getByCriteria). */
  private base = '/journalActivite';

  private buildRequest(data: unknown, isCreateUpdate = false) {
    const userId = this.getCurrentUserId();
    const token = this.getAuthToken();
    if (!userId || !token) throw new Error('Utilisateur non connecté');
    const baseRequest = { user: userId, token, isSimpleLoading: false };
    if (isCreateUpdate) return { ...baseRequest, datas: [data] };
    const payload = data != null && typeof data === 'object' ? { ...(data as object) } : {};
    return { ...baseRequest, data: payload };
  }

  /**
   * Liste paginée — appels possibles :
   * - `list()` ou `list({ userId, structureId, … })`
   * - `list(pageIndex, pageSize)` (comme sur la page `/logs`)
   */
  async list(
    filtersOrPageIndex?:
      | number
      | {
          index?: number;
          size?: number;
          userId?: number;
          structureId?: number;
        },
    pageSize?: number,
  ): Promise<ApiResponse<LogRow>> {
    let filters: {
      index?: number;
      size?: number;
      userId?: number;
      structureId?: number;
    } = {};

    if (typeof filtersOrPageIndex === 'number' && pageSize !== undefined) {
      filters = { index: filtersOrPageIndex, size: pageSize };
    } else if (filtersOrPageIndex != null && typeof filtersOrPageIndex === 'object') {
      filters = { ...filtersOrPageIndex };
    }

    const data: Record<string, unknown> = { isdeleted: false };
    if (filters.userId != null) data.userId = filters.userId;
    if (filters.structureId != null) data.structureId = filters.structureId;
    const req: Record<string, unknown> = this.buildRequest(data) as Record<string, unknown>;
    if (filters.index != null && filters.size != null) {
      req.pagination = { index: filters.index, size: filters.size };
    }
    return this.request<LogRow>('POST', `${this.base}/getByCriteria`, req);
  }

  /**
   * Archivage logique (soft delete) — aligné sur `JournalActiviteController` /update.
   */
  async archive(id: number): Promise<ApiResponse<LogRow>> {
    const userId = this.getCurrentUserId();
    const token = this.getAuthToken();
    if (!userId || !token) throw new Error('Utilisateur non connecté');
    const req = {
      user: userId,
      token,
      isSimpleLoading: false,
      datas: [{ id, isdeleted: true }],
    };
    return this.request<LogRow>('POST', `${this.base}/update`, req);
  }
}

export const logsService = new LogsService();
