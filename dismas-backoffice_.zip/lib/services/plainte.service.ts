/**
 * Plaintes — CRUD (/plainte).
 */

import { BaseApiService } from './base-api.service';
import type { ApiResponse } from '@/lib/types/api';

export type PlaintePayload = {
  id?: number;
  codeSuivi?: string;
  structureId?: number;
  niveauId?: number;
  motif: string;
  objet?: string;
  description: string;
  nomPlaignant?: string;
  contactPlaignant?: string;
  emailPlaignant?: string;
  statut?: string;
  priorite?: string;
  assigneeA?: number;
  resolution?: string;
  dateResolution?: string;
};

export type PlainteRow = PlaintePayload & {
  structureCode?: string;
  structureLibelle?: string;
  structureType?: string;
  assigneeName?: string;
  dateEmission?: string;
  createdat?: string;
  updatedat?: string;
  isdeleted?: boolean;
};

class PlainteService extends BaseApiService {
  private base = '/plainte';

  private buildRequest(data: unknown, isCreateUpdate = false) {
    const userId = this.getCurrentUserId();
    const token = this.getAuthToken();
    if (!userId || !token) throw new Error('Utilisateur non connecté');
    const baseRequest = { user: userId, token, isSimpleLoading: false };
    if (isCreateUpdate) return { ...baseRequest, datas: [data] };
    const payload = data != null && typeof data === 'object' ? { ...(data as object) } : {};
    return { ...baseRequest, data: payload };
  }

  async list(filters?: Partial<PlaintePayload>): Promise<ApiResponse<PlainteRow>> {
    const data: Record<string, unknown> = { isdeleted: false };
    if (filters?.structureId) data.structureId = filters.structureId;
    if (filters?.statut) data.statut = filters.statut;
    return this.request<PlainteRow>('POST', `${this.base}/getByCriteria`, this.buildRequest(data));
  }

  async create(payload: PlaintePayload): Promise<ApiResponse<PlainteRow>> {
    return this.request<PlainteRow>('POST', `${this.base}/create`, this.buildRequest(payload, true));
  }

  async update(payload: PlaintePayload & { id: number }): Promise<ApiResponse<PlainteRow>> {
    return this.request<PlainteRow>('POST', `${this.base}/update`, this.buildRequest(payload, true));
  }

  async remove(id: number): Promise<ApiResponse<PlainteRow>> {
    return this.request<PlainteRow>('POST', `${this.base}/delete`, this.buildRequest({ id }, true));
  }
}

export const plainteService = new PlainteService();
