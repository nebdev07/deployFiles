/**
 * Service d'authentification pour l'API DISMAS
 * Respecte l'architecture backend définie dans le prompt
 * Gère la connexion, validation OTP et gestion des tokens
 */

import { BaseApiService } from './base-api.service';
import { API_ENDPOINTS } from '@/lib/config/api';
import { ApiResponse, LoginApiRequest } from '@/lib/types/api';
import { User, LoginRequest, UserSession } from '@/lib/types/entities';

export class AuthService extends BaseApiService {
  
  /**
   * Connexion utilisateur avec login/password
   * Endpoint: POST /user/connexion
   * Format: { user: "1", data: { login, password, isLdapUser } }
   */
  async login(credentials: LoginRequest): Promise<ApiResponse<User>> {
    const request: LoginApiRequest = {
      user: "1", // Valeur fixe selon le format backend
      data: {
        login: credentials.login,
        password: credentials.password,
        isLdapUser: credentials.isLdapUser || false
      }
    };
    
    return this.post<User>(API_ENDPOINTS.LOGIN, request);
  }

  /**
   * Envoi d'un OTP pour le changement de mot de passe (sans token de session).
   * Endpoint: POST /user/sendOtp
   * Format: { data: { email } }
   */
  async sendPasswordChangeOtp(email: string): Promise<ApiResponse<User>> {
    const requestBody = {
      data: {
        email,
      },
    };

    return this.post<User>(`${API_ENDPOINTS.USERS}/sendOtp`, requestBody);
  }

  /**
   * Changement de mot de passe avec OTP (sans token de session).
   * Endpoint: POST /user/changePassword
   * Backend attend: Request<UserDto> avec email, password (nouveau) et otpCode.
   * Format: { data: { email, password, otpCode } }
   */
  async changePasswordWithOtp(params: {
    email: string;
    newPassword: string;
    otpCode: string;
  }): Promise<ApiResponse<User>> {
    const requestBody = {
      data: {
        email: params.email,
        password: params.newPassword,
        otpCode: params.otpCode,
      },
    };

    return this.post<User>(`${API_ENDPOINTS.USERS}/changePassword`, requestBody);
  }

  /**
   * Changement de mot de passe lors de la première connexion (sans OTP, sans token).
   * Endpoint: POST /user/changePasswordFirstLogin
   * Format: { data: { login, passCode: newPassword } }
   */
  async changePasswordFirstLogin(params: {
    login: string;
    /** Mot de passe actuel (obligatoire — vérifié côté serveur comme à la connexion) */
    currentPassword: string;
    newPassword: string;
  }): Promise<ApiResponse<User>> {
    const requestBody = {
      data: {
        login: params.login,
        password: params.currentPassword,
        passCode: params.newPassword,
      },
    };

    return this.post<User>(`${API_ENDPOINTS.USERS}/changePasswordFirstLogin`, requestBody);
  }

  /**
   * Déconnexion utilisateur
   * Nettoie le localStorage et les tokens
   */
  async logout(): Promise<void> {
    // Supprimer toutes les données d'authentification du localStorage
    if (typeof window !== 'undefined') {
      localStorage.removeItem('auth_token');
      localStorage.removeItem('user_session');
      localStorage.removeItem('dismas_user');
      localStorage.removeItem('token_expiry');
      // window.location.href = '/';
    }
  }

  /**
   * Sauvegarder la session utilisateur avec les tokens fournis par le backend.
   * Utilise user.token / user.tokenExpireAt (et optionnellement tokenCreatedAt).
   * Normalise les dates (ISO string ou timestamp) pour le stockage.
   */
  saveUserSession(apiResponse: ApiResponse<User>): void {
    if (typeof window === 'undefined') return;
    if (!apiResponse?.items?.length) return;

    const user = apiResponse.items[0];
    const token = user?.token ?? (apiResponse as any)?.token;
    if (!token || typeof token !== 'string') {
      console.warn('[Auth] Session non sauvegardée: token manquant dans la réponse backend.');
      return;
    }

    // Normaliser tokenExpireAt (backend peut envoyer ISO string ou timestamp)
    const rawExpiry = user?.tokenExpireAt ?? (apiResponse as any)?.tokenExpireAt;
    const tokenExpireAt = rawExpiry
      ? typeof rawExpiry === 'number'
        ? new Date(rawExpiry).toISOString()
        : String(rawExpiry)
      : new Date(Date.now() + 40 * 60 * 1000).toISOString(); // défaut 40 min si absent

    const userForSession: User = {
      ...user,
      token,
      tokenExpireAt,
      tokenCreatedAt: user?.tokenCreatedAt ?? (apiResponse as any)?.tokenCreatedAt ?? new Date().toISOString(),
    };

    localStorage.setItem('auth_token', token);
    localStorage.setItem('token_expiry', tokenExpireAt);
    localStorage.setItem('user_session', JSON.stringify(userForSession));
    localStorage.setItem('dismas_user', JSON.stringify(userForSession));
  }

  /**
   * Récupérer la session utilisateur depuis le localStorage
   */
  getUserSession(): UserSession | null {
    if (typeof window === 'undefined') return null;

    try {
      const token = localStorage.getItem('auth_token');
      const userStr = localStorage.getItem('user_session') || localStorage.getItem('dismas_user');
      const tokenExpiry = localStorage.getItem('token_expiry');

      if (!token || !userStr || !tokenExpiry) {
        return null;
      }

      const user = JSON.parse(userStr) as User;

      // Vérifier si le token a expiré
      const expiryDate = new Date(tokenExpiry);
      if (expiryDate <= new Date()) {
        this.logout();
        return null;
      }

      return {
        user,
        token,
        tokenExpireAt: tokenExpiry,
        isAuthenticated: true,
      };
    } catch (error) {
      console.error('Error parsing user session:', error);
      this.logout();
      return null;
    }
  }

  /**
   * Vérifier si l'utilisateur est authentifié
   */
  isAuthenticated(): boolean {
    const session = this.getUserSession();
    return session?.isAuthenticated || false;
  }

  /**
   * Obtenir le token d'authentification
   */
  getAuthToken(): string | null {
    if (typeof window !== 'undefined') {
      return localStorage.getItem('auth_token');
    }
    return null;
  }

  /**
   * Obtenir l'utilisateur connecté
   */
  getCurrentUser(): User | null {
    const session = this.getUserSession();
    return session?.user || null;
  }

  /**
   * Vérifier si le token est valide (non expiré)
   */
  isTokenValid(): boolean {
    const tokenExpiry = localStorage.getItem('token_expiry');
    if (!tokenExpiry) return false;

    const expiryDate = new Date(tokenExpiry);
    return expiryDate > new Date();
  }

  /**
   * Rafraîchir le token si nécessaire
   */
  async refreshTokenIfNeeded(): Promise<boolean> {
    if (this.isTokenValid()) {
      return true;
    }

    // Si le token a expiré, déconnecter l'utilisateur
    await this.logout();
    return false;
  }

  /**
   * Vérifier les permissions de l'utilisateur
   * Basé sur le roleCode de l'utilisateur
   */
  hasPermission(functionalityCode: string): boolean {
    const user = this.getCurrentUser();
    if (!user) return false;

    // Logique de vérification des permissions basée sur le roleCode
    const userRole = user.roleCode?.toLowerCase();
    
    // Admin a accès à tout
    if (userRole === 'admin') return true;

    // Logique spécifique selon les fonctionnalités et rôles
    switch (functionalityCode) {
      case 'USER_MANAGEMENT':
        return ['admin', 'daf'].includes(userRole || '');
      case 'STOCK_MANAGEMENT':
        return ['admin', 'daf', 'directeur'].includes(userRole || '');
      case 'DISTRIBUTION':
        return ['admin', 'daf', 'directeur', 'drena'].includes(userRole || '');
      case 'RAPPORTS':
        return ['admin', 'daf', 'drena', 'iepp', 'directeur'].includes(userRole || '');
      case 'ENQUETES':
        return ['admin', 'daf', 'drena', 'iepp', 'directeur'].includes(userRole || '');
      case 'PLAINTES':
        return ['admin', 'daf', 'drena', 'iepp', 'directeur'].includes(userRole || '');
      default:
        return false;
    }
  }

  /**
   * Obtenir les informations de session pour les en-têtes
   */
  getSessionHeaders(): Record<string, string> {
    const token = this.getAuthToken();
    return token ? { Authorization: `Bearer ${token}` } : {};
  }

  /**
   * Valider les credentials avant envoi
   */
  validateCredentials(credentials: LoginRequest): { isValid: boolean; error?: string } {
    if (!credentials.login || !credentials.password) {
      return { isValid: false, error: 'Matricule et mot de passe requis' };
    }

    if (credentials.login.length < 3) {
      return { isValid: false, error: 'Le matricule doit contenir au moins 3 caractères' };
    }

    if (credentials.password.length < 6) {
      return { isValid: false, error: 'Le mot de passe doit contenir au moins 6 caractères' };
    }

    return { isValid: true };
  }
}

// Export de l'instance du service
export const authService = new AuthService();