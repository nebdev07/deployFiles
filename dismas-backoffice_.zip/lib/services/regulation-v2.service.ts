/**
 * Régulation inter-établissements — demandes multi-sources, accords, exécution, don DAF direct.
 */

import { BaseApiService } from "./base-api.service"
import type { ApiResponse } from "../types/api"
import type { RegulationDto } from "./regulation.service"

export type RegulationV2SourceInput = {
  structureSourceId: number
  /** EPP destinataire pour cette ligne (multi-destinations). Si absent, utiliser eppDestId sur la demande. */
  structureDestId?: number
  matiereId: number
  niveauId: number
  quantite: number
}

export type RegulationV2IeppLigneInput = {
  ieppSourceId: number
  ieppDestId: number
  matiereId: number
  niveauId: number
  quantite: number
}

/** Ligne de suivi (toutes lignes d’une demande, avec statut accord source). */
export type RegulationV2SuiviLigneRow = {
  ligneId: number
  regulationId: number
  reference?: string
  type?: string
  matiereId: number
  niveauId: number
  quantite: number
  structureDestId: number
  structureSourceId: number
  /** EN_ATTENTE | ACCEPTE | REFUSE */
  statutLigne?: string
  /** Plafond d’ajustement (copié à l’acceptation source) ; absent = fallback sur `quantite`. */
  quantiteAccordSource?: number | null
  matiereCode?: string
  matiereLibelle?: string
  niveauCode?: string
  niveauLibelle?: string
  structureDestCode?: string
  structureDestLibelle?: string
  structureSourceCode?: string
  structureSourceLibelle?: string
  /** Statut de l’en-tête régulation (ex. EN_ATTENTE_VALIDATION_IEPP, EN_ATTENTE_ACCORDS). */
  statutDemande?: string
}

export type RegulationV2PendingRow = {
  ligneId: number
  regulationId: number
  reference?: string
  type?: string
  matiereId: number
  niveauId: number
  quantite: number
  structureDestId: number
  structureSourceId: number
  /** SOURCE = EPP excédentaire (accord) ; DESTINATION = EPP bénéficiaire (suivi). */
  cote?: "SOURCE" | "DESTINATION"
  /** Accorder / refuser autorisé côté UI (false pour DESTINATION ou validation IEPP en cours). */
  peutAccorder?: boolean
  statutDemande?: string
  /** Libellés enrichis par le backend (affichage sans exposer les IDs) */
  matiereCode?: string
  matiereLibelle?: string
  niveauCode?: string
  niveauLibelle?: string
  structureDestCode?: string
  structureDestLibelle?: string
  structureSourceCode?: string
  structureSourceLibelle?: string
}

class RegulationV2Service extends BaseApiService {
  private baseEndpoint = "/regulation/v2"

  async creerDemandeEpp(payload: {
    ieppId: number
    /** Optionnel si chaque source définit structureDestId */
    eppDestId?: number
    anneeScolaireId: number
    commentaire?: string
    sources: RegulationV2SourceInput[]
  }): Promise<ApiResponse<RegulationDto>> {
    const userId = this.getCurrentUserId()
    const token = this.getAuthToken()
    if (!userId || !token) throw new Error("Utilisateur non connecté")
    return this.post<RegulationDto>(`${this.baseEndpoint}/creer-demande-epp`, {
      user: userId,
      token,
      isSimpleLoading: false,
      data: payload,
    })
  }

  /** Variante DRENA/DAF : sources EPP multi-IEPP du ressort, destination dans l'IEPP ciblé. */
  async creerDemandeEppDrena(payload: {
    ieppId: number
    /** Optionnel si chaque source définit structureDestId */
    eppDestId?: number
    anneeScolaireId: number
    commentaire?: string
    sources: RegulationV2SourceInput[]
  }): Promise<ApiResponse<RegulationDto>> {
    const userId = this.getCurrentUserId()
    const token = this.getAuthToken()
    if (!userId || !token) throw new Error("Utilisateur non connecté")
    return this.post<RegulationDto>(`${this.baseEndpoint}/creer-demande-epp-drena`, {
      user: userId,
      token,
      isSimpleLoading: false,
      data: payload,
    })
  }

  async creerDemandeIepp(payload: {
    drenaId: number
    anneeScolaireId: number
    commentaire?: string
    lignes: RegulationV2IeppLigneInput[]
  }): Promise<ApiResponse<RegulationDto>> {
    const userId = this.getCurrentUserId()
    const token = this.getAuthToken()
    if (!userId || !token) throw new Error("Utilisateur non connecté")
    return this.post<RegulationDto>(`${this.baseEndpoint}/creer-demande-iepp`, {
      user: userId,
      token,
      isSimpleLoading: false,
      data: payload,
    })
  }

  async approuverLigne(ligneId: number): Promise<ApiResponse<Record<string, unknown>>> {
    const userId = this.getCurrentUserId()
    const token = this.getAuthToken()
    if (!userId || !token) throw new Error("Utilisateur non connecté")
    return this.post<Record<string, unknown>>(`${this.baseEndpoint}/approuver-ligne`, {
      user: userId,
      token,
      isSimpleLoading: false,
      data: { id: ligneId },
    })
  }

  async refuserLigne(ligneId: number): Promise<ApiResponse<Record<string, unknown>>> {
    const userId = this.getCurrentUserId()
    const token = this.getAuthToken()
    if (!userId || !token) throw new Error("Utilisateur non connecté")
    return this.post<Record<string, unknown>>(`${this.baseEndpoint}/refuser-ligne`, {
      user: userId,
      token,
      isSimpleLoading: false,
      data: { id: ligneId },
    })
  }

  async getAgregatDeficitsIepp(ieppId: number, anneeScolaireId: number): Promise<
    ApiResponse<{
      matiereId: number
      matiereCode?: string
      matiereLibelle?: string
      niveauId: number
      niveauCode?: string
      niveauLibelle?: string
      deficitTotal: number
      repartitionParEpp: Array<{ eppId: number; eppLibelle?: string; deficit: number }>
    }>
  > {
    const userId = this.getCurrentUserId()
    const token = this.getAuthToken()
    if (!userId || !token) throw new Error("Utilisateur non connecté")
    return this.post(`${this.baseEndpoint}/agregat-deficits-iepp`, {
      user: userId,
      token,
      isSimpleLoading: false,
      data: { ieppId, initieePar: ieppId, anneeScolaireId },
    })
  }

  async executerDemande(regulationId: number): Promise<ApiResponse<RegulationDto>> {
    const userId = this.getCurrentUserId()
    const token = this.getAuthToken()
    if (!userId || !token) throw new Error("Utilisateur non connecté")
    return this.post<RegulationDto>(`${this.baseEndpoint}/executer-demande`, {
      user: userId,
      token,
      isSimpleLoading: false,
      data: { id: regulationId },
    })
  }

  async ajusterQuantitesExecution(payload: {
    regulationId: number
    ajustements: Array<{ ligneId: number; quantite: number }>
  }): Promise<ApiResponse<Record<string, unknown>>> {
    const userId = this.getCurrentUserId()
    const token = this.getAuthToken()
    if (!userId || !token) throw new Error("Utilisateur non connecté")
    return this.post<Record<string, unknown>>(`${this.baseEndpoint}/ajuster-quantites-execution`, {
      user: userId,
      token,
      isSimpleLoading: false,
      data: payload,
    })
  }

  /** IEPP destinataire : ajuster les lignes EN_ATTENTE avant transmission aux EPP (demande initiée par la DRENA). */
  async ajusterQuantitesPendantValidationIepp(payload: {
    regulationId: number
    ajustements: Array<{ ligneId: number; quantite: number }>
  }): Promise<ApiResponse<Record<string, unknown>>> {
    const userId = this.getCurrentUserId()
    const token = this.getAuthToken()
    if (!userId || !token) throw new Error("Utilisateur non connecté")
    return this.post<Record<string, unknown>>(`${this.baseEndpoint}/ajuster-quantites-validation-iepp`, {
      user: userId,
      token,
      isSimpleLoading: false,
      data: payload,
    })
  }

  async validerDemandeV2ParIepp(regulationId: number): Promise<ApiResponse<RegulationDto>> {
    const userId = this.getCurrentUserId()
    const token = this.getAuthToken()
    if (!userId || !token) throw new Error("Utilisateur non connecté")
    return this.post<RegulationDto>(`${this.baseEndpoint}/valider-demande-iepp`, {
      user: userId,
      token,
      isSimpleLoading: false,
      data: { id: regulationId },
    })
  }

  async refuserDemandeV2ValidationIepp(regulationId: number): Promise<ApiResponse<RegulationDto>> {
    const userId = this.getCurrentUserId()
    const token = this.getAuthToken()
    if (!userId || !token) throw new Error("Utilisateur non connecté")
    return this.post<RegulationDto>(`${this.baseEndpoint}/refuser-demande-validation-iepp`, {
      user: userId,
      token,
      isSimpleLoading: false,
      data: { id: regulationId },
    })
  }

  async listerSuiviLignesIepp(ieppId: number, anneeScolaireId: number): Promise<ApiResponse<RegulationV2SuiviLigneRow>> {
    const userId = this.getCurrentUserId()
    const token = this.getAuthToken()
    if (!userId || !token) throw new Error("Utilisateur non connecté")
    return this.post<RegulationV2SuiviLigneRow>(`${this.baseEndpoint}/suivi-lignes-iepp`, {
      user: userId,
      token,
      isSimpleLoading: false,
      data: { ieppId, anneeScolaireId },
    })
  }

  async listerLignesEnAttente(): Promise<ApiResponse<RegulationV2PendingRow>> {
    const userId = this.getCurrentUserId()
    const token = this.getAuthToken()
    if (!userId || !token) throw new Error("Utilisateur non connecté")
    return this.post<RegulationV2PendingRow>(`${this.baseEndpoint}/lignes-en-attente`, {
      user: userId,
      token,
      isSimpleLoading: false,
      data: {},
    })
  }

  async donDafDirect(payload: {
    dafId: number
    destStructureId: number
    matiereId: number
    niveauId: number
    quantite: number
    anneeScolaireId: number
    commentaire?: string
  }): Promise<ApiResponse<RegulationDto>> {
    const userId = this.getCurrentUserId()
    const token = this.getAuthToken()
    if (!userId || !token) throw new Error("Utilisateur non connecté")
    return this.post<RegulationDto>(`${this.baseEndpoint}/don-daf-direct`, {
      user: userId,
      token,
      isSimpleLoading: false,
      data: payload,
    })
  }
}

export const regulationV2Service = new RegulationV2Service()
