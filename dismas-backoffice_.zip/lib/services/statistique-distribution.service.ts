/**
 * Service pour les statistiques de distribution (tableau de bord).
 * Endpoint backend existant: POST /statistiqueDistribution/getByCriteria
 */

import { BaseApiService } from "./base-api.service"
import type { ApiResponse } from "@/lib/types/api"

export interface StatistiqueDistributionDto {
  id?: number
  anneeScolaireId?: number
  structureId?: number
  niveauId?: number
  effectifTotal?: number
  effectifGarcons?: number
  effectifFilles?: number
  nbManuelsAttendus?: number
  nbManuelsRecus?: number
  nbManuelsDistribues?: number
  tauxCouverture?: number
  dateCalcul?: string
  createdat?: string
  createdby?: number
  updatedat?: string
  updatedby?: number
  isdeleted?: boolean
}

class StatistiqueDistributionService extends BaseApiService {
  private baseEndpoint = "/statistiqueDistribution"

  private buildRequest(data: any) {
    const userId = this.getCurrentUserId()
    const token = this.getAuthToken()

    if (!userId || !token) {
      throw new Error("Utilisateur non connecté")
    }

    return {
      user: userId,
      token,
      isSimpleLoading: false,
      data,
    }
  }

  async getByCriteria(filters: {
    anneeScolaireId: number
    structureId: number
    niveauId?: number
  }): Promise<ApiResponse<StatistiqueDistributionDto>> {
    const data = {
      id: "",
      anneeScolaireId: String(filters.anneeScolaireId ?? ""),
      structureId: String(filters.structureId ?? ""),
      niveauId: filters.niveauId != null ? String(filters.niveauId) : "",
      effectifTotal: "",
      effectifGarcons: "",
      effectifFilles: "",
      nbManuelsAttendus: "",
      nbManuelsRecus: "",
      nbManuelsDistribues: "",
      tauxCouverture: "",
      dateCalcul: "",
      createdat: "",
      createdby: "",
      updatedat: "",
      updatedby: "",
      isdeleted: "false",
    }

    return this.request<StatistiqueDistributionDto>(
      "POST",
      `${this.baseEndpoint}/getByCriteria`,
      this.buildRequest(data),
    )
  }
}

export const statistiqueDistributionService = new StatistiqueDistributionService()

