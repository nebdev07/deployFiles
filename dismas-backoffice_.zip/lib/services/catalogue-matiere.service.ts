import { BaseApiService } from './base-api.service'
import { CatalogueMatiere, CatalogueMatiereFilters } from '@/lib/types/entities'

/**
 * Service pour gérer les associations Catalogue-Matière
 */
export class CatalogueMatiereService extends BaseApiService {
  private baseEndpoint = '/catalogueMatiere'

  constructor() {
    super()
  }

  /**
   * Récupérer toutes les associations catalogue-matière
   */
  async getCatalogueMatieres(filters?: CatalogueMatiereFilters) {
    const userId = this.getCurrentUserId();
    const token = this.getAuthToken();
    
    // Vérifier si l'utilisateur est connecté
    if (!userId || !token) {
      console.warn('Utilisateur non connecté - impossible de charger les associations catalogue-matière');
      throw new Error('Utilisateur non connecté');
    }

    const data = {
      catalogueId: filters?.catalogueId || "",
      matiereId: filters?.matiereId || "",
      catalogueCode: filters?.catalogueCode || "",
      matiereCode: filters?.matiereCode || "",
      isdeleted: filters?.isDeleted || ""
    };

    const request = {
      user: userId,
      token: token,
      isSimpleLoading: false,
      data: data
    }

    return this.request<CatalogueMatiere[]>('POST', `${this.baseEndpoint}/getByCriteria`, request)
  }

  /**
   * Récupérer les matières associées à un catalogue spécifique
   */
  async getMatieresByCatalogueId(catalogueId: number) {
    const userId = this.getCurrentUserId();
    const token = this.getAuthToken();
    
    // Vérifier si l'utilisateur est connecté
    if (!userId || !token) {
      console.warn('Utilisateur non connecté - impossible de charger les matières du catalogue');
      throw new Error('Utilisateur non connecté');
    }

    const request = {
      user: userId,
      token: token,
      isSimpleLoading: false,
      data: {
        catalogueId: catalogueId
      }
    }

    return this.request<CatalogueMatiere[]>('POST', `${this.baseEndpoint}/getByCriteria`, request)
  }

  /**
   * Récupérer une association catalogue-matière par ID
   */
  async getCatalogueMatiereById(id: number) {
    const userId = this.getCurrentUserId();
    const token = this.getAuthToken();
    
    if (!userId || !token) {
      throw new Error('Utilisateur non connecté');
    }

    const data = {
      id: id.toString(),
      catalogueId: "",
      matiereId: "",
      catalogueCode: "",
      matiereCode: "",
      isdeleted: ""
    };

    const request = {
      user: userId,
      token: token,
      isSimpleLoading: false,
      data: data
    }

    return this.request<CatalogueMatiere[]>('POST', `${this.baseEndpoint}/getByCriteria`, request)
  }

  /**
   * Créer une nouvelle association catalogue-matière
   */
  async createCatalogueMatiere(data: Partial<CatalogueMatiere>) {
    const userId = this.getCurrentUserId();
    const token = this.getAuthToken();
    
    if (!userId || !token) {
      throw new Error('Utilisateur non connecté');
    }

    const request = {
      user: userId,
      token: token,
      isSimpleLoading: false,
      data: data
    }

    return this.request<CatalogueMatiere>('POST', `${this.baseEndpoint}/create`, request)
  }

  /**
   * Mettre à jour une association catalogue-matière
   */
  async updateCatalogueMatiere(id: number, data: Partial<CatalogueMatiere>) {
    const userId = this.getCurrentUserId();
    const token = this.getAuthToken();
    
    if (!userId || !token) {
      throw new Error('Utilisateur non connecté');
    }

    const request = {
      user: userId,
      token: token,
      isSimpleLoading: false,
      data: { ...data, id }
    }

    return this.request<CatalogueMatiere>('POST', `${this.baseEndpoint}/update`, request)
  }

  /**
   * Supprimer une association catalogue-matière
   */
  async deleteCatalogueMatiere(id: number) {
    const userId = this.getCurrentUserId();
    const token = this.getAuthToken();
    
    if (!userId || !token) {
      throw new Error('Utilisateur non connecté');
    }

    const request = {
      user: userId,
      token: token,
      isSimpleLoading: false,
      data: { id }
    }

    return this.request<void>('POST', `${this.baseEndpoint}/delete`, request)
  }
}

export const catalogueMatiereService = new CatalogueMatiereService()
