/**
 * Service pour la gestion des matières
 * Suit le même pattern que users.service.ts
 */

import { BaseApiService } from './base-api.service';
import { ApiResponse } from '@/lib/types/api';
import { Matiere, CreateMatiereRequest, MatiereFilters } from '@/lib/types/entities';

class MatiereService extends BaseApiService {
  private baseEndpoint = '/matiere';

  // Fonction utilitaire pour construire les requêtes selon le format backend
  private buildRequest(data: any, isCreateUpdate = false) {
    const userId = this.getCurrentUserId();
    const token = this.getAuthToken();
    
    // Vérifier si l'utilisateur est connecté
    if (!userId || !token) {
      console.warn('Utilisateur non connecté - impossible de charger les matières');
      throw new Error('Utilisateur non connecté');
    }
    
    const baseRequest = {
      user: userId,
      token: token,
      isSimpleLoading: false
    };
    
    if (isCreateUpdate) {
      // Pour CREATE/UPDATE/DELETE, utiliser "datas" avec un tableau
      return {
        ...baseRequest,
        datas: [data]
      };
    } else {
      // Pour GET/SEARCH, utiliser "data" avec un objet
      return {
        ...baseRequest,
        data
      };
    }
  }

  // Récupérer toutes les matières avec filtres
  async getMatieres(filters?: MatiereFilters): Promise<ApiResponse<Matiere[]>> {
    const data = {
      id: "",
      code: filters?.code || "",
      libelle: filters?.libelle || "",
      description: filters?.description || "",
      isactif: filters?.isActif || "",
      createdat: "",
      createdby: "",
      updatedat: "",
      updatedby: "",
      isdeleted: filters?.isDeleted || ""
    };
    
    return this.request<Matiere[]>('POST', `${this.baseEndpoint}/getByCriteria`, this.buildRequest(data));
  }

  // Récupérer une matière par ID
  async getMatiereById(id: number): Promise<ApiResponse<Matiere[]>> {
    const data = {
      id: id.toString(),
      code: "",
      libelle: "",
      description: "",
      isactif: "",
      createdat: "",
      createdby: "",
      updatedat: "",
      updatedby: "",
      isdeleted: ""
    };
    return this.request<Matiere[]>('POST', `${this.baseEndpoint}/getByCriteria`, this.buildRequest(data));
  }

  // Créer une nouvelle matière
  async createMatiere(matiereData: CreateMatiereRequest): Promise<ApiResponse<Matiere[]>> {
    // Construire la requête avec le format "datas" pour la création
    const requestData = this.buildRequest(matiereData, true);
    return this.request<Matiere[]>('POST', `${this.baseEndpoint}/create`, requestData);
  }

  // Mettre à jour une matière
  async updateMatiere(id: number, matiereData: Partial<CreateMatiereRequest>): Promise<ApiResponse<Matiere[]>> {
    const data = { id, ...matiereData };
    // Construire la requête avec le format "datas" pour la mise à jour
    const requestData = this.buildRequest(data, true);
    return this.request<Matiere[]>('POST', `${this.baseEndpoint}/update`, requestData);
  }

  // Supprimer une matière (soft delete)
  async deleteMatiere(id: number): Promise<ApiResponse<Matiere[]>> {
    const data = { id };
    // Construire la requête avec le format "datas" pour la suppression
    const requestData = this.buildRequest(data, true);
    return this.request<Matiere[]>('POST', `${this.baseEndpoint}/delete`, requestData);
  }

  // Rechercher des matières par terme
  async searchMatieres(searchTerm: string): Promise<ApiResponse<Matiere[]>> {
    const data = {
      id: "",
      code: searchTerm,
      libelle: searchTerm,
      description: searchTerm,
      isactif: "",
      createdat: "",
      createdby: "",
      updatedat: "",
      updatedby: "",
      isdeleted: ""
    };
    
    return this.request<Matiere[]>('POST', `${this.baseEndpoint}/getByCriteria`, this.buildRequest(data));
  }

  // Vérifier si un code matière existe déjà
  async checkCodeExists(code: string, excludeId?: number): Promise<boolean> {
    try {
      const data = {
        id: "",
        code: code,
        libelle: "",
        description: "",
        isactif: "",
        createdat: "",
        createdby: "",
        updatedat: "",
        updatedby: "",
        isdeleted: ""
      };
      const response = await this.request<Matiere[]>('POST', `${this.baseEndpoint}/getByCriteria`, this.buildRequest(data));
      
      const items = (response.items ?? []) as unknown as Matiere[];
      if (items.length > 0) {
        // Si on exclut un ID (pour la mise à jour), vérifier que ce n'est pas la même matière
        if (excludeId) {
          return items.some(matiere => matiere.id !== excludeId);
        }
        return true;
      }
      return false;
    } catch (error) {
      console.error('Erreur lors de la vérification du code matière:', error);
      return false;
    }
  }

  /** Matières avec is_actif = true (booléen JSON → MatiereDto.isActif) et non supprimées. */
  async getActivesMatieres(): Promise<ApiResponse<Matiere[]>> {
    const data = {
      isActif: true,
      isdeleted: false,
    };
    return this.request<Matiere[]>('POST', `${this.baseEndpoint}/getByCriteria`, this.buildRequest(data));
  }
}

export const matiereService = new MatiereService();
