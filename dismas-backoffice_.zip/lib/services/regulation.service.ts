/*
 * Service pour les régulations
 * Created on 2026-01-11
 */

import { BaseApiService } from "./base-api.service";
import type { ApiResponse } from "../types/api";

export type RegulationPrerequisAlerteDto = {
  structureId?: number;
  structureCode?: string;
  structureLibelle?: string;
  /** IEPP | DRENA */
  niveau?: string;
  statutOuManque?: string;
};

export interface RegulationDto {
  id?: number;
  reference?: string;
  anneeScolaireId?: number;
  dateRegulation?: string | Date;
  sourceId?: number;
  destinationId?: number;
  type?: string;
  initieePar?: number;
  valideePar?: number;
  dateValidation?: string | Date;
  statut?: string; // PROGRAMMEE, VALIDE, EN_COURS, TERMINEE, ANNULEE
  commentaire?: string;
  createdat?: string;
  createdby?: number;
  updatedat?: string;
  updatedby?: number;
  isdeleted?: boolean;
  // ✅ NOUVEAU : Champs pour le système de régulation programmée
  dateRecuperation?: string | Date;
  tauxRecuperation?: number; // 0.0 à 1.0 (ex: 0.90 = 90%)
  ieppId?: number;
  /** Structure admin DRENA (filtre getByCriteria / stats) */
  drenaId?: number;
  /** Réponse programmer-drena / programmer-daf : IEPP ou DRENA sans récupération TERMINEE (n’empêche pas la programmation) */
  alertesPrerequis?: RegulationPrerequisAlerteDto[];
}

export interface DetailRegulationDto {
  id?: number;
  regulationId?: number;
  manuelId?: number;
  quantite?: number;
  observations?: string;
  createdat?: string;
  createdby?: number;
  updatedat?: string;
  updatedby?: number;
  isdeleted?: boolean;
}

export interface RedistributionRequest {
  ieppId: number;
  eppId: number;
  matiereId: number;
  niveauId: number;
  quantite: number;
  anneeScolaireId: number;
  commentaire?: string;
}

export type StructureDeficitItem = {
  matiereId: number;
  matiereCode: string;
  matiereLibelle: string;
  niveauId: number;
  niveauCode: string;
  niveauLibelle: string;
  effectifClasse: number;
  quantiteRecueTotale: number;
  deficit: number;
};

export type StructureExcedentItem = {
  matiereId: number;
  matiereCode: string;
  matiereLibelle: string;
  niveauId: number;
  niveauCode: string;
  niveauLibelle: string;
  effectifClasse: number;
  quantiteRecueTotale: number;
  excedent: number;
};

/** Désactive les boutons hub DRENA/DAF si `NEXT_PUBLIC_REGULATION_MULTI_LEVEL=false` */
export function isRegulationMultiLevelEnabled(): boolean {
  return typeof process !== "undefined" && process.env.NEXT_PUBLIC_REGULATION_MULTI_LEVEL !== "false";
}

class RegulationService extends BaseApiService {
  private baseEndpoint = "/regulation";

  constructor() {
    super();
  }

  /**
   * Programme une régulation
   */
  async programmerRegulation(data: {
    ieppId: number;
    dateRecuperation: string | Date;
    tauxRecuperation: number;
    anneeScolaireId: number;
    commentaire?: string;
  }): Promise<ApiResponse<RegulationDto>> {
    const userId = this.getCurrentUserId();
    const token = this.getAuthToken();
    
    if (!userId || !token) {
      throw new Error('Utilisateur non connecté');
    }
    
    const request = {
      user: userId,
      token: token,
      isSimpleLoading: false,
      data: {
        ieppId: data.ieppId,
        dateRecuperation: data.dateRecuperation instanceof Date 
          ? this.formatDate(data.dateRecuperation) 
          : data.dateRecuperation,
        tauxRecuperation: data.tauxRecuperation,
        anneeScolaireId: data.anneeScolaireId,
        commentaire: data.commentaire,
        statut: "PROGRAMMEE",
      },
    };

    return this.post<RegulationDto>(`${this.baseEndpoint}/programmer`, request);
  }

  /**
   * Programmation récupération au périmètre DRENA (alertes IEPP non TERMINEE sans blocage).
   * ADMIN : fournir drenaId (structure admin). DRENA : drenaId optionnel (sa structure).
   */
  async programmerRegulationDrena(data: {
    drenaId?: number;
    dateRecuperation: string | Date;
    tauxRecuperation: number;
    anneeScolaireId: number;
    commentaire?: string;
  }): Promise<ApiResponse<RegulationDto>> {
    const userId = this.getCurrentUserId();
    const token = this.getAuthToken();
    if (!userId || !token) throw new Error("Utilisateur non connecté");
    const request = {
      user: userId,
      token,
      isSimpleLoading: false,
      data: {
        drenaId: data.drenaId,
        dateRecuperation:
          data.dateRecuperation instanceof Date ? this.formatDate(data.dateRecuperation) : data.dateRecuperation,
        tauxRecuperation: data.tauxRecuperation,
        anneeScolaireId: data.anneeScolaireId,
        commentaire: data.commentaire,
        statut: "PROGRAMMEE",
      },
    };
    return this.post<RegulationDto>(`${this.baseEndpoint}/programmer-drena`, request);
  }

  /** Programmation nationale DAF (alertes DRENA non TERMINEE sans blocage). */
  async programmerRegulationDaf(data: {
    dateRecuperation: string | Date;
    tauxRecuperation: number;
    anneeScolaireId: number;
    commentaire?: string;
  }): Promise<ApiResponse<RegulationDto>> {
    const userId = this.getCurrentUserId();
    const token = this.getAuthToken();
    if (!userId || !token) throw new Error("Utilisateur non connecté");
    const request = {
      user: userId,
      token,
      isSimpleLoading: false,
      data: {
        dateRecuperation:
          data.dateRecuperation instanceof Date ? this.formatDate(data.dateRecuperation) : data.dateRecuperation,
        tauxRecuperation: data.tauxRecuperation,
        anneeScolaireId: data.anneeScolaireId,
        commentaire: data.commentaire,
        statut: "PROGRAMMEE",
      },
    };
    return this.post<RegulationDto>(`${this.baseEndpoint}/programmer-daf`, request);
  }

  /**
   * Valide une régulation programmée
   */
  async validerRegulation(regulationId: number): Promise<ApiResponse<RegulationDto>> {
    const userId = this.getCurrentUserId();
    const token = this.getAuthToken();
    
    if (!userId || !token) {
      throw new Error('Utilisateur non connecté');
    }
    
    const request = {
      user: userId,
      token: token,
      isSimpleLoading: false,
      data: {
        id: regulationId,
      },
    };

    return this.post<RegulationDto>(`${this.baseEndpoint}/valider`, request);
  }

  /**
   * Annule une régulation
   */
  async annulerRegulation(regulationId: number, raison: string): Promise<ApiResponse<RegulationDto>> {
    const userId = this.getCurrentUserId();
    const token = this.getAuthToken();
    
    if (!userId || !token) {
      throw new Error('Utilisateur non connecté');
    }
    
    const request = {
      user: userId,
      token: token,
      isSimpleLoading: false,
      data: {
        id: regulationId,
        commentaire: raison,
      },
    };

    return this.post<RegulationDto>(`${this.baseEndpoint}/annuler`, request);
  }

  /**
   * Exécute manuellement une régulation (pour tests)
   * Vérifie que la date de récupération est arrivée
   */
  async executerRegulation(regulationId: number): Promise<ApiResponse<RegulationDto>> {
    const userId = this.getCurrentUserId();
    const token = this.getAuthToken();
    
    if (!userId || !token) {
      throw new Error('Utilisateur non connecté');
    }
    
    const request = {
      user: userId,
      token: token,
      isSimpleLoading: false,
      data: {
        id: regulationId,
      },
    };

    return this.post<RegulationDto>(`${this.baseEndpoint}/executer`, request);
  }

  /**
   * Exécute immédiatement une régulation validée (sans vérifier la date)
   * Permet à l'IEPP d'exécuter spontanément une régulation avant la date programmée
   */
  async executerRegulationImmediatement(regulationId: number): Promise<ApiResponse<RegulationDto>> {
    const userId = this.getCurrentUserId();
    const token = this.getAuthToken();
    
    if (!userId || !token) {
      throw new Error('Utilisateur non connecté');
    }
    
    const request = {
      user: userId,
      token: token,
      isSimpleLoading: false,
      data: {
        id: regulationId,
      },
    };

    return this.post<RegulationDto>(`${this.baseEndpoint}/executer-immediatement`, request);
  }

  /**
   * Redistribue des stocks de l'IEPP vers un EPP déficitaire
   */
  async redistribuerStock(data: RedistributionRequest): Promise<ApiResponse<RegulationDto>> {
    const userId = this.getCurrentUserId();
    const token = this.getAuthToken();
    
    if (!userId || !token) {
      throw new Error('Utilisateur non connecté');
    }
    
    const request = {
      user: userId,
      token: token,
      isSimpleLoading: false,
      data: {
        initieePar: data.ieppId, // Temporaire: initieePar = ieppId
        destinationId: data.eppId, // destinationId = eppId
        sourceId: data.matiereId, // Temporaire: sourceId = matiereId
        valideePar: data.niveauId, // Temporaire: valideePar = niveauId
        tauxRecuperation: data.quantite, // Temporaire: tauxRecuperation = quantite
        anneeScolaireId: data.anneeScolaireId,
        commentaire: data.commentaire,
      },
    };

    return this.post<RegulationDto>(`${this.baseEndpoint}/redistribuer`, request);
  }

  /**
   * Redistribution hub DRENA → IEPP (backend: /regulation/redistribuer-drena-iepp)
   */
  async redistribuerDrenaIepp(data: {
    drenaId: number;
    ieppId: number;
    matiereId: number;
    niveauId: number;
    quantite: number;
    anneeScolaireId: number;
    commentaire?: string;
  }): Promise<ApiResponse<RegulationDto>> {
    const userId = this.getCurrentUserId();
    const token = this.getAuthToken();
    if (!userId || !token) throw new Error("Utilisateur non connecté");
    const request = {
      user: userId,
      token,
      isSimpleLoading: false,
      data: {
        drenaId: data.drenaId,
        destinationId: data.ieppId,
        sourceId: data.matiereId,
        valideePar: data.niveauId,
        tauxRecuperation: data.quantite,
        anneeScolaireId: data.anneeScolaireId,
        commentaire: data.commentaire,
      },
    };
    return this.post<RegulationDto>(`${this.baseEndpoint}/redistribuer-drena-iepp`, request);
  }

  /**
   * Redistribution hub DAF → DRENA (backend: /regulation/redistribuer-daf-drena)
   */
  async redistribuerDafDrena(data: {
    dafId: number;
    drenaId: number;
    matiereId: number;
    niveauId: number;
    quantite: number;
    anneeScolaireId: number;
    commentaire?: string;
  }): Promise<ApiResponse<RegulationDto>> {
    const userId = this.getCurrentUserId();
    const token = this.getAuthToken();
    if (!userId || !token) throw new Error("Utilisateur non connecté");
    const request = {
      user: userId,
      token,
      isSimpleLoading: false,
      data: {
        initieePar: data.dafId,
        destinationId: data.drenaId,
        sourceId: data.matiereId,
        valideePar: data.niveauId,
        tauxRecuperation: data.quantite,
        anneeScolaireId: data.anneeScolaireId,
        commentaire: data.commentaire,
      },
    };
    return this.post<RegulationDto>(`${this.baseEndpoint}/redistribuer-daf-drena`, request);
  }

  /**
   * Agrégat des EPP déficitaires par IEPP pour une DRENA.
   */
  async getIeppDeficitairesByDrena(
    drenaId: number,
    anneeScolaireId: number
  ): Promise<
    ApiResponse<{
      ieppId: number;
      ieppCode: string;
      ieppLibelle: string;
      eppDeficitaires: unknown[];
    }>
  > {
    const userId = this.getCurrentUserId();
    const token = this.getAuthToken();
    if (!userId || !token) throw new Error("Utilisateur non connecté");
    const request = {
      user: userId,
      token,
      isSimpleLoading: false,
      data: {
        drenaId,
        anneeScolaireId,
      },
    };
    return this.post(`${this.baseEndpoint}/iepp-deficitaires-drena`, request);
  }

  /**
   * Agrégat des EPP excédentaires par IEPP pour une DRENA.
   */
  async getIeppExcedentairesByDrena(
    drenaId: number,
    anneeScolaireId: number
  ): Promise<
    ApiResponse<{
      ieppId: number;
      ieppCode: string;
      ieppLibelle: string;
      eppExcedentaires: unknown[];
    }>
  > {
    const userId = this.getCurrentUserId();
    const token = this.getAuthToken();
    if (!userId || !token) throw new Error("Utilisateur non connecté");
    const request = {
      user: userId,
      token,
      isSimpleLoading: false,
      data: {
        drenaId,
        anneeScolaireId,
      },
    };
    return this.post(`${this.baseEndpoint}/iepp-excedentaires-drena`, request);
  }

  /**
   * Récupère le stock récupéré lors des régulations par matière et niveau pour un IEPP
   */
  async getStockRecupere(ieppId: number, anneeScolaireId: number): Promise<ApiResponse<{ matiereId: number; niveauId: number; stockRecupere: number }>> {
    const userId = this.getCurrentUserId();
    const token = this.getAuthToken();
    
    if (!userId || !token) {
      throw new Error('Utilisateur non connecté');
    }
    
    const request = {
      user: userId,
      token: token,
      isSimpleLoading: false,
      data: {
        initieePar: ieppId, // Temporaire: initieePar = ieppId
        anneeScolaireId: anneeScolaireId,
      },
    };

    return this.post<{ matiereId: number; niveauId: number; stockRecupere: number }>(`${this.baseEndpoint}/getStockRecupere`, request);
  }

  /**
   * ✅ NOUVEAU : Récupère la liste des EPP déficitaires pour un IEPP et une année scolaire
   * Un EPP est considéré comme déficitaire si pour au moins une combinaison matière/niveau :
   * effectifClasse > SUM(quantite_recue)
   */
  async getEppDeficitaires(ieppId: number, anneeScolaireId: number): Promise<ApiResponse<{
    eppId: number;
    eppCode: string;
    eppLibelle: string;
    combinaisonsDeficitaires: Array<{
      matiereId: number;
      matiereCode: string;
      matiereLibelle: string;
      niveauId: number;
      niveauCode: string;
      niveauLibelle: string;
      effectifClasse: number;
      quantiteRecueTotale: number;
      deficit: number;
    }>;
    nombreCombinaisons: number;
  }>> {
    const userId = this.getCurrentUserId();
    const token = this.getAuthToken();
    
    if (!userId || !token) {
      throw new Error('Utilisateur non connecté');
    }
    
    const request = {
      user: userId,
      token: token,
      isSimpleLoading: false,
      data: {
        ieppId,
        initieePar: ieppId,
        anneeScolaireId: anneeScolaireId,
      },
    };

    return this.post<{
      eppId: number;
      eppCode: string;
      eppLibelle: string;
      combinaisonsDeficitaires: Array<{
        matiereId: number;
        matiereCode: string;
        matiereLibelle: string;
        niveauId: number;
        niveauCode: string;
        niveauLibelle: string;
        effectifClasse: number;
        quantiteRecueTotale: number;
        deficit: number;
      }>;
      nombreCombinaisons: number;
    }>(`${this.baseEndpoint}/getEppDeficitaires`, request);
  }

  /**
   * Récupère la liste des EPP excédentaires pour un IEPP et une année scolaire.
   * Un EPP est excédentaire s'il a au moins une combinaison matière/niveau avec
   * quantiteRecueTotale > effectifClasse.
   */
  async getEppExcedentaires(ieppId: number, anneeScolaireId: number): Promise<ApiResponse<{
    eppId: number;
    eppCode: string;
    eppLibelle: string;
    combinaisonsExcedentaires: Array<{
      matiereId: number;
      matiereCode: string;
      matiereLibelle: string;
      niveauId: number;
      niveauCode: string;
      niveauLibelle: string;
      effectifClasse: number;
      quantiteRecueTotale: number;
      excedent: number;
    }>;
    nombreCombinaisons: number;
    totalExcedentaire: number;
  }>> {
    const userId = this.getCurrentUserId();
    const token = this.getAuthToken();
    if (!userId || !token) throw new Error("Utilisateur non connecté");
    const request = {
      user: userId,
      token,
      isSimpleLoading: false,
      data: { ieppId, initieePar: ieppId, anneeScolaireId },
    };
    return this.post<{
      eppId: number;
      eppCode: string;
      eppLibelle: string;
      combinaisonsExcedentaires: Array<{
        matiereId: number;
        matiereCode: string;
        matiereLibelle: string;
        niveauId: number;
        niveauCode: string;
        niveauLibelle: string;
        effectifClasse: number;
        quantiteRecueTotale: number;
        excedent: number;
      }>;
      nombreCombinaisons: number;
      totalExcedentaire: number;
    }>(`${this.baseEndpoint}/getEppExcedentaires`, request);
  }

  /**
   * Déficits de la structure connectée (EPP) : effectifClasse > quantiteRecueTotale
   */
  async getStructureDeficits(structureId: number, anneeScolaireId: number): Promise<ApiResponse<StructureDeficitItem>> {
    const userId = this.getCurrentUserId();
    const token = this.getAuthToken();
    if (!userId || !token) throw new Error("Utilisateur non connecté");
    const request = {
      user: userId,
      token,
      isSimpleLoading: false,
      data: { sourceId: structureId, anneeScolaireId },
    };
    return this.post<StructureDeficitItem>(`${this.baseEndpoint}/getStructureDeficits`, request);
  }

  /**
   * Excédents de la structure connectée (EPP) : quantiteRecueTotale > effectifClasse
   */
  async getStructureExcedents(structureId: number, anneeScolaireId: number): Promise<ApiResponse<StructureExcedentItem>> {
    const userId = this.getCurrentUserId();
    const token = this.getAuthToken();
    if (!userId || !token) throw new Error("Utilisateur non connecté");
    const request = {
      user: userId,
      token,
      isSimpleLoading: false,
      data: { sourceId: structureId, anneeScolaireId },
    };
    return this.post<StructureExcedentItem>(`${this.baseEndpoint}/getStructureExcedents`, request);
  }

  /**
   * Récupère les régulations selon des critères
   */
  async getByCriteria(filters?: Partial<RegulationDto>, page: number = 0, size: number = 10): Promise<ApiResponse<RegulationDto>> {
    const userId = this.getCurrentUserId();
    const token = this.getAuthToken();
    
    if (!userId || !token) {
      throw new Error('Utilisateur non connecté');
    }
    
    const request = {
      user: userId,
      token: token,
      isSimpleLoading: false,
      data: filters,
      index: page,
      size: size,
    };

    return this.post<RegulationDto>(`${this.baseEndpoint}/getByCriteria`, request);
  }

  /**
   * Récupère les détails d'une régulation
   */
  async getDetails(regulationId: number): Promise<ApiResponse<RegulationDto>> {
    const userId = this.getCurrentUserId();
    const token = this.getAuthToken();
    
    if (!userId || !token) {
      throw new Error('Utilisateur non connecté');
    }
    
    const request = {
      user: userId,
      token: token,
      isSimpleLoading: false,
      data: {
        id: regulationId,
      },
    };

    return this.post<RegulationDto>(`${this.baseEndpoint}/getByCriteria`, request);
  }

  /**
   * Lignes de détail (récupération par EPP / matière / niveau) pour une régulation
   */
  async getDetailRegulationLignes(regulationId: number): Promise<ApiResponse<DetailRegulationDto>> {
    const userId = this.getCurrentUserId();
    const token = this.getAuthToken();
    if (!userId || !token) {
      throw new Error("Utilisateur non connecté");
    }
    const request = {
      user: userId,
      token,
      isSimpleLoading: false,
      data: {
        regulationId,
        isdeleted: false,
      },
      index: 0,
      size: 500,
    };
    return this.post<DetailRegulationDto>(`/detailRegulation/getByCriteria`, request);
  }

  private formatDate(date: Date): string {
    const day = String(date.getDate()).padStart(2, "0");
    const month = String(date.getMonth() + 1).padStart(2, "0");
    const year = date.getFullYear();
    return `${day}/${month}/${year}`;
  }
}

export const regulationService = new RegulationService();

