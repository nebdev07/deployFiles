/**
 * Service pour la gestion des structures administratives
 * DRENA, IEPP, EPP
 */

import { BaseApiService } from './base-api.service';
import { ApiResponse } from '@/lib/types/api';
import { authService } from './auth.service';

// Interfaces pour les structures
export interface Drena {
  id: number;
  code: string;
  libelle: string;
  description?: string;
  isActive?: boolean;
}

export interface Iepp {
  id: number;
  code: string;
  libelle: string;
  drenaId: number;
  drenaCode?: string;
  description?: string;
  isActive?: boolean;
}

export interface Epp {
  id: number;
  code: string;
  libelle: string;
  drenaId: number;
  drenaCode?: string;
  ieppId: number;
  ieppCode?: string;
  description?: string;
  isActive?: boolean;
}

export interface StructureFilters {
  drenaId?: number;
  ieppId?: number;
  eppId?: number;
  isActive?: boolean;
  /** Filtre backend (LIKE « contient » si non vide). */
  code?: string;
  libelle?: string;
}

/** Filtres texte optionnels pour listes IEPP / EPP (même sémantique que {@link StructureFilters}). */
export type StructureTextFilters = Pick<StructureFilters, "code" | "libelle">;

/** Pagination alignée sur {@code RequestBase.index} / {@code RequestBase.size} (0-based). */
export type StructurePage = { index: number; size: number }

class StructuresService extends BaseApiService {
  private baseEndpoint = '/structure';

  // Fonction utilitaire pour construire les requêtes selon le format backend
  private buildRequest(data: any, page?: StructurePage) {
    const userId = this.getCurrentUserId();
    const token = this.getAuthToken();
    
    // Vérifier si l'utilisateur est connecté
    if (!userId || !token) {
      console.warn('Utilisateur non connecté - impossible de charger les structures');
      throw new Error('Utilisateur non connecté');
    }
    
    const base: Record<string, unknown> = {
      user: userId,
      token: token,
      isSimpleLoading: false,
      data,
    }
    if (page != null && typeof page.index === "number" && typeof page.size === "number") {
      base.index = page.index
      base.size = page.size
    }
    return base
  }

  /** Requête create (datas[]) pour les endpoints POST /structure/iepp/create et /structure/epp/create */
  private buildStructureDatasRequest(datas: object[]) {
    const userId = this.getCurrentUserId();
    const token = this.getAuthToken();
    if (!userId || !token) {
      throw new Error('Utilisateur non connecté');
    }
    return {
      user: userId,
      token,
      isSimpleLoading: false,
      datas,
    };
  }

  /**
   * Création d’un IEPP (rôle DRENA sur la même DRENA, ou ADMIN).
   * Après création : créer le compte directeur IEPP via /user/create (userType IEPP, ieppCode, etc.).
   */
  async createIepp(payload: {
    code?: string;
    libelle: string;
    description: string;
    drenaId: number;
  }): Promise<ApiResponse<Iepp>> {
    return this.request<Iepp>(
      'POST',
      `${this.baseEndpoint}/iepp/create`,
      this.buildStructureDatasRequest([payload])
    );
  }

  /**
   * Création d’une EPP rattachée à un IEPP (rôle IEPP sur le même IEPP, DRENA sur la même DRENA, ou ADMIN).
   * Ensuite : compte directeur via /user/create (userType EPP, eppCode, ieppCode, drenaCode…).
   */
  async createEpp(payload: {
    code?: string;
    libelle: string;
    description: string;
    ieppId: number;
  }): Promise<ApiResponse<Epp>> {
    return this.request<Epp>(
      'POST',
      `${this.baseEndpoint}/epp/create`,
      this.buildStructureDatasRequest([payload])
    );
  }

  async createDrena(payload: {
    code?: string;
    libelle: string;
    description: string;
  }): Promise<ApiResponse<Drena>> {
    return this.request<Drena>(
      'POST',
      `${this.baseEndpoint}/drena/create`,
      this.buildStructureDatasRequest([payload])
    );
  }

  async updateDrena(payload: { id: number; code: string; libelle: string; description: string }): Promise<ApiResponse<Drena>> {
    return this.request<Drena>(
      'POST',
      `${this.baseEndpoint}/drena/update`,
      this.buildStructureDatasRequest([payload])
    );
  }

  async deleteDrena(id: number): Promise<ApiResponse<Drena>> {
    return this.request<Drena>(
      'POST',
      `${this.baseEndpoint}/drena/delete`,
      this.buildStructureDatasRequest([{ id }])
    );
  }

  async updateIepp(payload: {
    id: number;
    code: string;
    libelle: string;
    description: string;
    drenaId: number;
  }): Promise<ApiResponse<Iepp>> {
    return this.request<Iepp>(
      'POST',
      `${this.baseEndpoint}/iepp/update`,
      this.buildStructureDatasRequest([payload])
    );
  }

  async deleteIepp(id: number): Promise<ApiResponse<Iepp>> {
    return this.request<Iepp>(
      'POST',
      `${this.baseEndpoint}/iepp/delete`,
      this.buildStructureDatasRequest([{ id }])
    );
  }

  async updateEpp(payload: {
    id: number;
    code: string;
    libelle: string;
    description: string;
    ieppId: number;
  }): Promise<ApiResponse<Epp>> {
    return this.request<Epp>(
      'POST',
      `${this.baseEndpoint}/epp/update`,
      this.buildStructureDatasRequest([payload])
    );
  }

  async deleteEpp(id: number): Promise<ApiResponse<Epp>> {
    return this.request<Epp>(
      'POST',
      `${this.baseEndpoint}/epp/delete`,
      this.buildStructureDatasRequest([{ id }])
    );
  }

  // Récupérer les DRENA (pagination optionnelle : index / size sur la requête racine)
  async getDrenas(filters?: StructureFilters, page?: StructurePage): Promise<ApiResponse<Drena>> {
    try {
      const data = {
        id: filters?.drenaId || "",
        code: (filters?.code ?? "").trim(),
        libelle: (filters?.libelle ?? "").trim(),
        description: "",
        isDeleted: filters?.isActive === false ? "true" : "",
        createdAt: "",
        updatedAt: "",
        createdBy: "",
        updatedBy: ""
      };
      
      return await this.request<Drena>('POST', `${this.baseEndpoint}/drena/getByCriteria`, this.buildRequest(data, page));
    } catch (error: any) {
      // Si c'est une erreur de token invalide, laisser le service de base gérer la déconnexion
      if (error.code === '900' && (error.message.includes('Token invalide') || error.message.includes('Session expirée'))) {
        throw error; // Le service de base va gérer la déconnexion
      }
      throw error;
    }
  }

  // Récupérer toutes les IEPP
  async getIepps(filters?: StructureFilters): Promise<ApiResponse<Iepp>> {
    const data = {
      id: filters?.ieppId || "",
      code: "",
      libelle: "",
      description: "",
      isDeleted: filters?.isActive === false ? "true" : "",
      createdAt: "",
      updatedAt: "",
      createdBy: "",
      updatedBy: ""
    };
    
    return this.request<Iepp>('POST', `${this.baseEndpoint}/iepp/getByCriteria`, this.buildRequest(data));
  }

  // Récupérer toutes les EPP
  async getEpps(filters?: StructureFilters): Promise<ApiResponse<Epp>> {
    const data = {
      id: filters?.eppId || "",
      code: "",
      libelle: "",
      description: "",
      isDeleted: filters?.isActive === false ? "true" : "",
      createdAt: "",
      updatedAt: "",
      createdBy: "",
      updatedBy: ""
    };
    
    return this.request<Epp>('POST', `${this.baseEndpoint}/epp/getByCriteria`, this.buildRequest(data));
  }

  // Récupérer les IEPP d'une DRENA spécifique
  async getIeppsByDrena(
    drenaId: number,
    page?: StructurePage,
    text?: StructureTextFilters,
  ): Promise<ApiResponse<Iepp>> {
    try {
      const data = {
        id: "",
        code: (text?.code ?? "").trim(),
        libelle: (text?.libelle ?? "").trim(),
        description: "",
        drenaId: drenaId.toString(), // Filtrer par DRENA
        isDeleted: "false", // Seulement les actifs
        createdAt: "",
        updatedAt: "",
        createdBy: "",
        updatedBy: ""
      };
      
      return await this.request<Iepp>('POST', `${this.baseEndpoint}/iepp/getByCriteria`, this.buildRequest(data, page));
    } catch (error: any) {
      // Si c'est une erreur de token invalide, laisser le service de base gérer la déconnexion
      if (error.code === '900' && (error.message.includes('Token invalide') || error.message.includes('Session expirée'))) {
        throw error; // Le service de base va gérer la déconnexion
      }
      throw error;
    }
  }

  // Récupérer les EPP d'une IEPP spécifique
  async getEppsByIepp(
    ieppId: number,
    page?: StructurePage,
    text?: StructureTextFilters,
  ): Promise<ApiResponse<Epp>> {
    try {
      const data = {
        id: "",
        code: (text?.code ?? "").trim(),
        libelle: (text?.libelle ?? "").trim(),
        description: "",
        ieppId: ieppId.toString(), // Filtrer par IEPP
        isDeleted: "false", // Seulement les actifs
        createdAt: "",
        updatedAt: "",
        createdBy: "",
        updatedBy: ""
      };
      
      return await this.request<Epp>('POST', `${this.baseEndpoint}/epp/getByCriteria`, this.buildRequest(data, page));
    } catch (error: any) {
      // Si c'est une erreur de token invalide, laisser le service de base gérer la déconnexion
      if (error.code === '900' && (error.message.includes('Token invalide') || error.message.includes('Session expirée'))) {
        throw error; // Le service de base va gérer la déconnexion
      }
      throw error;
    }
  }

  // Récupérer les EPP d'une DRENA spécifique
  async getEppsByDrena(drenaId: number): Promise<ApiResponse<Epp>> {
    return this.getEpps({ isActive: true });
  }

  // Récupérer une DRENA par ID
  async getDrenaById(id: number): Promise<ApiResponse<Drena>> {
    const data = {
      id: id.toString(),
      code: "",
      libelle: "",
      description: "",
      isDeleted: "",
      createdAt: "",
      updatedAt: "",
      createdBy: "",
      updatedBy: ""
    };
    return this.request<Drena>('POST', `${this.baseEndpoint}/drena/getByCriteria`, this.buildRequest(data));
  }

  // Récupérer une IEPP par ID
  async getIeppById(id: number): Promise<ApiResponse<Iepp>> {
    const data = {
      id: id.toString(),
      code: "",
      libelle: "",
      description: "",
      isDeleted: "",
      createdAt: "",
      updatedAt: "",
      createdBy: "",
      updatedBy: ""
    };
    return this.request<Iepp>('POST', `${this.baseEndpoint}/iepp/getByCriteria`, this.buildRequest(data));
  }

  // Récupérer une EPP par ID
  async getEppById(id: number): Promise<ApiResponse<Epp>> {
    const data = {
      id: id.toString(),
      code: "",
      libelle: "",
      description: "",
      isDeleted: "",
      createdAt: "",
      updatedAt: "",
      createdBy: "",
      updatedBy: ""
    };
    return this.request<Epp>('POST', `${this.baseEndpoint}/epp/getByCriteria`, this.buildRequest(data));
  }

  /**
   * Structures administratives par type (ex. DAF) — aligné backend
   * {@link ci.dtsi.dismas.business.CommandeFournisseurBusiness#firstStructureDafNationale}.
   */
  /** `items` = liste de structures ; ne pas utiliser `ApiResponse<Array<T>>` (double tableau). */
  async getAdministrativeStructuresByType(
    type: string
  ): Promise<ApiResponse<{ id: number; code?: string; libelle?: string; type?: string }>> {
    return this.request<{ id: number; code?: string; libelle?: string; type?: string }>(
      "GET",
      `/structureAdministrative/getByType?type=${encodeURIComponent(type)}`
    );
  }
}

export const structuresService = new StructuresService();