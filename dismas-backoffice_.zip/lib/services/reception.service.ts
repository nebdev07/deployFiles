/**
 * Service pour la gestion des réceptions avec intégration complète backend
 * Gère les réceptions IEPP et EPP, les fichiers, et les stocks
 */

import { BaseApiService } from './base-api.service';
import { ApiResponse } from '@/lib/types/api';
import { apiConfig } from '@/lib/config/api';

// Type personnalisé pour les réponses du service de réception
interface ReceptionServiceResponse<T> {
  success: boolean;
  data: T | null;
  message: string;
}

// Types pour les réceptions
export interface ReceptionData {
  typeReception: 'IEPP' | 'EPP';
  observation?: string;
  numeroBordereau: string;
  dateReception: string;
  idStructure: number;
  catalogues: CatalogueReceptionData[];
}

export interface CatalogueReceptionData {
  id: number;
  matieres: MatiereQuantiteData[];
}

export interface MatiereQuantiteData {
  idMatiere: number;
  quantiteRecue: number;
  quantitePrevue: number;
}

export interface ReceptionFileData {
  id?: number;
  fileName: string;
  filePath: string;
  fileType: 'BORDEREAU' | 'PHOTO' | 'DOCUMENT';
  fileSize: number;
  uploadedBy: number;
  uploadedAt: string;
}

export interface ReceptionResponse {
  id: number;
  typeReception: string;
  observation: string;
  numeroBordereau: string;
  dateReception: string;
  idStructure: number;
  statut: string;
  validatedBy?: number;
  validatedAt?: string;
  validationLevel?: string;
  createdAt: string;
  createdBy: number;
}

class ReceptionService extends BaseApiService {
  private baseEndpoint = '/mouvement'; // CORRECTION: Reception → Mouvement
  private filesEndpoint = '/mouvementFiles'; // CORRECTION: CamelCase comme backend
  private catalogueReceptionEndpoint = '/catalogueMouvement'; // CORRECTION: CamelCase comme backend
  private matiereQuantiteEndpoint = '/matiereQuantite'; // CORRECTION: camelCase (lowercase initial) comme backend

  // Fonction utilitaire pour formater les dates au format backend
  private formatDateForBackend(dateString: string): string {
    if (!dateString) return '';
    
    // Vérifier si la date est valide
    const date = new Date(dateString);
    if (isNaN(date.getTime())) {
      console.error('Date invalide:', dateString);
      return '';
    }
    
    // Convertir de "2025-09-25" vers "25/09/2025 00:00:00" (format attendu par le backend)
    const day = String(date.getDate()).padStart(2, '0');
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const year = date.getFullYear();
    
    return `${day}/${month}/${year} 00:00:00`;
  }

  // Fonction utilitaire pour construire les requêtes selon le format backend
  private buildRequest(data: any, isCreateUpdate = false) {
    const userId = this.getCurrentUserId();
    const token = this.getAuthToken();
    
    // Vérifier si l'utilisateur est connecté
    if (!userId || !token) {
      console.warn('Utilisateur non connecté - impossible de gérer les réceptions');
      throw new Error('Utilisateur non connecté');
    }
    
    // Les dates sont déjà formatées par le composant, pas besoin de les reformater
    
    const baseRequest = {
      user: userId,
      token: token,
      isSimpleLoading: false
    };
    
    if (isCreateUpdate) {
      // Pour CREATE/UPDATE/DELETE, utiliser "datas" avec un tableau
      return {
        ...baseRequest,
        datas: [data]
      };
    } else {
      // Pour GET/SEARCH, utiliser "data" avec un objet
      return {
        ...baseRequest,
        data
      };
    }
  }

  /**
   * Crée une réception complète avec gestion des stocks
   */
  async createReceptionWithStock(receptionData: ReceptionData): Promise<ReceptionServiceResponse<ReceptionResponse>> {
    try {
      const request = this.buildRequest(receptionData, true);
      
      const response = await this.post(`${this.baseEndpoint}/createWithStock`, request);
      
      if (!response.hasError && response.items && response.items.length > 0) {
        return {
          success: true,
          data: response.items[0] as ReceptionResponse,
          message: response.status?.message || 'Réception créée avec succès'
        };
      } else {
        return {
          success: false,
          data: null as any,
          message: response.status?.message || 'Erreur lors de la création de la réception'
        };
      }
    } catch (error) {
      console.error('Erreur lors de la création de la réception:', error);
      return {
        success: false,
        data: null as any,
        message: error instanceof Error ? error.message : 'Erreur lors de la création de la réception'
      };
    }
  }

  /**
   * Crée une réception standard (sans gestion des stocks)
   */
  async createReception(receptionData: ReceptionData): Promise<ReceptionServiceResponse<ReceptionResponse>> {
    try {
      const request = this.buildRequest(receptionData, true);
      
      const response = await this.post(`${this.baseEndpoint}/create`, request);
      
      if (!response.hasError && response.items && response.items.length > 0) {
        return {
          success: true,
          data: response.items[0] as ReceptionResponse,
          message: response.status?.message || 'Réception créée avec succès'
        };
      } else {
        return {
          success: false,
          data: null as any,
          message: response.status?.message || 'Erreur lors de la création de la réception'
        };
      }
    } catch (error) {
      console.error('Erreur lors de la création de la réception:', error);
      return {
        success: false,
        data: null as any,
        message: error instanceof Error ? error.message : 'Erreur lors de la création de la réception'
      };
    }
  }

  /**
   * Valide une réception
   */
  async validateReception(receptionId: number, validationLevel: 'IEPP' | 'EPP'): Promise<ReceptionServiceResponse<ReceptionResponse>> {
    try {
      const request = this.buildRequest({
        id: receptionId,
        validationLevel: validationLevel
      }, false);
      
      const response = await this.post(`${this.baseEndpoint}/validate`, request);
      
      if (!response.hasError && response.items && response.items.length > 0) {
        return {
          success: true,
          data: response.items[0] as ReceptionResponse,
          message: response.status?.message || 'Réception validée avec succès'
        };
      } else {
        return {
          success: false,
          data: null as any,
          message: response.status?.message || 'Erreur lors de la validation de la réception'
        };
      }
    } catch (error) {
      console.error('Erreur lors de la validation de la réception:', error);
      return {
        success: false,
        data: null as any,
        message: error instanceof Error ? error.message : 'Erreur lors de la validation de la réception'
      };
    }
  }

  /**
   * Rejette une réception EPP (IEPP) et la renvoie en brouillon
   */
  async rejectReception(receptionId: number, raison: string): Promise<ReceptionServiceResponse<ReceptionResponse>> {
    try {
      const request = this.buildRequest({
        id: receptionId,
        raisonAnnulation: raison
      }, false);

      const response = await this.post(`${this.baseEndpoint}/reject`, request);

      if (!response.hasError && response.items && response.items.length > 0) {
        return {
          success: true,
          data: response.items[0] as ReceptionResponse,
          message: response.status?.message || 'Réception rejetée avec succès'
        };
      } else {
        return {
          success: false,
          data: null as any,
          message: response.status?.message || 'Erreur lors du rejet de la réception'
        };
      }
    } catch (error) {
      console.error('Erreur lors du rejet de la réception:', error);
      return {
        success: false,
        data: null as any,
        message: error instanceof Error ? error.message : 'Erreur lors du rejet de la réception'
      };
    }
  }

  /**
   * Valide le stock avant une réception EPP
   */
  async validateStockBeforeEPP(receptionData: any): Promise<ReceptionServiceResponse<any>> {
    try {
      const request = this.buildRequest(receptionData, false);
      const response = await this.post(`${this.baseEndpoint}/validateStockBeforeEPP`, request);
      
      if (!response.hasError) {
        return {
          success: true,
          data: response.items?.[0] as any || null,
          message: response.status?.message || 'Stock validé avec succès'
        };
      } else {
        return {
          success: false,
          data: null as any,
          message: response.status?.message || 'Stock insuffisant'
        };
      }
    } catch (error) {
      console.error('Erreur lors de la validation du stock:', error);
      return {
        success: false,
        data: null as any,
        message: error instanceof Error ? error.message : 'Erreur lors de la validation du stock'
      };
    }
  }

  /**
   * Corrige les stocks en créant les MouvementStock manquants
   * Appelle l'endpoint backend qui parcourt tous les mouvements
   */
  async correctStockData(): Promise<ReceptionServiceResponse<any>> {
    try {
      console.log('🔄 Appel correctStockData pour créer les MouvementStock...');
      const request = this.buildRequest({}, false);
      const response = await this.post(`${this.baseEndpoint}/correctStockData`, request);
      
      if (!response.hasError) {
        console.log('✅ Stocks corrigés avec succès');
        return {
          success: true,
          data: response.items || [],
          message: 'Stocks corrigés avec succès'
        };
      } else {
        console.error('❌ Erreur correction stocks:', response.status);
        return {
          success: false,
          data: null,
          message: response.status?.message || 'Erreur lors de la correction des stocks'
        };
      }
    } catch (error: any) {
      console.error('❌ Erreur appel correctStockData:', error);
      return {
        success: false,
        data: null,
        message: error.response?.data?.status?.message || 'Erreur lors de la correction des stocks'
      };
    }
  }

  /**
   * Récupère les réceptions selon des critères
   */
  async getReceptions(filters: any = {}): Promise<ReceptionServiceResponse<ReceptionResponse[]>> {
    try {
      // Utiliser les filtres fournis ou des filtres par défaut
      const requestFilters = filters.idStructure ? filters : {
        idStructure: filters.idStructure || null,
        ...filters
      };
      const request = this.buildRequest(requestFilters, false);
      
      const response = await this.post(`${this.baseEndpoint}/getByCriteria`, request);
      
      if (!response.hasError) {
        return {
          success: true,
          data: (response.items || []) as ReceptionResponse[],
          message: response.status?.message || 'Réceptions récupérées avec succès'
        };
      } else {
        return {
          success: false,
          data: [],
          message: response.status?.message || 'Erreur lors de la récupération des réceptions'
        };
      }
    } catch (error) {
      console.error('Erreur lors de la récupération des réceptions:', error);
      
      // Gérer les erreurs backend spécifiques
      if (error && typeof error === 'object' && 'code' in error) {
        return {
          success: false,
          data: [],
          message: (error as { message?: string }).message || 'Erreur lors de la récupération des réceptions'
        };
      }
      
      return {
        success: false,
        data: [],
        message: error instanceof Error ? error.message : 'Erreur lors de la récupération des réceptions'
      };
    }
  }

  /**
   * Interroge getByCriteria pour les deux libellés de type possibles en base :
   * - `RECEPTION_EPP` : valeur canonique après normalisation (MouvementBusiness)
   * - `EPP` : anciennes lignes ou création sans normalisation
   * L'API fait une égalité stricte sur type_mouvement → sans fusion, une seule variante exclut l'autre.
   */
  private async queryReceptionEppByIeppMerged(
    filters: Record<string, unknown>
  ): Promise<{ items: ReceptionResponse[]; allQueriesFailed: boolean; errorMessage?: string }> {
    const types = ['RECEPTION_EPP', 'EPP'] as const;
    const byId = new Map<number, ReceptionResponse>();
    let failCount = 0;
    let errorMessage: string | undefined;

    for (const typeMouvement of types) {
      const request = this.buildRequest({ ...filters, typeMouvement } as Record<string, unknown>, false);
      const response = await this.post<ReceptionResponse>(
        `${this.baseEndpoint}/getByCriteria`,
        request
      );
      if (response.hasError) {
        failCount++;
        if (!errorMessage && response.status?.message) {
          errorMessage = response.status.message;
        }
      }
      if (!response.hasError && response.items) {
        for (const it of response.items) {
          if (it?.id != null) {
            byId.set(Number(it.id), it);
          }
        }
      }
    }

    const items = Array.from(byId.values()).sort((a, b) => Number(b.id) - Number(a.id));
    return {
      items,
      allQueriesFailed: failCount >= types.length && items.length === 0,
      errorMessage,
    };
  }

  /**
   * ✅ Récupère les réceptions EPP en attente de validation IEPP
   * Utilisé par l'IEPP dans le menu Distribution pour valider les réceptions EPP
   */
  async getReceptionsEPPEnAttenteIEPP(ieppStructureId?: number): Promise<ReceptionServiceResponse<ReceptionResponse[]>> {
    try {
      console.log('📋 Récupération des réceptions EPP en attente de validation IEPP...');

      const filters: Record<string, unknown> = {
        statut: 'EN_ATTENTE',
      };
      if (ieppStructureId) {
        filters.idIEPPParent = ieppStructureId;
      }

      const { items, allQueriesFailed, errorMessage } = await this.queryReceptionEppByIeppMerged(filters);

      if (allQueriesFailed) {
        return {
          success: false,
          data: [],
          message: errorMessage || 'Erreur lors de la récupération des réceptions en attente',
        };
      }

      console.log(`✅ ${items.length} réceptions EPP en attente trouvées (RECEPTION_EPP + EPP fusionnés)`);
      return {
        success: true,
        data: items,
        message: 'Réceptions en attente récupérées avec succès',
      };
    } catch (error) {
      console.error('❌ Erreur lors de la récupération des réceptions en attente:', error);
      return {
        success: false,
        data: [],
        message: error instanceof Error ? error.message : 'Erreur lors de la récupération des réceptions en attente',
      };
    }
  }

  /**
   * Réceptions EPP déjà traitées par l'IEPP : validées (CONFIRMEE_IEPP) ou rejetées (BROUILLON + IEPP_REJET).
   * Utilisé sous Distribution → onglet Historique.
   */
  async getReceptionsEPPHistoriqueIEPP(ieppStructureId?: number): Promise<ReceptionServiceResponse<ReceptionResponse[]>> {
    try {
      const common: Record<string, unknown> = {};
      if (ieppStructureId) {
        common.idIEPPParent = ieppStructureId;
      }

      const [validees, rejetees] = await Promise.all([
        this.queryReceptionEppByIeppMerged({ ...common, statut: 'CONFIRMEE_IEPP' }),
        this.queryReceptionEppByIeppMerged({
          ...common,
          statut: 'BROUILLON',
          validationLevel: 'IEPP_REJET',
        }),
      ]);

      const byId = new Map<number, ReceptionResponse>();
      for (const it of validees.items) {
        if (it?.id != null) byId.set(Number(it.id), it);
      }
      for (const it of rejetees.items) {
        if (it?.id != null) byId.set(Number(it.id), it);
      }

      const merged = Array.from(byId.values()).sort((a, b) => Number(b.id) - Number(a.id));

      const totalFail =
        validees.allQueriesFailed &&
        rejetees.allQueriesFailed &&
        merged.length === 0;
      if (totalFail) {
        return {
          success: false,
          data: [],
          message:
            validees.errorMessage ||
            rejetees.errorMessage ||
            'Erreur lors de la récupération de l’historique',
        };
      }

      return {
        success: true,
        data: merged,
        message: 'Historique récupéré',
      };
    } catch (error) {
      console.error('Erreur historique réceptions EPP IEPP:', error);
      return {
        success: false,
        data: [],
        message: error instanceof Error ? error.message : 'Erreur lors de la récupération de l’historique',
      };
    }
  }


  /**
   * Récupère une réception avec tous ses détails (catalogues, matières, quantités)
   */
  async getReceptionWithDetails(receptionId: number): Promise<ReceptionServiceResponse<any>> {
    try {
      console.log('🔍 Récupération des détails pour la réception ID:', receptionId);
      
      const response = await this.get(`${this.baseEndpoint}/getWithDetails/${receptionId}`);
      console.log('📥 Réponse détails réception:', response);
      
      if (!response.hasError && response.items && response.items.length > 0) {
        return {
          success: true,
          data: response.items[0] as ReceptionResponse,
          message: response.status?.message || 'Détails de réception récupérés avec succès'
        };
      } else {
        return {
          success: false,
          data: null,
          message: response.status?.message || 'Erreur lors de la récupération des détails de réception'
        };
      }
    } catch (error) {
      console.error('Erreur lors de la récupération des détails de réception:', error);
      return {
        success: false,
        data: null,
        message: error instanceof Error ? error.message : 'Erreur lors de la récupération des détails de réception'
      };
    }
  }

  /**
   * Upload un fichier pour une réception
   */
  async uploadReceptionFile(
    receptionId: number, 
    file: File, 
    fileType: 'BORDEREAU' | 'PHOTO' | 'DOCUMENT'
  ): Promise<ReceptionServiceResponse<ReceptionFileData>> {
    try {
      // Lire le contenu du fichier
      const fileContent = await this.readFileAsBytes(file);
      
      // Construire la requête pour l'API avec le contenu du fichier
      const request = this.buildRequest({
        idMouvement: receptionId, // CORRECTION: Backend attend idMouvement
        fileName: file.name,
        fileType: fileType,
        fileSize: file.size,
        fileContent: fileContent, // Ajouter le contenu du fichier
        uploadedBy: this.getCurrentUserId(),
        uploadedAt: this.formatDateForBackend(new Date().toISOString().split('T')[0])
      }, true);

      const response = await this.post(`${this.filesEndpoint}/create`, request);
      
      if (!response.hasError && response.items && response.items.length > 0) {
        return {
          success: true,
          data: response.items[0] as unknown as ReceptionFileData,
          message: response.status?.message || 'Fichier uploadé avec succès'
        };
      } else {
        return {
          success: false,
          data: null as any,
          message: response.status?.message || 'Erreur lors de l\'upload du fichier'
        };
      }
    } catch (error) {
      console.error('Erreur lors de l\'upload du fichier:', error);
      return {
        success: false,
        data: null as any,
        message: error instanceof Error ? error.message : 'Erreur lors de l\'upload du fichier'
      };
    }
  }

  /**
   * Récupère les fichiers d'une réception
   */
  async getReceptionFiles(receptionId: number): Promise<ReceptionServiceResponse<ReceptionFileData[]>> {
    try {
      const request = this.buildRequest({
        idReception: receptionId
      }, false);
      
      const response = await this.post(`${this.filesEndpoint}/getByCriteria`, request);
      
      if (!response.hasError) {
        return {
          success: true,
          data: (response.items || []) as unknown as ReceptionFileData[],
          message: response.status?.message || 'Fichiers récupérés avec succès'
        };
      } else {
        return {
          success: false,
          data: [],
          message: response.status?.message || 'Erreur lors de la récupération des fichiers'
        };
      }
    } catch (error) {
      console.error('Erreur lors de la récupération des fichiers:', error);
      return {
        success: false,
        data: [],
        message: error instanceof Error ? error.message : 'Erreur lors de la récupération des fichiers'
      };
    }
  }

  /**
   * Crée une association catalogue-mouvement (catalogue-réception)
   */
  async createCatalogueReception(receptionId: number, catalogueId: number): Promise<ReceptionServiceResponse<any>> {
    try {
      const requestData = {
        idMouvement: receptionId, // CORRECTION: Backend attend idMouvement (pas idReception)
        idCatalogue: catalogueId,
        statut: 'ACTIF'
      };
      
      console.log('🔍 Données envoyées pour catalogue-mouvement:', requestData);
      
      const request = this.buildRequest(requestData, true);
      console.log('📤 Requête complète catalogue-mouvement:', request);
      
      const response = await this.post(`${this.catalogueReceptionEndpoint}/create`, request);
      console.log('📥 Réponse brute catalogue-mouvement:', response);
      
      if (!response.hasError && response.items && response.items.length > 0) {
        return {
          success: true,
          data: response.items[0] as ReceptionResponse,
          message: response.status?.message || 'Association catalogue-réception créée avec succès'
        };
      } else {
        return {
          success: false,
          data: null,
          message: response.status?.message || 'Erreur lors de la création de l\'association'
        };
      }
    } catch (error) {
      console.error('Erreur lors de la création de l\'association catalogue-réception:', error);
      return {
        success: false,
        data: null,
        message: error instanceof Error ? error.message : 'Erreur lors de la création de l\'association'
      };
    }
  }

  /**
   * Crée une entrée de quantité de matière
   * ✅ idNiveauScolaire supprimé - récupération automatique par le backend
   */
  async createMatiereQuantite(
    catalogueReceptionId: number,
    matiereId: number,
    quantiteRecue: number,
    quantitePrevue: number,
    idStructure: number,
    typeOperation: string,
    matiereCode?: string
  ): Promise<ReceptionServiceResponse<any>> {
    try {
      const ecart = quantiteRecue - quantitePrevue;
      
      const requestData = {
        idCatalogueMouvement: catalogueReceptionId, // CORRECTION: Backend attend idCatalogueMouvement
        idMatiere: matiereId,
        quantiteRecue: quantiteRecue,
        quantitePrevue: quantitePrevue,
        ecart: ecart,
        idStructure: idStructure,
        typeOperation: typeOperation,
        dateOperation: this.formatDateForBackend(new Date().toISOString().split('T')[0]),
        statutStock: 'DISPONIBLE',
        matiereCode: matiereCode // Ajout du code de la matière
        // ✅ idNiveauScolaire supprimé - Le backend le récupère automatiquement depuis CatalogueMatiere
      };
      
      console.log('🔍 Données envoyées pour quantité matière:', requestData);
      
      const request = this.buildRequest(requestData, true);
      console.log('📤 Requête complète quantité matière:', request);
      
      const response = await this.post(`${this.matiereQuantiteEndpoint}/create`, request);
      console.log('📥 Réponse brute quantité matière:', response);
      
      if (!response.hasError && response.items && response.items.length > 0) {
        return {
          success: true,
          data: response.items[0] as ReceptionResponse,
          message: response.status?.message || 'Quantité de matière créée avec succès'
        };
      } else {
        return {
          success: false,
          data: null,
          message: response.status?.message || 'Erreur lors de la création de la quantité de matière'
        };
      }
    } catch (error) {
      console.error('Erreur lors de la création de la quantité de matière:', error);
      return {
        success: false,
        data: null,
        message: error instanceof Error ? error.message : 'Erreur lors de la création de la quantité de matière'
      };
    }
  }

  /**
   * Récupère le stock disponible pour une structure et une matière
   */
  async getStock(idStructure: number, idMatiere: number): Promise<ReceptionServiceResponse<{ stockDisponible: number }>> {
    try {
      const request = this.buildRequest({
        idStructure: idStructure,
        idMatiere: idMatiere
      }, false);
      
      const response = await this.post(`${this.baseEndpoint}/getStock`, request);
      
      if (!response.hasError && response.items && response.items.length > 0) {
        return {
          success: true,
          data: response.items[0] as unknown as { stockDisponible: number },
          message: response.status?.message || 'Stock récupéré avec succès'
        };
      } else {
        return {
          success: false,
          data: { stockDisponible: 0 },
          message: response.status?.message || 'Erreur lors de la récupération du stock'
        };
      }
    } catch (error) {
      console.error('Erreur lors de la récupération du stock:', error);
      return {
        success: false,
        data: { stockDisponible: 0 },
        message: error instanceof Error ? error.message : 'Erreur lors de la récupération du stock'
      };
    }
  }

  /**
   * Envoyer une notification email
   */
  async sendNotificationEmail(
    type: 'RECEPTION_CREEE' | 'RECEPTION_ANNULEE' | 'STOCK_INSUFFISANT' | 'RECEPTION_CONFIRMEE',
    receptionId: number,
    destinataireEmail: string,
    details?: any
  ): Promise<ReceptionServiceResponse<any>> {
    try {
      console.log('📧 Envoi notification email:', { type, receptionId, destinataireEmail });
      
      // ⚠️ IMPORTANT :
      // Le backend /mouvement/sendNotification attend un MouvementDto avec :
      // - id                -> ID du Mouvement (réception)
      // - typeNotification  -> type de notification (RECEPTION_CREEE, ...)
      // - destinataireEmail -> email cible
      // - detailsNotification -> payload supplémentaire
      //
      // Les anciens champs (receptionId, type, details, envoyePar, dateEnvoi) ne sont pas utilisés côté backend.

      // Backend attend detailsNotification en String (pas un objet)
      const detailsNotificationStr =
        details != null && typeof details === 'object'
          ? JSON.stringify(details)
          : typeof details === 'string'
            ? details
            : undefined;

      const request = this.buildRequest({
        id: receptionId,                       // ✅ MouvementDto.id
        typeNotification: type,               // ✅ MouvementDto.typeNotification
        destinataireEmail: destinataireEmail, // ✅ MouvementDto.destinataireEmail
        detailsNotification: detailsNotificationStr
        // envoyePar / dateEnvoi non nécessaires côté backend actuel
      });
      
      const response = await this.post(`${this.baseEndpoint}/sendNotification`, request);
      
      if (!response.hasError && response.items && response.items.length > 0) {
        return {
          success: true,
          data: response.items[0] as ReceptionResponse,
          message: response.status?.message || 'Notification envoyée avec succès'
        };
      } else {
        return {
          success: false,
          data: null,
          message: response.status?.message || 'Erreur lors de l\'envoi de la notification'
        };
      }
    } catch (error) {
      console.error('Erreur lors de l\'envoi de la notification:', error);
      return {
        success: false,
        data: null,
        message: error instanceof Error ? error.message : 'Erreur lors de l\'envoi de la notification'
      };
    }
  }

  /**
   * Annuler une réception
   */
  async annulerReception(receptionId: number, raison: string): Promise<ReceptionServiceResponse<any>> {
    try {
      console.log('🔄 Annulation de la réception ID:', receptionId, 'Raison:', raison);
      
      const request = this.buildRequest({
        id: receptionId,
        raisonAnnulation: raison,
        annulePar: this.getCurrentUserId(),
        dateAnnulation: this.formatDateForBackend(new Date().toISOString().split('T')[0]),
        impactStock: true
      });
      
      const response = await this.post(`${this.baseEndpoint}/annuler`, request);
      
      if (!response.hasError && response.items && response.items.length > 0) {
        return {
          success: true,
          data: response.items[0] as ReceptionResponse,
          message: response.status?.message || 'Réception annulée avec succès'
        };
      } else {
        return {
          success: false,
          data: null,
          message: response.status?.message || 'Erreur lors de l\'annulation de la réception'
        };
      }
    } catch (error) {
      console.error('Erreur lors de l\'annulation de la réception:', error);
      return {
        success: false,
        data: null,
        message: error instanceof Error ? error.message : 'Erreur lors de l\'annulation de la réception'
      };
    }
  }

  /**
   * Corriger les données de stock existantes
   */
  /**
   * ✅ NOUVEAU : Créer les MouvementStock et mettre à jour StockDisponible pour un mouvement
   * Appelé après la création de tous les MatiereQuantite
   */
  async createStockMovements(mouvementId: number): Promise<ReceptionServiceResponse<any>> {
    try {
      console.log(`🔄 Création des MouvementStock pour mouvement ID: ${mouvementId}`);
      
      const response = await this.post(`${this.baseEndpoint}/createStockMovements/${mouvementId}`, {});
      
      if (!response.hasError) {
        console.log('✅ MouvementStock créés avec succès');
        return {
          success: true,
          data: response.items?.[0] as any || null,
          message: response.status?.message || 'MouvementStock créés avec succès'
        };
      } else {
        console.error('❌ Erreur création MouvementStock:', response.status);
        return {
          success: false,
          data: null as any,
          message: response.status?.message || 'Erreur lors de la création des MouvementStock'
        };
      }
    } catch (error: any) {
      console.error('❌ Erreur appel createStockMovements:', error);
      return {
        success: false,
        data: null as any,
        message: error.response?.data?.status?.message || 'Erreur lors de la création des MouvementStock'
      };
    }
  }

  /**
   * Lit un fichier et retourne son contenu en bytes
   */
  private async readFileAsBytes(file: File): Promise<number[]> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target?.result instanceof ArrayBuffer) {
          const bytes = Array.from(new Uint8Array(event.target.result));
          resolve(bytes);
        } else {
          reject(new Error('Impossible de lire le fichier'));
        }
      };
      reader.onerror = () => reject(new Error('Erreur lors de la lecture du fichier'));
      reader.readAsArrayBuffer(file);
    });
  }

  /**
   * Télécharge un fichier de réception
   */
  async downloadReceptionFile(fileId: number): Promise<ReceptionServiceResponse<Blob>> {
    try {
      console.log('📥 Téléchargement du fichier ID:', fileId);
      
      // Utiliser fetch directement pour les téléchargements de fichiers
      const response = await fetch(`${apiConfig.baseUrl}${this.filesEndpoint}/download/${fileId}`, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${this.getAuthToken()}`,
          'Content-Type': 'application/json'
        }
      });
      
      if (response.ok) {
        const blob = await response.blob();
        return {
          success: true,
          data: blob,
          message: 'Fichier téléchargé avec succès'
        };
      } else {
        return {
          success: false,
          data: null as any,
          message: `Erreur HTTP: ${response.status} ${response.statusText}`
        };
      }
    } catch (error) {
      console.error('Erreur lors du téléchargement du fichier:', error);
      return {
        success: false,
        data: null as any,
        message: error instanceof Error ? error.message : 'Erreur lors du téléchargement du fichier'
      };
    }
  }

  /**
   * ✅ MODIFIÉ : Récupère les détails complets d'une réception pour le modal
   * 
   * Cette méthode utilise l'endpoint existant mouvement/getWithDetails qui charge
   * toutes les relations (Mouvement, Structure, CatalogueMouvement) en une seule requête.
   * 
   * @param mouvementId ID du mouvement (réception)
   * @returns Promise avec les détails complets de la réception
   */
  async getReceptionDetails(mouvementId: number): Promise<ReceptionServiceResponse<any>> {
    try {
      console.log('🔍 Récupération détails complets réception ID:', mouvementId);

      const response = await this.get(`/mouvement/getWithDetails/${mouvementId}`);

      if (!response.hasError && response.items && response.items.length > 0) {
        console.log('✅ Détails réception récupérés:', response.items[0]);
        return {
          success: true,
          data: response.items[0], // Prendre le premier élément (Mouvement avec relations)
          message: 'Détails récupérés avec succès'
        };
      } else {
        console.warn('⚠️ Aucun détail trouvé pour cette réception');
        return {
          success: false,
          data: null,
          message: response.status?.message || 'Aucun détail trouvé pour cette réception'
        };
      }
    } catch (error) {
      console.error('❌ Erreur lors de la récupération des détails réception:', error);
      return {
        success: false,
        data: null,
        message: error instanceof Error ? error.message : 'Erreur lors de la récupération des détails'
      };
    }
  }

  /**
   * ✅ SÉCURITÉ CRITIQUE : Vérifie si l'EPP a une réception validée par IEPP
   * 
   * Cette méthode est appelée AVANT d'autoriser la distribution aux élèves.
   * Elle garantit que l'EPP ne peut distribuer que si l'IEPP a validé la réception.
   * 
   * @param structureId ID de la structure EPP
   * @param anneeScolaireId ID de l'année scolaire (optionnel)
   * @returns Promise avec le statut de la réception (ou null si aucune réception validée)
   */
  async verifierReceptionValideeIEPP(
    structureId: number,
    anneeScolaireId?: number
  ): Promise<ReceptionServiceResponse<{ hasReceptionValidee: boolean; statut?: string }>> {
    try {
      console.log('🔒 Vérification réception EPP validée IEPP pour structure', structureId);

      // Récupérer toutes les réceptions EPP de cette structure
      const filters: any = {
        typeMouvement: 'EPP',
        idStructure: structureId
      };

      if (anneeScolaireId) {
        filters.idAnneeScolaire = anneeScolaireId;
      }

      const request = this.buildRequest(filters, false);
      const response = await this.post(`${this.baseEndpoint}/getByCriteria`, request);

      if (!response.hasError && response.items && response.items.length > 0) {
        // Chercher une réception validée IEPP
        const receptionValidee = response.items.find((reception: any) => 
          reception.statut === 'CONFIRMEE_IEPP' || reception.statut === 'VALIDEE'
        );

        if (receptionValidee) {
          const reception = receptionValidee as { statut?: string };
          console.log('✅ Réception EPP validée IEPP trouvée:', receptionValidee);
          return {
            success: true,
            data: {
              hasReceptionValidee: true,
              statut: reception.statut
            },
            message: 'Réception EPP validée par IEPP'
          };
        } else {
          console.warn('⚠️ Aucune réception EPP validée IEPP');
          return {
            success: false,
            data: {
              hasReceptionValidee: false
            },
            message: 'Aucune réception EPP validée par IEPP. Contactez votre IEPP.'
          };
        }
      } else {
        console.warn('⚠️ Aucune réception EPP trouvée pour cette structure');
        return {
          success: false,
          data: {
            hasReceptionValidee: false
          },
          message: 'Aucune réception EPP trouvée. Veuillez d\'abord enregistrer une réception.'
        };
      }
    } catch (error) {
      console.error('❌ Erreur lors de la vérification réception validée IEPP:', error);
      return {
        success: false,
        data: {
          hasReceptionValidee: false
        },
        message: error instanceof Error ? error.message : 'Erreur lors de la vérification'
      };
    }
  }
}

// Export de l'instance singleton
export const receptionService = new ReceptionService();
export default receptionService;
