/**
 * Service pour la gestion des distributions avec validation de stock
 * Gère les distributions EPP vers classes avec validation automatique des stocks
 */

import { BaseApiService } from './base-api.service';
import { ApiResponse } from '@/lib/types/api';
import { apiConfig } from '@/lib/config/api';

// Type personnalisé pour les réponses du service de distribution
interface DistributionServiceResponse<T> {
  success: boolean;
  data: T | null;
  message: string;
  pagination?: { currentPage: number; pageSize: number; totalCount: number; totalPages: number };
}

// Interface pour les réponses du backend Spring Boot
interface BackendResponse<T> {
  item?: T;
  items?: T[];
  hasError: boolean;
  message?: string;
  status?: {
    code: string;
    message: string;
  };
  actionEffectue?: string;
  count?: number;
  sessionUser?: string;
}

// Types pour les distributions
export interface DistributionData {
  eppId: number;
  userId: number;
  distributionData: DistributionEleveData;
  matiereQuantites: MatiereQuantiteDistributionData[];
  commentaire?: string;
  fichiers?: File[]; // ✅ NOUVEAU : Fichiers à uploader après création
}

export interface DistributionEleveData {
  structureId: number; // ← Ajouté : ID de la structure (EPP)
  anneeScolaireId: number;
  niveauId: number; // ← Corrigé : backend attend niveauId, pas niveauScolaireId
  classe: string;
  dateDistribution: string; // ← Ajouté : date de distribution (format ISO)
  effectifGarcons: number;
  effectifFilles: number;
  /** Lot complémentaire (2e vague) — saisir l'effectif des élèves concernés par ce lot uniquement */
  complementaire?: boolean;
  distribuePar: number; // ← Corrigé : backend attend Integer, pas String
  commentaire: string; // ← Ajouté : commentaire obligatoire
  statut?: string; // Transition de workflow (ex: EN_ATTENTE_VALIDATION_EPP -> DISTRIBUE)
}

export interface MatiereQuantiteDistributionData {
  matiereId: number;
  matiereCode: string;
  quantite: number;
  niveauId?: number; // requis pour getStockDisponible(eppId, matiereId, niveauId)
}

export interface DistributionUpdateMatiereData {
  idMatiere: number;
  matiereCode?: string;
  quantiteRecue: number;
  quantitePrevue?: number;
}

export interface DistributionUpdateData extends Partial<DistributionEleveData> {
  isdeleted?: boolean;
  matiereQuantites?: DistributionUpdateMatiereData[];
}

export interface DistributionResponse {
  id: number;
  structureId: number;
  niveauId: number;
  classe: string;
  anneeScolaireId: number;
  dateDistribution: string;
  distribuePar: number;
  effectifGarcons: number;
  effectifFilles: number;
  commentaire?: string;
  statut: string;
  createdAt: string;
  createdBy: number;
}

export interface StockResponse {
  stock: number;
  hasError: boolean;
  message: string;
}

export class DistributionService extends BaseApiService {
  private serviceBaseUrl = `/distributionEleve`;
  private filesEndpoint = `/mouvementFiles`; // ✅ NOUVEAU : Endpoint pour les fichiers

  /**
   * Fonction utilitaire pour formater les dates au format backend
   */
  private formatDateForBackend(dateString: string): string {
    if (!dateString) return '';
    
    const date = new Date(dateString);
    if (isNaN(date.getTime())) {
      console.error('Date invalide:', dateString);
      return '';
    }
    
    const day = String(date.getDate()).padStart(2, '0');
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const year = date.getFullYear();
    
    return `${day}/${month}/${year} 00:00:00`;
  }

  /**
   * Lit un fichier et retourne son contenu en bytes
   */
  private async readFileAsBytes(file: File): Promise<number[]> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target?.result instanceof ArrayBuffer) {
          const bytes = Array.from(new Uint8Array(event.target.result));
          resolve(bytes);
        } else {
          reject(new Error('Erreur lors de la lecture du fichier'));
        }
      };
      reader.onerror = () => reject(new Error('Erreur lors de la lecture du fichier'));
      reader.readAsArrayBuffer(file);
    });
  }

  /**
   * Construit la requête selon le pattern du backend (identique à reception.service.ts)
   */
  private buildRequest(data: any, isCreateUpdate: boolean = true): any {
    const userId = 1; // TODO: Récupérer l'ID de l'utilisateur connecté
    const token = 'dummy-token'; // TODO: Récupérer le token d'authentification
    
    const baseRequest = {
      user: userId,
      token: token,
      isSimpleLoading: false
    };
    
    if (isCreateUpdate) {
      // Pour CREATE/UPDATE/DELETE, utiliser "datas" avec un tableau
      return {
        ...baseRequest,
        datas: [data]
      };
    } else {
      // Pour GET/SEARCH, utiliser "data" avec un objet
      return {
        ...baseRequest,
        data
      };
    }
  }

  /**
   * Crée une distribution avec validation de stock
   */
  async createDistributionWithStockValidation(
    distributionData: DistributionData
  ): Promise<DistributionServiceResponse<DistributionResponse>> {
    try {
      console.log('🚀 Création distribution avec validation de stock:', distributionData);
      const sessionUserId = this.getCurrentUserId();
      const sessionToken = this.getAuthToken();

      if (!sessionUserId || !sessionToken) {
        return {
          success: false,
          data: null,
          message: 'Utilisateur non connecté'
        };
      }

      // Mapper DistributionData vers DistributionRequest (format backend)
      const requestData = {
        eppId: distributionData.eppId,
        userId: sessionUserId,
        user: sessionUserId,
        token: sessionToken,
        distributionData: {
          ...distributionData.distributionData,
          complementaire: distributionData.distributionData.complementaire === true,
        },
        matiereQuantites: distributionData.matiereQuantites.map(mq => ({
          idMatiere: mq.matiereId,
          matiereCode: mq.matiereCode,
          quantiteRecue: mq.quantite
        })),
        commentaire: distributionData.commentaire
      };

      console.log('📤 Données envoyées au backend:', requestData);

      // Envoyer directement DistributionRequest (pas de buildRequest)
      const response = await this.post<BackendResponse<any>>(
        `${this.serviceBaseUrl}/createWithStockValidation`,
        requestData
      );

      // Debug: voir la réponse complète
      console.log('🔍 Réponse complète du backend:', JSON.stringify(response, null, 2));
      console.log('🔍 Structure de la réponse:', {
        hasError: (response as any).hasError,
        message: (response as any).message,
        status: (response as any).status,
        item: (response as any).item,
        items: (response as any).items,
        actionEffectue: (response as any).actionEffectue
      });

      // Le backend retourne Response<DistributionEleveDto> avec items (pas item)
      if (!(response as any).hasError && (response as any).items && (response as any).items.length > 0) {
        console.log('✅ Distribution créée avec succès:', (response as any).items[0]);
        return {
          success: true,
          data: (response as any).items[0] as any, // TODO: mapper correctement vers DistributionResponse
          message: 'Distribution créée avec succès'
        };
      } else {
        // Essayer différentes sources pour le message d'erreur
        // Priorité: status.message (pour les erreurs de validation de stock) > message > actionEffectue
        const errorMessage = (response as any).status?.message || (response as any).message || (response as any).actionEffectue || 'Erreur inconnue';
        console.error('❌ Erreur lors de la création de la distribution:', errorMessage);
        console.error('❌ Détails de l\'erreur:', {
          hasError: (response as any).hasError,
          message: (response as any).message,
          status: (response as any).status,
          actionEffectue: (response as any).actionEffectue,
          extractedMessage: errorMessage
        });
        return {
          success: false,
          data: null,
          message: errorMessage
        };
      }
    } catch (error: any) {
      console.error('❌ Erreur lors de la création de la distribution:', error);
      return {
        success: false,
        data: null,
        message: error.message || 'Erreur lors de la création de la distribution'
      };
    }
  }

  /**
   * ✅ CORRIGÉ : Récupère le stock disponible d'une EPP pour une matière et un niveau (POST sécurisé)
   */
  async getStockDisponible(eppId: number, matiereId: number, niveauId: number): Promise<DistributionServiceResponse<{ stockDisponible: number }>> {
    try {
      console.log(`📊 Récupération stock EPP ${eppId}, Matière ${matiereId}, Niveau ${niveauId}`);

      // ✅ CORRECTION : Utiliser POST avec body pour sécuriser les données (inclure niveauId)
      const requestData = {
        eppId: eppId,
        matiereId: matiereId,
        niveauId: niveauId
      };

      // Envoyer directement StockRequest (pas de buildRequest)
      const response = await this.post<BackendResponse<number>>(
        `${this.serviceBaseUrl}/getStock`,
        requestData
      );

      // Debug: voir la structure de la réponse
      console.log('🔍 Réponse complète du backend:', JSON.stringify(response, null, 2));

      // Le backend retourne directement { item: number, hasError: boolean, message: string }
      if (!(response as any).hasError && (response as any).item !== null && (response as any).item !== undefined) {
        const stockValue = (response as any).item;
        console.log(`✅ Stock récupéré: ${stockValue}`);
        return {
          success: true,
          data: { stockDisponible: stockValue },
          message: (response as any).message || 'Stock récupéré avec succès'
        };
      }

      console.error('❌ Erreur lors de la récupération du stock:', (response as any).actionEffectue);
      return {
        success: false,
        data: null,
        message: (response as any).actionEffectue || 'Erreur lors de la récupération du stock'
      };
    } catch (error: any) {
      console.error('❌ Erreur lors de la récupération du stock:', error);
      return {
        success: false,
        data: null,
        message: error.message || 'Erreur lors de la récupération du stock'
      };
    }
  }

  /**
   * Debug le stock pour diagnostiquer les problèmes
   */
  async debugStock(eppId: number, matiereId: number, niveauId: number): Promise<DistributionServiceResponse<string>> {
    try {
      console.log(`🔍 Debug stock EPP ${eppId}, Matière ${matiereId}, Niveau ${niveauId}`);

      const response = await this.get<BackendResponse<string>>(
        `${this.serviceBaseUrl}/debugStock/${eppId}/${matiereId}/${niveauId}`
      );

      console.log('🔍 Réponse debug complète:', response);
      
      if (!(response as any).hasError && (response as any).item) {
        const debugInfo = (response as any).item;
        console.log('🔍 Debug info:', debugInfo);
        return {
          success: true,
          data: debugInfo,
          message: 'Debug terminé'
        };
      } else {
        const errorMessage = (response as any).message || (response as any).status?.message || 'Erreur lors du debug';
        console.error('❌ Erreur debug:', errorMessage);
        return {
          success: false,
          data: null,
          message: errorMessage
        };
      }
    } catch (error: any) {
      console.error('❌ Erreur lors du debug:', error);
      return {
        success: false,
        data: null,
        message: error.message || 'Erreur lors du debug'
      };
    }
  }

  /**
   * Teste le système de validation de stock
   */
  async testStockSystem(eppId: number): Promise<DistributionServiceResponse<string>> {
    try {
      console.log(`🧪 Test système de stock pour EPP ${eppId}`);

      const response = await this.get<string>(
        `${this.serviceBaseUrl}/testStockSystem/${eppId}`
      );

      if (!response.hasError && response.items?.length) {
        const data = response.items[0];
        console.log('✅ Tests de stock exécutés:', data);
        return {
          success: true,
          data,
          message: 'Tests de stock exécutés avec succès'
        };
      } else {
        const errMsg = response.status?.message ?? response.actionEffectue ?? 'Erreur lors des tests';
        console.error('❌ Erreur lors des tests:', errMsg);
        return {
          success: false,
          data: null,
          message: errMsg
        };
      }
    } catch (error: any) {
      console.error('❌ Erreur lors des tests de stock:', error);
      return {
        success: false,
        data: null,
        message: error.message || 'Erreur lors des tests de stock'
      };
    }
  }

  /**
   * Valide le stock avant distribution (méthode utilitaire)
   */
  async validateStockBeforeDistribution(
    eppId: number, 
    matieres: MatiereQuantiteDistributionData[]
  ): Promise<{ isValid: boolean; errors: string[]; stockInfo: Record<number, number> }> {
    try {
      console.log('🔍 Validation du stock avant distribution:', { eppId, matieres });

      const errors: string[] = [];
      const stockInfo: Record<number, number> = {};

      // Vérifier le stock pour chaque matière
      for (const matiere of matieres) {
        const niveauId = matiere.niveauId ?? 0;
        const stockResponse = await this.getStockDisponible(eppId, matiere.matiereId, niveauId);
        
        if (stockResponse.success && stockResponse.data !== null) {
          const stockDisponible = stockResponse.data.stockDisponible;
          stockInfo[matiere.matiereId] = stockDisponible;

          if (matiere.quantite > stockDisponible) {
            errors.push(
              `Stock insuffisant pour la matière ${matiere.matiereId}. ` +
              `Disponible: ${stockDisponible}, Demandé: ${matiere.quantite}`
            );
          }
        } else {
          errors.push(
            `Impossible de récupérer le stock pour la matière ${matiere.matiereId}: ${stockResponse.message}`
          );
        }
      }

      const isValid = errors.length === 0;
      
      console.log('📋 Résultat validation stock:', { 
        isValid, 
        errors, 
        stockInfo 
      });

      return { isValid, errors, stockInfo };

    } catch (error: any) {
      console.error('❌ Erreur lors de la validation du stock:', error);
      return {
        isValid: false,
        errors: [`Erreur lors de la validation: ${error.message}`],
        stockInfo: {}
      };
    }
  }

  /**
   * Récupère toutes les distributions (méthode standard)
   */
  async getDistributions(): Promise<DistributionServiceResponse<any[]>> {
    try {
      console.log('📋 Récupération des distributions');

      // Utiliser l'endpoint getByCriteria du backend
      const userId = this.getCurrentUserId();
      const token = this.getAuthToken();
      
      // Vérifier si l'utilisateur est connecté
      if (!userId || !token) {
        console.warn('⚠️ Utilisateur non connecté - impossible de récupérer les distributions');
        return {
          success: false,
          data: null,
          message: 'Utilisateur non connecté'
        };
      }
      
      const requestData = {
        user: userId,
        token: token,
        isSimpleLoading: false,
        data: {
          // Pas de critères spécifiques = récupérer toutes les distributions
        }
      };

      console.log('📤 Requête envoyée au backend:', requestData);
      const response = await this.post<any>(`${this.serviceBaseUrl}/getByCriteria`, requestData);
      
      console.log('🔍 Réponse complète du backend:', JSON.stringify(response, null, 2));

      if (!response.hasError && response.items && Array.isArray(response.items)) {
        console.log('✅ Distributions récupérées:', response.items.length);
        return {
          success: true,
          data: response.items,
          message: 'Distributions récupérées avec succès'
        };
      } else {
        const msg = response.status?.message ?? response.actionEffectue ?? 'Aucune distribution trouvée';
        console.warn('⚠️ Aucune distribution trouvée ou erreur:', msg);
        return {
          success: true, // Pas d'erreur, juste aucune donnée
          data: [],
          message: msg
        };
      }
    } catch (error: any) {
      console.error('❌ Erreur lors de la récupération des distributions:', error);
      return {
        success: false,
        data: null,
        message: error.message || 'Erreur lors de la récupération des distributions'
      };
    }
  }

  /**
   * Met à jour une distribution existante
   */
  async updateDistribution(
    distributionId: number,
    distributionData: Partial<DistributionData>
  ): Promise<DistributionServiceResponse<DistributionResponse>> {
    try {
      console.log('🔄 Mise à jour distribution:', distributionId);

      const response = await this.put<DistributionResponse>(
        `${this.serviceBaseUrl}/update`,
        { id: distributionId, ...distributionData }
      );

      if (!response.hasError && response.items?.length) {
        const data = response.items[0];
        console.log('✅ Distribution mise à jour:', data);
        return {
          success: true,
          data,
          message: 'Distribution mise à jour avec succès'
        };
      } else {
        const errMsg = response.status?.message ?? response.actionEffectue ?? 'Erreur lors de la mise à jour de la distribution';
        console.error('❌ Erreur lors de la mise à jour:', errMsg);
        return {
          success: false,
          data: null,
          message: errMsg
        };
      }
    } catch (error: any) {
      console.error('❌ Erreur lors de la mise à jour de la distribution:', error);
      return {
        success: false,
        data: null,
        message: error.message || 'Erreur lors de la mise à jour de la distribution'
      };
    }
  }

  /**
   * Upload un fichier pour une distribution (fiche d'émargement, etc.)
   * Utilise le système MouvementFiles avec entity_type='DISTRIBUTION'
   */
  async uploadDistributionFile(
    distributionId: number,
    file: File,
    fileType: 'FICHE_EMARGEMENT' | 'DOCUMENT' | 'PHOTO'
  ): Promise<DistributionServiceResponse<any>> {
    try {
      console.log(`📤 Upload fichier pour distribution ${distributionId}:`, file.name);

      // Lire le contenu du fichier
      const fileContent = await this.readFileAsBytes(file);

      const userId = this.getCurrentUserId();
      const token = this.getAuthToken();

      if (!userId || !token) {
        return {
          success: false,
          data: null,
          message: 'Utilisateur non connecté'
        };
      }

      // ✅ TEMPORAIRE : Utiliser idMouvement avec l'ID de la distribution
      // TODO: Implémenter le système polymorphique dans le backend
      const request = {
        user: userId,
        token: token,
        isSimpleLoading: false,
        datas: [{
          idMouvement: distributionId, // ✅ TEMPORAIRE : Utiliser idMouvement jusqu'à ce que le système polymorphique soit implémenté
          fileName: file.name,
          fileType: fileType,
          fileSize: file.size,
          fileContent: fileContent,
          uploadedBy: userId,
          uploadedAt: this.formatDateForBackend(new Date().toISOString().split('T')[0])
        }]
      };

      const response = await this.post<any>(`${this.filesEndpoint}/create`, request);

      if (!response.hasError && response.items && response.items.length > 0) {
        console.log('✅ Fichier uploadé avec succès');
        return {
          success: true,
          data: response.items[0],
          message: response.status?.message || 'Fichier uploadé avec succès'
        };
      } else {
        return {
          success: false,
          data: null,
          message: response.status?.message || 'Erreur lors de l\'upload du fichier'
        };
      }
    } catch (error: any) {
      console.error('❌ Erreur lors de l\'upload du fichier:', error);
      return {
        success: false,
        data: null,
        message: error.message || 'Erreur lors de l\'upload du fichier'
      };
    }
  }

  /**
   * Télécharge un fichier lié à une distribution (même endpoint que réception : mouvement_files).
   */
  async downloadDistributionFile(fileId: number): Promise<DistributionServiceResponse<Blob>> {
    try {
      const response = await fetch(`${apiConfig.baseUrl}${this.filesEndpoint}/download/${fileId}`, {
        method: 'GET',
        headers: {
          Authorization: `Bearer ${this.getAuthToken()}`,
          'Content-Type': 'application/json',
        },
      });
      if (response.ok) {
        const blob = await response.blob();
        return {
          success: true,
          data: blob,
          message: 'Fichier téléchargé',
        };
      }
      return {
        success: false,
        data: null as any,
        message: `Erreur HTTP: ${response.status} ${response.statusText}`,
      };
    } catch (error: unknown) {
      return {
        success: false,
        data: null as any,
        message: error instanceof Error ? error.message : 'Erreur lors du téléchargement',
      };
    }
  }

  /**
   * Récupère les fichiers d'une distribution
   */
  async getDistributionFiles(distributionId: number): Promise<DistributionServiceResponse<any[]>> {
    try {
      const userId = this.getCurrentUserId();
      const token = this.getAuthToken();

      if (!userId || !token) {
        return {
          success: false,
          data: null,
          message: 'Utilisateur non connecté'
        };
      }

      // ✅ TEMPORAIRE : Utiliser idMouvement avec l'ID de la distribution
      // TODO: Implémenter le système polymorphique dans le backend
      const request = {
        user: userId,
        token: token,
        isSimpleLoading: false,
        data: {
          idMouvement: distributionId // ✅ TEMPORAIRE : Utiliser idMouvement jusqu'à ce que le système polymorphique soit implémenté
        }
      };

      const response = await this.post<any>(`${this.filesEndpoint}/getByCriteria`, request);

      if (!response.hasError && response.items) {
        return {
          success: true,
          data: response.items,
          message: 'Fichiers récupérés avec succès'
        };
      } else {
        return {
          success: false,
          data: null,
          message: response.status?.message || 'Erreur lors de la récupération des fichiers'
        };
      }
    } catch (error: any) {
      console.error('❌ Erreur lors de la récupération des fichiers:', error);
      return {
        success: false,
        data: null,
        message: error.message || 'Erreur lors de la récupération des fichiers'
      };
    }
  }

  /**
   * Met à jour une distribution (pour finalisation) - VERSION CORRIGÉE
   */
  async updateDistributionForFinalization(distributionId: number, distributionData: DistributionUpdateData): Promise<DistributionServiceResponse<any>> {
    try {
      console.log(`📝 Mise à jour distribution ${distributionId}:`, distributionData);

      const userId = this.getCurrentUserId();
      const token = this.getAuthToken();

      if (!userId || !token) {
        return {
          success: false,
          data: null,
          message: 'Utilisateur non connecté'
        };
      }

      const hasMatiereQuantites = Object.prototype.hasOwnProperty.call(distributionData, "matiereQuantites");
      const mappedMatiereQuantites = (distributionData.matiereQuantites || []).map((mq) => ({
        idMatiere: mq.idMatiere,
        matiereCode: mq.matiereCode,
        quantiteRecue: mq.quantiteRecue,
        quantitePrevue: mq.quantitePrevue
      }));

      const request = {
        user: userId,
        token: token,
        isSimpleLoading: false,
        datas: [{
          id: distributionId,
          ...distributionData,
          matiereQuantites: hasMatiereQuantites ? mappedMatiereQuantites : undefined,
          updatedBy: userId
        }]
      };

      const response = await this.post<any>(`${this.serviceBaseUrl}/update`, request);

      if (!response.hasError && response.items && response.items.length > 0) {
        console.log('✅ Distribution mise à jour avec succès');
        return {
          success: true,
          data: response.items[0],
          message: response.status?.message || 'Distribution mise à jour avec succès'
        };
      } else {
        return {
          success: false,
          data: null,
          message: response.status?.message || 'Erreur lors de la mise à jour de la distribution'
        };
      }
    } catch (error: any) {
      console.error('❌ Erreur lors de la mise à jour de la distribution:', error);
      return {
        success: false,
        data: null,
        message: error.message || 'Erreur lors de la mise à jour de la distribution'
      };
    }
  }

  /**
   * Récupère les détails d'une distribution (avec les matières) via le nouvel endpoint GET /distributionEleve/details/{id}
   */
  async getDistributionDetails(distributionId: number): Promise<DistributionServiceResponse<any>> {
    try {
      console.log(`📋 Récupération détails distribution ${distributionId}`);

      // ✅ NOUVEAU : appel direct du nouvel endpoint de détails
      const response: any = await this.get(
        `${this.serviceBaseUrl}/details/${distributionId}`
      );
      
      if (!response.hasError && response.item) {
        console.log('✅ Détails distribution récupérés:', response.item);
        return {
          success: true,
          data: response.item,
          message: 'Détails récupérés avec succès'
        };
      } else {
        console.warn('⚠️ Aucun détail trouvé:', response.message);
        return {
          success: false,
          data: null,
          message: response.message || 'Aucun détail trouvé'
        };
      }
    } catch (error: any) {
      console.error('❌ Erreur lors de la récupération des détails:', error);
      return {
        success: false,
        data: null,
        message: error.message || 'Erreur lors de la récupération des détails'
      };
    }
  }

  /**
   * Supprime une distribution
   */
  async deleteDistribution(distributionId: number): Promise<DistributionServiceResponse<boolean>> {
    try {
      console.log('🗑️ Suppression distribution:', distributionId);

      const response = await this.delete<boolean>(
        `${this.serviceBaseUrl}/delete/${distributionId}`
      );

      if (!response.hasError) {
        console.log('✅ Distribution supprimée');
        return {
          success: true,
          data: true,
          message: 'Distribution supprimée avec succès'
        };
      } else {
        const errMsg = response.status?.message ?? response.actionEffectue ?? 'Erreur lors de la suppression de la distribution';
        console.error('❌ Erreur lors de la suppression:', errMsg);
        return {
          success: false,
          data: null,
          message: errMsg
        };
      }
    } catch (error: any) {
      console.error('❌ Erreur lors de la suppression de la distribution:', error);
      return {
        success: false,
        data: null,
        message: error.message || 'Erreur lors de la suppression de la distribution'
      };
    }
  }

  /**
   * Récupérer les distributions avec pagination
   */
  async getDistributionsPaginated(
    page: number = 1, 
    pageSize: number = 10,
    filters: any = {}
  ): Promise<DistributionServiceResponse<any[]>> {
    try {
      console.log(`📋 Récupération des distributions - Page ${page}, Taille ${pageSize}`);

      // Utiliser l'endpoint getByCriteria du backend
      const userId = this.getCurrentUserId();
      const token = this.getAuthToken();
      
      // Vérifier si l'utilisateur est connecté
      if (!userId || !token) {
        console.warn('⚠️ Utilisateur non connecté - impossible de récupérer les distributions');
        return {
          success: false,
          data: null,
          message: 'Utilisateur non connecté'
        };
      }
      
      const requestData = {
        user: userId,
        token: token,
        isSimpleLoading: false,
        data: filters,
        // Paramètres de pagination
        index: page - 1, // Backend utilise un index basé sur 0
        size: pageSize
      };

      console.log('📤 Requête envoyée au backend:', requestData);
      const response = await this.post<any>(`${this.serviceBaseUrl}/getByCriteria`, requestData);
      
      console.log('🔍 Réponse complète du backend:', JSON.stringify(response, null, 2));

      if (!response.hasError && response.items && Array.isArray(response.items)) {
        console.log('✅ Distributions récupérées:', response.items.length);
        return {
          success: true,
          data: response.items,
          message: 'Distributions récupérées avec succès',
          // Ajouter les métadonnées de pagination si disponibles
          pagination: {
            currentPage: page,
            pageSize: pageSize,
            totalCount: (response as unknown as { count?: number }).count ?? response.items.length,
            totalPages: (() => { const c = (response as unknown as { count?: number }).count; return c != null ? Math.ceil(c / pageSize) : 1; })()
          }
        };
      } else {
        const msg = response.status?.message ?? response.actionEffectue ?? 'Aucune distribution trouvée';
        console.warn('⚠️ Aucune distribution trouvée ou erreur:', msg);
        return {
          success: true, // Pas d'erreur, juste aucune donnée
          data: [],
          message: msg,
          pagination: {
            currentPage: page,
            pageSize: pageSize,
            totalCount: 0,
            totalPages: 0
          }
        };
      }
    } catch (error: any) {
      console.error('❌ Erreur lors de la récupération des distributions:', error);
      return {
        success: false,
        data: null,
        message: error.message || 'Erreur lors de la récupération des distributions'
      };
    }
  }
}

// Instance singleton du service
export const distributionService = new DistributionService();