/**
 * Service pour la gestion des utilisateurs
 * Intègre avec l'API backend UserController
 */

import { BaseApiService } from './base-api.service';
import { API_ENDPOINTS } from '@/lib/config/api';
import { ApiResponse } from '@/lib/types/api';
import { User, UserFilters } from '@/lib/types/entities';

export class UserService extends BaseApiService {
  
  /**
   * Créer un nouvel utilisateur
   * Endpoint: POST /user/create
   */
  async create(user: User): Promise<ApiResponse<User>> {
    const request = this.buildCreateRequest(user);
    return this.post<User>(API_ENDPOINTS.USERS + '/create', request);
  }

  /**
   * Mettre à jour un utilisateur
   * Endpoint: POST /user/update
   */
  async update(user: User): Promise<ApiResponse<User>> {
    const request = this.buildUpdateRequest(user);
    return this.post<User>(API_ENDPOINTS.USERS + '/update', request);
  }

  /**
   * Supprimer un utilisateur
   * Endpoint: POST /user/delete
   *
   * On évite d'écraser la méthode delete() générique de BaseApiService.
   */
  async deleteUser(userId: number): Promise<ApiResponse<User>> {
    const request = this.buildApiRequest({ id: userId });
    return this.post<User>(API_ENDPOINTS.USERS + '/delete', request);
  }

  /**
   * Récupérer les utilisateurs par critères
   * Endpoint: POST /user/getByCriteria
   */
  async getByCriteria(
    filters?: UserFilters,
    pagination?: { index: number; size: number }
  ): Promise<ApiResponse<User>> {
    const request = this.buildApiRequest(undefined, filters, pagination);
    return this.post<User>(API_ENDPOINTS.USERS + '/getByCriteria', request);
  }

  /**
   * Récupérer tous les utilisateurs (avec pagination)
   */
  async getAllUsers(
    page: number = 0,
    size: number = 50
  ): Promise<ApiResponse<User>> {
    return this.getByCriteria({}, { index: page, size });
  }

  /**
   * Rechercher des utilisateurs par nom/prénom
   */
  async searchUsers(
    searchTerm: string,
    page: number = 0,
    size: number = 50
  ): Promise<ApiResponse<User>> {
    const filters: UserFilters = {
      firstName: `%${searchTerm}%`,
      lastName: `%${searchTerm}%`,
    };
    return this.getByCriteria(filters, { index: page, size });
  }

  /**
   * Récupérer les utilisateurs par rôle
   */
  async getUsersByRole(
    roleCode: string,
    page: number = 0,
    size: number = 50
  ): Promise<ApiResponse<User>> {
    const filters: UserFilters = {
      roleCode: roleCode,
    };
    return this.getByCriteria(filters, { index: page, size });
  }

  /**
   * Récupérer les utilisateurs actifs
   */
  async getActiveUsers(
    page: number = 0,
    size: number = 50
  ): Promise<ApiResponse<User>> {
    const filters: UserFilters = {
      isActive: true,
      isDeleted: false,
    };
    return this.getByCriteria(filters, { index: page, size });
  }

  /**
   * Activer/Désactiver un utilisateur
   */
  async toggleUserStatus(user: User): Promise<ApiResponse<User>> {
    const updatedUser = { ...user, isActive: !user.isActive };
    return this.update(updatedUser);
  }

  /**
   * Bloquer/Débloquer un utilisateur
   */
  async toggleUserLock(user: User): Promise<ApiResponse<User>> {
    const updatedUser = { ...user, isLocked: !user.isLocked };
    return this.update(updatedUser);
  }

  /**
   * Réinitialiser les tentatives de connexion
   */
  async resetLoginAttempts(user: User): Promise<ApiResponse<User>> {
    const updatedUser = { ...user, loginAttempts: 0 };
    return this.update(updatedUser);
  }
}