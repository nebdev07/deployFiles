/**
 * Service pour la gestion des niveaux scolaires
 * Suit le même pattern que matiere.service.ts
 */

import { BaseApiService } from './base-api.service';
import { ApiResponse } from '@/lib/types/api';
import { NiveauScolaire, CreateNiveauScolaireRequest, NiveauScolaireFilters } from '@/lib/types/entities';

class NiveauScolaireService extends BaseApiService {
  private baseEndpoint = '/niveauScolaire';

  // Fonction utilitaire pour construire les requêtes selon le format backend
  private buildRequest(data: any, isCreateUpdate = false) {
    const userId = this.getCurrentUserId();
    const token = this.getAuthToken();
    
    // Vérifier si l'utilisateur est connecté
    if (!userId || !token) {
      console.warn('Utilisateur non connecté - impossible de charger les niveaux scolaires');
      throw new Error('Utilisateur non connecté');
    }
    
    const baseRequest = {
      user: userId,
      token: token,
      isSimpleLoading: false
    };
    
    if (isCreateUpdate) {
      // Pour CREATE/UPDATE/DELETE, utiliser "datas" avec un tableau
      return {
        ...baseRequest,
        datas: [data]
      };
    } else {
      // Pour GET/SEARCH, utiliser "data" avec un objet
      return {
        ...baseRequest,
        data
      };
    }
  }

  // Récupérer tous les niveaux scolaires avec filtres
  async getNiveauxScolaires(filters?: NiveauScolaireFilters): Promise<ApiResponse<NiveauScolaire[]>> {
    const data = {
      id: "",
      code: filters?.code || "",
      libelle: filters?.libelle || "",
      ordre: filters?.ordre ? filters.ordre.toString() : "",
      createdat: "",
      createdby: "",
      updatedat: "",
      updatedby: "",
      isdeleted: filters?.isDeleted || ""
    };
    
    return this.request<NiveauScolaire[]>('POST', `${this.baseEndpoint}/getByCriteria`, this.buildRequest(data));
  }

  // Récupérer un niveau scolaire par ID
  async getNiveauScolaireById(id: number): Promise<ApiResponse<NiveauScolaire[]>> {
    const data = {
      id: id.toString(),
      code: "",
      libelle: "",
      ordre: "",
      createdat: "",
      createdby: "",
      updatedat: "",
      updatedby: "",
      isdeleted: ""
    };
    return this.request<NiveauScolaire[]>('POST', `${this.baseEndpoint}/getByCriteria`, this.buildRequest(data));
  }

  // Créer un nouveau niveau scolaire
  async createNiveauScolaire(niveauData: CreateNiveauScolaireRequest): Promise<ApiResponse<NiveauScolaire[]>> {
    // Construire la requête avec le format "datas" pour la création
    const requestData = this.buildRequest(niveauData, true);
    return this.request<NiveauScolaire[]>('POST', `${this.baseEndpoint}/create`, requestData);
  }

  // Mettre à jour un niveau scolaire
  async updateNiveauScolaire(id: number, niveauData: Partial<CreateNiveauScolaireRequest>): Promise<ApiResponse<NiveauScolaire[]>> {
    const data = { id, ...niveauData };
    // Construire la requête avec le format "datas" pour la mise à jour
    const requestData = this.buildRequest(data, true);
    return this.request<NiveauScolaire[]>('POST', `${this.baseEndpoint}/update`, requestData);
  }

  // Supprimer un niveau scolaire (soft delete)
  async deleteNiveauScolaire(id: number): Promise<ApiResponse<NiveauScolaire[]>> {
    const data = { id };
    // Construire la requête avec le format "datas" pour la suppression
    const requestData = this.buildRequest(data, true);
    return this.request<NiveauScolaire[]>('POST', `${this.baseEndpoint}/delete`, requestData);
  }

  // Rechercher des niveaux scolaires par terme
  async searchNiveauxScolaires(searchTerm: string): Promise<ApiResponse<NiveauScolaire[]>> {
    const data = {
      id: "",
      code: searchTerm,
      libelle: searchTerm,
      ordre: "",
      createdat: "",
      createdby: "",
      updatedat: "",
      updatedby: "",
      isdeleted: ""
    };
    
    return this.request<NiveauScolaire[]>('POST', `${this.baseEndpoint}/getByCriteria`, this.buildRequest(data));
  }

  // Vérifier si un code niveau scolaire existe déjà
  async checkCodeExists(code: string, excludeId?: number): Promise<boolean> {
    try {
      const data = {
        id: "",
        code: code,
        libelle: "",
        ordre: "",
        createdat: "",
        createdby: "",
        updatedat: "",
        updatedby: "",
        isdeleted: ""
      };
      const response = await this.request<NiveauScolaire[]>('POST', `${this.baseEndpoint}/getByCriteria`, this.buildRequest(data));
      
      const items = (response.items ?? []) as unknown as NiveauScolaire[];
      if (items.length > 0) {
        // Si on exclut un ID (pour la mise à jour), vérifier que ce n'est pas le même niveau
        if (excludeId) {
          return items.some(niveau => niveau.id !== excludeId);
        }
        return true;
      }
      return false;
    } catch (error) {
      console.error('Erreur lors de la vérification du code niveau scolaire:', error);
      return false;
    }
  }

  // Vérifier si un ordre existe déjà
  async checkOrdreExists(ordre: number, excludeId?: number): Promise<boolean> {
    try {
      const data = {
        id: "",
        code: "",
        libelle: "",
        ordre: ordre.toString(),
        createdat: "",
        createdby: "",
        updatedat: "",
        updatedby: "",
        isdeleted: ""
      };
      const response = await this.request<NiveauScolaire[]>('POST', `${this.baseEndpoint}/getByCriteria`, this.buildRequest(data));
      
      const itemsOrdre = (response.items ?? []) as unknown as NiveauScolaire[];
      if (itemsOrdre.length > 0) {
        // Si on exclut un ID (pour la mise à jour), vérifier que ce n'est pas le même niveau
        if (excludeId) {
          return itemsOrdre.some(niveau => niveau.id !== excludeId);
        }
        return true;
      }
      return false;
    } catch (error) {
      console.error('Erreur lors de la vérification de l\'ordre niveau scolaire:', error);
      return false;
    }
  }

  // Récupérer les niveaux scolaires triés par ordre
  async getNiveauxScolairesOrdered(): Promise<ApiResponse<NiveauScolaire[]>> {
    const data = {
      id: "",
      code: "",
      libelle: "",
      ordre: "",
      createdat: "",
      createdby: "",
      updatedat: "",
      updatedby: "",
      isdeleted: "false"
    };
    
    const response = await this.request<NiveauScolaire[]>('POST', `${this.baseEndpoint}/getByCriteria`, this.buildRequest(data));
    
    // Trier par ordre côté frontend si le backend ne le fait pas
    const itemsSorted = (response.items ?? []) as unknown as NiveauScolaire[];
    if (itemsSorted.length > 0) {
      itemsSorted.sort((a, b) => (a.ordre || 0) - (b.ordre || 0));
    }
    return { ...response, items: itemsSorted } as unknown as ApiResponse<NiveauScolaire[]>;
  }
}

export const niveauScolaireService = new NiveauScolaireService();
