import { BaseApiService } from "./base-api.service"
import type { ApiResponse } from "@/lib/types/api"

export type DashboardSummaryResponse = {
  anneeScolaireId: number
  structureId: number
  structureLibelle?: string
  totalStructures: { drena: number; iepp: number; epp: number }
  totalEleves: number
  totalManuelsRequis: number
  totalManuelsCommandes: number
  totalManuelsDistribues: number
  couvertureGlobale: number
}

export type DrenaActivitesResponse = {
  drenaId: number
  anneeScolaireId: number
  drenaLibelle?: string
  iepps: Array<{
    ieppId: number
    ieppCode: string
    ieppLibelle: string
    epps: Array<{
      eppId: number
      eppCode: string
      eppLibelle: string
      totalEleves: number
      totalManuelsRequis: number
      totalManuelsCommandes: number
      totalManuelsDistribues: number
      couvertureGlobale: number
      stockDisponibleTotal: number
      stocksEnRuptureCount: number
    }>
  }>
}

class DashboardService extends BaseApiService {
  private baseEndpoint = "/dashboard"

  private buildRequest(data: any) {
    const userId = this.getCurrentUserId()
    const token = this.getAuthToken()
    if (!userId || !token) throw new Error("Utilisateur non connecté")
    return { user: userId, token, isSimpleLoading: false, data }
  }

  async getSummary(structureId: number, anneeScolaireId: number): Promise<ApiResponse<DashboardSummaryResponse>> {
    // On réutilise le format Request<StatistiqueDistributionDto> côté backend (structureId, anneeScolaireId)
    const data = {
      id: "",
      anneeScolaireId: String(anneeScolaireId),
      structureId: String(structureId),
    }
    return this.request<DashboardSummaryResponse>(
      "POST",
      `${this.baseEndpoint}/summary`,
      this.buildRequest(data),
    )
  }

  async getDrenaActivites(drenaStructureId: number, anneeScolaireId: number): Promise<ApiResponse<DrenaActivitesResponse>> {
    const data = {
      id: "",
      anneeScolaireId: String(anneeScolaireId),
      structureId: String(drenaStructureId),
    }
    return this.request<DrenaActivitesResponse>(
      "POST",
      `${this.baseEndpoint}/drena/activites`,
      this.buildRequest(data),
    )
  }

  /** Liste des structures DRENA (plan national — sélecteur DAF). */
  async listNationalDrenas(): Promise<ApiResponse<{ id: number; code: string; libelle: string }>> {
    const data = { id: "", anneeScolaireId: "", structureId: "" }
    return this.request<{ id: number; code: string; libelle: string }>(
      "POST",
      `${this.baseEndpoint}/drena/listNational`,
      this.buildRequest(data),
    )
  }
}

export const dashboardService = new DashboardService()

