/**
 * Service pour la gestion des retours de manuels
 * Gère les retours de manuels des EPP en fin d'année scolaire
 */

import { BaseApiService } from './base-api.service';

// Type personnalisé pour les réponses du service de retour
interface RetourServiceResponse<T> {
  success: boolean;
  data: T | null;
  message: string;
  pagination?: {
    currentPage: number;
    totalPages: number;
    pageSize: number;
    totalCount: number;
  };
}

// Interface pour les réponses du backend Spring Boot
interface BackendResponse<T> {
  item?: T;
  items?: T[];
  hasError: boolean;
  message?: string;
  status?: {
    code: string;
    message: string;
  };
  count?: number;
}

// Types pour les retours de manuels
export interface RetourManuelData {
  id?: number;
  structureId: number;
  anneeScolaireId: number;
  niveauId: number;
  matiereId: number;
  dateRetour: string; // Format: "dd/MM/yyyy"
  quantiteRetournee: number;
  /** Référence stat : total distribué (pour écarts / manuels non retournés) */
  quantiteDistribuee?: number;
  effectifClasse?: number;
  enregistrePar?: number;
  commentaire?: string;
}

export interface RetourManuelResponse {
  id: number;
  structureId: number;
  structureLibelle?: string;
  structureCode?: string;
  structureType?: string;
  anneeScolaireId: number;
  anneeScolaireLibelle?: string;
  anneeScolaireCode?: string;
  niveauId: number;
  niveauLibelle?: string;
  niveauCode?: string;
  matiereId: number;
  matiereLibelle?: string;
  matiereCode?: string;
  dateRetour: string;
  quantiteRetournee: number;
  quantiteDistribuee?: number;
  effectifClasse?: number;
  enregistrePar?: number;
  commentaire?: string;
  createdat?: string;
  createdby?: number;
  updatedat?: string;
  updatedby?: number;
  isdeleted?: boolean;
}

export class RetourService extends BaseApiService {
  private serviceBaseUrl = `/retourManuel`;

  /**
   * Construit la requête selon le pattern du backend
   */
  private buildRequest(data: any, isCreateUpdate: boolean = true): any {
    const userId = this.getCurrentUserId();
    const token = this.getAuthToken();
    
    // Vérifier si l'utilisateur est connecté
    if (!userId || !token) {
      console.warn('Utilisateur non connecté - impossible de gérer les récupérations de manuels');
      throw new Error('Utilisateur non connecté');
    }
    
    const baseRequest = {
      user: userId,
      token: token,
      isSimpleLoading: false
    };
    
    if (isCreateUpdate) {
      // Pour CREATE/UPDATE/DELETE, utiliser "datas" avec un tableau
      return {
        ...baseRequest,
        datas: Array.isArray(data) ? data : [data]
      };
    } else {
      // Pour GET/SEARCH, utiliser "data" avec un objet
      return {
        ...baseRequest,
        data: data
      };
    }
  }

  /**
   * Formate une date JavaScript en format backend (dd/MM/yyyy HH:mm:ss)
   * Le backend attend une String au format "dd/MM/yyyy HH:mm:ss"
   * Le transformer MapStruct convertira cette String en Date Java
   */
  private formatDate(date: string | Date): string {
    const d = typeof date === 'string' ? new Date(date) : date;
    if (isNaN(d.getTime())) {
      console.error('Date invalide:', date);
      return '';
    }
    // ✅ CORRECTION : Format attendu par le backend : "dd/MM/yyyy HH:mm:ss" (String)
    const day = String(d.getDate()).padStart(2, '0');
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const year = d.getFullYear();
    const hours = String(d.getHours()).padStart(2, '0');
    const minutes = String(d.getMinutes()).padStart(2, '0');
    const seconds = String(d.getSeconds()).padStart(2, '0');
    return `${day}/${month}/${year} ${hours}:${minutes}:${seconds}`;
  }

  /**
   * Crée un nouveau retour de manuel
   */
  async create(retourData: RetourManuelData): Promise<RetourServiceResponse<RetourManuelResponse>> {
    try {
      console.log('📤 Création retour manuel:', retourData);

      // Formater la date pour le backend (format ISO pour Jackson)
      const formattedData = {
        ...retourData,
        dateRetour: this.formatDate(retourData.dateRetour)
      };

      const requestData = this.buildRequest(formattedData, true);
      
      const response = await this.post<BackendResponse<RetourManuelResponse>>(
        `${this.serviceBaseUrl}/create`,
        requestData
      );

      console.log('📥 Réponse backend create:', response);

      if (!response.hasError && response.items && response.items.length > 0) {
        return {
          success: true,
          data: response.items[0] as unknown as RetourManuelResponse,
          message: response.status?.message || 'Récupération enregistrée avec succès'
        };
      } else {
        return {
          success: false,
          data: null,
          message: response.status?.message || 'Erreur lors de l’enregistrement de la récupération'
        };
      }
    } catch (error: any) {
      console.error('❌ Erreur création retour:', error);
      return {
        success: false,
        data: null,
        message: error.message || 'Erreur lors de l’enregistrement de la récupération'
      };
    }
  }

  /**
   * Met à jour un retour de manuel existant
   */
  async update(retourData: RetourManuelData): Promise<RetourServiceResponse<RetourManuelResponse>> {
    try {
      console.log('📤 Mise à jour retour manuel:', retourData);

      // Formater la date pour le backend
      const formattedData = {
        ...retourData,
        dateRetour: this.formatDate(retourData.dateRetour)
      };

      const requestData = this.buildRequest(formattedData, true);
      
      const response = await this.post<BackendResponse<RetourManuelResponse>>(
        `${this.serviceBaseUrl}/update`,
        requestData
      );

      console.log('📥 Réponse backend update:', response);

      if (!response.hasError && response.items && response.items.length > 0) {
        return {
          success: true,
          data: response.items[0] as unknown as RetourManuelResponse,
          message: response.status?.message || 'Récupération mise à jour avec succès'
        };
      } else {
        return {
          success: false,
          data: null,
          message: response.status?.message || 'Erreur lors de la mise à jour de la récupération'
        };
      }
    } catch (error: any) {
      console.error('❌ Erreur mise à jour retour:', error);
      return {
        success: false,
        data: null,
        message: error.message || 'Erreur lors de la mise à jour de la récupération'
      };
    }
  }

  /**
   * Supprime un retour de manuel
   */
  async deleteRetour(id: number): Promise<RetourServiceResponse<void>> {
    try {
      console.log('🗑️ Suppression retour manuel:', id);

      const requestData = this.buildRequest({ id }, true);
      
      const response = await this.post<BackendResponse<any>>(
        `${this.serviceBaseUrl}/delete`,
        requestData
      );

      console.log('📥 Réponse backend delete:', response);

      if (!response.hasError) {
        return {
          success: true,
          data: null,
          message: response.status?.message || 'Récupération supprimée avec succès'
        };
      } else {
        return {
          success: false,
          data: null,
          message: response.status?.message || 'Erreur lors de la suppression de la récupération'
        };
      }
    } catch (error: any) {
      console.error('❌ Erreur suppression retour:', error);
      return {
        success: false,
        data: null,
        message: error.message || 'Erreur lors de la suppression de la récupération'
      };
    }
  }

  /**
   * Récupère les retours selon des critères de recherche
   */
  async getByCriteria(
    criteria: any = {},
    page: number = 0,
    size: number = 10
  ): Promise<RetourServiceResponse<RetourManuelResponse[]>> {
    try {
      console.log('🔍 Recherche retours avec critères:', { criteria, page, size });

      // ✅ CORRECTION : Le backend attend index et size au niveau racine de la requête
      // Les critères de recherche vont dans "data", pas index/size
      const requestData = this.buildRequest(criteria, false);
      
      // Ajouter index et size au niveau racine (comme dans RequestBase)
      requestData.index = page;
      requestData.size = size;
      
      const response = await this.post<BackendResponse<RetourManuelResponse>>(
        `${this.serviceBaseUrl}/getByCriteria`,
        requestData
      );

      console.log('📥 Réponse backend getByCriteria:', response);

      if (!response.hasError && response.items) {
        const totalCount = (response as unknown as { count?: number }).count ?? 0;
        const totalPages = Math.ceil(totalCount / size);

        return {
          success: true,
          data: (response.items ?? []) as unknown as RetourManuelResponse[],
          message: 'Récupérations chargées avec succès',
          pagination: {
            currentPage: page,
            totalPages: totalPages,
            pageSize: size,
            totalCount: totalCount
          }
        };
      } else {
        return {
          success: false,
          data: [],
          message: response.status?.message || 'Erreur lors du chargement des récupérations'
        };
      }
    } catch (error: any) {
      console.error('❌ Erreur récupération retours:', error);
      return {
        success: false,
        data: [],
        message: error.message || 'Erreur lors du chargement des récupérations'
      };
    }
  }

  /**
   * Récupère un retour par son ID
   */
  async getById(id: number): Promise<RetourServiceResponse<RetourManuelResponse>> {
    try {
      console.log('🔍 Récupération retour ID:', id);

      const response = await this.getByCriteria({ id }, 0, 1);

      if (response.success && response.data && response.data.length > 0) {
        return {
          success: true,
          data: response.data[0],
          message: 'Récupération chargée avec succès'
        };
      } else {
        return {
          success: false,
          data: null,
          message: 'Récupération introuvable'
        };
      }
    } catch (error: any) {
      console.error('❌ Erreur récupération retour:', error);
      return {
        success: false,
        data: null,
        message: error.message || 'Erreur lors du chargement de la récupération'
      };
    }
  }

  /**
   * Récupère les retours d'une structure pour une année scolaire
   */
  async getByStructure(
    structureId: number,
    anneeScolaireId?: number,
    page: number = 0,
    size: number = 10
  ): Promise<RetourServiceResponse<RetourManuelResponse[]>> {
    try {
      console.log('🔍 Récupération retours structure:', { structureId, anneeScolaireId });

      const criteria: any = {
        structureId: structureId
        // ✅ NOTE : Le backend trie automatiquement par dateRetour desc
        // Pas besoin de passer orderField/orderDirection
      };

      if (anneeScolaireId) {
        criteria.anneeScolaireId = anneeScolaireId;
      }

      return await this.getByCriteria(criteria, page, size);
    } catch (error: any) {
      console.error('❌ Erreur récupération retours structure:', error);
      return {
        success: false,
        data: [],
        message: error.message || 'Erreur lors du chargement des récupérations'
      };
    }
  }
}

export const retourService = new RetourService();

