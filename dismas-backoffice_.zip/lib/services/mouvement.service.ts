/**
 * Service pour la gestion des mouvements (Réceptions, Distributions, Retours)
 * Remplace le service de réception avec la nouvelle architecture unifiée
 */

import { logger } from '@/lib/utils/logger'

import { BaseApiService } from './base-api.service';
import { ApiResponse } from '@/lib/types/api';

// Type personnalisé pour les réponses du service
interface MouvementServiceResponse<T> {
  success: boolean;
  data: T | null;
  message: string;
}

// Types pour les mouvements
export interface MouvementData {
  id?: number; // ✅ NOUVEAU : ID du Mouvement pour mise à jour (depuis Besoin approuvé)
  typeMouvement: 'RECEPTION_IEPP' | 'RECEPTION_EPP' | 'DISTRIBUTION_CLASSES' | 'RETOUR_CLASSES';
  observation?: string;
  numeroBordereau: string;
  dateMouvement: string;
  idStructure: number;
  anneeScolaireId: number;
  catalogues?: CatalogueMouvementData[]; // Pour compatibilité (sera mappé vers CatalogueMouvements)
  CatalogueMouvements?: CatalogueMouvementData[]; // ✅ Format attendu par le backend (CamelCase)
}

export interface CatalogueMouvementData {
  idCatalogue: number;
  matieres?: MatiereQuantiteData[]; // Pour compatibilité
  matiereQuantites?: MatiereQuantiteData[]; // ✅ Format attendu par le backend
}

export interface MatiereQuantiteData {
  idMatiere: number;
  quantiteRecue: number;
  quantitePrevue: number;
  niveauId?: number; // Pour les distributions par niveau
}

export interface MouvementFileData {
  fileName: string;
  filePath: string;
  fileType: 'BORDEREAU' | 'PHOTO' | 'DOCUMENT';
  fileSize: number;
  uploadedBy: number;
  uploadedAt: string;
}

export interface MouvementResponse {
  id: number;
  typeMouvement: string;
  observation: string;
  numeroBordereau: string;
  dateMouvement: string;
  idStructure: number;
  structureLibelle?: string;
  anneeScolaireId: number;
  anneeScolaireLibelle?: string;
  anneeStockId?: number;
  anneeStockLibelle?: string;
  noteAnneeStock?: string;
  statut: string;
  validatedBy?: number;
  validatedAt?: string;
  validationLevel?: string;
  createdAt: string;
  createdBy: number;
  updatedAt?: string;
  updatedBy?: number;
}

export interface StockDisponibleData {
  structureId: number;
  matiereId: number;
  niveauId?: number;
  anneeScolaireId: number;
  quantiteDisponible: number;
  quantiteReceptions: number;
  quantiteDistributions: number;
  quantiteRetours: number;
  quantiteRetoursAnneePrecedente: number;
}

export class MouvementService extends BaseApiService {
  private baseEndpoint = '/mouvement'; // Nouveau endpoint unifié (minuscule)

  constructor() {
    super();
  }

  // ============================================================
  // MÉTHODES POUR LA GESTION DES MOUVEMENTS
  // ============================================================

  /**
   * Crée un mouvement (réception, distribution ou retour)
   */
  async createMouvement(mouvementData: MouvementData): Promise<MouvementServiceResponse<MouvementResponse>> {
    try {
      const request = this.buildRequest(mouvementData, true);
      
      const response = await this.post(`${this.baseEndpoint}/create`, request);
      
      if (!response.hasError && response.items && response.items.length > 0) {
        return {
          success: true,
          data: response.items[0] as MouvementResponse,
          message: response.status?.message || 'Mouvement créé avec succès'
        };
      } else {
        return {
          success: false,
          data: null,
          message: response.status?.message || 'Erreur lors de la création du mouvement'
        };
      }
    } catch (error) {
      logger.error('Erreur lors de la création du mouvement:', error);
      return {
        success: false,
        data: null,
        message: 'Erreur réseau ou serveur'
      };
    }
  }

  /**
   * ✅ NOUVEAU : Crée un mouvement COMPLET en une seule transaction (atomique)
   * Gère : Mouvement + CatalogueMouvement + MatiereQuantite
   * Si mouvementData.id est présent, met à jour le Mouvement existant (depuis Besoin approuvé)
   */
  async createMouvementComplete(mouvementData: MouvementData): Promise<MouvementServiceResponse<MouvementResponse>> {
    try {
      const request = this.buildRequest(mouvementData, true);
      
      const response = await this.post(`${this.baseEndpoint}/createComplete`, request);
      
      if (!response.hasError && response.items && response.items.length > 0) {
        return {
          success: true,
          data: response.items[0] as MouvementResponse,
          message: mouvementData.id 
            ? response.status?.message || 'Mouvement mis à jour avec succès'
            : response.status?.message || 'Mouvement créé avec succès'
        };
      } else {
        return {
          success: false,
          data: null,
          message: response.status?.message || 'Erreur lors de la création/mise à jour du mouvement'
        };
      }
    } catch (error) {
      logger.error('Erreur lors de la création/mise à jour du mouvement complet:', error);
      return {
        success: false,
        data: null,
        message: 'Erreur réseau ou serveur'
      };
    }
  }

  /**
   * ✅ NOUVEAU : Crée une réception EPP avec validation du stock IEPP
   * Utilise directement la table StockDisponible pour la validation côté backend
   * Endpoint dédié pour les réceptions EPP (IEPP → EPP)
   * 
   * @param mouvementData Données de la réception EPP (doit avoir typeMouvement = 'RECEPTION_EPP' ou 'EPP')
   * @returns Response avec la réception créée ou erreur si stock insuffisant
   */
  async createReceptionEPP(mouvementData: MouvementData): Promise<MouvementServiceResponse<MouvementResponse>> {
    try {
      logger.info('📥 Création réception EPP avec validation stock IEPP...');
      
      // Vérifier que c'est bien une réception EPP
      const typeStr = mouvementData.typeMouvement as string;
      if (typeStr !== 'RECEPTION_EPP' && typeStr !== 'EPP') {
        logger.warn('⚠️ Type de mouvement incorrect pour createReceptionEPP:', mouvementData.typeMouvement);
        return {
          success: false,
          data: null,
          message: 'Ce endpoint est réservé aux réceptions EPP (typeMouvement doit être RECEPTION_EPP ou EPP)'
        };
      }
      
      // Forcer le type à RECEPTION_EPP pour cohérence
      const dataToSend = {
        ...mouvementData,
        typeMouvement: 'RECEPTION_EPP' as const
      };
      
      const request = this.buildRequest(dataToSend, true);
      
      const response = await this.post(`${this.baseEndpoint}/createReceptionEPP`, request);
      
      if (!response.hasError && response.items && response.items.length > 0) {
        logger.info('✅ Réception EPP créée avec succès (stock IEPP validé)');
        return {
          success: true,
          data: response.items[0] as MouvementResponse,
          message: response.status?.message || 'Réception EPP créée avec succès (stock IEPP validé)'
        };
      } else {
        // Gérer les erreurs de stock insuffisant spécifiquement
        const errorMessage = response.status?.message || 'Erreur lors de la création de la réception EPP';
        const isStockError = errorMessage.includes('Stock insuffisant') || 
                            errorMessage.includes('Disponible:') || 
                            errorMessage.includes('Demandé:') ||
                            response.status?.code === '902';
        
        logger.error(isStockError ? '❌ Stock IEPP insuffisant' : '❌ Erreur création réception EPP:', errorMessage);
        
        return {
          success: false,
          data: null,
          message: errorMessage
        };
      }
    } catch (error: any) {
      // Comme pour la création d'utilisateur : laisser l'exception remonter pour que la page
      // affiche le message backend (error.message / error.details?.status?.message)
      logger.error('❌ Erreur création réception EPP (propagation vers la page):', error?.message ?? error);
      throw error;
    }
  }

  /**
   * Crée un mouvement avec gestion automatique des stocks
   */
  async createMouvementWithStock(mouvementData: MouvementData): Promise<MouvementServiceResponse<MouvementResponse>> {
    try {
      const request = this.buildRequest(mouvementData, true);
      
      const response = await this.post(`${this.baseEndpoint}/createWithStock`, request);
      
      if (!response.hasError && response.items && response.items.length > 0) {
        return {
          success: true,
          data: response.items[0] as MouvementResponse,
          message: response.status?.message || 'Mouvement créé avec stocks mis à jour'
        };
      } else {
        return {
          success: false,
          data: null,
          message: response.status?.message || 'Erreur lors de la création du mouvement'
        };
      }
    } catch (error) {
      logger.error('Erreur lors de la création du mouvement avec stock:', error);
      return {
        success: false,
        data: null,
        message: 'Erreur réseau ou serveur'
      };
    }
  }

  /**
   * Valide un mouvement (IEPP ou EPP)
   */
  async validateMouvement(
    mouvementId: number, 
    validationLevel: 'IEPP' | 'EPP'
  ): Promise<MouvementServiceResponse<MouvementResponse>> {
    try {
      const data = {
        id: mouvementId,
        validationLevel: validationLevel
      };
      
      const request = this.buildRequest(data, true);
      
      const response = await this.post(`${this.baseEndpoint}/validate`, request);
      
      if (!response.hasError && response.items && response.items.length > 0) {
        return {
          success: true,
          data: response.items[0] as MouvementResponse,
          message: response.status?.message || 'Mouvement validé avec succès'
        };
      } else {
        return {
          success: false,
          data: null,
          message: response.status?.message || 'Erreur lors de la validation'
        };
      }
    } catch (error) {
      logger.error('Erreur lors de la validation du mouvement:', error);
      return {
        success: false,
        data: null,
        message: 'Erreur réseau ou serveur'
      };
    }
  }

  /**
   * Récupère un mouvement avec tous ses détails
   */
  /**
   * ✅ NOUVEAU : Charge un Mouvement depuis un Besoin approuvé
   * 
   * @param besoinId ID du Besoin approuvé
   * @returns Mouvement complet avec CatalogueMouvement et MatiereQuantite
   */
  async loadFromBesoin(besoinId: number): Promise<MouvementServiceResponse<MouvementResponse>> {
    try {
      logger.info(`📥 Chargement Mouvement depuis Besoin approuvé: ${besoinId}`);

      const response: any = await this.get(
        `${this.baseEndpoint}/loadFromBesoin/${besoinId}`
      );

      if (response.hasError) {
        logger.error(`❌ Erreur lors du chargement depuis Besoin: ${response.status?.message || 'Erreur inconnue'}`);
        return {
          success: false,
          data: null,
          message: response.status?.message || 'Erreur lors du chargement du Mouvement depuis le Besoin',
        };
      }

      // Le backend retourne items (array) comme getMouvementWithDetails
      if (response.items && response.items.length > 0) {
        const mouvement = response.items[0];
        logger.info(`✅ Mouvement chargé depuis Besoin: ID=${mouvement.id}`);
        return {
          success: true,
          data: mouvement,
          message: 'Mouvement chargé avec succès depuis le Besoin approuvé',
        };
      } else {
        logger.warn(`⚠️ Aucun Mouvement trouvé pour Besoin: ${besoinId}`);
        return {
          success: false,
          data: null,
          message: 'Aucun Mouvement trouvé pour ce Besoin approuvé',
        };
      }
    } catch (error: any) {
      logger.error(`❌ Exception lors du chargement depuis Besoin: ${error.message}`);
      return {
        success: false,
        data: null,
        message: error.message || 'Erreur lors du chargement du Mouvement depuis le Besoin',
      };
    }
  }

  async getMouvementWithDetails(mouvementId: number): Promise<MouvementServiceResponse<MouvementResponse>> {
    try {
      const response = await this.get(`${this.baseEndpoint}/getWithDetails/${mouvementId}`);
      
      if (!response.hasError && response.items && response.items.length > 0) {
        return {
          success: true,
          data: response.items[0] as MouvementResponse,
          message: 'Mouvement récupéré avec succès'
        };
      } else {
        return {
          success: false,
          data: null,
          message: response.status?.message || 'Mouvement introuvable'
        };
      }
    } catch (error) {
      logger.error('Erreur lors de la récupération du mouvement:', error);
      return {
        success: false,
        data: null,
        message: 'Erreur réseau ou serveur'
      };
    }
  }

  /**
   * Recherche des mouvements par critères
   */
  async getMouvementsByCriteria(criteria: any): Promise<MouvementServiceResponse<MouvementResponse[]>> {
    try {
      const request = this.buildRequest(criteria, false);
      
      const response = await this.post(`${this.baseEndpoint}/getByCriteria`, request);
      
      if (!response.hasError) {
        return {
          success: true,
          data: response.items as MouvementResponse[],
          message: `${response.items?.length || 0} mouvement(s) trouvé(s)`
        };
      } else {
        return {
          success: false,
          data: [],
          message: response.status?.message || 'Aucun mouvement trouvé'
        };
      }
    } catch (error) {
      logger.error('Erreur lors de la recherche des mouvements:', error);
      return {
        success: false,
        data: [],
        message: 'Erreur réseau ou serveur'
      };
    }
  }

  /**
   * Annule un mouvement
   */
  async annulerMouvement(
    mouvementId: number, 
    raison: string
  ): Promise<MouvementServiceResponse<any>> {
    try {
      const data = {
        mouvementId: mouvementId,
        raison: raison
      };
      
      const request = this.buildRequest(data, true);
      
      const response = await this.post(`${this.baseEndpoint}/annuler`, request);
      
      if (!response.hasError) {
        return {
          success: true,
          data: response.items?.[0],
          message: response.status?.message || 'Mouvement annulé avec succès'
        };
      } else {
        return {
          success: false,
          data: null,
          message: response.status?.message || 'Erreur lors de l\'annulation'
        };
      }
    } catch (error) {
      logger.error('Erreur lors de l\'annulation du mouvement:', error);
      return {
        success: false,
        data: null,
        message: 'Erreur réseau ou serveur'
      };
    }
  }

  // ============================================================
  // MÉTHODES POUR LA CONSULTATION DES STOCKS
  // ============================================================

  /**
   * Récupère le stock disponible
   */
  async getStockDisponible(
    structureId: number,
    matiereId: number,
    niveauId: number | null,
    anneeScolaireId: number
  ): Promise<MouvementServiceResponse<StockDisponibleData>> {
    try {
      const params = new URLSearchParams({
        structureId: structureId.toString(),
        matiereId: matiereId.toString(),
        anneeScolaireId: anneeScolaireId.toString(),
        ...(niveauId && { niveauId: niveauId.toString() })
      });
      
      const response = await this.get(`/stock/disponible?${params.toString()}`);
      
      // ✅ CORRECTION : Le backend utilise `item` (singulier) pour /stock/disponible, pas `items` (pluriel)
      // Gérer les deux cas pour compatibilité
      const stockData = (response as any).item || (response.items && response.items.length > 0 ? response.items[0] : null);
      
      const msg = response.status?.message ?? response.actionEffectue;
      if (!response.hasError && stockData) {
        return {
          success: true,
          data: stockData as StockDisponibleData,
          message: msg || 'Stock récupéré avec succès'
        };
      } else {
        return {
          success: false,
          data: null,
          message: msg || 'Stock non disponible'
        };
      }
    } catch (error) {
      logger.error('Erreur lors de la récupération du stock:', error);
      return {
        success: false,
        data: null,
        message: 'Erreur réseau ou serveur'
      };
    }
  }

  /**
   * Récupère tous les stocks d'une structure pour une année
   */
  async getStocksByStructureAndAnnee(
    structureId: number,
    anneeScolaireId: number
  ): Promise<MouvementServiceResponse<StockDisponibleData[]>> {
    try {
      // ✅ IMPORTANT : préfixer par "/" pour éviter une URL du type "http://localhost:8081stock/..."
      const response = await this.get(`/stock/structure/${structureId}/annee/${anneeScolaireId}`);
      
      if (!response.hasError) {
        const items = (response.items ?? []) as StockDisponibleData[];
        return {
          success: true,
          data: items,
          message: `${items.length} stock(s) trouvé(s)`
        };
      } else {
        return {
          success: false,
          data: [],
          message: 'Aucun stock trouvé'
        };
      }
    } catch (error) {
      logger.error('Erreur lors de la récupération des stocks:', error);
      return {
        success: false,
        data: [],
        message: 'Erreur réseau ou serveur'
      };
    }
  }

  /**
   * Vérifie la disponibilité du stock avant distribution
   */
  async verifierStock(
    structureId: number,
    matiereId: number,
    niveauId: number | null,
    anneeScolaireId: number,
    quantiteDemandee: number
  ): Promise<MouvementServiceResponse<{ suffisant: boolean; disponible: number; manque?: number }>> {
    try {
      const data = {
        structureId,
        matiereId,
        niveauId,
        anneeScolaireId,
        quantiteDemandee
      };
      
      const request = this.buildRequest(data, false);
      
      const response = await this.post('stock/verifier', request);
      
      if (!response.hasError && response.items && response.items.length > 0) {
        return {
          success: true,
          data: response.items[0] as { suffisant: boolean; disponible: number; manque?: number },
          message: 'Vérification effectuée'
        };
      } else {
        return {
          success: false,
          data: null,
          message: response.status?.message || 'Erreur lors de la vérification'
        };
      }
    } catch (error) {
      logger.error('Erreur lors de la vérification du stock:', error);
      return {
        success: false,
        data: null,
        message: 'Erreur réseau ou serveur'
      };
    }
  }

  // ============================================================
  // MÉTHODES UTILITAIRES
  // ============================================================

  /**
   * Construit une requête au format attendu par le backend
   */
  private buildRequest(data: any, isCreateUpdate = false) {
    const userId = this.getCurrentUserId();
    const token = this.getAuthToken();
    
    // DEBUG: Log pour vérifier la récupération du token
    logger.log('🔍 MouvementService.buildRequest() - DEBUG:');
    logger.log('  - userId:', userId);
    logger.log('  - token présent ?', !!token);
    logger.log('  - token length:', token?.length);
    logger.log('  - token (20 premiers chars):', token?.substring(0, 20));
    logger.log('  - isCreateUpdate:', isCreateUpdate);
    
    if (!userId || !token) {
      logger.error('❌ Utilisateur non connecté - userId:', userId, 'token présent:', !!token);
      throw new Error('Utilisateur non connecté');
    }
    
    const baseRequest = {
      user: userId,
      token: token,
      isSimpleLoading: false
    };
    
    if (isCreateUpdate) {
      return {
        ...baseRequest,
        datas: Array.isArray(data) ? data : [data]
      };
    } else {
      return {
        ...baseRequest,
        data: data
      };
    }
  }

  // Les méthodes getCurrentUserId() et getAuthToken() sont héritées de BaseApiService
  // Pas besoin de les redéfinir ici

  /**
   * Convertit une date en format DD/MM/YYYY
   */
  private formatDate(date: Date): string {
    const day = String(date.getDate()).padStart(2, '0');
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const year = date.getFullYear();
    return `${day}/${month}/${year}`;
  }
}

// Export d'une instance unique
export const mouvementService = new MouvementService();

