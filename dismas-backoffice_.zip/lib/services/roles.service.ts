/**
 * Service pour la gestion des rôles
 * Récupère les rôles depuis le backend
 */

import { BaseApiService } from './base-api.service';
import { ApiResponse } from '@/lib/types/api';

export interface Role {
  id: number;
  code: string;
  libelle: string;
  description?: string;
  niveauHierarchique?: number;
  isActive?: boolean;
  createdAt?: string;
  updatedAt?: string;
  createdBy?: number;
  updatedBy?: number;
}

export interface RoleFilters {
  id?: number;
  code?: string;
  libelle?: string;
  isActive?: boolean;
}

class RolesService extends BaseApiService {
  private baseEndpoint = '/role';

  /**
   * Construire la requête au format attendu par le backend
   */
  private buildRequest(data: any) {
    const userId = this.getCurrentUserId();
    const token = this.getAuthToken();
    
    // Vérifier si l'utilisateur est connecté
    if (!userId || !token) {
      console.warn('Utilisateur non connecté - impossible de charger les rôles');
      throw new Error('Utilisateur non connecté');
    }
    
    return {
      user: userId,
      token: token,
      isSimpleLoading: false,
      data: data
    };
  }

  /**
   * Récupérer tous les rôles
   */
  async getRoles(filters?: RoleFilters): Promise<ApiResponse<Role[]>> {
    try {
      const data = {
        id: filters?.id || "",
        code: filters?.code || "",
        libelle: filters?.libelle || "",
        description: "",
        niveauHierarchique: "",
        isDeleted: filters?.isActive === false ? "true" : "",
        createdAt: "",
        updatedAt: "",
        createdBy: "",
        updatedBy: ""
      };
      
      return await this.request<Role[]>('POST', `${this.baseEndpoint}/getByCriteria`, this.buildRequest(data));
    } catch (error: any) {
      // Si c'est une erreur de token invalide ou session expirée, laisser le service de base gérer la déconnexion
      if (error.code === '900' && (error.message.includes('Token invalide') || error.message.includes('Session expirée'))) {
        throw error; // Le service de base va gérer la déconnexion
      }
      throw error;
    }
  }

  /**
   * Récupérer un rôle par ID
   */
  async getRoleById(id: number): Promise<ApiResponse<Role[]>> {
    try {
      const data = {
        id: id.toString(),
        code: "",
        libelle: "",
        description: "",
        niveauHierarchique: "",
        isDeleted: "",
        createdAt: "",
        updatedAt: "",
        createdBy: "",
        updatedBy: ""
      };
      
      return await this.request<Role[]>('POST', `${this.baseEndpoint}/getByCriteria`, this.buildRequest(data));
    } catch (error: any) {
      if (error.code === '900' && (error.message.includes('Token invalide') || error.message.includes('Session expirée'))) {
        throw error;
      }
      throw error;
    }
  }

  /**
   * Récupérer un rôle par code
   */
  async getRoleByCode(code: string): Promise<ApiResponse<Role[]>> {
    try {
      const data = {
        id: "",
        code: code,
        libelle: "",
        description: "",
        niveauHierarchique: "",
        isDeleted: "",
        createdAt: "",
        updatedAt: "",
        createdBy: "",
        updatedBy: ""
      };
      
      return await this.request<Role[]>('POST', `${this.baseEndpoint}/getByCriteria`, this.buildRequest(data));
    } catch (error: any) {
      if (error.code === '900' && (error.message.includes('Token invalide') || error.message.includes('Session expirée'))) {
        throw error;
      }
      throw error;
    }
  }
}

export const rolesService = new RolesService();