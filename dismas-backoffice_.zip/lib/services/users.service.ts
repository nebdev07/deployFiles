/**
 * Service pour la gestion des utilisateurs
 * Intègre les nouvelles interfaces avec structures administratives
 */

import { BaseApiService } from './base-api.service';
import { ApiResponse } from '@/lib/types/api';
import { User, CreateUserRequest, UserFilters } from '@/lib/types/entities';

function flattenItems<T>(raw: T[] | undefined | null): T[] {
  if (!raw || raw.length === 0) return [];
  if (Array.isArray(raw[0])) {
    return (raw as unknown as T[][]).flat();
  }
  return raw as T[];
}

class UsersService extends BaseApiService {
  private baseEndpoint = '/user';

  // Fonction utilitaire pour construire les requêtes selon le format backend
  private buildRequest(data: any, isCreateUpdate = false) {
    const userId = this.getCurrentUserId();
    const token = this.getAuthToken();

    if (!userId || !token) {
      console.warn('Utilisateur non connecté - impossible de charger les utilisateurs');
      throw new Error('Utilisateur non connecté');
    }

    const baseRequest = {
      user: userId,
      token: token,
      isSimpleLoading: false,
    };

    if (isCreateUpdate) {
      return {
        ...baseRequest,
        datas: [data],
      };
    } else {
      return {
        ...baseRequest,
        data,
      };
    }
  }

  /** Requête getByCriteria avec pagination serveur (index 0-based) et chargement léger. */
  private buildCriteriaListRequest(data: Record<string, unknown>, pageIndexZero: number, pageSize: number) {
    const userId = this.getCurrentUserId();
    const token = this.getAuthToken();
    if (!userId || !token) {
      console.warn('Utilisateur non connecté - impossible de charger les utilisateurs');
      throw new Error('Utilisateur non connecté');
    }
    return {
      user: userId,
      token,
      isSimpleLoading: true,
      index: pageIndexZero,
      size: pageSize,
      data,
    };
  }

  /**
   * Liste paginée (getByCriteria). Les filtres structure sont appliqués côté serveur selon la session.
   */
  async getUsers(
    filters?: UserFilters,
    pageIndexZero = 0,
    pageSize = 20,
  ): Promise<ApiResponse<User[]>> {
    const data: Record<string, unknown> = {
      id: '',
      idPersonnel: '',
      login: filters?.login ?? '',
      password: '',
      isConnected: '',
      isDefaultPassword: '',
      isLdapUser: '',
      lastConnectionDate: '',
      lastLockDate: '',
      createdAt: '',
      createdBy: '',
      updatedAt: '',
      updatedBy: '',
      roleId: '',
      quickSearch: filters?.quickSearch?.trim() ?? '',
      roleCode: filters?.roleCode ?? '',
    };

    if (filters?.isDeleted !== undefined) {
      data.isDeleted = filters.isDeleted;
    } else {
      data.isDeleted = false;
    }
    if (filters?.isActive !== undefined) {
      data.isActive = filters.isActive;
    } else {
      data.isActive = '';
    }
    if (filters?.isLocked !== undefined) {
      data.isLocked = filters.isLocked;
    } else {
      data.isLocked = '';
    }

    return this.request<User[]>(
      'POST',
      `${this.baseEndpoint}/getByCriteria`,
      this.buildCriteriaListRequest(data, pageIndexZero, pageSize),
    );
  }

  /** Liste large pour périmètre structures (IEPP/EPP libres) — même endpoint, taille élevée. */
  async getUsersForStructureOccupancy(maxRows = 8000): Promise<User[]> {
    const res = await this.getUsers({ isDeleted: false }, 0, maxRows);
    return flattenItems(res.items) as unknown as User[];
  }

  // Récupérer un utilisateur par ID
  async getUserById(id: number): Promise<ApiResponse<User[]>> {
    const data = {
      id: id.toString(),
      idPersonnel: '',
      login: '',
      password: '',
      isActive: '',
      isConnected: '',
      isDefaultPassword: '',
      isDeleted: '',
      isLdapUser: '',
      isLocked: '',
      lastConnectionDate: '',
      lastLockDate: '',
      createdAt: '',
      createdBy: '',
      updatedAt: '',
      updatedBy: '',
      roleId: '',
    };
    return this.request<User[]>('POST', `${this.baseEndpoint}/getByCriteria`, this.buildRequest(data));
  }

  // Créer un nouvel utilisateur
  async createUser(userData: CreateUserRequest): Promise<ApiResponse<User[]>> {
    const requestData = this.buildRequest(userData, true);
    return this.request<User[]>('POST', `${this.baseEndpoint}/create`, requestData);
  }

  // Mettre à jour un utilisateur
  async updateUser(id: number, userData: Partial<CreateUserRequest>): Promise<ApiResponse<User[]>> {
    const data = { id, ...userData };
    const requestData = this.buildRequest(data, true);
    return this.request<User[]>('POST', `${this.baseEndpoint}/update`, requestData);
  }

  // Supprimer un utilisateur (soft delete)
  async deleteUser(id: number): Promise<ApiResponse<User[]>> {
    const data = { id };
    const requestData = this.buildRequest(data, true);
    return this.request<User[]>('POST', `${this.baseEndpoint}/delete`, requestData);
  }

  // Activer/Désactiver un utilisateur
  async toggleUserStatus(id: number, isActive: boolean): Promise<ApiResponse<User[]>> {
    const data = { id, isActive };
    const requestData = this.buildRequest(data, true);
    return this.request<User[]>('POST', `${this.baseEndpoint}/toggleStatus`, requestData);
  }

  // Réinitialiser le mot de passe d'un utilisateur
  async resetPassword(id: number, newPassword?: string): Promise<ApiResponse<User[]>> {
    const data = { id, newPassword };
    const requestData = this.buildRequest(data, true);
    return this.request<User[]>('POST', `${this.baseEndpoint}/resetPassword`, requestData);
  }

  async lockUser(id: number): Promise<ApiResponse<User[]>> {
    const data = { id };
    const requestData = this.buildRequest(data, true);
    return this.request<User[]>('POST', `${this.baseEndpoint}/blockUser`, requestData);
  }

  async unlockUser(id: number): Promise<ApiResponse<User[]>> {
    const data = { id };
    const requestData = this.buildRequest(data, true);
    return this.request<User[]>('POST', `${this.baseEndpoint}/unBlockUser`, requestData);
  }

  async getUsersByStructure(structureType: 'DRENA' | 'IEPP' | 'EPP', structureId: number): Promise<ApiResponse<User[]>> {
    const data = {
      [`${structureType.toLowerCase()}Id`]: structureId,
      isActive: true,
      isDeleted: false,
    };

    return this.request<User[]>('POST', `${this.baseEndpoint}/getByCriteria`, this.buildRequest(data, false));
  }

  async getUsersByRole(roleCode: string): Promise<ApiResponse<User[]>> {
    const data = {
      roleCode,
      isActive: true,
      isDeleted: false,
    };

    return this.request<User[]>('POST', `${this.baseEndpoint}/getByCriteria`, this.buildRequest(data, false));
  }

  async checkLoginExists(login: string, excludeId?: number): Promise<boolean> {
    try {
      const data: Record<string, unknown> = {
        id: '',
        idPersonnel: '',
        login: login,
        password: '',
        isActive: '',
        isConnected: '',
        isDefaultPassword: '',
        isDeleted: '',
        isLdapUser: '',
        isLocked: '',
        lastConnectionDate: '',
        lastLockDate: '',
        createdAt: '',
        createdBy: '',
        updatedAt: '',
        updatedBy: '',
        roleId: '',
      };
      const response = await this.request<User[]>(
        'POST',
        `${this.baseEndpoint}/getByCriteria`,
        this.buildCriteriaListRequest(data as any, 0, 20),
      );

      const items = flattenItems(response.items) as unknown as User[];
      if (items.length > 0) {
        if (excludeId) {
          return items.some((u) => u.id !== excludeId);
        }
        return true;
      }
      return false;
    } catch (error) {
      console.error('Erreur lors de la vérification du login:', error);
      return false;
    }
  }

  async checkEmailExists(email: string, excludeId?: number): Promise<boolean> {
    try {
      console.warn('Vérification email non implémentée - le backend ne semble pas avoir de champ email');
      return false;
    } catch (error) {
      console.error("Erreur lors de la vérification de l'email:", error);
      return false;
    }
  }
}

export const usersService = new UsersService();
