/**
 * Service pour la gestion des stocks avec intégration backend
 * Récupère les stocks réels depuis l'API au lieu des données mockées
 */

import { logger } from '@/lib/utils/logger'

import { BaseApiService } from './base-api.service';
import { ApiResponse } from '@/lib/types/api';
import { apiConfig } from '@/lib/config/api';

// Types pour les stocks
export interface StockData {
  structureId: number;
  structureLibelle: string;
  structureCode: string;
  matiereId: number;
  matiereCode: string;
  matiereLibelle: string;
  niveauId?: number;
  niveauCode?: string;
  niveauLibelle?: string;
  stockDisponible: number;
  stockReception: number;
  stockRetours: number;
  stockRetoursAnneePrecedente: number;
  stockDistribution: number;
  /** Volume régulation (REDISTRIBUTION_STOCK) : sorties IEPP ou entrées EPP selon la structure. */
  stockRedistribution: number;
  seuilCritique?: number;
  statut: 'OK' | 'CRITIQUE' | 'EPUISE';
}

export interface StockByStructure {
  structureId: number;
  structureLibelle: string;
  structureCode: string;
  stockTotal: number;
  derniereMiseAJour: string;
  statutGlobal: 'BON' | 'CRITIQUE' | 'EPUISE';
  matieres: StockData[];
}

export interface MouvementStockData {
  id: number;
  dateMouvement: string;
  typeMouvement: string;
  matiereLibelle: string;
  matiereCode: string;
  quantite: number;
  structureSource?: string;
  structureDestination?: string;
  operateur: string;
  statut: string;
  bordereau?: string;
}

// Type personnalisé pour les réponses du service de stock
interface StockServiceResponse<T> {
  success: boolean;
  data: T | null;
  message: string;
}

/**
 * Calcule la quantité distribuée à afficher (tous onglets).
 * Le backend renvoie quantiteDistributions en négatif (sorties) ; on affiche la valeur absolue.
 */
export function normalizeQuantiteDistribuee(
  quantiteDistributions?: number | null,
  quantite_distributions?: number | null
): number {
  const raw = quantiteDistributions ?? quantite_distributions ?? 0;
  return Math.abs(typeof raw === 'number' ? raw : 0);
}

/** DTO backend StockDisponibleDto (champs utilisés pour le mapping) */
interface StockDisponibleDtoBackend {
  structureId?: number;
  structureLibelle?: string;
  structureCode?: string;
  matiereId?: number;
  matiereCode?: string;
  matiereLibelle?: string;
  niveauId?: number;
  niveauCode?: string;
  niveauLibelle?: string;
  quantiteDisponible?: number;
  quantiteReceptions?: number;
  /** Backend stocke les distributions en négatif ; on affiche la valeur absolue (quantité distribuée) */
  quantiteDistributions?: number;
  quantite_distributions?: number;
  quantiteRetours?: number;
  quantiteRetoursAnneePrecedente?: number;
  quantiteRedistribution?: number;
  estEnRupture?: boolean;
  updatedAt?: string;
}

export class StockService extends BaseApiService {
  private static readonly SEUIL_CRITIQUE = 10;

  /**
   * Récupère les données de stock pour la page Stocks (endpoint /stock/structure/.../annee/...).
   * Un seul appel, données cohérentes avec libellés.
   */
  async getStocksForPage(
    structureId: number,
    anneeScolaireId: number
  ): Promise<StockServiceResponse<{ structure: StockByStructure; allStocks: StockData[] }>> {
    try {
      logger.log(`📊 Récupération stock page structure ${structureId} année ${anneeScolaireId}`);
      const response = await this.get<StockDisponibleDtoBackend>(
        `/stock/structure/${structureId}/annee/${anneeScolaireId}`
      );
      const items = (response as any).items as StockDisponibleDtoBackend[] | undefined;
      if (!items || !Array.isArray(items)) {
        const structure: StockByStructure = {
          structureId,
          structureLibelle: `Structure ${structureId}`,
          structureCode: `STR-${structureId}`,
          stockTotal: 0,
          derniereMiseAJour: '',
          statutGlobal: 'BON',
          matieres: [],
        };
        return {
          success: true,
          data: { structure, allStocks: [] },
          message: (response as any).status?.message || 'Aucun stock trouvé',
        };
      }
      const allStocks: StockData[] = items.map((dto) => this.mapDtoToStockData(dto, structureId));
      const structure = this.buildStockByStructure(structureId, items, allStocks);
      logger.log(`✅ Stock page: ${allStocks.length} lignes pour structure ${structureId}`);
      return {
        success: true,
        data: { structure, allStocks },
        message: `${allStocks.length} stock(s) récupéré(s)`,
      };
    } catch (error: any) {
      logger.error('❌ Erreur getStocksForPage:', error);
      return {
        success: false,
        data: null,
        message: error?.message || 'Erreur lors du chargement du stock',
      };
    }
  }

  /**
   * Vue agrégée DRENA : stocks des IEPP du ressort uniquement (les EPP sont dans l’onglet dédié).
   */
  async getStocksForDrenaPage(
    drenaStructureId: number,
    anneeScolaireId: number
  ): Promise<StockServiceResponse<{ structure: StockByStructure; allStocks: StockData[] }>> {
    try {
      logger.log(`📊 Récupération stock agrégé DRENA ${drenaStructureId} année ${anneeScolaireId}`);
      const response = await this.get<StockDisponibleDtoBackend>(
        `/stock/drena/${drenaStructureId}/annee/${anneeScolaireId}`
      );
      const items = (response as any).items as StockDisponibleDtoBackend[] | undefined;
      const allStocks: StockData[] = Array.isArray(items)
        ? items.map((dto) => this.mapDtoToStockData(dto, dto.structureId ?? drenaStructureId))
        : [];

      const stockTotal = allStocks.reduce((sum, s) => sum + s.stockDisponible, 0);
      const hasRupture = allStocks.some((s) => s.statut === 'EPUISE');
      const hasCritique = allStocks.some((s) => s.statut === 'CRITIQUE');
      const statutGlobal: StockByStructure['statutGlobal'] = hasRupture ? 'EPUISE' : hasCritique ? 'CRITIQUE' : 'BON';
      const structure: StockByStructure = {
        structureId: drenaStructureId,
        structureLibelle: `DRENA #${drenaStructureId}`,
        structureCode: `DRENA-${drenaStructureId}`,
        stockTotal,
        derniereMiseAJour: '',
        statutGlobal,
        matieres: [],
      };

      return {
        success: true,
        data: { structure, allStocks },
        message: (response as any).status?.message || `${allStocks.length} stock(s) agrégés`,
      };
    } catch (error: any) {
      logger.error('❌ Erreur getStocksForDrenaPage:', error);
      return {
        success: false,
        data: null,
        message: error?.message || 'Erreur lors du chargement du stock agrégé DRENA',
      };
    }
  }

  /** Stocks IEPP du ressort DRENA (onglet IEPP optimisé). */
  async getStocksForDrenaIeppTab(
    drenaStructureId: number,
    anneeScolaireId: number
  ): Promise<StockServiceResponse<StockData[]>> {
    try {
      const response = await this.get<StockDisponibleDtoBackend>(
        `/stock/drena/${drenaStructureId}/iepp/annee/${anneeScolaireId}`
      );
      const items = (response as any).items as StockDisponibleDtoBackend[] | undefined;
      const allStocks: StockData[] = Array.isArray(items)
        ? items.map((dto) => this.mapDtoToStockData(dto, dto.structureId ?? drenaStructureId))
        : [];
      return { success: true, data: allStocks, message: (response as any).status?.message || 'OK' };
    } catch (error: any) {
      return { success: false, data: null, message: error?.message || 'Erreur chargement stocks IEPP DRENA' };
    }
  }

  /** Stocks EPP du ressort DRENA (onglet EPP optimisé). */
  async getStocksForDrenaEppTab(
    drenaStructureId: number,
    anneeScolaireId: number
  ): Promise<StockServiceResponse<StockData[]>> {
    try {
      const response = await this.get<StockDisponibleDtoBackend>(
        `/stock/drena/${drenaStructureId}/epp/annee/${anneeScolaireId}`
      );
      const items = (response as any).items as StockDisponibleDtoBackend[] | undefined;
      const allStocks: StockData[] = Array.isArray(items)
        ? items.map((dto) => this.mapDtoToStockData(dto, dto.structureId ?? drenaStructureId))
        : [];
      return { success: true, data: allStocks, message: (response as any).status?.message || 'OK' };
    } catch (error: any) {
      return { success: false, data: null, message: error?.message || 'Erreur chargement stocks EPP DRENA' };
    }
  }

  private mapDtoToStockData(dto: StockDisponibleDtoBackend, structureId: number): StockData {
    const quantiteDisponible = dto.quantiteDisponible ?? 0;
    const statut: StockData['statut'] = dto.estEnRupture
      ? 'EPUISE'
      : quantiteDisponible < StockService.SEUIL_CRITIQUE
        ? 'CRITIQUE'
        : 'OK';
    const stockDistribution = normalizeQuantiteDistribuee(dto.quantiteDistributions, dto.quantite_distributions);
    return {
      structureId: dto.structureId ?? structureId,
      structureLibelle: dto.structureLibelle ?? `Structure ${structureId}`,
      structureCode: dto.structureCode ?? `STR-${structureId}`,
      matiereId: dto.matiereId ?? 0,
      matiereCode: dto.matiereCode ?? '',
      matiereLibelle: dto.matiereLibelle ?? '',
      niveauId: dto.niveauId,
      niveauCode: dto.niveauCode,
      niveauLibelle: dto.niveauLibelle,
      stockDisponible: quantiteDisponible,
      stockReception: dto.quantiteReceptions ?? 0,
      stockRetours: dto.quantiteRetours ?? 0,
      stockRetoursAnneePrecedente: dto.quantiteRetoursAnneePrecedente ?? 0,
      stockDistribution,
      stockRedistribution: dto.quantiteRedistribution ?? 0,
      seuilCritique: StockService.SEUIL_CRITIQUE,
      statut,
    };
  }

  private buildStockByStructure(
    structureId: number,
    items: StockDisponibleDtoBackend[],
    allStocks: StockData[]
  ): StockByStructure {
    const first = items[0];
    const stockTotal = allStocks.reduce((sum, s) => sum + s.stockDisponible, 0);
    const updatedAts = items.map((d) => d.updatedAt).filter(Boolean) as string[];
    const derniereMiseAJour = updatedAts.length ? updatedAts.sort().reverse()[0] : '';
    const hasRupture = allStocks.some((s) => s.statut === 'EPUISE');
    const hasCritique = allStocks.some((s) => s.statut === 'CRITIQUE');
    const statutGlobal: StockByStructure['statutGlobal'] = hasRupture ? 'EPUISE' : hasCritique ? 'CRITIQUE' : 'BON';
    return {
      structureId: first?.structureId ?? structureId,
      structureLibelle: first?.structureLibelle ?? `Structure ${structureId}`,
      structureCode: first?.structureCode ?? `STR-${structureId}`,
      stockTotal,
      derniereMiseAJour,
      statutGlobal,
      matieres: [],
    };
  }

  /**
   * Récupère le stock d'une structure (EPP ou IEPP)
   * @deprecated Préférer getStocksForPage(structureId, anneeScolaireId) pour la page Stocks
   */
  async getStockByStructure(structureId: number): Promise<StockServiceResponse<StockByStructure>> {
    try {
      logger.log(`📊 Récupération stock structure ${structureId}`);

      // Pour l'instant, on utilise l'endpoint de distribution pour récupérer le stock
      // TODO: Créer un endpoint dédié aux stocks
      const response = await this.get<any>(`/distributionEleve/getStock/${structureId}/1`);
      
      if (!response.hasError) {
        // Construire la structure de données attendue
        const stockData: StockByStructure = {
          structureId: structureId,
          structureLibelle: `Structure ${structureId}`, // TODO: Récupérer depuis l'API
          structureCode: `STR-${structureId}`,
          stockTotal: 0,
          derniereMiseAJour: new Date().toISOString(),
          statutGlobal: 'BON',
          matieres: [] // TODO: Récupérer toutes les matières
        };

        logger.log('✅ Stock structure récupéré:', stockData);
        return {
          success: true,
          data: stockData,
          message: response.status?.message || 'Stock récupéré avec succès'
        };
      } else {
        const message = response.status?.message || 'Erreur lors de la récupération du stock';
        logger.error('❌ Erreur lors de la récupération du stock:', message);
        return {
          success: false,
          data: null,
          message
        };
      }
    } catch (error: any) {
      logger.error('❌ Erreur lors de la récupération du stock:', error);
      return {
        success: false,
        data: null,
        message: error.message || 'Erreur lors de la récupération du stock'
      };
    }
  }

  /**
   * Récupère le stock d'une matière spécifique pour une structure
   */
  async getStockByMatiere(structureId: number, matiereId: number): Promise<StockServiceResponse<StockData>> {
    try {
      logger.log(`📊 Récupération stock matière ${matiereId} pour structure ${structureId}`);

      const response = await this.get<any>(`/distributionEleve/getStock/${structureId}/${matiereId}`);
      const items = response.items ?? [];
      const stockValue = (items[0] ?? 0) as number;
      
      if (!response.hasError && items.length > 0) {
        const stockData: StockData = {
          structureId: structureId,
          structureLibelle: `Structure ${structureId}`,
          structureCode: `STR-${structureId}`,
          matiereId: matiereId,
          matiereCode: `MAT-${matiereId}`,
          matiereLibelle: `Matière ${matiereId}`,
          stockDisponible: stockValue,
          stockReception: 0, // TODO: Récupérer depuis l'API
          stockRetours: 0,
          stockRetoursAnneePrecedente: 0,
          stockDistribution: 0, // TODO: Récupérer depuis l'API
          stockRedistribution: 0,
          seuilCritique: 10,
          statut: stockValue === 0 ? 'EPUISE' : stockValue < 10 ? 'CRITIQUE' : 'OK'
        };

        logger.log('✅ Stock matière récupéré:', stockData);
        return {
          success: true,
          data: stockData,
          message: response.status?.message || 'Stock récupéré avec succès'
        };
      } else {
        const message = response.status?.message || 'Erreur lors de la récupération du stock';
        logger.error('❌ Erreur lors de la récupération du stock matière:', message);
        return {
          success: false,
          data: null,
          message
        };
      }
    } catch (error: any) {
      logger.error('❌ Erreur lors de la récupération du stock matière:', error);
      return {
        success: false,
        data: null,
        message: error.message || 'Erreur lors de la récupération du stock'
      };
    }
  }

  /**
   * Récupère tous les stocks d'une structure avec toutes les matières
   */
  async getAllStocksByStructure(structureId: number, matiereIds: number[]): Promise<StockServiceResponse<StockData[]>> {
    try {
      logger.log(`📊 Récupération tous les stocks structure ${structureId}`);

      const stocks: StockData[] = [];
      
      // Récupérer le stock pour chaque matière
      for (const matiereId of matiereIds) {
        try {
          const stockResponse = await this.getStockByMatiere(structureId, matiereId);
          if (stockResponse.success && stockResponse.data) {
            stocks.push(stockResponse.data);
          }
        } catch (error) {
          logger.warn(`Erreur pour matière ${matiereId}:`, error);
        }
      }

      logger.log(`✅ ${stocks.length} stocks récupérés pour structure ${structureId}`);
      return {
        success: true,
        data: stocks,
        message: `${stocks.length} stocks récupérés avec succès`
      };
    } catch (error: any) {
      logger.error('❌ Erreur lors de la récupération des stocks:', error);
      return {
        success: false,
        data: null,
        message: error.message || 'Erreur lors de la récupération des stocks'
      };
    }
  }

  /**
   * Récupère les mouvements de stock pour une structure (POST /mouvementStock/getByCriteria).
   * @param anneeStockId année de comptabilisation stock (alignée sur le sélecteur d’année de la page Stocks).
   */
  async getMouvementsStock(
    structureId: number,
    anneeStockId?: number | null
  ): Promise<StockServiceResponse<MouvementStockData[]>> {
    try {
      logger.log(
        `📊 Récupération mouvements stock structure ${structureId}` +
          (anneeStockId != null ? ` anneeStockId=${anneeStockId}` : '')
      );
      const userId = this.getCurrentUserId();
      const token = this.getAuthToken();
      if (!userId || !token) {
        return { success: false, data: null, message: 'Utilisateur non connecté' };
      }
      const request = {
        user: userId,
        token,
        isSimpleLoading: false,
        data: {
          structureId,
          ...(anneeStockId != null && anneeStockId > 0 ? { anneeStockId } : {}),
        },
        searchParam: { structureIdParam: { value: structureId, operator: 'EQ' as const } },
      };
      const response = await this.post<unknown>('/mouvementStock/getByCriteria', request);
      const items = (response as any).items as any[] | undefined;
      if (!items || !Array.isArray(items)) {
        return {
          success: true,
          data: [],
          message: (response as any).status?.message || 'Aucun mouvement trouvé',
        };
      }
      const mouvements: MouvementStockData[] = items.map((item) => ({
        id: item.id ?? 0,
        dateMouvement: item.dateMouvement ?? '',
        typeMouvement: item.typeMouvement ?? '',
        matiereLibelle: item.matiereLibelle ?? '',
        matiereCode: item.matiereCode ?? '',
        quantite: item.quantite ?? 0,
        structureSource: item.structureAdministrativeLibelle,
        structureDestination: undefined,
        operateur: item.createdBy != null ? String(item.createdBy) : '',
        statut: item.statut ?? '',
        bordereau: undefined,
      }));
      logger.log(`✅ ${mouvements.length} mouvements récupérés pour structure ${structureId}`);
      return {
        success: true,
        data: mouvements,
        message: `${mouvements.length} mouvement(s) récupéré(s)`,
      };
    } catch (error: any) {
      logger.error('❌ Erreur lors de la récupération des mouvements:', error);
      return {
        success: false,
        data: null,
        message: error?.message || 'Erreur lors de la récupération des mouvements',
      };
    }
  }

  /**
   * Vue agrégée DRENA : mouvements hub + IEPP + EPP du ressort.
   * @param anneeScolaireId filtre optionnel sur l’année de stock (query `anneeScolaireId`).
   */
  async getMouvementsStockForDrena(
    drenaStructureId: number,
    anneeScolaireId?: number | null
  ): Promise<StockServiceResponse<MouvementStockData[]>> {
    try {
      logger.log(`📊 Récupération mouvements agrégés DRENA ${drenaStructureId}`);
      const q =
        anneeScolaireId != null && anneeScolaireId > 0
          ? `?anneeScolaireId=${encodeURIComponent(String(anneeScolaireId))}`
          : '';
      const response = await this.get<any>(`/stock/drena/${drenaStructureId}/mouvements${q}`);
      const items = (response as any).items as any[] | undefined;
      if (!items || !Array.isArray(items)) {
        return {
          success: true,
          data: [],
          message: (response as any).status?.message || 'Aucun mouvement trouvé',
        };
      }
      const mouvements: MouvementStockData[] = items.map((item) => ({
        id: item.id ?? 0,
        dateMouvement: item.dateMouvement ?? '',
        typeMouvement: item.typeMouvement ?? '',
        matiereLibelle: item.matiereLibelle ?? '',
        matiereCode: item.matiereCode ?? '',
        quantite: item.quantite ?? 0,
        structureSource: item.structureAdministrativeLibelle,
        structureDestination: undefined,
        operateur: item.createdBy != null ? String(item.createdBy) : '',
        statut: item.statut ?? '',
        bordereau: undefined,
      }));
      return {
        success: true,
        data: mouvements,
        message: `${mouvements.length} mouvement(s) agrégés`,
      };
    } catch (error: any) {
      logger.error('❌ Erreur getMouvementsStockForDrena:', error);
      return {
        success: false,
        data: null,
        message: error?.message || 'Erreur lors de la récupération des mouvements agrégés',
      };
    }
  }

  /**
   * Met à jour le stock (pour les ajustements manuels)
   */
  async updateStock(
    structureId: number, 
    matiereId: number, 
    nouvelleQuantite: number,
    motif: string
  ): Promise<StockServiceResponse<boolean>> {
    try {
      logger.log(`🔄 Mise à jour stock structure ${structureId}, matière ${matiereId}, quantité ${nouvelleQuantite}`);

      // TODO: Créer un endpoint pour la mise à jour de stock
      // Pour l'instant, on simule la mise à jour
      logger.log('✅ Stock mis à jour (simulation)');
      return {
        success: true,
        data: true,
        message: 'Stock mis à jour avec succès'
      };
    } catch (error: any) {
      logger.error('❌ Erreur lors de la mise à jour du stock:', error);
      return {
        success: false,
        data: null,
        message: error.message || 'Erreur lors de la mise à jour du stock'
      };
    }
  }

  /**
   * @deprecated Préférer {@link rapportService.generate} avec `codeType: 'STOCK'` (API /rapport/generate).
   */
  async generateStockReport(_structureId: number): Promise<StockServiceResponse<null>> {
    return {
      success: false,
      data: null,
      message: 'Utiliser rapportService.generate({ codeType: "STOCK", anneeScolaireId, structureId })',
    };
  }
}

// Instance singleton du service
export const stockService = new StockService();
