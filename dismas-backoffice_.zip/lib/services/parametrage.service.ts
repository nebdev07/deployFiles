/**
 * Service pour la gestion des paramétrages
 * Regroupe les services pour TypeOuvrage, Matiere, NiveauScolaire, StructureAdministrative
 */

import { BaseApiService } from './base-api.service';
import { API_ENDPOINTS } from '@/lib/config/api';
import { ApiResponse } from '@/lib/types/api';
import { TypeOuvrage, Matiere, NiveauScolaire, StructureAdministrative } from '@/lib/types/entities';

// Interfaces pour les filtres
export interface TypeOuvrageFilters {
  code?: string;
  libelle?: string;
  isActive?: boolean;
  isDeleted?: boolean;
}

export interface MatiereFilters {
  code?: string;
  libelle?: string;
  isActive?: boolean;
  isDeleted?: boolean;
}

export interface NiveauScolaireFilters {
  code?: string;
  libelle?: string;
  ordre?: number;
  isActive?: boolean;
  isDeleted?: boolean;
}

export interface StructureAdministrativeFilters {
  code?: string;
  libelle?: string;
  type?: string;
  parentId?: number;
  ieppId?: number; // Pour filtrer par IEPP ID (relation iepp_id dans la table)
  isActive?: boolean;
  isDeleted?: boolean;
}

export class ParametrageService extends BaseApiService {
  
  // ==================== TYPE OUVRAGE ====================
  
  /**
   * Créer un nouveau type d'ouvrage
   */
  async createTypeOuvrage(typeOuvrage: TypeOuvrage): Promise<ApiResponse<TypeOuvrage>> {
    const request = this.buildCreateRequest(typeOuvrage);
    return this.post<TypeOuvrage>(API_ENDPOINTS.TYPE_OUVRAGE + '/create', request);
  }

  /**
   * Mettre à jour un type d'ouvrage
   */
  async updateTypeOuvrage(typeOuvrage: TypeOuvrage): Promise<ApiResponse<TypeOuvrage>> {
    const request = this.buildUpdateRequest(typeOuvrage);
    return this.post<TypeOuvrage>(API_ENDPOINTS.TYPE_OUVRAGE + '/update', request);
  }

  /**
   * Supprimer un type d'ouvrage
   */
  async deleteTypeOuvrage(id: number): Promise<ApiResponse<TypeOuvrage>> {
    const request = this.buildApiRequest({ id });
    return this.post<TypeOuvrage>(API_ENDPOINTS.TYPE_OUVRAGE + '/delete', request);
  }

  /**
   * Récupérer les types d'ouvrages par critères
   */
  async getTypeOuvragesByCriteria(
    filters?: TypeOuvrageFilters,
    pagination?: { index: number; size: number }
  ): Promise<ApiResponse<TypeOuvrage>> {
    const request = this.buildApiRequest(undefined, filters, pagination);
    return this.post<TypeOuvrage>(API_ENDPOINTS.TYPE_OUVRAGE + '/getByCriteria', request);
  }

  /**
   * Récupérer tous les types d'ouvrages actifs
   */
  async getAllTypeOuvrages(): Promise<ApiResponse<TypeOuvrage>> {
    const filters: TypeOuvrageFilters = {
      isActive: true,
      isDeleted: false,
    };
    return this.getTypeOuvragesByCriteria(filters);
  }

  // ==================== MATIERE ====================
  
  /**
   * Créer une nouvelle matière
   */
  async createMatiere(matiere: Matiere): Promise<ApiResponse<Matiere>> {
    const request = this.buildCreateRequest(matiere);
    return this.post<Matiere>(API_ENDPOINTS.MATIERE + '/create', request);
  }

  /**
   * Mettre à jour une matière
   */
  async updateMatiere(matiere: Matiere): Promise<ApiResponse<Matiere>> {
    const request = this.buildUpdateRequest(matiere);
    return this.post<Matiere>(API_ENDPOINTS.MATIERE + '/update', request);
  }

  /**
   * Supprimer une matière
   */
  async deleteMatiere(id: number): Promise<ApiResponse<Matiere>> {
    const request = this.buildApiRequest({ id });
    return this.post<Matiere>(API_ENDPOINTS.MATIERE + '/delete', request);
  }

  /**
   * Récupérer les matières par critères
   */
  async getMatieresByCriteria(
    filters?: MatiereFilters,
    pagination?: { index: number; size: number }
  ): Promise<ApiResponse<Matiere>> {
    const request = this.buildApiRequest(undefined, filters, pagination);
    return this.post<Matiere>(API_ENDPOINTS.MATIERE + '/getByCriteria', request);
  }

  /**
   * Récupérer toutes les matières actives
   */
  async getAllMatieres(): Promise<ApiResponse<Matiere>> {
    const filters: MatiereFilters = {
      isActive: true,
      isDeleted: false,
    };
    return this.getMatieresByCriteria(filters);
  }

  // ==================== NIVEAU SCOLAIRE ====================
  
  /**
   * Créer un nouveau niveau scolaire
   */
  async createNiveauScolaire(niveau: NiveauScolaire): Promise<ApiResponse<NiveauScolaire>> {
    const request = this.buildCreateRequest(niveau);
    return this.post<NiveauScolaire>(API_ENDPOINTS.NIVEAU_SCOLAIRE + '/create', request);
  }

  /**
   * Mettre à jour un niveau scolaire
   */
  async updateNiveauScolaire(niveau: NiveauScolaire): Promise<ApiResponse<NiveauScolaire>> {
    const request = this.buildUpdateRequest(niveau);
    return this.post<NiveauScolaire>(API_ENDPOINTS.NIVEAU_SCOLAIRE + '/update', request);
  }

  /**
   * Supprimer un niveau scolaire
   */
  async deleteNiveauScolaire(id: number): Promise<ApiResponse<NiveauScolaire>> {
    const request = this.buildApiRequest({ id });
    return this.post<NiveauScolaire>(API_ENDPOINTS.NIVEAU_SCOLAIRE + '/delete', request);
  }

  /**
   * Récupérer les niveaux scolaires par critères
   */
  async getNiveauxScolairesByCriteria(
    filters?: NiveauScolaireFilters,
    pagination?: { index: number; size: number }
  ): Promise<ApiResponse<NiveauScolaire>> {
    const request = this.buildApiRequest(undefined, filters, pagination);
    return this.post<NiveauScolaire>(API_ENDPOINTS.NIVEAU_SCOLAIRE + '/getByCriteria', request);
  }

  /**
   * Récupérer tous les niveaux scolaires actifs
   */
  async getAllNiveauxScolaires(): Promise<ApiResponse<NiveauScolaire>> {
    const filters: NiveauScolaireFilters = {
      isActive: true,
      isDeleted: false,
    };
    return this.getNiveauxScolairesByCriteria(filters);
  }

  // ==================== STRUCTURE ADMINISTRATIVE ====================
  
  /**
   * Créer une nouvelle structure administrative
   */
  async createStructureAdministrative(structure: StructureAdministrative): Promise<ApiResponse<StructureAdministrative>> {
    const request = this.buildCreateRequest(structure);
    return this.post<StructureAdministrative>(API_ENDPOINTS.STRUCTURE_ADMINISTRATIVE + '/create', request);
  }

  /**
   * Mettre à jour une structure administrative
   */
  async updateStructureAdministrative(structure: StructureAdministrative): Promise<ApiResponse<StructureAdministrative>> {
    const request = this.buildUpdateRequest(structure);
    return this.post<StructureAdministrative>(API_ENDPOINTS.STRUCTURE_ADMINISTRATIVE + '/update', request);
  }

  /**
   * Supprimer une structure administrative
   */
  async deleteStructureAdministrative(id: number): Promise<ApiResponse<StructureAdministrative>> {
    const request = this.buildApiRequest({ id });
    return this.post<StructureAdministrative>(API_ENDPOINTS.STRUCTURE_ADMINISTRATIVE + '/delete', request);
  }

  /**
   * Récupérer les structures administratives par critères
   */
  async getStructuresAdministrativesByCriteria(
    filters?: StructureAdministrativeFilters,
    pagination?: { index: number; size: number }
  ): Promise<ApiResponse<StructureAdministrative>> {
    const request = this.buildApiRequest(undefined, filters, pagination);
    return this.post<StructureAdministrative>(API_ENDPOINTS.STRUCTURE_ADMINISTRATIVE + '/getByCriteria', request);
  }

  /**
   * Récupérer toutes les structures administratives actives
   */
  async getAllStructuresAdministratives(): Promise<ApiResponse<StructureAdministrative>> {
    const filters: StructureAdministrativeFilters = {
      isActive: true,
      isDeleted: false,
    };
    return this.getStructuresAdministrativesByCriteria(filters);
  }

  /**
   * Récupérer les structures par type
   */
  async getStructuresByType(type: string): Promise<ApiResponse<StructureAdministrative>> {
    const filters: StructureAdministrativeFilters = {
      type: type,
      isActive: true,
      isDeleted: false,
    };
    return this.getStructuresAdministrativesByCriteria(filters);
  }

  /**
   * Une structure par id (table unique structure_administrative : DRENA, IEPP, EPP, etc.)
   */
  async getStructureAdministrativeById(id: number): Promise<ApiResponse<StructureAdministrative>> {
    const userId = this.getCurrentUserId();
    const token = this.getAuthToken();
    if (!userId || !token) {
      throw new Error("Utilisateur non connecté");
    }
    const request = {
      user: userId,
      token,
      isSimpleLoading: false,
      data: { id, isdeleted: false },
      index: 0,
      size: 1,
    };
    return this.post<StructureAdministrative>(
      API_ENDPOINTS.STRUCTURE_ADMINISTRATIVE + "/getByCriteria",
      request
    );
  }
}