/**
 * Types TypeScript pour les entités du système DISMAS
 * Alignés avec les DTOs backend et l'exemple de réponse fourni
 */

// Entité de base (selon l'architecture backend)
// Note: createdAt, updatedAt, isDeleted sont gérés automatiquement côté backend
export interface BaseEntity {
  id?: number;
  isActive?: boolean;
}

// Utilisateur (selon l'exemple de réponse OTP fourni)
export interface User extends BaseEntity {
  // Informations personnelles
  firstName: string;
  lastName: string;
  email: string;
  login: string;
  password?: string; // Masqué dans les réponses API
  fonction: string;
  
  // Rôle et permissions
  roleId: number;
  roleCode: string;
  
  // Structures administratives (selon le contexte)
  structureId?: number;
  structureCode?: string;
  structureLibelle?: string;
  structureType?: string;
  userType?: string; // DRENA, IEPP, EPP, ADMIN, DAF
  
  // Champs hiérarchiques conservés pour l'affichage (via la structure)
  drenaId?: number;
  drenaCode?: string;
  drenaLibelle?: string;
  ieppId?: number;
  ieppCode?: string;
  ieppLibelle?: string;
  eppId?: number;
  eppCode?: string;
  eppLibelle?: string;
  
  // Statut et sécurité
  isLdapUser: boolean;
  isLocked: boolean;
  loginAttempts: number;
  isDefaultPassword?: boolean;
  isFirstConnection?: boolean;
  
  // Authentification OTP
  otpCode?: string;
  token?: string;
  tokenCreatedAt?: string;
  tokenExpireAt?: string;
  dateSendCodeOtpAt?: string;
  
  // Champs gérés automatiquement par le backend (readonly)
  createdAt?: string;
  updatedAt?: string;
  isDeleted?: boolean;

  /** Droits effectifs {@code CODE:TYPE} (ex. USER:READ), renseignés après login si le backend les expose */
  functionalityPermissions?: string[];
}

// Rôle utilisateur
export interface Role extends BaseEntity {
  code: string;
  libelle: string;
  name?: string; // Alias pour libelle (compatibilité)
  description?: string;
  niveau_hierarchique?: number;
  niveauAcces?: number; // Champ backend
  isActive?: boolean;
  // Champs gérés automatiquement par le backend (readonly)
  createdAt?: string;
  updatedAt?: string;
  isDeleted?: boolean;
}

// Interface pour la création/modification de rôle (champs frontend uniquement)
export interface CreateRoleRequest {
  code: string;
  libelle: string;
  description?: string;
  niveauAcces?: number;
  isActive?: boolean;
}

// Filtres pour les rôles
export interface RoleFilters {
  code?: string;
  libelle?: string;
  description?: string;
  niveauAcces?: number;
  isActive?: boolean;
  isDeleted?: boolean;
}

// Catalogue
export interface Catalogue extends BaseEntity {
  code: string;
  libelle: string;
  niveauScolaireId: number;
  anneeScolaireId: number;
  active?: boolean; // Indique si le catalogue est actif
  // Relations
  anneeScolaire?: AnneeScolaire;
  matieres?: CatalogueMatiere[];
  // Informations enrichies depuis le backend
  anneeScolaireCode?: string;
  anneeScolaireLibelle?: string;
  niveauScolaireCode?: string;
  niveauScolaireLibelle?: string;
  nombreMatieres?: number;
  codesMatieresAssociees?: string; // Codes des matières séparés par des virgules
  // Champs gérés automatiquement par le backend (readonly)
  createdAt?: string;
  updatedAt?: string;
  isDeleted?: boolean;
}

// CatalogueMatiere (liaison Catalogue-Matière)
export interface CatalogueMatiere extends BaseEntity {
  catalogueId: number;
  matiereId: number;
  // Relations
  catalogue?: Catalogue;
  matiere?: Matiere;
  // Champs gérés automatiquement par le backend (readonly)
  createdAt?: string;
  updatedAt?: string;
  isDeleted?: boolean;
}

// Année Scolaire
export interface AnneeScolaire extends BaseEntity {
  code: string;
  libelle: string;
  dateDebut: string;
  dateFin: string;
  estCourante?: boolean;
  // Champs gérés automatiquement par le backend (readonly)
  createdAt?: string;
  updatedAt?: string;
  isDeleted?: boolean;
}

// Interface pour la création/modification de catalogue (champs frontend uniquement)
export interface CreateCatalogueRequest {
  code: string;
  libelle: string;
  niveauScolaireId: number;
  anneeScolaireId: number;
  active?: boolean; // Indique si le catalogue est actif
  matiereIds?: number[]; // Matières à associer
}

// Interface pour la création/modification d'année scolaire (champs frontend uniquement)
export interface CreateAnneeScolaireRequest {
  code: string;
  libelle: string;
  dateDebut: string;
  dateFin: string;
  estCourante?: boolean;
}

// Interface pour la liaison catalogue-matière
export interface CreateCatalogueMatiereRequest {
  catalogueId: number;
  matiereId: number;
  idNiveauScolaire?: number;
}

// Filtres pour les catalogues
export interface CatalogueFilters {
  code?: string;
  libelle?: string;
  niveauScolaireId?: number;
  anneeScolaireId?: number;
  active?: boolean;
  isDeleted?: boolean;
}

// Filtres pour les années scolaires
export interface AnneeScolaireFilters {
  code?: string;
  libelle?: string;
  estCourante?: boolean;
  isDeleted?: boolean;
}

// Fonctionnalité
export interface Functionality extends BaseEntity {
  code: string;
  name: string;
  description?: string;
  module: string;
  // Champs gérés automatiquement par le backend (readonly)
  createdAt?: string;
  updatedAt?: string;
  isDeleted?: boolean;
}

// Liaison Rôle-Fonctionnalité
export interface RoleFunctionality extends BaseEntity {
  roleId: number;
  functionalityId: number;
  // Champs gérés automatiquement par le backend (readonly)
  createdAt?: string;
  updatedAt?: string;
  isDeleted?: boolean;
}

// Données de connexion (selon le format backend réel)
export interface LoginRequest {
  login: string;
  password: string;
  isLdapUser?: boolean;
}

// Interface pour la création d'utilisateur (correspond aux champs backend)
export interface CreateUserRequest {
  // Informations personnelles
  firstName: string;
  lastName: string;
  email: string;
  login: string;
  telephone?: string;
  bornOn?: string;
  
  // Rôle et type d'utilisateur
  roleId: number;
  roleCode: string; // Code du rôle (ADMIN, DAF, DRENA, IEPP, DIRECTEUR)
  userType: string; // DRENA, IEPP, EPP, ADMIN, DAF
  
  // Structure administrative
  structureId?: number;
  
  // Structures hiérarchiques (selon le userType) - conservées pour compatibilité
  drenaId?: number;
  drenaCode?: string;
  ieppId?: number;
  ieppCode?: string;
  eppId?: number;
  eppCode?: string;
  
  // Statut
  isLdapUser?: boolean;
  isActive?: boolean;
}

// Session utilisateur (pour la gestion d'état frontend)
export interface UserSession {
  user: User;
  token: string;
  tokenExpireAt: string;
  isAuthenticated: boolean;
}

// Filtres pour les utilisateurs
export interface UserFilters {
  firstName?: string;
  lastName?: string;
  email?: string;
  login?: string;
  roleCode?: string;
  isActive?: boolean;
  isLocked?: boolean;
  isDeleted?: boolean;
  fonction?: string;
  /** Recherche OR sur login, prénom, nom, email (backend). */
  quickSearch?: string;
}

// Types pour les paramétrages
export interface TypeOuvrage extends BaseEntity {
  code: string;
  libelle: string;
  description?: string;
  // Champs gérés automatiquement par le backend (readonly)
  createdAt?: string;
  updatedAt?: string;
  isDeleted?: boolean;
}

export interface Matiere extends BaseEntity {
  code: string;
  libelle: string;
  description?: string;
  isActif?: boolean;
  couleur?: string;
  // Champs gérés automatiquement par le backend (readonly)
  createdAt?: string;
  updatedAt?: string;
  isDeleted?: boolean;
}

// Interface pour la création/modification de matière (champs frontend uniquement)
export interface CreateMatiereRequest {
  code: string;
  libelle: string;
  description?: string;
  isActif?: boolean;
}

// Filtres pour les matières
export interface MatiereFilters {
  code?: string;
  libelle?: string;
  description?: string;
  isActif?: boolean;
  isDeleted?: boolean;
}

export interface NiveauScolaire extends BaseEntity {
  code: string;
  libelle: string;
  description?: string;
  ordre?: number;
  // Champs gérés automatiquement par le backend (readonly)
  createdAt?: string;
  updatedAt?: string;
  isDeleted?: boolean;
}

// Interface pour la création/modification de niveau scolaire (champs frontend uniquement)
export interface CreateNiveauScolaireRequest {
  code: string;
  libelle: string;
  ordre: number;
}

// Filtres pour les niveaux scolaires
export interface NiveauScolaireFilters {
  code?: string;
  libelle?: string;
  ordre?: number;
  isDeleted?: boolean;
}

export interface StructureAdministrative extends BaseEntity {
  code: string;
  libelle: string;
  type: string;
  description?: string;
  parentId?: number;
  // Champs gérés automatiquement par le backend (readonly)
  createdAt?: string;
  updatedAt?: string;
  isDeleted?: boolean;
}

// Types pour les autres entités (à compléter selon les besoins)
export interface Stock extends BaseEntity {
  // Propriétés du stock à définir selon le backend
  titre?: string;
  niveau?: string;
  quantite?: number;
  distribues?: number;
  // Champs gérés automatiquement par le backend (readonly)
  createdAt?: string;
  updatedAt?: string;
  isDeleted?: boolean;
}

export interface Commande extends BaseEntity {
  // Propriétés de la commande à définir selon le backend
  // Champs gérés automatiquement par le backend (readonly)
  createdAt?: string;
  updatedAt?: string;
  isDeleted?: boolean;
}

export interface Distribution extends BaseEntity {
  // Propriétés de la distribution à définir selon le backend
  // Champs gérés automatiquement par le backend (readonly)
  createdAt?: string;
  updatedAt?: string;
  isDeleted?: boolean;
}

// Types pour la compatibilité avec l'existant (éviter la régression)
export interface LegacyUser {
  id: number;
  nom: string;
  prenoms: string;
  email: string;
  login: string;
  role: {
    id: number;
    code: string;
    libelle: string;
    niveau_hierarchique: number;
  };
  /**
   * PK `structure_administrative` de rattachement (session API).
   * `structure.id` peut être un id métier (ex. table `drena`) pour l’affichage — ne pas l’utiliser seul pour les filtres `drenaId` côté régulation.
   */
  structureAdministrativeId?: number;
  structure?: {
    id: number;
    code: string;
    libelle: string;
    type: string;
  };
  drena?: {
    id: number;
    code: string;
    libelle: string;
  };
  iepp?: {
    id: number;
    code: string;
    libelle: string;
  };
  epp?: {
    id: number;
    code: string;
    libelle: string;
  };

  /** Aligné sur User.functionalityPermissions (session) */
  functionalityPermissions?: string[];
}

// Fonction de conversion pour éviter la régression
export function convertLegacyUserToUser(legacyUser: LegacyUser): User {
  return {
    id: legacyUser.id,
    firstName: legacyUser.prenoms,
    lastName: legacyUser.nom,
    email: legacyUser.email,
    login: legacyUser.login,
    fonction: legacyUser.structure?.libelle || '',
    roleId: legacyUser.role.id,
    roleCode: legacyUser.role.code,
    // Structures administratives
    structureId: legacyUser.structureAdministrativeId ?? legacyUser.structure?.id,
    userType: getUserTypeFromRole(legacyUser.role.code),
    drenaId: legacyUser.drena?.id,
    drenaCode: legacyUser.drena?.code,
    ieppId: legacyUser.iepp?.id,
    ieppCode: legacyUser.iepp?.code,
    eppId: legacyUser.epp?.id,
    eppCode: legacyUser.epp?.code,
    // Statut par défaut
    isLdapUser: false,
    isLocked: false,
    loginAttempts: 0,
    isActive: true,
    isDeleted: false,
    functionalityPermissions: legacyUser.functionalityPermissions,
  };
}

/**
 * Structure « principale » pour l’UI (header, sidebar) : priorité au niveau le plus bas pertinent.
 * Pour un directeur d’EPP, afficher le nom d’établissement (eppLibelle), pas la chaîne hiérarchique IEPP.
 */
function buildLegacyMainStructure(user: User): NonNullable<LegacyUser["structure"]> {
  const sid = user.structureId ?? 1;

  if (user.eppId) {
    const libelle =
      user.eppLibelle?.trim() ||
      user.structureLibelle?.trim() ||
      (user.eppCode ? `EPP ${user.eppCode}` : "");
    const code = user.eppCode?.trim() || user.structureCode?.trim() || "";
    return {
      id: user.structureId ?? user.eppId,
      code: code || "EPP",
      libelle: libelle || "Établissement",
      type: user.structureType || "EPP",
    };
  }

  if (user.ieppId) {
    const libelle =
      user.ieppLibelle?.trim() ||
      user.structureLibelle?.trim() ||
      (user.ieppCode ? `IEPP ${user.ieppCode}` : "");
    const code = user.ieppCode?.trim() || user.structureCode?.trim() || "";
    return {
      id: user.structureId ?? user.ieppId,
      code: code || "IEPP",
      libelle: libelle || "IEPP",
      type: user.structureType || "IEPP",
    };
  }

  if (user.drenaId) {
    const libelle =
      user.drenaLibelle?.trim() ||
      user.structureLibelle?.trim() ||
      (user.drenaCode ? `DRENA ${user.drenaCode}` : "");
    const code = user.drenaCode?.trim() || user.structureCode?.trim() || "";
    return {
      /** Toujours préférer l'id DRENA métier (jointures regulation / iepp par drenaId), pas structureId qui peut être un autre nœud admin. */
      id: user.drenaId ?? user.structureId,
      code: code || "DRENA",
      libelle: libelle || "DRENA",
      type: user.structureType || "DRENA",
    };
  }

  if (user.structureLibelle?.trim() || user.structureCode?.trim()) {
    return {
      id: sid,
      code: user.structureCode?.trim() || "MENAET",
      libelle: user.structureLibelle?.trim() || "Ministère de l'Éducation Nationale",
      type: user.structureType || "MENA",
    };
  }

  return {
    id: sid,
    code: "MENAET",
    libelle: "Ministère de l'Éducation Nationale",
    type: "MENA",
  };
}

// Fonction de conversion inverse (API -> Legacy)
export function convertUserToLegacyUser(user: User): LegacyUser {
  // Déterminer le code du rôle basé sur l'ID si roleCode n'est pas fourni
  const roleCode = user.roleCode || getRoleCodeById(user.roleId || 0);
  const structureAdministrativeId =
    typeof user.structureId === "number" && user.structureId > 0 ? user.structureId : undefined;

  return {
    id: user.id || 0,
    nom: user.lastName,
    prenoms: user.firstName,
    email: user.email,
    login: user.login,
    role: {
      id: user.roleId || 0,
      code: roleCode,
      libelle: user.fonction || '',
      niveau_hierarchique: getRoleHierarchyLevel(roleCode),
    },
    structureAdministrativeId,
    structure: buildLegacyMainStructure(user),
    drena: user.drenaId ? {
      id: user.drenaId,
      code: user.drenaCode || '',
      libelle: user.drenaLibelle?.trim() || `DRENA ${user.drenaCode || ''}`
    } : undefined,
    iepp: user.ieppId ? {
      id: user.ieppId,
      code: user.ieppCode || '',
      libelle: user.ieppLibelle?.trim() || `IEPP ${user.ieppCode || ''}`
    } : undefined,
    epp: user.eppId ? {
      id: user.eppId,
      code: user.eppCode || '',
      libelle: user.eppLibelle?.trim() || `EPP ${user.eppCode || ''}`
    } : undefined,
    functionalityPermissions: user.functionalityPermissions,
  };
}

// Fonction pour obtenir le code du rôle basé sur l'ID
function getRoleCodeById(roleId: number): string {
  switch (roleId) {
    case 1: return 'ADMIN';
    case 2: return 'DAF';
    case 3: return 'DRENA';
    case 4: return 'IEPP';
    case 5: return 'DIRECTEUR';
    default: return 'USER';
  }
}

// Fonction pour obtenir le type d'utilisateur basé sur le rôle (aligné UserBusiness / structure)
export function getUserTypeFromRole(roleCode: string): string {
  switch (roleCode.toUpperCase()) {
    case 'ADMIN':
      return 'ADMIN';
    case 'DAF':
      return 'DAF';
    case 'DRENA':
      return 'DRENA';
    case 'IEPP':
      return 'IEPP';
    /** Conseiller pédagogique de secteur : même rattachement territorial qu’un inspecteur (DRENA + IEPP) */
    case 'CPS':
      return 'IEPP';
    /** CPPP : inspection (DRENA + IEPP), pas rattachement à une EPP unique */
    case 'CPPP':
      return 'IEPP';
    case 'INTENDANT':
    case 'INTENDENT':
      return 'IEPP';
    case 'DIRECTEUR':
    case 'INFORMATICIEN':
    case 'COGES':
    case 'MAITRE':
      return 'EPP';
    default:
      return 'USER';
  }
}

// Fonction pour obtenir le niveau hiérarchique selon le rôle
function getRoleHierarchyLevel(roleCode: string): number {
  switch (roleCode.toUpperCase()) {
    case 'ADMIN': return 10;
    case 'DAF': return 9;
    case 'DRENA': return 8;
    case 'IEPP': return 7;
    /** Sous le pilotage IEPP (aligné sur niveau_acces métier ~68 côté base). */
    case 'CPPP': return 6;
    case 'CPS':
    case 'INTENDANT':
    case 'INTENDENT':
      return 6;
    case 'DIRECTEUR': return 5;
    case 'INFORMATICIEN':
      return 4;
    case 'COGES':
    case 'MAITRE':
      return 3;
    default: return 1;
  }
}

// Fonction utilitaire pour convertir une date du format HTML (YYYY-MM-DD) vers le format backend (dd/MM/yyyy 00:00:00)
function convertDateToBackendFormat(dateString?: string): string | undefined {
  if (!dateString || dateString.trim() === '') {
    return undefined;
  }
  
  try {
    // Parse la date au format ISO (YYYY-MM-DD)
    const date = new Date(dateString);
    
    // Vérifier que la date est valide
    if (isNaN(date.getTime())) {
      console.warn(`Date invalide: ${dateString}`);
      return undefined;
    }
    
    // Convertir au format dd/MM/yyyy 00:00:00
    const day = date.getDate().toString().padStart(2, '0');
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    const year = date.getFullYear();
    
    return `${day}/${month}/${year} 00:00:00`;
  } catch (error) {
    console.error(`Erreur lors de la conversion de la date ${dateString}:`, error);
    return undefined;
  }
}

// Fonction utilitaire pour valider et construire la requête de création d'utilisateur
export function buildCreateUserRequest(
  userData: Partial<CreateUserRequest>,
  context: {
    roleCode: string;
    /** Si connu (liste des rôles chargée), préférer l’id réel plutôt que le fallback par code */
    roleId?: number;
    drenaId?: number;
    drenaCode?: string;
    ieppId?: number;
    ieppCode?: string;
    eppId?: number;
    eppCode?: string;
  }
): CreateUserRequest {
  const userType = getUserTypeFromRole(context.roleCode);

  const resolvedRoleId = context.roleId ?? getRoleIdByCode(context.roleCode);
  
  // Champs obligatoires côté frontend
  const requiredFields = ['firstName', 'lastName', 'login'];
  for (const field of requiredFields) {
    if (!userData[field as keyof CreateUserRequest]) {
      throw new Error(`Le champ ${field} est obligatoire`);
    }
  }
  const loginTrimmed = String(userData.login).trim();
  if (loginTrimmed.length < 6) {
    throw new Error('Le matricule doit comporter au moins 6 caractères');
  }
  
  // Construire la requête selon le type d'utilisateur
  const request: CreateUserRequest = {
    firstName: userData.firstName!,
    lastName: userData.lastName!,
    email: userData.email || '',
    login: loginTrimmed,
    telephone: userData.telephone,
    bornOn: convertDateToBackendFormat(userData.bornOn),
    roleId: resolvedRoleId,
    roleCode: context.roleCode, // Ajouter le code du rôle
    userType,
    isLdapUser: false,
    isActive: userData.isActive !== false,
  };
  
  // Ajouter les structures selon le type d'utilisateur
  switch (userType) {
    case 'DRENA':
      if (!context.drenaId || !context.drenaCode) {
        throw new Error('DRENA ID et Code sont obligatoires pour un utilisateur DRENA');
      }
      request.drenaId = context.drenaId;
      request.drenaCode = context.drenaCode;
      break;
      
    case 'IEPP':
      if (!context.drenaId || !context.drenaCode || !context.ieppId || !context.ieppCode) {
        throw new Error('DRENA et IEPP ID/Code sont obligatoires pour un utilisateur IEPP');
      }
      request.drenaId = context.drenaId;
      request.drenaCode = context.drenaCode;
      request.ieppId = context.ieppId;
      request.ieppCode = context.ieppCode;
      break;
      
    case 'EPP':
      if (!context.drenaId || !context.drenaCode || !context.ieppId || !context.ieppCode || !context.eppId || !context.eppCode) {
        throw new Error('DRENA, IEPP et EPP ID/Code sont obligatoires pour un utilisateur EPP');
      }
      request.drenaId = context.drenaId;
      request.drenaCode = context.drenaCode;
      request.ieppId = context.ieppId;
      request.ieppCode = context.ieppCode;
      request.eppId = context.eppId;
      request.eppCode = context.eppCode;
      break;
      
    case 'ADMIN':
    case 'DAF':
      // Pas de structures spécifiques requises
      break;
  }
  
  return request;
}

// Fonction pour obtenir l'ID du rôle basé sur le code
function getRoleIdByCode(roleCode: string): number {
  switch (roleCode.toUpperCase()) {
    case 'ADMIN': return 1;
    case 'DAF': return 2;
    case 'DRENA': return 3;
    case 'IEPP': return 4;
    case 'DIRECTEUR': return 5;
    default: return 1;
  }
}

// Interface CatalogueMatiere
export interface CatalogueMatiere extends BaseEntity {
  catalogueId: number;
  matiereId: number;
  // Informations enrichies depuis le backend
  catalogueCode?: string;
  catalogueLibelle?: string;
  matiereCode?: string;
  matiereLibelle?: string;
  anneeScolaireLibelle?: string;
  niveauScolaireLibelle?: string;
  // Relations
  catalogue?: Catalogue;
  matiere?: Matiere;
  // Champs gérés automatiquement par le backend (readonly)
  createdAt?: string;
  updatedAt?: string;
  isDeleted?: boolean;
}

// Interface pour la création/modification de catalogue-matière (champs frontend uniquement)
export interface CreateCatalogueMatiereRequest {
  catalogueId: number;
  matiereId: number;
  idNiveauScolaire?: number;
}

// Filtres pour les associations catalogue-matière
export interface CatalogueMatiereFilters {
  catalogueId?: number;
  matiereId?: number;
  catalogueCode?: string;
  matiereCode?: string;
  isDeleted?: boolean;
}