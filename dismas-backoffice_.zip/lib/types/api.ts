/**
 * Types TypeScript pour l'intégration avec l'API backend Spring Boot
 * Respecte exactement la structure des réponses définie dans le prompt
 */

// Structure des réponses API du backend (selon l'exemple fourni)
/** `T` = type d’un élément de `items` (pas `T[]` : sinon `items` serait typé `T[][]`). */
export interface ApiResponse<T = any> {
  hasError: boolean;
  status: {
    code: string;
    message: string;
  };
  items: T[];
  actionEffectue: string;
  /** Total côté serveur (listes paginées), si l’API l’expose — ex. journal d’audit */
  count?: number;
}

// Structure des requêtes API (selon l'architecture backend)
export interface ApiRequest<T = any> {
  user?: number;
  token?: string;
  isSimpleLoading?: boolean;
  datas?: T[];
  searchParam?: Record<string, { value: any; operator: SearchOperator }>;
  pagination?: {
    index: number;
    size: number;
  };
}

// Structure spécifique pour le login (format backend réel)
export interface LoginApiRequest {
  user: string;
  data: {
    login: string;
    password: string;
    isLdapUser: boolean;
  };
}

// Opérateurs de recherche (selon l'architecture backend)
export type SearchOperator = 
  | 'EQ'         // Égal
  | 'LIKE'       // Contient
  | 'GT'         // Supérieur à
  | 'LT'         // Inférieur à
  | 'GTE'        // Supérieur ou égal
  | 'LTE'        // Inférieur ou égal
  | 'IN'         // Dans la liste
  | 'NOT'        // Différent
  | 'IS_NULL'    // Est null
  | 'IS_NOT_NULL'; // N'est pas null

// Paramètres de pagination
export interface PaginationParams {
  index: number;
  size: number;
}

// Filtres de recherche génériques
export interface SearchParams {
  [key: string]: {
    value: any;
    operator: SearchOperator;
  };
}

// Erreur API personnalisée
export interface ApiError {
  code: string;
  message: string;
  details?: any;
  /** Refus RBAC (ex. code 900 : permission manquante sur une fonctionnalité) */
  isPermissionDenied?: boolean;
}

// Configuration des requêtes HTTP
export interface RequestConfig {
  timeout?: number;
  headers?: Record<string, string>;
  signal?: AbortSignal;
}

// Types pour les actions API
export type ApiAction = 
  | 'CREATE_USERS'
  | 'UPDATE_USERS'
  | 'DELETE_USERS'
  | 'Connexion utilisateur via code otp'
  | string; // Autres actions spécifiques