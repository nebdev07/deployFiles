/**
 * Quantités besoin → réception : sépare demande (consolidée / net / brut) et approuvée DAF.
 * Utilisé pour le flux IEPP (consolidation multi-EPP) et testable isolément.
 */

export function besoinDetailQuantiteDemandee(d: {
  quantiteConsolidee?: number | null
  quantiteNet?: number | null
  quantiteBrute?: number | null
}): number {
  const c = d.quantiteConsolidee ?? d.quantiteNet ?? d.quantiteBrute
  return typeof c === "number" && !Number.isNaN(c) ? c : 0
}

export type AggregatedNiveauMatiereQuantites = {
  matiereId: number
  matiereLibelle: string
  matiereCode: string
  niveauId: number
  niveauLibelle: string
  niveauCode: string
  quantiteDemandee: number
  quantiteApprouvee: number
}

/**
 * Agrège les BesoinDetail des besoins EPP par (niveau, matière) pour l’écran réception IEPP.
 * - Demandée : somme des quantités nettes/consolidées (ex. 100+100 = 200)
 * - Approuvée : somme des quantiteApprouvee DAF (ex. 80+80 = 160)
 */
export function aggregateConsolidationEppByNiveauMatiere(
  /** Réponse API `getConsolidationDetails` : liste de besoins EPP avec `besoinDetails`. */
  besoinsEpp: readonly unknown[] | null | undefined
): Map<string, AggregatedNiveauMatiereQuantites> {
  const aggregated = new Map<string, AggregatedNiveauMatiereQuantites>()
  for (const b of besoinsEpp ?? []) {
    if (!b || typeof b !== "object") continue
    const box = b as { besoinDetails?: ReadonlyArray<unknown> | null }
    for (const raw of box.besoinDetails || []) {
      const d = raw as {
        niveauScolaireId?: number
        matiereId?: number
        matiereLibelle?: string
        matiereCode?: string
        niveauScolaireLibelle?: string
        niveauScolaireCode?: string
        quantiteConsolidee?: number
        quantiteNet?: number
        quantiteBrute?: number
        quantiteApprouvee?: number
      }
      const nivId = d.niveauScolaireId ?? 0
      const matId = d.matiereId ?? 0
      if (!nivId || !matId) continue
      const key = `${nivId}-${matId}`
      const qDem = besoinDetailQuantiteDemandee(d)
      const qApp =
        typeof d.quantiteApprouvee === "number" && !Number.isNaN(d.quantiteApprouvee)
          ? d.quantiteApprouvee
          : 0
      const prev = aggregated.get(key)
      if (prev) {
        prev.quantiteDemandee += qDem
        prev.quantiteApprouvee += qApp
      } else {
        aggregated.set(key, {
          matiereId: matId,
          matiereLibelle: d.matiereLibelle || "",
          matiereCode: d.matiereCode || "",
          niveauId: nivId,
          niveauLibelle: d.niveauScolaireLibelle || "",
          niveauCode: d.niveauScolaireCode || "",
          quantiteDemandee: qDem,
          quantiteApprouvee: qApp,
        })
      }
    }
  }
  return aggregated
}
