/**
 * Regroupement DRENA/DAF : une ligne IEPP = id structure IEPP ;
 * une ligne EPP doit être rattachée à idIEPPParent, pas à idStructure (EPP).
 */

export type TerritorialReceptionLike = {
  type: string
  idStructure?: number
  ieppId?: number
  idIEPPParent?: number
  ieppLibelle?: string
  structureLibelle?: string
}

const ORPHAN_IEPP_KEY = -1

/** Si une seule réception « Livreur → IEPP » existe, son id structure = seul IEPP connu (heuristique données incomplètes). */
export function inferSoleIeppIdFromIeppRows(rows: TerritorialReceptionLike[]): number | undefined {
  const ids = new Set<number>()
  for (const r of rows) {
    if (String(r.type).toUpperCase() !== "IEPP") continue
    const id = Number(r.ieppId ?? r.idStructure)
    if (id > 0 && !Number.isNaN(id)) ids.add(id)
  }
  if (ids.size !== 1) return undefined
  return [...ids][0]
}

/**
 * Clé de groupe IEPP : toujours l’identifiant administratif de l’IEPP, jamais l’id d’une EPP.
 */
export function resolveTerritorialIeppGroupKey(
  r: TerritorialReceptionLike,
  soleIeppId: number | undefined
): number {
  const t = String(r.type).toUpperCase()
  if (t === "IEPP") {
    const id = Number(r.ieppId ?? r.idStructure)
    if (id > 0 && !Number.isNaN(id)) return id
    return ORPHAN_IEPP_KEY
  }
  if (t === "EPP") {
    let parent = Number(r.ieppId ?? r.idIEPPParent)
    if ((!parent || Number.isNaN(parent)) && soleIeppId != null) {
      parent = soleIeppId
    }
    if (parent > 0 && !Number.isNaN(parent)) return parent
    return ORPHAN_IEPP_KEY
  }
  return ORPHAN_IEPP_KEY
}

export function pickTerritorialIeppLabel(ieppKey: number, receptions: TerritorialReceptionLike[]): string {
  if (ieppKey === ORPHAN_IEPP_KEY) {
    return "IEPP (parent non renseigné — à contrôler côté données)"
  }
  const fromCentral = receptions.find((x) => String(x.type).toUpperCase() === "IEPP" && x.structureLibelle)
  if (fromCentral?.structureLibelle) {
    return String(fromCentral.structureLibelle)
  }
  const labels = receptions.map((x) => x.ieppLibelle).filter(Boolean) as string[]
  const decent = labels.find((l) => !/inconnu/i.test(l))
  return decent || labels[0] || `IEPP #${ieppKey}`
}

export function sortTerritorialIeppKeys(keys: number[]): number[] {
  return [...keys].sort((a, b) => {
    if (a === ORPHAN_IEPP_KEY && b !== ORPHAN_IEPP_KEY) return 1
    if (b === ORPHAN_IEPP_KEY && a !== ORPHAN_IEPP_KEY) return -1
    return a - b
  })
}
