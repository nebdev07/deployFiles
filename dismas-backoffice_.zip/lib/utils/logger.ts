/**
 * Logger utility for consistent logging across the application
 * ⚠️ LOGS ARE DISABLED IN PRODUCTION FOR SECURITY AND PERFORMANCE
 * 
 * Usage:
 * - Development: All logs are displayed
 * - Production: Only critical errors are logged (to external service if configured)
 */

type LogLevel = 'log' | 'info' | 'warn' | 'error' | 'debug';

interface LoggerConfig {
  enabled: boolean;
  isDevelopment: boolean;
  isProduction: boolean;
  allowProductionErrors: boolean; // Allow errors in production for monitoring
}

class Logger {
  private config: LoggerConfig;

  constructor() {
    const nodeEnv = process.env.NODE_ENV || 'development';
    const nextPublicEnv = process.env.NEXT_PUBLIC_ENVIRONMENT;
    
    this.config = {
      enabled: true,
      isDevelopment: nodeEnv === 'development',
      isProduction: nodeEnv === 'production' || nextPublicEnv === 'production',
      allowProductionErrors: true, // Keep critical errors for monitoring
    };
  }

  /**
   * Log informational messages (disabled in production)
   */
  log(...args: any[]): void {
    if (this.shouldLog('log')) {
      console.log(...args);
    }
  }

  /**
   * Log info messages (disabled in production)
   */
  info(...args: any[]): void {
    if (this.shouldLog('info')) {
      console.info(...args);
    }
  }

  /**
   * Log debug messages (disabled in production)
   */
  debug(...args: any[]): void {
    if (this.shouldLog('debug')) {
      console.debug(...args);
    }
  }

  /**
   * Log warning messages (disabled in production)
   */
  warn(...args: any[]): void {
    if (this.shouldLog('warn')) {
      console.warn(...args);
    }
  }

  /**
   * Log error messages
   * In production, only critical errors are logged (can be sent to monitoring service)
   */
  error(...args: any[]): void {
    if (this.shouldLog('error')) {
      console.error(...args);
      
      // In production, you can send critical errors to a monitoring service
      if (this.config.isProduction && typeof window !== 'undefined') {
        // Example: Send to Sentry, LogRocket, or custom endpoint
        // this.sendToMonitoringService(args);
      }
    }
  }

  /**
   * Determine if logging should occur based on environment and log level
   */
  private shouldLog(level: LogLevel): boolean {
    if (!this.config.enabled) {
      return false;
    }

    // In production, only allow errors if configured
    if (this.config.isProduction) {
      return level === 'error' && this.config.allowProductionErrors;
    }

    // In development, allow all logs
    return this.config.isDevelopment;
  }

  /**
   * Enable or disable logging
   */
  setEnabled(enabled: boolean): void {
    this.config.enabled = enabled;
  }

  /**
   * Check if we're in development mode
   */
  isDevelopment(): boolean {
    return this.config.isDevelopment;
  }

  /**
   * Check if we're in production mode
   */
  isProduction(): boolean {
    return this.config.isProduction;
  }

  /**
   * Get current logger configuration (for debugging)
   */
  getConfig(): LoggerConfig {
    return { ...this.config };
  }

  /**
   * Optional: Send errors to monitoring service in production
   * Uncomment and configure when ready to use
   */
  // private sendToMonitoringService(error: any[]): void {
  //   try {
  //     // Example with fetch to custom endpoint
  //     fetch('/api/log-error', {
  //       method: 'POST',
  //       headers: { 'Content-Type': 'application/json' },
  //       body: JSON.stringify({
  //         error: error,
  //         timestamp: new Date().toISOString(),
  //         userAgent: navigator.userAgent,
  //         url: window.location.href,
  //       }),
  //     }).catch(() => {
  //       // Silently fail if monitoring service is down
  //     });
  //   } catch (e) {
  //     // Fail silently
  //   }
  // }
}

// Export a singleton instance
export const logger = new Logger();

// Override console methods in production to prevent accidental logging
if (typeof window !== 'undefined' && logger.isProduction()) {
  const noop = () => {};
  
  // Save original console for errors only
  const originalError = console.error;
  
  // Override all console methods except error
  console.log = noop;
  console.info = noop;
  console.debug = noop;
  console.warn = noop;
  
  // Keep error but could filter it through logger
  console.error = (...args: any[]) => {
    if (logger.getConfig().allowProductionErrors) {
      originalError(...args);
    }
  };
}

