/** Profils « consultation » : pas d’actions de saisie / validation / suppression métier. */
export const CONSULTATION_ONLY_ROLE_CODES = ["CABINET"] as const

export function isConsultationOnlyRole(roleCode: string | undefined | null): boolean {
  const c = (roleCode || "").toUpperCase()
  return (CONSULTATION_ONLY_ROLE_CODES as readonly string[]).includes(c)
}

/** Vrai si l’utilisateur peut déclencher des mutations métier (hors profil / déconnexion). */
export function canPerformBusinessMutations(roleCode: string | undefined | null): boolean {
  return !isConsultationOnlyRole(roleCode)
}
