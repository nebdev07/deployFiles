/**
 * Contrôle d’accès menu basé sur les clés {@code FONCTIONALITE:TYPE} renvoyées par le backend
 * (voir User.functionalityPermissions). Si la liste est absente ou vide, on conserve le filtrage par rôle.
 */

import { isEppBesoinExpressionRole, isIeppTerritoryMenuRole } from "@/lib/utils/role-codes"

export function hasFunctionalityPermission(
  permissions: string[] | undefined,
  fonctionaliteCode: string,
  permissionType:
    | "CREATE"
    | "READ"
    | "UPDATE"
    | "DELETE"
    | "EXPORT"
    | "APPROVE"
    | "VALIDATE"
    | "CONSOLIDATE",
): boolean {
  if (!permissions?.length) return false
  const key = `${fonctionaliteCode}:${permissionType}`
  return permissions.some((p) => p.toUpperCase() === key.toUpperCase())
}

/**
 * @param userRoleCode — code rôle courant (ex. DRENA)
 * @param rolesAllowed — liste autorisée par l’item de menu
 * @param functionalityPermissions — session (optionnel)
 * @param functionalityReadCode — code fonctionnalité pour un accès READ (ex. FONCTIONALITE)
 * @param functionalityReadCodesAnyOf — si renseigné, afficher si au moins un code a READ (prioritaire sur {@code functionalityReadCode})
 */
export function canShowMenuItem(
  userRoleCode: string | undefined,
  rolesAllowed: string[],
  functionalityPermissions: string[] | undefined,
  functionalityReadCode?: string,
  functionalityReadCodesAnyOf?: string[],
): boolean {
  const rc = (userRoleCode || "").toUpperCase()
  if (!functionalityPermissions?.length) {
    return rolesAllowed.includes(rc)
  }
  if (functionalityReadCodesAnyOf?.length) {
    return functionalityReadCodesAnyOf.some((code) =>
      hasFunctionalityPermission(functionalityPermissions, code, "READ"),
    )
  }
  if (functionalityReadCode) {
    return hasFunctionalityPermission(functionalityPermissions, functionalityReadCode, "READ")
  }
  return rolesAllowed.includes(rc)
}

/** Onglet « Saisie » / bouton « Nouveau besoin » : contrôle strict RBAC {@code BESOIN:CREATE}. */
export function canAccessBesoinSaisieCreate(
  roleCode: string | undefined,
  functionalityPermissions: string[] | undefined,
): boolean {
  void roleCode
  return hasFunctionalityPermission(functionalityPermissions, "BESOIN", "CREATE")
}

/**
 * Inclure {@code structureId} dans getByCriteria : périmètre structure utilisateur quand READ ou CREATE BESOIN,
 * ou rôles EPP historiques sans liste RBAC.
 */
export function shouldScopeBesoinListByUserStructure(
  roleCode: string | undefined,
  functionalityPermissions: string[] | undefined,
): boolean {
  if (hasFunctionalityPermission(functionalityPermissions, "BESOIN", "READ")) {
    return true
  }
  if (hasFunctionalityPermission(functionalityPermissions, "BESOIN", "CREATE")) {
    return true
  }
  if (!functionalityPermissions?.length) {
    return isEppBesoinExpressionRole(roleCode)
  }
  return false
}

/** Bouton « Modifier » sur besoin SAISI : {@code BESOIN:UPDATE}, ou rôles saisie EPP si pas de RBAC en session. */
export function canUpdateBesoinSaisieRow(
  roleCode: string | undefined,
  functionalityPermissions: string[] | undefined,
): boolean {
  if (hasFunctionalityPermission(functionalityPermissions, "BESOIN", "UPDATE")) {
    return true
  }
  if (!functionalityPermissions?.length) {
    return isEppBesoinExpressionRole(roleCode)
  }
  return false
}

// --- Garde-fous pages (même principe que le menu : READ sur la fonctionnalité si session RBAC non vide) ---

const DASHBOARD_PAGE_ROLES = [
  "ADMIN",
  "DAF",
  "DRENA",
  "IEPP",
  "CPPP",
  "CPS",
  "DIRECTEUR",
  "INTENDANT",
  "INTENDENT",
  "INFORMATICIEN",
  "MAITRE",
  "COGES",
  "DPFC",
  "CABINET",
] as const

/** Page `/dashboard` — alignée menu « Tableau de bord » (filtre par rôle uniquement). */
export function canAccessDashboardPage(
  userRoleCode: string | undefined,
  functionalityPermissions: string[] | undefined,
): boolean {
  void userRoleCode
  return hasFunctionalityPermission(functionalityPermissions, "DASHBOARD", "READ")
}

const ADMIN_MONITORING_PAGE_ROLES = ["ADMIN"] as const

/** Page `/admin` (Monitoring) — code dédié {@code MONITORING:READ} (ou legacy {@code ROLE:READ}). */
export function canAccessAdminMonitoringPage(
  userRoleCode: string | undefined,
  functionalityPermissions: string[] | undefined,
): boolean {
  void userRoleCode
  return hasFunctionalityPermission(functionalityPermissions, "MONITORING", "READ")
}

const DISTRIBUTION_PAGE_ROLES = [
  "ADMIN",
  "DAF",
  "DRENA",
  "IEPP",
  "CPPP",
  "CPS",
  "INTENDANT",
  "INTENDENT",
  "DIRECTEUR",
  "INFORMATICIEN",
  "MAITRE",
] as const

/** Page `/distribution` — {@code MANUEL_DISTRIBUTION:READ}. */
export function canAccessDistributionPage(
  userRoleCode: string | undefined,
  functionalityPermissions: string[] | undefined,
): boolean {
  return canShowMenuItem(userRoleCode, [...DISTRIBUTION_PAGE_ROLES], functionalityPermissions, "MANUEL_DISTRIBUTION")
}

const ENQUETES_PAGE_ROLES = [
  "ADMIN",
  "DAF",
  "DRENA",
  "IEPP",
  "CPPP",
  "CPS",
  "INTENDANT",
  "INTENDENT",
  "DIRECTEUR",
  "INFORMATICIEN",
  "COGES",
] as const

/** Page `/enquetes` — {@code ENQUETE_SATISFACTION:READ}. */
export function canAccessEnquetesPage(
  userRoleCode: string | undefined,
  functionalityPermissions: string[] | undefined,
): boolean {
  return canShowMenuItem(userRoleCode, [...ENQUETES_PAGE_ROLES], functionalityPermissions, "ENQUETE_SATISFACTION")
}

const PLAINTES_PAGE_ROLES = [
  "ADMIN",
  "DAF",
  "DRENA",
  "IEPP",
  "CPPP",
  "CPS",
  "INTENDANT",
  "INTENDENT",
  "DIRECTEUR",
  "INFORMATICIEN",
  "COGES",
] as const

/** Page `/plaintes` — {@code PLAINTE:READ}. */
export function canAccessPlaintesPage(
  userRoleCode: string | undefined,
  functionalityPermissions: string[] | undefined,
): boolean {
  return canShowMenuItem(userRoleCode, [...PLAINTES_PAGE_ROLES], functionalityPermissions, "PLAINTE")
}

const PLANIFICATION_REPARTITION_PAGE_ROLES = [
  "ADMIN",
  "DAF",
  "DRENA",
  "IEPP",
  "CPPP",
  "CPS",
  "INTENDANT",
  "INTENDENT",
  "DIRECTEUR",
  "INFORMATICIEN",
  "CABINET",
] as const

/** Page `/planification/repartition` — code dédié {@code TABLEAU_REPARTITION:READ} (ou legacy {@code STATISTIQUE_DISTRIBUTION:READ}). */
export function canAccessPlanificationRepartitionPage(
  userRoleCode: string | undefined,
  functionalityPermissions: string[] | undefined,
): boolean {
  void userRoleCode
  return hasFunctionalityPermission(functionalityPermissions, "TABLEAU_REPARTITION", "READ")
}

const RAPPORTS_PAGE_ROLES = [
  "ADMIN",
  "DAF",
  "DRENA",
  "IEPP",
  "CPPP",
  "CPS",
  "INTENDANT",
  "INTENDENT",
  "DIRECTEUR",
  "INFORMATICIEN",
  "CABINET",
] as const

/** Page `/rapports` — {@code RAPPORT:READ}. */
export function canAccessRapportsPage(
  userRoleCode: string | undefined,
  functionalityPermissions: string[] | undefined,
): boolean {
  return canShowMenuItem(userRoleCode, [...RAPPORTS_PAGE_ROLES], functionalityPermissions, "RAPPORT")
}

const REGULATION_PAGE_ROLES = [
  "ADMIN",
  "DAF",
  "DRENA",
  "IEPP",
  "CPPP",
  "CPS",
  "INTENDANT",
  "INTENDENT",
  "DIRECTEUR",
  "INFORMATICIEN",
  "MAITRE",
  "COGES",
] as const

/** Pages `/regulation` et `/regulation/inter-etablissements` — {@code REGULATION:READ}. */
export function canAccessRegulationPage(
  userRoleCode: string | undefined,
  functionalityPermissions: string[] | undefined,
): boolean {
  return canShowMenuItem(userRoleCode, [...REGULATION_PAGE_ROLES], functionalityPermissions, "REGULATION")
}

const RETOURS_PAGE_ROLES = [
  "ADMIN",
  "DAF",
  "DRENA",
  "IEPP",
  "CPPP",
  "CPS",
  "INTENDANT",
  "INTENDENT",
  "DIRECTEUR",
  "INFORMATICIEN",
  "MAITRE",
] as const

/** Page `/retours` — {@code RETOUR_MANUEL:READ}. */
export function canAccessRetoursPage(
  userRoleCode: string | undefined,
  functionalityPermissions: string[] | undefined,
): boolean {
  return canShowMenuItem(userRoleCode, [...RETOURS_PAGE_ROLES], functionalityPermissions, "RETOUR_MANUEL")
}

const STOCKS_PAGE_ROLES = [
  "ADMIN",
  "DAF",
  "DRENA",
  "IEPP",
  "CPPP",
  "CPS",
  "INTENDANT",
  "INTENDENT",
  "DIRECTEUR",
  "INFORMATICIEN",
  "CABINET",
] as const

/** Page `/stocks` — {@code MOUVEMENT:READ}. */
export function canAccessStocksPage(
  userRoleCode: string | undefined,
  functionalityPermissions: string[] | undefined,
): boolean {
  return canShowMenuItem(userRoleCode, [...STOCKS_PAGE_ROLES], functionalityPermissions, "MOUVEMENT")
}

const COMMANDES_PAGE_ROLES = ["ADMIN", "DAF"] as const

/** Page `/commandes` — alignée menu « Commande » ({@code COMMANDE_FOURNISSEUR:READ}). */
export function canAccessCommandesPage(
  userRoleCode: string | undefined,
  functionalityPermissions: string[] | undefined,
): boolean {
  return canShowMenuItem(
    userRoleCode,
    [...COMMANDES_PAGE_ROLES],
    functionalityPermissions,
    "COMMANDE_FOURNISSEUR",
  )
}

const LOGS_PAGE_ROLES = ["ADMIN", "DAF"] as const

/** Page `/logs` — alignée menu « Journal d'activité » ({@code JOURNAL_ACTIVITE:READ}). */
export function canAccessLogsPage(
  userRoleCode: string | undefined,
  functionalityPermissions: string[] | undefined,
): boolean {
  return canShowMenuItem(userRoleCode, [...LOGS_PAGE_ROLES], functionalityPermissions, "JOURNAL_ACTIVITE")
}

const USERS_MODULE_ROLES = [
  "ADMIN",
  "DAF",
  "DRENA",
  "IEPP",
  "CPPP",
  "CPS",
  "INTENDANT",
  "INTENDENT",
  "DIRECTEUR",
  "INFORMATICIEN",
] as const

/** Gestion utilisateurs (page intégrée) — alignée menu « Utilisateur » ({@code USER:READ}). */
export function canAccessUsersManagementPage(
  userRoleCode: string | undefined,
  functionalityPermissions: string[] | undefined,
): boolean {
  return canShowMenuItem(userRoleCode, [...USERS_MODULE_ROLES], functionalityPermissions, "USER")
}

const PARAMETRAGES_INTEGRATED_ROLES = ["ADMIN", "DAF", "DPFC"] as const

/** Accès paramétrages catalogue (page intégrée) — aligné menu « Paramètre » (au moins une lecture métier). */
export function canAccessParametragesIntegratedPage(
  userRoleCode: string | undefined,
  functionalityPermissions: string[] | undefined,
): boolean {
  return canShowMenuItem(
    userRoleCode,
    [...PARAMETRAGES_INTEGRATED_ROLES],
    functionalityPermissions,
    undefined,
    ["FONCTIONALITE", "VIEW_DRENA", "VIEW_IEPP", "VIEW_EPP", "DRENA", "IEPP", "EPP"],
  )
}

const SYNTHESE_CATALOGUE_FALLBACK_ROLES = [
  "ADMIN",
  "DAF",
  "DRENA",
  "IEPP",
  "CPPP",
  "CPS",
  "INTENDANT",
  "INTENDENT",
  "DIRECTEUR",
  "INFORMATICIEN",
  "CABINET",
] as const

/** Synthèse catalogue besoins — lecture agrégée : {@code BESOIN:READ} si RBAC ; sinon rôles élargis (menu Besoins). */
export function canAccessSyntheseCatalogueBesoinsPage(
  userRoleCode: string | undefined,
  functionalityPermissions: string[] | undefined,
): boolean {
  return canShowMenuItem(
    userRoleCode,
    [...SYNTHESE_CATALOGUE_FALLBACK_ROLES],
    functionalityPermissions,
    "BESOIN",
  )
}

const STOCKS_ENTREPOT_TAB_ROLES = ["ADMIN", "DAF"] as const
const STOCKS_IEPP_TAB_ROLES = [
  "IEPP",
  "DRENA",
  "DAF",
  "ADMIN",
  "CABINET",
  "CPPP",
  "CPS",
  "INTENDANT",
  "INTENDENT",
  "INFORMATICIEN",
] as const
const STOCKS_EPP_TAB_ROLES = [
  "DIRECTEUR",
  "IEPP",
  "DRENA",
  "DAF",
  "ADMIN",
  "CABINET",
  "CPPP",
  "CPS",
  "INTENDANT",
  "INTENDENT",
  "INFORMATICIEN",
] as const

export function canShowStocksEntrepotTab(
  userRoleCode: string | undefined,
  functionalityPermissions: string[] | undefined,
): boolean {
  const rc = (userRoleCode || "").toUpperCase()
  if (!functionalityPermissions?.length) {
    return (STOCKS_ENTREPOT_TAB_ROLES as readonly string[]).includes(rc)
  }
  return (
    (STOCKS_ENTREPOT_TAB_ROLES as readonly string[]).includes(rc) &&
    hasFunctionalityPermission(functionalityPermissions, "MOUVEMENT", "READ")
  )
}

export function canShowStocksIeppTab(
  userRoleCode: string | undefined,
  functionalityPermissions: string[] | undefined,
): boolean {
  return canShowMenuItem(userRoleCode, [...STOCKS_IEPP_TAB_ROLES], functionalityPermissions, "MOUVEMENT")
}

export function canShowStocksEppTab(
  userRoleCode: string | undefined,
  functionalityPermissions: string[] | undefined,
): boolean {
  return canShowMenuItem(userRoleCode, [...STOCKS_EPP_TAB_ROLES], functionalityPermissions, "MOUVEMENT")
}

const DISTRIBUTION_IEPP_VALIDATIONS_TAB_ROLES = ["IEPP", "CPPP", "CPS", "INTENDANT", "INTENDENT"] as const

/** Onglet validations IEPP (réceptions liées) — aligné menu Distribution ({@code MANUEL_DISTRIBUTION:READ}). */
export function canUseDistributionIeppValidationsTab(
  userRoleCode: string | undefined,
  functionalityPermissions: string[] | undefined,
): boolean {
  return canShowMenuItem(
    userRoleCode,
    [...DISTRIBUTION_IEPP_VALIDATIONS_TAB_ROLES],
    functionalityPermissions,
    "MANUEL_DISTRIBUTION",
  )
}

// --- Page Expression des besoins (`/besoins`) : complément au menu / flux métier ---

const BESOINS_SUIVI_PAR_IEPP_ROLES = ["DRENA", "DAF", "IEPP"] as const

/** Suivi agrégé « une ligne par IEPP » (DRENA / DAF / IEPP + territoire inspection si pas de RBAC). */
export function canUseBesoinsSuiviParIeppGrouping(
  userRoleCode: string | undefined,
  functionalityPermissions: string[] | undefined,
): boolean {
  const rc = (userRoleCode || "").toUpperCase()
  if (!functionalityPermissions?.length) {
    if ((BESOINS_SUIVI_PAR_IEPP_ROLES as readonly string[]).includes(rc)) return true
    return isIeppTerritoryMenuRole(userRoleCode)
  }
  if (!hasFunctionalityPermission(functionalityPermissions, "BESOIN", "READ")) return false
  return (
    (BESOINS_SUIVI_PAR_IEPP_ROLES as readonly string[]).includes(rc) || isIeppTerritoryMenuRole(userRoleCode)
  )
}

const DAF_CABINET_APPROVAL_ROLES = ["DAF", "CABINET", "ADMIN"] as const

/** Espace validation / approbation type DAF (groupes consolidés, modale approbation). */
export function canAccessBesoinsDafValidationWorkspace(
  userRoleCode: string | undefined,
  functionalityPermissions: string[] | undefined,
): boolean {
  if (!functionalityPermissions?.length) {
    const rc = (userRoleCode || "").toUpperCase()
    return (DAF_CABINET_APPROVAL_ROLES as readonly string[]).includes(rc)
  }
  return hasFunctionalityPermission(functionalityPermissions, "BESOIN", "APPROVE")
}

/** Liste validation groupée par IEPP (DAF / cabinet), avec {@code BESOIN:APPROVE} si RBAC. */
export function canUseBesoinsValidationGroupedByIeppList(
  userRoleCode: string | undefined,
  functionalityPermissions: string[] | undefined,
): boolean {
  const rc = (userRoleCode || "").toUpperCase()
  const roleOk = rc === "DAF" || rc === "CABINET"
  if (!functionalityPermissions?.length) return roleOk
  return roleOk && hasFunctionalityPermission(functionalityPermissions, "BESOIN", "APPROVE")
}

const IEPP_CONSOLIDATION_WORKSPACE_ROLES = [
  "IEPP",
  "ADMIN",
  "CABINET",
  "CPPP",
  "CPS",
  "INTENDANT",
  "INTENDENT",
] as const

/** Bloc consolidation côté IEPP (onglet dédié) — {@code BESOIN:READ} si liste RBAC en session. */
export function canAccessBesoinsIeppConsolidationWorkspace(
  userRoleCode: string | undefined,
  functionalityPermissions: string[] | undefined,
): boolean {
  return canShowMenuItem(
    userRoleCode,
    [...IEPP_CONSOLIDATION_WORKSPACE_ROLES],
    functionalityPermissions,
    "BESOIN",
  )
}

/** Panneau « expression manuelle » côté DAF — {@code BESOIN:CREATE} si RBAC. */
export function canAccessExpressionManuelleDafBesoinsPanel(
  userRoleCode: string | undefined,
  functionalityPermissions: string[] | undefined,
): boolean {
  const rc = (userRoleCode || "").toUpperCase()
  const roleOk = rc === "DAF" || rc === "ADMIN"
  if (!functionalityPermissions?.length) return roleOk
  return roleOk && hasFunctionalityPermission(functionalityPermissions, "BESOIN", "CREATE")
}

const BESOIN_RELOAD_CONSOL_AFTER_RENVOI_ROLES = [
  "IEPP",
  "ADMIN",
  "DRENA",
  "CPPP",
  "CPS",
  "INTENDANT",
  "INTENDENT",
] as const

/** Rechargement consolidations après renvoi : rôles métier / territoire inspection + {@code BESOIN:READ} si RBAC. */
export function shouldReloadConsolidationsAfterBesoinRenvoi(
  userRoleCode: string | undefined,
  functionalityPermissions: string[] | undefined,
): boolean {
  const rc = (userRoleCode || "").toUpperCase()
  const baseRole =
    (BESOIN_RELOAD_CONSOL_AFTER_RENVOI_ROLES as readonly string[]).includes(rc) ||
    isIeppTerritoryMenuRole(userRoleCode)
  if (!functionalityPermissions?.length) return baseRole
  return baseRole && hasFunctionalityPermission(functionalityPermissions, "BESOIN", "READ")
}

const CONSOLIDATION_DRENA_SECTION_ROLES = ["DRENA", "DAF", "ADMIN", "CABINET"] as const

/** Section consolidation agrégée DRENA — rôle autorisé + {@code BESOIN:READ} si RBAC. */
export function canSeeBesoinsConsolidationDrenaSection(
  userRoleCode: string | undefined,
  functionalityPermissions: string[] | undefined,
): boolean {
  const rc = (userRoleCode || "").toUpperCase()
  const roleOk = (CONSOLIDATION_DRENA_SECTION_ROLES as readonly string[]).includes(rc)
  if (!functionalityPermissions?.length) return roleOk
  return roleOk && hasFunctionalityPermission(functionalityPermissions, "BESOIN", "READ")
}

/** Validation de saisie besoin : {@code BESOIN:VALIDATE}, ou rôle DIRECTEUR sans RBAC en session. */
export function canShowValidateSaisieBesoinButton(
  userRoleCode: string | undefined,
  functionalityPermissions: string[] | undefined,
): boolean {
  if (hasFunctionalityPermission(functionalityPermissions, "BESOIN", "VALIDATE")) return true
  if (!functionalityPermissions?.length) {
    return (userRoleCode || "").toUpperCase() === "DIRECTEUR"
  }
  return false
}

/** Jeu de données consolidation par territoire IEPP (ex. {@code getConsolidationIEPPByRole}). */
export function canUseIeppTerritoryConsolidationDataset(
  userRoleCode: string | undefined,
  functionalityPermissions: string[] | undefined,
): boolean {
  if (!functionalityPermissions?.length) {
    return isIeppTerritoryMenuRole(userRoleCode)
  }
  return (
    isIeppTerritoryMenuRole(userRoleCode) &&
    (hasFunctionalityPermission(functionalityPermissions, "BESOIN", "READ") ||
      hasFunctionalityPermission(functionalityPermissions, "BESOIN", "CONSOLIDATE"))
  )
}

/** Bouton « Consolider » sur une ligne VALIDE (saisie) : territoire inspection uniquement + {@code BESOIN:CONSOLIDATE} si RBAC. */
export function canShowConsolidateValideBesoinButton(
  userRoleCode: string | undefined,
  functionalityPermissions: string[] | undefined,
): boolean {
  if (!functionalityPermissions?.length) {
    return isIeppTerritoryMenuRole(userRoleCode)
  }
  return (
    isIeppTerritoryMenuRole(userRoleCode) &&
    hasFunctionalityPermission(functionalityPermissions, "BESOIN", "CONSOLIDATE")
  )
}

/**
 * Actions « Consolider » / lot dans l’espace consolidation IEPP (même périmètre rôle que l’onglet,
 * {@code BESOIN:CONSOLIDATE} si liste RBAC en session).
 */
export function canShowConsolidationIeppConsoliderAction(
  userRoleCode: string | undefined,
  functionalityPermissions: string[] | undefined,
): boolean {
  const rc = (userRoleCode || "").toUpperCase()
  const roleLegacy = (IEPP_CONSOLIDATION_WORKSPACE_ROLES as readonly string[]).includes(rc)
  if (!functionalityPermissions?.length) return roleLegacy
  return roleLegacy && hasFunctionalityPermission(functionalityPermissions, "BESOIN", "CONSOLIDATE")
}
