/**
 * Utilitaire pour gérer les chemins des assets (images, fichiers).
 * Utilise NEXT_PUBLIC_BASE_PATH (même que next.config) : en local vide, sur le VPS /dismas.
 * Les assets dans public/ sont servis par Next.js sous basePath automatiquement.
 */

/** Préfixe = basePath (aligné sur next.config.mjs). Vide en local, /dismas sur le VPS. */
const getBasePath = (): string => (process.env.NEXT_PUBLIC_BASE_PATH || '').replace(/\/$/, '');

/**
 * Détecte si on est en environnement de production
 */
export const isProduction = (): boolean => {
  return process.env.NODE_ENV === 'production';
};

/**
 * Construit le chemin d'un asset (images, PDF, etc.) avec le basePath si défini.
 *
 * @param path - Chemin relatif (ex: "/imgs/logos/logo.jpg")
 * @returns Chemin complet : en local "/imgs/...", sur le VPS "/dismas/imgs/..."
 */
export const getAssetPath = (path: string): string => {
  const normalizedPath = path.startsWith('/') ? path : `/${path}`;
  const prefix = getBasePath();
  return prefix ? `${prefix}${normalizedPath}` : normalizedPath;
};

/**
 * Construit le chemin d'une image
 * Raccourci pour getAssetPath avec validation
 * 
 * @param imagePath - Chemin de l'image
 * @returns Chemin complet de l'image
 */
export const getImagePath = (imagePath: string): string => {
  return getAssetPath(imagePath);
};

/**
 * Construit le chemin d'un logo
 * 
 * @param logoName - Nom du fichier logo (ex: "logo.jpg")
 * @returns Chemin complet du logo
 */
export const getLogoPath = (logoName: string): string => {
  const safe = logoName.split("/").map((seg) => encodeURIComponent(seg)).join("/");
  return getAssetPath(`/imgs/logos/${safe}`);
};

/**
 * Construit le chemin d'une icône
 * 
 * @param iconName - Nom du fichier icône
 * @returns Chemin complet de l'icône
 */
export const getIconPath = (iconName: string): string => {
  return getAssetPath(`/imgs/icons/${iconName}`);
};

/**
 * Construit l'URL de base pour les assets (aligné sur next.config basePath).
 */
export const getAssetBaseUrl = (): string => getBasePath();

/**
 * Log le chemin généré (pour debug)
 */
export const debugAssetPath = (path: string): void => {
  if (typeof window !== 'undefined') {
    const fullPath = getAssetPath(path);
    console.log(`[Asset Path] ${process.env.NODE_ENV}:`, {
      input: path,
      output: fullPath,
      isProduction: isProduction(),
    });
  }
};
















