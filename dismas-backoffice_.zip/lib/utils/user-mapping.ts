/**
 * Utilitaires de mapping pour les données utilisateurs
 * Conversion entre les formats backend (UserDto) et frontend
 */

import type { User } from '@/lib/types/entities';
import {
  isEppSchoolDelegatedFromInformaticienRole,
  isEppSchoolDelegatedRole,
  isIntendantRole,
} from '@/lib/utils/role-codes';

export { MAX_DIRECTEURS_PAR_EPP, collectEppDirectorCounts, isEppDirectorCapacityReached } from '@/lib/utils/epp-director-capacity';

/** Ligne structure IEPP / EPP (liste hiérarchique) */
export type StructureRowRef = {
  code?: string;
  libelle?: string;
  drenaCode?: string;
  ieppCode?: string;
};

// Interface pour les données utilisateur affichées dans la liste
export interface UserListItem {
  id: number;
  firstName: string;
  lastName: string;
  email: string;
  telephone?: string;
  login: string;
  role: {
    id: number;
    code: string;
    libelle: string;
  };
  structure: {
    code: string;
    libelle: string;
    type: string;
  };
  isActive: boolean;
  /** Compte verrouillé (trop de tentatives échouées, etc.) */
  isLocked?: boolean;
  /** Tentatives de connexion échouées (si exposé par l’API) */
  loginAttempts?: number;
  lastConnectionDate?: string;
  createdAt?: string;
  // Champs spécifiques pour l'affichage hiérarchique
  drenaCode?: string;
  drenaLibelle?: string;
  ieppCode?: string;
  ieppLibelle?: string;
  eppCode?: string;
  eppLibelle?: string;
  /** Identifiants structures (API) — utiles en édition */
  drenaId?: number;
  ieppId?: number;
  eppId?: number;
}

/**
 * Convertit un User (backend UserDto) vers un UserListItem pour l'affichage
 */
export function mapUserToListItem(user: User): UserListItem {
  const u = user as any;
  // Déterminer la structure principale et son type
  let structureCode = '';
  let structureLibelle = '';
  let structureType = '';

  // Priorité: structureId > champs hiérarchiques directs
  if (u.structureCode && u.structureLibelle) {
    structureCode = u.structureCode;
    structureLibelle = u.structureLibelle;
    structureType = u.structureType || 'STRUCTURE';
  } else {
    // Fallback sur les champs hiérarchiques directs
    if (u.eppCode && u.eppLibelle) {
      structureCode = u.eppCode;
      structureLibelle = u.eppLibelle;
      structureType = 'EPP';
    } else if (u.ieppCode && u.ieppLibelle) {
      structureCode = u.ieppCode;
      structureLibelle = u.ieppLibelle;
      structureType = 'IEPP';
    } else if (u.drenaCode && u.drenaLibelle) {
      structureCode = u.drenaCode;
      structureLibelle = u.drenaLibelle;
      structureType = 'DRENA';
    } else {
      // Par défaut, structure ministérielle
      structureCode = 'MENA-CI';
      structureLibelle = 'Ministère de l\'Éducation Nationale';
      structureType = 'MENA';
    }
  }

  return {
    id: u.id || 0,
    firstName: u.firstName || '',
    lastName: u.lastName || '',
    email: u.email || '',
    telephone: u.telephone || '',
    login: (u.login ?? u.matricule ?? u.userName ?? "") as string,
    role: {
      id: u.roleId || 0,
      code: u.roleCode || '',
      libelle: getRoleLabel(u.roleCode || ''),
    },
    structure: {
      code: structureCode,
      libelle: structureLibelle,
      type: structureType,
    },
    isActive: u.isActive ?? true,
    isLocked: u.isLocked ?? false,
    loginAttempts: typeof u.loginAttempts === 'number' ? u.loginAttempts : undefined,
    lastConnectionDate: u.lastConnectionDate,
    createdAt: u.createdAt,
    // Informations hiérarchiques complètes
    drenaCode: u.drenaCode,
    drenaLibelle: u.drenaLibelle,
    ieppCode: u.ieppCode,
    ieppLibelle: u.ieppLibelle,
    eppCode: u.eppCode,
    eppLibelle: u.eppLibelle,
    drenaId: typeof u.drenaId === "number" ? u.drenaId : undefined,
    ieppId: typeof u.ieppId === "number" ? u.ieppId : undefined,
    eppId: typeof u.eppId === "number" ? u.eppId : undefined,
  };
}

/**
 * Convertit une liste d'utilisateurs backend vers des éléments d'affichage
 */
export function mapUsersToListItems(users: User[]): UserListItem[] {
  return users.map(mapUserToListItem);
}

/**
 * Obtient le libellé d'un rôle à partir de son code
 */
/** Rôle inspection (IEPP ou CPPP) : même périmètre territorial DRENA + IEPP. */
export function isIeppInspectionRole(roleCode: string | undefined): boolean {
  const c = (roleCode || "").toUpperCase().trim()
  return c === "IEPP" || c === "CPPP"
}

/**
 * Code IEPP pour périmètre inspection (liste utilisateurs) : le DTO peut omettre ieppCode
 * pour un CPS rattaché à une structure administrative de type IEPP — on retombe sur structure.code.
 */
export function effectiveIeppCodeForListItem(u: UserListItem): string {
  const flat = (u.ieppCode || "").trim()
  if (flat) return flat
  if (u.structure?.type === "IEPP" && (u.structure.code || "").trim()) {
    return (u.structure.code || "").trim()
  }
  return ""
}

export function getRoleLabel(roleCode: string): string {
  switch (roleCode.toUpperCase()) {
    case 'ADMIN':
      return 'Administrateur Système';
    case 'DAF':
      return 'Directeur des Affaires Financières';
    case 'DRENA':
      return 'Directeur Régional';
    case 'IEPP':
      return 'Inspecteur Enseignement Primaire';
    case 'CPPP':
      return 'CPPP (inspection)';
    case 'DIRECTEUR':
      return 'Directeur d\'École';
    case 'INTENDANT':
    case 'INTENDENT':
      return 'Intendant';
    case 'INFORMATICIEN':
      return 'Informaticien (EPP)';
    case 'MAITRE':
      return 'Maître';
    case 'COGES':
      return 'COGES';
    case 'CPS':
      return 'Conseiller pédagogique';
    default:
      return roleCode;
  }
}

/**
 * Obtient la couleur CSS pour un rôle
 */
export function getRoleColor(roleCode: string): string {
  switch (roleCode.toUpperCase()) {
    case 'ADMIN':
      return 'bg-red-100 text-red-800';
    case 'DAF':
      return 'bg-orange-100 text-orange-800';
    case 'DRENA':
      return 'bg-yellow-100 text-yellow-800';
    case 'IEPP':
      return 'bg-green-100 text-green-800';
    case 'DIRECTEUR':
      return 'bg-blue-100 text-blue-800';
    case 'INTENDANT':
    case 'INTENDENT':
      return 'bg-indigo-100 text-indigo-800';
    case 'INFORMATICIEN':
      return 'bg-violet-100 text-violet-800';
    case 'MAITRE':
      return 'bg-sky-100 text-sky-800';
    case 'COGES':
      return 'bg-amber-100 text-amber-800';
    case 'CPPP':
      return 'bg-teal-100 text-teal-800';
    case 'CPS':
      return 'bg-cyan-100 text-cyan-800';
    default:
      return 'bg-gray-100 text-gray-800';
  }
}

/**
 * Filtre les utilisateurs selon la hiérarchie et le rôle de l'utilisateur connecté
 */
export function filterUsersByHierarchy(
  users: UserListItem[],
  currentUser: UserListItem
): UserListItem[] {
  const currentUserRole = currentUser.role.code.toUpperCase();

  switch (currentUserRole) {
    case 'ADMIN':
    case 'DAF':
      // Admin et DAF voient tous les utilisateurs
      return users;

    case 'DRENA':
      // DRENA voit ses IEPP, directeurs EPP, CPS de son ressort + lui-même
      return users.filter(user => {
        if (user.id === currentUser.id) return true; // Lui-même
        
        // Utilisateurs de ses structures
        return (
          (isIeppInspectionRole(user.role.code) && user.drenaCode === currentUser.drenaCode) ||
          (user.role.code === 'DIRECTEUR' && user.drenaCode === currentUser.drenaCode) ||
          (isEppSchoolDelegatedRole(user.role.code) && user.drenaCode === currentUser.drenaCode) ||
          (user.role.code === 'CPS' && user.drenaCode === currentUser.drenaCode) ||
          (isIntendantRole(user.role.code) && user.drenaCode === currentUser.drenaCode)
        );
      });

    case 'IEPP':
    case 'CPPP':
    case 'CPS':
    case 'INTENDANT':
    case 'INTENDENT':
      // Inspection / appui IEPP : même périmètre IEPP (directeurs, équipe EPP, intendant, autres inspections)
      return users.filter(user => {
        if (user.id === currentUser.id) return true; // Lui-même

        const curIepp = effectiveIeppCodeForListItem(currentUser)
        const rowIepp = effectiveIeppCodeForListItem(user)

        return (
          (user.role.code === 'DIRECTEUR' ||
            isEppSchoolDelegatedRole(user.role.code) ||
            user.role.code === 'CPS' ||
            user.role.code === 'CPPP' ||
            isIntendantRole(user.role.code)) &&
          user.drenaCode === currentUser.drenaCode &&
          !!curIepp &&
          rowIepp === curIepp
        );
      });

    case 'DIRECTEUR':
      // Directeur : lui-même + équipe établissement (même EPP)
      return users.filter((user) => {
        if (user.id === currentUser.id) return true
        if (!isEppSchoolDelegatedRole(user.role.code)) return false
        const ce = (currentUser.eppCode || "").trim()
        const ue = (user.eppCode || "").trim()
        return !!ce && ce === ue
      });

    case 'INFORMATICIEN':
      return users.filter((user) => {
        if (user.id === currentUser.id) return true
        if (!isEppSchoolDelegatedFromInformaticienRole(user.role.code)) return false
        const ce = (currentUser.eppCode || "").trim()
        const ue = (user.eppCode || "").trim()
        return !!ce && ce === ue
      });

    default:
      return users;
  }
}

/**
 * Formate une date pour l'affichage
 */
export function formatDate(dateString?: string): string {
  if (!dateString) return 'Jamais';
  
  try {
    // Le backend envoie les dates au format "dd/MM/yyyy HH:mm:ss"
    const [datePart, timePart] = dateString.split(' ');
    if (datePart) {
      const [day, month, year] = datePart.split('/');
      const date = new Date(parseInt(year), parseInt(month) - 1, parseInt(day));
      
      if (!isNaN(date.getTime())) {
        return date.toLocaleDateString('fr-FR');
      }
    }
    
    // Fallback: essayer de parser directement
    const date = new Date(dateString);
    if (!isNaN(date.getTime())) {
      return date.toLocaleDateString('fr-FR');
    }
    
    return dateString;
  } catch (error) {
    console.warn('Erreur lors du formatage de la date:', dateString, error);
    return dateString || 'Jamais';
  }
}

/**
 * Formate une date et heure pour l'affichage détaillé
 */
export function formatDateTime(dateString?: string): string {
  if (!dateString) return 'Jamais';
  
  try {
    // Le backend envoie les dates au format "dd/MM/yyyy HH:mm:ss"
    const [datePart, timePart] = dateString.split(' ');
    if (datePart && timePart) {
      const [day, month, year] = datePart.split('/');
      const [hours, minutes, seconds] = timePart.split(':');
      const date = new Date(
        parseInt(year),
        parseInt(month) - 1,
        parseInt(day),
        parseInt(hours),
        parseInt(minutes),
        parseInt(seconds)
      );
      
      if (!isNaN(date.getTime())) {
        return date.toLocaleString('fr-FR');
      }
    }
    
    // Fallback: essayer de parser directement
    const date = new Date(dateString);
    if (!isNaN(date.getTime())) {
      return date.toLocaleString('fr-FR');
    }
    
    return dateString;
  } catch (error) {
    console.warn('Erreur lors du formatage de la date/heure:', dateString, error);
    return dateString || 'Jamais';
  }
}

/**
 * Chaîne DRENA → IEPP → EPP pour affichage fiche utilisateur.
 */
export function formatHierarchyCompoundCode(u: UserListItem): string | null {
  const parts = [u.drenaCode, u.ieppCode, u.eppCode].filter(
    (x): x is string => typeof x === "string" && x.trim().length > 0,
  )
  if (parts.length === 0) return null
  return parts.join(" → ")
}

/**
 * Recherche locale sur code / libellé (tableau structures hiérarchiques).
 */
export function matchesStructureHierarchySearch(row: StructureRowRef, search: string): boolean {
  const t = search.trim().toLowerCase()
  if (!t) return true
  const c = (row.code || "").toLowerCase()
  const l = (row.libelle || "").toLowerCase()
  return c.includes(t) || l.includes(t)
}

/**
 * Clés `drenaCode|ieppCode` pour les IEPP déjà dotés d’un compte inspecteur.
 */
export function collectIeppOccupiedKeys(users: User[]): Set<string> {
  const set = new Set<string>()
  for (const u of users || []) {
    if ((u.roleCode || "").toUpperCase() !== "IEPP") continue
    const dk = (u.drenaCode || "").trim()
    const ik = (u.ieppCode || "").trim()
    if (dk && ik) set.add(`${dk}|${ik}`)
  }
  return set
}

export function isIeppStructureOccupied(
  row: { code?: string; drenaCode?: string },
  occupied: Set<string>,
): boolean {
  const dk = (row.drenaCode || "").trim()
  const ck = (row.code || "").trim()
  if (!ck) return false
  if (dk && occupied.has(`${dk}|${ck}`)) return true
  return occupied.has(`|${ck}`)
}

/** Directeur : gestion des comptes équipe établissement rattachés à la même EPP. */
export function isDirecteurManagingIntendantRow(
  managerEppCode: string | undefined,
  target: UserListItem,
): boolean {
  if (!isEppSchoolDelegatedRole(target.role.code)) return false
  const me = (managerEppCode || "").trim()
  const te = (target.eppCode || "").trim()
  if (!me || !te) return false
  return me === te
}

/** Informaticien : crée maître / COGES sur la même EPP. */
export function isInformaticienManagingDelegatedRow(
  managerEppCode: string | undefined,
  target: UserListItem,
): boolean {
  if (!isEppSchoolDelegatedFromInformaticienRole(target.role.code)) return false
  const me = (managerEppCode || "").trim()
  const te = (target.eppCode || "").trim()
  if (!me || !te) return false
  return me === te
}

/**
 * Périmètre DRENA / IEPP : lignes « enfants » gérables (hors compte connecté).
 */
export function isHierarchyManagedChildRow(
  managerRole: string | undefined,
  managerDrenaCode: string | undefined,
  managerIeppCode: string | undefined,
  connectedUserId: number | undefined,
  target: UserListItem,
  /** Pour le rôle DIRECTEUR : code EPP du compte connecté (équipe établissement). */
  managerEppCode?: string | undefined,
): boolean {
  if (connectedUserId != null && target.id === connectedUserId) return false
  const rc = managerRole?.toUpperCase()
  if (rc === "DRENA") {
    return (
      (isIeppInspectionRole(target.role.code) ||
        target.role.code === "DIRECTEUR" ||
        isEppSchoolDelegatedRole(target.role.code) ||
        target.role.code === "CPS" ||
        isIntendantRole(target.role.code)) &&
      !!managerDrenaCode &&
      target.drenaCode === managerDrenaCode
    )
  }
  if (rc === "IEPP" || rc === "CPPP" || rc === "CPS" || rc === "INTENDANT" || rc === "INTENDENT") {
    return (
      (target.role.code === "DIRECTEUR" ||
        isEppSchoolDelegatedRole(target.role.code) ||
        target.role.code === "CPS" ||
        target.role.code === "CPPP" ||
        isIntendantRole(target.role.code)) &&
      !!managerDrenaCode &&
      !!managerIeppCode &&
      target.drenaCode === managerDrenaCode &&
      target.ieppCode === managerIeppCode
    )
  }
  if (rc === "DIRECTEUR") {
    return isDirecteurManagingIntendantRow(managerEppCode ?? undefined, target)
  }
  if (rc === "INFORMATICIEN") {
    return isInformaticienManagingDelegatedRow(managerEppCode ?? undefined, target)
  }
  return false
}
