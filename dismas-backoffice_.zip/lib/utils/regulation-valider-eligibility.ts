import type { RegulationDto } from "@/lib/services/regulation.service"

/**
 * Aligné sur RegulationBusiness (validation + annulation) :
 * DAF n'agit pas sur une programmation au périmètre DRENA ; DRENA n'agit pas sur une programmation nationale (DAF).
 */
export function regulationTierActionBlockedReason(roleCodeUpper: string, r: RegulationDto): string | null {
  if (roleCodeUpper === "ADMIN") return null
  const noIepp = r.ieppId == null || Number(r.ieppId) <= 0
  const hasDrena = r.drenaId != null && Number(r.drenaId) > 0
  const drenaLevelProgrammation = noIepp && hasDrena
  const nationalDafProgrammation = noIepp && !hasDrena
  if (roleCodeUpper === "DAF" && drenaLevelProgrammation) {
    return "Le DAF ne peut pas valider ni annuler une programmation au niveau DRENA."
  }
  if (roleCodeUpper === "DRENA" && nationalDafProgrammation) {
    return "La DRENA ne peut pas valider ni annuler une programmation nationale (DAF)."
  }
  return null
}
