import type { Role } from "@/lib/types/entities"

/**
 * Ordre décroissant de pouvoir (indice 0 = le plus élevé).
 * Un créateur ne peut attribuer que des rôles situés **après** le sien dans cette liste
 * (niveau strictement inférieur à lui dans la hiérarchie organisationnelle).
 */
const ROLE_HIERARCHY_ORDER: readonly string[] = [
  "ADMIN",
  "DAF",
  "CABINET",
  "DPFC",
  "DRENA",
  "IEPP",
  "CPPP",
  "CPS",
  "INTENDANT",
  "DIRECTEUR",
  "INFORMATICIEN",
  "COGES",
  "MAITRE",
] as const

function rankOf(roleCode: string): number {
  const rc = roleCode.toUpperCase().trim()
  const normalized = rc === "INTENDENT" ? "INTENDANT" : rc
  const i = ROLE_HIERARCHY_ORDER.indexOf(normalized)
  return i >= 0 ? i : 999
}

/** Le créateur peut-il attribuer ce rôle cible ? (pas de pair, pas de supérieur) */
export function canCreatorAssignRoleCode(creatorRoleCode: string | undefined, targetRoleCode: string): boolean {
  if (!creatorRoleCode) return true
  const cr = creatorRoleCode.toUpperCase().trim()
  const tr = targetRoleCode.toUpperCase().trim()
  return rankOf(tr) > rankOf(cr)
}

function numericLevel(r: Role): number | undefined {
  const n = r.niveauAcces ?? r.niveau_hierarchique
  return typeof n === "number" && !Number.isNaN(n) ? n : undefined
}

/** Rôles attribuables par le créateur (priorité à {@code niveau_acces} / niveau du référentiel si présent). */
export function filterAssignableRoles(
  creatorRoleCode: string | undefined,
  roles: Role[],
): Role[] {
  if (!creatorRoleCode) return roles
  const cr = creatorRoleCode.toUpperCase().trim()
  /** Directeur : ne crée que l’informaticien EPP ; informaticien : maîtres / COGES. */
  const filterAssignableBySchoolChain = (list: Role[]) => {
    if (cr === "DIRECTEUR") {
      return list.filter((r) => (r.code || "").toUpperCase().trim() === "INFORMATICIEN")
    }
    if (cr === "INFORMATICIEN") {
      return list.filter((r) => {
        const x = (r.code || "").toUpperCase().trim()
        return x === "MAITRE" || x === "COGES"
      })
    }
    return list
  }

  const creator = roles.find((x) => x.code.toUpperCase() === cr)
  const creatorNv = creator ? numericLevel(creator) : undefined
  // IEPP / CPPP : ne pas se fier seul à niveau_acces (collisions possibles avec INTENDANT en base) ;
  // la hiérarchie fonctionnelle (ROLE_HIERARCHY_ORDER) reflète les rôles attribuables.
  if (creatorNv !== undefined && cr !== "IEPP" && cr !== "CPPP") {
    const step = roles.filter((r) => {
      if (!r.code) return false
      const tv = numericLevel(r)
      if (tv !== undefined) return tv < creatorNv
      return canCreatorAssignRoleCode(cr, r.code)
    })
    return filterAssignableBySchoolChain(step)
  }
  const base = roles.filter((r) => r.code && canCreatorAssignRoleCode(creatorRoleCode, r.code))
  return filterAssignableBySchoolChain(base)
}
