/**
 * Rôles « école » (EPP) : menus opérationnels + page territoire sans entrée « Paramètre ».
 * L’intendant est rattaché inspection (IEPP) — voir {@link isIeppTerritoryMenuRole}.
 */
export const EPP_SCHOOL_OPERATIONAL_ROLE_CODES = [
  "DIRECTEUR",
  "INFORMATICIEN",
  "MAITRE",
  "COGES",
] as const

export function isEppSchoolOperationalRole(roleCode: string | undefined): boolean {
  const c = (roleCode || "").toUpperCase().trim()
  return (EPP_SCHOOL_OPERATIONAL_ROLE_CODES as readonly string[]).includes(c)
}

/** Inspection / appui IEPP : même bandeau territoire que l’inspecteur (hors catalogue global « Paramètre »). */
export const IEPP_TERRITORY_MENU_ROLE_CODES = [
  "IEPP",
  "CPPP",
  "CPS",
  "INTENDANT",
  "INTENDENT",
] as const

export function isIeppTerritoryMenuRole(roleCode: string | undefined): boolean {
  const c = (roleCode || "").toUpperCase().trim()
  return (IEPP_TERRITORY_MENU_ROLE_CODES as readonly string[]).includes(c)
}

/**
 * Menu « Structures scolaires » : profils inspection / région uniquement (fallback si pas de liste RBAC en session).
 * L’équipe EPP n’y figure pas : accès via permission READ sur {@code STRUCTURE_ADMINISTRATIVE} (même code que l’API structures).
 */
export const STRUCTURES_SCOLAIRES_ROLE_CODES: readonly string[] = ["DRENA", ...IEPP_TERRITORY_MENU_ROLE_CODES]

/** Masquer « Paramètre » (paramétrages globaux) pour ces profils. */
export function hidesGlobalParametreMenu(roleCode: string | undefined): boolean {
  const c = (roleCode || "").toUpperCase().trim()
  return c === "DRENA" || isIeppTerritoryMenuRole(c) || isEppSchoolOperationalRole(c)
}

/** Accès page paramétrages limité à l’onglet « territoire » (pas catalogues / RBAC). */
export function isParametragesTerritoireOnlyRole(roleCode: string | undefined): boolean {
  return hidesGlobalParametreMenu(roleCode)
}

export function isIntendantRole(roleCode: string | undefined): boolean {
  const c = (roleCode || "").toUpperCase().trim()
  return c === "INTENDANT" || c === "INTENDENT"
}

/** Rôles école : expression de besoins au niveau EPP (directeur ou délégation informaticien). */
export function isEppBesoinExpressionRole(roleCode: string | undefined): boolean {
  const c = (roleCode || "").toUpperCase().trim()
  return c === "DIRECTEUR" || c === "INFORMATICIEN"
}

/** Rôles « équipe école » sous le directeur (hors le directeur). Le directeur crée l’informaticien. */
const EPP_SCHOOL_DELEGATED_FROM_DIRECTOR_CODES = ["INFORMATICIEN"] as const

/** Rôles créés par l’informaticien pour le compte de l’EPP. */
export const EPP_INFORMATICIEN_DELEGATED_ROLE_CODES = ["MAITRE", "COGES"] as const

export function isEppSchoolDelegatedFromDirectorRole(roleCode: string | undefined): boolean {
  const c = (roleCode || "").toUpperCase().trim()
  return (EPP_SCHOOL_DELEGATED_FROM_DIRECTOR_CODES as readonly string[]).includes(c)
}

export function isEppSchoolDelegatedFromInformaticienRole(roleCode: string | undefined): boolean {
  const c = (roleCode || "").toUpperCase().trim()
  return (EPP_INFORMATICIEN_DELEGATED_ROLE_CODES as readonly string[]).includes(c)
}

/** Toute personne de l’équipe école sous le même EPP (hors directeur) pour listes / filtres. */
export function isEppSchoolDelegatedRole(roleCode: string | undefined): boolean {
  return isEppSchoolDelegatedFromDirectorRole(roleCode) || isEppSchoolDelegatedFromInformaticienRole(roleCode)
}
