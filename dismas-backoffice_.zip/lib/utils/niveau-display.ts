export type NiveauScolaireAffichageInput = {
  code?: string | null;
  libelle?: string | null;
};

/**
 * Affiche le niveau avec le code en tête, le libellé en complément (liste, selects, lecture seule).
 */
export function displayNiveauScolaireCodeEtLibelle(n: NiveauScolaireAffichageInput): string {
  const code = (n.code ?? "").trim();
  const libelle = (n.libelle ?? "").trim();
  if (code && libelle) {
    if (code === libelle) return code;
    return `${code} — ${libelle}`;
  }
  return code || libelle || "—";
}

/** Affichage prioritaire du code (listes / tableaux quand le libellé est redondant). */
export function displayNiveauCodeOnly(code?: string | null, libelle?: string | null): string {
  const c = (code ?? "").trim();
  if (c) return c;
  return (libelle ?? "").trim() || "—";
}
