/**
 * Détection et libellés utilisateur pour les refus d’accès RBAC renvoyés par le backend (ex. code 900).
 */

/** Messages 900 liés à la session / token — à ne pas confondre avec un simple manque de droit métier */
function isSessionRelated900Message(message: string): boolean {
  const m = message.toLowerCase()
  return (
    m.includes("token invalide") ||
    m.includes("session expirée") ||
    m.includes("session expirer") ||
    m.includes("token expired") ||
    m.includes("unauthorized") && m.includes("session")
  )
}

/**
 * Indique si la réponse correspond à un refus d’opération faute de permission sur une fonctionnalité
 * (et non à une erreur technique ou à une session expirée).
 */
export function isRbacPermissionDenied(statusCode: string | undefined, message: string | undefined): boolean {
  if (String(statusCode ?? "") !== "900") return false
  const raw = (message ?? "").trim()
  if (!raw) return false
  if (isSessionRelated900Message(raw)) return false

  const lower = raw.toLowerCase()
  return (
    lower.includes("n'a pas la permission") ||
    lower.includes("na pas la permission") ||
    lower.includes("n’a pas la permission") ||
    (lower.includes("permission") &&
      (lower.includes("fonctionnalité") || lower.includes("fonctionnalite"))) ||
    ((lower.includes("operation interdite") || lower.includes("opération interdite")) &&
      (lower.includes("permission") || lower.includes("refus")))
  )
}

/**
 * Message court et lisible pour toast / alertes (une ou deux phrases).
 */
export function formatRbacPermissionDeniedMessage(rawMessage: string): string {
  const trimmed = rawMessage.trim()

  const permMatch =
    trimmed.match(/permission\s+['']([^'']+)['']/i) ||
    trimmed.match(/permission\s+[''`]([^''`]+)[''`]/i)
  const funcMatch =
    trimmed.match(/fonctionnalit[ée]\s+['']([^'']+)['']/i) ||
    trimmed.match(/fonctionnalit[ée]\s+[''`]([^''`]+)[''`]/i)
  const perm = permMatch?.[1]
  const fn = funcMatch?.[1]

  if (perm && fn) {
    return `Accès refusé : votre profil ne dispose pas du droit « ${perm} » sur la fonctionnalité « ${fn} ». Demandez à un administrateur si vous devez accéder à cette action.`
  }

  const withoutPrefix = trimmed.replace(/^Operation\s+interdite\/refus[ée]e\s*:\s*/i, "").replace(/^Opération\s+interdite\/refus[ée]e\s*:\s*/i, "").trim()

  if (withoutPrefix && withoutPrefix !== trimmed) {
    return `Accès refusé : ${withoutPrefix}`
  }

  return `Accès refusé : ${trimmed || "droits insuffisants pour cette opération."}`
}

/** Libellé déjà reformulé côté client (ex. après `formatRbacPermissionDeniedMessage`). */
export function isFormattedRbacPermissionMessage(message: string | undefined | null): boolean {
  return typeof message === "string" && message.trimStart().startsWith("Accès refusé")
}

/** Message affichable depuis une erreur levée par `BaseApiService` (`BackendBusinessError`, `ApiError`, `Error`). */
export function getThrownErrorMessage(err: unknown, fallback: string): string {
  if (err instanceof Error && err.message.trim()) return err.message.trim()
  if (err && typeof err === "object" && "message" in err) {
    const m = (err as { message?: unknown }).message
    if (typeof m === "string" && m.trim()) return m.trim()
  }
  if (err && typeof err === "object") {
    const st = (err as { details?: { status?: { message?: string } } }).details?.status?.message
    if (typeof st === "string" && st.trim()) return st.trim()
  }
  return fallback
}
