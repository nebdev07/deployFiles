/** Plafond aligné sur le backend : comptes DIRECTEUR par même structure (EPP). */
export const MAX_DIRECTEURS_PAR_EPP = 2

export type EppDirectorCountUser = {
  roleCode?: string
  drenaCode?: string
  ieppCode?: string
  eppCode?: string
}

/**
 * Compte les directeurs par clé `drenaCode|ieppCode|eppCode` (liste utilisateurs API ou équivalent).
 */
export function collectEppDirectorCounts(users: EppDirectorCountUser[] | null | undefined): Map<string, number> {
  const map = new Map<string, number>()
  for (const u of users || []) {
    if ((u.roleCode || "").toUpperCase() !== "DIRECTEUR") continue
    const dk = (u.drenaCode || "").trim()
    const ik = (u.ieppCode || "").trim()
    const ek = (u.eppCode || "").trim()
    if (!dk || !ik || !ek) continue
    const key = `${dk}|${ik}|${ek}`
    map.set(key, (map.get(key) ?? 0) + 1)
  }
  return map
}

/**
 * Vrai si l’EPP a déjà atteint le plafond de comptes directeur (masquer la ligne « créer un compte »).
 */
export function isEppDirectorCapacityReached(
  row: { code?: string; drenaCode?: string; ieppCode?: string },
  counts: Map<string, number>,
  max: number = MAX_DIRECTEURS_PAR_EPP,
): boolean {
  const dk = (row.drenaCode || "").trim()
  const ik = (row.ieppCode || "").trim()
  const ck = (row.code || "").trim()
  if (!dk || !ik || !ck) return false
  const key = `${dk}|${ik}|${ck}`
  return (counts.get(key) ?? 0) >= max
}
