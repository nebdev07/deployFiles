/**
 * Utilitaires pour l'API - Gestion des champs backend
 * Exclut les champs gérés automatiquement par le backend
 */

/**
 * Champs gérés automatiquement par le backend
 * Ces champs ne doivent pas être inclus dans les requêtes CREATE/UPDATE
 */
export const BACKEND_MANAGED_FIELDS = [
  'id',
  'createdAt',
  'updatedAt',
  'isDeleted',
  'token',
  'tokenCreatedAt',
  'tokenExpireAt',
  'dateSendCodeOtpAt',
  'otpCode',
  'loginAttempts'
] as const;

/**
 * Nettoie un objet en excluant les champs gérés par le backend
 * @param obj - L'objet à nettoyer
 * @param additionalFields - Champs supplémentaires à exclure
 * @returns L'objet nettoyé
 */
export function cleanForBackend<T extends Record<string, any>>(
  obj: T,
  additionalFields: string[] = []
): Partial<T> {
  const fieldsToExclude = [...BACKEND_MANAGED_FIELDS, ...additionalFields];
  
  const cleaned = { ...obj };
  
  fieldsToExclude.forEach(field => {
    delete cleaned[field];
  });
  
  return cleaned;
}

/**
 * Nettoie un tableau d'objets en excluant les champs gérés par le backend
 * @param items - Le tableau d'objets à nettoyer
 * @param additionalFields - Champs supplémentaires à exclure
 * @returns Le tableau nettoyé
 */
export function cleanArrayForBackend<T extends Record<string, any>>(
  items: T[],
  additionalFields: string[] = []
): Partial<T>[] {
  return items.map(item => cleanForBackend(item, additionalFields));
}

/**
 * Prépare les données pour une requête CREATE
 * Exclut tous les champs gérés par le backend
 */
export function prepareCreateData<T extends Record<string, any>>(
  data: T,
  additionalFields: string[] = []
): Partial<T> {
  return cleanForBackend(data, additionalFields);
}

/**
 * Prépare les données pour une requête UPDATE
 * Exclut les champs gérés par le backend mais garde l'ID
 */
export function prepareUpdateData<T extends Record<string, any>>(
  data: T,
  additionalFields: string[] = []
): Partial<T> & { id: number } {
  const cleaned = cleanForBackend(data, additionalFields);
  
  // S'assurer que l'ID est inclus pour les updates
  if (data.id) {
    return { ...cleaned, id: data.id };
  }
  
  return cleaned as Partial<T> & { id: number };
}

/**
 * Vérifie si un objet a des champs gérés par le backend
 */
export function hasBackendManagedFields(obj: Record<string, any>): boolean {
  return BACKEND_MANAGED_FIELDS.some(field => field in obj);
}

/**
 * Extrait uniquement les champs gérés par le backend (pour affichage)
 */
export function extractBackendManagedFields<T extends Record<string, any>>(
  obj: T
): Pick<T, keyof T & typeof BACKEND_MANAGED_FIELDS[number]> {
  const extracted = {} as any;
  
  BACKEND_MANAGED_FIELDS.forEach(field => {
    if (field in obj) {
      extracted[field] = obj[field];
    }
  });
  
  return extracted;
}