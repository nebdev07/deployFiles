/**
 * Utilitaires pour la gestion des rôles
 * Centralise la logique de vérification des permissions
 */

/**
 * Vérifie si l'utilisateur a un rôle spécifique (insensible à la casse)
 */
export function hasRole(userRoleCode: string, requiredRole: string): boolean {
  return userRoleCode.toUpperCase() === requiredRole.toUpperCase();
}

/**
 * Vérifie si l'utilisateur a l'un des rôles spécifiés (insensible à la casse)
 */
export function hasAnyRole(userRoleCode: string, requiredRoles: string[]): boolean {
  const userRoleUpper = userRoleCode.toUpperCase();
  return requiredRoles.some(role => role.toUpperCase() === userRoleUpper);
}

/**
 * Vérifie si l'utilisateur est administrateur
 */
export function isAdmin(userRoleCode: string): boolean {
  return hasRole(userRoleCode, 'ADMIN');
}

/**
 * Vérifie si l'utilisateur est DAF
 */
export function isDAF(userRoleCode: string): boolean {
  return hasRole(userRoleCode, 'DAF');
}

/**
 * Vérifie si l'utilisateur est DRENA
 */
export function isDRENA(userRoleCode: string): boolean {
  return hasRole(userRoleCode, 'DRENA');
}

/**
 * Vérifie si l'utilisateur est IEPP ou EPP
 */
export function isIEPP(userRoleCode: string): boolean {
  return hasAnyRole(userRoleCode, ['IEPP', 'EPP']);
}

/**
 * Vérifie si l'utilisateur est Directeur
 */
export function isDirecteur(userRoleCode: string): boolean {
  return hasRole(userRoleCode, 'DIRECTEUR');
}

/**
 * Vérifie si l'utilisateur peut accéder aux paramétrages
 */
export function canAccessParametrages(userRoleCode: string): boolean {
  return hasAnyRole(userRoleCode, ['ADMIN', 'DAF', 'DPFC']);
}

/**
 * Vérifie si l'utilisateur peut accéder aux commandes
 */
export function canAccessCommandes(userRoleCode: string): boolean {
  return hasAnyRole(userRoleCode, ['ADMIN', 'DAF']);
}

/**
 * Vérifie si l'utilisateur peut accéder aux réceptions
 */
export function canAccessReceptions(userRoleCode: string): boolean {
  return hasAnyRole(userRoleCode, ['ADMIN', 'DAF', 'DRENA', 'IEPP', 'EPP']);
}

/**
 * Vérifie si l'utilisateur peut gérer les utilisateurs
 */
export function canManageUsers(userRoleCode: string): boolean {
  return hasAnyRole(userRoleCode, ['ADMIN', 'DAF', 'DRENA', 'IEPP', 'EPP']);
}

/**
 * Vérifie si l'utilisateur peut valider les besoins
 */
export function canValidateBesoins(userRoleCode: string): boolean {
  return hasAnyRole(userRoleCode, ['ADMIN', 'DAF', 'DRENA', 'IEPP', 'EPP']);
}