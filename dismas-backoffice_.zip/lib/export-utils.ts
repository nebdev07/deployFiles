import jsPDF from 'jspdf'
import autoTable from 'jspdf-autotable'
import * as XLSX from 'xlsx'
import { saveAs } from 'file-saver'

// Types pour les données d'export
export interface ExportData {
  title: string
  subtitle?: string
  date: string
  generatedBy: string
  status: string
  statistics: {
    label: string
    value: string | number
  }[]
  tables: {
    title: string
    headers: string[]
    data: (string | number)[][]
  }[]
}

// 🎯 FONCTION: Export PDF avec jsPDF
export const exportToPDF = (data: ExportData, fileName: string) => {
  const doc = new jsPDF()
  
  // Configuration de la page
  const pageWidth = doc.internal.pageSize.getWidth()
  const margin = 20
  let currentY = 30
  
  // En-tête principal
  doc.setFontSize(20)
  doc.setFont('helvetica', 'bold')
  doc.text(data.title, pageWidth / 2, currentY, { align: 'center' })
  currentY += 15
  
  // Sous-titre (si présent)
  if (data.subtitle) {
    doc.setFontSize(14)
    doc.setFont('helvetica', 'normal')
    doc.text(data.subtitle, pageWidth / 2, currentY, { align: 'center' })
    currentY += 10
  }
  
  // Informations générales
  doc.setFontSize(12)
  doc.setFont('helvetica', 'normal')
  doc.text(`Date: ${data.date}`, margin, currentY)
  currentY += 8
  doc.text(`Généré par: ${data.generatedBy}`, margin, currentY)
  currentY += 8
  doc.text(`Statut: ${data.status}`, margin, currentY)
  currentY += 15
  
  // Statistiques
  if (data.statistics.length > 0) {
    doc.setFontSize(14)
    doc.setFont('helvetica', 'bold')
    doc.text('Statistiques', margin, currentY)
    currentY += 10
    
    doc.setFontSize(10)
    doc.setFont('helvetica', 'normal')
    data.statistics.forEach(stat => {
      doc.text(`${stat.label}: ${stat.value}`, margin, currentY)
      currentY += 6
    })
    currentY += 10
  }
  
  // Tableaux
  data.tables.forEach((table, index) => {
    // Vérifier si on a besoin d'une nouvelle page
    if (currentY > doc.internal.pageSize.getHeight() - 50) {
      doc.addPage()
      currentY = 30
    }
    
    // Titre du tableau
    doc.setFontSize(12)
    doc.setFont('helvetica', 'bold')
    doc.text(table.title, margin, currentY)
    currentY += 8
    
    // Tableau
    autoTable(doc, {
      head: [table.headers],
      body: table.data,
      startY: currentY,
      margin: { left: margin, right: margin },
      styles: {
        fontSize: 8,
        cellPadding: 2
      },
      headStyles: {
        fillColor: [41, 128, 185],
        textColor: 255,
        fontStyle: 'bold'
      },
      alternateRowStyles: {
        fillColor: [245, 245, 245]
      }
    })
    
    // Mettre à jour la position Y après le tableau
    currentY = (doc as any).lastAutoTable?.finalY + 10 || currentY + 50
  })
  
  // Numérotation des pages
  const pageCount = (doc.internal as any).getNumberOfPages?.() || (doc.internal as any).pages?.length || 1
  for (let i = 1; i <= pageCount; i++) {
    doc.setPage(i)
    doc.setFontSize(8)
    doc.text(`Page ${i} sur ${pageCount}`, pageWidth - 30, doc.internal.pageSize.getHeight() - 10)
  }
  
  // Sauvegarder
  doc.save(fileName)
}

// 📊 FONCTION: Export Excel avec XLSX
export const exportToExcel = (data: ExportData, fileName: string) => {
  const workbook = XLSX.utils.book_new()
  
  // Feuille 1: Vue d'ensemble
  const overviewData = [
    [data.title],
    [''],
    ['Date', data.date],
    ['Généré par', data.generatedBy],
    ['Statut', data.status],
    ['']
  ]
  
  // Ajouter les statistiques
  if (data.statistics.length > 0) {
    overviewData.push(['Statistiques'])
    data.statistics.forEach(stat => {
      overviewData.push([stat.label, String(stat.value)] as string[])
    })
    overviewData.push([''])
  }
  
  // Ajouter le premier tableau
  if (data.tables.length > 0) {
    overviewData.push([data.tables[0].title])
    overviewData.push(data.tables[0].headers)
    data.tables[0].data.forEach(row => {
      overviewData.push(row.map(cell => String(cell)) as string[])
    })
  }
  
  const overviewSheet = XLSX.utils.aoa_to_sheet(overviewData)
  XLSX.utils.book_append_sheet(workbook, overviewSheet, 'Vue d\'ensemble')
  
  // Feuilles supplémentaires pour les autres tableaux
  data.tables.slice(1).forEach((table, index) => {
    const sheetData = [
      [table.title],
      [''],
      table.headers,
      ...table.data
    ]
    
    const sheet = XLSX.utils.aoa_to_sheet(sheetData)
    XLSX.utils.book_append_sheet(workbook, sheet, `Feuille ${index + 2}`)
  })
  
  // Sauvegarder
  XLSX.writeFile(workbook, fileName)
}

// 🎯 FONCTION: Formatage des nombres
export const formatNumber = (num: number): string => {
  return new Intl.NumberFormat('fr-FR').format(num)
}

// 🎯 FONCTION: Génération de nom de fichier
export const generateFileName = (baseName: string, extension: string): string => {
  const date = new Date().toISOString().split('T')[0]
  return `${baseName}_${date}.${extension}`
}

// 🎯 FONCTION: Validation des données d'export
export const validateExportData = (data: ExportData): boolean => {
  if (!data.title || !data.date || !data.generatedBy) {
    return false
  }
  
  if (data.tables.length === 0) {
    return false
  }
  
  // Vérifier que chaque tableau a des en-têtes et des données
  for (const table of data.tables) {
    if (!table.title || table.headers.length === 0) {
      return false
    }
    
    // Vérifier que toutes les lignes ont le même nombre de colonnes que les en-têtes
    for (const row of table.data) {
      if (row.length !== table.headers.length) {
        return false
      }
    }
  }
  
  return true
} 