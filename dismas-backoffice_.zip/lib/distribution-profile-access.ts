/** Aligné sur `components/layout/sidebar.tsx` (entrée menu Distribution). */
export const DISTRIBUTION_MENU_ROLE_CODES = [
  "ADMIN",
  "DAF",
  "DRENA",
  "IEPP",
  "DIRECTEUR",
  "MAITRE",
] as const

export function canAccessDistributionFromMenu(roleCode: string | undefined): boolean {
  if (!roleCode) return false
  return (DISTRIBUTION_MENU_ROLE_CODES as readonly string[]).includes(roleCode)
}
