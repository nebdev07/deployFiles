/**
 * Construction et déduplication des lignes « manuels » pour l’affichage réceptions.
 * Le backend peut renvoyer des doublons (ex. plusieurs CatalogueMouvement actifs pour un même catalogue,
 * ou lignes résiduelles à quantiteRecue=0 après resaisie) — on fusionne par (code, niveau, titre).
 */

export type ManuelLigneAffichage = {
  code: string
  titre: string
  niveau: string
  quantite_prevue: number
  quantite_recue: number
  ecart: number
}

function cleLigne(m: ManuelLigneAffichage): string {
  return [m.code, m.niveau, m.titre].join("|")
}

/**
 * Fusionne les lignes en double : garde celle avec la plus grande quantité reçue
 * (données réelles), sinon la meilleure prévision.
 */
export function dedupeManuelsLignes(rows: ManuelLigneAffichage[]): ManuelLigneAffichage[] {
  const map = new Map<string, ManuelLigneAffichage>()
  for (const row of rows) {
    const k = cleLigne(row)
    const prev = map.get(k)
    if (!prev) {
      map.set(k, { ...row })
      continue
    }
    const qrPrev = prev.quantite_recue ?? 0
    const qrNew = row.quantite_recue ?? 0
    const qpPrev = prev.quantite_prevue ?? 0
    const qpNew = row.quantite_prevue ?? 0
    let chosen: ManuelLigneAffichage
    if (qrNew !== qrPrev) {
      chosen = qrNew > qrPrev ? row : prev
    } else if (qpNew !== qpPrev) {
      chosen = qpNew > qpPrev ? row : prev
    } else {
      chosen = row
    }
    const qp = chosen.quantite_prevue ?? 0
    const qr = chosen.quantite_recue ?? 0
    map.set(k, {
      ...chosen,
      quantite_prevue: qp,
      quantite_recue: qr,
      ecart: qr - qp,
    })
  }
  return Array.from(map.values())
}

/**
 * Aplatit catalogueMouvements (format API mouvement) puis déduplique.
 */
export function manuelsDepuisCatalogueMouvements(catalogueMouvements: unknown): ManuelLigneAffichage[] {
  if (!Array.isArray(catalogueMouvements) || catalogueMouvements.length === 0) {
    return []
  }
  const rows: ManuelLigneAffichage[] = []
  for (const catalogueMouvement of catalogueMouvements as any[]) {
    const mqs = catalogueMouvement?.matiereQuantites
    if (!Array.isArray(mqs)) continue
    for (const mq of mqs) {
      const qp = mq.quantitePrevue ?? 0
      const qr = mq.quantiteRecue ?? 0
      rows.push({
        code: mq.matiereCode || `MAT-${mq.idMatiere ?? ""}`,
        titre: mq.matiereLibelle || "Matière inconnue",
        niveau: catalogueMouvement.catalogueLibelle || "N/A",
        quantite_prevue: qp,
        quantite_recue: qr,
        ecart: mq.ecart != null ? mq.ecart : qr - qp,
      })
    }
  }
  return dedupeManuelsLignes(rows)
}
