/**
 * Quantités déjà engagées sur des demandes v2 EPP→EPP « en attente d’accords » (lignes EN_ATTENTE ou ACCEPTE),
 * aligné sur le calcul serveur (même IEPP / année, type REGULATION_V2_EPP).
 */

import { mobilisationKey } from "./regulation-v2-mobilisation"

export type SuiviRowLike = {
  type?: string
  matiereId: number
  niveauId: number
  structureSourceId: number
  quantite: number
  statutLigne?: string
  /** Ne compter dans l’« engagé » que les demandes déjà transmises aux EPP (hors validation IEPP). */
  statutDemande?: string
}

function comboKey(matiereId: number, niveauId: number): string {
  return `${matiereId}-${niveauId}`
}

function statutEngage(code: string | undefined): boolean {
  const c = (code ?? "").trim().toUpperCase()
  return c === "EN_ATTENTE" || c === "ACCEPTE"
}

function isRegulationV2Epp(type: string | undefined): boolean {
  return (type ?? "").trim().toUpperCase() === "REGULATION_V2_EPP"
}

function comptePourEngageDemande(statutDemande: string | undefined): boolean {
  const s = (statutDemande ?? "").trim().toUpperCase()
  if (!s) return true
  // Inclut aussi l'étape de validation IEPP (demandes DRENA/DAF pas encore transmises aux EPP).
  return s === "EN_ATTENTE_ACCORDS" || s === "EN_ATTENTE_VALIDATION_IEPP"
}

/** Sommes par matière–niveau (pour la synthèse besoin vs mobilisé). */
export function engagedByMatiereNiveauFromSuivi(rows: SuiviRowLike[]): Map<string, number> {
  const m = new Map<string, number>()
  for (const row of rows) {
    if (!isRegulationV2Epp(row.type) || !statutEngage(row.statutLigne) || !comptePourEngageDemande(row.statutDemande))
      continue
    const k = comboKey(row.matiereId, row.niveauId)
    const q = Number(row.quantite) || 0
    m.set(k, (m.get(k) ?? 0) + q)
  }
  return m
}

/** Sommes par EPP source – matière – niveau (plafond excédent / saisie mobilisation). */
export function engagedBySourceKeyFromSuivi(rows: SuiviRowLike[]): Map<string, number> {
  const m = new Map<string, number>()
  for (const row of rows) {
    if (!isRegulationV2Epp(row.type) || !statutEngage(row.statutLigne) || !comptePourEngageDemande(row.statutDemande))
      continue
    const k = mobilisationKey(row.structureSourceId, row.matiereId, row.niveauId)
    const q = Number(row.quantite) || 0
    m.set(k, (m.get(k) ?? 0) + q)
  }
  return m
}
