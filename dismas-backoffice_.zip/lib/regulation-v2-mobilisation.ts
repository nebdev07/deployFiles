/**
 * Logique pure : mobilisation IEPP (excédents → besoins agrégés) et construction des lignes API v2.
 */

export type AgregatDeficitRow = {
  matiereId: number
  niveauId: number
  matiereLibelle?: string
  niveauLibelle?: string
  deficitTotal: number
  repartitionParEpp: Array<{ eppId: number; eppLibelle?: string; deficit: number }>
}

export type ExcedentFlatRow = {
  eppId: number
  matiereId: number
  niveauId: number
  matiereLibelle: string
  niveauLibelle: string
  excedent: number
}

export type MobilisationEntry = {
  sourceEppId: number
  matiereId: number
  niveauId: number
  quantite: number
  excedentMax: number
}

export type V2SourcePayload = {
  structureSourceId: number
  structureDestId: number
  matiereId: number
  niveauId: number
  quantite: number
}

const comboKey = (m: number, n: number) => `${m}-${n}`

export function parseAgregatItems(items: unknown[]): AgregatDeficitRow[] {
  const out: AgregatDeficitRow[] = []
  for (const raw of items) {
    if (raw == null || typeof raw !== "object") continue
    const r = raw as Record<string, unknown>
    const matiereId = Number(r.matiereId ?? r.matiere_id)
    const niveauId = Number(r.niveauId ?? r.niveau_id)
    if (!Number.isFinite(matiereId) || !Number.isFinite(niveauId)) continue
    const repRaw = r.repartitionParEpp ?? r.repartition_par_epp
    const repartitionParEpp = Array.isArray(repRaw)
      ? repRaw.map((x) => {
          const o = x as Record<string, unknown>
          return {
            eppId: Number(o.eppId ?? o.epp_id),
            eppLibelle: o.eppLibelle != null ? String(o.eppLibelle) : o.epp_libelle != null ? String(o.epp_libelle) : undefined,
            deficit: Number(o.deficit ?? 0) || 0,
          }
        })
      : []
    out.push({
      matiereId,
      niveauId,
      matiereLibelle: r.matiereLibelle != null ? String(r.matiereLibelle) : r.matiere_libelle != null ? String(r.matiere_libelle) : undefined,
      niveauLibelle: r.niveauLibelle != null ? String(r.niveauLibelle) : r.niveau_libelle != null ? String(r.niveau_libelle) : undefined,
      deficitTotal: Number(r.deficitTotal ?? r.deficit_total ?? 0) || 0,
      repartitionParEpp,
    })
  }
  return out
}

export function flattenExcedents(
  eppExc: Array<{
    eppId: number
    combinaisonsExcedentaires?: Array<{
      matiereId: number
      niveauId: number
      matiereLibelle?: string
      niveauLibelle?: string
      excedent: number
    }>
  }>
): ExcedentFlatRow[] {
  const rows: ExcedentFlatRow[] = []
  for (const epp of eppExc) {
    const combs = epp.combinaisonsExcedentaires ?? []
    for (const c of combs) {
      const excedent = Number(c.excedent ?? 0) || 0
      if (excedent <= 0) continue
      rows.push({
        eppId: epp.eppId,
        matiereId: Number(c.matiereId),
        niveauId: Number(c.niveauId),
        matiereLibelle: String(c.matiereLibelle ?? ""),
        niveauLibelle: String(c.niveauLibelle ?? ""),
        excedent,
      })
    }
  }
  return rows
}

/** Clé UI : eppId-matiereId-niveauId */
export function mobilisationKey(sourceEppId: number, matiereId: number, niveauId: number) {
  return `${sourceEppId}-${matiereId}-${niveauId}`
}

export function recordToMobilisationEntries(
  qtyByKey: Record<string, number>,
  flatExc: ExcedentFlatRow[]
): MobilisationEntry[] {
  const excByKey = new Map<string, number>()
  for (const r of flatExc) {
    excByKey.set(mobilisationKey(r.eppId, r.matiereId, r.niveauId), r.excedent)
  }
  const out: MobilisationEntry[] = []
  for (const [k, raw] of Object.entries(qtyByKey)) {
    const q = Number(raw)
    if (!Number.isFinite(q) || q <= 0) continue
    const parts = k.split("-").map(Number)
    if (parts.length < 3 || parts.some((x) => !Number.isFinite(x))) continue
    const [sourceEppId, matiereId, niveauId] = parts
    const excedentMax = excByKey.get(k) ?? 0
    out.push({
      sourceEppId,
      matiereId,
      niveauId,
      quantite: Math.min(Math.floor(q), excedentMax > 0 ? excedentMax : Math.floor(q)),
      excedentMax,
    })
  }
  return out
}

function engagedForCombo(
  matiereId: number,
  niveauId: number,
  engagedByCombo?: ReadonlyMap<string, number> | Readonly<Record<string, number>>
): number {
  if (!engagedByCombo) return 0
  const k = comboKey(matiereId, niveauId)
  if (engagedByCombo instanceof Map) {
    return engagedByCombo.get(k) ?? 0
  }
  const v = (engagedByCombo as Readonly<Record<string, number>>)[k]
  return typeof v === "number" && Number.isFinite(v) ? v : 0
}

export function validateMobilisationAgainstAgregat(
  agregats: AgregatDeficitRow[],
  entries: MobilisationEntry[],
  engagedByCombo?: ReadonlyMap<string, number> | Readonly<Record<string, number>>
): { ok: true } | { ok: false; message: string } {
  const byCombo = new Map<string, number>()
  for (const e of entries) {
    const k = comboKey(e.matiereId, e.niveauId)
    byCombo.set(k, (byCombo.get(k) ?? 0) + e.quantite)
  }
  for (const [k, sumQty] of byCombo) {
    const [ms, ns] = k.split("-")
    const matiereId = Number(ms)
    const niveauId = Number(ns)
    const agg = agregats.find((a) => a.matiereId === matiereId && a.niveauId === niveauId)
    const maxAllowed = agg?.deficitTotal ?? 0
    const engaged = engagedForCombo(matiereId, niveauId, engagedByCombo)
    if (sumQty + engaged > maxAllowed) {
      return {
        ok: false,
        message: `Pour la combinaison matière/niveau concernée, la somme mobilisée (${sumQty}) plus les quantités déjà en demande (${engaged}) dépasse le besoin agrégé (${maxAllowed}).`,
      }
    }
  }
  return { ok: true }
}

/** Saisie mobilisation + demandes v2 en cours ne doivent pas dépasser l’excédent déclaré par EPP source. */
export function validateMobilisationAgainstExcedent(
  entries: MobilisationEntry[],
  flatExc: ExcedentFlatRow[],
  engagedBySourceKey: ReadonlyMap<string, number>
): { ok: true } | { ok: false; message: string } {
  const excByKey = new Map<string, number>()
  for (const r of flatExc) {
    excByKey.set(mobilisationKey(r.eppId, r.matiereId, r.niveauId), r.excedent)
  }
  const sumByKey = new Map<string, number>()
  for (const e of entries) {
    const k = mobilisationKey(e.sourceEppId, e.matiereId, e.niveauId)
    sumByKey.set(k, (sumByKey.get(k) ?? 0) + e.quantite)
  }
  for (const [k, sum] of sumByKey) {
    const exc = excByKey.get(k) ?? 0
    const eng = engagedBySourceKey.get(k) ?? 0
    if (sum + eng > exc) {
      return {
        ok: false,
        message: `Pour une combinaison EPP source / matière / niveau, la mobilisation (${sum}) plus les quantités déjà en demande (${eng}) dépasse l’excédent (${exc}).`,
      }
    }
  }
  return { ok: true }
}

/**
 * Répartit chaque quantité source vers les EPP déficitaires (ordre repartitionParEpp), sans dépasser le déficit restant par destination.
 */
export function buildCreerDemandeSources(
  agregats: AgregatDeficitRow[],
  entries: MobilisationEntry[],
  engagedByCombo?: ReadonlyMap<string, number> | Readonly<Record<string, number>>
): V2SourcePayload[] {
  const v = validateMobilisationAgainstAgregat(agregats, entries, engagedByCombo)
  if (!v.ok) {
    throw new Error(v.message)
  }
  const byCombo = new Map<string, MobilisationEntry[]>()
  for (const e of entries) {
    if (e.quantite <= 0) continue
    const k = comboKey(e.matiereId, e.niveauId)
    const arr = byCombo.get(k) ?? []
    arr.push(e)
    byCombo.set(k, arr)
  }
  const sources: V2SourcePayload[] = []
  for (const [k, group] of byCombo) {
    const [ms, ns] = k.split("-")
    const matiereId = Number(ms)
    const niveauId = Number(ns)
    const agg = agregats.find((a) => a.matiereId === matiereId && a.niveauId === niveauId)
    if (!agg) continue
    const destRemaining = new Map<number, number>()
    for (const d of agg.repartitionParEpp) {
      if (d.eppId > 0 && d.deficit > 0) {
        destRemaining.set(d.eppId, d.deficit)
      }
    }
    const destOrder = agg.repartitionParEpp.filter((d) => d.deficit > 0 && d.eppId > 0).map((d) => d.eppId)
    if (destRemaining.size === 0) {
      throw new Error(
        "Aucune répartition déficit EPP pour une combinaison : impossible de construire les destinations. Vérifiez l’agrégat côté serveur."
      )
    }
    const sortedSources = [...group].sort((a, b) => b.quantite - a.quantite)
    for (const src of sortedSources) {
      let q = src.quantite
      if (q <= 0) continue
      for (const destId of destOrder) {
        if (q <= 0) break
        const rem = destRemaining.get(destId) ?? 0
        if (rem <= 0) continue
        const chunk = Math.min(q, rem)
        if (chunk > 0) {
          sources.push({
            structureSourceId: src.sourceEppId,
            structureDestId: destId,
            matiereId,
            niveauId,
            quantite: chunk,
          })
          destRemaining.set(destId, rem - chunk)
          q -= chunk
        }
      }
      if (q > 0) {
        throw new Error(
          "Capacité de destination insuffisante pour absorber les quantités mobilisées (déficits EPP inférieurs à la mobilisation)."
        )
      }
    }
  }
  return sources
}

/** Somme saisie pour une combinaison matière+niveau (pour affichage « reste »). */
export function mobilisedSumForCombo(entries: MobilisationEntry[], matiereId: number, niveauId: number): number {
  return entries.filter((e) => e.matiereId === matiereId && e.niveauId === niveauId).reduce((s, e) => s + e.quantite, 0)
}
