/**
 * Régulation v2 — ajustement des quantités avant exécution (aligné sur les règles backend).
 */

export type LigneV2AjustementContext = {
  id: number
  statut: string
  structureSourceId: number
  matiereId: number
  niveauId: number
  quantite: number
  quantiteAccordSource?: number | null
}

export type AjustementLignePayload = { ligneId: number; quantite: number }

export function plafondQuantiteAccordeeLigne(quantite: number, quantiteAccordSource: number | null | undefined): number {
  if (quantiteAccordSource != null) {
    return Math.max(0, quantiteAccordSource)
  }
  return Math.max(0, quantite)
}

function tripleKey(structureSourceId: number, matiereId: number, niveauId: number): string {
  return `${structureSourceId}|${matiereId}|${niveauId}`
}

/** Validation pure (client ou tests) — ne vérifie pas « plus de EN_ATTENTE » ni le rôle. */
export function validateAjustementsAvantEnvoi(
  lignes: LigneV2AjustementContext[],
  ajustements: AjustementLignePayload[],
  stockDisponibleByTriple: ReadonlyMap<string, number> | Readonly<Record<string, number>>
): { ok: true } | { ok: false; message: string } {
  const getStock = (key: string): number => {
    if (stockDisponibleByTriple instanceof Map) {
      return stockDisponibleByTriple.get(key) ?? 0
    }
    const v = (stockDisponibleByTriple as Readonly<Record<string, number>>)[key]
    return typeof v === "number" && Number.isFinite(v) ? v : 0
  }

  const byId = new Map<number, LigneV2AjustementContext>()
  for (const l of lignes) {
    byId.set(l.id, l)
  }

  const newQty = new Map<number, number>()
  for (const l of lignes) {
    if ((l.statut ?? "").trim().toUpperCase() === "ACCEPTE") {
      newQty.set(l.id, l.quantite)
    }
  }

  const seen = new Set<number>()
  for (const a of ajustements) {
    if (!Number.isFinite(a.ligneId) || a.ligneId <= 0) {
      return { ok: false, message: "ligneId invalide" }
    }
    if (!Number.isFinite(a.quantite) || a.quantite < 0 || !Number.isInteger(a.quantite)) {
      return { ok: false, message: "quantite invalide" }
    }
    if (seen.has(a.ligneId)) {
      return { ok: false, message: "ligneId dupliqué" }
    }
    seen.add(a.ligneId)
    const ligne = byId.get(a.ligneId)
    if (!ligne) {
      return { ok: false, message: "ligne inconnue" }
    }
    if ((ligne.statut ?? "").trim().toUpperCase() !== "ACCEPTE") {
      return { ok: false, message: "seules les lignes ACCEPTE sont ajustables" }
    }
    const plaf = plafondQuantiteAccordeeLigne(ligne.quantite, ligne.quantiteAccordSource)
    if (a.quantite > plaf) {
      return { ok: false, message: `dépassement plafond ligne ${a.ligneId} (max ${plaf})` }
    }
    newQty.set(a.ligneId, a.quantite)
  }

  const sumByTriple = new Map<string, number>()
  for (const l of lignes) {
    if ((l.statut ?? "").trim().toUpperCase() !== "ACCEPTE") continue
    const q = newQty.get(l.id)
    if (q == null) continue
    const k = tripleKey(l.structureSourceId, l.matiereId, l.niveauId)
    sumByTriple.set(k, (sumByTriple.get(k) ?? 0) + q)
  }

  for (const [key, sum] of sumByTriple) {
    const dispo = getStock(key)
    if (sum > dispo) {
      return { ok: false, message: `stock insuffisant pour ${key} (demandé ${sum}, dispo ${dispo})` }
    }
  }

  return { ok: true }
}
