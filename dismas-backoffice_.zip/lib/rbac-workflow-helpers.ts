/**
 * Aide au flux « rôle personnalisé + matrice RBAC » (tests + UI).
 * Les permissions session sont des clés {@code FONCTIONALITE:TYPE} en majuscules.
 */

export type MatrixRowInput = {
  code: string
  grantedPermissionTypes: string[]
}

/** Normalise le code rôle stocké côté API (stable, sans espaces). */
export function normalizeRoleCodeForStorage(raw: string | undefined | null): string {
  return (raw ?? "")
    .trim()
    .toUpperCase()
    .replace(/\s+/g, "_")
    .replace(/[^A-Z0-9_]/g, "_")
    .replace(/_+/g, "_")
    .replace(/^_|_$/g, "")
}

/**
 * Reproduit la forme des entrées {@code functionalityPermissions} utilisateur
 * à partir des lignes matrice (code fonctionnalité × types cochés).
 */
export function flattenMatrixRowsToFunctionalityPermissions(rows: MatrixRowInput[]): string[] {
  const out: string[] = []
  for (const r of rows) {
    const fc = (r.code ?? "").trim().toUpperCase()
    if (!fc) continue
    for (const p of r.grantedPermissionTypes ?? []) {
      const pt = (p ?? "").trim().toUpperCase()
      if (pt) out.push(`${fc}:${pt}`)
    }
  }
  return [...new Set(out)].sort((a, b) => a.localeCompare(b, "en"))
}
