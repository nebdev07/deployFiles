import { shouldScopeBesoinListByUserStructure } from "@/lib/utils/functionality-permissions"

/** Rôles qui consultent la liste des besoins au niveau national (pas de filtre SA du compte). */
const BESOIN_LIST_NATIONAL_SCOPE_ROLES = new Set(["DAF", "ADMIN", "CABINET", "DPFC"])

/**
 * Critères POST /besoin/getByCriteria selon le rôle (périmètre territorial DRENA).
 */

export type BesoinCriteriaRoleInput = {
  roleCode?: string
  /** structure_administrative.id du directeur */
  structureId?: number
  /** id entité drena (profil DRENA), aligné synthèse catalogue */
  drenaIdFromProfile?: number
  /** Clés {@code BESOIN:READ} etc. — aligné session utilisateur */
  functionalityPermissions?: string[]
}

export function buildBesoinGetByCriteriaPayload(input: BesoinCriteriaRoleInput): Record<string, unknown> {
  const criteria: Record<string, unknown> = {}
  const role = String(input.roleCode || "").toUpperCase()
  const isDrena = role === "DRENA"

  if (
    !isDrena &&
    !BESOIN_LIST_NATIONAL_SCOPE_ROLES.has(role) &&
    shouldScopeBesoinListByUserStructure(input.roleCode, input.functionalityPermissions) &&
    input.structureId != null &&
    input.structureId > 0
  ) {
    criteria.structureId = input.structureId
  }

  // DRENA: ne pas forcer structureId/drenaId côté client.
  // Le backend applique déjà le périmètre territorial via request.user.
  if (!isDrena && input.drenaIdFromProfile != null && input.drenaIdFromProfile > 0) {
    criteria.drenaId = input.drenaIdFromProfile
  }

  return criteria
}
