/**
 * Préfixes de chemins autorisés pour le rôle CABINET (navigation directe / bookmark).
 * Aligné sur `components/layout/sidebar.tsx` pour ce profil.
 */
const CABINET_ALLOWED_PREFIXES = [
  "/dashboard",
  "/planification",
  "/besoins",
  "/receptions",
  "/stocks",
  "/rapports",
  "/profil",
] as const

export function isCabinetAllowedPath(pathname: string | null | undefined): boolean {
  if (!pathname || pathname === "") return false
  const p = pathname.replace(/\/+$/, "") || "/"
  if (p === "/") return false
  return (CABINET_ALLOWED_PREFIXES as readonly string[]).some(
    (prefix) => p === prefix || p.startsWith(`${prefix}/`),
  )
}
