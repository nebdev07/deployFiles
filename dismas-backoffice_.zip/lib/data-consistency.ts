// ✅ SYSTÈME DE COHÉRENCE DES DONNÉES DISMAS
// Assure la correspondance entre Besoins, Stocks, Distribution et Retours

// =====================================
// STRUCTURES ADMINISTRATIVES UNIFIÉES
// =====================================

export const structures = {
  epp: [
    {
      code: "EPP-COC-01",
      libelle: "EPP Cocody Centre",
      type: "EPP",
      iepp_code: "IEPP-COC",
      iepp_libelle: "IEPP Cocody",
      drena_code: "DRENA-ABJ",
      drena_libelle: "DRENA Abidjan",
      directeur: "KOUADIO Adjoua"
    },
    {
      code: "EPP-COC-02", 
      libelle: "EPP Cocody Riviera",
      type: "EPP",
      iepp_code: "IEPP-COC",
      iepp_libelle: "IEPP Cocody",
      drena_code: "DRENA-ABJ",
      drena_libelle: "DRENA Abidjan",
      directeur: "DIABATE Aminata"
    },
    {
      code: "EPP-COC-03",
      libelle: "EPP Cocody Angré", 
      type: "EPP",
      iepp_code: "IEPP-COC",
      iepp_libelle: "IEPP Cocody",
      drena_code: "DRENA-ABJ",
      drena_libelle: "DRENA Abidjan",
      directeur: "KONE Ibrahim"
    },
    {
      code: "EPP-COC-04",
      libelle: "EPP Cocody Danga",
      type: "EPP", 
      iepp_code: "IEPP-COC",
      iepp_libelle: "IEPP Cocody",
      drena_code: "DRENA-ABJ",
      drena_libelle: "DRENA Abidjan",
      directeur: "OUATTARA Fatoumata"
    }
  ]
}

// =====================================
// CATALOGUE UNIFIÉ DES MANUELS
// =====================================

export const catalogueManuels = {
  CP1: [
    { code: "FR-CP1-001", titre: "Livre de Français CP1", matiere: "Français", prix_unitaire: 1500 },
    { code: "MA-CP1-001", titre: "Mathématiques CP1", matiere: "Mathématiques", prix_unitaire: 1500 },
    { code: "FR-CP1-002", titre: "Cahier d'Exercices Français CP1", matiere: "Français", prix_unitaire: 800 },
    { code: "MA-CP1-002", titre: "Cahier d'Exercices Mathématiques CP1", matiere: "Mathématiques", prix_unitaire: 800 }
  ],
  CP2: [
    { code: "FR-CP2-001", titre: "Français CP2", matiere: "Français", prix_unitaire: 1500 },
    { code: "MA-CP2-001", titre: "Mathématiques CP2", matiere: "Mathématiques", prix_unitaire: 1500 },
    { code: "FR-CP2-002", titre: "Cahier d'Exercices Français CP2", matiere: "Français", prix_unitaire: 800 },
    { code: "MA-CP2-002", titre: "Cahier d'Exercices Mathématiques CP2", matiere: "Mathématiques", prix_unitaire: 800 }
  ],
  CE1: [
    { code: "FR-CE1-001", titre: "Français CE1", matiere: "Français", prix_unitaire: 1600 },
    { code: "MA-CE1-001", titre: "Mathématiques CE1", matiere: "Mathématiques", prix_unitaire: 1600 },
    { code: "DM-CE1-001", titre: "Découverte du Monde CE1", matiere: "Découverte du Monde", prix_unitaire: 1400 }
  ],
  CE2: [
    { code: "FR-CE2-001", titre: "Français CE2", matiere: "Français", prix_unitaire: 1600 },
    { code: "MA-CE2-001", titre: "Mathématiques CE2", matiere: "Mathématiques", prix_unitaire: 1600 },
    { code: "HG-CE2-001", titre: "Histoire-Géographie CE2", matiere: "Histoire-Géographie", prix_unitaire: 1400 }
  ],
  CM1: [
    { code: "FR-CM1-001", titre: "Français CM1", matiere: "Français", prix_unitaire: 1700 },
    { code: "MA-CM1-001", titre: "Mathématiques CM1", matiere: "Mathématiques", prix_unitaire: 1700 },
    { code: "HG-CM1-001", titre: "Histoire-Géographie CM1", matiere: "Histoire-Géographie", prix_unitaire: 1500 },
    { code: "SC-CM1-001", titre: "Sciences CM1", matiere: "Sciences", prix_unitaire: 1500 }
  ],
  CM2: [
    { code: "FR-CM2-001", titre: "Français CM2", matiere: "Français", prix_unitaire: 1700 },
    { code: "MA-CM2-001", titre: "Mathématiques CM2", matiere: "Mathématiques", prix_unitaire: 1700 },
    { code: "HG-CM2-001", titre: "Histoire-Géographie CM2", matiere: "Histoire-Géographie", prix_unitaire: 1500 },
    { code: "SC-CM2-001", titre: "Sciences CM2", matiere: "Sciences", prix_unitaire: 1500 }
  ]
}

// =====================================
// DONNÉES COHÉRENTES ENTRE MODULES
// =====================================

// Référentiel central pour EPP Cocody (IEPP Cocody)
export const baseDataCocody = {
  // BESOINS EXPRIMÉS (source: Expression des Besoins)
  besoins: {
    "EPP-COC-01": {
      cp1: { effectifs: 40, manuels: ["FR-CP1-001", "MA-CP1-001", "FR-CP1-002", "MA-CP1-002"] },
      cp2: { effectifs: 39, manuels: ["FR-CP2-001", "MA-CP2-001", "FR-CP2-002", "MA-CP2-002"] },
      total_effectifs: 79,
      total_manuels: 316
    },
    "EPP-COC-02": {
      ce1: { effectifs: 53, manuels: ["FR-CE1-001", "MA-CE1-001", "DM-CE1-001"] },
      ce2: { effectifs: 51, manuels: ["FR-CE2-001", "MA-CE2-001", "HG-CE2-001"] },
      total_effectifs: 104, 
      total_manuels: 312
    },
    "EPP-COC-03": {
      cm1: { effectifs: 62, manuels: ["FR-CM1-001", "MA-CM1-001", "HG-CM1-001", "SC-CM1-001"] },
      cm2: { effectifs: 54, manuels: ["FR-CM2-001", "MA-CM2-001", "HG-CM2-001", "SC-CM2-001"] },
      total_effectifs: 116,
      total_manuels: 464
    },
    "EPP-COC-04": {
      cp1: { effectifs: 68, manuels: ["FR-CP1-001", "MA-CP1-001", "FR-CP1-002"] },
      total_effectifs: 68,
      total_manuels: 204
    }
  },

  // RETOURS (année précédente - base pour calculer les besoins nets)
  retours: {
    "EPP-COC-01": {
      "FR-CP1-001": { bon_etat: 35, moyen_etat: 8, mauvais_etat: 2, perdue: 0 },
      "MA-CP1-001": { bon_etat: 33, moyen_etat: 10, mauvais_etat: 2, perdue: 0 },
      "FR-CP1-002": { bon_etat: 38, moyen_etat: 5, mauvais_etat: 2, perdue: 0 },
      "MA-CP1-002": { bon_etat: 36, moyen_etat: 7, mauvais_etat: 2, perdue: 0 }
    },
    "EPP-COC-02": {
      "FR-CE1-001": { bon_etat: 48, moyen_etat: 12, mauvais_etat: 3, perdue: 0 },
      "MA-CE1-001": { bon_etat: 45, moyen_etat: 15, mauvais_etat: 3, perdue: 0 },
      "DM-CE1-001": { bon_etat: 50, moyen_etat: 8, mauvais_etat: 2, perdue: 0 }
    }
  },

  // STOCKS IEPP (après distribution - stocks restants)
  stocks_iepp: {
    "IEPP-COC": {
      "FR-CP1-001": { quantite: 1200, distribue: 800, reste: 400 },
      "MA-CP1-001": { quantite: 1200, distribue: 800, reste: 400 },
      "FR-CE1-001": { quantite: 800, distribue: 750, reste: 50 },
      "MA-CE1-001": { quantite: 800, distribue: 780, reste: 20 },
      "FR-CE2-001": { quantite: 600, distribue: 580, reste: 20 },
      "MA-CE2-001": { quantite: 600, distribue: 590, reste: 10 },
      "FR-CM1-001": { quantite: 500, distribue: 480, reste: 20 },
      "MA-CM1-001": { quantite: 500, distribue: 485, reste: 15 }
    }
  },

  // DISTRIBUTIONS (historique des distributions effectuées)
  distributions: {
    "EPP-COC-01": {
      cp1: {
        date: "2024-10-15",
        statut: "TERMINEE", 
        manuels: [
          { code: "FR-CP1-001", quantite_prevue: 40, quantite_distribuee: 40 },
          { code: "MA-CP1-001", quantite_prevue: 40, quantite_distribuee: 40 },
          { code: "FR-CP1-002", quantite_prevue: 40, quantite_distribuee: 40 },
          { code: "MA-CP1-002", quantite_prevue: 40, quantite_distribuee: 40 }
        ]
      }
    },
    "EPP-COC-02": {
      ce1: {
        date: "2024-10-18",
        statut: "EN_COURS",
        manuels: [
          { code: "FR-CE1-001", quantite_prevue: 53, quantite_distribuee: 53 },
          { code: "MA-CE1-001", quantite_prevue: 53, quantite_distribuee: 50 }, // 3 manquants
          { code: "DM-CE1-001", quantite_prevue: 53, quantite_distribuee: 53 }
        ]
      }
    }
  }
}

// =====================================
// FONCTIONS DE COHÉRENCE
// =====================================

// Calculer les besoins nets (besoins - retours réutilisables)
export function calculateBesoinNet(besoinBrut: number, retours: any, coefReparable: number = 0.7) {
  const retoursReutilisables = (retours?.bon_etat || 0) + ((retours?.moyen_etat || 0) * coefReparable)
  return Math.max(0, besoinBrut - retoursReutilisables)
}

// Obtenir la structure parente d'une EPP ou les EPP d'une IEPP
export function getStructureParente(code: string) {
  // Si c'est une EPP, retourner sa hiérarchie
  const epp = structures.epp.find(e => e.code === code)
  if (epp) {
    return {
      iepp: { code: epp.iepp_code, libelle: epp.iepp_libelle },
      drena: { code: epp.drena_code, libelle: epp.drena_libelle }
    }
  }
  
  // Si c'est une IEPP, retourner la première EPP pour obtenir la hiérarchie
  const firstEpp = structures.epp.find(e => e.iepp_code === code)
  if (firstEpp) {
    return {
      iepp: { code: firstEpp.iepp_code, libelle: firstEpp.iepp_libelle },
      drena: { code: firstEpp.drena_code, libelle: firstEpp.drena_libelle }
    }
  }
  
  return null
}

// Obtenir toutes les EPP d'une IEPP
export function getEPPsByIEPP(ieppCode: string) {
  return structures.epp.filter(e => e.iepp_code === ieppCode)
}

// Calculer le montant total d'une commande
export function calculateMontantTotal(manuels: Array<{code: string, quantite: number}>) {
  return manuels.reduce((total, manuel) => {
    const catalogueManuel = Object.values(catalogueManuels)
      .flat()
      .find(m => m.code === manuel.code)
    return total + (manuel.quantite * (catalogueManuel?.prix_unitaire || 0))
  }, 0)
}

// Vérifier la cohérence entre besoins et stocks
export function verifyStockCoherence(eppCode: string) {
  const structure = getStructureParente(eppCode)
  if (!structure) return { coherent: false, errors: ["Structure non trouvée"] }

  const besoins = baseDataCocody.besoins[eppCode as keyof typeof baseDataCocody.besoins]
  const stocks = baseDataCocody.stocks_iepp[structure.iepp.code as keyof typeof baseDataCocody.stocks_iepp]
  
  const errors: string[] = []
  
  // Vérifier si les stocks couvrent les besoins
  if (besoins && stocks) {
    // Logique de vérification ici
    if (besoins.total_manuels > Object.values(stocks).reduce((sum: number, stock: any) => sum + stock.reste, 0)) {
      errors.push("Stocks insuffisants pour couvrir les besoins")
    }
  }

  return { coherent: errors.length === 0, errors }
}