# Guide de Création d'Utilisateur - DISMAS

## Vue d'ensemble

Ce guide explique comment utiliser les nouvelles interfaces de création d'utilisateur qui prennent en compte les structures administratives (DRENA, IEPP, EPP) selon le contexte du système DISMAS.

## Interfaces Principales

### 1. `CreateUserRequest`
Interface pour la création d'utilisateur qui correspond aux champs attendus par le backend.

```typescript
interface CreateUserRequest {
  // Informations personnelles
  firstName: string;
  lastName: string;
  email: string;
  login: string;
  password?: string;
  fonction: string;
  telephone?: string;
  lieuFonction?: string;
  bornOn?: string;
  
  // Rôle et type d'utilisateur
  roleId: number;
  userType: string; // DRENA, IEPP, EPP, ADMIN, DAF
  
  // Structures administratives (selon le userType)
  drenaId?: number;
  drenaCode?: string;
  ieppId?: number;
  ieppCode?: string;
  eppId?: number;
  eppCode?: string;
  
  // Statut
  isLdapUser?: boolean;
  isActive?: boolean;
}
```

### 2. `User` (Interface mise à jour)
L'interface `User` a été étendue pour inclure les structures administratives.

```typescript
interface User extends BaseEntity {
  // ... champs existants ...
  
  // Structures administratives (selon le contexte)
  structureId?: number;
  userType?: string; // DRENA, IEPP, EPP, ADMIN, DAF
  
  // DRENA
  drenaId?: number;
  drenaCode?: string;
  
  // IEPP
  ieppId?: number;
  ieppCode?: string;
  
  // EPP
  eppId?: number;
  eppCode?: string;
}
```

### 3. `LegacyUser` (Interface mise à jour)
L'interface `LegacyUser` a été étendue pour inclure les structures administratives.

```typescript
interface LegacyUser {
  // ... champs existants ...
  
  drena?: {
    id: number;
    code: string;
    libelle: string;
  };
  iepp?: {
    id: number;
    code: string;
    libelle: string;
  };
  epp?: {
    id: number;
    code: string;
    libelle: string;
  };
}
```

## Fonctions Utilitaires

### 1. `buildCreateUserRequest`
Fonction principale pour valider et construire la requête de création d'utilisateur.

```typescript
function buildCreateUserRequest(
  userData: Partial<CreateUserRequest>,
  context: {
    roleCode: string;
    drenaId?: number;
    drenaCode?: string;
    ieppId?: number;
    ieppCode?: string;
    eppId?: number;
    eppCode?: string;
  }
): CreateUserRequest
```

### 2. `getUserTypeFromRole`
Détermine le type d'utilisateur basé sur le code du rôle.

```typescript
function getUserTypeFromRole(roleCode: string): string
```

### 3. `getRoleIdByCode`
Obtient l'ID du rôle basé sur le code.

```typescript
function getRoleIdByCode(roleCode: string): number
```

## Types d'Utilisateurs et Structures Requises

### 1. ADMIN / DAF
- **Structures requises** : Aucune
- **Exemple** :
```typescript
const adminUser = buildCreateUserRequest(
  {
    firstName: "Admin",
    lastName: "System",
    email: "admin@dismas.ci",
    login: "admin",
    fonction: "Administrateur Système"
  },
  { roleCode: "ADMIN" }
);
```

### 2. DRENA
- **Structures requises** : `drenaId`, `drenaCode`
- **Exemple** :
```typescript
const drenaUser = buildCreateUserRequest(
  {
    firstName: "Directeur",
    lastName: "Regional",
    email: "drena@dismas.ci",
    login: "drena",
    fonction: "Directeur Régional"
  },
  {
    roleCode: "DRENA",
    drenaId: 1,
    drenaCode: "DRENA-BOUAKE"
  }
);
```

### 3. IEPP
- **Structures requises** : `drenaId`, `drenaCode`, `ieppId`, `ieppCode`
- **Exemple** :
```typescript
const ieppUser = buildCreateUserRequest(
  {
    firstName: "Inspecteur",
    lastName: "Primaire",
    email: "iepp@dismas.ci",
    login: "iepp",
    fonction: "Inspecteur Enseignement Primaire"
  },
  {
    roleCode: "IEPP",
    drenaId: 1,
    drenaCode: "DRENA-BOUAKE",
    ieppId: 1,
    ieppCode: "IEPP-BOUAKE-01"
  }
);
```

### 4. EPP (Directeur d'école)
- **Structures requises** : `drenaId`, `drenaCode`, `ieppId`, `ieppCode`, `eppId`, `eppCode`
- **Exemple** :
```typescript
const eppUser = buildCreateUserRequest(
  {
    firstName: "Directeur",
    lastName: "Ecole",
    email: "epp@dismas.ci",
    login: "epp",
    fonction: "Directeur d'École"
  },
  {
    roleCode: "DIRECTEUR",
    drenaId: 1,
    drenaCode: "DRENA-BOUAKE",
    ieppId: 1,
    ieppCode: "IEPP-BOUAKE-01",
    eppId: 1,
    eppCode: "EPP-BOUAKE-001"
  }
);
```

## Validation et Gestion d'Erreurs

La fonction `buildCreateUserRequest` valide automatiquement :

1. **Champs obligatoires** : `firstName`, `lastName`, `email`, `login`, `fonction`
2. **Structures selon le type** : Vérifie que les structures requises sont fournies
3. **Cohérence des données** : S'assure que les IDs et codes correspondent

### Exemple de gestion d'erreur :
```typescript
try {
  const userRequest = buildCreateUserRequest(userData, context);
  // Utiliser userRequest...
} catch (error) {
  console.error("Erreur de validation:", error.message);
  // Afficher l'erreur à l'utilisateur
}
```

## Utilisation dans les Composants React

### Exemple avec le composant `UserCreationForm` :

```typescript
import UserCreationForm from '@/components/examples/UserCreationForm';

function CreateUserPage() {
  const handleSubmit = (userData: CreateUserRequest) => {
    // Envoyer les données au backend
    console.log('Données utilisateur:', userData);
  };

  return (
    <UserCreationForm
      roleCode="IEPP"
      context={{
        drenaId: 1,
        drenaCode: "DRENA-BOUAKE",
        ieppId: 1,
        ieppCode: "IEPP-BOUAKE-01"
      }}
      onSubmit={handleSubmit}
    />
  );
}
```

## Correspondance avec le Backend

Les champs de `CreateUserRequest` correspondent exactement aux champs attendus par le backend :

- `firstName` → `firstName`
- `lastName` → `lastName`
- `email` → `email`
- `login` → `login`
- `password` → `password`
- `fonction` → `fonction`
- `telephone` → `telephone`
- `lieuFonction` → `lieuFonction`
- `bornOn` → `bornOn`
- `roleId` → `roleId`
- `userType` → `userType`
- `drenaId` → `drenaId`
- `drenaCode` → `drenaCode`
- `ieppId` → `ieppId`
- `ieppCode` → `ieppCode`
- `eppId` → `eppId`
- `eppCode` → `eppCode`
- `isLdapUser` → `isLdapUser`
- `isActive` → `isActive`

## Migration et Compatibilité

Les nouvelles interfaces sont rétrocompatibles :

1. **Conversion automatique** : `convertUserToLegacyUser` et `convertLegacyUserToUser` gèrent les nouvelles structures
2. **Champs optionnels** : Tous les nouveaux champs sont optionnels pour éviter les régressions
3. **Validation progressive** : La validation s'adapte selon le type d'utilisateur

## Exemples Complets

Voir le fichier `lib/examples/user-creation-examples.ts` pour des exemples complets d'utilisation de chaque type d'utilisateur.