// Script Puppeteer final - Plus simple et léger que Playwright
const puppeteer = require('puppeteer');
const fs = require('fs');
const path = require('path');

const users = [
  { role: 'ADMIN', login: 'admin', password: 'admin123' },
  { role: 'DAF', login: 'daf.kouame', password: 'daf123' },
  { role: 'DRENA', login: 'drena.kone', password: 'drena123' },
  { role: 'IEPP', login: 'iepp.assi', password: 'iepp123' },
  { role: 'DIRECTEUR', login: 'dir.kouadio', password: 'dir123' }
];

const pages = {
  ADMIN: ['/dashboard', '/besoins', '/commandes', '/admin'],
  DAF: ['/dashboard', '/besoins', '/commandes'],
  DRENA: ['/dashboard', '/besoins', '/commandes'],
  IEPP: ['/dashboard', '/besoins', '/distribution'],
  DIRECTEUR: ['/dashboard', '/besoins', '/commandes', '/admin']
};

async function captureWithPuppeteer() {
  console.log('🚀 CAPTURE AUTOMATIQUE AVEC PUPPETEER');
  console.log('⚡ Plus léger que Playwright, utilise Chrome installé\n');

  // Créer dossier
  const capturesDir = './captures';
  if (!fs.existsSync(capturesDir)) {
    fs.mkdirSync(capturesDir);
    console.log('📁 Dossier captures créé\n');
  }

  const browser = await puppeteer.launch({ 
    headless: false,  // Mode visible
    defaultViewport: { width: 1920, height: 1080 },
    slowMo: 100
  });

  console.log('✅ Navigateur Puppeteer lancé\n');

  for (let i = 0; i < users.length; i++) {
    const user = users[i];
    console.log(`${'='.repeat(60)}`);
    console.log(`🔐 [${i + 1}/${users.length}] RÔLE: ${user.role}`);
    console.log(`${'='.repeat(60)}`);

    const page = await browser.newPage();

    try {
      // Navigation et connexion
      console.log('🌐 Navigation vers la page de login...');
      await page.goto('http://localhost:3000', { waitUntil: 'domcontentloaded' });
      await page.waitForTimeout(3000);

      // Remplir les champs
      console.log(`🔑 Connexion avec ${user.login}...`);
      
      // Attendre les champs de saisie
      await page.waitForSelector('input', { timeout: 10000 });
      
      const inputs = await page.$$('input');
      if (inputs.length >= 2) {
        await inputs[0].type(user.login, { delay: 50 });
        await inputs[1].type(user.password, { delay: 50 });
        console.log('✅ Champs remplis');
      }

      // Cliquer sur le bouton
      const buttons = await page.$$('button');
      if (buttons.length > 0) {
        await buttons[0].click();
        console.log('✅ Bouton cliqué');
      }

      // Attendre la redirection
      await page.waitForTimeout(4000);
      console.log(`📍 URL: ${page.url()}`);

      // Capturer les pages
      const userPages = pages[user.role] || ['/dashboard'];
      console.log(`📸 ${userPages.length} pages à capturer\n`);

      for (let j = 0; j < userPages.length; j++) {
        const pagePath = userPages[j];
        console.log(`   [${j + 1}/${userPages.length}] ${pagePath}...`);

        try {
          await page.goto(`http://localhost:3000${pagePath}`, { waitUntil: 'domcontentloaded' });
          await page.waitForTimeout(3000);

          // Scroll vers le haut
          await page.evaluate(() => window.scrollTo(0, 0));
          await page.waitForTimeout(500);

          const filename = `${user.role}_${pagePath.replace('/', '') || 'home'}.png`;
          await page.screenshot({ 
            path: path.join(capturesDir, filename),
            fullPage: true
          });

          console.log(`   ✅ ${filename}`);
        } catch (error) {
          console.log(`   ❌ Erreur sur ${pagePath}: ${error.message}`);
        }
      }

      console.log(`✅ Terminé pour ${user.role}\n`);

    } catch (error) {
      console.log(`❌ Erreur ${user.role}: ${error.message}\n`);
    } finally {
      await page.close();
    }
  }

  await browser.close();
  console.log('🎉 TOUTES LES CAPTURES TERMINÉES!');
  console.log('📁 Vérifiez le dossier ./captures');
}

captureWithPuppeteer().catch(error => {
  console.error('💥 Erreur:', error.message);
  console.log('📧 Envoyez-moi cette erreur si elle persiste!');
});