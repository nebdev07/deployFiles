// Script de debug ultra-simple pour identifier le problème
console.log('🔬 SCRIPT DE DEBUG DISMAS');
console.log('='.repeat(50));

// Test 1: Vérification de Playwright
console.log('1️⃣ Test installation Playwright...');
try {
  const { chromium } = require('playwright');
  console.log('✅ Playwright installé correctement');
} catch (error) {
  console.log('❌ Playwright non installé ou erreur:');
  console.log('   ', error.message);
  console.log('📋 Exécutez: npm install -D @playwright/test');
  process.exit(1);
}

// Test 2: Vérification de l'application
console.log('\n2️⃣ Test accès application...');
const http = require('http');

function checkApp() {
  return new Promise((resolve) => {
    const req = http.get('http://localhost:3000', (res) => {
      console.log('✅ Application accessible sur port 3000');
      console.log(`   Status: ${res.statusCode}`);
      resolve(true);
    });
    
    req.on('error', (error) => {
      console.log('❌ Application NON accessible sur port 3000');
      console.log('   Erreur:', error.code);
      console.log('📋 Dans un autre terminal, exécutez: npm run dev');
      resolve(false);
    });
    
    req.setTimeout(3000, () => {
      console.log('❌ Timeout - Application ne répond pas');
      req.destroy();
      resolve(false);
    });
  });
}

// Test 3: Test création dossier
console.log('\n3️⃣ Test création dossier...');
const fs = require('fs');
const path = require('path');

try {
  const capturesDir = './captures-test';
  if (!fs.existsSync(capturesDir)) {
    fs.mkdirSync(capturesDir);
    console.log('✅ Dossier captures-test créé');
  } else {
    console.log('✅ Dossier captures-test existe déjà');
  }
  
  // Test écriture fichier
  const testFile = path.join(capturesDir, 'test.txt');
  fs.writeFileSync(testFile, 'Test de création de fichier');
  console.log('✅ Test écriture fichier réussi');
  
  // Nettoyage
  fs.unlinkSync(testFile);
  fs.rmdirSync(capturesDir);
  console.log('✅ Nettoyage effectué');
  
} catch (error) {
  console.log('❌ Erreur création dossier/fichier:');
  console.log('   ', error.message);
}

// Test 4: Vérification du répertoire de travail
console.log('\n4️⃣ Informations répertoire...');
console.log('📁 Répertoire actuel:', process.cwd());
console.log('📁 Répertoire script:', __dirname);

// Test 5: Test Playwright minimal si app accessible
async function testMinimal() {
  console.log('\n5️⃣ Test Playwright minimal...');
  
  const appAccessible = await checkApp();
  if (!appAccessible) {
    console.log('⏭️  Test Playwright ignoré (app non accessible)');
    return;
  }
  
  try {
    const { chromium } = require('playwright');
    console.log('   🚀 Lancement navigateur...');
    
    const browser = await chromium.launch({ 
      headless: false,
      timeout: 30000
    });
    console.log('   ✅ Navigateur lancé');
    
    const page = await browser.newPage();
    console.log('   ✅ Page créée');
    
    await page.goto('http://localhost:3000', { timeout: 10000 });
    console.log('   ✅ Navigation réussie');
    
    // Test capture
    await page.screenshot({ path: './test-debug.png' });
    console.log('   ✅ Capture test créée: test-debug.png');
    
    await browser.close();
    console.log('   ✅ Navigateur fermé');
    
    console.log('\n🎉 TOUS LES TESTS PASSENT!');
    console.log('➡️  Le script principal devrait fonctionner');
    
  } catch (error) {
    console.log('   ❌ Erreur Playwright:');
    console.log('     ', error.message);
    if (error.stack) {
      console.log('   📋 Stack trace:');
      console.log('     ', error.stack.split('\n').slice(0, 3).join('\n     '));
    }
  }
}

// Exécution
async function runDebug() {
  await testMinimal();
  
  console.log('\n' + '='.repeat(50));
  console.log('🏁 DEBUG TERMINÉ');
  console.log('📧 Envoyez-moi TOUT ce texte si des erreurs persistent');
  console.log('='.repeat(50));
}

runDebug().catch(error => {
  console.error('\n💥 ERREUR FATALE DEBUG:');
  console.error(error);
  console.log('\n📧 ENVOYEZ-MOI CETTE ERREUR COMPLÈTE!');
});