// Script d'assistance pour captures manuelles
// Ouvre automatiquement les bonnes pages, vous n'avez qu'à faire les captures

const { chromium } = require('playwright');

const scenarios = [
  { role: 'ADMIN', login: 'admin', password: 'admin123', pages: ['/dashboard', '/besoins', '/commandes'] },
  { role: 'DAF', login: 'daf.kouame', password: 'daf123', pages: ['/dashboard', '/commandes'] },
  { role: 'DRENA', login: 'drena.kone', password: 'drena123', pages: ['/dashboard', '/besoins', '/commandes'] },
  { role: 'IEPP', login: 'iepp.assi', password: 'iepp123', pages: ['/dashboard', '/besoins', '/distribution'] },
  { role: 'DIRECTEUR', login: 'dir.kouadio', password: 'dir123', pages: ['/dashboard', '/besoins', '/commandes'] }
];

async function assistCapture() {
  console.log('🎯 ASSISTANT CAPTURE MANUELLE');
  console.log('📸 Le navigateur va s\'ouvrir et naviguer automatiquement');
  console.log('👨‍💻 Vous n\'avez qu\'à faire les captures d\'écran manuellement!');
  console.log('\n⏰ Démarrage dans 3 secondes...\n');
  
  await new Promise(resolve => setTimeout(resolve, 3000));
  
  const browser = await chromium.launch({ 
    headless: false,
    slowMo: 1000  // Très lent pour vous laisser le temps
  });

  for (const scenario of scenarios) {
    console.log(`\n${'='.repeat(50)}`);
    console.log(`🔐 RÔLE: ${scenario.role}`);
    console.log(`🔑 Login: ${scenario.login} / Password: ${scenario.password}`);
    console.log(`${'='.repeat(50)}`);
    
    const page = await browser.newPage();
    await page.setViewportSize({ width: 1920, height: 1080 });
    
    try {
      // Aller à la page de login
      console.log('🌐 Navigation vers la page de login...');
      await page.goto('http://localhost:3000');
      await page.waitForTimeout(2000);
      
      console.log('⚠️  FAITES LA CONNEXION MANUELLEMENT!');
      console.log(`   Login: ${scenario.login}`);
      console.log(`   Password: ${scenario.password}`);
      
      // Attendre que l'utilisateur se connecte manuellement
      console.log('⏳ Attendez que vous soyez connecté, puis appuyez sur ENTRÉE...');
      await new Promise(resolve => {
        process.stdin.once('data', () => resolve());
      });
      
      // Naviguer sur chaque page
      for (let i = 0; i < scenario.pages.length; i++) {
        const pagePath = scenario.pages[i];
        console.log(`\n📱 [${i + 1}/${scenario.pages.length}] Navigation vers: ${pagePath}`);
        
        await page.goto(`http://localhost:3000${pagePath}`);
        await page.waitForTimeout(3000);
        
        console.log(`📸 CAPTURE MAINTENANT: ${scenario.role}_${pagePath.replace('/', '')}`);
        console.log('⏳ Appuyez sur ENTRÉE quand la capture est faite...');
        
        await new Promise(resolve => {
          process.stdin.once('data', () => resolve());
        });
      }
      
      console.log(`✅ Terminé pour ${scenario.role}`);
      
    } catch (error) {
      console.log(`❌ Erreur: ${error.message}`);
    }
    
    await page.close();
  }
  
  await browser.close();
  console.log('\n🎉 TOUTES LES CAPTURES TERMINÉES!');
}

assistCapture().catch(console.error);