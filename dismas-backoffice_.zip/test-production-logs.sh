#!/bin/bash

# ============================================
# Script de Test - Logs en Production
# ============================================

echo "🧪 Test de sécurisation des logs - DISMAS Frontend"
echo "=================================================="
echo ""

# Couleurs
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Fonction de test
test_step() {
    echo -e "${YELLOW}▶ $1${NC}"
}

success() {
    echo -e "${GREEN}✅ $1${NC}"
}

error() {
    echo -e "${RED}❌ $1${NC}"
}

# Test 1: Vérifier l'existence du logger
test_step "1. Vérification du logger..."
if [ -f "lib/utils/logger.ts" ]; then
    success "Logger trouvé"
else
    error "Logger non trouvé!"
    exit 1
fi

# Test 2: Vérifier la configuration
test_step "2. Vérification de la configuration..."
if [ -f "next.config.mjs" ]; then
    success "next.config.mjs configuré"
else
    error "next.config.mjs manquant"
fi

# Test 3: Créer .env.production si nécessaire
test_step "3. Vérification .env.production..."
if [ ! -f ".env.production" ]; then
    echo "Création de .env.production depuis le template..."
    if [ -f ".env.production.example" ]; then
        cp .env.production.example .env.production
        success ".env.production créé"
    else
        error ".env.production.example manquant"
    fi
else
    success ".env.production existe déjà"
fi

# Test 4: Build de test
test_step "4. Build de production..."
echo "⏳ Building... (cela peut prendre quelques secondes)"
if npm run build > /dev/null 2>&1; then
    success "Build réussi"
else
    error "Build échoué"
    exit 1
fi

# Test 5: Vérifier que la page de test existe
test_step "5. Vérification page de test..."
if [ -d "app/test-logging" ]; then
    success "Page de test disponible à /test-logging"
    echo "   👉 Testez manuellement: http://localhost:3000/test-logging"
else
    error "Page de test non trouvée"
fi

echo ""
echo "=================================================="
echo "🎯 Tests terminés!"
echo ""
echo "📋 Prochaines étapes:"
echo "   1. npm run start"
echo "   2. Ouvrir http://localhost:3000/test-logging"
echo "   3. Ouvrir Console (F12)"
echo "   4. Vérifier qu'aucun log n'apparaît (sauf erreurs)"
echo ""
echo "⚠️  Avant déploiement final:"
echo "   rm -rf app/test-logging"
echo "=================================================="















