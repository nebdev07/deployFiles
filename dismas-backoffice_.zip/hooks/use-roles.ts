/**
 * Hook personnalisé pour la gestion des rôles
 * Charge et gère l'état des rôles depuis le backend
 */

import { logger } from '@/lib/utils/logger'

import { useState, useEffect, useCallback } from 'react';
import { rolesService, Role, RoleFilters } from '@/lib/services/roles.service';
import { getThrownErrorMessage } from '@/lib/utils/api-permission-errors';

export interface UseRolesReturn {
  roles: Role[];
  loading: boolean;
  error: string | null;
  loadRoles: (filters?: RoleFilters) => Promise<void>;
  getRoleById: (id: number) => Role | undefined;
  getRoleByCode: (code: string) => Role | undefined;
  refreshRoles: () => Promise<void>;
}

export function useRoles(): UseRolesReturn {
  const [roles, setRoles] = useState<Role[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Charger tous les rôles
  const loadRoles = useCallback(async (filters?: RoleFilters) => {
    try {
      setLoading(true);
      setError(null);
      const response = await rolesService.getRoles(filters);
      if (response.items) {
        // S'assurer que response.items est un tableau plat
        let rolesTemp: any[] = [];
        if (Array.isArray(response.items)) {
          // Si c'est un tableau, vérifier s'il contient des tableaux imbriqués
          if (response.items.length > 0 && Array.isArray(response.items[0])) {
            // Aplatir le tableau de tableaux
            rolesTemp = (response.items as unknown as any[]).flat();
          } else {
            rolesTemp = (response.items as unknown as any[]);
          }
        }
        
        // Convertir explicitement en Role[]
        const roles: Role[] = rolesTemp as unknown as Role[];
        
        setRoles(roles);
      }
    } catch (err: unknown) {
      logger.error('Erreur lors du chargement des rôles:', err);
      const api = err as { code?: string; message?: string };

      const msg = getThrownErrorMessage(err, '');

      // Si c'est une erreur de token invalide ou session expirée, ne pas afficher d'erreur
      // car l'utilisateur sera automatiquement déconnecté
      if (api.code === '900' && (msg.includes('Token invalide') || msg.includes('Session expirée'))) {
        return;
      }

      // Si c'est une erreur d'utilisateur non connecté, ne pas afficher d'erreur
      if (msg === 'Utilisateur non connecté') {
        return;
      }

      setError(getThrownErrorMessage(err, 'Erreur lors du chargement des rôles'));
    } finally {
      setLoading(false);
    }
  }, []);

  // Récupérer un rôle par ID
  const getRoleById = useCallback((id: number): Role | undefined => {
    return roles.find(role => role.id === id);
  }, [roles]);

  // Récupérer un rôle par code
  const getRoleByCode = useCallback((code: string): Role | undefined => {
    return roles.find(role => role.code === code);
  }, [roles]);

  // Rafraîchir les rôles
  const refreshRoles = useCallback(async () => {
    await loadRoles({ isActive: true });
  }, [loadRoles]);

  // Charger les rôles au montage du composant seulement si l'utilisateur est connecté
  useEffect(() => {
    // Vérifier si l'utilisateur est connecté avant de charger les rôles
    if (typeof window !== 'undefined') {
      const userSession = localStorage.getItem('dismas_user') || localStorage.getItem('user_session');
      const authToken = localStorage.getItem('auth_token');
      
      logger.log('useRoles - Vérification de connexion:', {
        userSession: !!userSession,
        authToken: !!authToken,
        userSessionContent: userSession ? JSON.parse(userSession) : null
      });
      
      if (userSession && authToken) {
        logger.log('useRoles - Chargement des rôles...');
        loadRoles({ isActive: true });
      } else {
        logger.log('useRoles - Utilisateur non connecté, pas de chargement des rôles');
      }
    }
  }, [loadRoles]);

  return {
    roles,
    loading,
    error,
    loadRoles,
    getRoleById,
    getRoleByCode,
    refreshRoles
  };
}