/**
 * Hook personnalisé pour la gestion des matières
 * Suit le même pattern que use-users.ts
 */

import { useState, useCallback, useEffect } from 'react';
import { Matiere, MatiereFilters } from '@/lib/types/entities';
import { matiereService } from '@/lib/services/matiere.service';
import toast from 'react-hot-toast';

interface UseMatiereState {
  matieres: Matiere[];
  loading: boolean;
  error: string | null;
  currentPage: number;
  totalPages: number;
  pageSize: number;
  totalCount: number;
}

interface UseMatiereActions {
  getMatieres: (filters?: MatiereFilters) => Promise<void>;
  searchMatieres: (searchTerm: string) => Promise<void>;
  refreshMatieres: () => Promise<void>;
  setPage: (page: number) => void;
  setPageSize: (size: number) => void;
  clearError: () => void;
}

/** Si `onlyActive`, charge uniquement les matières avec isActif = true (API `getActivesMatieres`). */
export function useMatieres(options?: { onlyActive?: boolean }): UseMatiereState & UseMatiereActions {
  const onlyActive = options?.onlyActive === true
  const [state, setState] = useState<UseMatiereState>({
    matieres: [],
    loading: false,
    error: null,
    currentPage: 1,
    totalPages: 1,
    pageSize: 10,
    totalCount: 0,
  });

  const [currentFilters, setCurrentFilters] = useState<MatiereFilters | undefined>();

  // Fonction pour récupérer les matières avec gestion d'erreur
  const getMatieres = useCallback(async (filters?: MatiereFilters) => {
    try {
      setState(prev => ({ ...prev, loading: true, error: null }));
      setCurrentFilters(filters);
      
      const response = onlyActive
        ? await matiereService.getActivesMatieres()
        : await matiereService.getMatieres(filters);
      
      if (response.hasError) {
        throw new Error(response.status?.message || 'Erreur lors du chargement des matières');
      }
      
      // S'assurer que response.items est un tableau plat
      let matieresTemp: any[] = [];
      if (response.items) {
        if (Array.isArray(response.items)) {
          // Si c'est un tableau, vérifier s'il contient des tableaux imbriqués
          if (response.items.length > 0 && Array.isArray(response.items[0])) {
            // Aplatir le tableau de tableaux
            matieresTemp = (response.items as unknown as any[]).flat();
          } else {
            matieresTemp = (response.items as unknown as any[]);
          }
        }
      }
      
      // Convertir explicitement en Matiere[]
      const matieres: Matiere[] = matieresTemp as unknown as Matiere[];
      
      setState(prev => ({
        ...prev,
        matieres,
        totalCount: matieres.length,
        totalPages: Math.ceil(matieres.length / prev.pageSize),
        loading: false,
        error: null,
      }));
      
    } catch (error) {
      console.error('Erreur lors du chargement des matières:', error);
      const errorMessage = error instanceof Error ? error.message : 'Erreur inconnue';
      
      setState(prev => ({
        ...prev,
        matieres: [],
        loading: false,
        error: errorMessage,
      }));
      
      toast.error(`Erreur de chargement: ${errorMessage}`);
    }
  }, [onlyActive]);

  // Fonction de recherche
  const searchMatieres = useCallback(async (searchTerm: string) => {
    if (!searchTerm.trim()) {
      return getMatieres(currentFilters);
    }
    
    try {
      setState(prev => ({ ...prev, loading: true, error: null }));
      
      const response = await matiereService.searchMatieres(searchTerm);
      
      if (response.hasError) {
        throw new Error(response.status?.message || 'Erreur lors de la recherche');
      }
      
      // S'assurer que response.items est un tableau plat
      let matieresTemp: any[] = [];
      if (response.items) {
        if (Array.isArray(response.items)) {
          // Si c'est un tableau, vérifier s'il contient des tableaux imbriqués
          if (response.items.length > 0 && Array.isArray(response.items[0])) {
            // Aplatir le tableau de tableaux
            matieresTemp = (response.items as unknown as any[]).flat();
          } else {
            matieresTemp = (response.items as unknown as any[]);
          }
        }
      }
      
      // Convertir explicitement en Matiere[]
      const matieres: Matiere[] = matieresTemp as unknown as Matiere[];
      
      setState(prev => ({
        ...prev,
        matieres,
        totalCount: matieres.length,
        totalPages: Math.ceil(matieres.length / prev.pageSize),
        loading: false,
        error: null,
      }));
      
    } catch (error) {
      console.error('Erreur lors de la recherche des matières:', error);
      const errorMessage = error instanceof Error ? error.message : 'Erreur de recherche';
      
      setState(prev => ({
        ...prev,
        loading: false,
        error: errorMessage,
      }));
      
      toast.error(`Erreur de recherche: ${errorMessage}`);
    }
  }, [currentFilters, getMatieres]);

  // Fonction pour rafraîchir les données
  const refreshMatieres = useCallback(async () => {
    return getMatieres(currentFilters);
  }, [getMatieres, currentFilters]);

  // Fonction pour changer de page
  const setPage = useCallback((page: number) => {
    setState(prev => ({
      ...prev,
      currentPage: Math.max(1, Math.min(page, prev.totalPages)),
    }));
  }, []);

  // Fonction pour changer la taille de page
  const setPageSize = useCallback((size: number) => {
    setState(prev => ({
      ...prev,
      pageSize: Math.max(5, Math.min(size, 100)),
      currentPage: 1,
      totalPages: Math.ceil(prev.totalCount / size),
    }));
  }, []);

  // Fonction pour effacer les erreurs
  const clearError = useCallback(() => {
    setState(prev => ({ ...prev, error: null }));
  }, []);

  // Chargement initial des matières
  useEffect(() => {
    getMatieres();
  }, [getMatieres]);

  return {
    // État
    matieres: state.matieres,
    loading: state.loading,
    error: state.error,
    currentPage: state.currentPage,
    totalPages: state.totalPages,
    pageSize: state.pageSize,
    totalCount: state.totalCount,
    
    // Actions
    getMatieres,
    searchMatieres,
    refreshMatieres,
    setPage,
    setPageSize,
    clearError,
  };
}

// Hook séparé pour les opérations CRUD (création, modification, suppression)
export function useMatiereOperations() {
  const [loading, setLoading] = useState(false);
  
  // Créer une matière
  const createMatiere = useCallback(async (matiereData: { code: string; libelle: string; description?: string; isActif?: boolean }) => {
    try {
      setLoading(true);
      
      // Vérifier si le code existe déjà
      const codeExists = await matiereService.checkCodeExists(matiereData.code);
      if (codeExists) {
        toast.error('Ce code matière existe déjà. Veuillez en choisir un autre.');
        return { success: false, error: 'Code déjà existant' };
      }
      
      const response = await matiereService.createMatiere(matiereData);
      
      if (response.hasError) {
        throw new Error(response.status?.message || 'Erreur lors de la création');
      }
      
      toast.success('Matière créée avec succès !');
      return { success: true, data: response.items?.[0] };
      
    } catch (error) {
      console.error('Erreur lors de la création de la matière:', error);
      const errorMessage = error instanceof Error ? error.message : 'Erreur inconnue';
      toast.error(`Erreur de création: ${errorMessage}`);
      return { success: false, error: errorMessage };
    } finally {
      setLoading(false);
    }
  }, []);
  
  // Modifier une matière
  const updateMatiere = useCallback(async (id: number, matiereData: { code: string; libelle: string; description?: string; isActif?: boolean }) => {
    try {
      setLoading(true);

      const response = await matiereService.updateMatiere(id, matiereData);
      
      if (response.hasError) {
        throw new Error(response.status?.message || 'Erreur lors de la modification');
      }
      
      toast.success('Matière modifiée avec succès !');
      return { success: true, data: response.items?.[0] };
      
    } catch (error) {
      console.error('Erreur lors de la modification de la matière:', error);
      const errorMessage = error instanceof Error ? error.message : 'Erreur inconnue';
      toast.error(`Erreur de modification: ${errorMessage}`);
      return { success: false, error: errorMessage };
    } finally {
      setLoading(false);
    }
  }, []);
  
  // Supprimer une matière
  const deleteMatiere = useCallback(async (id: number) => {
    try {
      setLoading(true);
      
      const response = await matiereService.deleteMatiere(id);
      
      if (response.hasError) {
        throw new Error(response.status?.message || 'Erreur lors de la suppression');
      }
      
      toast.success('Matière supprimée avec succès !');
      return { success: true };
      
    } catch (error) {
      console.error('Erreur lors de la suppression de la matière:', error);
      const errorMessage = error instanceof Error ? error.message : 'Erreur inconnue';
      toast.error(`Erreur de suppression: ${errorMessage}`);
      return { success: false, error: errorMessage };
    } finally {
      setLoading(false);
    }
  }, []);
  
  return {
    loading,
    createMatiere,
    updateMatiere,
    deleteMatiere,
  };
}
