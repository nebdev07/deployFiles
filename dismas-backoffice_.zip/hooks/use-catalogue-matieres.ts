import { useState, useEffect, useRef } from 'react'
import { catalogueMatiereService } from '@/lib/services/catalogue-matiere.service'
import { CatalogueMatiere, CatalogueMatiereFilters } from '@/lib/types/entities'
import toast from 'react-hot-toast'

/**
 * Hook pour récupérer les associations catalogue-matière
 */
export function useCatalogueMatieres(filters?: CatalogueMatiereFilters) {
  const [catalogueMatieres, setCatalogueMatieres] = useState<CatalogueMatiere[]>([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const fetchCatalogueMatieres = async () => {
    setLoading(true)
    setError(null)
    
    try {
      const response = await catalogueMatiereService.getCatalogueMatieres(filters)
      if (!response.hasError && response.items) {
        // Traitement simple des données avec assertion de type
        setCatalogueMatieres((response.items as any) || [])
      } else {
        setError(response.status.message || 'Erreur lors du chargement des associations')
      }
    } catch (err) {
      console.error('Erreur lors du chargement des associations catalogue-matière:', err)
      setError('Erreur lors du chargement des associations')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchCatalogueMatieres()
  }, [filters?.catalogueId, filters?.matiereId])

  return {
    catalogueMatieres,
    loading,
    error,
    refresh: fetchCatalogueMatieres
  }
}

/**
 * Hook pour récupérer les matières associées à un catalogue spécifique
 */
export function useMatieresByCatalogue(catalogueId?: number) {
  const [matieres, setMatieres] = useState<CatalogueMatiere[]>([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const currentRequestIdRef = useRef<string | null>(null)

  const fetchMatieresByCatalogue = async (id?: number) => {
    const targetId = id || catalogueId
    if (!targetId) {
      setMatieres([])
      return
    }

    const requestId = `${targetId}-${Date.now()}`
    currentRequestIdRef.current = requestId
    setLoading(true)
    setError(null)
    
    try {
      const response = await catalogueMatiereService.getMatieresByCatalogueId(targetId)
      
      if (currentRequestIdRef.current !== requestId) {
        // A newer request has started; ignore this response
        return
      }
      
      if (!response.hasError && response.items) {
        setMatieres((response.items as any) || [])
      } else {
        setError(response.status?.message || 'Erreur lors du chargement des matières')
      }
    } catch (err) {
      if (currentRequestIdRef.current !== requestId) {
        return
      }
      console.error('Erreur lors du chargement des matières du catalogue:', err)
      setError('Erreur lors du chargement des matières')
    } finally {
      if (currentRequestIdRef.current === requestId) {
        setLoading(false)
        currentRequestIdRef.current = null
      }
    }
  }

  useEffect(() => {
    fetchMatieresByCatalogue()
  }, [catalogueId])

  const resetMatieres = () => {
    setMatieres([])
    setError(null)
    setLoading(false)
    currentRequestIdRef.current = null
  }

  return {
    matieres,
    loading,
    error,
    fetchMatieresByCatalogue,
    resetMatieres
  }
}

/**
 * Hook pour les opérations CRUD sur les associations catalogue-matière
 */
export function useCatalogueMatiereOperations() {
  const [loading, setLoading] = useState(false)

  const createCatalogueMatiere = async (data: Partial<CatalogueMatiere>) => {
    setLoading(true)
    try {
      const response = await catalogueMatiereService.createCatalogueMatiere(data)
      if (!response.hasError) {
        toast.success('Association créée avec succès')
        return { success: true, data: response.items?.[0] }
      } else {
        toast.error(response.status.message || 'Erreur lors de la création de l\'association')
        return { success: false, error: response.status.message }
      }
    } catch (error) {
      console.error('Erreur lors de la création de l\'association:', error)
      toast.error('Erreur lors de la création de l\'association')
      return { success: false, error: 'Erreur lors de la création' }
    } finally {
      setLoading(false)
    }
  }

  const updateCatalogueMatiere = async (id: number, data: Partial<CatalogueMatiere>) => {
    setLoading(true)
    try {
      const response = await catalogueMatiereService.updateCatalogueMatiere(id, data)
      if (!response.hasError) {
        toast.success('Association modifiée avec succès')
        return { success: true, data: response.items?.[0] }
      } else {
        toast.error(response.status.message || 'Erreur lors de la modification de l\'association')
        return { success: false, error: response.status.message }
      }
    } catch (error) {
      console.error('Erreur lors de la modification de l\'association:', error)
      toast.error('Erreur lors de la modification de l\'association')
      return { success: false, error: 'Erreur lors de la modification' }
    } finally {
      setLoading(false)
    }
  }

  const deleteCatalogueMatiere = async (id: number) => {
    setLoading(true)
    try {
      const response = await catalogueMatiereService.deleteCatalogueMatiere(id)
      if (!response.hasError) {
        toast.success('Association supprimée avec succès')
        return { success: true }
      } else {
        toast.error(response.status.message || 'Erreur lors de la suppression de l\'association')
        return { success: false, error: response.status.message }
      }
    } catch (error) {
      console.error('Erreur lors de la suppression de l\'association:', error)
      toast.error('Erreur lors de la suppression de l\'association')
      return { success: false, error: 'Erreur lors de la suppression' }
    } finally {
      setLoading(false)
    }
  }

  return {
    loading,
    createCatalogueMatiere,
    updateCatalogueMatiere,
    deleteCatalogueMatiere
  }
}


