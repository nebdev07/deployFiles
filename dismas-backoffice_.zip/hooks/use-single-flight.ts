"use client"

import { useCallback, useRef, useState } from "react"

/**
 * Verrouille une action asynchrone : le premier clic passe, les suivants sont ignorés
 * jusqu'à la fin du `Promise` (évite double envoi / double clic).
 *
 * Répertoire des usages recommandés dans le backoffice :
 * - Formulaires : soumission create/update (utilisateurs, commandes, réceptions, etc.)
 * - Modales : Enregistrer, Supprimer, Valider, exports PDF/Excel
 * - Actions ligne tableau : verrouiller, activer/désactiver, suppression
 * - Boutons « Actualiser » / rechargement liste : déjà souvent `disabled={loading}` côté hook métier
 *
 * Pour les boutons HTML : `disabled={busy || loading}` ou `<button disabled={run.isRunning}>`.
 */
export function useSingleFlight() {
  const [busy, setBusy] = useState(false)
  const lock = useRef(false)

  const run = useCallback(async <T,>(fn: () => Promise<T>): Promise<T | undefined> => {
    if (lock.current) return undefined
    lock.current = true
    setBusy(true)
    try {
      return await fn()
    } finally {
      lock.current = false
      setBusy(false)
    }
  }, [])

  return { busy, run }
}
