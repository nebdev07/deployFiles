/**
 * Hook personnalisé pour la gestion des années scolaires avec CRUD complet
 * Suit le même pattern que use-matieres.ts et use-niveaux-scolaires.ts
 */

import { useState, useCallback, useEffect } from 'react';
import { AnneeScolaire, CreateAnneeScolaireRequest, AnneeScolaireFilters } from '@/lib/types/entities';
import { anneeScolaireService } from '@/lib/services/annee-scolaire.service';
import toast from 'react-hot-toast';

interface UseAnneeScolaireState {
  anneesScolaires: AnneeScolaire[];
  loading: boolean;
  error: string | null;
  currentPage: number;
  totalPages: number;
  pageSize: number;
  totalCount: number;
}

interface UseAnneeScolaireActions {
  getAnneesScolaires: (filters?: AnneeScolaireFilters) => Promise<void>;
  searchAnneesScolaires: (searchTerm: string) => Promise<void>;
  refreshAnneesScolaires: () => Promise<void>;
  setPage: (page: number) => void;
  setPageSize: (size: number) => void;
  clearError: () => void;
}

export function useAnneesScolaires(): UseAnneeScolaireState & UseAnneeScolaireActions {
  const [state, setState] = useState<UseAnneeScolaireState>({
    anneesScolaires: [],
    loading: false,
    error: null,
    currentPage: 1,
    totalPages: 1,
    pageSize: 10,
    totalCount: 0,
  });

  const [currentFilters, setCurrentFilters] = useState<AnneeScolaireFilters | undefined>();

  // Fonction pour récupérer les années scolaires avec gestion d'erreur
  const getAnneesScolaires = useCallback(async (filters?: AnneeScolaireFilters) => {
    try {
      setState(prev => ({ ...prev, loading: true, error: null }));
      setCurrentFilters(filters);
      
      const response = await anneeScolaireService.getAnneesScolairesActives();
      
      if (response.hasError) {
        throw new Error(response.status?.message || 'Erreur lors du chargement des années scolaires');
      }
      
      // S'assurer que response.items est un tableau plat
      let anneesScolaires: AnneeScolaire[] = [];
      if (response.items) {
        if (Array.isArray(response.items)) {
          // Si c'est un tableau, vérifier s'il contient des tableaux imbriqués
          if (response.items.length > 0 && Array.isArray(response.items[0])) {
            // Aplatir le tableau de tableaux
            anneesScolaires = (response.items as unknown as any[]).flat() as AnneeScolaire[];
          } else {
            anneesScolaires = (response.items as unknown as AnneeScolaire[]);
          }
        }
      }
      
      // Trier par date de début décroissante (années récentes en premier)
      anneesScolaires.sort((a: any, b: any) => {
        const dateA = new Date(a.dateDebut).getTime();
        const dateB = new Date(b.dateDebut).getTime();
        return dateB - dateA;
      });
      
      setState(prev => ({
        ...prev,
        anneesScolaires,
        totalCount: anneesScolaires.length,
        totalPages: Math.ceil(anneesScolaires.length / prev.pageSize),
        loading: false,
        error: null,
      }));
      
    } catch (error) {
      console.error('Erreur lors du chargement des années scolaires:', error);
      const errorMessage = error instanceof Error ? error.message : 'Erreur inconnue';
      
      setState(prev => ({
        ...prev,
        anneesScolaires: [],
        loading: false,
        error: errorMessage,
      }));
      
      toast.error(`Erreur de chargement: ${errorMessage}`);
    }
  }, []);

  // Fonction de recherche
  const searchAnneesScolaires = useCallback(async (searchTerm: string) => {
    if (!searchTerm.trim()) {
      return getAnneesScolaires(currentFilters);
    }
    
    try {
      setState(prev => ({ ...prev, loading: true, error: null }));
      
      const response = await anneeScolaireService.searchAnneesScolaires(searchTerm);
      
      if (response.hasError) {
        throw new Error(response.status?.message || 'Erreur lors de la recherche');
      }
      
      // S'assurer que response.items est un tableau plat
      let anneesScolaires: AnneeScolaire[] = [];
      if (response.items) {
        if (Array.isArray(response.items)) {
          // Si c'est un tableau, vérifier s'il contient des tableaux imbriqués
          if (response.items.length > 0 && Array.isArray(response.items[0])) {
            // Aplatir le tableau de tableaux
            anneesScolaires = (response.items as unknown as any[]).flat() as AnneeScolaire[];
          } else {
            anneesScolaires = (response.items as unknown as AnneeScolaire[]);
          }
        }
      }
      
      setState(prev => ({
        ...prev,
        anneesScolaires,
        totalCount: anneesScolaires.length,
        totalPages: Math.ceil(anneesScolaires.length / prev.pageSize),
        loading: false,
        error: null,
      }));
      
    } catch (error) {
      console.error('Erreur lors de la recherche des années scolaires:', error);
      const errorMessage = error instanceof Error ? error.message : 'Erreur de recherche';
      
      setState(prev => ({
        ...prev,
        loading: false,
        error: errorMessage,
      }));
      
      toast.error(`Erreur de recherche: ${errorMessage}`);
    }
  }, [currentFilters, getAnneesScolaires]);

  // Fonction pour rafraîchir les données
  const refreshAnneesScolaires = useCallback(async () => {
    return getAnneesScolaires(currentFilters);
  }, [getAnneesScolaires, currentFilters]);

  // Fonction pour changer de page
  const setPage = useCallback((page: number) => {
    setState(prev => ({
      ...prev,
      currentPage: Math.max(1, Math.min(page, prev.totalPages)),
    }));
  }, []);

  // Fonction pour changer la taille de page
  const setPageSize = useCallback((size: number) => {
    setState(prev => ({
      ...prev,
      pageSize: Math.max(5, Math.min(size, 100)),
      currentPage: 1,
      totalPages: Math.ceil(prev.totalCount / size),
    }));
  }, []);

  // Fonction pour effacer les erreurs
  const clearError = useCallback(() => {
    setState(prev => ({ ...prev, error: null }));
  }, []);

  // Chargement initial des années scolaires
  useEffect(() => {
    getAnneesScolaires();
  }, [getAnneesScolaires]);

  return {
    // État
    anneesScolaires: state.anneesScolaires,
    loading: state.loading,
    error: state.error,
    currentPage: state.currentPage,
    totalPages: state.totalPages,
    pageSize: state.pageSize,
    totalCount: state.totalCount,
    
    // Actions
    getAnneesScolaires,
    searchAnneesScolaires,
    refreshAnneesScolaires,
    setPage,
    setPageSize,
    clearError,
  };
}

// Hook séparé pour les opérations CRUD (création, modification, suppression)
export function useAnneeScolaireOperations() {
  const [loading, setLoading] = useState(false);
  
  // Créer une année scolaire
  const createAnneeScolaire = useCallback(async (anneeData: CreateAnneeScolaireRequest) => {
    try {
      setLoading(true);
      
      // Vérifier si le code existe déjà
      const codeExists = await anneeScolaireService.checkCodeExists(anneeData.code);
      if (codeExists) {
        toast.error('Ce code année scolaire existe déjà. Veuillez en choisir un autre.');
        return { success: false, error: 'Code déjà existant' };
      }
      
      // Vérifier si le libellé existe déjà
      const libelleExists = await anneeScolaireService.checkLibelleExists(anneeData.libelle);
      if (libelleExists) {
        toast.error('Ce libellé année scolaire existe déjà. Veuillez en choisir un autre.');
        return { success: false, error: 'Libellé déjà existant' };
      }
      
      // Vérifier que la date de début est antérieure à la date de fin
      const dateDebut = new Date(anneeData.dateDebut);
      const dateFin = new Date(anneeData.dateFin);
      if (dateDebut >= dateFin) {
        toast.error('La date de début doit être antérieure à la date de fin.');
        return { success: false, error: 'Dates invalides' };
      }
      
      const response = await anneeScolaireService.createAnneeScolaire(anneeData);
      
      if (response.hasError) {
        throw new Error(response.status?.message || 'Erreur lors de la création');
      }
      
      toast.success('Année scolaire créée avec succès !');
      return { success: true, data: response.items?.[0] };
      
    } catch (error) {
      console.error('Erreur lors de la création de l\'année scolaire:', error);
      const errorMessage = error instanceof Error ? error.message : 'Erreur inconnue';
      toast.error(`Erreur de création: ${errorMessage}`);
      return { success: false, error: errorMessage };
    } finally {
      setLoading(false);
    }
  }, []);
  
  // Modifier une année scolaire
  const updateAnneeScolaire = useCallback(async (id: number, anneeData: Partial<CreateAnneeScolaireRequest>) => {
    try {
      setLoading(true);
      
      // Vérifier si le code existe déjà (en excluant l'ID actuel)
      if (anneeData.code) {
        const codeExists = await anneeScolaireService.checkCodeExists(anneeData.code, id);
        if (codeExists) {
          toast.error('Ce code année scolaire existe déjà. Veuillez en choisir un autre.');
          return { success: false, error: 'Code déjà existant' };
        }
      }
      
      // Vérifier si le libellé existe déjà (en excluant l'ID actuel)
      if (anneeData.libelle) {
        const libelleExists = await anneeScolaireService.checkLibelleExists(anneeData.libelle, id);
        if (libelleExists) {
          toast.error('Ce libellé année scolaire existe déjà. Veuillez en choisir un autre.');
          return { success: false, error: 'Libellé déjà existant' };
        }
      }
      
      // Vérifier que la date de début est antérieure à la date de fin
      if (anneeData.dateDebut && anneeData.dateFin) {
        const dateDebut = new Date(anneeData.dateDebut);
        const dateFin = new Date(anneeData.dateFin);
        if (dateDebut >= dateFin) {
          toast.error('La date de début doit être antérieure à la date de fin.');
          return { success: false, error: 'Dates invalides' };
        }
      }
      
      const response = await anneeScolaireService.updateAnneeScolaire(id, anneeData);
      
      if (response.hasError) {
        throw new Error(response.status?.message || 'Erreur lors de la modification');
      }
      
      toast.success('Année scolaire modifiée avec succès !');
      return { success: true, data: response.items?.[0] };
      
    } catch (error) {
      console.error('Erreur lors de la modification de l\'année scolaire:', error);
      const errorMessage = error instanceof Error ? error.message : 'Erreur inconnue';
      toast.error(`Erreur de modification: ${errorMessage}`);
      return { success: false, error: errorMessage };
    } finally {
      setLoading(false);
    }
  }, []);
  
  // Supprimer une année scolaire
  const deleteAnneeScolaire = useCallback(async (id: number) => {
    try {
      setLoading(true);
      
      const response = await anneeScolaireService.deleteAnneeScolaire(id);
      
      if (response.hasError) {
        throw new Error(response.status?.message || 'Erreur lors de la suppression');
      }
      
      toast.success('Année scolaire supprimée avec succès !');
      return { success: true };
      
    } catch (error) {
      console.error('Erreur lors de la suppression de l\'année scolaire:', error);
      const errorMessage = error instanceof Error ? error.message : 'Erreur inconnue';
      toast.error(`Erreur de suppression: ${errorMessage}`);
      return { success: false, error: errorMessage };
    } finally {
      setLoading(false);
    }
  }, []);
  
  // Marquer une année comme courante
  const setAnneeScolaireCourante = useCallback(async (id: number) => {
    try {
      setLoading(true);
      
      // D'abord, désactiver toutes les années courantes
      const allAnnees = await anneeScolaireService.getAnneesScolairesActives();
      if (allAnnees.items) {
        // S'assurer que items est un tableau plat
        let anneesArray: any[] = [];
        if (Array.isArray(allAnnees.items)) {
          if (allAnnees.items.length > 0 && Array.isArray(allAnnees.items[0])) {
            anneesArray = (allAnnees.items as unknown as any[]).flat();
          } else {
            anneesArray = (allAnnees.items as unknown as any[]);
          }
        }
        for (const annee of anneesArray) {
          if (annee.estCourante && annee.id !== id) {
            await anneeScolaireService.updateAnneeScolaire(annee.id!, { estCourante: false });
          }
        }
      }
      
      // Puis marquer l'année sélectionnée comme courante
      const response = await anneeScolaireService.updateAnneeScolaire(id, { estCourante: true });
      
      if (response.hasError) {
        throw new Error(response.status?.message || 'Erreur lors de la mise à jour');
      }
      
      toast.success('Année scolaire marquée comme courante !');
      return { success: true, data: response.items?.[0] };
      
    } catch (error) {
      console.error('Erreur lors de la mise à jour de l\'année courante:', error);
      const errorMessage = error instanceof Error ? error.message : 'Erreur inconnue';
      toast.error(`Erreur de mise à jour: ${errorMessage}`);
      return { success: false, error: errorMessage };
    } finally {
      setLoading(false);
    }
  }, []);
  
  return {
    loading,
    createAnneeScolaire,
    updateAnneeScolaire,
    deleteAnneeScolaire,
    setAnneeScolaireCourante,
  };
}
