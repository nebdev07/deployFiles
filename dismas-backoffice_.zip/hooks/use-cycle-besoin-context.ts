import { useCallback, useEffect, useState } from "react"
import { cycleBesoinService, type CycleBesoinContext } from "@/lib/services/cycle-besoin.service"

export function useCycleBesoinContext(anneeScolaireId: number | null | undefined) {
  const [ctx, setCtx] = useState<CycleBesoinContext | null>(null)
  const [loading, setLoading] = useState(false)

  const reload = useCallback(async () => {
    if (anneeScolaireId == null || anneeScolaireId <= 0) {
      setCtx(null)
      return
    }
    setLoading(true)
    try {
      const res = await cycleBesoinService.getContext(anneeScolaireId)
      const row = res.items?.[0] as CycleBesoinContext | undefined
      if (!res.hasError && row) {
        setCtx(row)
      } else {
        setCtx(null)
      }
    } catch {
      setCtx(null)
    } finally {
      setLoading(false)
    }
  }, [anneeScolaireId])

  useEffect(() => {
    reload()
    const t = window.setInterval(reload, 60_000)
    return () => window.clearInterval(t)
  }, [reload])

  return { ctx, loading, reload }
}
