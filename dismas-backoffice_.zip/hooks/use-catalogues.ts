/**
 * Hook personnalisé pour la gestion des catalogues avec CRUD complet et gestion des matières associées
 * Suit le même pattern que use-matieres.ts et use-niveaux-scolaires.ts
 */

import { useState, useCallback, useEffect } from 'react';
import { 
  Catalogue, 
  CatalogueMatiere, 
  CreateCatalogueRequest, 
  CatalogueFilters,
  Matiere 
} from '@/lib/types/entities';
import { catalogueService } from '@/lib/services/catalogue.service';
import toast from 'react-hot-toast';

interface UseCatalogueState {
  catalogues: Catalogue[];
  loading: boolean;
  error: string | null;
  currentPage: number;
  totalPages: number;
  pageSize: number;
  totalCount: number;
}

interface UseCatalogueActions {
  getCatalogues: (filters?: CatalogueFilters) => Promise<void>;
  searchCatalogues: (searchTerm: string) => Promise<void>;
  refreshCatalogues: () => Promise<void>;
  setPage: (page: number) => void;
  setPageSize: (size: number) => void;
  clearError: () => void;
}

const extractErrorMessage = (error: unknown): string => {
  if (error instanceof Error && error.message) return error.message;
  if (error && typeof error === 'object') {
    const maybeMessage = (error as any).message;
    if (typeof maybeMessage === 'string' && maybeMessage.trim()) return maybeMessage;
  }
  return 'Erreur inconnue';
};

const isLogoutInProgress = (): boolean => {
  if (typeof window === 'undefined') return false;
  return !localStorage.getItem('auth_token');
};

export function useCatalogues(): UseCatalogueState & UseCatalogueActions {
  const [state, setState] = useState<UseCatalogueState>({
    catalogues: [],
    loading: false,
    error: null,
    currentPage: 1,
    totalPages: 1,
    pageSize: 10,
    totalCount: 0,
  });

  const [currentFilters, setCurrentFilters] = useState<CatalogueFilters | undefined>();

  // Fonction pour récupérer les catalogues avec gestion d'erreur
  const getCatalogues = useCallback(async (filters?: CatalogueFilters) => {
    try {
      setState(prev => ({ ...prev, loading: true, error: null }));
      setCurrentFilters(filters);
      
      // Par défaut, on charge tous les catalogues non supprimés (actifs + inactifs)
      const effectiveFilters: CatalogueFilters = {
        isDeleted: false,
        ...filters,
      };
      const response = await catalogueService.getCatalogues(effectiveFilters);
      
      if (response.hasError) {
        throw new Error(response.status?.message || 'Erreur lors du chargement des catalogues');
      }
      
      // S'assurer que response.items est un tableau plat
      let cataloguesTemp: any[] = [];
      if (response.items) {
        if (Array.isArray(response.items)) {
          // Si c'est un tableau, vérifier s'il contient des tableaux imbriqués
          if (response.items.length > 0 && Array.isArray(response.items[0])) {
            // Aplatir le tableau de tableaux
            cataloguesTemp = (response.items as unknown as any[]).flat();
          } else {
            cataloguesTemp = (response.items as unknown as any[]);
          }
        }
      }
      
      // Trier par libellé alphabétique
      cataloguesTemp.sort((a: any, b: any) => a.libelle.localeCompare(b.libelle));
      
      // Convertir explicitement en Catalogue[]
      const catalogues: Catalogue[] = cataloguesTemp as unknown as Catalogue[];
      
      setState(prev => ({
        ...prev,
        catalogues,
        totalCount: catalogues.length,
        totalPages: Math.ceil(catalogues.length / prev.pageSize),
        loading: false,
        error: null,
      }));
      
    } catch (error) {
      console.error('Erreur lors du chargement des catalogues:', error);
      const errorMessage = error instanceof Error ? error.message : 'Erreur inconnue';
      
      setState(prev => ({
        ...prev,
        catalogues: [],
        loading: false,
        error: errorMessage,
      }));
      
      toast.error(`Erreur de chargement: ${errorMessage}`);
    }
  }, []);

  // Fonction de recherche
  const searchCatalogues = useCallback(async (searchTerm: string) => {
    if (!searchTerm.trim()) {
      return getCatalogues(currentFilters);
    }
    
    try {
      setState(prev => ({ ...prev, loading: true, error: null }));
      
      // Recherche cohérente avec les mêmes filtres que la liste (ex: active/inactive)
      const effectiveFilters: CatalogueFilters = {
        isDeleted: false,
        ...currentFilters,
        code: searchTerm,
        libelle: searchTerm,
      };
      const response = await catalogueService.getCatalogues(effectiveFilters);
      
      if (response.hasError) {
        throw new Error(response.status?.message || 'Erreur lors de la recherche');
      }
      
      // S'assurer que response.items est un tableau plat
      let cataloguesTemp: any[] = [];
      if (response.items) {
        if (Array.isArray(response.items)) {
          // Si c'est un tableau, vérifier s'il contient des tableaux imbriqués
          if (response.items.length > 0 && Array.isArray(response.items[0])) {
            // Aplatir le tableau de tableaux
            cataloguesTemp = (response.items as unknown as any[]).flat();
          } else {
            cataloguesTemp = (response.items as unknown as any[]);
          }
        }
      }
      
      // Convertir explicitement en Catalogue[]
      const catalogues: Catalogue[] = cataloguesTemp as unknown as Catalogue[];
      
      setState(prev => ({
        ...prev,
        catalogues,
        totalCount: catalogues.length,
        totalPages: Math.ceil(catalogues.length / prev.pageSize),
        loading: false,
        error: null,
      }));
      
    } catch (error) {
      console.error('Erreur lors de la recherche des catalogues:', error);
      const errorMessage = error instanceof Error ? error.message : 'Erreur de recherche';
      
      setState(prev => ({
        ...prev,
        loading: false,
        error: errorMessage,
      }));
      
      toast.error(`Erreur de recherche: ${errorMessage}`);
    }
  }, [currentFilters, getCatalogues]);

  // Fonction pour rafraîchir les données
  const refreshCatalogues = useCallback(async () => {
    return getCatalogues(currentFilters);
  }, [getCatalogues, currentFilters]);

  // Fonction pour changer de page
  const setPage = useCallback((page: number) => {
    setState(prev => ({
      ...prev,
      currentPage: Math.max(1, Math.min(page, prev.totalPages)),
    }));
  }, []);

  // Fonction pour changer la taille de page
  const setPageSize = useCallback((size: number) => {
    setState(prev => ({
      ...prev,
      pageSize: Math.max(5, Math.min(size, 100)),
      currentPage: 1,
      totalPages: Math.ceil(prev.totalCount / size),
    }));
  }, []);

  // Fonction pour effacer les erreurs
  const clearError = useCallback(() => {
    setState(prev => ({ ...prev, error: null }));
  }, []);

  // Chargement initial des catalogues
  useEffect(() => {
    getCatalogues();
  }, [getCatalogues]);

  return {
    // État
    catalogues: state.catalogues,
    loading: state.loading,
    error: state.error,
    currentPage: state.currentPage,
    totalPages: state.totalPages,
    pageSize: state.pageSize,
    totalCount: state.totalCount,
    
    // Actions
    getCatalogues,
    searchCatalogues,
    refreshCatalogues,
    setPage,
    setPageSize,
    clearError,
  };
}

// Hook séparé pour les opérations CRUD (création, modification, suppression)
export function useCatalogueOperations() {
  const [loading, setLoading] = useState(false);
  
  // Créer un catalogue
  const createCatalogue = useCallback(async (catalogueData: CreateCatalogueRequest) => {
    try {
      setLoading(true);
      
      // Vérifier si le code existe déjà
      const codeExists = await catalogueService.checkCodeExists(catalogueData.code);
      if (codeExists) {
        toast.error('Ce code catalogue existe déjà. Veuillez en choisir un autre.');
        return { success: false, error: 'Code déjà existant' };
      }
      
      // Vérifier si le libellé existe déjà
      const libelleExists = await catalogueService.checkLibelleExists(
        catalogueData.libelle,
        undefined,
        catalogueData.anneeScolaireId
      );
      if (libelleExists) {
        toast.error('Ce libellé catalogue existe déjà. Veuillez en choisir un autre.');
        return { success: false, error: 'Libellé déjà existant' };
      }
      
      // Créer le catalogue d'abord
      const response = await catalogueService.createCatalogue(catalogueData);
      
      if (response.hasError) {
        throw new Error(response.status?.message || 'Erreur lors de la création');
      }
      
      // S'assurer que response.items est un tableau plat
      let newCatalogue: Catalogue | undefined = undefined;
      if (response.items && Array.isArray(response.items)) {
        if (response.items.length > 0) {
          if (Array.isArray(response.items[0])) {
            newCatalogue = (response.items as unknown as any[]).flat()[0] as Catalogue;
          } else {
            newCatalogue = response.items[0] as Catalogue;
          }
        }
      }
      
      // Si des matières sont spécifiées, les associer au catalogue avec le niveau
      if (newCatalogue && catalogueData.matiereIds && catalogueData.matiereIds.length > 0) {
        try {
          // 🎯 Passer le niveauScolaireId du catalogue lors de l'association des matières
          await catalogueService.associateMatieresToCatalogue(
            newCatalogue.id!, 
            catalogueData.matiereIds,
            catalogueData.niveauScolaireId
          );
        } catch (matiereError) {
          console.warn('Erreur lors de l\'association des matières:', matiereError);
          toast.error('Catalogue créé mais erreur lors de l\'association des matières');
        }
      }
      
      toast.success('Catalogue créé avec succès !');
      return { success: true, data: newCatalogue };
      
    } catch (error) {
      console.error('Erreur lors de la création du catalogue:', error);
      const errorMessage = error instanceof Error ? error.message : 'Erreur inconnue';
      toast.error(`Erreur de création: ${errorMessage}`);
      return { success: false, error: errorMessage };
    } finally {
      setLoading(false);
    }
  }, []);
  
  // Modifier un catalogue
  const updateCatalogue = useCallback(async (id: number, catalogueData: Partial<CreateCatalogueRequest>) => {
    try {
      setLoading(true);
      
      // Vérifier si le code existe déjà (en excluant l'ID actuel)
      if (catalogueData.code) {
        const codeExists = await catalogueService.checkCodeExists(catalogueData.code, id);
        if (codeExists) {
          toast.error('Ce code catalogue existe déjà. Veuillez en choisir un autre.');
          return { success: false, error: 'Code déjà existant' };
        }
      }
      
      // Vérifier si le libellé existe déjà (en excluant l'ID actuel)
      if (catalogueData.libelle) {
        const libelleExists = await catalogueService.checkLibelleExists(
          catalogueData.libelle,
          id,
          catalogueData.anneeScolaireId
        );
        if (libelleExists) {
          toast.error('Ce libellé catalogue existe déjà. Veuillez en choisir un autre.');
          return { success: false, error: 'Libellé déjà existant' };
        }
      }
      
      // Mettre à jour le catalogue
      const response = await catalogueService.updateCatalogue(id, catalogueData);
      
      if (response.hasError) {
        throw new Error(response.status?.message || 'Erreur lors de la modification');
      }
      
      // Si des matières sont spécifiées, mettre à jour les associations
      if (catalogueData.matiereIds !== undefined) {
        try {
          // 🎯 Passer le niveauScolaireId lors de la mise à jour des matières
          await catalogueService.updateCatalogueMatieres(
            id, 
            catalogueData.matiereIds,
            catalogueData.niveauScolaireId
          );
        } catch (matiereError) {
          console.warn('Erreur lors de la mise à jour des matières:', matiereError);
          toast.error('Catalogue modifié mais erreur lors de la mise à jour des matières');
        }
      }
      
      toast.success('Catalogue modifié avec succès !');
      return { success: true, data: response.items?.[0] };
      
    } catch (error) {
      const errorMessage = extractErrorMessage(error);
      if (!isLogoutInProgress()) {
        console.error('Erreur lors de la modification du catalogue:', error);
        toast.error(`Erreur de modification: ${errorMessage}`);
      }
      return { success: false, error: errorMessage };
    } finally {
      setLoading(false);
    }
  }, []);
  
  // Supprimer un catalogue
  const deleteCatalogue = useCallback(async (id: number) => {
    try {
      setLoading(true);
      
      const response = await catalogueService.deleteCatalogue(id);
      
      if (response.hasError) {
        throw new Error(response.status?.message || 'Erreur lors de la suppression');
      }
      
      toast.success('Catalogue supprimé avec succès !');
      return { success: true };
      
    } catch (error) {
      console.error('Erreur lors de la suppression du catalogue:', error);
      const errorMessage = error instanceof Error ? error.message : 'Erreur inconnue';
      toast.error(`Erreur de suppression: ${errorMessage}`);
      return { success: false, error: errorMessage };
    } finally {
      setLoading(false);
    }
  }, []);
  
  return {
    loading,
    createCatalogue,
    updateCatalogue,
    deleteCatalogue,
  };
}

// Hook spécialisé pour la gestion des matières d'un catalogue
export function useCatalogueMatieres(catalogueId?: number) {
  const [matieres, setMatieres] = useState<CatalogueMatiere[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Charger les matières d'un catalogue
  const loadMatieres = useCallback(async (id: number) => {
    try {
      setLoading(true);
      setError(null);
      
      const response = await catalogueService.getMatieresByCatalogue(id);
      
      if (response.hasError) {
        throw new Error(response.status?.message || 'Erreur lors du chargement des matières');
      }
      
      // S'assurer que response.items est un tableau plat
      let matieresTemp: any[] = [];
      if (response.items) {
        if (Array.isArray(response.items)) {
          // Si c'est un tableau, vérifier s'il contient des tableaux imbriqués
          if (response.items.length > 0 && Array.isArray(response.items[0])) {
            // Aplatir le tableau de tableaux
            matieresTemp = (response.items as unknown as any[]).flat();
          } else {
            matieresTemp = (response.items as unknown as any[]);
          }
        }
      }
      
      // Convertir explicitement en CatalogueMatiere[]
      const matieres: CatalogueMatiere[] = matieresTemp as unknown as CatalogueMatiere[];
      
      setMatieres(matieres);
      
    } catch (error) {
      console.error('Erreur lors du chargement des matières du catalogue:', error);
      const errorMessage = error instanceof Error ? error.message : 'Erreur inconnue';
      setError(errorMessage);
      toast.error(`Erreur de chargement: ${errorMessage}`);
    } finally {
      setLoading(false);
    }
  }, []);

  // Associer une matière au catalogue
  const associateMatiere = useCallback(async (matiereId: number) => {
    if (!catalogueId) return { success: false, error: 'ID catalogue manquant' };
    
    try {
      setLoading(true);
      
      const response = await catalogueService.associateMatiereToCatalogue(catalogueId, matiereId);
      
      if (response.hasError) {
        throw new Error(response.status?.message || 'Erreur lors de l\'association');
      }
      
      // Recharger la liste des matières
      await loadMatieres(catalogueId);
      
      toast.success('Matière associée avec succès !');
      return { success: true };
      
    } catch (error) {
      console.error('Erreur lors de l\'association de la matière:', error);
      const errorMessage = error instanceof Error ? error.message : 'Erreur inconnue';
      toast.error(`Erreur d'association: ${errorMessage}`);
      return { success: false, error: errorMessage };
    } finally {
      setLoading(false);
    }
  }, [catalogueId, loadMatieres]);

  // Dissocier une matière du catalogue
  const dissociateMatiere = useCallback(async (catalogueMatiereId: number) => {
    try {
      setLoading(true);
      
      const response = await catalogueService.dissociateMatiereFromCatalogue(catalogueMatiereId);
      
      if (response.hasError) {
        throw new Error(response.status?.message || 'Erreur lors de la dissociation');
      }
      
      // Mettre à jour la liste locale
      setMatieres(prev => prev.filter(catalogueMatiere => catalogueMatiere.id !== catalogueMatiereId));
      
      toast.success('Matière dissociée avec succès !');
      return { success: true };
      
    } catch (error) {
      console.error('Erreur lors de la dissociation de la matière:', error);
      const errorMessage = error instanceof Error ? error.message : 'Erreur inconnue';
      toast.error(`Erreur de dissociation: ${errorMessage}`);
      return { success: false, error: errorMessage };
    } finally {
      setLoading(false);
    }
  }, []);

  // Charger automatiquement les matières si catalogueId est fourni
  useEffect(() => {
    if (catalogueId) {
      loadMatieres(catalogueId);
    }
  }, [catalogueId, loadMatieres]);

  return {
    matieres,
    loading,
    error,
    loadMatieres,
    associateMatiere,
    dissociateMatiere,
  };
}
