/**
 * Hook personnalisé pour la gestion des niveaux scolaires
 * Suit le même pattern que use-matieres.ts
 */

import { useState, useCallback, useEffect } from 'react';
import { NiveauScolaire, CreateNiveauScolaireRequest, NiveauScolaireFilters } from '@/lib/types/entities';
import { niveauScolaireService } from '@/lib/services/niveau-scolaire.service';
import toast from 'react-hot-toast';

interface UseNiveauScolaireState {
  niveauxScolaires: NiveauScolaire[];
  loading: boolean;
  error: string | null;
  currentPage: number;
  totalPages: number;
  pageSize: number;
  totalCount: number;
}

interface UseNiveauScolaireActions {
  getNiveauxScolaires: (filters?: NiveauScolaireFilters) => Promise<void>;
  searchNiveauxScolaires: (searchTerm: string) => Promise<void>;
  refreshNiveauxScolaires: () => Promise<void>;
  setPage: (page: number) => void;
  setPageSize: (size: number) => void;
  clearError: () => void;
}

export function useNiveauxScolaires(): UseNiveauScolaireState & UseNiveauScolaireActions {
  const [state, setState] = useState<UseNiveauScolaireState>({
    niveauxScolaires: [],
    loading: false,
    error: null,
    currentPage: 1,
    totalPages: 1,
    pageSize: 10,
    totalCount: 0,
  });

  const [currentFilters, setCurrentFilters] = useState<NiveauScolaireFilters | undefined>();

  // Fonction pour récupérer les niveaux scolaires avec gestion d'erreur
  const getNiveauxScolaires = useCallback(async (filters?: NiveauScolaireFilters) => {
    try {
      setState(prev => ({ ...prev, loading: true, error: null }));
      setCurrentFilters(filters);
      
      const response = await niveauScolaireService.getNiveauxScolairesOrdered();
      
      if (response.hasError) {
        throw new Error(response.status?.message || 'Erreur lors du chargement des niveaux scolaires');
      }
      
      // S'assurer que response.items est un tableau plat
      let niveauxScolairesTemp: any[] = [];
      if (response.items) {
        if (Array.isArray(response.items)) {
          // Si c'est un tableau, vérifier s'il contient des tableaux imbriqués
          if (response.items.length > 0 && Array.isArray(response.items[0])) {
            // Aplatir le tableau de tableaux
            niveauxScolairesTemp = (response.items as unknown as any[]).flat();
          } else {
            niveauxScolairesTemp = (response.items as unknown as any[]);
          }
        }
      }
      
      // Convertir explicitement en NiveauScolaire[]
      const niveauxScolaires: NiveauScolaire[] = niveauxScolairesTemp as unknown as NiveauScolaire[];
      
      setState(prev => ({
        ...prev,
        niveauxScolaires,
        totalCount: niveauxScolaires.length,
        totalPages: Math.ceil(niveauxScolaires.length / prev.pageSize),
        loading: false,
        error: null,
      }));
      
    } catch (error) {
      console.error('Erreur lors du chargement des niveaux scolaires:', error);
      const errorMessage = error instanceof Error ? error.message : 'Erreur inconnue';
      
      setState(prev => ({
        ...prev,
        niveauxScolaires: [],
        loading: false,
        error: errorMessage,
      }));
      
      toast.error(`Erreur de chargement: ${errorMessage}`);
    }
  }, []);

  // Fonction de recherche
  const searchNiveauxScolaires = useCallback(async (searchTerm: string) => {
    if (!searchTerm.trim()) {
      return getNiveauxScolaires(currentFilters);
    }
    
    try {
      setState(prev => ({ ...prev, loading: true, error: null }));
      
      const response = await niveauScolaireService.searchNiveauxScolaires(searchTerm);
      
      if (response.hasError) {
        throw new Error(response.status?.message || 'Erreur lors de la recherche');
      }
      
      // S'assurer que response.items est un tableau plat
      let niveauxScolairesTemp: any[] = [];
      if (response.items) {
        if (Array.isArray(response.items)) {
          // Si c'est un tableau, vérifier s'il contient des tableaux imbriqués
          if (response.items.length > 0 && Array.isArray(response.items[0])) {
            // Aplatir le tableau de tableaux
            niveauxScolairesTemp = (response.items as unknown as any[]).flat();
          } else {
            niveauxScolairesTemp = (response.items as unknown as any[]);
          }
        }
      }
      
      // Convertir explicitement en NiveauScolaire[]
      const niveauxScolaires: NiveauScolaire[] = niveauxScolairesTemp as unknown as NiveauScolaire[];
      
      setState(prev => ({
        ...prev,
        niveauxScolaires,
        totalCount: niveauxScolaires.length,
        totalPages: Math.ceil(niveauxScolaires.length / prev.pageSize),
        loading: false,
        error: null,
      }));
      
    } catch (error) {
      console.error('Erreur lors de la recherche des niveaux scolaires:', error);
      const errorMessage = error instanceof Error ? error.message : 'Erreur de recherche';
      
      setState(prev => ({
        ...prev,
        loading: false,
        error: errorMessage,
      }));
      
      toast.error(`Erreur de recherche: ${errorMessage}`);
    }
  }, [currentFilters, getNiveauxScolaires]);

  // Fonction pour rafraîchir les données
  const refreshNiveauxScolaires = useCallback(async () => {
    return getNiveauxScolaires(currentFilters);
  }, [getNiveauxScolaires, currentFilters]);

  // Fonction pour changer de page
  const setPage = useCallback((page: number) => {
    setState(prev => ({
      ...prev,
      currentPage: Math.max(1, Math.min(page, prev.totalPages)),
    }));
  }, []);

  // Fonction pour changer la taille de page
  const setPageSize = useCallback((size: number) => {
    setState(prev => ({
      ...prev,
      pageSize: Math.max(5, Math.min(size, 100)),
      currentPage: 1,
      totalPages: Math.ceil(prev.totalCount / size),
    }));
  }, []);

  // Fonction pour effacer les erreurs
  const clearError = useCallback(() => {
    setState(prev => ({ ...prev, error: null }));
  }, []);

  // Chargement initial des niveaux scolaires
  useEffect(() => {
    getNiveauxScolaires();
  }, [getNiveauxScolaires]);

  return {
    // État
    niveauxScolaires: state.niveauxScolaires,
    loading: state.loading,
    error: state.error,
    currentPage: state.currentPage,
    totalPages: state.totalPages,
    pageSize: state.pageSize,
    totalCount: state.totalCount,
    
    // Actions
    getNiveauxScolaires,
    searchNiveauxScolaires,
    refreshNiveauxScolaires,
    setPage,
    setPageSize,
    clearError,
  };
}

// Hook séparé pour les opérations CRUD (création, modification, suppression)
export function useNiveauScolaireOperations() {
  const [loading, setLoading] = useState(false);
  
  // Créer un niveau scolaire
  const createNiveauScolaire = useCallback(async (niveauData: CreateNiveauScolaireRequest) => {
    try {
      setLoading(true);
      
      // Vérifier si le code existe déjà
      const codeExists = await niveauScolaireService.checkCodeExists(niveauData.code);
      if (codeExists) {
        toast.error('Ce code niveau scolaire existe déjà. Veuillez en choisir un autre.');
        return { success: false, error: 'Code déjà existant' };
      }
      
      // Vérifier si l'ordre existe déjà
      const ordreExists = await niveauScolaireService.checkOrdreExists(niveauData.ordre);
      if (ordreExists) {
        toast.error('Cet ordre est déjà utilisé. Veuillez en choisir un autre.');
        return { success: false, error: 'Ordre déjà existant' };
      }
      
      const response = await niveauScolaireService.createNiveauScolaire(niveauData);
      
      if (response.hasError) {
        throw new Error(response.status?.message || 'Erreur lors de la création');
      }
      
      toast.success('Niveau scolaire créé avec succès !');
      return { success: true, data: response.items?.[0] };
      
    } catch (error) {
      console.error('Erreur lors de la création du niveau scolaire:', error);
      const errorMessage = error instanceof Error ? error.message : 'Erreur inconnue';
      toast.error(`Erreur de création: ${errorMessage}`);
      return { success: false, error: errorMessage };
    } finally {
      setLoading(false);
    }
  }, []);
  
  // Modifier un niveau scolaire
  const updateNiveauScolaire = useCallback(async (id: number, niveauData: Partial<CreateNiveauScolaireRequest>) => {
    try {
      setLoading(true);
      
      // Vérifier si le code existe déjà (en excluant l'ID actuel)
      if (niveauData.code) {
        const codeExists = await niveauScolaireService.checkCodeExists(niveauData.code, id);
        if (codeExists) {
          toast.error('Ce code niveau scolaire existe déjà. Veuillez en choisir un autre.');
          return { success: false, error: 'Code déjà existant' };
        }
      }
      
      // Vérifier si l'ordre existe déjà (en excluant l'ID actuel)
      if (niveauData.ordre) {
        const ordreExists = await niveauScolaireService.checkOrdreExists(niveauData.ordre, id);
        if (ordreExists) {
          toast.error('Cet ordre est déjà utilisé. Veuillez en choisir un autre.');
          return { success: false, error: 'Ordre déjà existant' };
        }
      }
      
      const response = await niveauScolaireService.updateNiveauScolaire(id, niveauData);
      
      if (response.hasError) {
        throw new Error(response.status?.message || 'Erreur lors de la modification');
      }
      
      toast.success('Niveau scolaire modifié avec succès !');
      return { success: true, data: response.items?.[0] };
      
    } catch (error) {
      console.error('Erreur lors de la modification du niveau scolaire:', error);
      const errorMessage = error instanceof Error ? error.message : 'Erreur inconnue';
      toast.error(`Erreur de modification: ${errorMessage}`);
      return { success: false, error: errorMessage };
    } finally {
      setLoading(false);
    }
  }, []);
  
  // Supprimer un niveau scolaire
  const deleteNiveauScolaire = useCallback(async (id: number) => {
    try {
      setLoading(true);
      
      const response = await niveauScolaireService.deleteNiveauScolaire(id);
      
      if (response.hasError) {
        throw new Error(response.status?.message || 'Erreur lors de la suppression');
      }
      
      toast.success('Niveau scolaire supprimé avec succès !');
      return { success: true };
      
    } catch (error) {
      console.error('Erreur lors de la suppression du niveau scolaire:', error);
      const errorMessage = error instanceof Error ? error.message : 'Erreur inconnue';
      toast.error(`Erreur de suppression: ${errorMessage}`);
      return { success: false, error: errorMessage };
    } finally {
      setLoading(false);
    }
  }, []);
  
  return {
    loading,
    createNiveauScolaire,
    updateNiveauScolaire,
    deleteNiveauScolaire,
  };
}
