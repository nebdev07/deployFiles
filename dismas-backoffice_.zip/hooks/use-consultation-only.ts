"use client"

import { useMemo } from "react"
import { useAuth } from "@/app/providers"
import { isConsultationOnlyRole } from "@/lib/utils/role-access"

/**
 * Profils « consultation uniquement » (ex. CABINET) : pas d’actions métier de saisie / validation.
 * Préférer masquer les CTA ; ajouter aussi une garde dans les handlers pour la défense en profondeur.
 */
export function useConsultationOnly() {
  const { user } = useAuth()
  const consultationOnly = useMemo(
    () => isConsultationOnlyRole(user?.role?.code),
    [user?.role?.code],
  )
  return {
    consultationOnly,
    canMutate: !consultationOnly,
  }
}
