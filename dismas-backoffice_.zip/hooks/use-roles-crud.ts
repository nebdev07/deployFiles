/**
 * Hook personnalisé pour la gestion des rôles avec CRUD complet
 * Suit le même pattern que use-matieres.ts et use-niveaux-scolaires.ts
 */

import { useState, useCallback, useEffect } from 'react';
import { Role, CreateRoleRequest, RoleFilters } from '@/lib/types/entities';
import { roleCrudService } from '@/lib/services/role-crud.service';
import { getThrownErrorMessage, isFormattedRbacPermissionMessage } from '@/lib/utils/api-permission-errors';
import toast from 'react-hot-toast';

interface UseRoleCrudState {
  roles: Role[];
  loading: boolean;
  error: string | null;
  currentPage: number;
  totalPages: number;
  pageSize: number;
  totalCount: number;
}

interface UseRoleCrudActions {
  getRoles: (filters?: RoleFilters) => Promise<void>;
  searchRoles: (searchTerm: string) => Promise<void>;
  refreshRoles: () => Promise<void>;
  setPage: (page: number) => void;
  setPageSize: (size: number) => void;
  clearError: () => void;
}

export function useRolesCrud(): UseRoleCrudState & UseRoleCrudActions {
  const [state, setState] = useState<UseRoleCrudState>({
    roles: [],
    loading: false,
    error: null,
    currentPage: 1,
    totalPages: 1,
    pageSize: 10,
    totalCount: 0,
  });

  const [currentFilters, setCurrentFilters] = useState<RoleFilters | undefined>();

  // Fonction pour récupérer les rôles avec gestion d'erreur
  const getRoles = useCallback(async (filters?: RoleFilters) => {
    try {
      setState(prev => ({ ...prev, loading: true, error: null }));
      setCurrentFilters(filters);
      
      const response = await roleCrudService.getRolesOrderedByLevel();
      
      if (response.hasError) {
        throw new Error(response.status?.message || 'Erreur lors du chargement des rôles');
      }
      
      // S'assurer que response.items est un tableau plat
      let rolesTemp: any[] = [];
      if (response.items) {
        if (Array.isArray(response.items)) {
          // Si c'est un tableau, vérifier s'il contient des tableaux imbriqués
          if (response.items.length > 0 && Array.isArray(response.items[0])) {
            // Aplatir le tableau de tableaux
            rolesTemp = (response.items as unknown as any[]).flat();
          } else {
            rolesTemp = (response.items as unknown as any[]);
          }
        }
      }
      
      // Convertir explicitement en Role[]
      const roles: Role[] = rolesTemp as unknown as Role[];
      
      setState(prev => ({
        ...prev,
        roles,
        totalCount: roles.length,
        totalPages: Math.ceil(roles.length / prev.pageSize),
        loading: false,
        error: null,
      }));
      
    } catch (error) {
      console.error('Erreur lors du chargement des rôles:', error);
      const errorMessage = getThrownErrorMessage(error, 'Erreur inconnue');

      setState((prev) => ({
        ...prev,
        roles: [],
        loading: false,
        error: errorMessage,
      }));

      if (isFormattedRbacPermissionMessage(errorMessage)) {
        toast.error(errorMessage, { icon: '🔒', duration: 7000 });
      } else {
        toast.error(`Erreur de chargement : ${errorMessage}`);
      }
    }
  }, []);

  // Fonction de recherche
  const searchRoles = useCallback(async (searchTerm: string) => {
    if (!searchTerm.trim()) {
      return getRoles(currentFilters);
    }
    
    try {
      setState(prev => ({ ...prev, loading: true, error: null }));
      
      const response = await roleCrudService.searchRoles(searchTerm);
      
      if (response.hasError) {
        throw new Error(response.status?.message || 'Erreur lors de la recherche');
      }
      
      // S'assurer que response.items est un tableau plat
      let rolesTemp: any[] = [];
      if (response.items) {
        if (Array.isArray(response.items)) {
          // Si c'est un tableau, vérifier s'il contient des tableaux imbriqués
          if (response.items.length > 0 && Array.isArray(response.items[0])) {
            // Aplatir le tableau de tableaux
            rolesTemp = (response.items as unknown as any[]).flat();
          } else {
            rolesTemp = (response.items as unknown as any[]);
          }
        }
      }
      
      // Convertir explicitement en Role[]
      const roles: Role[] = rolesTemp as unknown as Role[];
      
      setState(prev => ({
        ...prev,
        roles,
        totalCount: roles.length,
        totalPages: Math.ceil(roles.length / prev.pageSize),
        loading: false,
        error: null,
      }));
      
    } catch (error) {
      console.error('Erreur lors de la recherche des rôles:', error);
      const errorMessage = getThrownErrorMessage(error, 'Erreur de recherche');

      setState((prev) => ({
        ...prev,
        loading: false,
        error: errorMessage,
      }));

      if (isFormattedRbacPermissionMessage(errorMessage)) {
        toast.error(errorMessage, { icon: '🔒', duration: 7000 });
      } else {
        toast.error(`Erreur de recherche : ${errorMessage}`);
      }
    }
  }, [currentFilters, getRoles]);

  // Fonction pour rafraîchir les données
  const refreshRoles = useCallback(async () => {
    return getRoles(currentFilters);
  }, [getRoles, currentFilters]);

  // Fonction pour changer de page
  const setPage = useCallback((page: number) => {
    setState(prev => ({
      ...prev,
      currentPage: Math.max(1, Math.min(page, prev.totalPages)),
    }));
  }, []);

  // Fonction pour changer la taille de page
  const setPageSize = useCallback((size: number) => {
    setState(prev => ({
      ...prev,
      pageSize: Math.max(5, Math.min(size, 100)),
      currentPage: 1,
      totalPages: Math.ceil(prev.totalCount / size),
    }));
  }, []);

  // Fonction pour effacer les erreurs
  const clearError = useCallback(() => {
    setState(prev => ({ ...prev, error: null }));
  }, []);

  // Chargement initial des rôles
  useEffect(() => {
    getRoles();
  }, [getRoles]);

  return {
    // État
    roles: state.roles,
    loading: state.loading,
    error: state.error,
    currentPage: state.currentPage,
    totalPages: state.totalPages,
    pageSize: state.pageSize,
    totalCount: state.totalCount,
    
    // Actions
    getRoles,
    searchRoles,
    refreshRoles,
    setPage,
    setPageSize,
    clearError,
  };
}

// Hook séparé pour les opérations CRUD (création, modification, suppression)
export function useRoleOperations() {
  const [loading, setLoading] = useState(false);
  
  // Créer un rôle
  const createRole = useCallback(async (roleData: CreateRoleRequest) => {
    try {
      setLoading(true);
      
      // Vérifier si le code existe déjà
      const codeExists = await roleCrudService.checkCodeExists(roleData.code);
      if (codeExists) {
        toast.error('Ce code rôle existe déjà. Veuillez en choisir un autre.');
        return { success: false, error: 'Code déjà existant' };
      }
      
      // Vérifier si le libellé existe déjà
      const libelleExists = await roleCrudService.checkLibelleExists(roleData.libelle);
      if (libelleExists) {
        toast.error('Ce libellé rôle existe déjà. Veuillez en choisir un autre.');
        return { success: false, error: 'Libellé déjà existant' };
      }
      
      const response = await roleCrudService.createRole(roleData);
      
      if (response.hasError) {
        throw new Error(response.status?.message || 'Erreur lors de la création');
      }
      
      toast.success('Rôle créé avec succès !');
      return { success: true, data: response.items?.[0] };
      
    } catch (error) {
      console.error('Erreur lors de la création du rôle:', error);
      const errorMessage = error instanceof Error ? error.message : 'Erreur inconnue';
      toast.error(`Erreur de création: ${errorMessage}`);
      return { success: false, error: errorMessage };
    } finally {
      setLoading(false);
    }
  }, []);
  
  // Modifier un rôle
  const updateRole = useCallback(async (id: number, roleData: Partial<CreateRoleRequest>) => {
    try {
      setLoading(true);
      
      // Vérifier si le code existe déjà (en excluant l'ID actuel)
      if (roleData.code) {
        const codeExists = await roleCrudService.checkCodeExists(roleData.code, id);
        if (codeExists) {
          toast.error('Ce code rôle existe déjà. Veuillez en choisir un autre.');
          return { success: false, error: 'Code déjà existant' };
        }
      }
      
      // Vérifier si le libellé existe déjà (en excluant l'ID actuel)
      if (roleData.libelle) {
        const libelleExists = await roleCrudService.checkLibelleExists(roleData.libelle, id);
        if (libelleExists) {
          toast.error('Ce libellé rôle existe déjà. Veuillez en choisir un autre.');
          return { success: false, error: 'Libellé déjà existant' };
        }
      }
      
      const response = await roleCrudService.updateRole(id, roleData);
      
      if (response.hasError) {
        throw new Error(response.status?.message || 'Erreur lors de la modification');
      }
      
      toast.success('Rôle modifié avec succès !');
      return { success: true, data: response.items?.[0] };
      
    } catch (error) {
      console.error('Erreur lors de la modification du rôle:', error);
      const errorMessage = error instanceof Error ? error.message : 'Erreur inconnue';
      toast.error(`Erreur de modification: ${errorMessage}`);
      return { success: false, error: errorMessage };
    } finally {
      setLoading(false);
    }
  }, []);
  
  // Supprimer un rôle
  const deleteRole = useCallback(async (id: number) => {
    try {
      setLoading(true);
      
      const response = await roleCrudService.deleteRole(id);
      
      if (response.hasError) {
        throw new Error(response.status?.message || 'Erreur lors de la suppression');
      }
      
      toast.success('Rôle supprimé avec succès !');
      return { success: true };
      
    } catch (error) {
      console.error('Erreur lors de la suppression du rôle:', error);
      const errorMessage = error instanceof Error ? error.message : 'Erreur inconnue';
      toast.error(`Erreur de suppression: ${errorMessage}`);
      return { success: false, error: errorMessage };
    } finally {
      setLoading(false);
    }
  }, []);
  
  return {
    loading,
    createRole,
    updateRole,
    deleteRole,
  };
}
