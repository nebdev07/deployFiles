/**
 * Hook personnalisé pour la gestion des utilisateurs
 * Intègre le service UsersService avec l'état React et la pagination serveur
 */

import { useState, useCallback, useRef, useEffect } from 'react';
import { usersService } from '@/lib/services/users.service';
import { User, UserFilters } from '@/lib/types/entities';
import toast from 'react-hot-toast';

function flattenItems<T>(raw: T[] | undefined | null): T[] {
  if (!raw || raw.length === 0) return [];
  if (Array.isArray(raw[0])) {
    return (raw as unknown as T[][]).flat();
  }
  return raw as T[];
}

interface UseUsersState {
  users: User[];
  loading: boolean;
  error: string | null;
  /** Total côté serveur pour les critères courants (pagination). */
  totalCount: number;
  currentPage: number;
  pageSize: number;
  totalPages: number;
}

interface UseUsersActions {
  loadUsers: (filters?: UserFilters, page?: number, size?: number) => Promise<void>;
  setPage: (page: number) => void;
  setPageSize: (size: number) => void;
  searchUsers: (searchTerm: string) => Promise<void>;
  refreshUsers: () => Promise<void>;
  resetFilters: () => Promise<void>;
}

export function useUsers(): UseUsersState & UseUsersActions {
  const [state, setState] = useState<UseUsersState>({
    users: [],
    loading: false,
    error: null,
    totalCount: 0,
    currentPage: 1,
    pageSize: 20,
    totalPages: 0,
  });

  const [currentFilters, setCurrentFilters] = useState<UserFilters | undefined>();
  const filtersRef = useRef<UserFilters | undefined>(undefined);
  const pageRef = useRef({ page: 1, size: 20 });

  useEffect(() => {
    filtersRef.current = currentFilters;
  }, [currentFilters]);

  useEffect(() => {
    pageRef.current = { page: state.currentPage, size: state.pageSize };
  }, [state.currentPage, state.pageSize]);

  const loadUsers = useCallback(async (filters?: UserFilters, page: number = 1, size?: number) => {
    setState((prev) => ({ ...prev, loading: true, error: null }));
    setCurrentFilters(filters);
    const pageSizeUsed = size ?? pageRef.current.size;
    const indexZero = Math.max(0, page - 1);

    try {
      const response = await usersService.getUsers(filters, indexZero, pageSizeUsed);
      const itemsTemp = flattenItems(response.items) as unknown as User[];
      const count =
        typeof response.count === 'number' && !Number.isNaN(response.count)
          ? response.count
          : itemsTemp.length;
      const totalPages = count === 0 ? 0 : Math.ceil(count / pageSizeUsed);

      setState((prev) => ({
        ...prev,
        users: itemsTemp,
        totalCount: count,
        currentPage: page,
        pageSize: pageSizeUsed,
        totalPages,
        loading: false,
      }));
    } catch (error) {
      console.error('Erreur lors du chargement des utilisateurs:', error);
      const errorMessage = 'Erreur lors du chargement des utilisateurs';

      setState((prev) => ({
        ...prev,
        error: errorMessage,
        loading: false,
      }));

      toast.error(errorMessage);
    }
  }, []);

  const setPage = useCallback((page: number) => {
    setState((prev) => ({ ...prev, currentPage: Math.max(1, page) }));
  }, []);

  const setPageSize = useCallback((newSize: number) => {
    setState((prev) => ({ ...prev, pageSize: newSize, currentPage: 1 }));
  }, []);

  const searchUsers = useCallback(
    async (searchTerm: string) => {
      const filters: UserFilters = { ...(filtersRef.current ?? {}) };
      if (searchTerm.trim()) {
        filters.quickSearch = searchTerm.trim();
      } else {
        delete filters.quickSearch;
      }
      await loadUsers(filters, 1, pageRef.current.size);
    },
    [loadUsers],
  );

  const refreshUsers = useCallback(async () => {
    await loadUsers(filtersRef.current, pageRef.current.page, pageRef.current.size);
  }, [loadUsers]);

  const resetFilters = useCallback(async () => {
    setCurrentFilters(undefined);
    await loadUsers(undefined, 1, pageRef.current.size);
  }, [loadUsers]);

  return {
    ...state,
    loadUsers,
    setPage,
    setPageSize,
    searchUsers,
    refreshUsers,
    resetFilters,
  };
}
