"use client"

import { useAuth } from "@/app/providers"

/**
 * Vérifie si le rôle courant fait partie de la liste autorisée (comparaison insensible à la casse).
 * Utile pour les écrans réservés à certains profils (ex. journal d’audit ADMIN / DAF).
 */
export function useOnlyRole(allowedRoleCodes: readonly string[]) {
  const { user } = useAuth()
  const roleCode = (user?.role?.code ?? "").toUpperCase()
  const allowed = allowedRoleCodes.some((r) => r.toUpperCase() === roleCode)

  return { allowed, roleCode, user }
}

/**
 * Rôles autorisés pour la page Journal d’activité (`/logs`) — repli sans liste RBAC en session.
 * Préférer {@code canAccessLogsPage} depuis {@code lib/utils/functionality-permissions} pour la garde réelle.
 */
export const LOGS_PAGE_ROLES = ["ADMIN", "DAF"] as const
