/**
 * Hook personnalisé pour la gestion des structures administratives
 */

import { logger } from '@/lib/utils/logger'

import { useState, useEffect, useCallback, useRef } from 'react';
import { structuresService, Drena, Iepp, Epp } from '@/lib/services/structures.service';

export interface UseStructuresReturn {
  // États
  drenas: Drena[];
  iepps: Iepp[];
  epps: Epp[];
  loading: boolean;
  error: string | null;

  // Actions
  loadDrenas: () => Promise<void>;
  loadIepps: (drenaId?: number) => Promise<void>;
  loadEpps: (drenaId?: number, ieppId?: number) => Promise<void>;
  /** Vide uniquement la liste EPP (ex. après désélection de l’IEPP sans changement de DRENA). */
  clearEpps: () => void;
  /** Vide IEPP et EPP (ex. après désélection de la DRENA). */
  clearIeppsAndEpps: () => void;
  clearStructures: () => void;
  getDrenaById: (id: number) => Drena | undefined;
  getIeppById: (id: number) => Iepp | undefined;
  getEppById: (id: number) => Epp | undefined;
}

export function useStructures(): UseStructuresReturn {
  const [drenas, setDrenas] = useState<Drena[]>([]);
  const [iepps, setIepps] = useState<Iepp[]>([]);
  const [epps, setEpps] = useState<Epp[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  /** Évite d’appliquer une réponse réseau obsolète si l’utilisateur change vite de DRENA / IEPP. */
  const ieppsLoadSeq = useRef(0);
  const eppsLoadSeq = useRef(0);

  // Charger toutes les DRENA
  const loadDrenas = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      const response = await structuresService.getDrenas({ isActive: true });
      if (response.items) {
        // S'assurer que response.items est un tableau plat
        let drenasTemp: any[] = [];
        if (Array.isArray(response.items)) {
          // Si c'est un tableau, vérifier s'il contient des tableaux imbriqués
          if (response.items.length > 0 && Array.isArray(response.items[0])) {
            // Aplatir le tableau de tableaux
            drenasTemp = (response.items as unknown as any[]).flat();
          } else {
            drenasTemp = (response.items as unknown as any[]);
          }
        }
        
        // Convertir explicitement en Drena[]
        const drenas: Drena[] = drenasTemp as unknown as Drena[];
        
        setDrenas(drenas);
      }
    } catch (err: any) {
      logger.error('Erreur lors du chargement des DRENA:', err);
      
      // Si c'est une erreur de token invalide ou session expirée, ne pas afficher d'erreur
      // car l'utilisateur sera automatiquement déconnecté
      if (err.code === '900' && (err.message.includes('Token invalide') || err.message.includes('Session expirée'))) {
        return; // La déconnexion est gérée par le service de base
      }
      
      // Si c'est une erreur d'utilisateur non connecté, ne pas afficher d'erreur
      if (err.message === 'Utilisateur non connecté') {
        return;
      }
      
      setError('Erreur lors du chargement des DRENA');
    } finally {
      setLoading(false);
    }
  }, []);

  // Charger les IEPP (optionnellement filtrées par DRENA)
  const loadIepps = useCallback(async (drenaId?: number) => {
    const seq = ++ieppsLoadSeq.current;
    try {
      setLoading(true);
      setError(null);

      // Nouvelle portée DRENA : ne plus afficher les IEPP/EPP de la sélection précédente
      if (drenaId != null) {
        setIepps([]);
        setEpps([]);
      }

      let response;
      if (drenaId) {
        // Charger les IEPP d'une DRENA spécifique
        response = await structuresService.getIeppsByDrena(drenaId);
      } else {
        // Charger toutes les IEPP
        response = await structuresService.getIepps({ isActive: true });
      }

      if (seq !== ieppsLoadSeq.current) {
        return;
      }

      if (response.items) {
        // S'assurer que response.items est un tableau plat
        let ieppsTemp: any[] = [];
        if (Array.isArray(response.items)) {
          if (response.items.length > 0 && Array.isArray(response.items[0])) {
            ieppsTemp = (response.items as unknown as any[]).flat();
          } else {
            ieppsTemp = (response.items as unknown as any[]);
          }
        }
        const iepps: Iepp[] = ieppsTemp as unknown as Iepp[];
        setIepps(iepps);
      }
    } catch (err: any) {
      logger.error('Erreur lors du chargement des IEPP:', err);
      
      // Si c'est une erreur de token invalide ou session expirée, ne pas afficher d'erreur
      // car l'utilisateur sera automatiquement déconnecté
      if (err.code === '900' && (err.message.includes('Token invalide') || err.message.includes('Session expirée'))) {
        return; // La déconnexion est gérée par le service de base
      }
      
      // Si c'est une erreur d'utilisateur non connecté, ne pas afficher d'erreur
      if (err.message === 'Utilisateur non connecté') {
        return;
      }
      
      setError('Erreur lors du chargement des IEPP');
    } finally {
      setLoading(false);
    }
  }, []);

  // Charger les EPP (optionnellement filtrées par DRENA et/ou IEPP)
  const loadEpps = useCallback(async (drenaId?: number, ieppId?: number) => {
    const seq = ++eppsLoadSeq.current;
    try {
      setLoading(true);
      setError(null);

      // Chargement filtré : vider tout de suite pour ne pas garder les EPP de l’IEPP / DRENA précédente
      const filtered = drenaId != null || ieppId != null;
      if (filtered) {
        setEpps([]);
      }

      let response;
      if (ieppId) {
        // Charger les EPP d'une IEPP spécifique
        response = await structuresService.getEppsByIepp(ieppId);
      } else if (drenaId) {
        // Charger les EPP d'une DRENA spécifique
        response = await structuresService.getEppsByDrena(drenaId);
      } else {
        // Charger toutes les EPP
        response = await structuresService.getEpps({ isActive: true });
      }

      if (seq !== eppsLoadSeq.current) {
        return;
      }

      if (response.items) {
        // S'assurer que response.items est un tableau plat
        let eppsTemp: any[] = [];
        if (Array.isArray(response.items)) {
          if (response.items.length > 0 && Array.isArray(response.items[0])) {
            eppsTemp = (response.items as unknown as any[]).flat();
          } else {
            eppsTemp = (response.items as unknown as any[]);
          }
        }
        const epps: Epp[] = eppsTemp as unknown as Epp[];
        setEpps(epps);
      }
    } catch (err: any) {
      logger.error('Erreur lors du chargement des EPP:', err);
      
      // Si c'est une erreur de token invalide ou session expirée, ne pas afficher d'erreur
      // car l'utilisateur sera automatiquement déconnecté
      if (err.code === '900' && (err.message.includes('Token invalide') || err.message.includes('Session expirée'))) {
        return; // La déconnexion est gérée par le service de base
      }
      
      // Si c'est une erreur d'utilisateur non connecté, ne pas afficher d'erreur
      if (err.message === 'Utilisateur non connecté') {
        return;
      }
      
      setError('Erreur lors du chargement des EPP');
    } finally {
      setLoading(false);
    }
  }, []);

  const clearEpps = useCallback(() => {
    eppsLoadSeq.current += 1;
    setEpps([]);
  }, []);

  const clearIeppsAndEpps = useCallback(() => {
    ieppsLoadSeq.current += 1;
    eppsLoadSeq.current += 1;
    setIepps([]);
    setEpps([]);
  }, []);

  // Vider les structures
  const clearStructures = useCallback(() => {
    setDrenas([]);
    setIepps([]);
    setEpps([]);
    setError(null);
  }, []);

  // Récupérer une DRENA par ID
  const getDrenaById = useCallback((id: number): Drena | undefined => {
    return drenas.find(drena => drena.id === id);
  }, [drenas]);

  // Récupérer une IEPP par ID
  const getIeppById = useCallback((id: number): Iepp | undefined => {
    return iepps.find(iepp => iepp.id === id);
  }, [iepps]);

  // Récupérer une EPP par ID
  const getEppById = useCallback((id: number): Epp | undefined => {
    return epps.find(epp => epp.id === id);
  }, [epps]);

  // Charger les DRENA au montage du composant seulement si l'utilisateur est connecté
  useEffect(() => {
    // Vérifier si l'utilisateur est connecté avant de charger les structures
    if (typeof window !== 'undefined') {
      const userSession = localStorage.getItem('dismas_user') || localStorage.getItem('user_session');
      const authToken = localStorage.getItem('auth_token');
      
      logger.log('useStructures - Vérification de connexion:', {
        userSession: !!userSession,
        authToken: !!authToken,
        userSessionContent: userSession ? JSON.parse(userSession) : null
      });
      
      if (userSession && authToken) {
        logger.log('useStructures - Chargement des DRENA...');
        loadDrenas();
      } else {
        logger.log('useStructures - Utilisateur non connecté, pas de chargement des structures');
      }
    }
  }, [loadDrenas]);

  return {
    // États
    drenas,
    iepps,
    epps,
    loading,
    error,

    // Actions
    loadDrenas,
    loadIepps,
    loadEpps,
    clearEpps,
    clearIeppsAndEpps,
    clearStructures,
    getDrenaById,
    getIeppById,
    getEppById,
  };
}