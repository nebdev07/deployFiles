// Script de test simple pour diagnostiquer les problèmes
const { chromium } = require('playwright');

async function testBasic() {
  console.log('🧪 Test de base pour diagnostiquer les problèmes...\n');
  
  let browser;
  let success = true;
  
  try {
    // Test 1: Lancement du navigateur
    console.log('1️⃣ Test lancement navigateur...');
    browser = await chromium.launch({ headless: false });
    console.log('✅ Navigateur lancé avec succès\n');
    
    // Test 2: Accès à l'application
    console.log('2️⃣ Test accès application...');
    const page = await browser.newPage();
    await page.goto('http://localhost:3000', { timeout: 10000 });
    console.log('✅ Application accessible\n');
    
    // Test 3: Détection des éléments de login
    console.log('3️⃣ Test détection éléments login...');
    const loginInputs = await page.$$('input');
    console.log(`   📝 ${loginInputs.length} champs input trouvés`);
    
    const buttons = await page.$$('button');
    console.log(`   🔘 ${buttons.length} boutons trouvés`);
    
    // Test spécifique des sélecteurs
    const selectors = [
      'input[type="text"]',
      'input[type="password"]', 
      'button[type="submit"]',
      '.btn-primary'
    ];
    
    for (const selector of selectors) {
      try {
        const element = await page.$(selector);
        if (element) {
          console.log(`   ✅ Trouvé: ${selector}`);
        } else {
          console.log(`   ❌ Manque: ${selector}`);
          success = false;
        }
      } catch (error) {
        console.log(`   ❌ Erreur ${selector}: ${error.message}`);
        success = false;
      }
    }
    
    // Test 4: Capture d'écran de test
    console.log('\n4️⃣ Test capture d\'écran...');
    await page.screenshot({ path: './test-login-page.png', fullPage: true });
    console.log('✅ Capture test sauvegardée: test-login-page.png\n');
    
    // Test 5: Tentative de connexion
    console.log('5️⃣ Test connexion...');
    try {
      await page.fill('input[type="text"]', 'admin');
      await page.fill('input[type="password"]', 'admin123');
      console.log('   ✅ Champs remplis');
      
      await page.click('button[type="submit"]');
      console.log('   ✅ Bouton cliqué');
      
      await page.waitForTimeout(3000);
      const currentUrl = page.url();
      console.log(`   📍 URL actuelle: ${currentUrl}`);
      
      if (currentUrl.includes('dashboard')) {
        console.log('   ✅ Redirection vers dashboard réussie');
      } else {
        console.log('   ⚠️  Pas de redirection vers dashboard');
      }
      
    } catch (error) {
      console.log(`   ❌ Erreur connexion: ${error.message}`);
      success = false;
    }
    
  } catch (error) {
    console.log(`❌ Erreur générale: ${error.message}`);
    console.log(`   Stack: ${error.stack}`);
    success = false;
  } finally {
    if (browser) {
      await browser.close();
    }
  }
  
  console.log('\n' + '='.repeat(50));
  if (success) {
    console.log('🎉 TOUS LES TESTS PASSENT - Le script principal devrait fonctionner!');
    console.log('➡️  Lancez maintenant: node playwright-capture-script.js');
  } else {
    console.log('⚠️  PROBLÈMES DÉTECTÉS - Vérifiez les erreurs ci-dessus');
    console.log('📧 Envoyez-moi ces erreurs pour que je les corrige!');
  }
  console.log('='.repeat(50));
}

testBasic().catch(error => {
  console.error('💥 Erreur fatale du test:', error);
  console.log('\n📧 Envoyez-moi cette erreur complète pour diagnostic!');
});