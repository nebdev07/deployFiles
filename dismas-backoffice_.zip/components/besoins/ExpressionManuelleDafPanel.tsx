"use client"

import { useEffect, useRef, useState, type ChangeEvent } from "react"
import {
  ArrowDownTrayIcon,
  CloudArrowUpIcon,
  DocumentMagnifyingGlassIcon,
} from "@heroicons/react/24/outline"
import toast from "react-hot-toast"
import { besoinsService } from "@/lib/services/besoins.service"

type AnneeOption = { id: number; code?: string; libelle?: string }

interface ExpressionManuelleDafPanelProps {
  anneesScolaires: AnneeOption[]
  defaultAnneeId: number | null
  loadingAnnees?: boolean
}

export default function ExpressionManuelleDafPanel({
  anneesScolaires,
  defaultAnneeId,
  loadingAnnees,
}: ExpressionManuelleDafPanelProps) {
  const [anneeId, setAnneeId] = useState<number | null>(defaultAnneeId)
  const [exporting, setExporting] = useState(false)
  const [parsing, setParsing] = useState(false)
  const [committing, setCommitting] = useState(false)
  const [selectedFile, setSelectedFile] = useState<File | null>(null)
  const [lastParse, setLastParse] = useState<Record<string, unknown> | null>(null)
  const [lastCommit, setLastCommit] = useState<{
    besoinsCrees?: number
    besoinsMisAJour?: number
    structuresNonModifiees?: number
    warnings?: string[]
    profilingMsTotal?: number
    profilingMsBuildTemplate?: number
    profilingMsReadWorkbook?: number
    profilingMsBuildEppMaps?: number
    profilingMsEppPersistLoop?: number
    profilingMsConsolidationIepp?: number
    profilingMsPromoteEpp?: number
    profilingMsApproveIepp?: number
  } | null>(null)
  const [jobPolling, setJobPolling] = useState<string | null>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const pollAbortRef = useRef(false)

  useEffect(() => {
    if (defaultAnneeId != null) {
      setAnneeId(defaultAnneeId)
    }
  }, [defaultAnneeId])

  useEffect(() => {
    return () => {
      pollAbortRef.current = true
    }
  }, [])

  const handleDownload = async () => {
    if (anneeId == null) {
      toast.error("Choisissez une année scolaire.")
      return
    }
    setExporting(true)
    try {
      const r = await besoinsService.exportExpressionManuelleTemplateDafExcel(anneeId)
      if (!r.success || !r.data?.fileBase64) {
        toast.error(r.message || "Export impossible")
        return
      }
      const bin = atob(r.data.fileBase64)
      const bytes = new Uint8Array(bin.length)
      for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i)
      const blob = new Blob([bytes], {
        type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      })
      const a = document.createElement("a")
      a.href = URL.createObjectURL(blob)
      a.download = r.data.fileName || "expression_manuelle_DAF.xlsx"
      a.click()
      URL.revokeObjectURL(a.href)
      const n = r.data.rowCount
      toast.success(
        typeof n === "number"
          ? `Modèle téléchargé (${n.toLocaleString("fr-FR")} lignes).`
          : "Modèle téléchargé.",
      )
    } catch (e: unknown) {
      toast.error(e instanceof Error ? e.message : "Export impossible")
    } finally {
      setExporting(false)
    }
  }

  const handlePickFile = (e: ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0] ?? null
    e.target.value = ""
    setSelectedFile(f)
    setLastParse(null)
    setLastCommit(null)
    if (f) toast.success(`Fichier sélectionné : ${f.name}`)
  }

  const handleVerify = async () => {
    if (anneeId == null) {
      toast.error("Choisissez une année scolaire.")
      return
    }
    if (!selectedFile) {
      toast.error("Choisissez d’abord un fichier Excel.")
      return
    }
    setParsing(true)
    setLastParse(null)
    try {
      const r = await besoinsService.parseExpressionManuelleTemplateDafExcel(selectedFile, anneeId)
      if (!r.success) {
        toast.error(r.message || "Analyse impossible")
        return
      }
      setLastParse(r.data ?? null)
      const rec = Number(r.data?.lignesReconnues ?? 0)
      const pos = Number(r.data?.lignesQuantiteStrictementPositive ?? 0)
      const ign = Number(r.data?.lignesIgnorees ?? 0)
      toast.success(
        `Analyse OK : ${rec.toLocaleString("fr-FR")} ligne(s) reconnue(s), ${pos.toLocaleString("fr-FR")} avec quantité > 0, ${ign.toLocaleString("fr-FR")} ignorée(s).`,
      )
    } catch (err: unknown) {
      toast.error(err instanceof Error ? err.message : "Analyse impossible")
    } finally {
      setParsing(false)
    }
  }

  const handleCommit = async () => {
    if (anneeId == null) {
      toast.error("Choisissez une année scolaire.")
      return
    }
    if (!selectedFile) {
      toast.error("Choisissez d’abord un fichier Excel.")
      return
    }
    const ok = window.confirm(
      "Lancer l’import en arrière-plan ? Les quantités seront enregistrées, les besoins EPP consolidés avec l’IEPP, puis les besoins IEPP seront approuvés au niveau DAF (100 %, sous réserve du stock national) afin d’ouvrir la réception. Un e-mail vous sera envoyé à la fin. Les lignes déjà figées (déjà approuvées, etc.) ne seront pas modifiées.",
    )
    if (!ok) return
    setCommitting(true)
    setLastCommit(null)
    setJobPolling(null)
    pollAbortRef.current = false
    const POLL_MS = 3000
    const MAX_POLLS = 400
    try {
      const sub = await besoinsService.submitExpressionManuelleTemplateDafExcelAsync(selectedFile, anneeId)
      if (!sub.success || sub.jobId == null) {
        toast.error(sub.message || "Soumission impossible")
        return
      }
      toast.success(
        "Import accepté : traitement en cours sur le serveur (la plateforme reste utilisable). Vous recevrez un e-mail à la fin.",
        { duration: 6000 },
      )
      setJobPolling(`Tâche #${sub.jobId} — en attente / traitement…`)

      let lastStatus = ""
      for (let i = 0; i < MAX_POLLS; i++) {
        if (pollAbortRef.current) break
        await new Promise((r) => setTimeout(r, POLL_MS))
        const st = await besoinsService.getDafExpressionManuelleImportJobStatus(sub.jobId)
        if (!st.success || !st.data) {
          setJobPolling(`Tâche #${sub.jobId} — ${st.message}`)
          continue
        }
        const status = String(st.data.status ?? "")
        if (status && status !== lastStatus) {
          lastStatus = status
          setJobPolling(`Tâche #${sub.jobId} — ${status}`)
        }
        if (status === "FAILED") {
          toast.error(String(st.data.errorMessage ?? "Import en échec"))
          setJobPolling(null)
          return
        }
        if (status === "DONE") {
          const d = st.data
          const num = (k: string): number | undefined => {
            const v = d[k] as unknown
            if (typeof v === "number" && Number.isFinite(v)) return v
            if (typeof v === "string") {
              const n = Number(v)
              return Number.isFinite(n) ? n : undefined
            }
            return undefined
          }
          const summary = {
            besoinsCrees: typeof d.besoinsCrees === "number" ? d.besoinsCrees : Number(d.besoinsCrees) || 0,
            besoinsMisAJour: typeof d.besoinsMisAJour === "number" ? d.besoinsMisAJour : Number(d.besoinsMisAJour) || 0,
            structuresNonModifiees:
              typeof d.structuresNonModifiees === "number"
                ? d.structuresNonModifiees
                : Number(d.structuresNonModifiees) || 0,
            warnings: Array.isArray(d.warnings) ? (d.warnings as string[]) : undefined,
            profilingMsTotal: num("profilingMsTotal"),
            profilingMsBuildTemplate: num("profilingMsBuildTemplate"),
            profilingMsReadWorkbook: num("profilingMsReadWorkbook"),
            profilingMsBuildEppMaps: num("profilingMsBuildEppMaps"),
            profilingMsEppPersistLoop: num("profilingMsEppPersistLoop"),
            profilingMsConsolidationIepp: num("profilingMsConsolidationIepp"),
            profilingMsPromoteEpp: num("profilingMsPromoteEpp"),
            profilingMsApproveIepp: num("profilingMsApproveIepp"),
          }
          setLastCommit(summary)
          setJobPolling(null)
          toast.success(
            `Terminé : ${summary.besoinsCrees} créé(s), ${summary.besoinsMisAJour} mis à jour, ${summary.structuresNonModifiees} structure(s) inchangée(s) ou non modifiable(s).`,
          )
          if (summary.warnings?.length) {
            summary.warnings.forEach((w) => toast(w, { icon: "⚠️", duration: 8000 }))
          }
          return
        }
      }
      toast(
        "Le suivi automatique a expiré ; le traitement peut encore continuer côté serveur — vérifiez vos e-mails ou rechargez la page plus tard.",
        { icon: "ℹ️", duration: 8000 },
      )
    } catch (err: unknown) {
      toast.error(err instanceof Error ? err.message : "Enregistrement impossible")
    } finally {
      setCommitting(false)
    }
  }

  return (
    <div className="rounded-lg border border-amber-200 bg-amber-50/80 p-4 shadow-sm">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h3 className="text-base font-semibold text-gray-900">Expression manuelle (DAF / Admin)</h3>
          <p className="mt-1 max-w-3xl text-sm text-gray-700">
            Le fichier généré comporte une <strong>feuille par DRENA</strong> (onglets en bas). Une ligne = combinaison
            IEPP / EPP × matière × niveau × catalogue actif pour l’année. Seule la colonne{" "}
            <code className="rounded bg-white px-1 text-xs">quantite_SAISIE_DAF</code> est à saisir (0 par défaut). La
            colonne <code className="rounded bg-white px-1 text-xs">no_ordre_epp_dans_iepp</code> est un numéro d’ordre
            (liste EPP triée par libellé dans l’IEPP), pour la lecture seulement. L’enregistrement se fait en{" "}
            <strong>tâche de fond</strong> : consolidation IEPP puis <strong>approbation DAF des besoins IEPP</strong>{" "}
            (sous réserve du stock national) ; les EPP restent <strong>consolidés</strong>, ce qui correspond au flux
            réception / distribution attendu.
          </p>
        </div>
      </div>
      <div className="mt-4 flex flex-wrap items-end gap-3">
        <div>
          <label className="mb-1 block text-xs font-medium text-gray-600">Année scolaire du modèle</label>
          <select
            className="min-w-[220px] rounded-md border border-gray-300 bg-white px-3 py-2 text-sm"
            value={anneeId ?? ""}
            onChange={(e) => setAnneeId(e.target.value ? Number(e.target.value) : null)}
            disabled={Boolean(loadingAnnees) || anneesScolaires.length === 0}
          >
            <option value="">— Choisir —</option>
            {anneesScolaires.map((a) => (
              <option key={a.id} value={a.id}>
                {(a.libelle || a.code || `Année #${a.id}`) + (a.code ? ` (${a.code})` : "")}
              </option>
            ))}
          </select>
        </div>
        <button
          type="button"
          onClick={handleDownload}
          disabled={exporting || anneeId == null}
          className="inline-flex items-center gap-2 rounded-md bg-amber-700 px-3 py-2 text-sm font-medium text-white hover:bg-amber-800 disabled:opacity-50"
        >
          <ArrowDownTrayIcon className="h-5 w-5" />
          {exporting ? "Génération…" : "Télécharger le modèle Excel"}
        </button>
        <input
          ref={fileInputRef}
          type="file"
          accept=".xlsx,.xls"
          className="hidden"
          disabled={parsing || committing || anneeId == null}
          onChange={handlePickFile}
        />
        <button
          type="button"
          onClick={() => fileInputRef.current?.click()}
          disabled={parsing || committing || anneeId == null}
          className="inline-flex items-center gap-2 rounded-md border border-gray-300 bg-white px-3 py-2 text-sm font-medium text-gray-800 hover:bg-gray-50 disabled:opacity-50"
        >
          Choisir un fichier…
        </button>
        <button
          type="button"
          onClick={handleVerify}
          disabled={parsing || committing || anneeId == null || !selectedFile}
          className="inline-flex items-center gap-2 rounded-md border border-gray-300 bg-white px-3 py-2 text-sm font-medium text-gray-800 hover:bg-gray-50 disabled:opacity-50"
        >
          <DocumentMagnifyingGlassIcon className="h-5 w-5 text-gray-600" />
          {parsing ? "Analyse…" : "Vérifier"}
        </button>
        <button
          type="button"
          onClick={handleCommit}
          disabled={parsing || committing || anneeId == null || !selectedFile}
          className="inline-flex items-center gap-2 rounded-md bg-emerald-700 px-3 py-2 text-sm font-medium text-white hover:bg-emerald-800 disabled:opacity-50"
        >
          <CloudArrowUpIcon className="h-5 w-5" />
          {committing ? "Import en cours…" : "Enregistrer en base (asynchrone)"}
        </button>
      </div>
      {jobPolling && (
        <p className="mt-2 rounded-md border border-blue-200 bg-blue-50 px-3 py-2 text-sm text-blue-900">{jobPolling}</p>
      )}
      {selectedFile && (
        <p className="mt-2 text-xs text-gray-600">
          Fichier : <span className="font-medium text-gray-800">{selectedFile.name}</span>
        </p>
      )}
      {lastParse && (
        <div className="mt-3 rounded-md border border-amber-100 bg-white/90 p-3 text-sm text-gray-800">
          <p className="font-medium text-gray-900">Dernier résultat de contrôle</p>
          <ul className="mt-2 list-inside list-disc space-y-1 text-gray-700">
            <li>Reconnues : {String(lastParse.lignesReconnues ?? "—")}</li>
            <li>Quantité {">"} 0 : {String(lastParse.lignesQuantiteStrictementPositive ?? "—")}</li>
            <li>Ignorées (hors périmètre) : {String(lastParse.lignesIgnorees ?? "—")}</li>
          </ul>
          {typeof lastParse.message === "string" && lastParse.message.length > 0 && (
            <p className="mt-2 text-xs text-gray-600">{lastParse.message}</p>
          )}
        </div>
      )}
      {lastCommit && (
        <div className="mt-3 rounded-md border border-emerald-100 bg-white/90 p-3 text-sm text-gray-800">
          <p className="font-medium text-gray-900">Dernier enregistrement</p>
          <ul className="mt-2 list-inside list-disc space-y-1 text-gray-700">
            <li>Besoins créés : {String(lastCommit.besoinsCrees ?? "—")}</li>
            <li>Besoins mis à jour : {String(lastCommit.besoinsMisAJour ?? "—")}</li>
            <li>Structures non modifiées : {String(lastCommit.structuresNonModifiees ?? "—")}</li>
          </ul>
          {lastCommit.warnings && lastCommit.warnings.length > 0 && (
            <ul className="mt-2 list-inside list-disc text-amber-800">
              {lastCommit.warnings.map((w, i) => (
                <li key={i}>{w}</li>
              ))}
            </ul>
          )}
          {typeof lastCommit.profilingMsTotal === "number" && (
            <div className="mt-3 rounded border border-slate-200 bg-slate-50/80 px-3 py-2 text-xs text-slate-800">
              <p className="font-medium text-slate-900">Durée côté serveur (ms)</p>
              <ul className="mt-1 grid gap-0.5 sm:grid-cols-2">
                <li>Total : {lastCommit.profilingMsTotal}</li>
                {lastCommit.profilingMsBuildTemplate != null && (
                  <li>Modèle : {lastCommit.profilingMsBuildTemplate}</li>
                )}
                {lastCommit.profilingMsReadWorkbook != null && (
                  <li>Lecture fichier : {lastCommit.profilingMsReadWorkbook}</li>
                )}
                {lastCommit.profilingMsBuildEppMaps != null && (
                  <li>Cartes EPP : {lastCommit.profilingMsBuildEppMaps}</li>
                )}
                {lastCommit.profilingMsEppPersistLoop != null && (
                  <li>Enregistrement EPP : {lastCommit.profilingMsEppPersistLoop}</li>
                )}
                {lastCommit.profilingMsConsolidationIepp != null && (
                  <li>Consolidation IEPP : {lastCommit.profilingMsConsolidationIepp}</li>
                )}
                {lastCommit.profilingMsPromoteEpp != null && (
                  <li>Post-import EPP : {lastCommit.profilingMsPromoteEpp}</li>
                )}
                {lastCommit.profilingMsApproveIepp != null && (
                  <li>Approbation IEPP : {lastCommit.profilingMsApproveIepp}</li>
                )}
              </ul>
            </div>
          )}
        </div>
      )}
    </div>
  )
}
