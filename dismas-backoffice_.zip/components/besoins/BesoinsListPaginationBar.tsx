"use client"

const PAGE_SIZE_OPTIONS = [10, 25, 50, 100, 200] as const

export type BesoinsListPaginationBarProps = {
  total: number
  page: number
  pageSize: number
  onPageChange: (page: number) => void
  onPageSizeChange: (size: number) => void
  /** Libellé court pour le contexte (ex. « lignes », « IEPP ») */
  itemLabel?: string
  className?: string
}

/**
 * Pagination client pour les grands volumes (jusqu’à des dizaines de milliers de lignes côté données chargées).
 * Affiche plage 1-based, taille de page DISMAS (10–200).
 */
export function BesoinsListPaginationBar({
  total,
  page,
  pageSize,
  onPageChange,
  onPageSizeChange,
  itemLabel = "lignes",
  className = "",
}: BesoinsListPaginationBarProps) {
  const totalPages = Math.max(1, Math.ceil(total / pageSize))
  const safePage = Math.min(Math.max(1, page), totalPages)
  const from = total === 0 ? 0 : (safePage - 1) * pageSize + 1
  const to = Math.min(total, safePage * pageSize)

  return (
    <div
      className={`flex flex-wrap items-center justify-between gap-3 border-t border-gray-200 bg-gray-50/90 px-4 py-3 text-sm text-gray-700 ${className}`}
    >
      <div className="flex flex-wrap items-center gap-2">
        <span className="text-gray-600">
          {total === 0 ? (
            <>Aucun élément</>
          ) : (
            <>
              <span className="font-medium text-gray-900">
                {from.toLocaleString("fr-FR")} – {to.toLocaleString("fr-FR")}
              </span>{" "}
              sur {total.toLocaleString("fr-FR")} {itemLabel}
            </>
          )}
        </span>
        <label className="inline-flex items-center gap-1.5 text-gray-600">
          <span className="sr-only">Taille de page</span>
          <span className="hidden sm:inline">Par page</span>
          <select
            value={pageSize}
            onChange={(e) => onPageSizeChange(Number(e.target.value))}
            className="rounded-md border border-gray-300 bg-white px-2 py-1 text-sm shadow-sm focus:border-orange-500 focus:outline-none focus:ring-1 focus:ring-orange-500"
          >
            {PAGE_SIZE_OPTIONS.map((n) => (
              <option key={n} value={n}>
                {n}
              </option>
            ))}
          </select>
        </label>
      </div>
      <div className="flex items-center gap-2">
        <button
          type="button"
          disabled={safePage <= 1}
          onClick={() => onPageChange(safePage - 1)}
          className="rounded-md border border-gray-300 bg-white px-3 py-1.5 text-sm font-medium text-gray-800 shadow-sm hover:bg-gray-50 disabled:cursor-not-allowed disabled:opacity-40"
        >
          Précédent
        </button>
        <span className="tabular-nums text-gray-600">
          Page {safePage} / {totalPages}
        </span>
        <button
          type="button"
          disabled={safePage >= totalPages}
          onClick={() => onPageChange(safePage + 1)}
          className="rounded-md border border-gray-300 bg-white px-3 py-1.5 text-sm font-medium text-gray-800 shadow-sm hover:bg-gray-50 disabled:cursor-not-allowed disabled:opacity-40"
        >
          Suivant
        </button>
      </div>
    </div>
  )
}

export function sliceBesoinsPage<T>(items: readonly T[], page: number, pageSize: number): T[] {
  const total = items.length
  const totalPages = Math.max(1, Math.ceil(total / pageSize))
  const safePage = Math.min(Math.max(1, page), totalPages)
  const start = (safePage - 1) * pageSize
  return items.slice(start, start + pageSize)
}
