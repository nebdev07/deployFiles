"use client"

import Link from "next/link"
import { usePathname, useSearchParams } from "next/navigation"
import { buildBesoinsNavTabs, resolveBesoinsActiveTab } from "@/lib/besoins-nav"

type BesoinsSubNavProps = {
  roleCode: string
  functionalityPermissions?: string[]
}

export function BesoinsSubNav({ roleCode, functionalityPermissions }: BesoinsSubNavProps) {
  const pathname = usePathname()
  const searchParams = useSearchParams()
  const tabs = buildBesoinsNavTabs(roleCode, functionalityPermissions)
  const tabQuery = searchParams.get("tab")
  const activeInternalTab = resolveBesoinsActiveTab(roleCode, tabQuery, functionalityPermissions)
  const onBesoinsRoot =
    pathname === "/besoins" || pathname === "/besoins/"

  return (
    <div className="border-b border-gray-200">
      <nav className="-mb-px flex flex-wrap gap-x-6 gap-y-1">
        {tabs.map((tab) => {
          const isRouteTab = Boolean(tab.href)
          const isActive = isRouteTab
            ? pathname === tab.href || pathname?.startsWith(`${tab.href}/`)
            : onBesoinsRoot && activeInternalTab === tab.id

          const className = `py-2 px-1 border-b-2 font-medium text-sm inline-flex items-center space-x-2 ${
            isActive
              ? "border-orange-500 text-orange-600"
              : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
          }`

          if (isRouteTab) {
            return (
              <Link key={tab.id} href={tab.href!} className={className}>
                <tab.icon className="h-4 w-4 shrink-0" />
                <span>{tab.name}</span>
              </Link>
            )
          }

          return (
            <Link key={tab.id} href={`/besoins?tab=${tab.id}`} className={className} scroll={false}>
              <tab.icon className="h-4 w-4 shrink-0" />
              <span>{tab.name}</span>
            </Link>
          )
        })}
      </nav>
    </div>
  )
}
