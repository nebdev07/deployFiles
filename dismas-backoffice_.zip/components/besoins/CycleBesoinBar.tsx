"use client"

import { useState } from "react"
import { ClockIcon, ExclamationTriangleIcon } from "@heroicons/react/24/outline"
import type { CycleBesoinContext } from "@/lib/services/cycle-besoin.service"
import { cycleBesoinService } from "@/lib/services/cycle-besoin.service"
import toast from "react-hot-toast"

function formatCountdown(seconds: number | null | undefined): string {
  if (seconds == null || seconds < 0) return "—"
  const d = Math.floor(seconds / 86400)
  const h = Math.floor((seconds % 86400) / 3600)
  const m = Math.floor((seconds % 3600) / 60)
  if (d > 0) return `${d} j ${h} h`
  if (h > 0) return `${h} h ${m} min`
  return `${m} min`
}

export type CycleBesoinBarProps = {
  anneeScolaireId: number | null
  structureType?: string
  roleCode?: string
  ctx: CycleBesoinContext | null
  loading?: boolean
  onReload: () => void | Promise<void>
}

export function CycleBesoinBar({ anneeScolaireId, structureType, roleCode, ctx, loading, onReload }: CycleBesoinBarProps) {
  const [dateInput, setDateInput] = useState("")
  const [saving, setSaving] = useState(false)

  if (!anneeScolaireId) {
    return null
  }

  const typ = (structureType || "").toUpperCase()
  const role = (roleCode || "").toUpperCase()
  const canParametrer = typ === "IEPP" || typ === "DAF" || role === "ADMIN"

  const handleSaveDate = async () => {
    if (!dateInput) {
      toast.error("Choisissez une date")
      return
    }
    setSaving(true)
    try {
      const res = await cycleBesoinService.saveDatePrevue(anneeScolaireId, `${dateInput}T08:00:00`)
      if (res.hasError) {
        toast.error(res.status?.message || "Enregistrement impossible")
        return
      }
      toast.success("Date du cycle enregistrée")
      await onReload()
    } catch (e: unknown) {
      toast.error(e instanceof Error ? e.message : "Erreur")
    } finally {
      setSaving(false)
    }
  }

  if (loading && !ctx) {
    return (
      <div className="mb-4 rounded-lg border border-gray-200 bg-white px-4 py-3 text-sm text-gray-600">
        Chargement du calendrier cycle besoins…
      </div>
    )
  }

  if (!ctx) {
    return null
  }

  const blocked = ctx.expressionBesoinAutorisee === false
  /** Après consolidation IEPP, `expressionEppFermeeAt` est posé : le décompte vers la date annoncée n’a plus de sens. */
  const cycleCalendrierFerme = Boolean(ctx.expressionEppFermeeAt)
  const showCountdown =
    !cycleCalendrierFerme &&
    (typ === "EPP" || typ === "IEPP") &&
    ctx.datePrevue != null &&
    ctx.secondsUntilDatePrevue != null

  return (
    <div className="mb-4 space-y-3">
      {blocked && (
        <div
          className="flex items-start gap-3 rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-900"
          role="alert"
        >
          <ExclamationTriangleIcon className="h-5 w-5 shrink-0 text-red-600" />
          <div>
            <span className="font-medium">Expression de besoin fermée</span>
            <p className="mt-1 text-red-800">{ctx.motifBlocage || "Contactez votre IEPP."}</p>
          </div>
        </div>
      )}

      {showCountdown && !blocked && (
        <div className="flex flex-wrap items-center gap-3 rounded-lg border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-950">
          <ClockIcon className="h-5 w-5 shrink-0 text-amber-700" />
          <div>
            <span className="font-medium">Date prévue de consolidation IEPP</span>
            {ctx.ieppLibelle ? (
              <span className="text-amber-900"> — {ctx.ieppLibelle}</span>
            ) : null}
            <div className="mt-1 tabular-nums text-amber-900">
              Temps restant avant la date annoncée : <strong>{formatCountdown(ctx.secondsUntilDatePrevue)}</strong>
            </div>
          </div>
        </div>
      )}

      {canParametrer && (typ === "IEPP" || typ === "DAF") && (
        <div className="flex flex-wrap items-end gap-3 rounded-lg border border-gray-200 bg-white px-4 py-3 text-sm">
          <div>
            <label className="block text-xs font-medium text-gray-600">
              {typ === "IEPP" ? "Date prévue de consolidation des besoins EPP" : "Date objectif d’approbation DAF"}
            </label>
            <input
              type="date"
              className="mt-1 rounded border border-gray-300 px-2 py-1"
              value={dateInput}
              onChange={(e) => setDateInput(e.target.value)}
            />
          </div>
          <button
            type="button"
            disabled={saving}
            onClick={handleSaveDate}
            className="rounded bg-gray-900 px-3 py-1.5 text-white hover:bg-gray-800 disabled:opacity-50"
          >
            {saving ? "…" : "Enregistrer"}
          </button>
          {ctx.datePrevue && (
            <span className="text-gray-600">
              Actuellement : {new Date(ctx.datePrevue).toLocaleDateString("fr-FR")}
            </span>
          )}
        </div>
      )}
    </div>
  )
}
