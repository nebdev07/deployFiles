"use client"

/**
 * États de chargement partagés pour le module Besoins (listes longues, agrégations).
 */

export function BesoinsSpinner({ className = "h-10 w-10" }: { className?: string }) {
  return (
    <div
      className={`animate-spin rounded-full border-2 border-orange-200 border-t-orange-600 ${className}`}
      role="status"
      aria-label="Chargement"
    />
  )
}

type BesoinsSectionLoaderProps = {
  title?: string
  subtitle?: string
  className?: string
}

export function BesoinsSectionLoader({
  title = "Chargement des données",
  subtitle = "Récupération des besoins et préparation des indicateurs…",
  className = "",
}: BesoinsSectionLoaderProps) {
  return (
    <div
      className={`flex min-h-[280px] flex-col items-center justify-center rounded-xl border border-slate-200 bg-gradient-to-b from-slate-50/90 to-white px-6 py-16 text-center shadow-sm ${className}`}
    >
      <BesoinsSpinner className="h-12 w-12" />
      <p className="mt-5 text-sm font-semibold text-slate-800">{title}</p>
      <p className="mt-2 max-w-md text-xs leading-relaxed text-slate-500">{subtitle}</p>
    </div>
  )
}

/** Overlay semi-opaque sur une zone relative (ex. contenu d’un onglet) */
export function BesoinsDataOverlay({
  visible,
  title = "Chargement en cours",
  subtitle = "Merci de patienter pendant la récupération des besoins et le calcul des totaux.",
}: {
  visible: boolean
  title?: string
  subtitle?: string
}) {
  if (!visible) return null
  return (
    <div
      className="absolute inset-0 z-20 flex flex-col items-center justify-center rounded-lg bg-white/85 backdrop-blur-[2px]"
      role="status"
      aria-live="polite"
      aria-busy="true"
    >
      <BesoinsSpinner className="h-11 w-11" />
      <p className="mt-4 text-sm font-semibold text-gray-800">{title}</p>
      <p className="mt-1 max-w-sm px-4 text-center text-xs text-gray-500">{subtitle}</p>
    </div>
  )
}

/** Skeleton pour la grille KPI (synthèse catalogue) */
export function BesoinsKpiSkeletonGrid({ columns = 4 }: { columns?: number }) {
  return (
    <div
      className={`grid gap-4 sm:grid-cols-2 ${
        columns >= 4 ? "lg:grid-cols-4" : "lg:grid-cols-2"
      }`}
    >
      {Array.from({ length: columns }).map((_, i) => (
        <div
          key={i}
          className="animate-pulse rounded-xl border border-slate-200 bg-white p-5 shadow-sm"
        >
          <div className="h-3 w-24 rounded bg-slate-200" />
          <div className="mt-4 h-8 w-32 rounded bg-slate-200" />
          <div className="mt-2 h-3 w-40 rounded bg-slate-100" />
        </div>
      ))}
    </div>
  )
}

/** Skeleton tableau (lignes factices) */
export function BesoinsTableSkeleton({ rows = 6 }: { rows?: number }) {
  return (
    <div className="overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm">
      <div className="border-b border-slate-100 bg-slate-50 px-5 py-3">
        <div className="h-4 w-48 animate-pulse rounded bg-slate-200" />
      </div>
      <div className="divide-y divide-slate-100">
        {Array.from({ length: rows }).map((_, i) => (
          <div key={i} className="flex gap-4 px-5 py-3">
            <div className="h-4 flex-1 animate-pulse rounded bg-slate-100" />
            <div className="h-4 w-20 animate-pulse rounded bg-slate-100" />
            <div className="h-4 w-24 animate-pulse rounded bg-slate-100" />
            <div className="h-4 w-16 animate-pulse rounded bg-slate-100" />
          </div>
        ))}
      </div>
    </div>
  )
}
