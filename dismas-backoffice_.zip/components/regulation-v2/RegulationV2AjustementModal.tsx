"use client"

import { useEffect, useMemo, useState } from "react"
import { regulationV2Service, type RegulationV2SuiviLigneRow } from "@/lib/services/regulation-v2.service"
import { formatRegulationReferenceForDisplay } from "@/lib/regulation-display"
import { plafondQuantiteAccordeeLigne } from "@/lib/regulation-v2-ajustement"
import { toast } from "sonner"
import { getApiErrorMessage } from "@/lib/utils/api-error-message"

type Props = {
  open: boolean
  onClose: () => void
  regulationId: number
  referenceLabel?: string
  /** Lignes ACCEPTE de cette demande (suivi IEPP). */
  lignesAcceptees: RegulationV2SuiviLigneRow[]
  onSaved: () => void | Promise<void>
}

type GroupeDest = {
  structureDestId: number
  label: string
  rows: RegulationV2SuiviLigneRow[]
}

function fmtStructure(
  libelle: string | undefined,
  code: string | undefined,
  structureId: number | undefined
): string {
  const l = libelle?.trim()
  if (l && code) return `${l} (${code})`
  if (l) return l
  if (code?.trim()) return code.trim()
  if (structureId != null) return `#${structureId}`
  return "—"
}

export function RegulationV2AjustementModal({
  open,
  onClose,
  regulationId,
  referenceLabel,
  lignesAcceptees,
  onSaved,
}: Props) {
  const [draft, setDraft] = useState<Record<number, number>>({})
  const [saving, setSaving] = useState(false)

  useEffect(() => {
    if (!open) return
    const next: Record<number, number> = {}
    for (const row of lignesAcceptees) {
      next[row.ligneId] = row.quantite
    }
    setDraft(next)
  }, [open, lignesAcceptees])

  const groupesParDest = useMemo(() => {
    const m = new Map<number, RegulationV2SuiviLigneRow[]>()
    for (const row of lignesAcceptees) {
      const did = row.structureDestId
      const key = typeof did === "number" && Number.isFinite(did) ? did : -1
      if (!m.has(key)) m.set(key, [])
      m.get(key)!.push(row)
    }
    const out: GroupeDest[] = [...m.entries()].map(([structureDestId, rows]) => {
      const sorted = [...rows].sort((a, b) => (a.ligneId ?? 0) - (b.ligneId ?? 0))
      const head = sorted[0]
      const label = fmtStructure(head?.structureDestLibelle, head?.structureDestCode, structureDestId === -1 ? undefined : structureDestId)
      return { structureDestId, label, rows: sorted }
    })
    out.sort((a, b) => a.label.localeCompare(b.label, "fr"))
    return out
  }, [lignesAcceptees])

  const handleSave = async () => {
    const ajustements: Array<{ ligneId: number; quantite: number }> = []
    for (const row of lignesAcceptees) {
      const max = plafondQuantiteAccordeeLigne(row.quantite, row.quantiteAccordSource)
      const raw = draft[row.ligneId]
      const q = Number.isFinite(raw) ? Math.max(0, Math.floor(raw)) : 0
      if (q > max) {
        toast.error(`Quantité trop élevée pour une ligne (max ${max})`)
        return
      }
      ajustements.push({ ligneId: row.ligneId, quantite: Math.min(q, max) })
    }
    setSaving(true)
    try {
      const r = await regulationV2Service.ajusterQuantitesExecution({ regulationId, ajustements })
      if (r.hasError) {
        toast.error(r.status?.message ?? "Ajustement refusé")
        return
      }
      toast.success("Quantités enregistrées")
      await onSaved()
      onClose()
    } catch (e: unknown) {
      toast.error(getApiErrorMessage(e, "Erreur lors de l’enregistrement"))
    } finally {
      setSaving(false)
    }
  }

  if (!open) return null

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4" role="dialog" aria-modal="true">
      <div className="max-h-[90vh] w-full max-w-3xl overflow-hidden rounded-lg bg-white shadow-xl flex flex-col">
        <div className="border-b border-gray-200 px-4 py-3 flex items-start justify-between gap-3">
          <div>
            <h2 className="text-lg font-semibold text-gray-900">Ajuster les quantités avant exécution</h2>
            <p className="text-sm text-gray-600 mt-0.5">
              {formatRegulationReferenceForDisplay(referenceLabel) || `Demande #${regulationId}`} — par EPP déficit (destination), sans dépasser
              l’accord de chaque source.
            </p>
          </div>
          <button type="button" className="text-gray-500 hover:text-gray-800 text-sm shrink-0" onClick={onClose}>
            Fermer
          </button>
        </div>
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {lignesAcceptees.length === 0 ? (
            <p className="text-sm text-gray-500">Aucune ligne acceptée à ajuster.</p>
          ) : (
            groupesParDest.map((g) => (
              <div key={g.structureDestId} className="rounded-lg border border-gray-200 overflow-hidden">
                <div className="bg-emerald-50 border-b border-emerald-100 px-3 py-2 text-sm font-semibold text-emerald-950">
                  EPP destination (déficit) : {g.label}
                </div>
                <div className="overflow-x-auto">
                  <table className="min-w-full text-sm">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-3 py-2 text-left">EPP source</th>
                        <th className="px-3 py-2 text-left">Matière / niveau</th>
                        <th className="px-3 py-2 text-right">Max (accord)</th>
                        <th className="px-3 py-2 text-right">Qté</th>
                      </tr>
                    </thead>
                    <tbody>
                      {g.rows.map((row) => {
                        const max = plafondQuantiteAccordeeLigne(row.quantite, row.quantiteAccordSource)
                        const src = fmtStructure(row.structureSourceLibelle, row.structureSourceCode, row.structureSourceId)
                        const mat = row.matiereLibelle?.trim()
                          ? row.matiereCode
                            ? `${row.matiereLibelle} (${row.matiereCode})`
                            : row.matiereLibelle
                          : row.matiereCode ?? "—"
                        const niv = row.niveauLibelle?.trim()
                          ? row.niveauCode
                            ? `${row.niveauLibelle} (${row.niveauCode})`
                            : row.niveauLibelle
                          : row.niveauCode ?? "—"
                        return (
                          <tr key={row.ligneId} className="border-t border-gray-100">
                            <td className="px-3 py-2 text-gray-800">{src}</td>
                            <td className="px-3 py-2">
                              {mat} — {niv}
                            </td>
                            <td className="px-3 py-2 text-right text-gray-600">{max}</td>
                            <td className="px-3 py-2 text-right">
                              <input
                                type="number"
                                min={0}
                                max={max}
                                className="input-field w-24 text-right"
                                value={draft[row.ligneId] ?? ""}
                                onChange={(e) => {
                                  const n = e.target.value === "" ? 0 : Number(e.target.value)
                                  const q = Number.isFinite(n) ? Math.max(0, Math.floor(n)) : 0
                                  setDraft((prev) => ({ ...prev, [row.ligneId]: Math.min(q, max) }))
                                }}
                              />
                            </td>
                          </tr>
                        )
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
            ))
          )}
        </div>
        <div className="border-t border-gray-200 px-4 py-3 flex flex-wrap justify-end gap-2">
          <button type="button" className="btn-secondary" onClick={onClose} disabled={saving}>
            Annuler
          </button>
          <button
            type="button"
            className="btn-primary"
            disabled={saving || lignesAcceptees.length === 0}
            onClick={() => void handleSave()}
          >
            {saving ? "Enregistrement…" : "Enregistrer"}
          </button>
        </div>
      </div>
    </div>
  )
}
