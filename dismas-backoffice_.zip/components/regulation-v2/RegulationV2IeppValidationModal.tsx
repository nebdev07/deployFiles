"use client"

import { useEffect, useMemo, useState } from "react"
import { regulationV2Service, type RegulationV2SuiviLigneRow } from "@/lib/services/regulation-v2.service"
import { formatRegulationReferenceForDisplay } from "@/lib/regulation-display"
import { toast } from "sonner"
import { getApiErrorMessage } from "@/lib/utils/api-error-message"

type Props = {
  open: boolean
  onClose: () => void
  regulationId: number
  referenceLabel?: string
  /** Lignes EN_ATTENTE de cette demande (phase validation IEPP). */
  lignesEnAttente: RegulationV2SuiviLigneRow[]
  onSaved: () => void | Promise<void>
  /** Si false : consultation seule (ex. DRENA). */
  allowActions?: boolean
}

export function RegulationV2IeppValidationModal({
  open,
  onClose,
  regulationId,
  referenceLabel,
  lignesEnAttente,
  onSaved,
  allowActions = true,
}: Props) {
  const [draft, setDraft] = useState<Record<number, number>>({})
  const [saving, setSaving] = useState(false)

  useEffect(() => {
    if (!open) return
    const next: Record<number, number> = {}
    for (const row of lignesEnAttente) {
      next[row.ligneId] = row.quantite
    }
    setDraft(next)
  }, [open, lignesEnAttente])

  const sortedLignes = useMemo(() => {
    return [...lignesEnAttente].sort((a, b) => (a.ligneId ?? 0) - (b.ligneId ?? 0))
  }, [lignesEnAttente])

  const handleSaveQuantites = async () => {
    const ajustements: Array<{ ligneId: number; quantite: number }> = []
    for (const row of lignesEnAttente) {
      const raw = draft[row.ligneId]
      const q = Number.isFinite(raw) ? Math.max(0, Math.floor(raw)) : 0
      ajustements.push({ ligneId: row.ligneId, quantite: q })
    }
    setSaving(true)
    try {
      const r = await regulationV2Service.ajusterQuantitesPendantValidationIepp({ regulationId, ajustements })
      if (r.hasError) {
        toast.error(r.status?.message ?? "Ajustement refusé")
        return
      }
      toast.success("Quantités enregistrées")
      await onSaved()
      onClose()
    } catch (e: unknown) {
      toast.error(getApiErrorMessage(e, "Erreur lors de l’enregistrement"))
    } finally {
      setSaving(false)
    }
  }

  const handleValider = async () => {
    if (!confirm("Transmettre cette demande aux EPP sources pour accord ?")) return
    setSaving(true)
    try {
      const r = await regulationV2Service.validerDemandeV2ParIepp(regulationId)
      if (r.hasError) {
        toast.error(r.status?.message ?? "Validation refusée")
        return
      }
      toast.success("Demande transmise aux EPP")
      await onSaved()
      onClose()
    } catch (e: unknown) {
      toast.error(getApiErrorMessage(e, "Erreur"))
    } finally {
      setSaving(false)
    }
  }

  const handleRefuser = async () => {
    if (!confirm("Refuser définitivement cette demande (elle ne sera pas envoyée aux EPP) ?")) return
    setSaving(true)
    try {
      const r = await regulationV2Service.refuserDemandeV2ValidationIepp(regulationId)
      if (r.hasError) {
        toast.error(r.status?.message ?? "Refus impossible")
        return
      }
      toast.success("Demande refusée")
      await onSaved()
      onClose()
    } catch (e: unknown) {
      toast.error(getApiErrorMessage(e, "Erreur"))
    } finally {
      setSaving(false)
    }
  }

  if (!open) return null

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40" role="dialog" aria-modal="true">
      <div className="bg-white rounded-xl shadow-xl max-w-2xl w-full max-h-[90vh] overflow-hidden flex flex-col">
        <div className="px-4 py-3 border-b border-gray-100 flex justify-between items-start gap-2">
          <div>
            <h2 className="text-lg font-semibold text-gray-900">Validation IEPP (DRENA)</h2>
            <p className="text-sm text-gray-600 mt-0.5">
              {formatRegulationReferenceForDisplay(referenceLabel) || `Demande #${regulationId}`} — ajustez les quantités si besoin, puis transmettez
              aux EPP sources ou refusez.
            </p>
          </div>
          <button type="button" className="text-gray-500 hover:text-gray-800 text-xl leading-none px-1" onClick={onClose}>
            ×
          </button>
        </div>
        <div className="p-4 overflow-y-auto flex-1 space-y-3">
          {sortedLignes.length === 0 ? (
            <p className="text-sm text-gray-500">Aucune ligne en attente pour cette demande.</p>
          ) : (
            <div className="rounded-lg border border-gray-200 overflow-hidden">
              <table className="min-w-full text-sm">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-2 py-2 text-left">Source → Dest</th>
                    <th className="px-2 py-2 text-left">M / N</th>
                    <th className="px-2 py-2 text-right">Qté</th>
                  </tr>
                </thead>
                <tbody>
                  {sortedLignes.map((row) => {
                    const src = [row.structureSourceLibelle, row.structureSourceCode].filter(Boolean).join(" ")
                    const dst = [row.structureDestLibelle, row.structureDestCode].filter(Boolean).join(" ")
                    const mn = `${row.matiereLibelle ?? "—"} — ${row.niveauLibelle ?? "—"}`
                    return (
                      <tr key={row.ligneId} className="border-t border-gray-100">
                        <td className="px-2 py-2 text-xs">
                          {src || "EPP source"} → {dst || "EPP dest."}
                        </td>
                        <td className="px-2 py-2 text-xs text-gray-600">{mn}</td>
                        <td className="px-2 py-2 text-right">
                          {allowActions ? (
                            <input
                              type="number"
                              min={0}
                              className="input-field w-20 text-right text-sm py-1"
                              value={draft[row.ligneId] ?? ""}
                              onChange={(e) => {
                                const n = e.target.value === "" ? 0 : Number(e.target.value)
                                const q = Number.isFinite(n) ? Math.max(0, Math.floor(n)) : 0
                                setDraft((prev) => ({ ...prev, [row.ligneId]: q }))
                              }}
                            />
                          ) : (
                            <span className="text-gray-800">{row.quantite}</span>
                          )}
                        </td>
                      </tr>
                    )
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
        <div className="px-4 py-3 border-t border-gray-100 flex flex-wrap gap-2 justify-end bg-gray-50">
          <button type="button" className="btn-secondary text-sm" disabled={saving} onClick={onClose}>
            Fermer
          </button>
          {allowActions ? (
            <>
              {sortedLignes.length > 0 ? (
                <button
                  type="button"
                  className="btn-secondary text-sm"
                  disabled={saving}
                  onClick={() => void handleSaveQuantites()}
                >
                  Enregistrer les quantités
                </button>
              ) : null}
              <button
                type="button"
                className="btn-secondary text-sm text-red-800 border-red-200"
                disabled={saving}
                onClick={() => void handleRefuser()}
              >
                Refuser la demande
              </button>
              <button
                type="button"
                className="btn-primary text-sm"
                disabled={saving || sortedLignes.length === 0}
                onClick={() => void handleValider()}
              >
                Transmettre aux EPP
              </button>
            </>
          ) : null}
        </div>
      </div>
    </div>
  )
}
