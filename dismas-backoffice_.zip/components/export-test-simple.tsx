"use client"

import { useState } from "react"
import { exportToPDF, exportToExcel, formatNumber } from '../lib/export-utils'

// Données de test simples
const simpleTestData = {
  title: 'TEST SIMPLE',
  subtitle: 'Test des corrections',
  date: new Date().toISOString().split('T')[0],
  generatedBy: 'Test User',
  status: 'TEST',
  statistics: [
    { label: 'Test 1', value: formatNumber(1000) },
    { label: 'Test 2', value: '50%' }
  ],
  tables: [
    {
      title: 'Tableau Test',
      headers: ['Colonne 1', 'Colonne 2'],
      data: [
        ['A1', 'B1'],
        ['A2', 'B2'],
        ['A3', 'B3']
      ]
    }
  ]
}

export default function ExportTestSimple() {
  const [isExporting, setIsExporting] = useState(false)
  const [message, setMessage] = useState<string | null>(null)

  const handleTest = async (type: 'pdf' | 'excel') => {
    setIsExporting(true)
    setMessage(null)

    try {
      const fileName = `test_simple_${new Date().toISOString().split('T')[0]}.${type}`
      
      if (type === 'pdf') {
        exportToPDF(simpleTestData, fileName)
      } else {
        exportToExcel(simpleTestData, fileName)
      }

      setMessage(`✅ Test ${type.toUpperCase()} réussi !`)
    } catch (error) {
      console.error('Erreur test:', error)
      setMessage(`❌ Erreur test ${type.toUpperCase()}: ${error instanceof Error ? error.message : 'Erreur inconnue'}`)
    } finally {
      setIsExporting(false)
    }
  }

  return (
    <div className="p-4 bg-white rounded-lg shadow">
      <h3 className="text-lg font-bold mb-4">🧪 Test Simple Export</h3>
      
      <div className="space-y-4">
        <div className="flex space-x-4">
          <button
            onClick={() => handleTest('pdf')}
            disabled={isExporting}
            className="bg-red-600 hover:bg-red-700 disabled:bg-red-300 text-white px-4 py-2 rounded"
          >
            {isExporting ? 'Test...' : 'Test PDF'}
          </button>
          
          <button
            onClick={() => handleTest('excel')}
            disabled={isExporting}
            className="bg-green-600 hover:bg-green-700 disabled:bg-green-300 text-white px-4 py-2 rounded"
          >
            {isExporting ? 'Test...' : 'Test Excel'}
          </button>
        </div>

        {message && (
          <div className={`p-3 rounded ${
            message.includes('✅') ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
          }`}>
            {message}
          </div>
        )}
      </div>
    </div>
  )
} 