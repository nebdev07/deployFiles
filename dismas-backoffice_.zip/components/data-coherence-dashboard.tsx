"use client"

import { useEffect, useMemo, useState } from "react"
import { coherenceService, type CoherenceDashboard } from "@/lib/services/coherence.service"
import { CheckCircleIcon, ExclamationTriangleIcon } from "@heroicons/react/24/outline"

interface DataCoherenceDashboardProps {
  roleCode: string
  anneeScolaireId: number | null
  structureId?: number
  drenaId?: number
  ieppId?: number
}

export default function DataCoherenceDashboard(props: DataCoherenceDashboardProps) {
  const [activeTab, setActiveTab] = useState<"overview" | "besoins" | "stocks" | "distribution" | "recuperation">("overview")
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [data, setData] = useState<CoherenceDashboard | null>(null)

  const canLoad = useMemo(() => {
    return !!props.roleCode && !!props.anneeScolaireId
  }, [props.roleCode, props.anneeScolaireId])

  useEffect(() => {
    const load = async () => {
      if (!canLoad || !props.anneeScolaireId) return
      setLoading(true)
      setError(null)
      try {
        const res = await coherenceService.getDashboard({
          anneeScolaireId: props.anneeScolaireId,
          roleCode: props.roleCode,
          structureId: props.structureId,
          drenaId: props.drenaId,
          ieppId: props.ieppId,
          includeDetails: true,
        })
        if (!res.hasError && Array.isArray(res.items) && res.items.length > 0) {
          setData(res.items[0])
        } else {
          setError(res.status?.message || "Impossible de charger le dashboard de cohérence")
          setData(null)
        }
      } catch (e: any) {
        setError(e?.message || "Erreur de chargement")
        setData(null)
      } finally {
        setLoading(false)
      }
    }
    load()
  }, [canLoad, props.roleCode, props.anneeScolaireId, props.structureId, props.drenaId, props.ieppId])

  if (!canLoad) return <p className="text-sm text-gray-500">Sélectionnez une année scolaire.</p>
  if (loading) return <p className="text-sm text-gray-500">Chargement de la cohérence des données...</p>
  if (error) return <p className="text-sm text-red-600">{error}</p>
  if (!data) return <p className="text-sm text-gray-500">Aucune donnée de cohérence disponible.</p>

  const coherent = (data.kpis?.anomaliesCount ?? 0) === 0

  return (
    <div className="bg-white rounded-lg shadow">
      <div className="px-6 py-4 border-b border-gray-200 flex items-center justify-between">
        <div>
          <h3 className="text-lg font-medium text-gray-900">
            Cohérence des Données - {data.scopeLibelle}
          </h3>
          <p className="text-xs text-gray-500">
            Rôle: {data.roleCode} | Périmètre: {data.scopeType}
          </p>
        </div>
        <div className="flex items-center space-x-2">
          {coherent ? (
            <div className="flex items-center text-green-600">
              <CheckCircleIcon className="h-5 w-5 mr-1" />
              <span className="text-sm font-medium">Cohérent</span>
            </div>
          ) : (
            <div className="flex items-center text-red-600">
              <ExclamationTriangleIcon className="h-5 w-5 mr-1" />
              <span className="text-sm font-medium">Incohérences détectées</span>
            </div>
          )}
        </div>
      </div>

      <div className="border-b border-gray-200 px-6">
        <nav className="-mb-px flex space-x-6 overflow-x-auto">
          {[
            { id: "overview", label: "Vue d'ensemble" },
            { id: "besoins", label: "Besoins" },
            { id: "stocks", label: "Stocks" },
            { id: "distribution", label: "Distribution" },
            { id: "recuperation", label: "Récupération" },
          ].map((tab) => (
            <button
              key={tab.id}
              type="button"
              onClick={() => setActiveTab(tab.id as any)}
              className={`py-3 text-sm font-medium border-b-2 whitespace-nowrap ${
                activeTab === tab.id ? "border-orange-500 text-orange-600" : "border-transparent text-gray-500 hover:text-gray-700"
              }`}
            >
              {tab.label}
            </button>
          ))}
        </nav>
      </div>

      <div className="p-6 space-y-6">
        {activeTab === "overview" && (
          <>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <KpiCard title="Total Élèves" value={data.kpis?.totalEleves ?? 0} />
              <KpiCard title="Manuels Requis" value={data.kpis?.totalManuelsRequis ?? 0} />
              <KpiCard title="Stock Disponible" value={data.kpis?.stockDisponibleTotal ?? 0} />
              <KpiCard title="Couverture (%)" value={data.kpis?.couvertureGlobale ?? 0} />
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <KpiCard title="Manuels Commandés" value={data.kpis?.totalManuelsCommandes ?? 0} />
              <KpiCard title="Manuels Distribués" value={data.kpis?.totalManuelsDistribues ?? 0} />
              <KpiCard title="Ruptures / Anomalies" value={(data.kpis?.stocksEnRuptureCount ?? 0) + (data.kpis?.anomaliesCount ?? 0)} />
            </div>
          </>
        )}

        {activeTab === "besoins" && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <KpiCard title="Manuels Requis" value={data.besoins?.partA ?? data.kpis?.totalManuelsRequis ?? 0} />
            <KpiCard title="Manuels Commandés" value={data.besoins?.partB ?? data.kpis?.totalManuelsCommandes ?? 0} />
            <KpiCard title="Écart Requis-Commandés" value={data.besoins?.ecart ?? 0} />
          </div>
        )}

        {activeTab === "stocks" && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <KpiCard title="Stock Disponible Total" value={data.stocks?.partA ?? data.kpis?.stockDisponibleTotal ?? 0} />
            <KpiCard title="Lignes en Rupture" value={data.stocks?.partB ?? data.kpis?.stocksEnRuptureCount ?? 0} />
            <KpiCard title="Anomalies Stock" value={data.stocks?.anomalies ?? data.anomalies?.filter((a) => a.code?.includes("STOCK") || a.code?.includes("RUPTURE")).length ?? 0} />
          </div>
        )}

        {activeTab === "distribution" && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <KpiCard title="Manuels Distribués" value={data.distribution?.partA ?? data.kpis?.totalManuelsDistribues ?? 0} />
            <KpiCard title="Couverture (%)" value={data.distribution?.partB ?? data.kpis?.couvertureGlobale ?? 0} />
            <KpiCard title="Écart Requis-Distribués" value={data.distribution?.ecart ?? 0} />
          </div>
        )}

        {activeTab === "recuperation" && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <KpiCard title="Récupérations année courante" value={data.retours?.partA ?? 0} />
            <KpiCard title="Récupérations année courante reportées" value={data.retours?.partB ?? 0} />
            <KpiCard title="Total récupérations comptabilisées" value={data.retours?.total ?? 0} />
          </div>
        )}

        {Array.isArray(data.scopes) && data.scopes.length > 0 && (
          <div>
            <h4 className="text-base font-semibold text-gray-900 mb-3">Sous-périmètres</h4>
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Type</th>
                    <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Structure</th>
                    <th className="px-4 py-2 text-right text-xs font-medium text-gray-500 uppercase">Élèves</th>
                    <th className="px-4 py-2 text-right text-xs font-medium text-gray-500 uppercase">Requis</th>
                    <th className="px-4 py-2 text-right text-xs font-medium text-gray-500 uppercase">Stock</th>
                    <th className="px-4 py-2 text-right text-xs font-medium text-gray-500 uppercase">Couverture</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {data.scopes.map((s) => (
                    <tr key={`${s.type}-${s.id}`}>
                      <td className="px-4 py-2 text-sm text-gray-700">{s.type}</td>
                      <td className="px-4 py-2 text-sm text-gray-900">{s.libelle} ({s.code})</td>
                      <td className="px-4 py-2 text-sm text-right">{s.kpis?.totalEleves ?? 0}</td>
                      <td className="px-4 py-2 text-sm text-right">{s.kpis?.totalManuelsRequis ?? 0}</td>
                      <td className="px-4 py-2 text-sm text-right">{s.kpis?.stockDisponibleTotal ?? 0}</td>
                      <td className="px-4 py-2 text-sm text-right">{s.kpis?.couvertureGlobale ?? 0}%</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        <div>
          <h4 className="text-base font-semibold text-gray-900 mb-3">Anomalies</h4>
          {(!data.anomalies || data.anomalies.length === 0) ? (
            <p className="text-sm text-green-700">Aucune anomalie détectée.</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-red-50">
                  <tr>
                    <th className="px-4 py-2 text-left text-xs font-medium text-red-700 uppercase">Code</th>
                    <th className="px-4 py-2 text-left text-xs font-medium text-red-700 uppercase">Sévérité</th>
                    <th className="px-4 py-2 text-left text-xs font-medium text-red-700 uppercase">Structure</th>
                    <th className="px-4 py-2 text-left text-xs font-medium text-red-700 uppercase">Matière</th>
                    <th className="px-4 py-2 text-left text-xs font-medium text-red-700 uppercase">Message</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {data.anomalies.map((a, idx) => (
                    <tr key={`${a.code}-${idx}`}>
                      <td className="px-4 py-2 text-sm">{a.code}</td>
                      <td className="px-4 py-2 text-sm">{a.severity}</td>
                      <td className="px-4 py-2 text-sm">{a.structureLibelle || a.structureCode || "-"}</td>
                      <td className="px-4 py-2 text-sm">{a.matiereLibelle || a.matiereCode || "-"}</td>
                      <td className="px-4 py-2 text-sm">{a.message}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

function KpiCard({ title, value }: { title: string; value: number }) {
  return (
    <div className="bg-gray-50 rounded-lg p-4">
      <p className="text-sm font-medium text-gray-700">{title}</p>
      <p className="text-2xl font-bold text-gray-900">{value}</p>
    </div>
  )
}