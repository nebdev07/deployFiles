/**
 * Composant widget pour afficher le stock disponible d'une EPP
 * Permet de consulter le stock en temps réel
 */

import { logger } from '@/lib/utils/logger'

import React, { useState, useEffect } from 'react';
import { distributionService } from '@/lib/services/distribution.service';
import { receptionService } from '@/lib/services/reception.service';
import { useStructures } from '@/hooks/use-structures';
import { useMatieres } from '@/hooks/use-matieres';
import toast from 'react-hot-toast';
import { 
  CubeIcon, 
  ExclamationTriangleIcon, 
  CheckCircleIcon,
  ArrowPathIcon 
} from '@heroicons/react/24/outline';

interface StockWidgetProps {
  eppId?: number;
  className?: string;
}

interface StockInfo {
  matiereId: number;
  matiereCode: string;
  matiereLibelle: string;
  stock: number;
  isLoading: boolean;
  error?: string;
}

export default function StockWidget({ eppId, className = '' }: StockWidgetProps) {
  const { epps, loadEpps } = useStructures();
  const { matieres, loading: matieresLoading } = useMatieres();
  
  const [selectedEppId, setSelectedEppId] = useState<number>(eppId || 0);
  const [selectedMatiereId, setSelectedMatiereId] = useState<number>(0);
  const [stockInfo, setStockInfo] = useState<StockInfo | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [showAllStocks, setShowAllStocks] = useState(false);
  const [allStocks, setAllStocks] = useState<StockInfo[]>([]);

  // Charger les EPP au montage
  useEffect(() => {
    loadEpps();
  }, []);

  // Charger le stock quand l'EPP ou la matière change
  useEffect(() => {
    if (selectedEppId && selectedMatiereId) {
      loadStock();
    }
  }, [selectedEppId, selectedMatiereId]);

  /**
   * Charge le stock pour une matière spécifique
   */
  const loadStock = async () => {
    if (!selectedEppId || !selectedMatiereId) return;

    setIsLoading(true);
    try {
      const response = await receptionService.getStock(selectedEppId, selectedMatiereId);
      
      if (response.success && response.data !== null) {
        const matiere = matieres.find(m => m.id === selectedMatiereId);
        setStockInfo({
          matiereId: selectedMatiereId,
          matiereCode: matiere?.code || '',
          matiereLibelle: matiere?.libelle || '',
          stock: response.data.stockDisponible || 0,
          isLoading: false
        });
      } else {
        setStockInfo({
          matiereId: selectedMatiereId,
          matiereCode: '',
          matiereLibelle: '',
          stock: 0,
          isLoading: false,
          error: response.message
        });
      }
    } catch (error: any) {
      logger.error('Erreur lors du chargement du stock:', error);
      setStockInfo({
        matiereId: selectedMatiereId,
        matiereCode: '',
        matiereLibelle: '',
        stock: 0,
        isLoading: false,
        error: error instanceof Error ? error.message : 'Erreur inconnue'
      });
    } finally {
      setIsLoading(false);
    }
  };

  /**
   * Charge le stock pour toutes les matières d'une EPP
   */
  const loadAllStocks = async () => {
    if (!selectedEppId || matieres.length === 0) return;

    setIsLoading(true);
    const stocks: StockInfo[] = [];

    try {
      for (const matiere of matieres.slice(0, 10)) { // Limiter à 10 matières pour les performances
        if (!matiere.id) continue
        try {
          const response = await receptionService.getStock(selectedEppId, matiere.id);
          
          stocks.push({
            matiereId: matiere.id,
            matiereCode: matiere.code || '',
            matiereLibelle: matiere.libelle || '',
            stock: response.success ? (response.data?.stockDisponible || 0) : 0,
            isLoading: false,
            error: response.success ? undefined : response.message
          });
        } catch (error) {
          stocks.push({
            matiereId: matiere.id,
            matiereCode: matiere.code || '',
            matiereLibelle: matiere.libelle || '',
            stock: 0,
            isLoading: false,
            error: 'Erreur de chargement'
          });
        }
      }

      setAllStocks(stocks);
      setShowAllStocks(true);
    } catch (error) {
      logger.error('Erreur lors du chargement des stocks:', error);
      toast.error('Erreur lors du chargement des stocks');
    } finally {
      setIsLoading(false);
    }
  };

  /**
   * Teste le système de stock
   */
  const testStockSystem = async () => {
    if (!selectedEppId) {
      toast.error('Veuillez sélectionner une EPP');
      return;
    }

    setIsLoading(true);
    try {
      const response = await distributionService.testStockSystem(selectedEppId);
      
      if (response.success) {
        toast.success('Tests de stock exécutés avec succès. Vérifiez la console pour les détails.');
        logger.log('Tests de stock:', response.data);
      } else {
        toast.error(`Erreur lors des tests: ${response.message}`);
      }
    } catch (error: any) {
      logger.error('Erreur lors des tests:', error);
      toast.error('Erreur lors des tests de stock');
    } finally {
      setIsLoading(false);
    }
  };

  const getStockStatusColor = (stock: number) => {
    if (stock === 0) return 'text-red-600';
    if (stock < 10) return 'text-yellow-600';
    return 'text-green-600';
  };

  const getStockStatusIcon = (stock: number) => {
    if (stock === 0) return <ExclamationTriangleIcon className="h-5 w-5 text-red-600" />;
    if (stock < 10) return <ExclamationTriangleIcon className="h-5 w-5 text-yellow-600" />;
    return <CheckCircleIcon className="h-5 w-5 text-green-600" />;
  };

  return (
    <div className={`bg-white rounded-lg shadow-sm border p-6 ${className}`}>
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-gray-900 flex items-center">
          <CubeIcon className="h-5 w-5 mr-2 text-blue-600" />
          Stock EPP
        </h3>
        <button
          onClick={() => setShowAllStocks(false)}
          className="text-sm text-gray-500 hover:text-gray-700"
        >
          {showAllStocks ? 'Vue détaillée' : 'Vue globale'}
        </button>
      </div>

      {/* Sélection EPP */}
      <div className="form-group mb-4">
        <label className="form-label">École EPP</label>
        <select
          value={selectedEppId}
          onChange={(e) => setSelectedEppId(parseInt(e.target.value))}
          className="input-field"
        >
          <option value={0}>Sélectionner une EPP</option>
          {epps.map((epp) => (
            <option key={epp.id} value={epp.id}>
              {epp.libelle} ({epp.code})
            </option>
          ))}
        </select>
      </div>

      {selectedEppId && (
        <>
          {!showAllStocks ? (
            <>
              {/* Sélection matière */}
              <div className="form-group mb-4">
                <label className="form-label">Matière</label>
                <select
                  value={selectedMatiereId}
                  onChange={(e) => setSelectedMatiereId(parseInt(e.target.value))}
                  className="input-field"
                >
                  <option value={0}>Sélectionner une matière</option>
                  {matieres.map((matiere) => (
                    <option key={matiere.id} value={matiere.id}>
                      {matiere.libelle} ({matiere.code})
                    </option>
                  ))}
                </select>
              </div>

              {/* Affichage du stock */}
              {selectedMatiereId && (
                <div className="space-y-4">
                  {stockInfo && (
                    <div className={`p-4 rounded-lg border ${stockInfo.error ? 'border-red-200 bg-red-50' : 'border-gray-200 bg-gray-50'}`}>
                      <div className="flex items-center justify-between">
                        <div>
                          <h4 className="font-medium text-gray-900">{stockInfo.matiereLibelle}</h4>
                          <p className="text-sm text-gray-500">{stockInfo.matiereCode}</p>
                        </div>
                        <div className="text-right">
                          <div className="flex items-center">
                            {getStockStatusIcon(stockInfo.stock)}
                            <span className={`ml-2 text-2xl font-bold ${getStockStatusColor(stockInfo.stock)}`}>
                              {isLoading ? (
                                <ArrowPathIcon className="h-6 w-6 animate-spin" />
                              ) : (
                                stockInfo.stock
                              )}
                            </span>
                          </div>
                          <p className="text-sm text-gray-500">unités disponibles</p>
                        </div>
                      </div>
                      
                      {stockInfo.error && (
                        <p className="text-sm text-red-600 mt-2">{stockInfo.error}</p>
                      )}
                    </div>
                  )}

                  {/* Actions */}
                  <div className="flex space-x-2">
                    <button
                      onClick={loadStock}
                      disabled={isLoading}
                      className="btn-secondary text-sm"
                    >
                      {isLoading ? (
                        <>
                          <ArrowPathIcon className="h-4 w-4 animate-spin mr-1" />
                          Chargement...
                        </>
                      ) : (
                        <>
                          <ArrowPathIcon className="h-4 w-4 mr-1" />
                          Actualiser
                        </>
                      )}
                    </button>
                    
                    <button
                      onClick={loadAllStocks}
                      disabled={isLoading}
                      className="btn-primary text-sm"
                    >
                      Voir tous les stocks
                    </button>
                    
                    <button
                      onClick={testStockSystem}
                      disabled={isLoading}
                      className="btn-outline text-sm"
                    >
                      Tester le système
                    </button>
                  </div>
                </div>
              )}
            </>
          ) : (
            <>
              {/* Vue globale des stocks */}
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h4 className="font-medium text-gray-900">Tous les stocks ({allStocks.length})</h4>
                  <button
                    onClick={() => setShowAllStocks(false)}
                    className="text-sm text-blue-600 hover:text-blue-800"
                  >
                    Vue détaillée
                  </button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 max-h-60 overflow-y-auto">
                  {allStocks.map((stock) => (
                    <div
                      key={stock.matiereId}
                      className={`p-3 rounded border ${
                        stock.error ? 'border-red-200 bg-red-50' : 'border-gray-200 bg-gray-50'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium text-gray-900 truncate">
                            {stock.matiereLibelle}
                          </p>
                          <p className="text-xs text-gray-500">{stock.matiereCode}</p>
                        </div>
                        <div className="flex items-center ml-2">
                          {getStockStatusIcon(stock.stock)}
                          <span className={`ml-1 text-lg font-bold ${getStockStatusColor(stock.stock)}`}>
                            {stock.stock}
                          </span>
                        </div>
                      </div>
                      
                      {stock.error && (
                        <p className="text-xs text-red-600 mt-1">{stock.error}</p>
                      )}
                    </div>
                  ))}
                </div>

                <button
                  onClick={loadAllStocks}
                  disabled={isLoading}
                  className="btn-secondary text-sm w-full"
                >
                  {isLoading ? (
                    <>
                      <ArrowPathIcon className="h-4 w-4 animate-spin mr-1" />
                      Actualisation...
                    </>
                  ) : (
                    <>
                      <ArrowPathIcon className="h-4 w-4 mr-1" />
                      Actualiser tous les stocks
                    </>
                  )}
                </button>
              </div>
            </>
          )}
        </>
      )}

      {!selectedEppId && (
        <div className="text-center py-8 text-gray-500">
          <CubeIcon className="h-12 w-12 mx-auto mb-2 text-gray-300" />
          <p>Sélectionnez une EPP pour consulter son stock</p>
        </div>
      )}
    </div>
  );
}
