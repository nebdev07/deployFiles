"use client"

import { useEffect, useState, useCallback } from "react"
import { usePathname, useSearchParams } from "next/navigation"

/**
 * Barre de progression en haut de l'écran lors des navigations internes (clic sur un lien).
 * Complète app/loading.tsx qui couvre le chargement RSC.
 * À utiliser dans un boundary Suspense (useSearchParams).
 */
export function NavigationProgress() {
  const pathname = usePathname()
  const searchParams = useSearchParams()
  const [active, setActive] = useState(false)

  const locationKey = `${pathname}?${searchParams?.toString() ?? ""}`

  useEffect(() => {
    setActive(false)
  }, [locationKey])

  const onPointerDownCapture = useCallback(() => {
    const handler = (e: PointerEvent) => {
      if (e.button !== 0) return
      const target = e.target as HTMLElement | null
      const anchor = target?.closest?.("a")
      if (!anchor || !(anchor instanceof HTMLAnchorElement)) return
      if (anchor.target && anchor.target !== "" && anchor.target !== "_self") return
      if (anchor.hasAttribute("download")) return
      if (e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return

      let url: URL
      try {
        url = new URL(anchor.href, window.location.origin)
      } catch {
        return
      }
      if (url.origin !== window.location.origin) return

      const next = `${url.pathname}${url.search}`
      const current = `${window.location.pathname}${window.location.search}`
      if (next === current) return

      setActive(true)
    }
    return handler
  }, [])

  useEffect(() => {
    const handler = onPointerDownCapture()
    document.addEventListener("pointerdown", handler, true)
    return () => document.removeEventListener("pointerdown", handler, true)
  }, [onPointerDownCapture])

  if (!active) return null

  return (
    <div
      className="fixed top-0 left-0 right-0 z-[9998] h-1 overflow-hidden bg-orange-100/80 pointer-events-none"
      aria-hidden
    >
      <div className="h-full w-1/3 bg-orange-600 nav-progress-indeterminate" />
    </div>
  )
}
