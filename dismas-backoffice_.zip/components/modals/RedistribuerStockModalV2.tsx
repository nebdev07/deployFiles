"use client"

import { useState, useEffect } from "react"
import { XCircleIcon, TrashIcon, InformationCircleIcon } from "@heroicons/react/24/outline"
import { regulationService } from "@/lib/services/regulation.service"
import { structuresService } from "@/lib/services/structures.service"
import { matiereService } from "@/lib/services/matiere.service"
import { niveauScolaireService } from "@/lib/services/niveau-scolaire.service"
import { anneeScolaireService } from "@/lib/services/annee-scolaire.service"
import { useAuth } from "@/app/providers"
import { getApiBaseUrl } from "@/lib/config/api"
import { toast } from "sonner"

interface RedistribuerStockModalV2Props {
  isOpen: boolean
  eppId?: number // EPP déficitaire à qui donner du stock
  /** IEPP (structure admin) pour DRENA/DAF ; défaut = structure utilisateur */
  ieppStructureId?: number
  onClose: () => void
  onSuccess: () => void
}

interface StockItem {
  id: string // matiereId_niveauId
  matiereId: number
  matiereLibelle: string
  niveauId: number
  niveauLibelle: string
  stockIEPP: number // Stock disponible de l'IEPP
  stockRecupere?: number // Stock récupéré lors des régulations (optionnel)
  quantiteARedistribuer: number
  taux?: number // Taux appliqué si redistribution globale
  deficitEpp?: number // ✅ NOUVEAU : Déficit de l'EPP (quantite_prevue - quantite_recue)
  stockInsuffisant?: boolean // true si (stock IEPP + stock récupéré) < déficit EPP
}

/** Quantité mobilisable pour la ligne : stock courant affiché + stock issu des récupérations (même logique métier que la capacité réelle). */
function disponiblePourRedistribution(item: Pick<StockItem, "stockIEPP" | "stockRecupere">): number {
  return Math.max(0, (item.stockIEPP ?? 0) + (item.stockRecupere ?? 0))
}

/** Identifiants numériques depuis l’API (parfois typés différemment selon la sérialisation). */
function stockNumericId(value: unknown): number | undefined {
  if (value === null || value === undefined) return undefined
  const n = typeof value === "number" ? value : Number(value)
  return Number.isFinite(n) && n > 0 ? Math.trunc(n) : undefined
}

function stockQuantite(value: StockDisponibleDataLike): number {
  const raw =
    value.quantiteDisponible ??
    (value as { quantite_disponible?: unknown }).quantite_disponible
  if (raw === null || raw === undefined) return 0
  const n = typeof raw === "number" ? raw : Number(raw)
  return Number.isFinite(n) ? Math.max(0, n) : 0
}

/** Champs utiles pour l’agrégation IEPP (évite d’ignorer les lignes sans niveau côté backend). */
type StockDisponibleDataLike = {
  matiereId?: unknown
  niveauId?: unknown
  quantiteDisponible?: unknown
  quantite_disponible?: unknown
}

export default function RedistribuerStockModalV2({
  isOpen,
  eppId,
  ieppStructureId,
  onClose,
  onSuccess,
}: RedistribuerStockModalV2Props) {
  const { user } = useAuth()
  const ieppContextId: number | undefined = ieppStructureId ?? user?.structure?.id
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isLoadingStocks, setIsLoadingStocks] = useState(false)
  const [stockRecupereMap, setStockRecupereMap] = useState<Map<string, number>>(new Map()) // Clé: "matiereId_niveauId"
  
  // Mode de redistribution : "global" (taux) ou "manuel" (quantités spécifiques)
  const [redistributionMode, setRedistributionMode] = useState<"global" | "manuel">("manuel")
  const [tauxGlobal, setTauxGlobal] = useState<number>(100) // Taux en pourcentage (100% = tout le stock)
  
  const [formData, setFormData] = useState({
    eppId: eppId || 0,
    anneeScolaireId: 0,
    commentaire: "",
  })
  
  const [stockItems, setStockItems] = useState<StockItem[]>([])
  const [eppList, setEppList] = useState<any[]>([])
  const [matieres, setMatieres] = useState<any[]>([])
  const [niveaux, setNiveaux] = useState<any[]>([])
  const [anneesScolaires, setAnneesScolaires] = useState<any[]>([])

  useEffect(() => {
    if (isOpen) {
      loadData()
    }
  }, [isOpen, user, ieppStructureId])

  useEffect(() => {
    // Quand l'année scolaire change, réinitialiser les stocks et le stock récupéré
    // et recharger les EPP déficitaires pour cette année
    if (formData.anneeScolaireId > 0 && ieppContextId) {
      // Réinitialiser les stocks chargés pour forcer un nouveau chargement
      setStockItems([])
      setStockRecupereMap(new Map())
      // Recharger les EPP déficitaires pour cette année
      loadEppDeficitaires()
    }
  }, [formData.anneeScolaireId, ieppContextId])

  const loadEppDeficitaires = async () => {
    if (!ieppContextId || formData.anneeScolaireId <= 0) return

    try {
      console.log("📊 Chargement des EPP déficitaires pour IEPP:", ieppContextId, "Année:", formData.anneeScolaireId)
      const response = await regulationService.getEppDeficitaires(
        ieppContextId,
        formData.anneeScolaireId
      )

      if (response.items && Array.isArray(response.items)) {
        // Transformer les EPP déficitaires en format compatible avec le select
        const eppListFormatted = response.items.map((epp: any) => ({
          id: epp.eppId,
          code: epp.eppCode,
          libelle: epp.eppLibelle,
          nombreCombinaisons: epp.nombreCombinaisons || 0,
          combinaisonsDeficitaires: epp.combinaisonsDeficitaires || [],
        }))
        
        setEppList(eppListFormatted)
        console.log(`✅ ${eppListFormatted.length} EPP déficitaire(s) chargé(s)`)
        
        if (eppListFormatted.length === 0) {
          toast.info("Aucun EPP déficitaire trouvé pour cette année scolaire")
        }
      } else {
        setEppList([])
        console.warn("⚠️ Aucun EPP déficitaire trouvé dans la réponse")
      }
    } catch (error) {
      console.error("❌ Erreur lors du chargement des EPP déficitaires:", error)
      toast.error("Erreur lors du chargement des EPP déficitaires")
      // En cas d'erreur, charger tous les EPP comme fallback
      try {
        const eppResponse = await structuresService.getEppsByIepp(ieppContextId)
        if (eppResponse.items) {
          setEppList(eppResponse.items)
        }
      } catch (fallbackError) {
        console.error("❌ Erreur lors du chargement de fallback des EPP:", fallbackError)
      }
    }
  }

  // 🔄 Chargement automatique des combinaisons déficitaires dès qu'un EPP et une année sont sélectionnés
  useEffect(() => {
    if (isOpen && formData.eppId > 0 && formData.anneeScolaireId > 0 && ieppContextId) {
      // Ne relance pas si un chargement est déjà en cours
      if (!isLoadingStocks) {
        loadCombinaisonsDeficitaires()
      }
    }
  }, [isOpen, formData.eppId, formData.anneeScolaireId, ieppContextId])

  const loadData = async () => {
    if (!ieppContextId) return

    try {
      // ✅ NOUVEAU : Charger uniquement les EPP déficitaires si une année scolaire est sélectionnée
      // Sinon, charger tous les EPP (pour l'affichage initial)
      if (formData.anneeScolaireId > 0) {
        await loadEppDeficitaires()
      } else {
        // Charger tous les EPP de l'IEPP (pour l'affichage initial)
        const eppResponse = await structuresService.getEppsByIepp(ieppContextId)
        if (eppResponse.items) {
          setEppList(eppResponse.items)
          if (eppId && !formData.eppId) {
            setFormData((prev) => ({ ...prev, eppId }))
          }
        }
      }

      // Charger les matières
      // ✅ Utiliser le service matiereService.getMatieres (getByCriteria n'existe pas sur ce service)
      const matieresResponse = await matiereService.getMatieres({})
      if (matieresResponse.items) {
        setMatieres(matieresResponse.items)
      }

      // Charger les niveaux
      // ✅ Utiliser le service niveauScolaireService.getNiveauxScolaires (getByCriteria n'existe pas sur ce service)
      const niveauxResponse = await niveauScolaireService.getNiveauxScolaires({})
      if (niveauxResponse.items) {
        setNiveaux(niveauxResponse.items)
      }

      // Charger les années scolaires
      const anneesResponse = await anneeScolaireService.getByCriteria({}, 0, 100)
      console.log("📅 Réponse années scolaires:", anneesResponse)
      if (anneesResponse.items && anneesResponse.items.length > 0) {
        setAnneesScolaires(anneesResponse.items)
        const itemsArray = Array.isArray(anneesResponse.items) ? anneesResponse.items : (anneesResponse.items ? [anneesResponse.items] : [])
        const anneeCourante = itemsArray.find((a: any) => a.estCourante) || itemsArray[0]
        if (anneeCourante && (anneeCourante as any).id) {
          console.log("📅 Année courante sélectionnée:", anneeCourante)
          setFormData((prev) => ({ ...prev, anneeScolaireId: (anneeCourante as any).id || 0 }))
        }
      } else {
        console.warn("⚠️ Aucune année scolaire trouvée")
        toast.warning("Aucune année scolaire trouvée")
      }
    } catch (error) {
      console.error("Erreur lors du chargement des données:", error)
      toast.error("Erreur lors du chargement des données")
    }
  }

  /**
   * ✅ NOUVEAU : Charge automatiquement les combinaisons déficitaires de l'EPP sélectionné
   * Récupère les combinaisons matière/niveau où l'EPP a un déficit et pré-remplit le tableau
   */
  const loadCombinaisonsDeficitaires = async () => {
    if (!ieppContextId || formData.anneeScolaireId <= 0 || formData.eppId <= 0) return

    setIsLoadingStocks(true)
    try {
      // 1. Récupérer les EPP déficitaires pour trouver les combinaisons de l'EPP sélectionné
      const eppDeficitairesResponse = await regulationService.getEppDeficitaires(
        ieppContextId,
        formData.anneeScolaireId
      )

      // 2. Trouver l'EPP sélectionné dans la liste des déficitaires
      const eppSelectionne = eppDeficitairesResponse.items?.find(
        (epp: any) => epp.eppId === formData.eppId
      )

      if (!eppSelectionne || !eppSelectionne.combinaisonsDeficitaires || eppSelectionne.combinaisonsDeficitaires.length === 0) {
        toast.info("Cet EPP n'a pas de combinaisons déficitaires pour cette année")
        setStockItems([])
        setIsLoadingStocks(false)
        return
      }

      // 3. Récupérer les stocks disponibles de l'IEPP
      const { mouvementService } = await import("@/lib/services/mouvement.service")
      const stocksIEPPResponse = await mouvementService.getStocksByStructureAndAnnee(
        ieppContextId,
        formData.anneeScolaireId
      )

      // 4. Maps IEPP : par combinaison matière/niveau, et repli par matière seule (stock général sans niveau en base)
      const stockIEPPParCombinaison = new Map<string, number>()
      const stockIEPPParMatiereSansNiveau = new Map<number, number>()
      if (stocksIEPPResponse.data && Array.isArray(stocksIEPPResponse.data)) {
        for (const raw of stocksIEPPResponse.data) {
          const stock = raw as StockDisponibleDataLike
          const matiereId = stockNumericId(
            stock.matiereId ?? (stock as { matiere_id?: unknown }).matiere_id
          )
          if (matiereId === undefined) continue
          const niveauId = stockNumericId(
            stock.niveauId ?? (stock as { niveau_id?: unknown }).niveau_id
          )
          const qty = stockQuantite(stock)
          if (niveauId !== undefined) {
            const k = `${matiereId}_${niveauId}`
            stockIEPPParCombinaison.set(k, (stockIEPPParCombinaison.get(k) ?? 0) + qty)
          } else {
            stockIEPPParMatiereSansNiveau.set(
              matiereId,
              (stockIEPPParMatiereSansNiveau.get(matiereId) ?? 0) + qty
            )
          }
        }
      }

      // 5. Construire les items avec les combinaisons déficitaires
      const items: StockItem[] = []
      
      for (const combinaison of eppSelectionne.combinaisonsDeficitaires) {
        const mid = stockNumericId(combinaison.matiereId) ?? Math.trunc(Number(combinaison.matiereId))
        const nid = stockNumericId(combinaison.niveauId) ?? Math.trunc(Number(combinaison.niveauId))
        const key = `${mid}_${nid}`
        const stockIEPP =
          stockIEPPParCombinaison.get(key) ??
          (Number.isFinite(mid) && mid > 0 ? stockIEPPParMatiereSansNiveau.get(mid) ?? 0 : 0)
        const deficit = combinaison.deficit || 0
        // Stock récupéré chargé ensuite ; ici capacité = IEPP seul jusqu’à fusion
        const disponible = stockIEPP
        let quantiteARedistribuer = 0
        if (redistributionMode === "global") {
          quantiteARedistribuer = Math.min(deficit, Math.round(disponible * (tauxGlobal / 100)))
        } else {
          quantiteARedistribuer = Math.min(deficit, disponible)
        }

        const stockInsuffisant = disponible < deficit

        items.push({
          id: key,
          matiereId: combinaison.matiereId,
          matiereLibelle: combinaison.matiereLibelle || `Matière ${combinaison.matiereId}`,
          niveauId: combinaison.niveauId,
          niveauLibelle: combinaison.niveauLibelle || `Niveau ${combinaison.niveauId}`,
          stockIEPP: stockIEPP,
          stockRecupere: 0, // Sera mis à jour après le chargement du stock récupéré
          quantiteARedistribuer: quantiteARedistribuer,
          taux: redistributionMode === "global" ? tauxGlobal : undefined,
          deficitEpp: deficit, // ✅ NOUVEAU : Déficit de l'EPP
          stockInsuffisant: stockInsuffisant, // ✅ NOUVEAU : Alerte si stock insuffisant
        })
      }

      setStockItems(items)

      // 6. Charger le stock récupéré pour ces items
      await loadStockRecupereForItems(items)

      // 7. Afficher un message avec le nombre de combinaisons et les alertes
      const nbStockInsuffisant = items.filter(item => item.stockInsuffisant).length
      if (nbStockInsuffisant > 0) {
        toast.warning(
          `${items.length} combinaison(s) chargée(s). ${nbStockInsuffisant} ligne(s) où le stock mobilisable (IEPP + récupéré) ne couvre pas tout le déficit — ajustez après chargement du stock récupéré.`,
          { duration: 6000 }
        )
      } else {
        toast.success(`${items.length} combinaison(s) déficitaire(s) chargée(s) automatiquement`)
      }
    } catch (error) {
      console.error("Erreur lors du chargement des combinaisons déficitaires:", error)
      toast.error("Erreur lors du chargement des combinaisons déficitaires")
    } finally {
      setIsLoadingStocks(false)
    }
  }

  const loadStockRecupereForItems = async (items: StockItem[]) => {
    if (!ieppContextId || formData.anneeScolaireId <= 0) {
      console.warn("⚠️ Impossible de charger le stock récupéré: structureId ou anneeScolaireId manquant", {
        structureId: ieppContextId,
        anneeScolaireId: formData.anneeScolaireId
      })
      return
    }

    try {
      console.log("📊 Chargement du stock récupéré pour IEPP:", ieppContextId, "Année:", formData.anneeScolaireId)
      const response = await regulationService.getStockRecupere(
        ieppContextId,
        formData.anneeScolaireId
      )

      console.log("📊 Réponse stock récupéré:", response)

      if (response.items && Array.isArray(response.items)) {
        const map = new Map<string, number>()
        for (const item of response.items) {
          const key = `${item.matiereId}_${item.niveauId}`
          map.set(key, item.stockRecupere || 0)
          console.log(`  ✅ Stock récupéré: ${key} = ${item.stockRecupere}`)
        }
        setStockRecupereMap(map)
        
        // Mettre à jour les stockItems avec le stock récupéré + recalcul alertes / quantités (IEPP + récupéré)
        setStockItems(prevItems =>
          prevItems.map((item) => {
            const key = `${item.matiereId}_${item.niveauId}`
            const stockRecupere = map.get(key) || 0
            const disponible = disponiblePourRedistribution({ ...item, stockRecupere })
            const deficit = item.deficitEpp ?? 0
            const stockInsuffisant = disponible < deficit
            const maxQ = Math.min(disponible, deficit)
            let quantiteARedistribuer = item.quantiteARedistribuer
            if (redistributionMode === "global") {
              quantiteARedistribuer = Math.min(deficit, Math.round(disponible * (tauxGlobal / 100)))
            } else {
              quantiteARedistribuer = Math.min(item.quantiteARedistribuer, maxQ)
            }
            return {
              ...item,
              stockRecupere,
              stockInsuffisant,
              quantiteARedistribuer,
            }
          })
        )
        console.log("✅ Stock récupéré mis à jour dans les items")
      } else {
        console.warn("⚠️ Aucun stock récupéré trouvé dans la réponse")
      }
    } catch (error) {
      console.error("❌ Erreur lors du chargement du stock récupéré:", error)
      toast.error("Erreur lors du chargement du stock récupéré")
    }
  }

  const handleRemoveItem = (id: string) => {
    setStockItems(stockItems.filter(item => item.id !== id))
  }

  const handleMatiereNiveauChange = async (id: string, matiereId: number, niveauId: number) => {
    if (!ieppContextId || matiereId <= 0 || niveauId <= 0 || formData.anneeScolaireId <= 0) return

    // Mettre à jour l'item
    const updatedItems = stockItems.map(item => {
      if (item.id === id) {
        const matiere = matieres.find(m => m.id === matiereId)
        const niveau = niveaux.find(n => n.id === niveauId)
        
        return {
          ...item,
          matiereId,
          matiereLibelle: matiere?.libelle || "",
          niveauId,
          niveauLibelle: niveau?.libelle || "",
        }
      }
      return item
    })
    setStockItems(updatedItems)

    // Charger le stock de l'IEPP pour cette combinaison
    try {
      // Utiliser directement l'endpoint getStock
      const response = await fetch(`${getApiBaseUrl()}/distributionEleve/getStock`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('auth_token')}`,
          'Session-Key': localStorage.getItem('auth_token') || '',
        },
        body: JSON.stringify({
          eppId: ieppContextId, // Utiliser l'IEPP comme structure
          matiereId: matiereId,
          niveauId: niveauId,
        }),
      })

      const data = await response.json()
      const stockDisponible = data.item || 0
      const key = `${matiereId}_${niveauId}`
      const stockRecupere = stockRecupereMap.get(key) || 0
      const disponible = disponiblePourRedistribution({
        stockIEPP: stockDisponible,
        stockRecupere,
      })

      const finalItems = updatedItems.map((item) => {
        if (item.id === id) {
          const deficit = item.deficitEpp ?? 0
          const stockInsuffisant = disponible < deficit
          let quantiteARedistribuer = item.quantiteARedistribuer
          if (redistributionMode === "global") {
            quantiteARedistribuer = Math.min(deficit, Math.round(disponible * (tauxGlobal / 100)))
          } else {
            quantiteARedistribuer = Math.min(item.quantiteARedistribuer, Math.min(disponible, deficit))
          }
          return {
            ...item,
            stockIEPP: stockDisponible,
            stockRecupere,
            stockInsuffisant,
            quantiteARedistribuer,
            taux: redistributionMode === "global" ? tauxGlobal : undefined,
          }
        }
        return item
      })
      setStockItems(finalItems)
    } catch (error) {
      console.error("Erreur lors du chargement du stock:", error)
      toast.error("Erreur lors du chargement du stock pour cette combinaison")
    }
  }

  const handleTauxGlobalChange = (taux: number) => {
    setTauxGlobal(taux)
    const updatedItems = stockItems.map((item) => {
      const disponible = disponiblePourRedistribution(item)
      if (disponible > 0) {
        const maxAllowed = Math.min(disponible, item.deficitEpp ?? disponible)
        const quantiteCalculee = Math.min(maxAllowed, Math.round(disponible * (taux / 100)))
        return {
          ...item,
          quantiteARedistribuer: quantiteCalculee,
          taux: taux,
        }
      }
      return item
    })
    setStockItems(updatedItems)
  }

  const handleQuantiteChange = (id: string, quantite: number) => {
    const updatedItems = stockItems.map((item) => {
      if (item.id === id) {
        const disponible = disponiblePourRedistribution(item)
        const maxAllowed = Math.min(disponible, item.deficitEpp ?? disponible)
        const safeQuantite = Math.max(0, Math.min(maxAllowed, quantite))
        return {
          ...item,
          quantiteARedistribuer: safeQuantite,
          taux: disponible > 0 ? Math.round((safeQuantite / disponible) * 100) : 0,
        }
      }
      return item
    })
    setStockItems(updatedItems)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!ieppContextId) {
      toast.error("Impossible de déterminer votre IEPP")
      return
    }

    if (formData.eppId <= 0) {
      toast.error("Veuillez sélectionner un EPP")
      return
    }

    if (formData.anneeScolaireId <= 0) {
      toast.error("Veuillez sélectionner une année scolaire")
      return
    }

    // Filtrer les items valides (avec matière, niveau et quantité > 0)
    const validItems = stockItems.filter(
      item => item.matiereId > 0 && item.niveauId > 0 && item.quantiteARedistribuer > 0
    )

    if (validItems.length === 0) {
      toast.error("Veuillez ajouter au moins une combinaison matière/niveau avec une quantité à redistribuer")
      return
    }
    for (const item of validItems) {
      const disponible = disponiblePourRedistribution(item)
      const maxAllowed = Math.min(disponible, item.deficitEpp ?? disponible)
      if (item.quantiteARedistribuer > maxAllowed) {
        toast.error(
          `Quantité invalide pour ${item.matiereLibelle} / ${item.niveauLibelle}. Maximum autorisé: ${maxAllowed}.`
        )
        return
      }
    }

    setIsSubmitting(true)

    try {
      // Redistribuer chaque combinaison matière/niveau
      if (!ieppContextId) {
        toast.error("Structure utilisateur non trouvée")
        return
      }
      const errors: string[] = []
      for (const item of validItems) {
        const result = await regulationService.redistribuerStock({
          ieppId: ieppContextId!,
          eppId: formData.eppId,
          matiereId: item.matiereId,
          niveauId: item.niveauId,
          quantite: item.quantiteARedistribuer,
          anneeScolaireId: formData.anneeScolaireId,
          commentaire: formData.commentaire || undefined,
        })
        if (result.hasError) {
          errors.push(
            `${item.matiereLibelle} / ${item.niveauLibelle}: ${result.status?.message || "Échec redistribution"}`
          )
        }
      }

      if (errors.length > 0) {
        toast.error(`${errors.length} redistribution(s) ont échoué sur ${validItems.length}`)
      } else {
        toast.success(`${validItems.length} redistribution(s) effectuée(s) avec succès`)
        onSuccess()
        onClose()
        // Réinitialiser
        setStockItems([])
        setFormData({
          eppId: eppId || 0,
          anneeScolaireId: formData.anneeScolaireId,
          commentaire: "",
        })
      }
    } catch (error: any) {
      console.error("Erreur lors de la redistribution:", error)
      toast.error(error?.message || "Erreur lors de la redistribution")
    } finally {
      setIsSubmitting(false)
    }
  }

  const totalQuantite = stockItems.reduce((sum, item) => sum + item.quantiteARedistribuer, 0)
  const validItemsCount = stockItems.filter(
    item => item.matiereId > 0 && item.niveauId > 0 && item.quantiteARedistribuer > 0
  ).length

  if (!isOpen) return null

  return (
    <div className="modal-overlay" onClick={onClose}>
      {/* ✅ Modal élargi et plus confortable pour le tableau */}
      <div
        className="modal-content !w-[96vw] !max-w-[96vw] !mx-0 max-h-[94vh] overflow-y-auto rounded-xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between mb-4 sticky top-0 bg-white pb-4 border-b">
          <div>
            <h3 className="text-xl font-semibold">Redistribuer du Stock</h3>
            <p className="text-sm text-gray-500 mt-1">
              Redistribuez le stock de l'IEPP vers un EPP déficitaire par matière et niveau
            </p>
          </div>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600">
            <XCircleIcon className="h-6 w-6" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Informations générales */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="form-group">
              <label className="form-label">
                EPP Destinataire <span className="text-red-500">*</span>
              </label>
              <select
                className="input-field"
                value={formData.eppId}
                onChange={(e) =>
                  setFormData((prev) => ({ ...prev, eppId: parseInt(e.target.value) }))
                }
                required
                disabled={!!eppId}
              >
                <option value="0">Sélectionner un EPP</option>
                {eppList.map((epp: any) => (
                  <option key={epp.id} value={epp.id}>
                    {epp.libelle} ({epp.code})
                    {epp.nombreCombinaisons !== undefined && ` - ${epp.nombreCombinaisons} combinaison(s) déficitaire(s)`}
                  </option>
                ))}
              </select>
            </div>

            <div className="form-group">
              <label className="form-label">
                Année Scolaire <span className="text-red-500">*</span>
              </label>
              <select
                className="input-field"
                value={formData.anneeScolaireId}
                onChange={(e) =>
                  setFormData((prev) => ({ ...prev, anneeScolaireId: parseInt(e.target.value) }))
                }
                required
              >
                <option value="0">Sélectionner une année scolaire</option>
                {anneesScolaires.map((annee) => (
                  <option key={annee.id} value={annee.id}>
                    {annee.libelle} {annee.estCourante ? "(Année courante)" : ""}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Mode de redistribution */}
          <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <InformationCircleIcon className="h-5 w-5 text-blue-600" />
                <label className="font-semibold text-gray-700">Mode de Redistribution</label>
              </div>
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setRedistributionMode("global")}
                  className={`px-4 py-2 rounded-md text-sm font-medium ${
                    redistributionMode === "global"
                      ? "bg-orange-600 text-white"
                      : "bg-gray-200 text-gray-700 hover:bg-gray-300"
                  }`}
                >
                  Global (Taux)
                </button>
                <button
                  type="button"
                  onClick={() => setRedistributionMode("manuel")}
                  className={`px-4 py-2 rounded-md text-sm font-medium ${
                    redistributionMode === "manuel"
                      ? "bg-orange-600 text-white"
                      : "bg-gray-200 text-gray-700 hover:bg-gray-300"
                  }`}
                >
                  Manuel (Quantités)
                </button>
              </div>
            </div>

            {redistributionMode === "global" && (
              <div className="mt-3">
                <label className="form-label">
                  Taux de Redistribution Global <span className="text-red-500">*</span>
                </label>
                <div className="flex items-center gap-4">
                  <input
                    type="range"
                    min="0"
                    max="100"
                    value={tauxGlobal}
                    onChange={(e) => handleTauxGlobalChange(parseInt(e.target.value))}
                    className="flex-1"
                  />
                  <div className="w-24">
                    <input
                      type="number"
                      min="0"
                      max="100"
                      value={tauxGlobal}
                      onChange={(e) => handleTauxGlobalChange(parseInt(e.target.value) || 0)}
                      className="input-field text-center"
                    />
                  </div>
                  <span className="text-gray-600 font-medium">%</span>
                </div>
                <p className="text-xs text-gray-500 mt-1">
                  Ce taux s’applique au total mobilisable par ligne (stock IEPP + stock récupéré).
                </p>
              </div>
            )}
          </div>

          {/* Chargement automatique métier */}
          {formData.anneeScolaireId > 0 && formData.eppId > 0 && (
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <p className="text-sm text-blue-800">
                Les combinaisons matière/niveau déficitaires sont chargées automatiquement pour l&apos;EPP sélectionné.
              </p>
              <p className="text-xs text-blue-900/90 mt-2">
                Pour chaque ligne, la quantité mobilisable est la somme du <strong>stock IEPP</strong> et du{" "}
                <strong>stock récupéré</strong> (les plafonds et l’alerte « Stock insuffisant » utilisent ce total, aligné
                sur le contrôle côté serveur sur le stock disponible).
              </p>
            </div>
          )}

          {/* Message si aucune année ou EPP sélectionné */}
          {(!formData.anneeScolaireId || !formData.eppId) && (
            <div className="bg-gray-50 border border-gray-200 rounded-lg p-4 text-center text-gray-500">
              <InformationCircleIcon className="h-8 w-8 mx-auto mb-2 text-gray-400" />
              <p className="text-sm">
                Veuillez sélectionner un EPP destinataire et une année scolaire pour continuer.
              </p>
            </div>
          )}

          {/* Message si aucun stock chargé */}
          {stockItems.length === 0 && formData.anneeScolaireId > 0 && formData.eppId > 0 && !isLoadingStocks && (
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-6 text-center">
              <InformationCircleIcon className="h-12 w-12 mx-auto mb-3 text-blue-400" />
              <h4 className="font-semibold text-gray-700 mb-2">Aucun stock chargé</h4>
              <p className="text-sm text-gray-600 mb-4">
                Aucun déficit redistribuable trouvé pour cet EPP et cette année.
              </p>
            </div>
          )}

          {/* Tableau des stocks */}
          {stockItems.length > 0 && (
            <div className="border rounded-lg overflow-hidden shadow-sm">
              <div className="bg-gradient-to-r from-gray-50 to-gray-100 px-4 py-3 border-b">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-semibold text-gray-700">
                      Stocks à Redistribuer ({validItemsCount} combinaison(s) valide(s))
                    </h4>
                    <p className="text-sm text-gray-500 mt-1">
                      Total à redistribuer: <span className="font-bold text-lg text-orange-600">{totalQuantite}</span> unités
                    </p>
                  </div>
                  {redistributionMode === "global" && (
                    <div className="text-right">
                      <p className="text-xs text-gray-500">Taux appliqué</p>
                      <p className="text-lg font-bold text-orange-600">{tauxGlobal}%</p>
                    </div>
                  )}
                </div>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-100">
                    <tr>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-700 uppercase">Matière</th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-700 uppercase">Niveau</th>
                      <th className="px-4 py-3 text-right text-xs font-medium text-gray-700 uppercase">Stock IEPP</th>
                      <th className="px-4 py-3 text-right text-xs font-medium text-gray-700 uppercase">Stock Récupéré</th>
                      <th className="px-4 py-3 text-right text-xs font-medium text-gray-700 uppercase">Déficit EPP</th>
                      <th className="px-4 py-3 text-right text-xs font-medium text-gray-700 uppercase">
                        {redistributionMode === "global" ? "Taux" : "Quantité"}
                      </th>
                      <th className="px-4 py-3 text-right text-xs font-medium text-gray-700 uppercase">À Redistribuer</th>
                      <th className="px-4 py-3 text-center text-xs font-medium text-gray-700 uppercase">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-200">
                    {stockItems.map((item) => (
                      <tr 
                        key={item.id} 
                        className={`hover:bg-gray-50 ${item.stockInsuffisant ? 'bg-red-50 border-l-4 border-red-500' : ''}`}
                      >
                        <td className="px-4 py-3">
                          {item.matiereId > 0 ? (
                            <span className="font-medium">{item.matiereLibelle}</span>
                          ) : (
                            <select
                              className="input-field text-sm"
                              value={item.matiereId}
                              onChange={(e) => {
                                const matiereId = parseInt(e.target.value)
                                handleMatiereNiveauChange(item.id, matiereId, item.niveauId)
                              }}
                            >
                              <option value="0">Sélectionner...</option>
                              {matieres.map((m) => (
                                <option key={m.id} value={m.id}>
                                  {m.libelle}
                                </option>
                              ))}
                            </select>
                          )}
                        </td>
                        <td className="px-4 py-3">
                          {item.niveauId > 0 ? (
                            <span className="font-medium">{item.niveauLibelle}</span>
                          ) : (
                            <select
                              className="input-field text-sm"
                              value={item.niveauId}
                              onChange={(e) => {
                                const niveauId = parseInt(e.target.value)
                                handleMatiereNiveauChange(item.id, item.matiereId, niveauId)
                              }}
                            >
                              <option value="0">Sélectionner...</option>
                              {niveaux.map((n) => (
                                <option key={n.id} value={n.id}>
                                  {n.libelle}
                                </option>
                              ))}
                            </select>
                          )}
                        </td>
                        <td className="px-4 py-3 text-right">
                          <div className="flex flex-col items-end">
                            <span className={`font-semibold text-lg ${item.stockIEPP > 0 ? 'text-green-600' : 'text-gray-400'}`}>
                              {item.stockIEPP}
                            </span>
                            <span className="text-xs text-gray-500">disponible</span>
                          </div>
                        </td>
                        <td className="px-4 py-3 text-right">
                          <div className="flex flex-col items-end">
                            <span className={`font-semibold ${(item.stockRecupere || 0) > 0 ? 'text-blue-600' : 'text-gray-400'}`}>
                              {item.stockRecupere || 0}
                            </span>
                            <span className="text-xs text-gray-500">récupéré</span>
                          </div>
                        </td>
                        <td className="px-4 py-3 text-right">
                          {item.deficitEpp !== undefined ? (
                            <div className="flex flex-col items-end">
                              <span className={`font-semibold text-lg ${item.deficitEpp > 0 ? 'text-red-600' : 'text-gray-400'}`}>
                                {item.deficitEpp}
                              </span>
                              <span className="text-xs text-gray-500">manquant</span>
                              {item.stockInsuffisant && (
                                <span
                                  className="text-xs text-red-600 font-medium mt-1"
                                  title="Stock mobilisable (IEPP + récupéré) inférieur au déficit de l’EPP"
                                >
                                  ⚠️ Stock insuffisant
                                </span>
                              )}
                            </div>
                          ) : (
                            <span className="text-gray-400 text-sm">-</span>
                          )}
                        </td>
                        <td className="px-4 py-3 text-right">
                          {redistributionMode === "global" ? (
                            <span className="text-gray-600">{item.taux || 0}%</span>
                          ) : (
                            <input
                              type="number"
                              min="0"
                              max={Math.min(
                                disponiblePourRedistribution(item),
                                item.deficitEpp ?? disponiblePourRedistribution(item)
                              )}
                              value={item.quantiteARedistribuer}
                              onChange={(e) => handleQuantiteChange(item.id, parseInt(e.target.value) || 0)}
                              className="input-field text-sm w-24 text-right"
                              disabled={disponiblePourRedistribution(item) <= 0}
                            />
                          )}
                        </td>
                        <td className="px-4 py-3 text-right">
                          <span className="font-bold text-orange-600">
                            {item.quantiteARedistribuer}
                          </span>
                        </td>
                        <td className="px-4 py-3 text-center">
                          <button
                            type="button"
                            onClick={() => handleRemoveItem(item.id)}
                            className="text-red-600 hover:text-red-800"
                            title="Supprimer"
                          >
                            <TrashIcon className="h-5 w-5" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                  <tfoot className="bg-gray-50 border-t-2">
                    <tr>
                      <td colSpan={6} className="px-4 py-3 text-right font-semibold">
                        Total à redistribuer:
                      </td>
                      <td className="px-4 py-3 text-right">
                        <span className="font-bold text-lg text-orange-600">{totalQuantite}</span>
                      </td>
                      <td></td>
                    </tr>
                  </tfoot>
                </table>
              </div>
            </div>
          )}

          {/* Commentaire */}
          <div className="form-group">
            <label className="form-label">Commentaire (optionnel)</label>
            <textarea
              className="input-field"
              rows={3}
              value={formData.commentaire}
              onChange={(e) =>
                setFormData((prev) => ({ ...prev, commentaire: e.target.value }))
              }
              placeholder="Ajoutez un commentaire pour cette redistribution..."
            />
          </div>

          {/* Boutons d'action */}
          <div className="flex justify-end space-x-3 pt-4 border-t sticky bottom-0 bg-white">
            <button
              type="button"
              onClick={onClose}
              className="btn-outline"
              disabled={isSubmitting}
            >
              Annuler
            </button>
            <button
              type="submit"
              className="btn-primary"
              disabled={isSubmitting || validItemsCount === 0}
            >
              {isSubmitting
                ? "Redistribution..."
                : `Redistribuer ${validItemsCount} combinaison(s)`}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}

