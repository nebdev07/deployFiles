"use client"

import { useEffect, useState, useCallback } from "react"
import { XCircleIcon, TrashIcon, InformationCircleIcon } from "@heroicons/react/24/outline"
import { regulationService } from "@/lib/services/regulation.service"
import { structuresService } from "@/lib/services/structures.service"
import { mouvementService } from "@/lib/services/mouvement.service"
import { toast } from "sonner"

export type HubRedistributionScope = "DRENA_IEPP" | "DAF_DRENA"

type HubLine = {
  id: string
  matiereId: number
  niveauId: number
  matiereLibelle: string
  niveauLibelle: string
  stockHub: number
  deficit: number
  quantiteARedistribuer: number
  stockInsuffisant: boolean
}

type EppDefComb = {
  matiereId: number
  niveauId: number
  matiereLibelle?: string
  niveauLibelle?: string
  deficit?: number
}

type IeppOptionRow = { id: number; code?: string; libelle?: string }

function disponibleHub(line: Pick<HubLine, "stockHub">): number {
  return Math.max(0, line.stockHub ?? 0)
}

function aggregateDeficitsFromEppItems(
  eppBlocks: Array<{ combinaisonsDeficitaires?: EppDefComb[] }>
): HubLine[] {
  const map = new Map<string, HubLine>()
  for (const epp of eppBlocks) {
    for (const c of epp.combinaisonsDeficitaires ?? []) {
      const k = `${c.matiereId}_${c.niveauId}`
      const prev = map.get(k)
      const def = (c.deficit ?? 0) + (prev?.deficit ?? 0)
      map.set(k, {
        id: k,
        matiereId: c.matiereId,
        niveauId: c.niveauId,
        matiereLibelle: c.matiereLibelle ?? `Matière ${c.matiereId}`,
        niveauLibelle: c.niveauLibelle ?? `Niveau ${c.niveauId}`,
        stockHub: 0,
        deficit: def,
        quantiteARedistribuer: 0,
        stockInsuffisant: false,
      })
    }
  }
  return Array.from(map.values())
}

function stockNumericId(value: unknown): number | undefined {
  if (value === null || value === undefined) return undefined
  const n = typeof value === "number" ? value : Number(value)
  return Number.isFinite(n) && n > 0 ? Math.trunc(n) : undefined
}

function stockQty(row: { quantiteDisponible?: unknown; quantite_disponible?: unknown }): number {
  const raw = row.quantiteDisponible ?? row.quantite_disponible
  if (raw === null || raw === undefined) return 0
  const n = typeof raw === "number" ? raw : Number(raw)
  return Number.isFinite(n) ? Math.max(0, n) : 0
}

interface RedistribuerHubStockModalV2Props {
  isOpen: boolean
  onClose: () => void
  onSuccess: () => void
  scope: HubRedistributionScope
  /** PK SA : stock source (DRENA pour DRENA→IEPP, DAF pour DAF→DRENA) */
  hubStructureId: number
  /** PK SA DRENA destinataire — requis pour DAF→DRENA */
  drenaDestinationId?: number
  anneeScolaireId: number
}

export default function RedistribuerHubStockModalV2({
  isOpen,
  onClose,
  onSuccess,
  scope,
  hubStructureId,
  drenaDestinationId,
  anneeScolaireId,
}: RedistribuerHubStockModalV2Props) {
  const [ieppOptions, setIeppOptions] = useState<IeppOptionRow[]>([])
  const [selectedIeppId, setSelectedIeppId] = useState<number>(0)
  const [lines, setLines] = useState<HubLine[]>([])
  const [loading, setLoading] = useState(false)
  const [loadingIepp, setLoadingIepp] = useState(false)
  const [submitting, setSubmitting] = useState(false)
  const [redistributionMode, setRedistributionMode] = useState<"global" | "manuel">("manuel")
  const [tauxGlobal, setTauxGlobal] = useState(100)
  const [commentaire, setCommentaire] = useState("")

  const hubLabel = scope === "DRENA_IEPP" ? "DRENA" : "DAF"
  const title = scope === "DRENA_IEPP" ? "Redistribution DRENA → IEPP" : "Redistribution DAF → DRENA"
  const subtitle =
    scope === "DRENA_IEPP"
      ? "Transférez le stock du hub DRENA vers un IEPP déficitaire, par matière et niveau (comme la redistribution IEPP → EPP)."
      : "Transférez le stock du hub national (DAF) vers une DRENA déficitaire, par matière et niveau."

  const loadIeppList = useCallback(async () => {
    if (!isOpen || scope !== "DRENA_IEPP" || !hubStructureId) return
    setLoadingIepp(true)
    try {
      const res = await structuresService.getIeppsByDrena(hubStructureId)
      const raw = (res.items ?? []) as unknown
      let list: IeppOptionRow[] = []
      if (Array.isArray(raw)) {
        if (raw.length > 0 && Array.isArray(raw[0])) {
          list = (raw as unknown[][]).flat() as IeppOptionRow[]
        } else {
          list = raw as IeppOptionRow[]
        }
      }
      setIeppOptions(list)
    } catch {
      setIeppOptions([])
      toast.error("Impossible de charger la liste des IEPP")
    } finally {
      setLoadingIepp(false)
    }
  }, [isOpen, scope, hubStructureId])

  const recalcQuantities = useCallback(
    (rows: HubLine[]) =>
      rows.map((line) => {
        const disponible = disponibleHub(line)
        const deficit = line.deficit
        let quantiteARedistribuer = 0
        if (redistributionMode === "global") {
          quantiteARedistribuer = Math.min(deficit, Math.round(disponible * (tauxGlobal / 100)))
        } else {
          quantiteARedistribuer = Math.min(deficit, disponible)
        }
        return { ...line, quantiteARedistribuer, stockInsuffisant: disponible < deficit }
      }),
    [redistributionMode, tauxGlobal]
  )

  const mergeHubStock = useCallback(
    async (baseLines: HubLine[]): Promise<HubLine[]> => {
      const stocksRes = await mouvementService.getStocksByStructureAndAnnee(hubStructureId, anneeScolaireId)
      const data = stocksRes.data
      const byKey = new Map<string, number>()
      const byMatiereOnly = new Map<number, number>()
      if (Array.isArray(data)) {
        for (const raw of data) {
          const row = raw as {
            matiereId?: unknown
            matiere_id?: unknown
            niveauId?: unknown
            niveau_id?: unknown
            quantiteDisponible?: unknown
            quantite_disponible?: unknown
          }
          const mid = stockNumericId(row.matiereId ?? row.matiere_id)
          if (mid === undefined) continue
          const nid = stockNumericId(row.niveauId ?? row.niveau_id)
          const q = stockQty(row)
          if (nid !== undefined) {
            const k = `${mid}_${nid}`
            byKey.set(k, (byKey.get(k) ?? 0) + q)
          } else {
            byMatiereOnly.set(mid, (byMatiereOnly.get(mid) ?? 0) + q)
          }
        }
      }
      const withStock = baseLines.map((line) => {
        const k = `${line.matiereId}_${line.niveauId}`
        const stockHub = byKey.get(k) ?? byMatiereOnly.get(line.matiereId) ?? 0
        return { ...line, stockHub }
      })
      return recalcQuantities(withStock)
    },
    [hubStructureId, anneeScolaireId, recalcQuantities]
  )

  const loadLinesDrenaIepp = useCallback(async () => {
    if (!selectedIeppId || anneeScolaireId <= 0) {
      setLines([])
      return
    }
    setLoading(true)
    try {
      const res = await regulationService.getEppDeficitaires(selectedIeppId, anneeScolaireId)
      const eppBlocks = (res.items ?? []) as Array<{ combinaisonsDeficitaires?: EppDefComb[] }>
      const agg = aggregateDeficitsFromEppItems(eppBlocks)
      const merged = await mergeHubStock(agg)
      setLines(merged)
      if (merged.length === 0) {
        toast.info("Aucune combinaison déficitaire agrégée pour cet IEPP sur cette année")
      }
    } catch {
      toast.error("Erreur lors du chargement des déficits IEPP")
      setLines([])
    } finally {
      setLoading(false)
    }
  }, [selectedIeppId, anneeScolaireId, mergeHubStock])

  const loadLinesDafDrena = useCallback(async () => {
    if (!drenaDestinationId || anneeScolaireId <= 0) {
      setLines([])
      return
    }
    setLoading(true)
    try {
      const res = await regulationService.getIeppDeficitairesByDrena(drenaDestinationId, anneeScolaireId)
      const rows = (res.items ?? []) as Array<{ eppDeficitaires?: Array<{ combinaisonsDeficitaires?: EppDefComb[] }> }>
      const eppBlocks: Array<{ combinaisonsDeficitaires?: EppDefComb[] }> = []
      for (const r of rows) {
        for (const epp of r.eppDeficitaires ?? []) {
          eppBlocks.push(epp)
        }
      }
      const agg = aggregateDeficitsFromEppItems(eppBlocks)
      const merged = await mergeHubStock(agg)
      setLines(merged)
      if (merged.length === 0) {
        toast.info("Aucun déficit agrégé trouvé pour cette DRENA")
      }
    } catch {
      toast.error("Erreur lors du chargement des déficits DRENA")
      setLines([])
    } finally {
      setLoading(false)
    }
  }, [drenaDestinationId, anneeScolaireId, mergeHubStock])

  useEffect(() => {
    if (!isOpen) return
    setSelectedIeppId(0)
    setLines([])
    setCommentaire("")
    if (scope === "DRENA_IEPP") {
      loadIeppList()
    } else if (scope === "DAF_DRENA" && drenaDestinationId) {
      loadLinesDafDrena()
    }
  }, [isOpen, scope, drenaDestinationId, loadIeppList, loadLinesDafDrena])

  useEffect(() => {
    if (!isOpen || scope !== "DRENA_IEPP" || selectedIeppId <= 0) return
    loadLinesDrenaIepp()
  }, [isOpen, scope, selectedIeppId, loadLinesDrenaIepp])

  useEffect(() => {
    if (!isOpen || lines.length === 0) return
    setLines((prev) => recalcQuantities(prev))
  }, [redistributionMode, isOpen, recalcQuantities])

  useEffect(() => {
    if (!isOpen || lines.length === 0 || redistributionMode !== "global") return
    setLines((prev) => recalcQuantities(prev))
  }, [tauxGlobal, isOpen, recalcQuantities, redistributionMode])

  const handleTauxGlobalChange = (t: number) => {
    setTauxGlobal(t)
  }

  const handleQuantiteChange = (id: string, q: number) => {
    setLines((prev) =>
      prev.map((line) => {
        if (line.id !== id) return line
        const disponible = disponibleHub(line)
        const maxAllowed = Math.min(disponible, line.deficit)
        const safe = Math.max(0, Math.min(maxAllowed, q))
        return { ...line, quantiteARedistribuer: safe, stockInsuffisant: disponible < line.deficit }
      })
    )
  }

  const handleRemove = (id: string) => setLines((prev) => prev.filter((l) => l.id !== id))

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    const valid = lines.filter((l) => l.quantiteARedistribuer > 0)
    if (valid.length === 0) {
      toast.error("Indiquez au moins une quantité à transférer")
      return
    }
    if (scope === "DRENA_IEPP" && selectedIeppId <= 0) {
      toast.error("Choisissez un IEPP destinataire")
      return
    }
    if (scope === "DAF_DRENA" && !drenaDestinationId) {
      toast.error("DRENA destinataire manquante")
      return
    }
    for (const l of valid) {
      const maxAllowed = Math.min(disponibleHub(l), l.deficit)
      if (l.quantiteARedistribuer > maxAllowed) {
        toast.error(`Quantité invalide pour ${l.matiereLibelle} / ${l.niveauLibelle}`)
        return
      }
    }
    setSubmitting(true)
    try {
      const errors: string[] = []
      for (const l of valid) {
        if (scope === "DRENA_IEPP") {
          const r = await regulationService.redistribuerDrenaIepp({
            drenaId: hubStructureId,
            ieppId: selectedIeppId,
            matiereId: l.matiereId,
            niveauId: l.niveauId,
            quantite: l.quantiteARedistribuer,
            anneeScolaireId,
            commentaire: commentaire || undefined,
          })
          if (r.hasError) errors.push(`${l.matiereLibelle}: ${(r.status as { message?: string })?.message ?? "échec"}`)
        } else {
          const r = await regulationService.redistribuerDafDrena({
            dafId: hubStructureId,
            drenaId: drenaDestinationId!,
            matiereId: l.matiereId,
            niveauId: l.niveauId,
            quantite: l.quantiteARedistribuer,
            anneeScolaireId,
            commentaire: commentaire || undefined,
          })
          if (r.hasError) errors.push(`${l.matiereLibelle}: ${(r.status as { message?: string })?.message ?? "échec"}`)
        }
      }
      if (errors.length > 0) {
        toast.error(errors.slice(0, 3).join(" ; "))
      } else {
        toast.success(`${valid.length} ligne(s) enregistrée(s)`)
        onSuccess()
        onClose()
      }
    } catch (err: unknown) {
      toast.error(err instanceof Error ? err.message : "Erreur")
    } finally {
      setSubmitting(false)
    }
  }

  const totalQ = lines.reduce((s, l) => s + l.quantiteARedistribuer, 0)
  const validCount = lines.filter((l) => l.quantiteARedistribuer > 0).length

  if (!isOpen) return null

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div
        className="modal-content !w-[96vw] !max-w-[96vw] !mx-0 max-h-[94vh] overflow-y-auto rounded-xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between mb-4 sticky top-0 bg-white pb-4 border-b z-10">
          <div>
            <h3 className="text-xl font-semibold">{title}</h3>
            <p className="text-sm text-gray-500 mt-1">{subtitle}</p>
          </div>
          <button type="button" onClick={onClose} className="text-gray-400 hover:text-gray-600">
            <XCircleIcon className="h-6 w-6" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-5">
          {scope === "DRENA_IEPP" && (
            <div className="form-group max-w-xl">
              <label className="form-label">IEPP destinataire *</label>
              <select
                className="input-field"
                value={selectedIeppId || ""}
                onChange={(e) => setSelectedIeppId(Number(e.target.value) || 0)}
                required
                disabled={loadingIepp}
              >
                <option value="0">{loadingIepp ? "Chargement…" : "— Choisir un IEPP —"}</option>
                {ieppOptions.map((o) => (
                  <option key={o.id} value={o.id}>
                    {o.libelle ?? o.code ?? `IEPP ${o.id}`}
                  </option>
                ))}
              </select>
            </div>
          )}

          {scope === "DAF_DRENA" && drenaDestinationId != null && (
            <p className="text-sm text-gray-700">
              DRENA destinataire : <span className="font-medium">#{drenaDestinationId}</span>
            </p>
          )}

          <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
            <div className="flex items-center gap-2 mb-2">
              <InformationCircleIcon className="h-5 w-5 text-blue-600" />
              <span className="font-semibold text-gray-700">Mode de redistribution</span>
            </div>
            <div className="flex gap-2 mb-3">
              <button
                type="button"
                onClick={() => setRedistributionMode("global")}
                className={`px-4 py-2 rounded-md text-sm font-medium ${
                  redistributionMode === "global" ? "bg-orange-600 text-white" : "bg-gray-200 text-gray-700"
                }`}
              >
                Global (Taux)
              </button>
              <button
                type="button"
                onClick={() => setRedistributionMode("manuel")}
                className={`px-4 py-2 rounded-md text-sm font-medium ${
                  redistributionMode === "manuel" ? "bg-orange-600 text-white" : "bg-gray-200 text-gray-700"
                }`}
              >
                Manuel (Quantités)
              </button>
            </div>
            {redistributionMode === "global" && (
              <div className="flex items-center gap-4">
                <input
                  type="range"
                  min={0}
                  max={100}
                  value={tauxGlobal}
                  onChange={(e) => handleTauxGlobalChange(parseInt(e.target.value, 10))}
                  className="flex-1"
                />
                <input
                  type="number"
                  min={0}
                  max={100}
                  value={tauxGlobal}
                  onChange={(e) => handleTauxGlobalChange(parseInt(e.target.value, 10) || 0)}
                  className="input-field w-20 text-center"
                />
                <span className="text-gray-600">%</span>
              </div>
            )}
          </div>

          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 text-sm text-blue-900">
            Les combinaisons matière/niveau et le besoin (déficit agrégé) sont chargés automatiquement. La quantité
            mobilisable correspond au <strong>stock disponible au hub {hubLabel}</strong> pour chaque ligne.
          </div>

          {loading && <p className="text-gray-500 text-sm">Chargement des lignes…</p>}

          {lines.length > 0 && (
            <div className="border rounded-lg overflow-hidden shadow-sm">
              <div className="bg-gradient-to-r from-gray-50 to-gray-100 px-4 py-3 border-b flex justify-between items-center">
                <div>
                  <h4 className="font-semibold text-gray-700">
                    Stocks à transférer ({validCount} ligne(s) avec quantité &gt; 0)
                  </h4>
                  <p className="text-sm text-gray-500 mt-1">
                    Total : <span className="font-bold text-lg text-orange-600">{totalQ}</span> unités
                  </p>
                </div>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="bg-gray-100">
                    <tr>
                      <th className="px-3 py-2 text-left">Matière</th>
                      <th className="px-3 py-2 text-left">Niveau</th>
                      <th className="px-3 py-2 text-right">Stock hub ({hubLabel})</th>
                      <th className="px-3 py-2 text-right">Déficit (agrégé)</th>
                      <th className="px-3 py-2 text-right">{redistributionMode === "global" ? "Taux" : "Quantité"}</th>
                      <th className="px-3 py-2 text-right">À transférer</th>
                      <th className="px-3 py-2 text-center">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-200">
                    {lines.map((line) => (
                      <tr
                        key={line.id}
                        className={line.stockInsuffisant ? "bg-red-50 border-l-4 border-red-400" : "hover:bg-gray-50"}
                      >
                        <td className="px-3 py-2 font-medium">{line.matiereLibelle}</td>
                        <td className="px-3 py-2">{line.niveauLibelle}</td>
                        <td className="px-3 py-2 text-right text-green-700 font-semibold">{line.stockHub}</td>
                        <td className="px-3 py-2 text-right text-red-700 font-semibold">{line.deficit}</td>
                        <td className="px-3 py-2 text-right">
                          {redistributionMode === "global" ? (
                            <span>{tauxGlobal}%</span>
                          ) : (
                            <input
                              type="number"
                              min={0}
                              max={Math.min(disponibleHub(line), line.deficit)}
                              className="input-field w-24 text-right"
                              value={line.quantiteARedistribuer}
                              onChange={(e) => handleQuantiteChange(line.id, parseInt(e.target.value, 10) || 0)}
                            />
                          )}
                        </td>
                        <td className="px-3 py-2 text-right font-bold text-orange-600">{line.quantiteARedistribuer}</td>
                        <td className="px-3 py-2 text-center">
                          <button type="button" onClick={() => handleRemove(line.id)} className="text-red-600">
                            <TrashIcon className="h-5 w-5" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          <div className="form-group">
            <label className="form-label">Commentaire (optionnel)</label>
            <textarea
              className="input-field"
              rows={2}
              value={commentaire}
              onChange={(e) => setCommentaire(e.target.value)}
            />
          </div>

          <div className="flex justify-end gap-2 pt-4 border-t">
            <button type="button" className="btn-outline" onClick={onClose} disabled={submitting}>
              Annuler
            </button>
            <button type="submit" className="btn-primary" disabled={submitting || validCount === 0}>
              {submitting ? "Envoi…" : `Valider ${validCount} ligne(s)`}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}
