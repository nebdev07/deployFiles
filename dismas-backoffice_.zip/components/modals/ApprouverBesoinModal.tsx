"use client"

import { useState, useEffect, useMemo, useRef, type ChangeEvent } from "react"
import { XMarkIcon, EyeIcon, CheckCircleIcon, ArrowDownTrayIcon, DocumentArrowUpIcon } from "@heroicons/react/24/outline"
import toast from "react-hot-toast"
import { besoinsService, BesoinResponse } from "../../lib/services/besoins.service"
import {
  downloadApprobationTemplateFromBackend,
  approbationParseToMaps,
  administrativeStructureId,
  eppExceptionCompositeKey,
  filterEppBesoinsForIeppConsolidation,
} from "@/lib/approbation-besoin-excel"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"

type BesoinDetailRow = NonNullable<BesoinResponse["besoinDetails"]>[number]

/** Exécute des promesses avec une limite de concurrence (évite de saturer le réseau / le serveur). */
async function mapWithConcurrency<T, R>(
  items: T[],
  concurrency: number,
  mapper: (item: T, index: number) => Promise<R>
): Promise<R[]> {
  if (items.length === 0) return []
  const cap = Math.max(1, Math.min(concurrency, items.length))
  const results: R[] = new Array(items.length)
  let nextIndex = 0
  async function worker() {
    for (;;) {
      const i = nextIndex++
      if (i >= items.length) return
      results[i] = await mapper(items[i], i)
    }
  }
  await Promise.all(Array.from({ length: cap }, () => worker()))
  return results
}

function sortBesoinDetailsByNiveauThenMatiere(details: BesoinDetailRow[] | undefined): BesoinDetailRow[] {
  if (!details?.length) return []
  return [...details].sort((a, b) => {
    const na = a.niveauScolaireId ?? 1_000_000
    const nb = b.niveauScolaireId ?? 1_000_000
    if (na !== nb) return na - nb
    return (a.matiereLibelle || a.matiereCode || String(a.matiereId)).localeCompare(
      b.matiereLibelle || b.matiereCode || String(b.matiereId),
      "fr",
      { sensitivity: "base" }
    )
  })
}

/** Une entrée EPP par structure administrative, détails fusionnés (plusieurs besoins IEPP / niveaux). */
function mergeEppBesoinsByAdministrativeStructure(eppChunks: BesoinResponse[]): BesoinResponse[] {
  const bySid = new Map<number, BesoinResponse>()
  for (const b of eppChunks) {
    const sid = administrativeStructureId(b) ?? b.id
    if (typeof sid !== "number" || sid <= 0) continue
    const existing = bySid.get(sid)
    if (!existing) {
      bySid.set(sid, { ...b, besoinDetails: [...(b.besoinDetails || [])] })
      continue
    }
    const seen = new Set((existing.besoinDetails || []).map((d) => d.id))
    const merged = [...(existing.besoinDetails || [])]
    for (const d of b.besoinDetails || []) {
      if (!seen.has(d.id)) {
        seen.add(d.id)
        merged.push(d)
      }
    }
    existing.besoinDetails = merged
  }
  return [...bySid.values()].sort((a, b) =>
    (a.structureAdministrativeLibelle || `Structure ${a.id}`).localeCompare(
      b.structureAdministrativeLibelle || `Structure ${b.id}`,
      "fr",
      { sensitivity: "base" }
    )
  )
}

/** Blocs « par niveau » pour afficher les manuels EPP (sous-titres + lignes matières). */
function groupBesoinDetailsByNiveauScolaire(
  details: BesoinDetailRow[] | undefined
): { key: string; label: string; rows: BesoinDetailRow[] }[] {
  const sorted = sortBesoinDetailsByNiveauThenMatiere(details)
  const by = new Map<number, BesoinDetailRow[]>()
  for (const d of sorted) {
    const k = d.niveauScolaireId ?? -1
    if (!by.has(k)) by.set(k, [])
    by.get(k)!.push(d)
  }
  const keys = [...by.keys()].sort((a, b) => {
    if (a === -1) return 1
    if (b === -1) return -1
    return a - b
  })
  return keys.map((k) => {
    const rows = by.get(k)!
    const label =
      rows[0]?.niveauScolaireLibelle ||
      rows[0]?.niveauScolaireCode ||
      (k === -1 ? "Niveau non renseigné" : `Niveau ${k}`)
    return { key: `n-${k}`, label, rows }
  })
}

/** Libellé DRENA : depuis la liste besoins (page) si présent, sinon préfixe du code structure (ex. A010-B001… → DRENA A010). */
function drenaGroupMeta(besoinIepp: BesoinResponse, listBesoins: BesoinResponse[]): { key: string; label: string } {
  type Row = BesoinResponse & { _rawData?: { id?: number; drena?: string }; drena?: string }
  const rawList = listBesoins as Row[]
  const match = rawList.find((x) => {
    const rid = x._rawData?.id ?? x.id
    return rid === besoinIepp.id
  })
  const fromList = match?._rawData?.drena ?? match?.drena
  if (typeof fromList === "string" && fromList.trim()) {
    const t = fromList.trim()
    return { key: t, label: t }
  }
  const code = (besoinIepp.structureAdministrativeCode || "").trim()
  const prefix = code.split("-")[0]?.trim() || "—"
  const lab = `DRENA ${prefix}`
  return { key: lab, label: lab }
}

function sumConsolidatedAndApprovedForIeppList(
  iepps: BesoinResponse[],
  quantitesApprouvees: Map<number, number>,
  tauxGlobal: number | undefined
): { demandee: number; approuvee: number } {
  let demandee = 0
  let approuvee = 0
  for (const besoin of iepps) {
    for (const detail of besoin.besoinDetails || []) {
      const qc = detail.quantiteConsolidee ?? 0
      if (qc <= 0) continue
      demandee += qc
      let qa = qc
      if (quantitesApprouvees.has(detail.id)) {
        qa = quantitesApprouvees.get(detail.id)!
      } else if (tauxGlobal !== undefined && tauxGlobal !== null) {
        qa = Math.round(qc * tauxGlobal)
      }
      approuvee += qa
    }
  }
  return { demandee, approuvee }
}

/** Données issues d’un parse Excel (ex. import depuis l’onglet validation) à appliquer une fois les détails chargés. */
export type ApprobationExcelPrefill = {
  quantitesApprouvees: Record<string, number>
  exceptionsEpp: Record<string, Record<string, number>>
}

interface ApprouverBesoinModalProps {
  isOpen: boolean
  onClose: () => void
  besoinIds: number[]
  onApprove: (tauxGlobal?: number, quantitesApprouvees?: Map<number, number>, exceptionsEpp?: Map<number, Map<string, number>>) => Promise<void>
  besoins?: BesoinResponse[]
  /** Si défini après ouverture, remplit quantités / exceptions (sans taux global) puis appelle onExcelPrefillConsumed. */
  excelPrefill?: ApprobationExcelPrefill | null
  onExcelPrefillConsumed?: () => void
}

export default function ApprouverBesoinModal({
  isOpen,
  onClose,
  besoinIds,
  onApprove,
  besoins = [],
  excelPrefill = null,
  onExcelPrefillConsumed,
}: ApprouverBesoinModalProps) {
  const [tauxGlobal, setTauxGlobal] = useState<number | undefined>(undefined)
  const [quantitesApprouvees, setQuantitesApprouvees] = useState<Map<number, number>>(new Map())
  const [exceptionsEpp, setExceptionsEpp] = useState<Map<number, Map<string, number>>>(new Map()) // Map<eppId, Map<niveau_matiere, qte>>
  const [loadingDetails, setLoadingDetails] = useState(false)
  /** Phase IEPP : progression des appels getDetails (ids sélectionnés). */
  const [ieppFetchProgress, setIeppFetchProgress] = useState<{ done: number; total: number } | null>(null)
  /** Phase EPP : getConsolidationDetails par IEPP (après affichage du formulaire IEPP). */
  const [eppFetchProgress, setEppFetchProgress] = useState<{ done: number; total: number } | null>(null)
  const loadBesoinsDetailsGenRef = useRef(0)
  const [loadingPreview, setLoadingPreview] = useState(false)
  const [loadingApprove, setLoadingApprove] = useState(false)
  const [besoinsDetails, setBesoinsDetails] = useState<BesoinResponse[]>([])
  const [previewData, setPreviewData] = useState<any>(null)
  const [showPreview, setShowPreview] = useState(false)
  const [eppBesoinsMap, setEppBesoinsMap] = useState<Map<number, BesoinResponse[]>>(new Map()) // Map<ieppBesoinId, EPP besoins[]>
  const [loadingExcel, setLoadingExcel] = useState(false)
  const excelFileInputRef = useRef<HTMLInputElement | null>(null)
  /** Import Excel : le serveur a renvoyé des avertissements (ex. quantités ramenées) — attendre la confirmation utilisateur. */
  const [pendingExcelImportWarnings, setPendingExcelImportWarnings] = useState<{
    warnings: string[]
    prefill: ApprobationExcelPrefill
  } | null>(null)
  const skipExcelWarningsCloseToastRef = useRef(false)

  // Charger les détails des besoins au montage
  useEffect(() => {
    if (isOpen && besoinIds.length > 0) {
      loadBesoinsDetails()
    }
  }, [isOpen, besoinIds])

  useEffect(() => {
    if (!isOpen) {
      setPendingExcelImportWarnings(null)
      skipExcelWarningsCloseToastRef.current = false
    }
  }, [isOpen])

  useEffect(() => {
    const eppPending = eppFetchProgress != null && eppFetchProgress.done < eppFetchProgress.total
    if (!isOpen || loadingDetails || eppPending || !excelPrefill || besoinsDetails.length === 0) {
      return
    }
    const { quantites, exceptions } = approbationParseToMaps(excelPrefill)
    setQuantitesApprouvees(quantites)
    setExceptionsEpp(exceptions)
    setTauxGlobal(undefined)
    onExcelPrefillConsumed?.()
  }, [isOpen, loadingDetails, eppFetchProgress, excelPrefill, besoinsDetails.length, onExcelPrefillConsumed])

  const loadBesoinsDetails = async () => {
    const gen = ++loadBesoinsDetailsGenRef.current
    setLoadingDetails(true)
    setIeppFetchProgress(besoinIds.length > 0 ? { done: 0, total: besoinIds.length } : null)
    setEppFetchProgress(null)
    // Nouvelle ouverture / nouvelle sélection : ne pas réutiliser taux, quantités ou exceptions d’une session précédente
    setTauxGlobal(undefined)
    setQuantitesApprouvees(new Map())
    setExceptionsEpp(new Map())
    setEppBesoinsMap(new Map())
    setPreviewData(null)
    setShowPreview(false)
    try {
      const totalIds = besoinIds.length
      let ieppCompleted = 0
      const results = await mapWithConcurrency(besoinIds, 8, async (id) => {
        const r = await besoinsService.getDetails(id)
        ieppCompleted += 1
        if (loadBesoinsDetailsGenRef.current === gen) {
          setIeppFetchProgress({ done: ieppCompleted, total: totalIds })
        }
        return r
      })

      if (loadBesoinsDetailsGenRef.current !== gen) return

      const loadedBesoins = results
        .filter((r) => r.success && r.data)
        .map((r) => r.data!)

      const besoinsIepp = loadedBesoins.filter(
        (b) => b.structureType === "IEPP" && b.statut === "CONSOLIDE"
      )

      if (besoinsIepp.length === 0) {
        toast.error(
          "Aucun besoin IEPP consolidé trouvé. Seuls les besoins IEPP consolidés peuvent être approuvés par la DAF."
        )
        onClose()
        return
      }

      if (loadedBesoins.length > besoinsIepp.length) {
        toast(
          `${loadedBesoins.length - besoinsIepp.length} besoin(s) EPP ignoré(s). Seuls les besoins IEPP consolidés sont affichés.`,
          { icon: "⚠️", duration: 4000 }
        )
      }

      setBesoinsDetails(besoinsIepp)
      setLoadingDetails(false)
      setIeppFetchProgress(null)

      const eppTotal = besoinsIepp.length
      let eppCompleted = 0
      setEppFetchProgress({ done: 0, total: eppTotal })

      try {
        await mapWithConcurrency(besoinsIepp, 3, async (besoinIepp) => {
          const ieppSid = administrativeStructureId(besoinIepp)
          try {
            if (ieppSid != null) {
              const eppBesoinsResult = await besoinsService.getConsolidationDetails(ieppSid)
              if (eppBesoinsResult.success && eppBesoinsResult.data) {
                const eppBesoinsFiltered = filterEppBesoinsForIeppConsolidation(
                  eppBesoinsResult.data,
                  besoinIepp
                )
                if (eppBesoinsFiltered.length > 0 && loadBesoinsDetailsGenRef.current === gen) {
                  setEppBesoinsMap((prev) => {
                    const n = new Map(prev)
                    n.set(besoinIepp.id, eppBesoinsFiltered)
                    return n
                  })
                }
              }
            }
          } catch (error) {
            console.warn(`Erreur lors du chargement des besoins EPP consolidés pour IEPP ${besoinIepp.id}:`, error)
          } finally {
            eppCompleted += 1
            if (loadBesoinsDetailsGenRef.current === gen) {
              setEppFetchProgress({ done: eppCompleted, total: eppTotal })
            }
          }
        })
      } finally {
        if (loadBesoinsDetailsGenRef.current === gen) {
          setEppFetchProgress(null)
        }
      }
    } catch (error: any) {
      console.error("Erreur lors du chargement des détails:", error)
      toast.error("Erreur lors du chargement des détails des besoins")
    } finally {
      if (loadBesoinsDetailsGenRef.current === gen) {
        setLoadingDetails(false)
        setIeppFetchProgress(null)
      }
    }
  }

  const handlePreview = async () => {
    setLoadingPreview(true)
    try {
      const result = await besoinsService.previewApprove(
        besoinIds,
        tauxGlobal,
        quantitesApprouvees.size > 0 ? quantitesApprouvees : undefined,
        exceptionsEpp.size > 0 ? exceptionsEpp : undefined
      )

      if (result.success && result.data) {
        setPreviewData(result.data)
        setShowPreview(true)
        toast.success('Prévisualisation générée avec succès')
      } else {
        toast.error(result.message || 'Erreur lors de la prévisualisation')
      }
    } catch (error: any) {
      console.error('Erreur lors de la prévisualisation:', error)
      toast.error('Erreur lors de la prévisualisation')
    } finally {
      setLoadingPreview(false)
    }
  }

  const handleApprove = async () => {
    setLoadingApprove(true)
    try {
      await onApprove(
        tauxGlobal,
        quantitesApprouvees.size > 0 ? quantitesApprouvees : undefined,
        exceptionsEpp.size > 0 ? exceptionsEpp : undefined
      )
      onClose()
    } catch (error: any) {
      console.error('Erreur lors de l\'approbation:', error)
      toast.error('Erreur lors de l\'approbation')
    } finally {
      setLoadingApprove(false)
    }
  }

  const updateQuantiteApprouvee = (besoinDetailId: number, quantite: number) => {
    const newMap = new Map(quantitesApprouvees)
    if (quantite > 0) {
      newMap.set(besoinDetailId, quantite)
    } else {
      newMap.delete(besoinDetailId)
    }
    setQuantitesApprouvees(newMap)
  }
  
  // ✅ NOUVEAU : Mettre à jour une exception EPP
  const updateExceptionEpp = (eppId: number, niveauMatiereKey: string, quantite: number) => {
    const newMap = new Map(exceptionsEpp)
    if (!newMap.has(eppId)) {
      newMap.set(eppId, new Map())
    }
    const eppExceptions = newMap.get(eppId)!
    if (quantite > 0) {
      eppExceptions.set(niveauMatiereKey, quantite)
    } else {
      eppExceptions.delete(niveauMatiereKey)
      if (eppExceptions.size === 0) {
        newMap.delete(eppId)
      }
    }
    setExceptionsEpp(newMap)
  }
  
  const getExceptionEpp = (eppId: number, niveauMatiereKey: string): number | undefined => {
    return exceptionsEpp.get(eppId)?.get(niveauMatiereKey)
  }

  const handleDownloadTemplateServer = async () => {
    if (besoinIds.length === 0) return
    setLoadingExcel(true)
    try {
      await downloadApprobationTemplateFromBackend(besoinIds)
      toast.success("Modèle Excel téléchargé (généré par le serveur, codes métier en colonnes).")
    } catch (e: any) {
      toast.error(e?.message || "Impossible de générer le modèle")
    } finally {
      setLoadingExcel(false)
    }
  }

  const applyParsedExcelPrefill = (prefill: ApprobationExcelPrefill) => {
    const { quantites, exceptions } = approbationParseToMaps(prefill)
    setQuantitesApprouvees(quantites)
    setExceptionsEpp(exceptions)
    setTauxGlobal(undefined)
  }

  const handleExcelFileChosen = async (e: ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0]
    e.target.value = ""
    if (!f) return
    setLoadingExcel(true)
    try {
      const r = await besoinsService.parseApprovalTemplateExcel(f, besoinIds)
      if (!r.success || !r.data) {
        toast.error(r.message || "Analyse du fichier impossible")
        return
      }
      const w = Array.isArray(r.data.warnings) ? r.data.warnings.filter(Boolean) : []
      const prefill: ApprobationExcelPrefill = {
        quantitesApprouvees: r.data.quantitesApprouvees ?? {},
        exceptionsEpp: r.data.exceptionsEpp ?? {},
      }
      if (w.length > 0) {
        setPendingExcelImportWarnings({ warnings: w, prefill })
        return
      }
      applyParsedExcelPrefill(prefill)
      toast.success("Fichier importé : quantités / exceptions EPP appliquées (sans taux global).")
    } catch (err: any) {
      toast.error(err?.message || "Import impossible")
    } finally {
      setLoadingExcel(false)
    }
  }

  const confirmPendingExcelImport = () => {
    if (!pendingExcelImportWarnings) return
    applyParsedExcelPrefill(pendingExcelImportWarnings.prefill)
    skipExcelWarningsCloseToastRef.current = true
    setPendingExcelImportWarnings(null)
    toast.success(
      "Fichier importé avec les quantités validées par le serveur (certaines valeurs ont pu être ajustées — voir la liste d’avertissements).",
      { duration: 6000 }
    )
  }

  const cancelPendingExcelImport = () => {
    skipExcelWarningsCloseToastRef.current = true
    setPendingExcelImportWarnings((prev) => {
      if (prev) {
        toast("Import annulé. Corrigez le fichier Excel si besoin, puis réimportez.", {
          icon: "⚠️",
          duration: 5000,
        })
      }
      return null
    })
  }

  const onExcelWarningsDialogOpenChange = (open: boolean) => {
    if (open) return
    if (skipExcelWarningsCloseToastRef.current) {
      skipExcelWarningsCloseToastRef.current = false
      return
    }
    setPendingExcelImportWarnings((prev) => {
      if (prev) {
        toast("Import annulé. Corrigez le fichier Excel si besoin, puis réimportez.", {
          icon: "⚠️",
          duration: 5000,
        })
      }
      return null
    })
  }

  const getQuantiteApprouvee = (besoinDetailId: number, quantiteConsolidee: number): number => {
    // Si modification manuelle, utiliser cette valeur
    if (quantitesApprouvees.has(besoinDetailId)) {
      return quantitesApprouvees.get(besoinDetailId)!
    }
    // Sinon, si taux global, l'appliquer
    if (tauxGlobal !== undefined && tauxGlobal !== null) {
      return Math.round(quantiteConsolidee * tauxGlobal)
    }
    // Sinon, retourner la quantité consolidée
    return quantiteConsolidee
  }

  const { totalQuantiteDemandee, totalQuantiteApprouvee } = useMemo(() => {
    let demandee = 0
    let approuvee = 0
    for (const besoin of besoinsDetails) {
      for (const detail of besoin.besoinDetails || []) {
        const qc = detail.quantiteConsolidee ?? 0
        demandee += qc
        let qa = qc
        if (quantitesApprouvees.has(detail.id)) {
          qa = quantitesApprouvees.get(detail.id)!
        } else if (tauxGlobal !== undefined && tauxGlobal !== null) {
          qa = Math.round(qc * tauxGlobal)
        }
        approuvee += qa
      }
    }
    return { totalQuantiteDemandee: demandee, totalQuantiteApprouvee: approuvee }
  }, [besoinsDetails, tauxGlobal, quantitesApprouvees])

  /** Regroupe les besoins consolidés par structure IEPP (même établissement, plusieurs niveaux = une entrée). */
  const drenaGroups = useMemo(() => {
    type IeppStructureGroup = {
      structureKey: number
      libelle: string
      besoins: BesoinResponse[]
    }
    type DrenaGroup = { key: string; label: string; structures: IeppStructureGroup[] }
    const map = new Map<string, DrenaGroup>()
    for (const b of besoinsDetails) {
      const { key, label } = drenaGroupMeta(b, besoins)
      if (!map.has(key)) {
        map.set(key, { key, label, structures: [] })
      }
      const sk = administrativeStructureId(b) ?? b.structureId ?? b.id
      const g = map.get(key)!
      let st = g.structures.find((s) => s.structureKey === sk)
      if (!st) {
        st = {
          structureKey: sk,
          libelle: b.structureAdministrativeLibelle || `Structure ${sk}`,
          besoins: [],
        }
        g.structures.push(st)
      }
      st.besoins.push(b)
    }
    for (const g of map.values()) {
      for (const st of g.structures) {
        st.besoins.sort((a, b) => (a.niveauScolaireId ?? 0) - (b.niveauScolaireId ?? 0))
      }
      g.structures.sort((a, b) =>
        a.libelle.localeCompare(b.libelle, "fr", { sensitivity: "base" })
      )
    }
    return Array.from(map.values()).sort((a, b) =>
      a.label.localeCompare(b.label, "fr", { sensitivity: "base" })
    )
  }, [besoinsDetails, besoins])

  const eppStillLoading =
    eppFetchProgress != null &&
    eppFetchProgress.total > 0 &&
    eppFetchProgress.done < eppFetchProgress.total

  if (!isOpen) return null

  return (
    <>
    <div className="fixed inset-0 z-50 overflow-y-auto">
      <div className="flex items-center justify-center min-h-screen px-4 pt-4 pb-20 text-center sm:block sm:p-0">
        <div className="fixed inset-0 transition-opacity bg-gray-500 bg-opacity-75" onClick={onClose}></div>

        <div className="inline-block align-bottom bg-white rounded-lg text-left overflow-hidden shadow-xl ring-1 ring-slate-200/80 transform transition-all sm:my-8 sm:align-middle sm:max-w-7xl sm:w-full">
          <div className="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4">
            <div className="flex items-center justify-between mb-4 border-b border-blue-100 pb-3">
              <h3 className="text-base font-semibold tracking-tight text-blue-950">
                Approbation DAF
              </h3>
              <button
                onClick={onClose}
                className="text-slate-400 hover:text-blue-800"
              >
                <XMarkIcon className="h-6 w-6" />
              </button>
            </div>

            {loadingDetails ? (
              <div className="py-8 px-2">
                <div className="mx-auto max-w-md text-center">
                  <div className="animate-spin rounded-full h-8 w-8 border-2 border-blue-100 border-t-blue-600 mx-auto" />
                  <p className="mt-2 text-sm font-medium text-slate-700">Chargement des besoins IEPP…</p>
                  {ieppFetchProgress && ieppFetchProgress.total > 0 && (
                    <>
                      <p className="mt-1 text-xs tabular-nums text-slate-500">
                        {ieppFetchProgress.done} / {ieppFetchProgress.total} fiches
                      </p>
                      <div className="mt-3 h-2 w-full overflow-hidden rounded-full bg-slate-200">
                        <div
                          className="h-full rounded-full bg-blue-600 transition-[width] duration-300 ease-out"
                          style={{
                            width: `${Math.min(100, Math.round((100 * ieppFetchProgress.done) / ieppFetchProgress.total))}%`,
                          }}
                        />
                      </div>
                      <p className="mt-2 text-[11px] leading-snug text-slate-400">
                        Chargement limité en parallèle pour éviter de bloquer le serveur ; les données EPP suivront
                        ensuite.
                      </p>
                    </>
                  )}
                </div>
              </div>
            ) : (
              <div className="space-y-5">
                {eppStillLoading && eppFetchProgress && (
                  <div className="flex flex-wrap items-center justify-between gap-2 rounded-md border border-amber-200 bg-amber-50 px-3 py-2 text-sm text-amber-950">
                    <span className="font-medium">Chargement des données EPP (exceptions)…</span>
                    <span className="text-xs tabular-nums text-amber-900/80">
                      {eppFetchProgress.done} / {eppFetchProgress.total} IEPP
                    </span>
                  </div>
                )}
                {besoinsDetails.length > 0 && (
                  <>
                    <p className="rounded-md border border-blue-100 bg-blue-50/90 px-3 py-2.5 text-sm leading-snug text-blue-950">
                      Par défaut, agrément à <span className="font-semibold text-blue-900">100 %</span> du consolidé IEPP.
                      Modifiez les quantités ci-dessous (IEPP ou EPP) ou utilisez l’import Excel.
                    </p>
                    <div className="flex flex-col gap-3 rounded-lg border border-slate-200 bg-slate-50/90 px-3 py-3 sm:flex-row sm:items-center sm:justify-between">
                      <div className="flex flex-wrap items-baseline gap-x-4 gap-y-1 text-sm tabular-nums">
                        <span className="text-slate-600">
                          Demandé{" "}
                          <span className="font-semibold text-slate-900">{totalQuantiteDemandee.toLocaleString()}</span>
                        </span>
                        <span className="text-slate-300 hidden sm:inline">|</span>
                        <span className="text-slate-600">
                          À approuver{" "}
                          <span className="font-semibold text-blue-800">{totalQuantiteApprouvee.toLocaleString()}</span>
                          {totalQuantiteDemandee > 0 && (
                            <span className="text-slate-500 font-normal ml-1">
                              ({Math.round((totalQuantiteApprouvee / totalQuantiteDemandee) * 100)} %)
                            </span>
                          )}
                        </span>
                      </div>
                      <div className="flex flex-wrap items-center gap-2">
                        <button
                          type="button"
                          onClick={handleDownloadTemplateServer}
                          disabled={loadingDetails || loadingExcel}
                          className="inline-flex items-center gap-1.5 rounded border border-gray-300 bg-white px-3 py-1.5 text-xs font-medium text-gray-700 hover:bg-gray-50 disabled:opacity-50"
                        >
                          <ArrowDownTrayIcon className="h-3.5 w-3.5" />
                          Modèle Excel
                        </button>
                        <input
                          ref={excelFileInputRef}
                          type="file"
                          accept=".xlsx,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                          className="hidden"
                          onChange={handleExcelFileChosen}
                        />
                        <button
                          type="button"
                          onClick={() => excelFileInputRef.current?.click()}
                          disabled={loadingDetails || loadingExcel}
                          className="inline-flex items-center gap-1.5 rounded border border-gray-300 bg-white px-3 py-1.5 text-xs font-medium text-gray-700 hover:bg-gray-50 disabled:opacity-50"
                        >
                          <DocumentArrowUpIcon className="h-3.5 w-3.5" />
                          {loadingExcel ? "…" : "Importer"}
                        </button>
                      </div>
                    </div>
                  </>
                )}

                {besoinsDetails.length > 0 && (
                  <div className="overflow-hidden rounded-lg border-2 border-slate-200 bg-white shadow-sm">
                    {!loadingDetails &&
                      besoinsDetails.every((b) => (eppBesoinsMap.get(b.id) || []).length === 0) && (
                        <div className="border-b border-amber-200 bg-amber-50 px-4 py-2 text-xs font-medium text-amber-950">
                          Aucune donnée EPP chargée pour ces IEPP (vérifier la consolidation).
                        </div>
                      )}
                    {drenaGroups.map((drena) => {
                      const besoinsDrena = drena.structures.flatMap((s) => s.besoins)
                      const { demandee: dD, approuvee: dA } = sumConsolidatedAndApprovedForIeppList(
                        besoinsDrena,
                        quantitesApprouvees,
                        tauxGlobal
                      )
                      return (
                        <details key={drena.key} className="group border-b border-indigo-100 last:border-b-0 open:bg-indigo-50/30">
                          <summary className="flex cursor-pointer list-none flex-wrap items-center justify-between gap-2 border-l-4 border-indigo-500 bg-indigo-50 px-4 py-3 text-sm font-semibold text-indigo-950 hover:bg-indigo-100/80 [&::-webkit-details-marker]:hidden">
                            <span className="flex items-center gap-2">
                              <span className="rounded bg-indigo-600 px-1.5 py-0.5 text-[10px] font-bold uppercase tracking-wide text-white">
                                DRENA
                              </span>
                              {drena.label}
                            </span>
                            <span className="text-xs font-medium text-indigo-800/80 tabular-nums">
                              {drena.structures.length} IEPP · {dD.toLocaleString()} → {dA.toLocaleString()} man.
                            </span>
                          </summary>
                          <div className="divide-y divide-indigo-100/80 bg-indigo-50/20">
                            {drena.structures.map((st) => {
                              const { demandee: iD, approuvee: iA } = sumConsolidatedAndApprovedForIeppList(
                                st.besoins,
                                quantitesApprouvees,
                                tauxGlobal
                              )
                              const eppUnified = mergeEppBesoinsByAdministrativeStructure(
                                st.besoins.flatMap((b) => eppBesoinsMap.get(b.id) || [])
                              )
                              return (
                                <details key={st.structureKey} className="group open:bg-white">
                                  <summary className="cursor-pointer list-none border-b border-sky-100 border-l-4 border-sky-500 bg-sky-50/90 px-4 py-2.5 pl-5 text-sm text-sky-950 hover:bg-sky-100/90 [&::-webkit-details-marker]:hidden">
                                    <div className="flex flex-wrap items-center justify-between gap-2">
                                      <span className="flex items-center gap-2 font-semibold">
                                        <span className="rounded bg-sky-600 px-1.5 py-0.5 text-[10px] font-bold uppercase tracking-wide text-white">
                                          IEPP
                                        </span>
                                        {st.libelle}
                                      </span>
                                      <span className="text-xs font-medium text-sky-900/75 tabular-nums">
                                        {st.besoins.length} niveau(x)
                                        {eppUnified.length > 0
                                          ? ` · ${eppUnified.length} école(s) EPP`
                                          : ""}{" "}
                                        · {iD.toLocaleString()} → {iA.toLocaleString()} man.
                                      </span>
                                    </div>
                                  </summary>
                                  <div className="divide-y divide-slate-100 bg-white">
                                    {st.besoins.map((besoin) => {
                                      const sortedIeppDetails = sortBesoinDetailsByNiveauThenMatiere(
                                        besoin.besoinDetails
                                      )
                                      return (
                                        <details key={besoin.id} className="group">
                                          <summary className="cursor-pointer list-none border-l-4 border-emerald-400 bg-emerald-50/60 px-4 py-2.5 pl-8 text-sm text-emerald-950 hover:bg-emerald-50 [&::-webkit-details-marker]:hidden">
                                            <div className="flex flex-wrap items-center justify-between gap-2">
                                              <span className="flex flex-wrap items-center gap-2">
                                                <span className="rounded bg-emerald-600 px-1.5 py-0.5 text-[10px] font-bold uppercase tracking-wide text-white">
                                                  Niveau
                                                </span>
                                                <span className="font-semibold">
                                                  {besoin.niveauScolaireLibelle || besoin.niveauScolaireCode || "Niveau"}
                                                </span>
                                                <span className="font-normal text-emerald-800/70">· {besoin.reference}</span>
                                              </span>
                                            </div>
                                          </summary>
                                          <div className="space-y-4 border-b border-emerald-100/80 bg-emerald-50/10 px-4 pb-4 pl-9 last:border-b-0">
                                    {sortedIeppDetails.length > 0 ? (
                                      <div className="overflow-x-auto rounded-lg border border-emerald-200/80 bg-white shadow-sm">
                                        <table className="min-w-full text-sm">
                                          <thead>
                                            <tr className="border-b border-emerald-200 bg-emerald-100/80 text-left text-xs font-semibold uppercase tracking-wide text-emerald-900">
                                              <th className="px-3 py-2">Niveau</th>
                                              <th className="px-3 py-2">Matière</th>
                                              <th className="px-3 py-2 text-right w-24">Consol.</th>
                                              <th className="px-3 py-2 text-right w-28">Approuvé</th>
                                              <th className="px-3 py-2 text-right w-20">Δ</th>
                                            </tr>
                                          </thead>
                                          <tbody className="divide-y divide-emerald-100">
                                            {sortedIeppDetails.map((detail, rowIdx) => {
                                              const quantiteConsolidee = detail.quantiteConsolidee || 0
                                              const quantiteApprouvee = getQuantiteApprouvee(
                                                detail.id,
                                                quantiteConsolidee
                                              )
                                              const ecart = quantiteApprouvee - quantiteConsolidee
                                              const isManual = quantitesApprouvees.has(detail.id)
                                              return (
                                                <tr
                                                  key={detail.id}
                                                  className={
                                                    isManual
                                                      ? "bg-violet-100/70"
                                                      : rowIdx % 2 === 1
                                                        ? "bg-slate-50/80"
                                                        : "bg-white"
                                                  }
                                                >
                                                  <td className="px-3 py-2 text-slate-700 whitespace-nowrap">
                                                    {detail.niveauScolaireLibelle ||
                                                      detail.niveauScolaireCode ||
                                                      "—"}
                                                  </td>
                                                  <td className="px-3 py-2 text-slate-900">
                                                    {detail.matiereLibelle ||
                                                      detail.matiereCode ||
                                                      `Matière ${detail.matiereId}`}
                                                  </td>
                                                  <td className="px-3 py-2 text-right tabular-nums text-slate-600">
                                                    {quantiteConsolidee.toLocaleString()}
                                                  </td>
                                                  <td className="px-3 py-2 text-right">
                                                    <input
                                                      type="number"
                                                      min={0}
                                                      max={quantiteConsolidee}
                                                      value={quantiteApprouvee}
                                                      onChange={(e) => {
                                                        const newValue = parseInt(e.target.value, 10) || 0
                                                        updateQuantiteApprouvee(detail.id, newValue)
                                                      }}
                                                      className="ml-auto block w-full max-w-[7rem] rounded-md border border-emerald-200 bg-white px-2 py-1 text-right text-sm tabular-nums focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-500/30"
                                                    />
                                                  </td>
                                                  <td
                                                    className={`px-3 py-2 text-right text-xs tabular-nums ${
                                                      ecart === 0
                                                        ? "text-gray-400"
                                                        : ecart < 0
                                                          ? "text-red-600"
                                                          : "text-emerald-700"
                                                    }`}
                                                  >
                                                    {ecart === 0 ? "—" : `${ecart > 0 ? "+" : ""}${ecart.toLocaleString()}`}
                                                  </td>
                                                </tr>
                                              )
                                            })}
                                          </tbody>
                                        </table>
                                      </div>
                                    ) : (
                                      <p className="text-xs text-emerald-800/70">Aucune ligne IEPP.</p>
                                    )}
                                  </div>
                                </details>
                              )
                            })}
                                    {eppUnified.length > 0 && (
                                      <div className="border-t-2 border-amber-300 bg-gradient-to-b from-amber-50/90 to-orange-50/40">
                                        <div className="flex flex-wrap items-center gap-2 px-4 py-2.5 pl-6 text-xs font-semibold uppercase tracking-wide text-amber-950">
                                          <span className="rounded bg-amber-600 px-1.5 py-0.5 text-[10px] font-bold text-white">
                                            EPP
                                          </span>
                                          Écoles · saisie manuelle par niveau
                                        </div>
                                        <div className="grid grid-cols-1 gap-3 px-4 pb-4 pl-6 xl:grid-cols-2">
                                          {eppUnified.map((besoinEpp) => {
                                            const eppId = administrativeStructureId(besoinEpp)
                                            const niveauGroups = groupBesoinDetailsByNiveauScolaire(besoinEpp.besoinDetails)
                                            const rowCount = niveauGroups.reduce((n, g) => n + g.rows.length, 0)
                                            if (!eppId || rowCount === 0) return null
                                            return (
                                              <details
                                                key={`epp-${eppId}`}
                                                className="group min-w-0 overflow-hidden rounded-lg border-2 border-amber-200/90 bg-white shadow-sm ring-1 ring-amber-100/80"
                                              >
                                                <summary className="cursor-pointer list-none border-l-4 border-amber-500 bg-amber-50/80 px-3 py-2.5 text-sm font-semibold text-amber-950 hover:bg-amber-100/80 [&::-webkit-details-marker]:hidden">
                                                  <span className="block truncate">
                                                    {besoinEpp.structureAdministrativeLibelle || "EPP"}
                                                  </span>
                                                </summary>
                                                <div className="space-y-3 border-t border-amber-100 bg-amber-50/20 px-3 pb-3 pt-2">
                                                  {niveauGroups.map((g) => (
                                                    <div key={g.key} className="min-w-0">
                                                      <div className="mb-1.5 rounded-sm border border-orange-200/80 bg-orange-50 px-2 py-1 text-[11px] font-bold uppercase tracking-wide text-orange-900">
                                                        {g.label}
                                                      </div>
                                                      <div className="overflow-x-auto rounded-md border border-amber-100 bg-white">
                                                        <table className="w-full min-w-[280px] table-fixed text-xs">
                                                          <colgroup>
                                                            <col className="w-[32%]" />
                                                            <col className="w-[18%]" />
                                                            <col className="w-[25%]" />
                                                            <col className="w-[25%]" />
                                                          </colgroup>
                                                          <thead>
                                                            <tr className="border-b border-amber-100 bg-amber-100/60 text-left text-amber-950">
                                                              <th className="px-2 py-1.5 font-semibold">Matière</th>
                                                              <th className="px-2 py-1.5 text-right font-semibold">Net</th>
                                                              <th className="px-2 py-1.5 text-right font-semibold" colSpan={2}>
                                                                Manuel
                                                              </th>
                                                            </tr>
                                                          </thead>
                                                          <tbody className="divide-y divide-amber-50">
                                                            {g.rows.map((detail, eppRowIdx) => {
                                                              if (!detail.matiereId) return null
                                                              const quantiteNetEpp = detail.quantiteNet || 0
                                                              const nmKey = eppExceptionCompositeKey(
                                                                detail.niveauScolaireId,
                                                                detail.matiereId
                                                              )
                                                              const exception = getExceptionEpp(eppId, nmKey)
                                                              const maxQ = Math.max(quantiteNetEpp, exception ?? 0)
                                                              const touched = exception !== undefined
                                                              return (
                                                                <tr
                                                                  key={detail.id}
                                                                  className={
                                                                    touched
                                                                      ? "bg-violet-100/80"
                                                                      : eppRowIdx % 2 === 1
                                                                        ? "bg-amber-50/40"
                                                                        : undefined
                                                                  }
                                                                >
                                                                  <td className="px-2 py-1.5 text-amber-950">
                                                                    <span className="line-clamp-2">
                                                                      {detail.matiereLibelle || detail.matiereCode}
                                                                    </span>
                                                                  </td>
                                                                  <td className="px-2 py-1.5 text-right tabular-nums text-amber-800/80">
                                                                    {quantiteNetEpp.toLocaleString()}
                                                                  </td>
                                                                  <td className="px-2 py-1.5 text-right" colSpan={2}>
                                                                    <input
                                                                      type="number"
                                                                      min={0}
                                                                      max={maxQ}
                                                                      value={exception !== undefined ? exception : ""}
                                                                      onChange={(e) => {
                                                                        const newValue = parseInt(e.target.value, 10) || 0
                                                                        updateExceptionEpp(eppId, nmKey, newValue)
                                                                      }}
                                                                      placeholder={String(quantiteNetEpp)}
                                                                      className="ml-auto block w-full max-w-[6rem] rounded-md border border-amber-200 bg-white px-1.5 py-1 text-right tabular-nums focus:border-orange-500 focus:outline-none focus:ring-2 focus:ring-orange-400/30"
                                                                    />
                                                                  </td>
                                                                </tr>
                                                              )
                                                            })}
                                                          </tbody>
                                                        </table>
                                                      </div>
                                                    </div>
                                                  ))}
                                                </div>
                                              </details>
                                            )
                                          })}
                                        </div>
                                      </div>
                                    )}
                          </div>
                        </details>
                      )
                    })}
                          </div>
                        </details>
                      )
                    })}
                  </div>
                )}

                {showPreview && previewData && (
                  <div className="rounded-lg border border-blue-200 bg-gradient-to-r from-blue-50 to-indigo-50/80 px-4 py-3 text-sm shadow-sm">
                    <span className="font-semibold text-blue-950">Prévisualisation · </span>
                    <span className="text-blue-900/85 tabular-nums">
                      consolidé {previewData.totalQuantiteConsolidee?.toLocaleString() ?? 0} · approuvé{" "}
                      {previewData.totalQuantiteApprouvee?.toLocaleString() ?? 0}
                      {previewData.tauxApprobationGlobal != null && (
                        <>
                          {" "}
                          · {Math.round(previewData.tauxApprobationGlobal * 100)} %
                        </>
                      )}
                    </span>
                  </div>
                )}
              </div>
            )}
          </div>

          <div className="bg-gray-50 px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse">
            <div className="flex gap-3">
              <button
                type="button"
                onClick={handlePreview}
                disabled={loadingPreview || loadingDetails || eppStillLoading}
                className="inline-flex items-center px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50"
              >
                <EyeIcon className="h-4 w-4 mr-2" />
                Prévisualiser
              </button>
              <button
                type="button"
                onClick={handleApprove}
                disabled={loadingApprove || loadingDetails || eppStillLoading}
                className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50"
              >
                <CheckCircleIcon className="h-4 w-4 mr-2" />
                {loadingApprove ? 'Approbation...' : 'Approuver'}
              </button>
              <button
                type="button"
                onClick={onClose}
                className="inline-flex items-center px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-500"
              >
                Annuler
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>

    <Dialog open={pendingExcelImportWarnings !== null} onOpenChange={onExcelWarningsDialogOpenChange}>
      <DialogContent className="z-[100] max-h-[min(92vh,720px)] max-w-2xl gap-0 overflow-hidden border-slate-300 p-0 shadow-xl sm:max-w-2xl">
        <DialogHeader className="border-b border-amber-300 bg-amber-100 px-6 py-5 text-left">
          <DialogTitle className="text-xl font-semibold tracking-tight text-amber-950">
            Avertissements à l’import Excel
          </DialogTitle>
          <DialogDescription asChild>
            <p className="mt-2 text-[15px] font-normal leading-relaxed text-amber-950">
              Le fichier a été analysé, mais le serveur a corrigé certaines quantités (par exemple ramenées au net EPP
              ou au consolidé IEPP). La quantité approuvée ne peut pas dépasser la quantité demandée (net EPP ou
              consolidé IEPP). Vous pouvez appliquer les valeurs corrigées, ou annuler puis modifier le fichier et
              réimporter.
            </p>
          </DialogDescription>
        </DialogHeader>
        <div className="max-h-[min(50vh,420px)] overflow-y-auto bg-white px-6 py-4">
          <p className="mb-4 text-sm font-medium leading-snug text-slate-800">
            Détail par ligne concernée (le numéro indiqué est la ligne dans la feuille Excel, sous l’en-tête) :
          </p>
          <ul className="space-y-3">
            {(pendingExcelImportWarnings?.warnings ?? []).map((line, i) => (
              <li
                key={i}
                className="flex gap-3 rounded-lg border border-slate-200 bg-slate-50 px-4 py-3.5 text-[15px] leading-relaxed text-gray-900 shadow-sm"
              >
                <span
                  className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-amber-600 text-sm font-bold text-white"
                  aria-hidden
                >
                  {i + 1}
                </span>
                <span className="min-w-0 flex-1 break-words">{line}</span>
              </li>
            ))}
          </ul>
        </div>
        <DialogFooter className="border-t border-slate-200 bg-slate-50 px-6 py-4">
          <button
            type="button"
            onClick={cancelPendingExcelImport}
            className="inline-flex items-center justify-center rounded-md border border-slate-300 bg-white px-4 py-2 text-sm font-medium text-slate-700 shadow-sm hover:bg-slate-50"
          >
            Annuler l’import
          </button>
          <button
            type="button"
            onClick={confirmPendingExcelImport}
            className="inline-flex items-center justify-center rounded-md border border-transparent bg-blue-600 px-4 py-2 text-sm font-medium text-white shadow-sm hover:bg-blue-700"
          >
            Appliquer les quantités corrigées
          </button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
    </>
  )
}

