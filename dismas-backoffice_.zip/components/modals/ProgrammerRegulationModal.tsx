"use client"

import { useState, useEffect } from "react"
import { XCircleIcon } from "@heroicons/react/24/outline"
import { regulationService, type RegulationDto } from "@/lib/services/regulation.service"
import { anneeScolaireService } from "@/lib/services/annee-scolaire.service"
import { useAuth } from "@/app/providers"
import { toast } from "sonner"

interface ProgrammerRegulationModalProps {
  isOpen: boolean
  /** IEPP cible (structure admin). Défaut : structure de l’utilisateur. */
  ieppStructureId?: number
  onClose: () => void
  onSuccess: () => void
}

export default function ProgrammerRegulationModal({
  isOpen,
  ieppStructureId,
  onClose,
  onSuccess,
}: ProgrammerRegulationModalProps) {
  const { user } = useAuth()
  const targetIeppId = ieppStructureId ?? user?.structure?.id
  /** PK `structure_administrative` DRENA (session) — requis pour `programmerRegulationDrena`. */
  const drenaSaPk =
    (user as { structureAdministrativeId?: number } | null | undefined)?.structureAdministrativeId ??
    user?.structure?.id
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [formData, setFormData] = useState({
    dateRecuperation: "",
    tauxRecuperation: 1.0,
    anneeScolaireId: 0,
    commentaire: "",
  })
  /** Année courante uniquement — non modifiable dans ce formulaire */
  const [anneeCouranteInfo, setAnneeCouranteInfo] = useState<{ id: number; libelle: string } | null>(null)

  useEffect(() => {
    if (isOpen) {
      void loadAnneeCourante()
    }
  }, [isOpen])

  const loadAnneeCourante = async () => {
    try {
      const response = await anneeScolaireService.getByCriteria({}, 0, 100)
      if (response.items && Array.isArray(response.items) && response.items.length > 0) {
        const itemsArray = response.items as any[]
        const courante = itemsArray.find((a) => a.estCourante) || itemsArray[0]
        if (courante?.id) {
          const libelle = String(courante.libelle ?? "").trim() || `Année #${courante.id}`
          setAnneeCouranteInfo({ id: courante.id, libelle })
          setFormData((prev) => ({ ...prev, anneeScolaireId: courante.id }))
        } else {
          setAnneeCouranteInfo(null)
          toast.error("Aucune année scolaire valide")
        }
      } else {
        console.warn("Aucune année scolaire trouvée")
        setAnneeCouranteInfo(null)
        toast.error("Aucune année scolaire disponible")
      }
    } catch (error: any) {
      console.error("Erreur lors du chargement de l’année scolaire courante:", error)
      setAnneeCouranteInfo(null)
      toast.error(error?.message || "Erreur lors du chargement de l’année scolaire")
    }
  }

  const roleCode = (user?.role?.code ?? "").trim().toUpperCase()
  const isDaf = roleCode === "DAF"
  const isDrena = roleCode === "DRENA"

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    
    if (isDrena && (drenaSaPk == null || drenaSaPk <= 0)) {
      toast.error("Impossible de déterminer votre structure DRENA (identifiant administratif manquant)")
      return
    }
    if (!isDaf && !isDrena && !user?.structure?.id) {
      toast.error("Impossible de déterminer votre structure")
      return
    }

    if (formData.anneeScolaireId <= 0 || !anneeCouranteInfo) {
      toast.error("Année scolaire courante indisponible. Réessayez après chargement.")
      return
    }

    if (!formData.dateRecuperation) {
      toast.error("Veuillez sélectionner une date de récupération")
      return
    }

    if (formData.tauxRecuperation < 0 || formData.tauxRecuperation > 1) {
      toast.error("Le taux de récupération doit être entre 0% et 100%")
      return
    }

    setIsSubmitting(true)

    try {
      const dateRecup = new Date(formData.dateRecuperation)
      const aujourdhui = new Date()
      aujourdhui.setHours(0, 0, 0, 0)
      dateRecup.setHours(0, 0, 0, 0)

      if (dateRecup < aujourdhui) {
        toast.error("La date de récupération ne peut pas être dans le passé")
        setIsSubmitting(false)
        return
      }

      let response
      if (isDaf) {
        response = await regulationService.programmerRegulationDaf({
          dateRecuperation: formData.dateRecuperation,
          tauxRecuperation: formData.tauxRecuperation,
          anneeScolaireId: formData.anneeScolaireId,
          commentaire: formData.commentaire || undefined,
        })
      } else if (isDrena) {
        response = await regulationService.programmerRegulationDrena({
          drenaId: drenaSaPk as number,
          dateRecuperation: formData.dateRecuperation,
          tauxRecuperation: formData.tauxRecuperation,
          anneeScolaireId: formData.anneeScolaireId,
          commentaire: formData.commentaire || undefined,
        })
      } else {
        response = await regulationService.programmerRegulation({
          ieppId: targetIeppId as number,
          dateRecuperation: formData.dateRecuperation,
          tauxRecuperation: formData.tauxRecuperation,
          anneeScolaireId: formData.anneeScolaireId,
          commentaire: formData.commentaire || undefined,
        })
      }

      if (response.hasError) {
        toast.error(response.status?.message || "Erreur lors de la programmation de la régulation")
      } else {
        const item = Array.isArray(response.items) ? response.items[0] : response.items
        const alertes = item && typeof item === "object" && "alertesPrerequis" in item ? (item as RegulationDto).alertesPrerequis : undefined
        if (alertes && alertes.length > 0) {
          toast.warning(
            `${alertes.length} alerte(s) périmètre (structures sans récupération TERMINEE). La programmation est enregistrée.`,
            { duration: 8000 },
          )
        }
        const notif =
          isDaf
            ? "Régulation nationale programmée. Les DRENA concernés seront notifiés par email."
            : isDrena
              ? "Régulation DRENA programmée. Les IEPP seront notifiés par email."
              : "Régulation programmée avec succès. Les EPP seront notifiés par email."
        toast.success(notif)
        onSuccess()
        onClose()
        // Réinitialiser le formulaire (année toujours = courante)
        setFormData({
          dateRecuperation: "",
          tauxRecuperation: 1.0,
          anneeScolaireId: anneeCouranteInfo?.id ?? 0,
          commentaire: "",
        })
      }
    } catch (error: any) {
      console.error("Erreur lors de la programmation:", error)
      toast.error(error?.message || "Erreur lors de la programmation de la régulation")
    } finally {
      setIsSubmitting(false)
    }
  }

  if (!isOpen) return null

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-content max-w-lg" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold">Programmation de récupération</h3>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600">
            <XCircleIcon className="h-6 w-6" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="form-group">
            <label className="form-label">Année scolaire</label>
            <div
              className="input-field flex items-center justify-between bg-gray-50 text-gray-900 border-gray-200 cursor-default select-none"
              aria-readonly="true"
            >
              <span>
                {anneeCouranteInfo ? (
                  <>
                    <span className="font-medium">{anneeCouranteInfo.libelle}</span>
                    <span className="text-gray-500 font-normal ml-1">(Année courante)</span>
                  </>
                ) : (
                  <span className="text-gray-500">Chargement de l’année scolaire…</span>
                )}
              </span>
            </div>
            <p className="text-xs text-gray-500 mt-1">
              La programmation est enregistrée uniquement pour l’année scolaire en cours.
            </p>
          </div>

          <div className="form-group">
            <label className="form-label">
              Date de Récupération <span className="text-red-500">*</span>
            </label>
            <input
              type="date"
              className="input-field"
              value={formData.dateRecuperation}
              onChange={(e) =>
                setFormData((prev) => ({ ...prev, dateRecuperation: e.target.value }))
              }
              min={new Date().toISOString().split("T")[0]}
              required
            />
            <p className="text-xs text-gray-500 mt-1">
              Date à laquelle les stocks excédentaires seront récupérés automatiquement
            </p>
          </div>

          <div className="form-group">
            <label className="form-label">
              Taux de Récupération <span className="text-red-500">*</span>
            </label>
            <div className="flex items-center space-x-2">
              <input
                type="number"
                className="input-field flex-1"
                min="0"
                max="100"
                step="1"
                value={formData.tauxRecuperation * 100}
                onChange={(e) => {
                  const taux = parseFloat(e.target.value) / 100
                  setFormData((prev) => ({ ...prev, tauxRecuperation: taux }))
                }}
                required
              />
              <span className="text-gray-600">%</span>
            </div>
            <p className="text-xs text-gray-500 mt-1">
              Pourcentage du stock disponible à récupérer (ex: 90% = 0.90)
            </p>
          </div>

          <div className="form-group">
            <label className="form-label">Commentaire (optionnel)</label>
            <textarea
              className="input-field"
              rows={3}
              value={formData.commentaire}
              onChange={(e) =>
                setFormData((prev) => ({ ...prev, commentaire: e.target.value }))
              }
              placeholder="Ajoutez un commentaire pour cette régulation..."
            />
          </div>

          <div className="flex justify-end space-x-3 mt-6">
            <button
              type="button"
              onClick={onClose}
              className="btn-outline"
              disabled={isSubmitting}
            >
              Annuler
            </button>
            <button
              type="submit"
              className="btn-primary"
              disabled={isSubmitting || !anneeCouranteInfo || formData.anneeScolaireId <= 0}
            >
              {isSubmitting ? "Programmation..." : "Programmer la Régulation"}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}

