'use client';

import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Upload, FileSpreadsheet, CheckCircle, AlertCircle, X, Download, Calendar, FileText } from 'lucide-react';
import { toast } from 'sonner';

interface ImportModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function ImportModal({ isOpen, onClose }: ImportModalProps) {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [importStatus, setImportStatus] = useState<'idle' | 'uploading' | 'processing' | 'completed' | 'error'>('idle');
  const [previewData, setPreviewData] = useState<any[]>([]);
  const [anneeScolaire, setAnneeScolaire] = useState('2024');

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setSelectedFile(file);
      simulateFilePreview(file);
    }
  };

  const simulateFilePreview = (file: File) => {
    const mockData = [
      { epp: 'EPP-COC-01', nom_epp: 'EPP Cocody Centre', niveau: 'CP1', manuel: 'Français CP1', quantite_prevue: 120, quantite_distribuee: 0 },
      { epp: 'EPP-COC-01', nom_epp: 'EPP Cocody Centre', niveau: 'CP1', manuel: 'Mathématiques CP1', quantite_prevue: 120, quantite_distribuee: 0 },
      { epp: 'EPP-YOP-02', nom_epp: 'EPP Yopougon Niangon', niveau: 'CP1', manuel: 'Français CP1', quantite_prevue: 95, quantite_distribuee: 0 },
      { epp: 'EPP-YOP-02', nom_epp: 'EPP Yopougon Niangon', niveau: 'CP1', manuel: 'Mathématiques CP1', quantite_prevue: 95, quantite_distribuee: 0 },
      { epp: 'EPP-ABO-03', nom_epp: 'EPP Abobo Gare', niveau: 'CP1', manuel: 'Français CP1', quantite_prevue: 110, quantite_distribuee: 0 },
    ];
    setPreviewData(mockData);
  };

  const handleImport = async () => {
    if (!selectedFile) {
      toast.error('Veuillez sélectionner un fichier');
      return;
    }

    setImportStatus('uploading');
    
    setTimeout(() => {
      setImportStatus('processing');
      
      setTimeout(() => {
        setImportStatus('completed');
        toast.success('Import terminé avec succès ! 150 lignes importées');
        onClose();
      }, 2000);
    }, 1000);
  };

  const getStatusIcon = () => {
    switch (importStatus) {
      case 'completed':
        return <CheckCircle className="h-5 w-5 text-green-500" />;
      case 'error':
        return <AlertCircle className="h-5 w-5 text-red-500" />;
      case 'uploading':
      case 'processing':
        return <div className="h-5 w-5 animate-spin rounded-full border-2 border-orange-500 border-t-transparent" />;
      default:
        return <FileSpreadsheet className="h-5 w-5 text-orange-500" />;
    }
  };

  const getStatusText = () => {
    switch (importStatus) {
      case 'completed':
        return 'Import terminé';
      case 'error':
        return 'Erreur lors de l\'import';
      case 'uploading':
        return 'Upload en cours...';
      case 'processing':
        return 'Traitement en cours...';
      default:
        return 'En attente d\'import';
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-5xl max-h-[90vh] overflow-y-auto bg-gradient-to-br from-white to-orange-50 border-2 border-orange-200">
        <DialogHeader className="space-y-4">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-gradient-to-r from-orange-500 to-green-500 rounded-xl">
              <Upload className="h-6 w-6 text-white" />
            </div>
            <div>
              <DialogTitle className="text-2xl font-bold text-gray-900">
                Import Tableau de Répartition
              </DialogTitle>
              <DialogDescription className="text-gray-600">
                Importez le tableau de répartition existant pour cette année scolaire
              </DialogDescription>
            </div>
          </div>
          
          <div className="flex items-center justify-between">
            <Badge 
              variant="outline" 
              className="flex items-center gap-2 bg-white border-orange-200 text-orange-700"
            >
              {getStatusIcon()}
              {getStatusText()}
            </Badge>
          </div>
        </DialogHeader>

        <div className="space-y-6">
          {/* Section Paramètres */}
          <Card className="border-orange-200 bg-white shadow-lg">
            <CardHeader className="bg-gradient-to-r from-orange-50 to-green-50 rounded-t-lg">
              <CardTitle className="flex items-center gap-2 text-gray-900">
                <Calendar className="h-5 w-5 text-orange-600" />
                Paramètres d'import
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6 p-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="annee" className="text-gray-700 font-medium">
                    Année scolaire
                  </Label>
                  <Select value={anneeScolaire} onValueChange={setAnneeScolaire}>
                    <SelectTrigger className="border-orange-200 focus:border-orange-500 focus:ring-orange-500">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="2024">2024-2025</SelectItem>
                      <SelectItem value="2023">2023-2024</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="file" className="text-gray-700 font-medium">
                  Fichier Excel (.xlsx, .xls)
                </Label>
                <div className="relative">
                  <Input
                    id="file"
                    type="file"
                    accept=".xlsx,.xls"
                    onChange={handleFileSelect}
                    className="cursor-pointer border-orange-200 focus:border-orange-500 focus:ring-orange-500 file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-sm file:font-medium file:bg-orange-50 file:text-orange-700 hover:file:bg-orange-100"
                  />
                </div>
                {selectedFile && (
                  <div className="flex items-center gap-2 text-sm text-green-600 bg-green-50 p-3 rounded-lg">
                    <CheckCircle className="h-4 w-4" />
                    Fichier sélectionné : {selectedFile.name}
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Section Aperçu */}
          {previewData.length > 0 && (
            <Card className="border-green-200 bg-white shadow-lg">
              <CardHeader className="bg-gradient-to-r from-green-50 to-blue-50 rounded-t-lg">
                <CardTitle className="flex items-center gap-2 text-gray-900">
                  <FileText className="h-5 w-5 text-green-600" />
                  Aperçu des données ({previewData.length} lignes)
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6">
                <div className="overflow-x-auto">
                  <table className="w-full text-sm border-collapse">
                    <thead>
                      <tr className="bg-gradient-to-r from-orange-50 to-green-50">
                        <th className="text-left p-3 font-semibold text-gray-700 border-b border-orange-200">EPP</th>
                        <th className="text-left p-3 font-semibold text-gray-700 border-b border-orange-200">Niveau</th>
                        <th className="text-left p-3 font-semibold text-gray-700 border-b border-orange-200">Manuel</th>
                        <th className="text-left p-3 font-semibold text-gray-700 border-b border-orange-200">Effectif de la classe</th>
                        <th className="text-left p-3 font-semibold text-gray-700 border-b border-orange-200">Quantité Distribuée</th>
                      </tr>
                    </thead>
                    <tbody>
                      {previewData.map((row, index) => (
                        <tr key={index} className="border-b border-gray-100 hover:bg-orange-50 transition-colors">
                          <td className="p-3 font-medium text-gray-900">{row.epp}</td>
                          <td className="p-3 text-gray-700">{row.niveau}</td>
                          <td className="p-3 text-gray-700">{row.manuel}</td>
                          <td className="p-3 text-gray-700">{row.quantite_prevue}</td>
                          <td className="p-3 text-gray-700">{row.quantite_distribuee}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Actions */}
          <div className="flex justify-end gap-4 pt-4 border-t border-orange-200">
            <Button 
              variant="outline" 
              onClick={onClose}
              className="border-orange-300 text-orange-700 hover:bg-orange-50"
            >
              <X className="h-4 w-4 mr-2" />
              Annuler
            </Button>
            <Button 
              onClick={handleImport}
              disabled={!selectedFile || importStatus === 'uploading' || importStatus === 'processing'}
              className="bg-gradient-to-r from-orange-600 to-green-600 hover:from-orange-700 hover:to-green-700 text-white shadow-lg"
            >
              <Upload className="h-4 w-4 mr-2" />
              {importStatus === 'uploading' || importStatus === 'processing' ? 'Import en cours...' : 'Importer'}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
} 