'use client';

import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Upload, FileText, CheckCircle, AlertCircle, Users, Package, ClipboardList, Calculator, Shield, X, Truck, FileSpreadsheet } from 'lucide-react';
import { toast } from 'sonner';

interface ConfirmationEPPModalProps {
  isOpen: boolean;
  onClose: () => void;
  niveau: 'EPP' | 'IEPP';
}

export default function ConfirmationEPPModal({ isOpen, onClose, niveau }: ConfirmationEPPModalProps) {
  const [activeTab, setActiveTab] = useState('quantites');
  const [bordereauFile, setBordereauFile] = useState<File | null>(null);
  const [ficheFile, setFicheFile] = useState<File | null>(null);
  const [ficheRepartitionFile, setFicheRepartitionFile] = useState<File | null>(null);
  const [bordereauLivreurFile, setBordereauLivreurFile] = useState<File | null>(null);
  const [uploadStatus, setUploadStatus] = useState<'idle' | 'uploading' | 'completed' | 'error'>('idle');
  const [quantitesRecues, setQuantitesRecues] = useState<any[]>([]);
  const [observations, setObservations] = useState('');

  // Données simulées pour la confirmation des quantités
  const mockData = [
    { epp: 'EPP-COC-01', nom_epp: 'EPP Cocody Centre', niveau: 'CP1', manuel: 'Français CP1', quantite_prevue: 120, quantite_recue: 115 },
    { epp: 'EPP-COC-01', nom_epp: 'EPP Cocody Centre', niveau: 'CP1', manuel: 'Mathématiques CP1', quantite_prevue: 120, quantite_recue: 120 },
    { epp: 'EPP-COC-01', nom_epp: 'EPP Cocody Centre', niveau: 'CP2', manuel: 'Français CP2', quantite_prevue: 110, quantite_recue: 108 },
    { epp: 'EPP-COC-01', nom_epp: 'EPP Cocody Centre', niveau: 'CP2', manuel: 'Mathématiques CP2', quantite_prevue: 110, quantite_recue: 110 },
  ];

  const handleQuantiteChange = (index: number, value: string) => {
    const newQuantites = [...mockData];
    newQuantites[index].quantite_recue = parseInt(value) || 0;
    setQuantitesRecues(newQuantites);
  };

  const handleBordereauUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setBordereauFile(file);
      toast.success('Bordereau de livraison uploadé');
    }
  };

  const handleFicheUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setFicheFile(file);
      toast.success('Fiche de synthèse uploadée');
    }
  };

  const handleFicheRepartitionUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setFicheRepartitionFile(file);
      toast.success('Fiche de répartition uploadée');
    }
  };

  const handleBordereauLivreurUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setBordereauLivreurFile(file);
      toast.success('Bordereau du livreur uploadé');
    }
  };

  const handleValidation = async () => {
    if (!bordereauFile && niveau === 'EPP') {
      toast.error('Veuillez uploader le bordereau de livraison');
      return;
    }

    if (!ficheFile && niveau === 'EPP') {
      toast.error('Veuillez uploader la fiche de synthèse avec émargements');
      return;
    }

    if (niveau === 'IEPP' && !bordereauLivreurFile) {
      toast.error('Veuillez uploader le bordereau de livraison du livreur');
      return;
    }

    setUploadStatus('uploading');
    
    setTimeout(() => {
      setUploadStatus('completed');
      toast.success(`${niveau === 'EPP' ? 'Réception' : 'Validation'} confirmée avec succès !`);
      onClose();
    }, 2000);
  };

  const getStatusIcon = () => {
    switch (uploadStatus) {
      case 'completed':
        return <CheckCircle className="h-5 w-5 text-green-500" />;
      case 'error':
        return <AlertCircle className="h-5 w-5 text-red-500" />;
      case 'uploading':
        return <div className="h-5 w-5 animate-spin rounded-full border-2 border-orange-500 border-t-transparent" />;
      default:
        return <Package className="h-5 w-5 text-orange-500" />;
    }
  };

  const getStatusText = () => {
    switch (uploadStatus) {
      case 'completed':
        return 'Confirmation terminée';
      case 'error':
        return 'Erreur lors de la confirmation';
      case 'uploading':
        return 'Validation en cours...';
      default:
        return 'En attente de confirmation';
    }
  };

  const getNiveauIcon = () => {
    return niveau === 'EPP' ? <Shield className="h-6 w-6 text-white" /> : <Calculator className="h-6 w-6 text-white" />;
  };

  const getNiveauColor = () => {
    return niveau === 'EPP' 
      ? 'from-orange-500 to-green-500' 
      : 'from-green-500 to-blue-500';
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-5xl max-h-[90vh] overflow-y-auto bg-gradient-to-br from-white to-orange-50 border-2 border-orange-200">
        <DialogHeader className="space-y-4">
          <div className="flex items-center gap-3">
            <div className={`p-3 bg-gradient-to-r ${getNiveauColor()} rounded-xl`}>
              {getNiveauIcon()}
            </div>
            <div>
              <DialogTitle className="text-2xl font-bold text-gray-900">
                {niveau === 'EPP' ? 'Confirmation Réception EPP' : 'Validation Distribution IEPP'}
              </DialogTitle>
              <DialogDescription className="text-gray-600">
                {niveau === 'EPP' 
                  ? 'Confirmez les quantités reçues et uploadez les documents de livraison'
                  : 'Validez les distributions des EPP de votre circonscription'
                }
              </DialogDescription>
            </div>
          </div>
          
          <div className="flex items-center justify-between">
            <Badge 
              variant="outline" 
              className="flex items-center gap-2 bg-white border-orange-200 text-orange-700"
            >
              {getStatusIcon()}
              {getStatusText()}
            </Badge>
          </div>
        </DialogHeader>

        <div className="space-y-6">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-2 bg-orange-50 p-1 rounded-lg">
              <TabsTrigger 
                value="quantites" 
                className="data-[state=active]:bg-white data-[state=active]:text-orange-700 data-[state=active]:shadow-sm"
              >
                <Calculator className="h-4 w-4 mr-2" />
                Quantités Reçues
              </TabsTrigger>
              <TabsTrigger 
                value="documents" 
                className="data-[state=active]:bg-white data-[state=active]:text-orange-700 data-[state=active]:shadow-sm"
              >
                <FileText className="h-4 w-4 mr-2" />
                Documents
              </TabsTrigger>
            </TabsList>

            <TabsContent value="quantites" className="space-y-6 mt-6">
              <Card className="border-orange-200 bg-white shadow-lg">
                <CardHeader className="bg-gradient-to-r from-orange-50 to-green-50 rounded-t-lg">
                  <CardTitle className="flex items-center gap-2 text-gray-900">
                    <ClipboardList className="h-5 w-5 text-orange-600" />
                    Confirmation des Quantités Reçues
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-6">
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm border-collapse">
                      <thead>
                        <tr className="bg-gradient-to-r from-orange-50 to-green-50">
                          <th className="text-left p-3 font-semibold text-gray-700 border-b border-orange-200">Niveau</th>
                          <th className="text-left p-3 font-semibold text-gray-700 border-b border-orange-200">Manuel</th>
                          <th className="text-left p-3 font-semibold text-gray-700 border-b border-orange-200">Effectif de la classe</th>
                          <th className="text-left p-3 font-semibold text-gray-700 border-b border-orange-200">Quantité Reçue</th>
                          <th className="text-left p-3 font-semibold text-gray-700 border-b border-orange-200">Écart</th>
                        </tr>
                      </thead>
                      <tbody>
                        {mockData.map((row, index) => {
                          const ecart = row.quantite_recue - row.quantite_prevue;
                          return (
                            <tr key={index} className="border-b border-gray-100 hover:bg-orange-50 transition-colors">
                              <td className="p-3 font-medium text-gray-900">{row.niveau}</td>
                              <td className="p-3 text-gray-700">{row.manuel}</td>
                              <td className="p-3 text-gray-700">{row.quantite_prevue}</td>
                              <td className="p-3">
                                <Input
                                  type="number"
                                  value={row.quantite_recue}
                                  onChange={(e) => handleQuantiteChange(index, e.target.value)}
                                  className="w-20 border-orange-200 focus:border-orange-500 focus:ring-orange-500"
                                />
                              </td>
                              <td className="p-3">
                                <Badge 
                                  variant={ecart < 0 ? "destructive" : ecart > 0 ? "default" : "secondary"}
                                  className={ecart < 0 ? "bg-red-100 text-red-800" : ecart > 0 ? "bg-green-100 text-green-800" : "bg-gray-100 text-gray-800"}
                                >
                                  {ecart > 0 ? '+' : ''}{ecart}
                                </Badge>
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="documents" className="space-y-6 mt-6">
              {niveau === 'EPP' && (
                <>
                  <Card className="border-green-200 bg-white shadow-lg">
                    <CardHeader className="bg-gradient-to-r from-green-50 to-blue-50 rounded-t-lg">
                      <CardTitle className="flex items-center gap-2 text-gray-900">
                        <FileText className="h-5 w-5 text-green-600" />
                        Bordereau de Livraison
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4 p-6">
                      <div className="space-y-2">
                        <Label htmlFor="bordereau" className="text-gray-700 font-medium">
                          Upload bordereau de livraison (PDF, JPG, PNG)
                        </Label>
                        <div className="relative">
                          <Input
                            id="bordereau"
                            type="file"
                            accept=".pdf,.jpg,.jpeg,.png"
                            onChange={handleBordereauUpload}
                            className="cursor-pointer border-green-200 focus:border-green-500 focus:ring-green-500 file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-sm file:font-medium file:bg-green-50 file:text-green-700 hover:file:bg-green-100"
                          />
                        </div>
                        {bordereauFile && (
                          <div className="flex items-center gap-2 text-sm text-green-600 bg-green-50 p-3 rounded-lg">
                            <CheckCircle className="h-4 w-4" />
                            Fichier uploadé : {bordereauFile.name}
                          </div>
                        )}
                      </div>
                    </CardContent>
                  </Card>

                  <Card className="border-blue-200 bg-white shadow-lg">
                    <CardHeader className="bg-gradient-to-r from-blue-50 to-purple-50 rounded-t-lg">
                      <CardTitle className="flex items-center gap-2 text-gray-900">
                        <Users className="h-5 w-5 text-blue-600" />
                        Fiche de Synthèse avec Émargements
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4 p-6">
                      <div className="space-y-2">
                        <Label htmlFor="fiche" className="text-gray-700 font-medium">
                          Upload fiche de synthèse physique (PDF, JPG, PNG)
                        </Label>
                        <div className="relative">
                          <Input
                            id="fiche"
                            type="file"
                            accept=".pdf,.jpg,.jpeg,.png"
                            onChange={handleFicheUpload}
                            className="cursor-pointer border-blue-200 focus:border-blue-500 focus:ring-blue-500 file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-sm file:font-medium file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100"
                          />
                        </div>
                        {ficheFile && (
                          <div className="flex items-center gap-2 text-sm text-blue-600 bg-blue-50 p-3 rounded-lg">
                            <CheckCircle className="h-4 w-4" />
                            Fichier uploadé : {ficheFile.name}
                          </div>
                        )}
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="observations" className="text-gray-700 font-medium">
                          Observations (optionnel)
                        </Label>
                        <Textarea
                          id="observations"
                          placeholder="Ajoutez des observations sur la réception..."
                          value={observations}
                          onChange={(e) => setObservations(e.target.value)}
                          rows={3}
                          className="border-blue-200 focus:border-blue-500 focus:ring-blue-500"
                        />
                      </div>
                    </CardContent>
                  </Card>
                </>
              )}

              {niveau === 'IEPP' && (
                <>
                  <Card className="border-green-200 bg-white shadow-lg">
                    <CardHeader className="bg-gradient-to-r from-green-50 to-blue-50 rounded-t-lg">
                      <CardTitle className="flex items-center gap-2 text-gray-900">
                        <Truck className="h-5 w-5 text-green-600" />
                        Bordereau de Livraison du Livreur
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4 p-6">
                      <div className="space-y-2">
                        <Label htmlFor="bordereau-livreur" className="text-gray-700 font-medium">
                          Upload bordereau de livraison du livreur (PDF, JPG, PNG)
                        </Label>
                        <div className="relative">
                          <Input
                            id="bordereau-livreur"
                            type="file"
                            accept=".pdf,.jpg,.jpeg,.png"
                            onChange={handleBordereauLivreurUpload}
                            className="cursor-pointer border-green-200 focus:border-green-500 focus:ring-green-500 file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-sm file:font-medium file:bg-green-50 file:text-green-700 hover:file:bg-green-100"
                          />
                        </div>
                        {bordereauLivreurFile && (
                          <div className="flex items-center gap-2 text-sm text-green-600 bg-green-50 p-3 rounded-lg">
                            <CheckCircle className="h-4 w-4" />
                            Fichier uploadé : {bordereauLivreurFile.name}
                          </div>
                        )}
                      </div>
                    </CardContent>
                  </Card>

                  <Card className="border-purple-200 bg-white shadow-lg">
                    <CardHeader className="bg-gradient-to-r from-purple-50 to-pink-50 rounded-t-lg">
                      <CardTitle className="flex items-center gap-2 text-gray-900">
                        <FileSpreadsheet className="h-5 w-5 text-purple-600" />
                        Fiche de Répartition (optionnel)
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4 p-6">
                      <div className="space-y-2">
                        <Label htmlFor="fiche-repartition" className="text-gray-700 font-medium">
                          Upload fiche de répartition si disponible (PDF, JPG, PNG, XLSX)
                        </Label>
                        <div className="relative">
                          <Input
                            id="fiche-repartition"
                            type="file"
                            accept=".pdf,.jpg,.jpeg,.png,.xlsx,.xls"
                            onChange={handleFicheRepartitionUpload}
                            className="cursor-pointer border-purple-200 focus:border-purple-500 focus:ring-purple-500 file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-sm file:font-medium file:bg-purple-50 file:text-purple-700 hover:file:bg-purple-100"
                          />
                        </div>
                        {ficheRepartitionFile && (
                          <div className="flex items-center gap-2 text-sm text-purple-600 bg-purple-50 p-3 rounded-lg">
                            <CheckCircle className="h-4 w-4" />
                            Fichier uploadé : {ficheRepartitionFile.name}
                          </div>
                        )}
                      </div>
                      <div className="bg-purple-50 border border-purple-200 rounded-lg p-3">
                        <p className="text-sm text-purple-700">
                          <strong>Note :</strong> Ce document est optionnel. Il permet de documenter la répartition 
                          des manuels entre les EPP de votre circonscription.
                        </p>
                      </div>
                    </CardContent>
                  </Card>

                  <Card className="border-blue-200 bg-white shadow-lg">
                    <CardHeader className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-t-lg">
                      <CardTitle className="flex items-center gap-2 text-gray-900">
                        <Shield className="h-5 w-5 text-blue-600" />
                        Validation IEPP
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="p-6">
                      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                        <p className="text-sm text-blue-800">
                          Validez les confirmations des EPP de votre circonscription. 
                          Les documents uploadés par les EPP seront consolidés automatiquement.
                        </p>
                      </div>
                    </CardContent>
                  </Card>
                </>
              )}
            </TabsContent>
          </Tabs>

          {/* Actions */}
          <div className="flex justify-end gap-4 pt-4 border-t border-orange-200">
            <Button 
              variant="outline" 
              onClick={onClose}
              className="border-orange-300 text-orange-700 hover:bg-orange-50"
            >
              <X className="h-4 w-4 mr-2" />
              Annuler
            </Button>
            <Button 
              onClick={handleValidation}
              disabled={uploadStatus === 'uploading'}
              className="bg-gradient-to-r from-orange-600 to-green-600 hover:from-orange-700 hover:to-green-700 text-white shadow-lg"
            >
              <CheckCircle className="h-4 w-4 mr-2" />
              {niveau === 'EPP' ? 'Confirmer Réception' : 'Valider Distribution'}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
} 