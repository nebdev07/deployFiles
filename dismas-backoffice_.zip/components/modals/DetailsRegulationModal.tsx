"use client"

import { useState, useEffect, useMemo } from "react"
import { XCircleIcon } from "@heroicons/react/24/outline"
import { regulationService, type RegulationDto, type DetailRegulationDto } from "@/lib/services/regulation.service"
import { ParametrageService } from "@/lib/services/parametrage.service"
import { useAuth } from "@/app/providers"
import { toast } from "sonner"

const parametrageService = new ParametrageService()

interface DetailsRegulationModalProps {
  isOpen: boolean
  regulationId: number | null
  onClose: () => void
}

function normalizeType(t?: string | null) {
  return (t ?? "").trim().toUpperCase()
}

/** Bandeau « détails pas encore disponibles » (statut PROGRAMMEE) : libellé selon le lecteur. */
function getPendingRecuperationNotice(roleCode: string | undefined): string {
  const rc = (roleCode ?? "").trim().toUpperCase()
  if (rc === "DRENA") {
    return "La récupération n’a pas encore été exécutée ou validée. Après validation DRENA, les lignes détaillées (quantités par IEPP, matière et niveau) s’afficheront ici."
  }
  if (rc === "DAF") {
    return "La récupération n’a pas encore été exécutée. Après validation DAF, les lignes détaillées (quantités par DRENA, matière et niveau) s’afficheront ici."
  }
  return "La récupération n’a pas encore été exécutée. Après validation IEPP, les lignes détaillées (quantités par EPP, matière et niveau) s’afficheront ici."
}

/**
 * Identifiants extraits des textes historiques (id = clé StructureAdministrative, pas la table epp).
 * Formats : « EPP 17 », « EPP #17 »…
 */
function collectStructureIdsFromObservationText(texts: (string | undefined)[]): number[] {
  const ids = new Set<number>()
  const patterns = [/EPP\s+(\d+)/g, /EPP\s*#\s*(\d+)/gi, /EPP\s*n[°o]\s*(\d+)/gi]
  for (const raw of texts) {
    const text = raw ?? ""
    for (const re of patterns) {
      for (const m of text.matchAll(re)) {
        const n = Number(m[1])
        if (Number.isFinite(n) && n > 0) ids.add(n)
      }
    }
  }
  return [...ids]
}

type ParsedRecupLine = {
  structure: string
  matiere: string
  niveau: string
  fullFallback: string
}

function parseRecuperationLine(obs: string, structureLibById: Record<number, string>): ParsedRecupLine {
  const fullFallback = obs.trim()

  const replaceLegacyEppTokens = (s: string) =>
    s
      .replace(/EPP\s+(\d+)/g, (_, idStr: string) => {
        const id = Number(idStr)
        return structureLibById[id] ?? `Structure #${idStr}`
      })
      .replace(/EPP\s*#\s*(\d+)/gi, (_, idStr: string) => {
        const id = Number(idStr)
        return structureLibById[id] ?? `Structure #${idStr}`
      })

  const matiereNiveau = fullFallback.match(/\(Matière:\s*([^,]+),\s*Niveau:\s*([^)]+)\)\s*$/)
  if (!matiereNiveau) {
    return {
      structure: replaceLegacyEppTokens(fullFallback) || "—",
      matiere: "—",
      niveau: "—",
      fullFallback,
    }
  }

  const matiere = matiereNiveau[1].trim()
  const niveau = matiereNiveau[2].trim()

  let structurePart = fullFallback
    .replace(/\s*\(Matière:\s*[^,]+,\s*Niveau:\s*[^)]+\)\s*$/, "")
    .trim()

  structurePart = structurePart.replace(/^Récupération depuis\s+/i, "").trim()
  structurePart = replaceLegacyEppTokens(structurePart)
  structurePart = structurePart.replace(/^«\s*/, "").replace(/\s*»$/, "").trim()

  return {
    structure: structurePart || "—",
    matiere: matiere || "—",
    niveau: niveau || "—",
    fullFallback,
  }
}

export default function DetailsRegulationModal({
  isOpen,
  regulationId,
  onClose,
}: DetailsRegulationModalProps) {
  const { user } = useAuth()
  const [regulation, setRegulation] = useState<RegulationDto | null>(null)
  const [details, setDetails] = useState<DetailRegulationDto[]>([])
  const [loading, setLoading] = useState(true)
  /** Libellés StructureAdministrative (clé = id structure) */
  const [structureLibelleById, setStructureLibelleById] = useState<Record<number, string>>({})
  const [structureLabelsLoading, setStructureLabelsLoading] = useState(false)
  /** Libellés pour le bandeau « Flux » des redistributions */
  const [fluxLabels, setFluxLabels] = useState<{ source?: string; dest?: string }>({})

  useEffect(() => {
    if (!isOpen) {
      setRegulation(null)
      setDetails([])
      setLoading(false)
      setStructureLibelleById({})
      setFluxLabels({})
      return
    }
    if (!regulationId) return

    let cancelled = false

    const load = async () => {
      setLoading(true)
      try {
        const [regRes, detRes] = await Promise.all([
          regulationService.getDetails(regulationId),
          regulationService.getDetailRegulationLignes(regulationId),
        ])
        if (cancelled) return
        if (regRes.items && regRes.items.length > 0) {
          setRegulation(regRes.items[0])
        } else {
          setRegulation(null)
        }
        setDetails(Array.isArray(detRes.items) ? detRes.items : [])
      } catch (error) {
        console.error("Erreur lors du chargement des détails:", error)
        toast.error("Erreur lors du chargement des détails")
        setRegulation(null)
        setDetails([])
      } finally {
        if (!cancelled) setLoading(false)
      }
    }

    void load()
    return () => {
      cancelled = true
    }
  }, [isOpen, regulationId])

  useEffect(() => {
    if (!isOpen || details.length === 0) {
      setStructureLibelleById({})
      return
    }
    const ids = collectStructureIdsFromObservationText(details.map((d) => d.observations))
    if (ids.length === 0) {
      setStructureLibelleById({})
      return
    }

    let cancelled = false
    setStructureLabelsLoading(true)
    ;(async () => {
      try {
        const pairs = await Promise.all(
          ids.map(async (id) => {
            try {
              const res = await parametrageService.getStructureAdministrativeById(id)
              const st = Array.isArray(res.items) ? res.items[0] : undefined
              const lib = st?.libelle?.trim() || st?.code?.trim()
              return [id, lib && lib.length > 0 ? lib : `Structure #${id}`] as const
            } catch {
              return [id, `Structure #${id}`] as const
            }
          })
        )
        if (!cancelled) {
          setStructureLibelleById(Object.fromEntries(pairs) as Record<number, string>)
        }
      } finally {
        if (!cancelled) setStructureLabelsLoading(false)
      }
    })()

    return () => {
      cancelled = true
    }
  }, [isOpen, details])

  useEffect(() => {
    if (!isOpen || !regulation) {
      setFluxLabels({})
      return
    }
    if (normalizeType(regulation.type) !== "REDISTRIBUTION") {
      setFluxLabels({})
      return
    }
    const sid = regulation.sourceId
    const did = regulation.destinationId
    if (sid == null && did == null) {
      setFluxLabels({})
      return
    }
    let cancelled = false
    ;(async () => {
      try {
        let source: string | undefined
        let dest: string | undefined
        if (sid != null) {
          const r = await parametrageService.getStructureAdministrativeById(sid)
          const s = r.items?.[0]
          source = s?.libelle?.trim() || s?.code?.trim() || `Structure #${sid}`
        }
        if (did != null) {
          const r = await parametrageService.getStructureAdministrativeById(did)
          const s = r.items?.[0]
          dest = s?.libelle?.trim() || s?.code?.trim() || `Structure #${did}`
        }
        if (!cancelled) setFluxLabels({ source, dest })
      } catch {
        if (!cancelled) {
          setFluxLabels({
            source: sid != null ? `Structure #${sid}` : undefined,
            dest: did != null ? `Structure #${did}` : undefined,
          })
        }
      }
    })()
    return () => {
      cancelled = true
    }
  }, [isOpen, regulation])

  const getStatusBadge = (statut?: string) => {
    switch (statut) {
      case "PROGRAMMEE":
        return "badge-warning"
      case "VALIDE":
        return "badge-info"
      case "TERMINEE":
        return "badge-success"
      case "ANNULEE":
        return "badge-error"
      default:
        return "badge-info"
    }
  }

  const dateRecup = regulation?.dateRecuperation
    ? new Date(regulation.dateRecuperation).toLocaleDateString("fr-FR")
    : "Non définie"

  const taux = regulation?.tauxRecuperation != null
    ? `${(regulation.tauxRecuperation * 100).toFixed(0)}%`
    : "100%"

  const typeLabel = (() => {
    const t = normalizeType(regulation?.type)
    if (t === "RECUPERATION") return "Récupération stocks EPP"
    if (t === "REDISTRIBUTION") return "Redistribution IEPP → EPP"
    return regulation?.type ?? "—"
  })()

  const totalQuantite = useMemo(
    () => details.reduce((sum, d) => sum + (d.quantite ?? 0), 0),
    [details]
  )

  const isRecuperation = normalizeType(regulation?.type) === "RECUPERATION"
  const isRedistribution = normalizeType(regulation?.type) === "REDISTRIBUTION"
  const isTerminee = regulation?.statut === "TERMINEE"
  const isProgrammee = regulation?.statut === "PROGRAMMEE"

  if (!isOpen) return null

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div
        className="modal-content !max-w-none w-[min(96vw,1440px)] max-w-[min(96vw,1440px)] mx-3 sm:mx-4 max-h-[92vh] overflow-y-auto rounded-xl shadow-2xl border border-gray-200/90 p-6 sm:p-8"
        style={{ width: "min(96vw, 1440px)", maxWidth: "min(96vw, 1440px)" }}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-lg font-semibold text-gray-900">Détails de la régulation</h3>
            {regulation?.reference && (
              <p className="text-sm text-gray-500 mt-0.5">{regulation.reference}</p>
            )}
          </div>
          <button type="button" onClick={onClose} className="text-gray-400 hover:text-gray-600">
            <XCircleIcon className="h-6 w-6" />
          </button>
        </div>

        {loading ? (
          <div className="text-center py-8">
            <p className="text-gray-600">Chargement...</p>
          </div>
        ) : regulation ? (
          <div className="space-y-5">
            <div className="flex flex-wrap gap-2 items-center">
              <span className="text-xs font-medium text-gray-500 uppercase tracking-wide">Type</span>
              <span className="rounded-full bg-orange-50 text-orange-800 border border-orange-200 px-3 py-1 text-sm font-medium">
                {typeLabel}
              </span>
              <span className={`${getStatusBadge(regulation.statut)} inline-block text-sm px-2 py-0.5 rounded`}>
                {regulation.statut || "N/A"}
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 rounded-lg border border-gray-200 bg-gray-50/80 p-4">
              <div>
                <p className="text-xs font-medium text-gray-500 uppercase">Date de récupération prévue</p>
                <p className="text-sm text-gray-900 mt-0.5">{dateRecup}</p>
              </div>
              <div>
                <p className="text-xs font-medium text-gray-500 uppercase">Taux de récupération</p>
                <p className="text-sm text-gray-900 mt-0.5">{taux}</p>
              </div>
              <div>
                <p className="text-xs font-medium text-gray-500 uppercase">Date de programmation</p>
                <p className="text-sm text-gray-900 mt-0.5">
                  {regulation.dateRegulation
                    ? new Date(regulation.dateRegulation).toLocaleDateString("fr-FR")
                    : "—"}
                </p>
              </div>
              {regulation.dateValidation && (
                <div>
                  <p className="text-xs font-medium text-gray-500 uppercase">Date de validation</p>
                  <p className="text-sm text-gray-900 mt-0.5">
                    {new Date(regulation.dateValidation).toLocaleDateString("fr-FR")}
                  </p>
                </div>
              )}
              {isRedistribution &&
                (regulation.sourceId != null || regulation.destinationId != null) && (
                  <div className="sm:col-span-2">
                    <p className="text-xs font-medium text-gray-500 uppercase">Flux</p>
                    <p className="text-sm text-gray-900 mt-0.5 leading-relaxed">
                      <span className="font-medium text-orange-800">Structure source</span> (IEPP) :{" "}
                      {fluxLabels.source ?? `ID ${regulation.sourceId ?? "—"}`}
                      <span className="mx-2 text-gray-400">→</span>
                      <span className="font-medium text-orange-800">Structure destination</span> (EPP) :{" "}
                      {fluxLabels.dest ?? `ID ${regulation.destinationId ?? "—"}`}
                    </p>
                  </div>
                )}
            </div>

            {regulation.commentaire && (
              <div className="rounded-lg border border-gray-200 p-3 bg-white">
                <p className="text-xs font-medium text-gray-500 uppercase mb-1">Commentaire & trace</p>
                <p className="text-sm text-gray-800 whitespace-pre-wrap">{regulation.commentaire}</p>
              </div>
            )}

            {/* Exécution récupération : lignes issues de detail_regulation */}
            {isRecuperation && (
              <>
                {details.length > 0 && (
                  <div className="rounded-lg border border-orange-200 bg-orange-50/40 p-4">
                    <div className="flex flex-wrap items-baseline justify-between gap-2 mb-3">
                      <h4 className="text-sm font-semibold text-gray-900">
                        Récupération exécutée — par structure, matière et niveau
                      </h4>
                      <p className="text-sm text-gray-700">
                        <span className="font-medium">{details.length}</span> ligne(s) ·{" "}
                        <span className="font-medium">{totalQuantite}</span> unité(s) au total
                        {structureLabelsLoading && (
                          <span className="ml-2 text-xs text-gray-500">(libellés StructureAdministrative…)</span>
                        )}
                      </p>
                    </div>
                    <div className="overflow-x-auto rounded-md border border-gray-200 bg-white">
                      <table className="min-w-[920px] w-full divide-y divide-gray-200 text-sm">
                        <thead className="bg-gray-50">
                          <tr>
                            <th className="px-3 py-2.5 text-left text-xs font-medium text-gray-600 w-10">
                              #
                            </th>
                            <th className="px-3 py-2.5 text-left text-xs font-medium text-gray-600 w-[28%]">
                              Structure administrative
                            </th>
                            <th className="px-3 py-2.5 text-left text-xs font-medium text-gray-600 w-[26%]">
                              Matière
                            </th>
                            <th className="px-3 py-2.5 text-left text-xs font-medium text-gray-600 w-[30%]">
                              Niveau
                            </th>
                            <th className="px-3 py-2.5 text-right text-xs font-medium text-gray-600 w-24">
                              Qté
                            </th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-100">
                          {details.map((detail, index) => {
                            const obs = detail.observations?.trim()
                            const parsed = obs
                              ? parseRecuperationLine(obs, structureLibelleById)
                              : null
                            return (
                              <tr key={detail.id ?? `row-${index}`} className="align-top">
                                <td className="px-3 py-2.5 text-gray-500 tabular-nums">{index + 1}</td>
                                <td className="px-3 py-2.5 text-gray-900 break-words">
                                  {parsed
                                    ? parsed.structure
                                    : detail.manuelId != null
                                      ? `Manuel #${detail.manuelId}`
                                      : "—"}
                                </td>
                                <td className="px-3 py-2.5 text-gray-800 break-words">
                                  {parsed?.matiere ?? "—"}
                                </td>
                                <td className="px-3 py-2.5 text-gray-800 break-words">
                                  {parsed?.niveau ?? "—"}
                                </td>
                                <td className="px-3 py-2.5 text-right font-semibold tabular-nums text-gray-900">
                                  {detail.quantite ?? 0}
                                </td>
                              </tr>
                            )
                          })}
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}

                {details.length === 0 && isTerminee && (
                  <div className="rounded-lg border border-amber-200 bg-amber-50 p-4 text-sm text-amber-900">
                    Aucune ligne de détail n’a été trouvée en base pour cette régulation, alors que le statut
                    est « terminée ». Vérifiez les droits d’accès aux détails ou l’intégrité des données.
                  </div>
                )}

                {details.length === 0 && isProgrammee && (
                  <div className="rounded-lg border border-blue-200 bg-blue-50 p-4 text-sm text-blue-900">
                    {getPendingRecuperationNotice(user?.role?.code)}
                  </div>
                )}
              </>
            )}

            {isRedistribution && (
              <div className="rounded-lg border border-gray-200 bg-slate-50 p-4 text-sm text-gray-700">
                Cette opération est une <strong>redistribution</strong> de stock. Le détail des mouvements est
                enregistré côté mouvements de stock ; il n’y a pas de lignes « récupération EPP » de ce type
                pour cette fiche.
              </div>
            )}
          </div>
        ) : (
          <div className="text-center py-8">
            <p className="text-gray-600">Régulation non trouvée</p>
          </div>
        )}

        <div className="flex justify-end mt-6 pt-4 border-t border-gray-100">
          <button type="button" onClick={onClose} className="btn-outline">
            Fermer
          </button>
        </div>
      </div>
    </div>
  )
}
