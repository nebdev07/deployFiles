"use client"

import { useEffect, useState } from "react"
import { XCircleIcon } from "@heroicons/react/24/outline"
import { regulationService } from "@/lib/services/regulation.service"
import { structuresService, type Iepp } from "@/lib/services/structures.service"
import { matiereService } from "@/lib/services/matiere.service"
import { niveauScolaireService } from "@/lib/services/niveau-scolaire.service"
import { mouvementService } from "@/lib/services/mouvement.service"
import { toast } from "sonner"

export type HubRegulationScope = "DRENA_IEPP" | "DAF_DRENA"

interface RedistribuerHubModalProps {
  isOpen: boolean
  onClose: () => void
  onSuccess: () => void
  scope: HubRegulationScope
  /** Stock hub DRENA (sortie) — requis pour DRENA_IEPP */
  drenaHubId?: number
  /** Stock hub DAF (sortie) — requis pour DAF_DRENA */
  dafHubId?: number
  /** DRENA destinataire — requis pour DAF_DRENA */
  drenaDestinationId?: number
  anneeScolaireId: number
}

type IeppOption = { ieppId: number; ieppCode?: string; ieppLibelle?: string }

export default function RedistribuerHubModal({
  isOpen,
  onClose,
  onSuccess,
  scope,
  drenaHubId,
  dafHubId,
  drenaDestinationId,
  anneeScolaireId,
}: RedistribuerHubModalProps) {
  const [ieppOptions, setIeppOptions] = useState<IeppOption[]>([])
  const [selectedIeppId, setSelectedIeppId] = useState<number | "">("")
  const [matiereId, setMatiereId] = useState<number | "">("")
  const [niveauId, setNiveauId] = useState<number | "">("")
  const [quantite, setQuantite] = useState(1)
  const [commentaire, setCommentaire] = useState("")
  const [matieres, setMatieres] = useState<{ id: number; libelle?: string; code?: string }[]>([])
  const [niveaux, setNiveaux] = useState<{ id: number; libelle?: string; code?: string }[]>([])
  const [stockDispoHub, setStockDispoHub] = useState<number | null>(null)
  const [loading, setLoading] = useState(false)
  const [loadingIepp, setLoadingIepp] = useState(false)

  const hubIdForStock = scope === "DAF_DRENA" ? dafHubId : drenaHubId

  useEffect(() => {
    if (!isOpen) return
    ;(async () => {
      try {
        const [mr, nr] = await Promise.all([
          matiereService.getMatieres({}),
          niveauScolaireService.getNiveauxScolaires({}),
        ])
        if (mr.items)
          setMatieres(mr.items as unknown as { id: number; libelle?: string; code?: string }[])
        if (nr.items)
          setNiveaux(nr.items as unknown as { id: number; libelle?: string; code?: string }[])
      } catch {
        toast.error("Erreur chargement matières / niveaux")
      }
    })()
  }, [isOpen])

  useEffect(() => {
    if (!isOpen || scope !== "DRENA_IEPP" || !drenaHubId || anneeScolaireId <= 0) {
      setIeppOptions([])
      return
    }
    let cancelled = false
    setLoadingIepp(true)
    /** Liste complète des IEPP rattachés à la DRENA (pas seulement ceux avec EPP déficitaires). */
    structuresService
      .getIeppsByDrena(drenaHubId)
      .then((res) => {
        if (cancelled) return
        const raw = (res.items ?? []) as unknown
        const list: Iepp[] =
          Array.isArray(raw) && raw.length > 0 && Array.isArray((raw as Iepp[][])[0])
            ? (raw as Iepp[][]).flat()
            : (raw as Iepp[])
        const opts: IeppOption[] = list.map((x) => ({
          ieppId: x.id,
          ieppCode: x.code,
          ieppLibelle: x.libelle,
        }))
        setIeppOptions(opts)
      })
      .catch(() => {
        if (!cancelled) setIeppOptions([])
      })
      .finally(() => {
        if (!cancelled) setLoadingIepp(false)
      })
    return () => {
      cancelled = true
    }
  }, [isOpen, scope, drenaHubId, anneeScolaireId])

  useEffect(() => {
    if (!isOpen || !hubIdForStock || anneeScolaireId <= 0 || matiereId === "" || niveauId === "") {
      setStockDispoHub(null)
      return
    }
    let cancelled = false
    mouvementService
      .getStocksByStructureAndAnnee(hubIdForStock, anneeScolaireId)
      .then((res) => {
        if (cancelled || !res.success || !res.data || !Array.isArray(res.data)) return
        const mid = Number(matiereId)
        const nid = Number(niveauId)
        let sum = 0
        for (const row of res.data as { matiereId?: number; niveauId?: number; quantiteDisponible?: number }[]) {
          if (Number(row.matiereId) === mid && Number(row.niveauId) === nid) {
            sum += Number(row.quantiteDisponible ?? 0)
          }
        }
        setStockDispoHub(sum)
      })
      .catch(() => {
        if (!cancelled) setStockDispoHub(null)
      })
    return () => {
      cancelled = true
    }
  }, [isOpen, hubIdForStock, anneeScolaireId, matiereId, niveauId])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (matiereId === "" || niveauId === "" || quantite <= 0) {
      toast.error("Matière, niveau et quantité valides requis")
      return
    }
    setLoading(true)
    try {
      if (scope === "DRENA_IEPP") {
        if (!drenaHubId || selectedIeppId === "") {
          toast.error("DRENA et IEPP destinataire requis")
          return
        }
        const res = await regulationService.redistribuerDrenaIepp({
          drenaId: drenaHubId,
          ieppId: Number(selectedIeppId),
          matiereId: Number(matiereId),
          niveauId: Number(niveauId),
          quantite,
          anneeScolaireId,
          commentaire: commentaire || undefined,
        })
        if (res.hasError) {
          toast.error((res.status as { message?: string })?.message || "Erreur redistribution")
          return
        }
        toast.success("Redistribution DRENA → IEPP enregistrée")
      } else {
        if (!dafHubId || !drenaDestinationId) {
          toast.error("DAF et DRENA destinataire requis")
          return
        }
        const res = await regulationService.redistribuerDafDrena({
          dafId: dafHubId,
          drenaId: drenaDestinationId,
          matiereId: Number(matiereId),
          niveauId: Number(niveauId),
          quantite,
          anneeScolaireId,
          commentaire: commentaire || undefined,
        })
        if (res.hasError) {
          toast.error((res.status as { message?: string })?.message || "Erreur redistribution")
          return
        }
        toast.success("Redistribution DAF → DRENA enregistrée")
      }
      onSuccess()
      onClose()
    } catch (err: unknown) {
      toast.error(err instanceof Error ? err.message : "Erreur")
    } finally {
      setLoading(false)
    }
  }

  if (!isOpen) return null

  const title = scope === "DRENA_IEPP" ? "Redistribution DRENA → IEPP" : "Redistribution DAF → DRENA"

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4">
      <div className="bg-white rounded-lg shadow-xl max-w-lg w-full max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between border-b px-4 py-3">
          <h2 className="text-lg font-semibold text-gray-900">{title}</h2>
          <button type="button" onClick={onClose} className="text-gray-500 hover:text-gray-700">
            <XCircleIcon className="h-6 w-6" />
          </button>
        </div>
        <form onSubmit={handleSubmit} className="p-4 space-y-4">
          <p className="text-sm text-gray-600">
            Transfert depuis le stock du hub ({scope === "DRENA_IEPP" ? "DRENA" : "DAF"}) vers{" "}
            {scope === "DRENA_IEPP" ? "l’IEPP sélectionné" : "la DRENA sélectionnée"}.
          </p>

          {scope === "DRENA_IEPP" && (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">IEPP destinataire</label>
              <select
                value={selectedIeppId}
                onChange={(e) => setSelectedIeppId(e.target.value ? Number(e.target.value) : "")}
                className="w-full rounded border border-gray-300 px-3 py-2 text-sm"
                required
                disabled={loadingIepp}
              >
                <option value="">{loadingIepp ? "Chargement…" : "— Choisir —"}</option>
                {ieppOptions.map((o) => (
                  <option key={o.ieppId} value={o.ieppId}>
                    {o.ieppLibelle || o.ieppCode || `IEPP ${o.ieppId}`}
                  </option>
                ))}
              </select>
            </div>
          )}

          {scope === "DAF_DRENA" && drenaDestinationId != null && (
            <p className="text-sm text-gray-700">
              DRENA destinataire : <span className="font-medium">#{drenaDestinationId}</span>
            </p>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Matière</label>
              <select
                value={matiereId}
                onChange={(e) => setMatiereId(e.target.value ? Number(e.target.value) : "")}
                className="w-full rounded border border-gray-300 px-3 py-2 text-sm"
                required
              >
                <option value="">—</option>
                {matieres.map((m) => (
                  <option key={m.id} value={m.id}>
                    {m.libelle || m.code || m.id}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Niveau</label>
              <select
                value={niveauId}
                onChange={(e) => setNiveauId(e.target.value ? Number(e.target.value) : "")}
                className="w-full rounded border border-gray-300 px-3 py-2 text-sm"
                required
              >
                <option value="">—</option>
                {niveaux.map((n) => (
                  <option key={n.id} value={n.id}>
                    {n.libelle || n.code || n.id}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {stockDispoHub != null && (
            <p className="text-sm text-violet-800">
              Stock disponible au hub (indicatif) : <strong>{stockDispoHub}</strong>
            </p>
          )}

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Quantité</label>
            <input
              type="number"
              min={1}
              value={quantite}
              onChange={(e) => setQuantite(Math.max(1, Number(e.target.value) || 1))}
              className="w-full rounded border border-gray-300 px-3 py-2 text-sm"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Commentaire (optionnel)</label>
            <textarea
              value={commentaire}
              onChange={(e) => setCommentaire(e.target.value)}
              className="w-full rounded border border-gray-300 px-3 py-2 text-sm"
              rows={2}
            />
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button type="button" onClick={onClose} className="px-4 py-2 text-sm border rounded border-gray-300">
              Annuler
            </button>
            <button
              type="submit"
              disabled={loading}
              className="px-4 py-2 text-sm rounded bg-orange-600 text-white hover:bg-orange-700 disabled:opacity-50"
            >
              {loading ? "Envoi…" : "Valider la redistribution"}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}
