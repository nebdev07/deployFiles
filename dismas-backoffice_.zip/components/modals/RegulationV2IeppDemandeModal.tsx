"use client"

import { useCallback, useEffect, useMemo, useState } from "react"
import { XMarkIcon, PlusIcon, TrashIcon } from "@heroicons/react/24/outline"
import { regulationV2Service } from "@/lib/services/regulation-v2.service"
import { regulationService } from "@/lib/services/regulation.service"
import { toast } from "sonner"

export type RegulationV2IeppDemandeModalProps = {
  isOpen: boolean
  ieppId: number
  anneeScolaireId: number
  onClose: () => void
  onSuccess: () => void
}

type AggRow = {
  matiereId: number
  matiereLibelle: string
  niveauId: number
  niveauLibelle: string
  deficitTotal: number
  repartitionParEpp: Array<{ eppId: number; eppLibelle: string; deficit: number }>
}

type ExcedentOption = {
  key: string
  structureSourceId: number
  matiereId: number
  niveauId: number
  label: string
  excedent: number
}

type SourceLineDraft = {
  key: string
  excedentKey: string
  structureDestId: number
  quantite: number
}

function parseAggRows(items: unknown[]): AggRow[] {
  const out: AggRow[] = []
  for (const raw of items) {
    if (raw == null || typeof raw !== "object") continue
    const r = raw as Record<string, unknown>
    const matiereId = Number(r.matiereId ?? r.matiere_id)
    const niveauId = Number(r.niveauId ?? r.niveau_id)
    if (!Number.isFinite(matiereId) || !Number.isFinite(niveauId)) continue
    const repRaw = r.repartitionParEpp ?? r.repartition_par_epp
    const repartitionParEpp = Array.isArray(repRaw)
      ? repRaw.map((x) => {
          const o = x as Record<string, unknown>
          return {
            eppId: Number(o.eppId ?? o.epp_id),
            eppLibelle: String(o.eppLibelle ?? o.epp_libelle ?? ""),
            deficit: Number(o.deficit ?? 0) || 0,
          }
        })
      : []
    out.push({
      matiereId,
      matiereLibelle: String(r.matiereLibelle ?? r.matiere_libelle ?? ""),
      niveauId,
      niveauLibelle: String(r.niveauLibelle ?? r.niveau_libelle ?? ""),
      deficitTotal: Number(r.deficitTotal ?? r.deficit_total ?? 0) || 0,
      repartitionParEpp,
    })
  }
  return out
}

function buildExcedentOptions(eppRows: unknown[]): ExcedentOption[] {
  const opts: ExcedentOption[] = []
  for (const raw of eppRows) {
    if (raw == null || typeof raw !== "object") continue
    const epp = raw as Record<string, unknown>
    const eppId = Number(epp.eppId ?? epp.epp_id)
    const code = String(epp.eppCode ?? epp.epp_code ?? "")
    const lib = String(epp.eppLibelle ?? epp.epp_libelle ?? "")
    const combs = epp.combinaisonsExcedentaires ?? epp.combinaisons_excedentaires
    if (!Array.isArray(combs) || !Number.isFinite(eppId)) continue
    for (const c of combs) {
      if (c == null || typeof c !== "object") continue
      const o = c as Record<string, unknown>
      const matiereId = Number(o.matiereId ?? o.matiere_id)
      const niveauId = Number(o.niveauId ?? o.niveau_id)
      const excedent = Number(o.excedent ?? 0) || 0
      if (!Number.isFinite(matiereId) || !Number.isFinite(niveauId) || excedent <= 0) continue
      const matiereLib = String(o.matiereLibelle ?? o.matiere_libelle ?? "")
      const niveauLib = String(o.niveauLibelle ?? o.niveau_libelle ?? "")
      opts.push({
        key: `${eppId}-${matiereId}-${niveauId}`,
        structureSourceId: eppId,
        matiereId,
        niveauId,
        label: `${[code, lib].filter(Boolean).join(" — ") || "EPP source"} · ${matiereLib} / ${niveauLib} (excédent ${excedent})`,
        excedent,
      })
    }
  }
  return opts
}

function newLineKey() {
  return `l-${Date.now()}-${Math.random().toString(36).slice(2, 9)}`
}

export default function RegulationV2IeppDemandeModal({
  isOpen,
  ieppId,
  anneeScolaireId,
  onClose,
  onSuccess,
}: RegulationV2IeppDemandeModalProps) {
  const [loading, setLoading] = useState(false)
  const [submitting, setSubmitting] = useState(false)
  const [commentaire, setCommentaire] = useState("")
  const [agregats, setAgregats] = useState<AggRow[]>([])
  const [excedentOptions, setExcedentOptions] = useState<ExcedentOption[]>([])
  const [lines, setLines] = useState<SourceLineDraft[]>([])

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const [aggRes, excRes] = await Promise.all([
        regulationV2Service.getAgregatDeficitsIepp(ieppId, anneeScolaireId),
        regulationService.getEppExcedentaires(ieppId, anneeScolaireId),
      ])
      if (aggRes.hasError) {
        toast.error(aggRes.status?.message || "Erreur agrégat déficits")
        setAgregats([])
      } else {
        setAgregats(parseAggRows((aggRes.items ?? []) as unknown[]))
      }
      if (excRes.hasError) {
        toast.error(excRes.status?.message || "Erreur EPP excédentaires")
        setExcedentOptions([])
      } else {
        setExcedentOptions(buildExcedentOptions((excRes.items ?? []) as unknown[]))
      }
    } catch (e: unknown) {
      console.error(e)
      toast.error("Erreur de chargement des données")
    } finally {
      setLoading(false)
    }
  }, [ieppId, anneeScolaireId])

  useEffect(() => {
    if (!isOpen) return
    setCommentaire("")
    setLines([])
    void load()
  }, [isOpen, load])

  const aggByKey = useMemo(() => {
    const m = new Map<string, AggRow>()
    for (const a of agregats) {
      m.set(`${a.matiereId}-${a.niveauId}`, a)
    }
    return m
  }, [agregats])

  const addLine = () => {
    if (excedentOptions.length === 0) return
    const firstOpt = excedentOptions[0]
    const agg = aggByKey.get(`${firstOpt.matiereId}-${firstOpt.niveauId}`)
    const firstDest = agg?.repartitionParEpp[0]?.eppId ?? 0
    setLines((prev) => [
      ...prev,
      {
        key: newLineKey(),
        excedentKey: firstOpt.key,
        structureDestId: firstDest,
        quantite: 1,
      },
    ])
  }

  const removeLine = (key: string) => setLines((prev) => prev.filter((l) => l.key !== key))

  const updateLine = (key: string, patch: Partial<SourceLineDraft>) => {
    setLines((prev) =>
      prev.map((l) => {
        if (l.key !== key) return l
        const next = { ...l, ...patch }
        if (patch.excedentKey != null) {
          const opt = excedentOptions.find((o) => o.key === patch.excedentKey)
          const agg = opt ? aggByKey.get(`${opt.matiereId}-${opt.niveauId}`) : undefined
          const d0 = agg?.repartitionParEpp[0]?.eppId ?? 0
          next.structureDestId = d0
        }
        return next
      })
    )
  }

  const handleSubmit = async () => {
    if (lines.length === 0) {
      toast.error("Ajoutez au moins une ligne de transfert")
      return
    }
    const sources: Array<{
      structureSourceId: number
      structureDestId: number
      matiereId: number
      niveauId: number
      quantite: number
    }> = []
    for (const line of lines) {
      const opt = excedentOptions.find((o) => o.key === line.excedentKey)
      if (!opt || line.structureDestId <= 0 || line.quantite <= 0) {
        toast.error("Chaque ligne doit avoir une source, une destination EPP et une quantité valide")
        return
      }
      if (line.quantite > opt.excedent) {
        toast.error(`Quantité trop élevée pour la ligne « ${opt.label} » (max ${opt.excedent})`)
        return
      }
      sources.push({
        structureSourceId: opt.structureSourceId,
        structureDestId: line.structureDestId,
        matiereId: opt.matiereId,
        niveauId: opt.niveauId,
        quantite: line.quantite,
      })
    }
    setSubmitting(true)
    try {
      const res = await regulationV2Service.creerDemandeEpp({
        ieppId,
        anneeScolaireId,
        commentaire: commentaire.trim() || undefined,
        sources,
      })
      if (res.hasError) {
        toast.error(res.status?.message || "Création refusée")
        return
      }
      const created = res.items?.[0]
      const id = created?.id
      toast.success(id != null ? `Demande créée (n° ${id}). Accords EPP sources requis.` : "Demande créée.")
      onSuccess()
      onClose()
    } catch (e: unknown) {
      console.error(e)
      toast.error("Erreur lors de l’envoi")
    } finally {
      setSubmitting(false)
    }
  }

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40">
      <div className="bg-white rounded-xl shadow-xl max-w-4xl w-full max-h-[90vh] overflow-hidden flex flex-col">
        <div className="flex items-center justify-between border-b px-4 py-3">
          <h2 className="text-lg font-semibold text-gray-900">Demande de régulation (multi-EPP)</h2>
          <button type="button" onClick={onClose} className="p-2 rounded-lg hover:bg-gray-100 text-gray-600">
            <XMarkIcon className="h-5 w-5" />
          </button>
        </div>

        <div className="overflow-y-auto flex-1 px-4 py-3 space-y-4 text-sm">
          {loading ? (
            <p className="text-gray-600">Chargement des agrégats et des excédents…</p>
          ) : (
            <>
              <p className="text-gray-600">
                Déficits agrégés par matière / niveau (répartition par EPP). Ajoutez une ou plusieurs lignes : EPP
                source (excédent), quantité, EPP déficitaire destinataire. Chaque structure source devra accepter ou
                refuser sa ligne avant exécution par l’IEPP.
              </p>

              {agregats.length === 0 ? (
                <p className="text-amber-800 bg-amber-50 rounded-lg px-3 py-2">Aucun déficit agrégé pour cette année.</p>
              ) : (
                <div className="border rounded-lg overflow-hidden">
                  <table className="min-w-full text-xs">
                    <thead className="bg-gray-50 text-gray-700">
                      <tr>
                        <th className="text-left px-2 py-1.5">Matière / niveau</th>
                        <th className="text-right px-2 py-1.5">Déficit total</th>
                        <th className="text-left px-2 py-1.5">Répartition EPP</th>
                      </tr>
                    </thead>
                    <tbody>
                      {agregats.map((a) => (
                        <tr key={`${a.matiereId}-${a.niveauId}`} className="border-t">
                          <td className="px-2 py-1.5">
                            {a.matiereLibelle} — {a.niveauLibelle}
                          </td>
                          <td className="px-2 py-1.5 text-right font-medium text-red-700">{a.deficitTotal}</td>
                          <td className="px-2 py-1.5 text-gray-700">
                            {(a.repartitionParEpp ?? [])
                              .map((r) => `${r.eppLibelle?.trim() || "EPP déficitaire"} (${r.deficit})`)
                              .join(" · ") || "—"}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}

              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="font-medium text-gray-800">Lignes de transfert</span>
                  <button
                    type="button"
                    onClick={addLine}
                    disabled={excedentOptions.length === 0}
                    className="inline-flex items-center gap-1 text-sm text-orange-700 font-medium disabled:opacity-40"
                  >
                    <PlusIcon className="h-4 w-4" />
                    Ajouter une ligne
                  </button>
                </div>
                {excedentOptions.length === 0 ? (
                  <p className="text-gray-500">Aucune combinaison excédentaire disponible pour constituer des sources.</p>
                ) : lines.length === 0 ? (
                  <p className="text-gray-500">Cliquez sur « Ajouter une ligne » pour commencer.</p>
                ) : (
                  <div className="space-y-2">
                    {lines.map((line) => {
                      const opt = excedentOptions.find((o) => o.key === line.excedentKey)
                      const agg = opt ? aggByKey.get(`${opt.matiereId}-${opt.niveauId}`) : undefined
                      const dests = agg?.repartitionParEpp ?? []
                      return (
                        <div key={line.key} className="flex flex-wrap gap-2 items-end border rounded-lg p-2 bg-gray-50">
                          <div className="flex-1 min-w-[220px]">
                            <label className="block text-xs text-gray-500 mb-0.5">Source (excédent)</label>
                            <select
                              className="w-full border rounded px-2 py-1.5 text-sm"
                              value={line.excedentKey}
                              onChange={(e) => updateLine(line.key, { excedentKey: e.target.value })}
                            >
                              {excedentOptions.map((o) => (
                                <option key={o.key} value={o.key}>
                                  {o.label}
                                </option>
                              ))}
                            </select>
                          </div>
                          <div className="w-28">
                            <label className="block text-xs text-gray-500 mb-0.5">Qté</label>
                            <input
                              type="number"
                              min={1}
                              max={opt?.excedent ?? 1}
                              className="w-full border rounded px-2 py-1.5 text-sm"
                              value={line.quantite}
                              onChange={(e) => updateLine(line.key, { quantite: Math.max(1, Number(e.target.value) || 0) })}
                            />
                          </div>
                          <div className="flex-1 min-w-[180px]">
                            <label className="block text-xs text-gray-500 mb-0.5">EPP déficitaire</label>
                            <select
                              className="w-full border rounded px-2 py-1.5 text-sm"
                              value={line.structureDestId || ""}
                              onChange={(e) => updateLine(line.key, { structureDestId: Number(e.target.value) })}
                              disabled={dests.length === 0}
                            >
                              {dests.length === 0 ? (
                                <option value="">— Pas de déficit pour cette matière/niveau —</option>
                              ) : (
                                dests.map((d) => (
                                  <option key={d.eppId} value={d.eppId}>
                                    {(d.eppLibelle?.trim() || "EPP déficitaire") + ` (déficit ${d.deficit})`}
                                  </option>
                                ))
                              )}
                            </select>
                          </div>
                          <button
                            type="button"
                            onClick={() => removeLine(line.key)}
                            className="p-2 text-red-600 hover:bg-red-50 rounded"
                            title="Retirer la ligne"
                          >
                            <TrashIcon className="h-4 w-4" />
                          </button>
                        </div>
                      )
                    })}
                  </div>
                )}
              </div>

              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">Commentaire (optionnel)</label>
                <textarea
                  className="w-full border rounded-lg px-3 py-2 text-sm"
                  rows={2}
                  value={commentaire}
                  onChange={(e) => setCommentaire(e.target.value)}
                />
              </div>
            </>
          )}
        </div>

        <div className="border-t px-4 py-3 flex justify-end gap-2 bg-gray-50">
          <button type="button" onClick={onClose} className="px-4 py-2 text-sm rounded-lg border border-gray-300">
            Annuler
          </button>
          <button
            type="button"
            disabled={submitting || loading || lines.length === 0}
            onClick={() => void handleSubmit()}
            className="px-4 py-2 text-sm rounded-lg bg-orange-600 text-white font-medium disabled:opacity-50"
          >
            {submitting ? "Envoi…" : "Créer la demande"}
          </button>
        </div>
      </div>
    </div>
  )
}
