"use client"

import { useState, useEffect, useMemo, useCallback, useRef } from "react"
import { XCircleIcon, CheckCircleIcon, ExclamationTriangleIcon } from "@heroicons/react/24/outline"
import { receptionService } from "@/lib/services/reception.service"
import { mouvementService, StockDisponibleData } from "@/lib/services/mouvement.service"
import { niveauScolaireService } from "@/lib/services/niveau-scolaire.service"
import { useAuth } from "@/app/providers"
import { toast } from "sonner"

interface MatiereQuantite {
  id: number
  matiereId?: number // ID de la matière
  matiereLibelle: string
  matiereCode: string
  niveauScolaireLibelle: string
  niveauScolaireCode?: string // Code du niveau (CP1, CP2, etc.)
  niveauScolaireId?: number // ID du niveau scolaire
  quantiteRecue: number
  quantitePrevue: number
  ecart: number
  stockIEPPDisponible?: number
}

interface ReceptionEPP {
  id: number
  reference?: string
  typeMouvement: string
  numeroBordereau: string
  dateMouvement: string
  observation?: string
  statut: string
  structure?: {
    id: number
    libelle: string
    code: string
  }
  structureLibelle?: string
  structureType?: string
  matiereQuantites?: MatiereQuantite[]
  catalogueMouvements?: any[]
}

interface ValidationIEPPModalProps {
  reception: ReceptionEPP
  onClose: () => void
  onValidate: () => void
  onReject?: () => void
}

export default function ValidationIEPPModal({ reception, onClose, onValidate, onReject }: ValidationIEPPModalProps) {
  const { user } = useAuth() // ✅ Récupérer l'utilisateur connecté (IEPP)
  const [isValidating, setIsValidating] = useState(false)
  const [isRejecting, setIsRejecting] = useState(false)
  const [observations, setObservations] = useState("")
  // ✅ SIMPLIFICATION : Stocker directement les objets StockDisponibleData complets pour accéder à quantiteDisponible directement
  const [stockDetails, setStockDetails] = useState<Map<string, StockDisponibleData>>(new Map())
  const [loadingStock, setLoadingStock] = useState(true)
  const niveauxMapRef = useRef<Map<string, number>>(new Map()) // Cache code → ID (ref pour éviter dépendances)
  // ✅ CORRECTION : Mapping matiereId → niveauId pour réutiliser le niveauId correct lors du rendu
  const matiereNiveauMapRef = useRef<Map<number, number>>(new Map()) // Cache matiereId → niveauId

  /**
   * Récupère toutes les matières de la réception (depuis matiereQuantites ou catalogues)
   * Fonction réutilisable mémorisée pour éviter les recalculs
   */
  const getAllMatieres = useCallback((): MatiereQuantite[] => {
    if (reception.matiereQuantites && reception.matiereQuantites.length > 0) {
      return reception.matiereQuantites
    }
    
    // Si les données sont dans catalogueMouvements
    if (reception.catalogueMouvements) {
      const allMatieres: MatiereQuantite[] = []
      reception.catalogueMouvements.forEach((cat) => {
        if (cat.matiereQuantites) {
          cat.matiereQuantites.forEach((mq: any) => {
            // Enrichir la matière avec les infos du catalogue si manquantes
            const matiereEnrichie: MatiereQuantite = {
              id: mq.id || mq.matiereId || mq.idMatiere || 0,
              matiereId: mq.matiereId || mq.idMatiere || mq.id,
              matiereLibelle: mq.matiereLibelle || 'Matière inconnue',
              matiereCode: mq.matiereCode || '',
              niveauScolaireLibelle: mq.niveauScolaireLibelle || cat.catalogueLibelle || 'N/A',
              niveauScolaireCode: mq.niveauScolaireCode || cat.niveauScolaireCode || null,
              niveauScolaireId: mq.niveauScolaireId || cat.niveauScolaireId || null,
              quantiteRecue: mq.quantiteRecue || 0,
              quantitePrevue: mq.quantitePrevue || 0,
              ecart: mq.ecart || 0
            }
            allMatieres.push(matiereEnrichie)
          })
        }
      })
      return allMatieres
    }
    
    return []
  }, [reception.matiereQuantites, reception.catalogueMouvements])

  // Mémoriser les matières pour éviter les recalculs
  const matieres = useMemo(() => getAllMatieres(), [getAllMatieres])

  /**
   * Fonction utilitaire réutilisable : Mappe le code niveau vers l'ID
   * Utilise une ref pour éviter les dépendances circulaires
   */
  const getNiveauIdFromCode = useCallback(async (niveauCode: string | null | undefined): Promise<number | null> => {
    if (!niveauCode) return null
    
    // Vérifier le cache (ref pour éviter dépendances)
    if (niveauxMapRef.current.has(niveauCode)) {
      return niveauxMapRef.current.get(niveauCode) || null
    }
    
    try {
      // Récupérer le niveau par code
      const response = await niveauScolaireService.getNiveauxScolaires({ code: niveauCode })
      if (response.items && response.items.length > 0) {
        const niveau = response.items[0]
        const niveauId = (niveau as any).id
        // Mettre en cache (ref pour éviter dépendances)
        niveauxMapRef.current.set(niveauCode, niveauId)
        return niveauId
      }
    } catch (error) {
      console.error(`❌ Erreur récupération niveau ${niveauCode}:`, error)
    }
    
    return null
  }, []) // Pas de dépendances grâce à la ref

  /**
   * Charge le stock IEPP disponible pour chaque matière
   * Réutilise les fonctions existantes pour éviter la duplication
   */
  const loadStockIEPP = useCallback(async () => {
    setLoadingStock(true)
    try {
      // ✅ SIMPLIFICATION : Utiliser directement la structure de l'utilisateur connecté (IEPP)
      // L'utilisateur connecté est l'IEPP qui valide les réceptions EPP
      if (!user?.structure?.id) {
        console.error('❌ Impossible de récupérer la structure IEPP de l\'utilisateur connecté')
        toast.error('Erreur: Structure IEPP non trouvée dans la session')
        return
      }
      
      const ieppStructureId = user.structure.id
      
      // 4. Utiliser les matières mémorisées
      
      // 5. Récupérer l'année scolaire courante (utiliser l'année de la réception si disponible)
      // @ts-ignore - anneeScolaireId peut être présent dans les données de réception
      const anneeScolaireId: number = (reception as any).anneeScolaireId || 2 // TODO: Récupérer l'année courante
      
      // 6. Pour chaque matière, récupérer le stock IEPP
      // ✅ SIMPLIFICATION : Stocker les objets StockDisponibleData complets pour accéder directement à quantiteDisponible
      const newStockDetails = new Map<string, StockDisponibleData>()
      
      for (const matiere of matieres) {
        try {
          // Utiliser matiereId si disponible, sinon matiere.id
          const matiereId = matiere.matiereId || matiere.id
          
          // Récupérer le niveau scolaire ID depuis le code ou l'ID
          let niveauId: number | null = matiere.niveauScolaireId || null
          const niveauCode = matiere.niveauScolaireCode || null
          
          // Si niveauId manquant mais code disponible, mapper le code vers l'ID
          if (!niveauId && niveauCode) {
            niveauId = await getNiveauIdFromCode(niveauCode)
          }
          
          // ✅ CORRECTION : Stocker le mapping matiereId → niveauId pour réutiliser lors du rendu
          if (niveauId && matiereId) {
            matiereNiveauMapRef.current.set(matiereId, niveauId)
          }
          
          // Appeler l'API pour récupérer le stock IEPP
          // Utiliser ieppStructureId (structure administrative ID) au lieu de ieppParentId (IEPP ID)
          const stockResponse = await mouvementService.getStockDisponible(
            ieppStructureId, // Structure Administrative ID de l'IEPP (comme le backend le fait)
            matiereId,        // Matière
            niveauId,         // Niveau ID
            anneeScolaireId
          )
          
          if (stockResponse.success && stockResponse.data) {
            // ✅ SIMPLIFICATION : Stocker directement l'objet complet StockDisponibleData
            const stockData = stockResponse.data
            const stockKey = `${matiereId}-${niveauId || 'null'}`
            newStockDetails.set(stockKey, stockData)
            const stockDisponible = stockData.quantiteDisponible || 0
            const suffisant = stockDisponible >= matiere.quantiteRecue
            if (!suffisant) {
              console.warn(`⚠️ STOCK INSUFFISANT: ${matiere.matiereLibelle} - Disponible: ${stockDisponible}, Demandé: ${matiere.quantiteRecue}`)
            }
          }
          // En cas d'erreur ou pas de données, ne pas stocker (la Map retournera undefined, qu'on gérera avec || 0)
        } catch (error: any) {
          console.error(`❌ Erreur stock pour ${matiere.matiereLibelle}:`, error)
          // En cas d'exception, ne pas stocker (la Map retournera undefined, qu'on gérera avec || 0)
        }
      }
      
      setStockDetails(newStockDetails)
    } catch (error: any) {
      console.error('❌ Erreur chargement stock IEPP:', error)
      toast.error('Erreur lors du chargement des stocks IEPP: ' + (error instanceof Error ? error.message : 'Erreur inconnue'))
    } finally {
      setLoadingStock(false)
    }
  }, [reception, matieres, getNiveauIdFromCode])

  useEffect(() => {
    // Charger les stocks IEPP disponibles pour vérification
    if (reception.id && matieres.length > 0) {
      loadStockIEPP()
    }
  }, [reception.id, matieres.length, loadStockIEPP])

  /**
   * Calcule le total des quantités demandées
   */
  const getTotalQuantites = () => {
    const matieres = getAllMatieres()
    return matieres.reduce((sum, m) => sum + (m.quantiteRecue || 0), 0)
  }

  /**
   * Calcule l'écart total
   */
  const getTotalEcart = () => {
    const matieres = getAllMatieres()
    return matieres.reduce((sum, m) => sum + (m.ecart || 0), 0)
  }

  /**
   * Vérifie si tous les stocks IEPP sont suffisants
   */
  const hasStockInsuffisant = () => {
    const matieres = getAllMatieres()
    return matieres.some(m => {
      // ✅ SIMPLIFICATION : Utiliser directement quantiteDisponible depuis l'objet StockDisponibleData
      const matiereId = m.matiereId || m.id
      // ✅ CORRECTION : Utiliser le niveauId depuis le mapping si m.niveauScolaireId est null
      let niveauId = m.niveauScolaireId || null
      if (!niveauId && matiereId) {
        niveauId = matiereNiveauMapRef.current.get(matiereId) || null
      }
      const stockKey = `${matiereId}-${niveauId || 'null'}`
      const stockData = stockDetails.get(stockKey)
      const stockDisponible = stockData?.quantiteDisponible || 0
      return stockDisponible < (m.quantiteRecue || 0)
    })
  }

  /**
   * Valide la réception EPP
   */
  const handleValidate = async () => {
    // Vérifier les stocks
    if (hasStockInsuffisant()) {
      toast.error("Stock IEPP insuffisant pour certaines matières. Validation impossible.")
      return
    }

    setIsValidating(true)
    try {
      console.log(`🔄 Validation IEPP de la réception ${reception.id}...`)
      
      const response = await receptionService.validateReception(reception.id, 'IEPP')
      
      if (response.success) {
        toast.success('✅ Réception validée avec succès ! Les stocks ont été mis à jour.')
        onValidate()
        onClose()
      } else {
        toast.error(`❌ Erreur : ${response.message}`)
      }
    } catch (error: any) {
      console.error('❌ Erreur validation:', error)
      toast.error('Erreur lors de la validation')
    } finally {
      setIsValidating(false)
    }
  }

  /**
   * Rejette la réception EPP et la renvoie en brouillon
   */
  const handleReject = async () => {
    const motif = observations.trim()
    if (!motif) {
      toast.error("Le motif de rejet est obligatoire.")
      return
    }

    const ok = window.confirm("Rejeter cette réception et la renvoyer en brouillon pour l'EPP ?")
    if (!ok) return

    setIsRejecting(true)
    try {
      const response = await receptionService.rejectReception(reception.id, motif)
      if (response.success) {
        toast.success("✅ Réception rejetée et renvoyée en brouillon.")
        onReject?.()
        onClose()
      } else {
        toast.error(`❌ Erreur : ${response.message}`)
      }
    } catch (error: any) {
      console.error("❌ Erreur rejet:", error)
      toast.error("Erreur lors du rejet")
    } finally {
      setIsRejecting(false)
    }
  }

  const totalQuantites = useMemo(() => matieres.reduce((sum, m) => sum + (m.quantiteRecue || 0), 0), [matieres])
  const totalEcart = useMemo(() => matieres.reduce((sum, m) => sum + (m.ecart || 0), 0), [matieres])
  const stockInsuffisant = useMemo(() => matieres.some(m => {
    // ✅ SIMPLIFICATION : Utiliser directement quantiteDisponible depuis l'objet StockDisponibleData
    const matiereId = m.matiereId || m.id
    // ✅ CORRECTION : Utiliser le niveauId depuis le mapping si m.niveauScolaireId est null
    let niveauId = m.niveauScolaireId || null
    if (!niveauId && matiereId) {
      niveauId = matiereNiveauMapRef.current.get(matiereId) || null
    }
    const stockKey = `${matiereId}-${niveauId || 'null'}`
    const stockData = stockDetails.get(stockKey)
    const stockDisponible = stockData?.quantiteDisponible || 0
    return stockDisponible < (m.quantiteRecue || 0)
  }), [matieres, stockDetails])

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="bg-white rounded-lg shadow-2xl w-[98vw] max-w-[1800px] max-h-[95vh] overflow-y-auto mx-auto p-8" onClick={(e) => e.stopPropagation()}>
        {/* Header */}
        <div className="flex items-center justify-between mb-6 pb-4 border-b border-gray-200">
          <div>
            <h3 className="text-xl font-bold text-gray-900 flex items-center gap-2">
              <CheckCircleIcon className="h-6 w-6 text-blue-600" />
              Validation Réception EPP
            </h3>
            <p className="text-sm text-gray-600 mt-1">
              Validez la réception pour transférer les stocks IEPP → EPP
            </p>
          </div>
          <button 
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 transition-colors"
          >
            <XCircleIcon className="h-6 w-6" />
          </button>
        </div>

        {/* Informations de la réception */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6 p-6 bg-gray-50 rounded-lg border border-gray-200">
          <div>
            <label className="text-sm font-medium text-gray-600 mb-1 block">EPP Concernée</label>
            <p className="text-base font-semibold text-gray-900">
              {reception.structure?.libelle || reception.structureLibelle || 'Structure Inconnue'}
            </p>
          </div>
          <div>
            <label className="text-sm font-medium text-gray-600 mb-1 block">Date Réception</label>
            <p className="text-base font-semibold text-gray-900">
              {reception.dateMouvement ? 
                (() => {
                  try {
                    const date = new Date(reception.dateMouvement);
                    if (isNaN(date.getTime())) {
                      return 'Date non disponible';
                    }
                    return date.toLocaleDateString('fr-FR');
                  } catch (error) {
                    return 'Date non disponible';
                  }
                })() : 
                'Date non disponible'
              }
            </p>
          </div>
          <div>
            <label className="text-sm font-medium text-gray-600 mb-1 block">Bordereau</label>
            <p className="text-base font-semibold text-gray-900">{reception.numeroBordereau || 'N/A'}</p>
          </div>
          <div>
            <label className="text-sm font-medium text-gray-600 mb-1 block">Statut</label>
            <span className="inline-flex px-3 py-1 text-sm font-semibold rounded-full bg-yellow-100 text-yellow-800">
              ⏳ En Attente Validation
            </span>
          </div>
        </div>

        {/* Alerte stock insuffisant */}
        {stockInsuffisant && !loadingStock && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-6">
            <div className="flex items-start">
              <ExclamationTriangleIcon className="h-5 w-5 text-red-600 mr-3 mt-0.5 flex-shrink-0" />
              <div>
                <p className="text-red-800 font-semibold">⚠️ Stock IEPP Insuffisant</p>
                <p className="text-red-700 text-sm mt-1">
                  Le stock IEPP est insuffisant pour certaines matières. Veuillez ajuster les quantités ou réapprovisionner avant validation.
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Tableau des matières */}
        <div className="border border-gray-200 rounded-lg overflow-hidden mb-6">
          <div className="bg-gray-50 px-6 py-4 border-b border-gray-200">
            <h4 className="text-lg font-semibold text-gray-900">📚 Détails des Manuels</h4>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-8 py-4 text-left text-sm font-semibold text-gray-700 uppercase tracking-wider w-[25%]">Matière</th>
                  <th className="px-8 py-4 text-left text-sm font-semibold text-gray-700 uppercase tracking-wider w-[20%]">Niveau</th>
                  <th className="px-8 py-4 text-right text-sm font-semibold text-gray-700 uppercase tracking-wider w-[13%]">Qté Demandée</th>
                  <th className="px-8 py-4 text-right text-sm font-semibold text-gray-700 uppercase tracking-wider w-[13%]">Stock IEPP</th>
                  <th className="px-8 py-4 text-right text-sm font-semibold text-gray-700 uppercase tracking-wider w-[12%]">Écart</th>
                  <th className="px-8 py-4 text-center text-sm font-semibold text-gray-700 uppercase tracking-wider w-[17%]">Statut</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {loadingStock ? (
                  <tr>
                    <td colSpan={6} className="px-4 py-8 text-center text-gray-500">
                      <div className="flex items-center justify-center">
                        <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-gray-600 mr-2"></div>
                        Chargement des stocks...
                      </div>
                    </td>
                  </tr>
                ) : matieres.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="px-4 py-8 text-center text-gray-500">
                      Aucune matière trouvée
                    </td>
                  </tr>
                ) : (
                  matieres.map((matiere, index) => {
                    // ✅ SIMPLIFICATION : Utiliser directement quantiteDisponible depuis l'objet StockDisponibleData
                    const matiereId = matiere.matiereId || matiere.id
                    // ✅ CORRECTION : Utiliser le niveauId depuis le mapping si matiere.niveauScolaireId est null
                    // Cela garantit qu'on utilise la même clé que lors du stockage
                    let niveauId = matiere.niveauScolaireId || null
                    if (!niveauId && matiereId) {
                      niveauId = matiereNiveauMapRef.current.get(matiereId) || null
                    }
                    const stockKey = `${matiereId}-${niveauId || 'null'}`
                    const stockData = stockDetails.get(stockKey)
                    const stockDisponible = stockData?.quantiteDisponible || 0
                    const quantiteDemandee = matiere.quantiteRecue || 0
                    const ecart = matiere.ecart || 0
                    const stockSuffisant = stockDisponible >= quantiteDemandee

                    return (
                      <tr key={index} className={`hover:bg-gray-50 transition-colors ${!stockSuffisant ? 'bg-red-50' : ''}`}>
                        <td className="px-8 py-5 text-base">
                          <div className="font-semibold text-gray-900">{matiere.matiereLibelle || 'Matière inconnue'}</div>
                          <div className="text-sm text-gray-500 mt-1">{matiere.matiereCode || ''}</div>
                        </td>
                        <td className="px-8 py-5 text-base text-gray-700">
                          {matiere.niveauScolaireLibelle || 'N/A'}
                        </td>
                        <td className="px-8 py-5 text-base text-right font-bold text-gray-900">
                          {quantiteDemandee}
                        </td>
                        <td className="px-8 py-5 text-base text-right">
                          <span className={`font-bold text-lg ${stockSuffisant ? 'text-green-600' : 'text-red-600'}`}>
                            {stockDisponible}
                          </span>
                        </td>
                        <td className="px-8 py-5 text-base text-right">
                          <span className={`inline-flex px-3 py-1.5 text-sm font-bold rounded-full ${
                            ecart < 0 
                              ? 'bg-red-100 text-red-800' 
                              : ecart > 0 
                                ? 'bg-green-100 text-green-800' 
                                : 'bg-gray-100 text-gray-800'
                          }`}>
                            {ecart > 0 ? '+' : ''}{ecart}
                          </span>
                        </td>
                        <td className="px-8 py-5 text-center">
                          {stockSuffisant ? (
                            <span className="inline-flex items-center px-3 py-1.5 text-sm font-bold rounded-full bg-green-100 text-green-800">
                              <CheckCircleIcon className="h-4 w-4 mr-1" />
                              OK
                            </span>
                          ) : (
                            <span className="inline-flex items-center px-3 py-1.5 text-sm font-bold rounded-full bg-red-100 text-red-800">
                              <ExclamationTriangleIcon className="h-4 w-4 mr-1" />
                              Insuffisant
                            </span>
                          )}
                        </td>
                      </tr>
                    )
                  })
                )}
              </tbody>
              <tfoot className="bg-gray-100 border-t-2 border-gray-400">
                <tr>
                  <td colSpan={2} className="px-8 py-5 text-base font-bold text-gray-900 uppercase">
                    TOTAL
                  </td>
                  <td className="px-8 py-5 text-base text-right font-bold text-blue-600 text-lg">
                    {totalQuantites}
                  </td>
                  <td className="px-8 py-5 text-base text-right font-bold text-gray-600">
                    --
                  </td>
                  <td className="px-8 py-5 text-base text-right font-bold text-gray-900">
                    <span className={`inline-flex px-3 py-1.5 text-sm font-bold rounded-full ${
                      totalEcart < 0 
                        ? 'bg-red-100 text-red-800' 
                        : totalEcart > 0 
                          ? 'bg-green-100 text-green-800' 
                          : 'bg-gray-100 text-gray-800'
                    }`}>
                      {totalEcart > 0 ? '+' : ''}{totalEcart}
                    </span>
                  </td>
                  <td className="px-8 py-5"></td>
                </tr>
              </tfoot>
            </table>
          </div>
        </div>

        {/* Observations EPP */}
        {reception.observation && (
          <div className="mb-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
            <label className="block text-sm font-semibold text-blue-900 mb-2">
              📝 Observations EPP
            </label>
            <p className="text-sm text-blue-800">{reception.observation}</p>
          </div>
        )}

        {/* Observations IEPP */}
        <div className="mb-6">
          <label className="block text-sm font-semibold text-gray-700 mb-2">
            💬 Observations IEPP (optionnel) / Motif de rejet (obligatoire si rejet)
          </label>
          <textarea
            value={observations}
            onChange={(e) => setObservations(e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            rows={3}
            placeholder="Ajouter des observations sur cette validation (écarts, remarques, actions à suivre...)"
          />
        </div>

        {/* Explication de l'action */}
        <div className="mb-6 p-6 bg-green-50 border-2 border-green-300 rounded-lg shadow-sm">
          <h5 className="text-lg font-bold text-green-900 mb-4 flex items-center gap-2">
            <CheckCircleIcon className="h-6 w-6" />
            Effet de la Validation
          </h5>
          <ul className="text-base text-green-800 space-y-2">
            <li className="flex items-start">
              <span className="mr-2">✅</span>
              <span>Stock IEPP sera <strong className="font-bold">déduit</strong> de <strong className="font-bold text-green-900">{totalQuantites} manuels</strong></span>
            </li>
            <li className="flex items-start">
              <span className="mr-2">✅</span>
              <span>Stock EPP "<strong className="font-bold text-green-900">{reception.structure?.libelle || reception.structureLibelle || 'Structure Inconnue'}</strong>" sera <strong className="font-bold">crédité</strong> de <strong className="font-bold text-green-900">{totalQuantites} manuels</strong></span>
            </li>
            <li className="flex items-start">
              <span className="mr-2">✅</span>
              <span>L'EPP pourra <strong className="font-bold">distribuer</strong> les manuels aux élèves</span>
            </li>
            <li className="flex items-start">
              <span className="mr-2">✅</span>
              <span>Le statut passera à <strong className="font-bold text-green-900">CONFIRMEE_IEPP</strong></span>
            </li>
          </ul>
        </div>

        {/* Actions */}
        <div className="flex justify-between items-center pt-6 border-t-2 border-gray-300">
          <button
            onClick={onClose}
            className="px-8 py-3 border-2 border-gray-300 rounded-lg text-base font-semibold text-gray-700 hover:bg-gray-50 transition-colors shadow-sm"
            disabled={isValidating || isRejecting}
          >
            Annuler
          </button>

          <div className="flex items-center gap-3">
            <button
              onClick={handleReject}
              disabled={isValidating || isRejecting}
              className={`px-8 py-3 rounded-lg text-base font-bold transition-all flex items-center gap-2 shadow-lg ${
                isValidating || isRejecting
                  ? 'bg-gray-300 text-gray-500 cursor-not-allowed'
                  : 'bg-red-600 text-white hover:bg-red-700 hover:shadow-xl'
              }`}
            >
              {isRejecting ? "Rejet en cours..." : "Rejeter"}
            </button>

            <button
              onClick={handleValidate}
              disabled={isValidating || isRejecting || stockInsuffisant || loadingStock}
              className={`px-8 py-3 rounded-lg text-base font-bold transition-all flex items-center gap-2 shadow-lg ${
                stockInsuffisant || loadingStock || isRejecting
                  ? 'bg-gray-300 text-gray-500 cursor-not-allowed'
                  : 'bg-green-600 text-white hover:bg-green-700 hover:shadow-xl transform hover:scale-105'
              }`}
            >
              {isValidating ? (
                <>
                  <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                  Validation en cours...
                </>
              ) : (
                <>
                  <CheckCircleIcon className="h-6 w-6" />
                  Valider la Distribution
                </>
              )}
            </button>
          </div>
        </div>

        {/* Avertissement si stock insuffisant */}
        {stockInsuffisant && (
          <div className="mt-4 p-3 bg-red-50 border border-red-200 rounded-md">
            <p className="text-sm text-red-800 font-medium">
              ⚠️ Validation bloquée : Stock IEPP insuffisant pour certaines matières
            </p>
          </div>
        )}
      </div>
    </div>
  )
}

