'use client';

import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Upload, FileText, CheckCircle, AlertCircle, Package, ClipboardList, Calculator, Shield, X, Truck, FileSpreadsheet } from 'lucide-react';
import { toast } from 'sonner';

interface ConfirmationReceptionModalProps {
  isOpen: boolean;
  onClose: () => void;
  reception: any;
}

export default function ConfirmationReceptionModal({ isOpen, onClose, reception }: ConfirmationReceptionModalProps) {
  const [activeTab, setActiveTab] = useState('quantites');
  const [bordereauFile, setBordereauFile] = useState<File | null>(null);
  const [ficheReceptionFile, setFicheReceptionFile] = useState<File | null>(null);
  const [uploadStatus, setUploadStatus] = useState<'idle' | 'uploading' | 'completed' | 'error'>('idle');
  const [quantitesRecues, setQuantitesRecues] = useState<any[]>([]);
  const [observations, setObservations] = useState('');

  // Initialiser les quantités reçues avec les données de la réception
  useState(() => {
    if (reception && reception.manuels) {
      setQuantitesRecues([...reception.manuels]);
    }
  });

  const handleQuantiteChange = (index: number, value: string) => {
    const newQuantites = [...quantitesRecues];
    newQuantites[index].quantite_recue = parseInt(value) || 0;
    newQuantites[index].ecart = newQuantites[index].quantite_recue - newQuantites[index].quantite_prevue;
    setQuantitesRecues(newQuantites);
  };

  const handleBordereauUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setBordereauFile(file);
      toast.success('Bordereau de livraison uploadé');
    }
  };

  const handleFicheReceptionUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setFicheReceptionFile(file);
      toast.success('Fiche de réception uploadée');
    }
  };

  const handleValidation = async () => {
    if (!bordereauFile) {
      toast.error('Veuillez uploader le bordereau de livraison');
      return;
    }

    if (!ficheReceptionFile) {
      toast.error('Veuillez uploader la fiche de réception');
      return;
    }

    setUploadStatus('uploading');
    
    // Simulation de la validation
    setTimeout(() => {
      setUploadStatus('completed');
      toast.success('Réception confirmée avec succès ! Stock IEPP mis à jour.');
      onClose();
    }, 2000);
  };

  const getStatusIcon = () => {
    switch (uploadStatus) {
      case 'completed':
        return <CheckCircle className="h-5 w-5 text-green-500" />;
      case 'error':
        return <AlertCircle className="h-5 w-5 text-red-500" />;
      case 'uploading':
        return <div className="h-5 w-5 animate-spin rounded-full border-2 border-blue-500 border-t-transparent" />;
      default:
        return <Package className="h-5 w-5 text-blue-500" />;
    }
  };

  const getStatusText = () => {
    switch (uploadStatus) {
      case 'completed':
        return 'Réception confirmée';
      case 'error':
        return 'Erreur lors de la confirmation';
      case 'uploading':
        return 'Confirmation en cours...';
      default:
        return 'En attente de confirmation';
    }
  };

  if (!reception) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-xl">
            <Truck className="h-6 w-6 text-blue-600" />
            Confirmation Réception Libraire → IEPP
          </DialogTitle>
          <DialogDescription>
            Confirmer la réception des manuels du libraire et mettre à jour le stock IEPP
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          {/* Informations de la réception */}
          <Card className="border-blue-200 bg-blue-50">
            <CardHeader className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-t-lg">
              <CardTitle className="flex items-center gap-2 text-gray-900">
                <FileText className="h-5 w-5 text-blue-600" />
                Informations de la Réception
              </CardTitle>
            </CardHeader>
            <CardContent className="p-6">
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div>
                  <Label className="text-sm font-medium text-gray-700">Référence</Label>
                  <p className="text-gray-900 font-medium">{reception.reference}</p>
                </div>
                <div>
                  <Label className="text-sm font-medium text-gray-700">Bordereau</Label>
                  <p className="text-gray-900">{reception.bordereau}</p>
                </div>
                <div>
                  <Label className="text-sm font-medium text-gray-700">Fournisseur</Label>
                  <p className="text-gray-900">{reception.fournisseur}</p>
                </div>
                <div>
                  <Label className="text-sm font-medium text-gray-700">Date Réception</Label>
                  <p className="text-gray-900">
                    {new Date(reception.date_reception).toLocaleDateString("fr-FR")}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="quantites" className="flex items-center gap-2">
                <ClipboardList className="h-4 w-4" />
                Quantités Reçues
              </TabsTrigger>
              <TabsTrigger value="documents" className="flex items-center gap-2">
                <FileText className="h-4 w-4" />
                Documents
              </TabsTrigger>
            </TabsList>

            <TabsContent value="quantites" className="space-y-6 mt-6">
              <Card className="border-blue-200 bg-white shadow-lg">
                <CardHeader className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-t-lg">
                  <CardTitle className="flex items-center gap-2 text-gray-900">
                    <ClipboardList className="h-5 w-5 text-blue-600" />
                    Confirmation des Quantités Reçues
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-6">
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm border-collapse">
                      <thead>
                        <tr className="bg-gradient-to-r from-blue-50 to-indigo-50">
                          <th className="text-left p-3 font-semibold text-gray-700 border-b border-blue-200">Code</th>
                          <th className="text-left p-3 font-semibold text-gray-700 border-b border-blue-200">Manuel</th>
                          <th className="text-left p-3 font-semibold text-gray-700 border-b border-blue-200">Effectif de la classe</th>
                          <th className="text-left p-3 font-semibold text-gray-700 border-b border-blue-200">Quantité Reçue</th>
                          <th className="text-left p-3 font-semibold text-gray-700 border-b border-blue-200">Écart</th>
                        </tr>
                      </thead>
                      <tbody>
                        {quantitesRecues.map((row, index) => {
                          const ecart = row.quantite_recue - row.quantite_prevue;
                          return (
                            <tr key={index} className="border-b border-gray-100 hover:bg-blue-50 transition-colors">
                              <td className="p-3 font-medium text-gray-900">{row.code}</td>
                              <td className="p-3 text-gray-700">{row.titre}</td>
                              <td className="p-3 text-gray-700">{row.quantite_prevue}</td>
                              <td className="p-3">
                                <Input
                                  type="number"
                                  value={row.quantite_recue}
                                  onChange={(e) => handleQuantiteChange(index, e.target.value)}
                                  className="w-20 border-blue-200 focus:border-blue-500 focus:ring-blue-500"
                                />
                              </td>
                              <td className="p-3">
                                <Badge 
                                  variant={ecart < 0 ? "destructive" : ecart > 0 ? "default" : "secondary"}
                                  className={ecart < 0 ? "bg-red-100 text-red-800" : ecart > 0 ? "bg-green-100 text-green-800" : "bg-gray-100 text-gray-800"}
                                >
                                  {ecart > 0 ? '+' : ''}{ecart}
                                </Badge>
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="documents" className="space-y-6 mt-6">
              <Card className="border-blue-200 bg-white shadow-lg">
                <CardHeader className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-t-lg">
                  <CardTitle className="flex items-center gap-2 text-gray-900">
                    <FileText className="h-5 w-5 text-blue-600" />
                    Documents de Réception
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-6 space-y-6">
                  {/* Bordereau de livraison */}
                  <div className="space-y-3">
                    <Label className="text-sm font-medium text-gray-700 flex items-center gap-2">
                      <Truck className="h-4 w-4 text-blue-600" />
                      Bordereau de Livraison du Libraire
                    </Label>
                    <div className="flex items-center gap-3">
                      <Input
                        type="file"
                        accept=".pdf,.doc,.docx,.jpg,.jpeg,.png"
                        onChange={handleBordereauUpload}
                        className="flex-1"
                      />
                      {bordereauFile && (
                        <Badge variant="secondary" className="bg-green-100 text-green-800">
                          <CheckCircle className="h-3 w-3 mr-1" />
                          Uploadé
                        </Badge>
                      )}
                    </div>
                    <p className="text-xs text-gray-500">
                      Format accepté : PDF, DOC, DOCX, JPG, PNG (Max 5MB)
                    </p>
                  </div>

                  {/* Fiche de réception */}
                  <div className="space-y-3">
                    <Label className="text-sm font-medium text-gray-700 flex items-center gap-2">
                      <ClipboardList className="h-4 w-4 text-green-600" />
                      Fiche de Réception avec Émargements
                    </Label>
                    <div className="flex items-center gap-3">
                      <Input
                        type="file"
                        accept=".pdf,.doc,.docx,.jpg,.jpeg,.png"
                        onChange={handleFicheReceptionUpload}
                        className="flex-1"
                      />
                      {ficheReceptionFile && (
                        <Badge variant="secondary" className="bg-green-100 text-green-800">
                          <CheckCircle className="h-3 w-3 mr-1" />
                          Uploadé
                        </Badge>
                      )}
                    </div>
                    <p className="text-xs text-gray-500">
                      Fiche de réception signée par le responsable IEPP
                    </p>
                  </div>

                  {/* Observations */}
                  <div className="space-y-3">
                    <Label className="text-sm font-medium text-gray-700">Observations</Label>
                    <Textarea
                      value={observations}
                      onChange={(e) => setObservations(e.target.value)}
                      placeholder="Observations sur la réception, état des manuels, etc."
                      className="min-h-[100px] border-blue-200 focus:border-blue-500 focus:ring-blue-500"
                    />
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>

          {/* Actions */}
          <div className="flex items-center justify-between pt-6 border-t border-gray-200">
            <div className="flex items-center gap-3">
              {getStatusIcon()}
              <span className="text-sm text-gray-600">{getStatusText()}</span>
            </div>
            
            <div className="flex gap-3">
              <Button
                variant="outline"
                onClick={onClose}
                disabled={uploadStatus === 'uploading'}
              >
                <X className="h-4 w-4 mr-2" />
                Annuler
              </Button>
              
              <Button
                onClick={handleValidation}
                disabled={uploadStatus === 'uploading' || !bordereauFile || !ficheReceptionFile}
                className="bg-blue-600 hover:bg-blue-700"
              >
                <CheckCircle className="h-4 w-4 mr-2" />
                {uploadStatus === 'uploading' ? 'Confirmation...' : 'Confirmer Réception'}
              </Button>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
} 