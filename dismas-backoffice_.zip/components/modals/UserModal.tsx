/**
 * Modal pour créer/modifier un utilisateur
 * Intègre avec l'API backend
 */

"use client"

import React, { useState, useEffect } from 'react';
import { User, Role, StructureAdministrative } from '@/lib/types/entities';
import { RoleService } from '@/lib/services/role.service';
import { ParametrageService } from '@/lib/services/parametrage.service';
import { XMarkIcon } from '@heroicons/react/24/outline';

interface UserModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (user: User) => Promise<boolean>;
  user?: User | null;
  title: string;
}

export default function UserModal({ isOpen, onClose, onSave, user, title }: UserModalProps) {
  const [formData, setFormData] = useState<Partial<User>>({
    firstName: '',
    lastName: '',
    email: '',
    login: '',
    password: '',
    fonction: '',
    roleId: 0,
    isActive: true,
    isLdapUser: false,
  });

  const [roles, setRoles] = useState<Role[]>([]);
  const [structures, setStructures] = useState<StructureAdministrative[]>([]);
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const roleService = new RoleService();
  const parametrageService = new ParametrageService();

  // Charger les données de référence
  useEffect(() => {
    if (isOpen) {
      loadReferenceData();
    }
  }, [isOpen]);

  // Initialiser le formulaire
  useEffect(() => {
    if (user) {
      setFormData({
        id: user.id,
        firstName: user.firstName,
        lastName: user.lastName,
        email: user.email,
        login: user.login,
        password: '',
        fonction: user.fonction,
        roleId: user.roleId,
        isActive: user.isActive,
        isLdapUser: user.isLdapUser,
      });
    } else {
      setFormData({
        firstName: '',
        lastName: '',
        email: '',
        login: '',
        password: '',
        fonction: '',
        roleId: 0,
        isActive: true,
        isLdapUser: false,
      });
    }
    setErrors({});
  }, [user, isOpen]);

  const loadReferenceData = async () => {
    try {
      const [rolesResponse, structuresResponse] = await Promise.all([
        roleService.getAllRoles(),
        parametrageService.getAllStructuresAdministratives(),
      ]);

      if (rolesResponse.items) {
        setRoles(rolesResponse.items);
      }
      if (structuresResponse.items) {
        setStructures(structuresResponse.items);
      }
    } catch (error) {
      console.error('Erreur lors du chargement des données de référence:', error);
    }
  };

  const validateForm = (): boolean => {
    const newErrors: Record<string, string> = {};

    if (!formData.firstName?.trim()) {
      newErrors.firstName = 'Le prénom est requis';
    }
    if (!formData.lastName?.trim()) {
      newErrors.lastName = 'Le nom est requis';
    }
    if (!formData.email?.trim()) {
      newErrors.email = 'L\'email est requis';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = 'Format d\'email invalide';
    }
    if (!formData.login?.trim()) {
      newErrors.login = 'Le matricule est requis';
    }
    if (!user && !formData.password?.trim()) {
      newErrors.password = 'Le mot de passe est requis';
    }
    if (!formData.roleId || formData.roleId === 0) {
      newErrors.roleId = 'Le rôle est requis';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (loading) return;

    if (!validateForm()) {
      return;
    }

    setLoading(true);
    
    try {
      const success = await onSave(formData as User);
      if (success) {
        onClose();
      }
    } catch (error) {
      console.error('Erreur lors de la sauvegarde:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (field: keyof User, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    // Effacer l'erreur pour ce champ
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-3 sm:p-4">
      <div className="bg-white rounded-lg shadow-xl w-[min(80vw,1440px)] max-w-none max-h-[92vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <h3 className="text-lg font-semibold text-gray-900">{title}</h3>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600"
          >
            <XMarkIcon className="h-6 w-6" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Prénom */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Prénom *
              </label>
              <input
                type="text"
                value={formData.firstName || ''}
                onChange={(e) => handleChange('firstName', e.target.value)}
                className={`input-field ${errors.firstName ? 'border-red-500' : ''}`}
                placeholder="Prénom de l'utilisateur"
              />
              {errors.firstName && (
                <p className="text-red-500 text-xs mt-1">{errors.firstName}</p>
              )}
            </div>

            {/* Nom */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Nom *
              </label>
              <input
                type="text"
                value={formData.lastName || ''}
                onChange={(e) => handleChange('lastName', e.target.value)}
                className={`input-field ${errors.lastName ? 'border-red-500' : ''}`}
                placeholder="Nom de l'utilisateur"
              />
              {errors.lastName && (
                <p className="text-red-500 text-xs mt-1">{errors.lastName}</p>
              )}
            </div>

            {/* Email */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Email *
              </label>
              <input
                type="email"
                value={formData.email || ''}
                onChange={(e) => handleChange('email', e.target.value)}
                className={`input-field ${errors.email ? 'border-red-500' : ''}`}
                placeholder="email@exemple.com"
              />
              {errors.email && (
                <p className="text-red-500 text-xs mt-1">{errors.email}</p>
              )}
            </div>

            {/* Matricule */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Matricule *
              </label>
              <input
                type="text"
                value={formData.login || ''}
                onChange={(e) => handleChange('login', e.target.value)}
                className={`input-field ${errors.login ? 'border-red-500' : ''}`}
                placeholder="Matricule"
              />
              {errors.login && (
                <p className="text-red-500 text-xs mt-1">{errors.login}</p>
              )}
            </div>

            {/* Mot de passe */}
            {!user && (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Mot de passe *
                </label>
                <input
                  type="password"
                  value={formData.password || ''}
                  onChange={(e) => handleChange('password', e.target.value)}
                  className={`input-field ${errors.password ? 'border-red-500' : ''}`}
                  placeholder="Mot de passe"
                />
                {errors.password && (
                  <p className="text-red-500 text-xs mt-1">{errors.password}</p>
                )}
              </div>
            )}

            {/* Fonction */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Fonction
              </label>
              <input
                type="text"
                value={formData.fonction || ''}
                onChange={(e) => handleChange('fonction', e.target.value)}
                className="input-field"
                placeholder="Fonction de l'utilisateur"
              />
            </div>

            {/* Rôle */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Rôle *
              </label>
              <select
                value={formData.roleId || 0}
                onChange={(e) => handleChange('roleId', parseInt(e.target.value))}
                className={`input-field ${errors.roleId ? 'border-red-500' : ''}`}
              >
                <option value={0}>Sélectionner un rôle</option>
                {roles.map((role) => (
                  <option key={role.id} value={role.id}>
                    {role.libelle || role.name}
                  </option>
                ))}
              </select>
              {errors.roleId && (
                <p className="text-red-500 text-xs mt-1">{errors.roleId}</p>
              )}
            </div>
          </div>

          {/* Options */}
          <div className="flex items-center space-x-6">
            <label className="flex items-center">
              <input
                type="checkbox"
                checked={formData.isActive || false}
                onChange={(e) => handleChange('isActive', e.target.checked)}
                className="mr-2"
              />
              <span className="text-sm text-gray-700">Actif</span>
            </label>

            <label className="flex items-center">
              <input
                type="checkbox"
                checked={formData.isLdapUser || false}
                onChange={(e) => handleChange('isLdapUser', e.target.checked)}
                className="mr-2"
              />
              <span className="text-sm text-gray-700">Utilisateur LDAP</span>
            </label>
          </div>

          {/* Actions */}
          <div className="flex justify-end space-x-3 pt-4 border-t border-gray-200">
            <button
              type="button"
              onClick={onClose}
              className="btn-secondary"
              disabled={loading}
            >
              Annuler
            </button>
            <button
              type="submit"
              className="btn-primary flex items-center"
              disabled={loading}
            >
              {loading && (
                <div className="spinner mr-2"></div>
              )}
              {user ? 'Modifier' : 'Créer'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}