"use client"

import { useState, useEffect } from "react"
import { XCircleIcon } from "@heroicons/react/24/outline"
import { regulationService, type RedistributionRequest } from "@/lib/services/regulation.service"
import { structuresService } from "@/lib/services/structures.service"
import { matiereService } from "@/lib/services/matiere.service"
import { niveauScolaireService } from "@/lib/services/niveau-scolaire.service"
import { anneeScolaireService } from "@/lib/services/annee-scolaire.service"
import { useAuth } from "@/app/providers"
import { toast } from "sonner"

interface RedistribuerStockModalProps {
  isOpen: boolean
  eppId?: number // EPP déficitaire à qui donner du stock
  onClose: () => void
  onSuccess: () => void
}

export default function RedistribuerStockModal({
  isOpen,
  eppId,
  onClose,
  onSuccess,
}: RedistribuerStockModalProps) {
  const { user } = useAuth()
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [formData, setFormData] = useState({
    eppId: eppId || 0,
    matiereId: 0,
    niveauId: 0,
    quantite: 0,
    anneeScolaireId: 0,
    commentaire: "",
  })
  const [eppList, setEppList] = useState<any[]>([])
  const [matieres, setMatieres] = useState<any[]>([])
  const [niveaux, setNiveaux] = useState<any[]>([])
  const [anneesScolaires, setAnneesScolaires] = useState<any[]>([])

  useEffect(() => {
    if (isOpen) {
      loadData()
    }
  }, [isOpen, user])

  const loadData = async () => {
    if (!user?.structure?.id) return

    try {
      // Charger les EPP de l'IEPP
      const eppResponse = await structuresService.getEppsByIepp(user.structure.id)
      if (eppResponse.items) {
        setEppList(eppResponse.items)
        if (eppId && !formData.eppId) {
          setFormData((prev) => ({ ...prev, eppId }))
        }
      }

      // Charger les matières
      const matieresResponse = await matiereService.getMatieres({})
      if (matieresResponse.items) {
        setMatieres(matieresResponse.items)
      }

      // Charger les niveaux
      const niveauxResponse = await niveauScolaireService.getNiveauxScolaires({})
      if (niveauxResponse.items) {
        setNiveaux(niveauxResponse.items)
      }

      // Charger les années scolaires
      const anneesResponse = await anneeScolaireService.getByCriteria({}, 0, 100) as any
      const itemsArray = Array.isArray(anneesResponse.items) ? anneesResponse.items : (anneesResponse.items ? [anneesResponse.items] : [])
      if (itemsArray.length > 0) {
        setAnneesScolaires(itemsArray)
        const anneeCourante = itemsArray.find((a: any) => a.estCourante) || itemsArray[0]
        if (anneeCourante && anneeCourante.id) {
          setFormData((prev) => ({ ...prev, anneeScolaireId: anneeCourante.id || 0 }))
        }
      }
    } catch (error) {
      console.error("Erreur lors du chargement des données:", error)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!user?.structure?.id) {
      toast.error("Impossible de déterminer votre IEPP")
      return
    }

    if (formData.eppId <= 0) {
      toast.error("Veuillez sélectionner un EPP")
      return
    }

    if (formData.matiereId <= 0) {
      toast.error("Veuillez sélectionner une matière")
      return
    }

    if (formData.niveauId <= 0) {
      toast.error("Veuillez sélectionner un niveau")
      return
    }

    if (formData.quantite <= 0) {
      toast.error("La quantité doit être supérieure à 0")
      return
    }

    if (formData.anneeScolaireId <= 0) {
      toast.error("Veuillez sélectionner une année scolaire")
      return
    }

    setIsSubmitting(true)

    try {
      const request: RedistributionRequest = {
        ieppId: user.structure.id,
        eppId: formData.eppId,
        matiereId: formData.matiereId,
        niveauId: formData.niveauId,
        quantite: formData.quantite,
        anneeScolaireId: formData.anneeScolaireId,
        commentaire: formData.commentaire || undefined,
      }

      const response = await regulationService.redistribuerStock(request)

      if (response.hasError) {
        toast.error(response.status?.message || "Erreur lors de la redistribution")
      } else {
        toast.success("Stock redistribué avec succès")
        onSuccess()
        onClose()
        // Réinitialiser le formulaire
        setFormData({
          eppId: eppId || 0,
          matiereId: 0,
          niveauId: 0,
          quantite: 0,
          anneeScolaireId: formData.anneeScolaireId,
          commentaire: "",
        })
      }
    } catch (error: any) {
      console.error("Erreur lors de la redistribution:", error)
      toast.error(error?.message || "Erreur lors de la redistribution")
    } finally {
      setIsSubmitting(false)
    }
  }

  if (!isOpen) return null

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-content max-w-lg" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold">Redistribuer du Stock</h3>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600">
            <XCircleIcon className="h-6 w-6" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="form-group">
            <label className="form-label">
              EPP Destinataire <span className="text-red-500">*</span>
            </label>
            <select
              className="input-field"
              value={formData.eppId}
              onChange={(e) =>
                setFormData((prev) => ({ ...prev, eppId: parseInt(e.target.value) }))
              }
              required
              disabled={!!eppId}
            >
              <option value="0">Sélectionner un EPP</option>
              {eppList.map((epp) => (
                <option key={epp.id} value={epp.id}>
                  {epp.libelle} ({epp.code})
                </option>
              ))}
            </select>
          </div>

          <div className="form-group">
            <label className="form-label">
              Année Scolaire <span className="text-red-500">*</span>
            </label>
            <select
              className="input-field"
              value={formData.anneeScolaireId}
              onChange={(e) =>
                setFormData((prev) => ({ ...prev, anneeScolaireId: parseInt(e.target.value) }))
              }
              required
            >
              <option value="0">Sélectionner une année scolaire</option>
              {anneesScolaires.map((annee) => (
                <option key={annee.id} value={annee.id}>
                  {annee.libelle} {annee.estCourante ? "(Année courante)" : ""}
                </option>
              ))}
            </select>
          </div>

          <div className="form-group">
            <label className="form-label">
              Matière <span className="text-red-500">*</span>
            </label>
            <select
              className="input-field"
              value={formData.matiereId}
              onChange={(e) =>
                setFormData((prev) => ({ ...prev, matiereId: parseInt(e.target.value) }))
              }
              required
            >
              <option value="0">Sélectionner une matière</option>
              {matieres.map((matiere) => (
                <option key={matiere.id} value={matiere.id}>
                  {matiere.libelle} ({matiere.code})
                </option>
              ))}
            </select>
          </div>

          <div className="form-group">
            <label className="form-label">
              Niveau Scolaire <span className="text-red-500">*</span>
            </label>
            <select
              className="input-field"
              value={formData.niveauId}
              onChange={(e) =>
                setFormData((prev) => ({ ...prev, niveauId: parseInt(e.target.value) }))
              }
              required
            >
              <option value="0">Sélectionner un niveau</option>
              {niveaux.map((niveau) => (
                <option key={niveau.id} value={niveau.id}>
                  {niveau.libelle} ({niveau.code})
                </option>
              ))}
            </select>
          </div>

          <div className="form-group">
            <label className="form-label">
              Quantité <span className="text-red-500">*</span>
            </label>
            <input
              type="number"
              className="input-field"
              min="1"
              value={formData.quantite}
              onChange={(e) =>
                setFormData((prev) => ({ ...prev, quantite: parseInt(e.target.value) || 0 }))
              }
              required
            />
          </div>

          <div className="form-group">
            <label className="form-label">Commentaire (optionnel)</label>
            <textarea
              className="input-field"
              rows={3}
              value={formData.commentaire}
              onChange={(e) =>
                setFormData((prev) => ({ ...prev, commentaire: e.target.value }))
              }
              placeholder="Ajoutez un commentaire pour cette redistribution..."
            />
          </div>

          <div className="flex justify-end space-x-3 mt-6">
            <button
              type="button"
              onClick={onClose}
              className="btn-outline"
              disabled={isSubmitting}
            >
              Annuler
            </button>
            <button type="submit" className="btn-primary" disabled={isSubmitting}>
              {isSubmitting ? "Redistribution..." : "Redistribuer le Stock"}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}

