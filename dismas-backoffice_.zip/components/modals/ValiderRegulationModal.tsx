"use client"

import { useState } from "react"
import { XCircleIcon, CheckCircleIcon } from "@heroicons/react/24/outline"
import { regulationService, type RegulationDto } from "@/lib/services/regulation.service"
import { regulationTierActionBlockedReason } from "@/lib/utils/regulation-valider-eligibility"
import { useAuth } from "@/app/providers"
import { toast } from "sonner"

interface ValiderRegulationModalProps {
  isOpen: boolean
  regulation: RegulationDto | null
  onClose: () => void
  onSuccess: () => void
}

export default function ValiderRegulationModal({
  isOpen,
  regulation,
  onClose,
  onSuccess,
}: ValiderRegulationModalProps) {
  const { user } = useAuth()
  const [isSubmitting, setIsSubmitting] = useState(false)
  const roleCode = (user?.role?.code ?? "").trim().toUpperCase()
  const submitBlockedReason =
    regulation != null ? regulationTierActionBlockedReason(roleCode, regulation) : null

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!regulation?.id) {
      toast.error("Régulation invalide")
      return
    }
    if (submitBlockedReason) {
      toast.error(submitBlockedReason)
      return
    }

    setIsSubmitting(true)

    try {
      const response = await regulationService.validerRegulation(regulation.id)

      if (response.hasError) {
        toast.error(response.status?.message || "Erreur lors de la validation")
      } else {
        toast.success("Régulation validée avec succès. Elle sera exécutée à la date programmée.")
        onSuccess()
        onClose()
      }
    } catch (error: any) {
      console.error("Erreur lors de la validation:", error)
      toast.error(error?.message || "Erreur lors de la validation de la régulation")
    } finally {
      setIsSubmitting(false)
    }
  }

  if (!isOpen || !regulation) return null

  const dateRecup = regulation.dateRecuperation
    ? new Date(regulation.dateRecuperation).toLocaleDateString("fr-FR")
    : "Non définie"

  const taux = regulation.tauxRecuperation
    ? `${(regulation.tauxRecuperation * 100).toFixed(0)}%`
    : "100%"

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-content max-w-lg" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold">Valider une Régulation</h3>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600">
            <XCircleIcon className="h-6 w-6" />
          </button>
        </div>

        <div className="mb-4 p-4 bg-blue-50 border border-blue-200 rounded-lg">
          <p className="text-sm font-medium text-blue-900 mb-2">Détails de la régulation</p>
          <div className="space-y-1 text-sm text-blue-800">
            <p>
              <strong>Référence:</strong> {regulation.reference}
            </p>
            <p>
              <strong>Date de récupération:</strong> {dateRecup}
            </p>
            <p>
              <strong>Taux de récupération:</strong> {taux}
            </p>
            {regulation.commentaire && (
              <p>
                <strong>Commentaire:</strong> {regulation.commentaire}
              </p>
            )}
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {submitBlockedReason && (
            <div className="p-4 bg-gray-100 border border-gray-300 rounded-lg text-sm text-gray-800">
              {submitBlockedReason}
            </div>
          )}
          <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
            <p className="text-sm text-yellow-800">
              <strong>Attention:</strong> Valider uniquement lorsque vous avez physiquement reçu les manuels des EPP.
              La récupération des stocks sera enregistrée immédiatement (passage en terminé).
            </p>
          </div>

          <div className="flex justify-end space-x-3 mt-6">
            <button
              type="button"
              onClick={onClose}
              className="btn-outline"
              disabled={isSubmitting}
            >
              Annuler
            </button>
            <button
              type="submit"
              className="btn-primary"
              disabled={isSubmitting || !!submitBlockedReason}
              title={submitBlockedReason ?? undefined}
            >
              {isSubmitting ? (
                "Validation..."
              ) : (
                <>
                  <CheckCircleIcon className="h-5 w-5 mr-2 inline" />
                  Valider la Régulation
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}




