/**
 * Composant de formulaire de distribution avec validation de stock
 * Reproduit EXACTEMENT le formulaire de réception pour la distribution
 */

import React, { useState, useEffect } from 'react';
import { useMatieres } from '@/hooks/use-matieres';
import { useAnneesScolaires } from '@/hooks/use-annees-scolaires';
import { distributionService, DistributionData, MatiereQuantiteDistributionData } from '@/lib/services/distribution.service';
import { catalogueService } from '@/lib/services/catalogue.service';
import { DocumentTextIcon, CheckIcon, XCircleIcon, PlusIcon, ClipboardDocumentListIcon, PaperClipIcon } from '@heroicons/react/24/outline';
import toast from 'react-hot-toast';

interface DistributionFormProps {
  /** Reçoit une seule distribution ou un tableau (une par catalogue, effectifs par catalogue) */
  onSubmit: (distributionData: DistributionData | DistributionData[]) => void;
  onCancel: () => void;
  loading?: boolean;
  userStructure?: any;
  receptionStatut?: string;
}

interface FormData {
  date_distribution: string;
  observations: string;
  manuels: any[];
  /** Effectifs globaux (optionnel quand on utilise effectifs par catalogue) */
  effectifGarcons: number;
  effectifFilles: number;
  /** 2e vague (ex. après stock reçu par régulation) — effectifs par catalogue = élèves concernés restant */
  complementaire: boolean;
  fichiers: File[];
}

interface Catalogue {
  id: number;
  libelle: string; // ← Ajouté pour correspondre au mapping
  niveauScolaire: string;
  niveauScolaireId: number; // ← Ajouté pour le niveauId
  niveauCode: string;
  code: string;
  anneeScolaire: string;
  icone: string;
  matieres: any[];
  quantitesSaisies: any[];
  /** Effectifs pour ce catalogue (comme BesoinForm) */
  effectifGarcons?: number;
  effectifFilles?: number;
}

export default function DistributionForm({ onSubmit, onCancel, loading = false, userStructure }: DistributionFormProps) {
  const { matieres, loading: matieresLoading } = useMatieres();
  const { anneesScolaires: annees, loading: anneesLoading } = useAnneesScolaires();

  // État du formulaire principal (identique à receptionFormData)
  const [distributionFormData, setDistributionFormData] = useState<FormData>({
    date_distribution: new Date().toISOString().split('T')[0], // Date du jour
    observations: '',
    manuels: [],
    effectifGarcons: 0, // ✅ NOUVEAU : Effectif garçons
    effectifFilles: 0,   // ✅ NOUVEAU : Effectif filles
    complementaire: false,
    fichiers: []        // ✅ NOUVEAU : Fichiers à uploader
  });
  
  // ✅ NOUVEAU : État pour l'upload de fichiers
  const [uploadingFiles, setUploadingFiles] = useState(false);

  // États identiques au formulaire de réception
  const [selectedCatalogueId, setSelectedCatalogueId] = useState<string>('');
  const [availableCatalogues, setAvailableCatalogues] = useState<Catalogue[]>([]);
  const [selectedCatalogues, setSelectedCatalogues] = useState<Catalogue[]>([]);
  const [currentCatalogueData, setCurrentCatalogueData] = useState<Catalogue | null>(null);
  const [catalogueMatieres, setCatalogueMatieres] = useState<any[]>([]);
  const [loadingCatalogues, setLoadingCatalogues] = useState(false);
  const [stockDisponible, setStockDisponible] = useState<Record<number, number>>({});
  const [loadingStocks, setLoadingStocks] = useState(false);
  const [error, setError] = useState<string>('');
  /** Effectifs du catalogue en cours de sélection (avant ajout au tableau) */
  const [currentCatalogueEffectifs, setCurrentCatalogueEffectifs] = useState({ effectifGarcons: 0, effectifFilles: 0 });

  // Fonction utilitaire pour obtenir l'icône du catalogue (identique à la réception)
  const getCatalogueIcon = (niveauCode: string) => {
    const iconMap: { [key: string]: string } = {
      'CP1': '📚',
      'CP2': '📖',
      'CE1': '📘',
      'CE2': '📗',
      'CM1': '📙',
      'CM2': '📕'
    };
    return iconMap[niveauCode] || '📄';
  };

  // Charger les stocks disponibles
  useEffect(() => {
    if (userStructure?.id && currentCatalogueData) {
      loadStockDisponible();
    }
  }, [userStructure?.id, currentCatalogueData]);

  /**
   * Charge les catalogues actifs pour l'année indiquée (sinon année courante côté API).
   */
  const loadCatalogues = async (anneeScolaireId?: number) => {
    setLoadingCatalogues(true);
    setError('');
    
    try {
      console.log('📚 Chargement des catalogues pour distribution...');
      
      const result = await catalogueService.getCataloguesActifs(anneeScolaireId);
      
      console.log('📚 Résultat service catalogue:', result);
      
      if (result.hasError) {
        throw new Error(result.status?.message || 'Erreur lors de la récupération des catalogues');
      }

      // Vérifier que les données sont présentes
      if (!result.items || !Array.isArray(result.items)) {
        console.error('Format de données invalide:', result);
        if (result.status && result.status.message) {
          throw new Error(result.status.message);
        }
        throw new Error('Aucune donnée reçue du serveur');
      }

      // Mapper les données backend vers le format frontend (identique à la réception)
      const mappedCatalogues: Catalogue[] = result.items.map((catalogue: any) => {
        // 🔍 DEBUG: Log détaillé pour chaque catalogue
        const niveauId = catalogue.niveauScolaire?.id || catalogue.niveauScolaireId || catalogue.idNiveauScolaire || 0;
        const niveauCode = catalogue.niveauScolaire?.code || catalogue.niveauScolaireCode || 'N/A';
        const niveauLibelle = catalogue.niveauScolaire?.libelle || catalogue.niveauScolaireLibelle || 'N/A';
        
        console.log(`🔍 Mapping catalogue ${catalogue.id} (${catalogue.libelle}):`, {
          'niveauScolaire.id': catalogue.niveauScolaire?.id,
          'niveauScolaireId': catalogue.niveauScolaireId,
          'idNiveauScolaire': catalogue.idNiveauScolaire,
          'niveauCode': niveauCode,
          'niveauLibelle': niveauLibelle,
          'niveauId final': niveauId
        });
        
        return {
        id: catalogue.id,
        libelle: catalogue.libelle,
        code: catalogue.code,
        anneeScolaire: catalogue.anneeScolaire?.libelle || catalogue.anneeScolaireLibelle || 'N/A',
          niveauScolaire: niveauLibelle,
          niveauScolaireId: niveauId, // ✅ Utiliser le niveauId extrait avec fallback
          niveauCode: niveauCode,
          icone: getCatalogueIcon(niveauCode),
        matieres: catalogue.matieres || [],
        quantitesSaisies: []
        };
      });

      console.log('📚 Catalogues mappés pour distribution:', mappedCatalogues);
      console.log('🔍 DEBUG niveauId dans les catalogues mappés:');
      mappedCatalogues.forEach((cat, index) => {
        console.log(`  [${index}] Catalogue ${cat.libelle} (${cat.niveauCode}): niveauScolaireId = ${cat.niveauScolaireId}`);
      });
      
      setAvailableCatalogues(mappedCatalogues);
      
      if (mappedCatalogues.length === 0) {
        toast.error("Aucun catalogue actif trouvé", {
          icon: '⚠️'
        });
      }
      
    } catch (error) {
      console.error('Erreur lors du chargement des catalogues:', error);
      const errorMessage = error instanceof Error ? error.message : 'Erreur inconnue';
      setError(errorMessage);
      toast.error(`Erreur lors du chargement des catalogues: ${errorMessage}`);
      setAvailableCatalogues([]);
    } finally {
      setLoadingCatalogues(false);
    }
  };

  useEffect(() => {
    if (anneesLoading) return;
    const courante = annees.find((a) => a.estCourante)?.id ?? annees[0]?.id;
    void loadCatalogues(courante);
  }, [anneesLoading, annees]);

  /**
   * Charge les stocks disponibles pour l'EPP de l'utilisateur
   */
  const loadStockDisponible = async () => {
    if (!userStructure?.id || !currentCatalogueData) return;

    setLoadingStocks(true);
    try {
      const stocks: Record<number, number> = {};
      
      for (const matiere of currentCatalogueData.matieres) {
        try {
          // ✅ CORRECTION : Ajouter le niveauId requis par le backend
          const response = await distributionService.getStockDisponible(
            userStructure.id, 
            matiere.id, 
            currentCatalogueData.niveauScolaireId
          );
          if (response.success && response.data) {
            stocks[matiere.id] = response.data.stockDisponible || 0;
          } else {
            stocks[matiere.id] = 0;
          }
        } catch (error) {
          console.error(`Erreur stock pour matière ${matiere.id}:`, error);
          stocks[matiere.id] = 0;
        }
      }
      
      setStockDisponible(stocks);
    } catch (error) {
      console.error('Erreur lors du chargement des stocks:', error);
      toast.error('Erreur lors du chargement des stocks');
    } finally {
      setLoadingStocks(false);
    }
  };

  /**
   * Récupère les stocks pour les matières données (identique à la réception)
   */
  const fetchStockDisponible = async (matieres: any[], catalogue?: Catalogue | null) => {
    if (!userStructure?.id || !matieres.length) return;

    // ✅ CORRECTION : Utiliser le catalogue passé en paramètre ou currentCatalogueData
    const catalogueToUse = catalogue || currentCatalogueData;
    if (!catalogueToUse) {
      console.warn('⚠️ Aucun catalogue disponible pour charger les stocks');
      return;
    }

    setLoadingStocks(true);
    try {
      console.log('📊 Chargement des stocks pour matières:', matieres.map(m => m.libelle));
      
      // ✅ CORRECTION : Récupérer le niveauId du catalogue passé en paramètre
      const niveauId = catalogueToUse.niveauScolaireId;
      console.log('📊 Niveau ID utilisé:', niveauId, `(Catalogue: ${catalogueToUse.libelle}, Niveau: ${catalogueToUse.niveauCode})`);
      
      const stockData: Record<number, number> = {};
      
      // Charger le stock pour chaque matière
      for (const matiere of matieres) {
        try {
          // ✅ CORRECTION : Ajouter le niveauId requis par le backend
          const result = await distributionService.getStockDisponible(userStructure.id, matiere.id, niveauId);
          
          if (result.success && result.data) {
            stockData[matiere.id] = result.data.stockDisponible;
            console.log(`📊 Stock ${matiere.libelle} (Niveau ${niveauId}):`, result.data.stockDisponible);
            
            // Si le stock est à 0, lancer un debug
            if (result.data.stockDisponible === 0) {
              console.log(`🔍 Stock à 0 pour ${matiere.libelle}, lancement du debug...`);
              try {
                const debugResult = await distributionService.debugStock(userStructure.id, matiere.id, niveauId);
                if (debugResult.success && debugResult.data) {
                  console.log(`🔍 Debug info pour ${matiere.libelle}:`, debugResult.data);
                }
              } catch (debugError) {
                console.error(`❌ Erreur debug pour ${matiere.libelle}:`, debugError);
              }
            }
          } else {
            console.warn(`⚠️ Pas de stock trouvé pour ${matiere.libelle}`);
            stockData[matiere.id] = 0;
          }
        } catch (error) {
          console.error(`❌ Erreur stock ${matiere.libelle}:`, error);
          stockData[matiere.id] = 0;
        }
      }
      
      setStockDisponible(stockData);
      console.log('📊 Stocks chargés:', stockData);
      
    } catch (error) {
      console.error('❌ Erreur lors du chargement des stocks:', error);
      toast.error('Erreur lors du chargement des stocks');
    } finally {
      setLoadingStocks(false);
    }
  };

  /**
   * Gère la sélection d'un catalogue (identique à la réception)
   */
  const handleCatalogueSelect = async (catalogueId: string) => {
    if (!catalogueId) {
      setSelectedCatalogueId('');
      setCurrentCatalogueData(null);
      setCatalogueMatieres([]);
      return;
    }
    
    const catalogue = availableCatalogues.find(c => c.id.toString() === catalogueId);
    if (!catalogue) {
      console.error(`❌ Catalogue ${catalogueId} non trouvé dans availableCatalogues`);
      return;
    }
    
    // 🔍 DEBUG: Vérifier le catalogue trouvé avant de le stocker
    console.log('🔍 DEBUG handleCatalogueSelect - Catalogue trouvé:', {
      'catalogueId sélectionné': catalogueId,
      'catalogue.id': catalogue.id,
      'catalogue.libelle': catalogue.libelle,
      'catalogue.niveauCode': catalogue.niveauCode,
      'catalogue.niveauScolaire': catalogue.niveauScolaire,
      'catalogue.niveauScolaireId': catalogue.niveauScolaireId,
      'type niveauScolaireId': typeof catalogue.niveauScolaireId
    });
    
    // ✅ Vérification de cohérence : le niveauId doit correspondre au niveauCode
    if (catalogue.niveauScolaireId === 0 || !catalogue.niveauScolaireId) {
      console.error(`⚠️ ATTENTION: Catalogue ${catalogue.libelle} a un niveauScolaireId invalide (${catalogue.niveauScolaireId})`);
      toast.error(`Erreur: Le catalogue ${catalogue.libelle} n'a pas de niveau scolaire valide`);
      return;
    }
    
    setSelectedCatalogueId(catalogueId);
    setCurrentCatalogueData(catalogue);
    setCurrentCatalogueEffectifs({ effectifGarcons: 0, effectifFilles: 0 });
    setError('');
    
    // Récupérer les matières associées à ce catalogue
    await fetchCatalogueMatieres(parseInt(catalogueId));
  };

  /**
   * Récupère les matières d'un catalogue (identique à la réception)
   */
  const fetchCatalogueMatieres = async (catalogueId: number) => {
    try {
      console.log('📚 Récupération des matières pour catalogue:', catalogueId);
      
      // Utiliser le service catalogue comme dans les paramétrages
      const result = await catalogueService.getMatieresByCatalogue(catalogueId);
      
      console.log('📚 Données matières reçues pour catalogue', catalogueId, ':', result);
      
      if (result.hasError) {
        throw new Error(result.status?.message || 'Erreur lors de la récupération des matières');
      }

      // Mapper les matières reçues (les données sont déjà aplaties)
      const matieres = result.items?.map((cm: any) => ({
        id: cm.matiereId,
        code: cm.matiereCode,
        libelle: cm.matiereLibelle,
        quantite_prevue: 0 // Valeur par défaut pour la quantité prévue
      })) || [];

      console.log('📚 Matières mappées:', matieres);
      
      setCatalogueMatieres(matieres);
      
      // ✅ CORRECTION : Passer le catalogue actuel pour éviter le problème de timing avec currentCatalogueData
      // Récupérer le catalogue depuis availableCatalogues pour avoir la version à jour
      const catalogueActuel = availableCatalogues.find(c => c.id === catalogueId);
      if (catalogueActuel) {
        console.log('🔍 Catalogue actuel pour stocks:', {
          id: catalogueActuel.id,
          libelle: catalogueActuel.libelle,
          niveauCode: catalogueActuel.niveauCode,
          niveauScolaireId: catalogueActuel.niveauScolaireId
        });
        // Récupérer les stocks pour ces matières avec le catalogue en paramètre
        await fetchStockDisponible(matieres, catalogueActuel);
      } else {
        console.warn('⚠️ Catalogue non trouvé pour charger les stocks');
      await fetchStockDisponible(matieres);
      }
      
    } catch (error) {
      console.error('Erreur lors de la récupération des matières du catalogue:', error);
      toast.error("Erreur lors du chargement des matières du catalogue");
      setCatalogueMatieres([]);
    }
  };

  /**
   * Ajoute le catalogue sélectionné au tableau (identique à la réception)
   */
  const addCatalogueToTable = () => {
    if (!selectedCatalogueId || !currentCatalogueData) {
      setError('Veuillez sélectionner un catalogue');
      return;
    }

    const totalEffectifCatalogue =
      (currentCatalogueEffectifs.effectifGarcons || 0) + (currentCatalogueEffectifs.effectifFilles || 0);
    if (totalEffectifCatalogue <= 0) {
      toast.error(
        distributionFormData.complementaire
          ? 'Veuillez renseigner le nombre de garçons et de filles concernés restant avant d’ajouter le catalogue.'
          : 'Veuillez renseigner l’effectif de classe (garçons/filles) avant d’ajouter le catalogue.'
      );
      return;
    }

    // Vérifier si le catalogue est déjà sélectionné
    const isAlreadySelected = selectedCatalogues.some(c => c.id === currentCatalogueData.id);
    if (isAlreadySelected) {
      setError('Ce catalogue est déjà sélectionné');
      return;
    }

    // Ajouter le catalogue avec les quantités et effectifs (par catalogue, comme BesoinForm)
    const catalogueWithQuantites = {
      ...currentCatalogueData,
      effectifGarcons: currentCatalogueEffectifs.effectifGarcons,
      effectifFilles: currentCatalogueEffectifs.effectifFilles,
      quantitesSaisies: catalogueMatieres.map((matiere: any) => ({
        matiereId: matiere.id,
        code: matiere.code,
        libelle: matiere.libelle,
        quantite_prevue: matiere.quantite_prevue || 0,
        quantite_recue: distributionFormData.manuels.find((m: any) => m.matiereId === matiere.id)?.quantite_recue || 0
      }))
    };

    setSelectedCatalogues(prev => [...prev, catalogueWithQuantites]);
    setSelectedCatalogueId('');
    setCurrentCatalogueData(null);
    setCurrentCatalogueEffectifs({ effectifGarcons: 0, effectifFilles: 0 });
    setError('');
  };

  /** Met à jour les effectifs d'un catalogue déjà dans le tableau (comme BesoinForm) */
  const handleUpdateCatalogueEffectifs = (catalogueId: number, field: 'effectifGarcons' | 'effectifFilles', value: number) => {
    setSelectedCatalogues(prev =>
      prev.map(c =>
        c.id === catalogueId
          ? { ...c, [field]: value }
          : c
      )
    );
  };

  /**
   * Retire un catalogue du tableau (identique à la réception)
   */
  const removeCatalogueFromTable = (catalogueId: number) => {
    setSelectedCatalogues(prev => prev.filter(c => c.id !== catalogueId));
  };

  /**
   * Valide le formulaire avant soumission (identique à la réception)
   */
  const validateForm = (): boolean => {
    if (!distributionFormData.date_distribution) {
      toast.error("Veuillez saisir la date de distribution");
      return false;
    }

    if (selectedCatalogues.length === 0) {
      toast.error("Veuillez sélectionner au moins un catalogue");
      return false;
    }

    // Validation des quantités saisies pour tous les catalogues
    const hasQuantities = selectedCatalogues.some(catalogue => 
      catalogue.quantitesSaisies && catalogue.quantitesSaisies.some(q => q.quantite_recue > 0)
    );
    if (!hasQuantities) {
      toast.error("Veuillez saisir au moins une quantité pour un catalogue");
      return false;
    }

    // Validation métier : l'effectif doit être renseigné pour chaque niveau (catalogue)
    const cataloguesSansEffectif = selectedCatalogues.filter((catalogue) => {
      const total = (catalogue.effectifGarcons ?? 0) + (catalogue.effectifFilles ?? 0);
      return total <= 0;
    });
    if (cataloguesSansEffectif.length > 0) {
      toast.error(
        distributionFormData.complementaire
          ? 'Veuillez renseigner, pour chaque catalogue, le nombre de garçons et de filles concernés restant.'
          : 'Veuillez renseigner l’effectif (garçons/filles) pour chaque catalogue sélectionné.'
      );
      return false;
    }
    
    return true;
  };

  /**
   * ✅ NOUVEAU : Gère la sélection de fichiers
   */
  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    if (files.length > 0) {
      setDistributionFormData({
        ...distributionFormData,
        fichiers: [...distributionFormData.fichiers, ...files]
      });
    }
  };

  /**
   * ✅ NOUVEAU : Retire un fichier de la liste
   */
  const removeFile = (index: number) => {
    const newFiles = distributionFormData.fichiers.filter((_, i) => i !== index);
    setDistributionFormData({
      ...distributionFormData,
      fichiers: newFiles
    });
  };

  /**
   * Soumet le formulaire : une distribution par catalogue (effectifs par catalogue, comme avant)
   */
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) return;
    
    // Utiliser en priorité l'année scolaire marquée comme courante,
    // sinon basculer sur la première année disponible
    const currentAnnee =
      annees && annees.length > 0
        ? (annees.find((a: any) => a.estCourante) || annees[0])
        : null;
    const eppId = userStructure?.id || 0;
    const userId = 1; // TODO: récupérer l'utilisateur connecté

    // Une distribution par catalogue (niveau + effectifs + matières de ce catalogue)
    const payloads: DistributionData[] = selectedCatalogues.map((catalogue) => {
      const matiereQuantites = (catalogue.quantitesSaisies || [])
        .filter((q: any) => (q.quantite_recue ?? 0) > 0)
        .map((q: any) => ({
          matiereId: q.matiereId,
          matiereCode: q.code || '',
          quantite: q.quantite_recue ?? 0
        }));
      return {
        eppId,
        userId,
        matiereQuantites,
        distributionData: {
          structureId: eppId,
          anneeScolaireId: currentAnnee?.id || 1,
          niveauId: catalogue.niveauScolaireId,
          classe: "DISTRIBUTION",
          dateDistribution: distributionFormData.date_distribution,
          effectifGarcons: catalogue.effectifGarcons ?? 0,
          effectifFilles: catalogue.effectifFilles ?? 0,
          complementaire: distributionFormData.complementaire,
          distribuePar: userId,
          commentaire: distributionFormData.observations || "Distribution de matériel"
        },
        fichiers: catalogue === selectedCatalogues[0] ? distributionFormData.fichiers : undefined
      };
    });

    console.log('📤 Données de distribution (une par catalogue):', payloads);
    onSubmit(payloads.length === 1 ? payloads[0] : payloads);
  };

  // Les matières du catalogue courant sont maintenant gérées par l'état catalogueMatieres

  const effLibelles = distributionFormData.complementaire
    ? {
        garcons: 'Garçons concernés restant',
        filles: 'Filles concernées restant',
        total: 'Total élèves pour ce lot',
        hint: 'Comptez uniquement les élèves touchés restant complémentaire, pas l’effectif total de la classe.',
        colG: 'Garçons (lot)',
        colF: 'Filles (lot)',
        colT: 'Total (lot)',
        resumeTotal: 'Total élèves concernés restant (tous catalogues)',
      }
    : {
        garcons: 'Effectif Garçons',
        filles: 'Effectif Filles',
        total: 'Effectif classe',
        hint: 'Ces effectifs servent à tracer la distribution par niveau/classe.',
        colG: 'Effectif G.',
        colF: 'Effectif F.',
        colT: 'Effectif classe',
        resumeTotal: 'Effectif total (tous catalogues)',
      }

  return (
    <div className="max-w-6xl mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-xl font-bold text-gray-900 flex items-center gap-3">
          <PlusIcon className="h-6 w-6 text-gray-700" />
          Nouvelle Distribution - EPP
        </h3>
        <button 
          onClick={onCancel} 
          className="text-gray-400 hover:text-gray-600 transition-colors"
          disabled={loading}
        >
          <XCircleIcon className="h-6 w-6" />
        </button>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="rounded-lg border border-amber-200 bg-amber-50/80 p-4">
          <label className="flex cursor-pointer items-start gap-3">
            <input
              type="checkbox"
              className="mt-1 h-4 w-4 rounded border-gray-300 text-amber-700 focus:ring-amber-500"
              checked={distributionFormData.complementaire}
              onChange={(e) =>
                setDistributionFormData((prev) => ({ ...prev, complementaire: e.target.checked }))
              }
              disabled={loading}
            />
            <span>
              <span className="font-semibold text-gray-900">Distribution complémentaire</span>
              <span className="block text-sm text-gray-700 mt-1">
                À cocher si une distribution est déjà finalisée pour cette année et que vous distribuez du stock
                reçu après régulation (IEPP). Les effectifs saisis par catalogue représentent alors uniquement les
                élèves concernés restant, pas l’effectif total de classe.
              </span>
            </span>
          </label>
        </div>

        {/* Sélection de Catalogue (identique à la réception) */}
        <div className="bg-gray-50 p-4 rounded-lg">
          <h4 className="text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2">
            <ClipboardDocumentListIcon className="h-5 w-5 text-gray-700" />
            Sélection des Catalogues
          </h4>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Choisir un Catalogue
              </label>
              <select
                value={selectedCatalogueId}
                onChange={(e) => handleCatalogueSelect(e.target.value)}
                className={`w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-gray-500 focus:border-transparent ${
                  error ? 'border-red-300' : 'border-gray-300'
                }`}
                disabled={loadingCatalogues}
              >
                <option value="">-- Sélectionner un catalogue --</option>
                {availableCatalogues
                  .filter((catalogue) => !selectedCatalogues.some((c) => c.id === catalogue.id))
                  .map((catalogue) => (
                    <option key={catalogue.id} value={catalogue.id}>
                      {catalogue.icone} {catalogue.niveauScolaire} - {catalogue.code}
                    </option>
                  ))}
              </select>
              
              {error && (
                <div className="mt-2 text-sm text-red-600 flex items-center">
                  <svg className="w-4 h-4 mr-1" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
                  </svg>
                  {error}
                </div>
              )}
            </div>
            <div className="flex items-end">
              <button
                type="button"
                onClick={addCatalogueToTable}
                disabled={!selectedCatalogueId || !currentCatalogueData}
                className="w-full btn-primary disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Ajouter au Tableau
              </button>
            </div>
          </div>

          {/* Affichage du catalogue sélectionné (identique à la réception) */}
          {currentCatalogueData && (
            <div className="bg-white p-4 rounded-lg border mb-4">
              <h5 className="font-semibold text-gray-900 mb-3">
                Catalogue Sélectionné: {currentCatalogueData.niveauScolaire}
              </h5>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm mb-4">
                <div>
                  <span className="font-medium text-gray-700">Code:</span>
                  <span className="ml-2 text-gray-900">{currentCatalogueData.code}</span>
                </div>
                <div>
                  <span className="font-medium text-gray-700">Année:</span>
                  <span className="ml-2 text-gray-900">{currentCatalogueData.anneeScolaire}</span>
                </div>
                <div>
                  <span className="font-medium text-gray-700">Matières:</span>
                  <span className="ml-2 text-gray-900">{catalogueMatieres.length}</span>
                </div>
              </div>

              {/* Effectifs pour ce catalogue */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">{effLibelles.garcons}</label>
                  <input
                    type="number"
                    min={0}
                    value={currentCatalogueEffectifs.effectifGarcons}
                    onChange={(e) => setCurrentCatalogueEffectifs(prev => ({ ...prev, effectifGarcons: parseInt(e.target.value) || 0 }))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-gray-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">{effLibelles.filles}</label>
                  <input
                    type="number"
                    min={0}
                    value={currentCatalogueEffectifs.effectifFilles}
                    onChange={(e) => setCurrentCatalogueEffectifs(prev => ({ ...prev, effectifFilles: parseInt(e.target.value) || 0 }))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-gray-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">{effLibelles.total}</label>
                  <input
                    type="number"
                    value={(currentCatalogueEffectifs.effectifGarcons || 0) + (currentCatalogueEffectifs.effectifFilles || 0)}
                    readOnly
                    className="w-full px-3 py-2 border border-gray-200 bg-gray-100 text-gray-700 rounded-md cursor-not-allowed"
                  />
                </div>
              </div>
              <p className="text-xs text-gray-500 mb-2">{effLibelles.hint}</p>

              {/* Matières avec champs de quantités (identique à la réception) */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <h6 className="font-medium text-gray-900">Saisir les quantités:</h6>
                  {loadingStocks && (
                    <div className="flex items-center text-sm text-gray-500">
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-gray-500 mr-2"></div>
                      Chargement des stocks...
                    </div>
                  )}
                </div>
                
                {catalogueMatieres.length === 0 ? (
                  <div className="text-center py-4 text-gray-500">
                    Aucune matière trouvée pour ce catalogue
                  </div>
                ) : (
                  catalogueMatieres.map((matiere: any) => {
                    const quantiteRecue = distributionFormData.manuels.find((m: any) => m.matiereId === matiere.id)?.quantite_recue || 0
                    const stockActuel = stockDisponible[matiere.id] || 0
                    
                    return (
                      <div key={matiere.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div className="flex-1">
                          <div className="font-medium text-gray-900">{matiere.libelle}</div>
                          <div className="text-sm text-gray-600">
                            Code: {matiere.code} | Prévu: {matiere.quantite_prevue}
                            {userStructure?.id && (
                              <span className={`ml-2 ${stockActuel > 0 ? 'text-green-600' : 'text-red-600'}`}>
                                | Stock disponible: {stockActuel}
                              </span>
                            )}
                          </div>
                        </div>
                        <div className="ml-4">
                          <input
                            type="number"
                            value={quantiteRecue}
                            onChange={(e) => {
                              const newQuantite = parseInt(e.target.value) || 0
                              
                              // Validation pour distribution : ne pas dépasser le stock disponible
                              if (userStructure?.id && newQuantite > stockActuel) {
                                toast.error(`Stock insuffisant pour ${matiere.libelle}. Stock disponible: ${stockActuel}`)
                                return
                              }
                              
                              const newManuels = [...distributionFormData.manuels]
                              const existingIndex = newManuels.findIndex((m: any) => m.matiereId === matiere.id)
                              
                              if (existingIndex >= 0) {
                                newManuels[existingIndex].quantite_recue = newQuantite
                              } else {
                                newManuels.push({
                                  matiereId: matiere.id,
                                  code: matiere.code,
                                  libelle: matiere.libelle,
                                  quantite_prevue: matiere.quantite_prevue,
                                  quantite_recue: newQuantite
                                })
                              }
                              
                              setDistributionFormData({...distributionFormData, manuels: newManuels})
                            }}
                            className="w-24 px-3 py-2 text-center border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-gray-500 focus:border-transparent"
                            min="0"
                            max={userStructure?.id ? stockActuel : undefined}
                            placeholder="0"
                            disabled={loadingStocks}
                          />
                        </div>
                      </div>
                    )
                  })
                )}
              </div>
            </div>
          )}

          {/* Tableau des catalogues sélectionnés (identique à la réception) */}
          {selectedCatalogues.length > 0 && (
            <div className="mt-6">
              <h5 className="font-semibold text-gray-900 mb-3">
                Catalogues Sélectionnés ({selectedCatalogues.length})
              </h5>
              <div className="overflow-x-auto">
                <table className="min-w-full bg-white border border-gray-200 rounded-lg">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Catalogue</th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Niveau</th>
                      <th
                        className="px-4 py-3 text-left text-xs font-medium text-gray-500 tracking-wide max-w-[9rem] leading-tight"
                        title={effLibelles.garcons}
                      >
                        {effLibelles.colG}
                      </th>
                      <th
                        className="px-4 py-3 text-left text-xs font-medium text-gray-500 tracking-wide max-w-[9rem] leading-tight"
                        title={effLibelles.filles}
                      >
                        {effLibelles.colF}
                      </th>
                      <th
                        className="px-4 py-3 text-left text-xs font-medium text-gray-500 tracking-wide max-w-[9rem] leading-tight"
                        title={effLibelles.total}
                      >
                        {effLibelles.colT}
                      </th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Matières</th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Quantités Saisies</th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {selectedCatalogues.map((catalogue) => (
                      <tr key={catalogue.id} className="hover:bg-gray-50">
                        <td className="px-4 py-3 text-sm">
                          <div className="flex items-center">
                            <span className="text-lg mr-2">{catalogue.icone}</span>
                            <div>
                              <div className="font-medium text-gray-900">{catalogue.niveauScolaire}</div>
                              <div className="text-gray-500 text-xs">{catalogue.code}</div>
                            </div>
                          </div>
                        </td>
                        <td className="px-4 py-3 text-sm">
                          <span className="inline-flex px-2 py-1 text-xs font-semibold rounded-full bg-blue-100 text-blue-800">
                            {catalogue.niveauCode}
                          </span>
                        </td>
                        <td className="px-4 py-3 text-sm">
                          <input
                            type="number"
                            min={0}
                            value={catalogue.effectifGarcons ?? 0}
                            onChange={(e) => handleUpdateCatalogueEffectifs(catalogue.id, 'effectifGarcons', parseInt(e.target.value) || 0)}
                            className="w-20 px-2 py-1 text-sm border border-gray-300 rounded focus:outline-none focus:ring-1 focus:ring-gray-500"
                          />
                        </td>
                        <td className="px-4 py-3 text-sm">
                          <input
                            type="number"
                            min={0}
                            value={catalogue.effectifFilles ?? 0}
                            onChange={(e) => handleUpdateCatalogueEffectifs(catalogue.id, 'effectifFilles', parseInt(e.target.value) || 0)}
                            className="w-20 px-2 py-1 text-sm border border-gray-300 rounded focus:outline-none focus:ring-1 focus:ring-gray-500"
                          />
                        </td>
                        <td className="px-4 py-3 text-sm">
                          <span className="inline-flex px-2.5 py-1 text-xs font-semibold rounded-full bg-indigo-100 text-indigo-800">
                            {(catalogue.effectifGarcons ?? 0) + (catalogue.effectifFilles ?? 0)}
                          </span>
                        </td>
                        <td className="px-4 py-3 text-sm text-gray-900">
                          {catalogue.quantitesSaisies.length} matière(s)
                        </td>
                        <td className="px-4 py-3 text-sm">
                          <div className="space-y-1">
                            {catalogue.quantitesSaisies.map((q: any, index: number) => (
                              <div key={index} className="text-xs">
                                {q.libelle}: <span className="font-medium text-green-600">{q.quantite_recue}</span>
                              </div>
                            ))}
                            {catalogue.quantitesSaisies.length === 0 && (
                              <span className="text-gray-400 text-xs">Aucune quantité saisie</span>
                            )}
                          </div>
                        </td>
                        <td className="px-4 py-3 text-sm">
                          <button
                            type="button"
                            onClick={() => removeCatalogueFromTable(catalogue.id)}
                            className="text-red-600 hover:text-red-800 text-xs font-medium"
                          >
                            Retirer
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>

        {/* Informations de Base (adapté pour la distribution) */}
        <div className="bg-gray-50 p-4 rounded-lg">
          <h4 className="text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2">
            <DocumentTextIcon className="h-5 w-5 text-gray-700" />
            Informations de Distribution
          </h4>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Date de Distribution <span className="text-red-500">*</span>
              </label>
              <input
                type="date"
                value={distributionFormData.date_distribution}
                onChange={(e) => {
                  setDistributionFormData({
                    ...distributionFormData,
                    date_distribution: e.target.value
                  })
                }}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-gray-500 focus:border-transparent"
                required
              />
            </div>
          </div>
          {selectedCatalogues.length > 0 && (() => {
            const totalG = selectedCatalogues.reduce((s, c) => s + (c.effectifGarcons ?? 0), 0);
            const totalF = selectedCatalogues.reduce((s, c) => s + (c.effectifFilles ?? 0), 0);
            if (totalG + totalF === 0) return null;
            return (
              <div className="mt-4 p-3 bg-blue-50 border border-blue-200 rounded-md">
                <p className="text-sm text-blue-800">
                  <span className="font-semibold">{effLibelles.resumeTotal} :</span> {totalG + totalF} élèves
                  ({totalG} garçons + {totalF} filles)
                </p>
              </div>
            );
          })()}
        </div>

        {/* Observations (identique à la réception) */}
        <div className="bg-gray-50 p-4 rounded-lg">
          <h4 className="text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2">
            <DocumentTextIcon className="h-5 w-5 text-gray-700" />
            Observations
          </h4>
          
          <textarea
            value={distributionFormData.observations}
            onChange={(e) => setDistributionFormData({
              ...distributionFormData,
              observations: e.target.value
            })}
            placeholder="Observations sur la distribution (optionnel)"
            rows={3}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-gray-500 focus:border-transparent"
          />
        </div>

        {/* ✅ NOUVEAU : Section upload de fichiers */}
        <div className="bg-gray-50 p-4 rounded-lg">
          <h4 className="text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2">
            <PaperClipIcon className="h-5 w-5 text-gray-700" />
            Fichiers Joints (optionnel)
          </h4>
          
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Ajouter des fichiers (fiches d'émargement, photos, documents)
              </label>
              <input
                type="file"
                multiple
                accept=".pdf,.doc,.docx,.jpg,.jpeg,.png,.xls,.xlsx"
                onChange={handleFileSelect}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-gray-500 focus:border-transparent"
              />
              <p className="mt-1 text-xs text-gray-500">
                Formats acceptés: PDF, Word, Excel, Images (JPG, PNG). Taille max: 10 MB par fichier.
              </p>
            </div>

            {/* Liste des fichiers sélectionnés */}
            {distributionFormData.fichiers.length > 0 && (
              <div className="mt-4 space-y-2">
                <p className="text-sm font-medium text-gray-700">
                  Fichiers sélectionnés ({distributionFormData.fichiers.length}):
                </p>
                <div className="space-y-2">
                  {distributionFormData.fichiers.map((file, index) => (
                    <div
                      key={index}
                      className="flex items-center justify-between p-3 bg-white border border-gray-200 rounded-lg"
                    >
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                          <PaperClipIcon className="h-5 w-5 text-blue-600" />
                        </div>
                        <div>
                          <p className="text-sm font-medium text-gray-900">{file.name}</p>
                          <p className="text-xs text-gray-500">
                            {(file.size / 1024).toFixed(2)} KB
                          </p>
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={() => removeFile(index)}
                        className="text-red-600 hover:text-red-800 text-sm font-medium"
                      >
                        <XCircleIcon className="h-5 w-5" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Actions (identique à la réception) */}
        <div className="flex items-center justify-between mt-6 pt-6 border-t border-gray-200">
          <div className="flex gap-3">
            <button
              type="button"
              onClick={() => {
                // Sauvegarder en tant que tâche
                if (selectedCatalogues.length === 0) {
                  toast.error("Aucun catalogue sélectionné")
                  return
                }
                
                // TODO: Implémenter la sauvegarde de tâche
                toast.success("Tâche sauvegardée avec succès !")
              }}
              className="px-4 py-2 text-gray-700 bg-gray-100 border border-gray-300 rounded-md hover:bg-gray-200 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2 transition-colors"
              disabled={selectedCatalogues.length === 0}
            >
              💾 Sauvegarder comme Tâche
            </button>
          </div>
          
          <div className="flex gap-3">
            <button
              type="button"
              onClick={onCancel}
              className="px-6 py-2 text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2 transition-colors"
              disabled={loading}
            >
              Annuler
            </button>
            <button
              type="submit"
              disabled={loading || selectedCatalogues.length === 0}
              className="px-6 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed flex items-center"
            >
              {loading ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                  Création en cours...
                </>
              ) : (
                <>
                  <CheckIcon className="h-4 w-4 mr-2" />
                  Créer la Distribution
                </>
              )}
            </button>
          </div>
        </div>
      </form>
    </div>
  );
}