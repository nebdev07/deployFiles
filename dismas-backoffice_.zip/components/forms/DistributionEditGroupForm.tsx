"use client"

import React from "react"

type Props = {
  items: any[]
  selectedCatalogueId: string
  addableCatalogues: any[]
  onChangeSelectedCatalogue: (value: string) => void
  onAddCatalogue: () => void
  onRemoveNewItem: (itemIndex: number) => void
  onRemoveExistingItem: (itemIndex: number) => void
  onUpdateItemField: (itemIndex: number, field: "effectifGarcons" | "effectifFilles" | "commentaire", value: any) => void
  onUpdateMatiereQty: (itemIndex: number, mqIndex: number, value: number) => void
  onRemoveMatiere: (itemIndex: number, mqIndex: number) => void
  onSave: () => void
}

export default function DistributionEditGroupForm({
  items,
  selectedCatalogueId,
  addableCatalogues,
  onChangeSelectedCatalogue,
  onAddCatalogue,
  onRemoveNewItem,
  onRemoveExistingItem,
  onUpdateItemField,
  onUpdateMatiereQty,
  onRemoveMatiere,
  onSave,
}: Props) {
  return (
    <div className="space-y-4">
      <div className="bg-gray-50 p-4 rounded-lg border border-gray-200">
        <h4 className="text-lg font-semibold text-gray-900 mb-3">Selection des Catalogues</h4>
        <div className="grid grid-cols-1 sm:grid-cols-[1fr_auto] gap-3">
          <select
            value={selectedCatalogueId}
            onChange={(e) => onChangeSelectedCatalogue(e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-gray-500"
          >
            <option value="">-- Selectionner un catalogue --</option>
            {addableCatalogues.map((c: any) => (
              <option key={c.id} value={c.id}>
                {c.niveauLibelle || c.niveauCode || "Niveau"} - {c.code || c.libelle || `Catalogue ${c.id}`}
              </option>
            ))}
          </select>
          <button type="button" onClick={onAddCatalogue} className="btn-outline btn-sm">
            Ajouter
          </button>
        </div>
      </div>

      {items.map((item: any, itemIdx: number) => (
        <div key={item.id || `new-${itemIdx}`} className="rounded-xl border border-gray-200 overflow-hidden bg-white">
          <div className="px-4 py-3 bg-blue-50/80 border-b border-gray-200 flex items-center justify-between">
            <div>
              <h4 className="text-sm font-semibold text-gray-800">
                Niveau: {item.niveauLibelle || item.niveauCode || "N/A"} | Effectif: {(item.effectifGarcons ?? 0) + (item.effectifFilles ?? 0)}
              </h4>
            </div>
            {item.__isNew ? (
              <button type="button" className="btn-danger btn-sm" onClick={() => onRemoveNewItem(itemIdx)}>
                Retirer
              </button>
            ) : (
              <button type="button" className="btn-danger btn-sm" onClick={() => onRemoveExistingItem(itemIdx)}>
                Supprimer niveau
              </button>
            )}
          </div>

          <div className="px-4 py-4 bg-gray-50/70 border-b border-gray-100">
            <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1">Effectif Garcons</label>
                <input
                  type="number"
                  min={0}
                  value={item.effectifGarcons ?? 0}
                  onChange={(e) => onUpdateItemField(itemIdx, "effectifGarcons", parseInt(e.target.value) || 0)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1">Effectif Filles</label>
                <input
                  type="number"
                  min={0}
                  value={item.effectifFilles ?? 0}
                  onChange={(e) => onUpdateItemField(itemIdx, "effectifFilles", parseInt(e.target.value) || 0)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1">Effectif classe</label>
                <input
                  type="number"
                  readOnly
                  value={(item.effectifGarcons ?? 0) + (item.effectifFilles ?? 0)}
                  className="w-full px-3 py-2 border border-gray-200 bg-gray-100 rounded-md text-sm text-gray-700"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1">Commentaire (optionnel)</label>
                <input
                  type="text"
                  value={item.commentaire ?? ""}
                  onChange={(e) => onUpdateItemField(itemIdx, "commentaire", e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-gray-50">
                <tr>
                  <th className="text-left py-3 px-4 text-xs font-semibold text-gray-500 uppercase tracking-wider">Matiere</th>
                  <th className="text-left py-3 px-4 text-xs font-semibold text-gray-500 uppercase tracking-wider">Code</th>
                  <th className="text-right py-3 px-4 text-xs font-semibold text-gray-500 uppercase tracking-wider">Quantite</th>
                  <th className="text-right py-3 px-4 text-xs font-semibold text-gray-500 uppercase tracking-wider">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {(item.matiereQuantites || []).map((mq: any, mqIdx: number) => (
                  <tr key={`${mq.idMatiere || mqIdx}-${mqIdx}`} className="hover:bg-gray-50/50">
                    <td className="py-3 px-4 font-medium text-gray-900">{mq.matiereLibelle || mq.matiereCode || "N/A"}</td>
                    <td className="py-3 px-4 text-gray-600">{mq.matiereCode || "N/A"}</td>
                    <td className="py-3 px-4 text-right">
                      <input
                        type="number"
                        min={0}
                        value={mq.quantiteRecue ?? mq.quantite ?? 0}
                        onChange={(e) => onUpdateMatiereQty(itemIdx, mqIdx, parseInt(e.target.value) || 0)}
                        className="w-24 ml-auto px-2 py-1 border border-gray-300 rounded text-sm text-right"
                      />
                    </td>
                    <td className="py-3 px-4 text-right">
                      <button type="button" className="btn-danger btn-sm" onClick={() => onRemoveMatiere(itemIdx, mqIdx)}>
                        Retirer
                      </button>
                    </td>
                  </tr>
                ))}
                {(item.matiereQuantites || []).length === 0 && (
                  <tr>
                    <td colSpan={4} className="py-3 px-4 text-center text-gray-500">
                      Aucune matiere pour ce niveau.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      ))}

      <div className="flex justify-end">
        <button type="button" className="btn-primary btn-sm" onClick={onSave}>
          Enregistrer les modifications
        </button>
      </div>
    </div>
  )
}

