"use client"

import { useCallback, useEffect, useMemo, useRef, useState } from "react"
import toast from "react-hot-toast"
import {
  ArrowPathIcon,
  BuildingLibraryIcon,
  ChevronRightIcon,
  MagnifyingGlassIcon,
  PencilIcon,
  PlusIcon,
  TrashIcon,
} from "@heroicons/react/24/outline"
import { structuresService, type Drena, type Epp, type Iepp } from "@/lib/services/structures.service"
import { hasFunctionalityPermission } from "@/lib/utils/functionality-permissions"
import type { LegacyUser } from "@/lib/types/entities"

type PanelUser = LegacyUser & { functionalityPermissions?: string[] }

/** Codes fonctionnalité alignés sur le backend (VIEW_*, CREATE_*, …). */
function fonctionaliteTerritoire(
  entity: "DRENA" | "IEPP" | "EPP",
  kind: "CREATE" | "READ" | "UPDATE" | "DELETE",
): string {
  if (kind === "READ") return `VIEW_${entity}`
  return `${kind}_${entity}`
}

/**
 * Alignement RBAC : le backend peut lier le parent (`DRENA:READ`, `IEPP:UPDATE`…) ou les codes
 * `VIEW_*` / `CREATE_*` (ex. `VIEW_DRENA:READ`). On accepte les deux.
 */
function can(
  perms: string[] | undefined,
  entity: "DRENA" | "IEPP" | "EPP",
  kind: "CREATE" | "READ" | "UPDATE" | "DELETE",
): boolean {
  if (!perms?.length) return true
  const specific = fonctionaliteTerritoire(entity, kind)
  if (hasFunctionalityPermission(perms, specific, kind)) return true
  return hasFunctionalityPermission(perms, entity, kind)
}

function normalizeDescription(v: string | undefined, libelle: string): string {
  const t = (v ?? "").trim()
  return t.length > 0 ? t : libelle.trim() || "-"
}

const PAGE_SIZE = 15
const SEARCH_DEBOUNCE_MS = 400

type DebouncedCodeLibelle = { code: string; libelle: string }

function useDebouncedCodeLibelle(code: string, libelle: string, delayMs: number): DebouncedCodeLibelle {
  const [debounced, setDebounced] = useState<DebouncedCodeLibelle>({ code: "", libelle: "" })
  useEffect(() => {
    const t = window.setTimeout(() => {
      setDebounced({ code: code.trim(), libelle: libelle.trim() })
    }, delayMs)
    return () => window.clearTimeout(t)
  }, [code, libelle, delayMs])
  return debounced
}

function StructureTablePagination({
  pageIndex,
  pageSize,
  total,
  loading,
  onPageChange,
}: {
  pageIndex: number
  pageSize: number
  total: number
  loading: boolean
  onPageChange: (nextIndex: number) => void
}) {
  if (total === 0) return null
  const totalPages = Math.max(1, Math.ceil(total / pageSize))
  if (total <= pageSize && pageIndex === 0) return null
  return (
    <div className="mt-3 flex flex-wrap items-center justify-between gap-2 border-t border-gray-100 pt-2 text-sm text-gray-600">
      <span>
        {total} enregistrement{total > 1 ? "s" : ""} · page {pageIndex + 1} / {totalPages}
      </span>
      <div className="flex gap-2">
        <button
          type="button"
          className="btn-outline px-2 py-1 text-xs disabled:opacity-40"
          disabled={loading || pageIndex <= 0}
          onClick={() => onPageChange(pageIndex - 1)}
        >
          Précédent
        </button>
        <button
          type="button"
          className="btn-outline px-2 py-1 text-xs disabled:opacity-40"
          disabled={loading || pageIndex >= totalPages - 1}
          onClick={() => onPageChange(pageIndex + 1)}
        >
          Suivant
        </button>
      </div>
    </div>
  )
}

function StructureTextFiltersRow({
  code,
  libelle,
  onCodeChange,
  onLibelleChange,
  disabled,
}: {
  code: string
  libelle: string
  onCodeChange: (v: string) => void
  onLibelleChange: (v: string) => void
  disabled?: boolean
}) {
  return (
    <div className="mb-3 flex flex-wrap items-end gap-3 rounded-md border border-gray-100 bg-gray-50 px-3 py-2">
      <MagnifyingGlassIcon className="mb-2 h-5 w-5 shrink-0 text-gray-400" aria-hidden />
      <div className="min-w-[120px] flex-1">
        <label className="mb-0.5 block text-xs font-medium text-gray-600">Code (contient)</label>
        <input
          type="search"
          className="w-full rounded border border-gray-300 px-2 py-1.5 text-sm"
          value={code}
          onChange={(e) => onCodeChange(e.target.value)}
          disabled={disabled}
          placeholder="Ex. DRENA-…"
          autoComplete="off"
        />
      </div>
      <div className="min-w-[160px] flex-[1.2]">
        <label className="mb-0.5 block text-xs font-medium text-gray-600">Libellé (contient)</label>
        <input
          type="search"
          className="w-full rounded border border-gray-300 px-2 py-1.5 text-sm"
          value={libelle}
          onChange={(e) => onLibelleChange(e.target.value)}
          disabled={disabled}
          placeholder="Rechercher…"
          autoComplete="off"
        />
      </div>
    </div>
  )
}

export function ParametragesTerritorialStructuresPanel({ user }: { user: PanelUser }) {
  const role = (user.role?.code || "").toUpperCase()
  const perms = user.functionalityPermissions

  const isAdminLike = role === "ADMIN" || role === "DAF" || role === "DPFC"
  const isDrena = role === "DRENA"
  const isIepp = role === "IEPP"

  const lockedDrenaId = user.drena?.id
  const lockedIeppId = user.iepp?.id

  const [drenas, setDrenas] = useState<Drena[]>([])
  const [iepps, setIepps] = useState<Iepp[]>([])
  const [epps, setEpps] = useState<Epp[]>([])
  const [loadingDrenas, setLoadingDrenas] = useState(false)
  const [loadingIepps, setLoadingIepps] = useState(false)
  const [loadingEpps, setLoadingEpps] = useState(false)

  const [drenaPage, setDrenaPage] = useState(0)
  const [drenaTotal, setDrenaTotal] = useState(0)
  const [ieppPage, setIeppPage] = useState(0)
  const [ieppTotal, setIeppTotal] = useState(0)
  const [eppPage, setEppPage] = useState(0)
  const [eppTotal, setEppTotal] = useState(0)

  const [selectedDrenaId, setSelectedDrenaId] = useState<number | null>(null)
  const [selectedDrenaLibelle, setSelectedDrenaLibelle] = useState<string | null>(null)
  const [selectedIepp, setSelectedIepp] = useState<Iepp | null>(null)
  const prevDrenaForIepp = useRef<number | null>(null)

  const [modal, setModal] = useState<
    | { kind: "closed" }
    | { kind: "drena"; mode: "create" | "edit"; row?: Drena }
    | { kind: "iepp"; mode: "create" | "edit"; row?: Iepp }
    | { kind: "epp"; mode: "create" | "edit"; row?: Epp }
  >({ kind: "closed" })

  const [formLibelle, setFormLibelle] = useState("")
  const [formDescription, setFormDescription] = useState("")

  const [drenaFilterCode, setDrenaFilterCode] = useState("")
  const [drenaFilterLibelle, setDrenaFilterLibelle] = useState("")
  const drenaSearchDebounced = useDebouncedCodeLibelle(drenaFilterCode, drenaFilterLibelle, SEARCH_DEBOUNCE_MS)
  const drenaListFilterKeyRef = useRef<string | null>(null)

  const [ieppFilterCode, setIeppFilterCode] = useState("")
  const [ieppFilterLibelle, setIeppFilterLibelle] = useState("")
  const ieppSearchDebounced = useDebouncedCodeLibelle(ieppFilterCode, ieppFilterLibelle, SEARCH_DEBOUNCE_MS)
  const ieppListFilterKeyRef = useRef<string | null>(null)

  const [eppFilterCode, setEppFilterCode] = useState("")
  const [eppFilterLibelle, setEppFilterLibelle] = useState("")
  const eppSearchDebounced = useDebouncedCodeLibelle(eppFilterCode, eppFilterLibelle, SEARCH_DEBOUNCE_MS)
  const eppListFilterKeyRef = useRef<string | null>(null)

  const canCrudDrena = isAdminLike && can(perms, "DRENA", "CREATE")
  const canReadDrenaList = (isAdminLike && can(perms, "DRENA", "READ")) || isDrena
  const canUpdDrena =
    (isAdminLike && can(perms, "DRENA", "UPDATE")) || (isDrena && can(perms, "DRENA", "UPDATE"))
  const canDelDrena = isAdminLike && can(perms, "DRENA", "DELETE")

  const canCrudIepp =
    (isAdminLike && can(perms, "IEPP", "CREATE")) || (isDrena && can(perms, "IEPP", "CREATE"))
  const canUpdIepp = (isAdminLike && can(perms, "IEPP", "UPDATE")) || (isDrena && can(perms, "IEPP", "UPDATE"))
  const canDelIepp = (isAdminLike && can(perms, "IEPP", "DELETE")) || (isDrena && can(perms, "IEPP", "DELETE"))

  const canCrudEpp =
    (isAdminLike && can(perms, "EPP", "CREATE")) ||
    (isDrena && can(perms, "EPP", "CREATE")) ||
    (isIepp && can(perms, "EPP", "CREATE"))
  const canUpdEpp =
    (isAdminLike && can(perms, "EPP", "UPDATE")) ||
    (isDrena && can(perms, "EPP", "UPDATE")) ||
    (isIepp && can(perms, "EPP", "UPDATE"))
  const canDelEpp =
    (isAdminLike && can(perms, "EPP", "DELETE")) ||
    (isDrena && can(perms, "EPP", "DELETE")) ||
    (isIepp && can(perms, "EPP", "DELETE"))

  const loadDrenas = useCallback(async () => {
    if (isIepp) return
    if (!canReadDrenaList) return
    setLoadingDrenas(true)
    try {
      if (isDrena && lockedDrenaId) {
        const res = await structuresService.getDrenaById(lockedDrenaId)
        const items = (res as unknown as { items?: Drena[] }).items ?? []
        const row = items[0]
        setDrenas(row ? [row] : [])
        setDrenaTotal(row ? 1 : 0)
        setSelectedDrenaId((prev) => prev ?? lockedDrenaId)
        if (row) setSelectedDrenaLibelle(row.libelle ?? null)
      } else if (isAdminLike) {
        const fk = `${drenaSearchDebounced.code}|${drenaSearchDebounced.libelle}`
        let pageIdx = drenaPage
        if (drenaListFilterKeyRef.current !== fk) {
          drenaListFilterKeyRef.current = fk
          pageIdx = 0
          if (drenaPage !== 0) setDrenaPage(0)
        }
        const res = await structuresService.getDrenas(
          {
            isActive: true,
            code: drenaSearchDebounced.code,
            libelle: drenaSearchDebounced.libelle,
          },
          { index: pageIdx, size: PAGE_SIZE },
        )
        const items = (res as unknown as { items?: Drena[] }).items ?? []
        setDrenas(Array.isArray(items) ? items : [])
        setDrenaTotal(Number((res as unknown as { count?: number }).count ?? items.length))
      }
    } catch (e: unknown) {
      console.error(e)
      toast.error("Impossible de charger les DRENA.")
    } finally {
      setLoadingDrenas(false)
    }
  }, [canReadDrenaList, isAdminLike, isDrena, isIepp, lockedDrenaId, drenaPage, drenaSearchDebounced])

  const loadIepps = useCallback(
    async (drenaId: number, pageIndex: number) => {
      setLoadingIepps(true)
      try {
        const fk = `${drenaId}|${ieppSearchDebounced.code}|${ieppSearchDebounced.libelle}`
        let p = pageIndex
        if (ieppListFilterKeyRef.current !== fk) {
          ieppListFilterKeyRef.current = fk
          p = 0
          if (pageIndex !== 0) setIeppPage(0)
        }
        const res = await structuresService.getIeppsByDrena(
          drenaId,
          { index: p, size: PAGE_SIZE },
          { code: ieppSearchDebounced.code, libelle: ieppSearchDebounced.libelle },
        )
        const items = (res as unknown as { items?: Iepp[] }).items ?? []
        setIepps(Array.isArray(items) ? items : [])
        setIeppTotal(Number((res as unknown as { count?: number }).count ?? items.length))
      } catch (e: unknown) {
        console.error(e)
        toast.error("Impossible de charger les IEPP.")
      } finally {
        setLoadingIepps(false)
      }
    },
    [ieppSearchDebounced],
  )

  const loadEpps = useCallback(async (ieppId: number, pageIndex: number) => {
    setLoadingEpps(true)
    try {
      const fk = `${ieppId}|${eppSearchDebounced.code}|${eppSearchDebounced.libelle}`
      let p = pageIndex
      if (eppListFilterKeyRef.current !== fk) {
        eppListFilterKeyRef.current = fk
        p = 0
        if (pageIndex !== 0) setEppPage(0)
      }
      const res = await structuresService.getEppsByIepp(
        ieppId,
        { index: p, size: PAGE_SIZE },
        { code: eppSearchDebounced.code, libelle: eppSearchDebounced.libelle },
      )
      const items = (res as unknown as { items?: Epp[] }).items ?? []
      setEpps(Array.isArray(items) ? items : [])
      setEppTotal(Number((res as unknown as { count?: number }).count ?? items.length))
    } catch (e: unknown) {
      console.error(e)
      toast.error("Impossible de charger les EPP.")
    } finally {
      setLoadingEpps(false)
    }
  }, [eppSearchDebounced])

  useEffect(() => {
    void loadDrenas()
  }, [loadDrenas])

  useEffect(() => {
    if (isIepp && lockedIeppId) {
      setSelectedDrenaId(lockedDrenaId ?? null)
      void structuresService.getIeppById(lockedIeppId).then((res) => {
        const items = (res as unknown as { items?: Iepp[] }).items ?? []
        const row = items[0]
        if (row) {
          setSelectedIepp(row)
        }
      })
    }
  }, [isIepp, lockedIeppId, lockedDrenaId])

  useEffect(() => {
    const ieppId = isIepp ? (lockedIeppId ?? null) : (selectedIepp?.id ?? null)
    if (!ieppId) return
    void loadEpps(ieppId, eppPage)
  }, [isIepp, lockedIeppId, selectedIepp?.id, eppPage, loadEpps])

  useEffect(() => {
    if (!selectedDrenaId || isIepp) return
    const drenaChanged = prevDrenaForIepp.current !== selectedDrenaId
    prevDrenaForIepp.current = selectedDrenaId
    if (drenaChanged) {
      setSelectedIepp(null)
      setEpps([])
      setIeppPage(0)
      void loadIepps(selectedDrenaId, 0)
      return
    }
    void loadIepps(selectedDrenaId, ieppPage)
  }, [selectedDrenaId, isIepp, ieppPage, loadIepps])

  const selectedDrena = useMemo(
    () => drenas.find((d) => d.id === selectedDrenaId) ?? null,
    [drenas, selectedDrenaId],
  )
  const selectedDrenaTitle = selectedDrena?.libelle ?? selectedDrenaLibelle ?? ""

  const openModal = (
    kind: "drena" | "iepp" | "epp",
    mode: "create" | "edit",
    row?: Drena | Iepp | Epp,
  ) => {
    if (kind === "drena") {
      const r = row as Drena | undefined
      setFormLibelle(r?.libelle ?? "")
      setFormDescription(r?.description ?? "")
      setModal({ kind: "drena", mode, row: r })
    } else if (kind === "iepp") {
      const r = row as Iepp | undefined
      setFormLibelle(r?.libelle ?? "")
      setFormDescription(r?.description ?? "")
      setModal({ kind: "iepp", mode, row: r })
    } else {
      const r = row as Epp | undefined
      setFormLibelle(r?.libelle ?? "")
      setFormDescription(r?.description ?? "")
      setModal({ kind: "epp", mode, row: r })
    }
  }

  const closeModal = () => {
    setModal({ kind: "closed" })
    setFormLibelle("")
    setFormDescription("")
  }

  const submitModal = async () => {
    const desc = normalizeDescription(formDescription, formLibelle)
    try {
      if (modal.kind === "drena") {
        if (modal.mode === "create") {
          await structuresService.createDrena({
            libelle: formLibelle.trim(),
            description: desc,
          })
          toast.success("DRENA créée (code généré automatiquement).")
        } else if (modal.row?.id) {
          await structuresService.updateDrena({
            id: modal.row.id,
            code: modal.row.code,
            libelle: formLibelle.trim(),
            description: desc,
          })
          toast.success("DRENA mise à jour.")
        }
        await loadDrenas()
      } else if (modal.kind === "iepp") {
        const drenaId = selectedDrenaId ?? lockedDrenaId
        if (!drenaId) {
          toast.error("Sélectionnez une DRENA.")
          return
        }
        if (modal.mode === "create") {
          await structuresService.createIepp({
            libelle: formLibelle.trim(),
            description: desc,
            drenaId,
          })
          toast.success("IEPP créée (code généré automatiquement).")
        } else if (modal.row?.id) {
          await structuresService.updateIepp({
            id: modal.row.id,
            code: modal.row.code,
            libelle: formLibelle.trim(),
            description: desc,
            drenaId: modal.row.drenaId ?? drenaId,
          })
          toast.success("IEPP mise à jour.")
        }
        await loadIepps(drenaId, ieppPage)
      } else if (modal.kind === "epp") {
        const ieppId = selectedIepp?.id ?? lockedIeppId
        if (!ieppId) {
          toast.error("Sélectionnez une IEPP.")
          return
        }
        if (modal.mode === "create") {
          await structuresService.createEpp({
            libelle: formLibelle.trim(),
            description: desc,
            ieppId,
          })
          toast.success("EPP créée (code généré automatiquement).")
        } else if (modal.row?.id) {
          await structuresService.updateEpp({
            id: modal.row.id,
            code: modal.row.code,
            libelle: formLibelle.trim(),
            description: desc,
            ieppId: modal.row.ieppId ?? ieppId,
          })
          toast.success("EPP mise à jour.")
        }
        await loadEpps(ieppId, eppPage)
      }
      closeModal()
    } catch (e: unknown) {
      console.error(e)
      const msg = e && typeof e === "object" && "message" in e ? String((e as { message: string }).message) : "Erreur serveur."
      toast.error(msg)
    }
  }

  const confirmDelete = async (kind: "drena" | "iepp" | "epp", id: number) => {
    if (!window.confirm("Confirmer la suppression (soft delete) ?")) return
    try {
      if (kind === "drena") {
        await structuresService.deleteDrena(id)
        toast.success("DRENA supprimée.")
        if (selectedDrenaId === id) {
          setSelectedDrenaId(null)
          setIepps([])
          setEpps([])
        }
        await loadDrenas()
      } else if (kind === "iepp") {
        await structuresService.deleteIepp(id)
        toast.success("IEPP supprimée.")
        if (selectedIepp?.id === id) {
          setSelectedIepp(null)
          setEpps([])
        }
        if (selectedDrenaId) await loadIepps(selectedDrenaId, ieppPage)
      } else {
        await structuresService.deleteEpp(id)
        toast.success("EPP supprimée.")
        const iid = selectedIepp?.id ?? lockedIeppId
        if (iid) await loadEpps(iid, eppPage)
      }
    } catch (e: unknown) {
      console.error(e)
      const msg = e && typeof e === "object" && "message" in e ? String((e as { message: string }).message) : "Suppression impossible."
      toast.error(msg)
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <button type="button" className="btn-outline inline-flex items-center" onClick={() => void loadDrenas()}>
          <ArrowPathIcon className="h-5 w-5 mr-2" />
          Actualiser
        </button>
      </div>

      {!isIepp && (
        <section className="rounded-lg border border-gray-200 bg-white p-4 shadow-sm">
          <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
            <h3 className="font-medium text-gray-900 flex items-center gap-2">
              <BuildingLibraryIcon className="h-5 w-5 text-orange-600" />
              DRENA
            </h3>
            {canCrudDrena && (
              <button type="button" className="btn-primary text-sm" onClick={() => openModal("drena", "create")}>
                <PlusIcon className="h-4 w-4 mr-1 inline" />
                Nouvelle DRENA
              </button>
            )}
          </div>
          {isAdminLike && (
            <StructureTextFiltersRow
              code={drenaFilterCode}
              libelle={drenaFilterLibelle}
              onCodeChange={setDrenaFilterCode}
              onLibelleChange={setDrenaFilterLibelle}
              disabled={loadingDrenas}
            />
          )}
          {loadingDrenas ? (
            <p className="text-sm text-gray-500">Chargement…</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="min-w-full text-sm">
                <thead>
                  <tr className="border-b text-left text-gray-600">
                    <th className="py-2 pr-4">Code</th>
                    <th className="py-2 pr-4">Libellé</th>
                    <th className="py-2 w-40">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {drenas.map((d) => (
                    <tr
                      key={d.id}
                      className={`border-b border-gray-100 ${selectedDrenaId === d.id ? "bg-orange-50" : ""}`}
                    >
                      <td className="py-2 pr-4 font-mono text-xs">{d.code}</td>
                      <td className="py-2 pr-4">{d.libelle}</td>
                      <td className="py-2">
                        <button
                          type="button"
                          className="text-orange-600 hover:underline mr-2"
                          onClick={() => {
                            setSelectedDrenaId(d.id)
                            setSelectedDrenaLibelle(d.libelle ?? null)
                          }}
                        >
                          Sélectionner
                        </button>
                        {canUpdDrena && (
                          <button
                            type="button"
                            className="text-gray-700 hover:text-orange-600 mr-2"
                            onClick={() => openModal("drena", "edit", d)}
                          >
                            <PencilIcon className="h-4 w-4 inline" />
                          </button>
                        )}
                        {canDelDrena && (
                          <button
                            type="button"
                            className="text-red-600 hover:underline"
                            onClick={() => void confirmDelete("drena", d.id)}
                          >
                            <TrashIcon className="h-4 w-4 inline" />
                          </button>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
              <StructureTablePagination
                pageIndex={drenaPage}
                pageSize={PAGE_SIZE}
                total={drenaTotal}
                loading={loadingDrenas}
                onPageChange={setDrenaPage}
              />
            </div>
          )}
        </section>
      )}

      {!isIepp && selectedDrenaId && (
        <section className="rounded-lg border border-gray-200 bg-white p-4 shadow-sm">
          <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
            <h3 className="font-medium text-gray-900 flex items-center gap-2">
              <ChevronRightIcon className="h-5 w-5 text-gray-400" />
              IEPP
              {selectedDrenaTitle ? (
                <span className="text-gray-500 font-normal">— {selectedDrenaTitle}</span>
              ) : null}
            </h3>
            {canCrudIepp && (
              <button type="button" className="btn-primary text-sm" onClick={() => openModal("iepp", "create")}>
                <PlusIcon className="h-4 w-4 mr-1 inline" />
                Nouvelle IEPP
              </button>
            )}
          </div>
          <StructureTextFiltersRow
            code={ieppFilterCode}
            libelle={ieppFilterLibelle}
            onCodeChange={setIeppFilterCode}
            onLibelleChange={setIeppFilterLibelle}
            disabled={loadingIepps}
          />
          {loadingIepps ? (
            <p className="text-sm text-gray-500">Chargement…</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="min-w-full text-sm">
                <thead>
                  <tr className="border-b text-left text-gray-600">
                    <th className="py-2 pr-4">Code</th>
                    <th className="py-2 pr-4">Libellé</th>
                    <th className="py-2 w-40">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {iepps.map((i) => (
                    <tr
                      key={i.id}
                      className={`border-b border-gray-100 ${selectedIepp?.id === i.id ? "bg-green-50" : ""}`}
                    >
                      <td className="py-2 pr-4 font-mono text-xs">{i.code}</td>
                      <td className="py-2 pr-4">{i.libelle}</td>
                      <td className="py-2">
                        <button
                          type="button"
                          className="text-green-700 hover:underline mr-2"
                          onClick={() => {
                            setSelectedIepp(i)
                            setEppPage(0)
                          }}
                        >
                          Sélectionner
                        </button>
                        {canUpdIepp && (
                          <button
                            type="button"
                            className="text-gray-700 hover:text-orange-600 mr-2"
                            onClick={() => openModal("iepp", "edit", i)}
                          >
                            <PencilIcon className="h-4 w-4 inline" />
                          </button>
                        )}
                        {canDelIepp && (
                          <button
                            type="button"
                            className="text-red-600"
                            onClick={() => void confirmDelete("iepp", i.id)}
                          >
                            <TrashIcon className="h-4 w-4 inline" />
                          </button>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
              <StructureTablePagination
                pageIndex={ieppPage}
                pageSize={PAGE_SIZE}
                total={ieppTotal}
                loading={loadingIepps}
                onPageChange={setIeppPage}
              />
            </div>
          )}
        </section>
      )}

      {(selectedIepp || isIepp) && (
        <section className="rounded-lg border border-gray-200 bg-white p-4 shadow-sm">
          <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
            <h3 className="font-medium text-gray-900 flex items-center gap-2">
              <ChevronRightIcon className="h-5 w-5 text-gray-400" />
              EPP
              {selectedIepp && <span className="text-gray-500 font-normal">— {selectedIepp.libelle}</span>}
            </h3>
            {canCrudEpp && (selectedIepp || lockedIeppId) && (
              <button type="button" className="btn-primary text-sm" onClick={() => openModal("epp", "create")}>
                <PlusIcon className="h-4 w-4 mr-1 inline" />
                Nouvelle EPP
              </button>
            )}
          </div>
          <StructureTextFiltersRow
            code={eppFilterCode}
            libelle={eppFilterLibelle}
            onCodeChange={setEppFilterCode}
            onLibelleChange={setEppFilterLibelle}
            disabled={loadingEpps}
          />
          {loadingEpps ? (
            <p className="text-sm text-gray-500">Chargement…</p>
          ) : (
            <div className="overflow-x-auto max-h-[420px] overflow-y-auto">
              <table className="min-w-full text-sm">
                <thead className="sticky top-0 bg-white">
                  <tr className="border-b text-left text-gray-600">
                    <th className="py-2 pr-4">Code</th>
                    <th className="py-2 pr-4">Libellé</th>
                    <th className="py-2 w-32">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {epps.map((e) => (
                    <tr key={e.id} className="border-b border-gray-100">
                      <td className="py-2 pr-4 font-mono text-xs">{e.code}</td>
                      <td className="py-2 pr-4">{e.libelle}</td>
                      <td className="py-2">
                        {canUpdEpp && (
                          <button
                            type="button"
                            className="text-gray-700 hover:text-orange-600 mr-2"
                            onClick={() => openModal("epp", "edit", e)}
                          >
                            <PencilIcon className="h-4 w-4 inline" />
                          </button>
                        )}
                        {canDelEpp && (
                          <button type="button" className="text-red-600" onClick={() => void confirmDelete("epp", e.id)}>
                            <TrashIcon className="h-4 w-4 inline" />
                          </button>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
              <StructureTablePagination
                pageIndex={eppPage}
                pageSize={PAGE_SIZE}
                total={eppTotal}
                loading={loadingEpps}
                onPageChange={setEppPage}
              />
            </div>
          )}
        </section>
      )}

      {modal.kind !== "closed" && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4">
          <div className="w-full max-w-md rounded-lg bg-white p-6 shadow-xl">
            <h4 className="text-lg font-semibold text-gray-900 mb-4">
              {modal.kind === "drena" && (modal.mode === "create" ? "Nouvelle DRENA" : "Modifier DRENA")}
              {modal.kind === "iepp" && (modal.mode === "create" ? "Nouvelle IEPP" : "Modifier IEPP")}
              {modal.kind === "epp" && (modal.mode === "create" ? "Nouvelle EPP" : "Modifier EPP")}
            </h4>
            <div className="space-y-3">
              {modal.mode === "create" ? (
                <p className="text-xs text-gray-600 rounded border border-dashed border-gray-200 bg-gray-50 px-3 py-2">
                  Le code sera généré automatiquement (même convention que les structures déjà enregistrées).
                </p>
              ) : (
                <div>
                  <span className="block text-xs font-medium text-gray-600 mb-1">Code</span>
                  <p className="font-mono text-sm text-gray-900">
                    {modal.kind === "drena" && (modal.row as Drena | undefined)?.code}
                    {modal.kind === "iepp" && (modal.row as Iepp | undefined)?.code}
                    {modal.kind === "epp" && (modal.row as Epp | undefined)?.code}
                  </p>
                </div>
              )}
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">Libellé *</label>
                <input
                  className="w-full rounded border border-gray-300 px-3 py-2 text-sm"
                  value={formLibelle}
                  onChange={(e) => setFormLibelle(e.target.value)}
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">Description</label>
                <textarea
                  className="w-full rounded border border-gray-300 px-3 py-2 text-sm"
                  rows={2}
                  value={formDescription}
                  onChange={(e) => setFormDescription(e.target.value)}
                  placeholder="Texte libre (synonyme du libellé si vide)"
                />
              </div>
            </div>
            <div className="mt-6 flex justify-end gap-2">
              <button type="button" className="btn-outline" onClick={closeModal}>
                Annuler
              </button>
              <button type="button" className="btn-primary" onClick={() => void submitModal()}>
                Enregistrer
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
