"use client"

import { useCallback, useEffect, useState } from "react"
import {
  RbacMatrixService,
  RBAC_PERMISSION_TYPES,
  type RbacMatrixRow,
  type RbacPermissionType,
} from "@/lib/services/rbac-matrix.service"
import type { Role } from "@/lib/types/entities"
import toast from "react-hot-toast"
import { ArrowPathIcon, ShieldCheckIcon } from "@heroicons/react/24/outline"

const rbacService = new RbacMatrixService()

type Props = {
  roles: Role[]
  rolesLoading: boolean
  rolesError: string | null
  /** Pour le badge de l’onglet « Permissions » dans la barre d’onglets */
  onFonctionCountChange?: (count: number) => void
  /** Après création d’un rôle : présélectionner ce rôle dans la liste (puis appeler consume). */
  matrixInitialRoleId?: number | null
  onMatrixInitialRoleConsumed?: () => void
  /** ADMIN / DAF : raccourci vers l’onglet Rôles + modal création */
  canManageRoles?: boolean
  onGoToCreateRole?: () => void
}

/**
 * Matrice RBAC (fonctionnalités × types de permission) pour un rôle — même cadre visuel que les autres sous-menus Paramètres.
 */
export function ParametragesRbacPermissionsPanel({
  roles,
  rolesLoading,
  rolesError,
  onFonctionCountChange,
  matrixInitialRoleId,
  onMatrixInitialRoleConsumed,
  canManageRoles,
  onGoToCreateRole,
}: Props) {
  const [roleId, setRoleId] = useState<number | "">("")
  const [snapshotLabel, setSnapshotLabel] = useState("")
  const [rows, setRows] = useState<RbacMatrixRow[]>([])
  const [matrixLoading, setMatrixLoading] = useState(false)
  const [saving, setSaving] = useState(false)

  const loadMatrix = useCallback(
    async (rid: number) => {
      try {
        setMatrixLoading(true)
        const res = await rbacService.loadMatrix(rid)
        if (res.hasError) {
          throw new Error(res.status?.message || "Chargement matrice impossible")
        }
        const snap = res.items?.[0] as
          | {
              roleId?: number
              roleCode?: string
              roleLibelle?: string
              rows?: RbacMatrixRow[]
            }
          | undefined
        if (!snap?.rows) {
          setRows([])
          setSnapshotLabel("")
          onFonctionCountChange?.(0)
          toast.error("Réponse matrice vide")
          return
        }
        setSnapshotLabel(`${snap.roleCode ?? ""} — ${snap.roleLibelle ?? ""}`.trim())
        onFonctionCountChange?.(snap.rows.length)
        setRows(
          snap.rows.map((r) => ({
            ...r,
            grantedPermissionTypes: [...(r.grantedPermissionTypes ?? [])],
          })),
        )
      } catch (e: unknown) {
        toast.error(e instanceof Error ? e.message : "Erreur chargement")
        setRows([])
        onFonctionCountChange?.(0)
      } finally {
        setMatrixLoading(false)
      }
    },
    [onFonctionCountChange],
  )

  useEffect(() => {
    if (roleId === "") {
      setRows([])
      setSnapshotLabel("")
      return
    }
    loadMatrix(roleId as number)
  }, [roleId, loadMatrix])

  useEffect(() => {
    if (matrixInitialRoleId != null && matrixInitialRoleId > 0) {
      setRoleId(matrixInitialRoleId)
      onMatrixInitialRoleConsumed?.()
    }
  }, [matrixInitialRoleId, onMatrixInitialRoleConsumed])

  const togglePerm = (fonctionnaliteId: number, perm: RbacPermissionType) => {
    setRows((prev) =>
      prev.map((r) => {
        if (r.fonctionnaliteId !== fonctionnaliteId) return r
        const set = new Set(r.grantedPermissionTypes.map((x) => x.toUpperCase()))
        const p = perm.toUpperCase()
        if (set.has(p)) set.delete(p)
        else set.add(p)
        return {
          ...r,
          grantedPermissionTypes: Array.from(set).sort(),
        }
      }),
    )
  }

  const hasPerm = (r: RbacMatrixRow, perm: RbacPermissionType) =>
    r.grantedPermissionTypes.some((x) => x.toUpperCase() === perm.toUpperCase())

  const onSave = async () => {
    if (roleId === "") {
      toast.error("Choisissez un rôle")
      return
    }
    try {
      setSaving(true)
      await rbacService.saveMatrix({
        roleId: roleId as number,
        rows: rows.map((r) => ({
          fonctionnaliteId: r.fonctionnaliteId,
          grantedPermissionTypes: r.grantedPermissionTypes,
        })),
      })
      toast.success("Permissions enregistrées — reconnectez-vous pour rafraîchir votre session si besoin.")
      await loadMatrix(roleId as number)
    } catch (e: unknown) {
      toast.error(e instanceof Error ? e.message : "Erreur enregistrement")
    } finally {
      setSaving(false)
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
        <div className="flex gap-3">
          <div className="rounded-lg bg-orange-50 p-2 text-orange-700">
            <ShieldCheckIcon className="h-7 w-7 shrink-0" />
          </div>
          <div>
            <h2 className="text-lg font-semibold text-gray-900">Permissions par rôle et par fonctionnalité</h2>
            <p className="text-gray-600">
              <span className="font-medium text-gray-800">Étape 1</span> — créez le rôle (code stable + libellé) dans
              l’onglet « Rôles ». <span className="font-medium text-gray-800">Étape 2</span> — choisissez ce rôle
              ci-dessous et cochez les types d’accès (CREATE, READ, …) par fonctionnalité, puis enregistrez. Référence
              sécurité : <code className="rounded bg-gray-100 px-1 text-xs">ROLE_FONCTIONALITE</code>.
            </p>
            {rolesError && <p className="mt-1 text-sm text-red-600">❌ {rolesError}</p>}
            {snapshotLabel ? (
              <p className="mt-1 text-xs text-gray-500">Rôle courant : {snapshotLabel}</p>
            ) : null}
          </div>
        </div>
        <div className="flex flex-shrink-0 flex-wrap items-center gap-2">
          {canManageRoles && onGoToCreateRole && (
            <button type="button" onClick={onGoToCreateRole} className="btn-outline" title="Ouvre l’onglet Rôles">
              Nouveau rôle…
            </button>
          )}
          <button
            type="button"
            onClick={() => roleId !== "" && loadMatrix(roleId as number)}
            disabled={roleId === "" || matrixLoading}
            className="btn-outline"
            title="Recharger la matrice"
          >
            <ArrowPathIcon className={`mr-2 h-5 w-5 ${matrixLoading ? "animate-spin" : ""}`} />
            Actualiser
          </button>
          <button
            type="button"
            onClick={onSave}
            disabled={roleId === "" || saving || matrixLoading || rows.length === 0}
            className="btn-primary"
          >
            {saving ? "Enregistrement…" : "Enregistrer"}
          </button>
        </div>
      </div>

      <div className="card p-4">
        <label className="mb-2 block text-sm font-medium text-gray-700">Rôle</label>
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
          <select
            className="w-full max-w-md rounded-lg border border-gray-300 px-3 py-2 text-sm focus:border-orange-500 focus:outline-none focus:ring-1 focus:ring-orange-500"
            value={roleId === "" ? "" : String(roleId)}
            disabled={rolesLoading}
            onChange={(e) => {
              const v = e.target.value
              setRoleId(v === "" ? "" : Number(v))
            }}
          >
            <option value="">{rolesLoading ? "Chargement…" : "— Choisir un rôle —"}</option>
            {roles.map((r) => (
              <option key={r.id} value={r.id}>
                {r.code} — {r.libelle}
              </option>
            ))}
          </select>
        </div>
      </div>

      {matrixLoading && (
        <div className="rounded-lg border border-dashed border-gray-300 bg-gray-50 p-8 text-center text-gray-600">
          Chargement de la matrice…
        </div>
      )}

      {!matrixLoading && roleId !== "" && rows.length > 0 && (
        <div className="overflow-x-auto rounded-lg border border-gray-200 bg-white shadow-sm">
          <table className="min-w-full divide-y divide-gray-200 text-sm">
            <thead className="bg-gray-50">
              <tr>
                <th
                  scope="col"
                  className="sticky left-0 z-10 min-w-[220px] bg-gray-50 px-3 py-2 text-left text-xs font-semibold uppercase tracking-wide text-gray-600"
                >
                  Fonctionnalité
                </th>
                {RBAC_PERMISSION_TYPES.map((p) => (
                  <th
                    key={p}
                    scope="col"
                    className="min-w-[72px] px-1 py-2 text-center text-xs font-semibold uppercase text-gray-600"
                  >
                    {p}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {rows.map((row) => (
                <tr key={row.fonctionnaliteId} className="hover:bg-gray-50/80">
                  <td className="sticky left-0 z-10 bg-white px-3 py-2 align-top shadow-[2px_0_4px_-2px_rgba(0,0,0,0.06)]">
                    <div className="font-mono text-xs text-orange-800">{row.code}</div>
                    <div className="text-gray-800">{row.libelle ?? "—"}</div>
                  </td>
                  {RBAC_PERMISSION_TYPES.map((p) => (
                    <td key={p} className="px-1 py-2 text-center align-middle">
                      <input
                        type="checkbox"
                        className="h-4 w-4 rounded border-gray-300 text-orange-600 focus:ring-orange-500"
                        checked={hasPerm(row, p)}
                        onChange={() => togglePerm(row.fonctionnaliteId, p)}
                        aria-label={`${row.code} ${p}`}
                      />
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {!matrixLoading && roleId !== "" && rows.length === 0 && (
        <p className="text-sm text-gray-500">Aucune ligne à afficher pour ce rôle.</p>
      )}
    </div>
  )
}
