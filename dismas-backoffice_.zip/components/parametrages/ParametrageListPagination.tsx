"use client"

/**
 * Pagination client pour les listes de l’écran Paramétrages (même principe que les structures DRENA/IEPP/EPP).
 */
export function ParametrageListPagination({
  pageIndex,
  pageSize,
  total,
  loading,
  onPageChange,
}: {
  pageIndex: number
  pageSize: number
  total: number
  loading: boolean
  onPageChange: (nextIndex: number) => void
}) {
  if (total === 0) return null
  const totalPages = Math.max(1, Math.ceil(total / pageSize))
  if (total <= pageSize && pageIndex === 0) return null
  return (
    <div className="mt-3 flex flex-wrap items-center justify-between gap-2 border-t border-gray-100 pt-2 text-sm text-gray-600">
      <span>
        {total} enregistrement{total > 1 ? "s" : ""} · page {pageIndex + 1} / {totalPages}
      </span>
      <div className="flex gap-2">
        <button
          type="button"
          className="btn-outline px-2 py-1 text-xs disabled:opacity-40"
          disabled={loading || pageIndex <= 0}
          onClick={() => onPageChange(pageIndex - 1)}
        >
          Précédent
        </button>
        <button
          type="button"
          className="btn-outline px-2 py-1 text-xs disabled:opacity-40"
          disabled={loading || pageIndex >= totalPages - 1}
          onClick={() => onPageChange(pageIndex + 1)}
        >
          Suivant
        </button>
      </div>
    </div>
  )
}

export const PARAMETRAGE_LIST_PAGE_SIZE = 15
