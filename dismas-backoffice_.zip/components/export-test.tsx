"use client"

import { useState } from "react"
import { 
  exportToPDF, 
  exportToExcel, 
  formatNumber, 
  generateFileName, 
  validateExportData,
  type ExportData 
} from '../lib/export-utils'

// Données de test
const testData: ExportData = {
  title: 'TEST D\'EXPORT',
  subtitle: 'Vérification des fonctions d\'export',
  date: new Date().toISOString().split('T')[0],
  generatedBy: 'Système de Test',
  status: 'TEST',
  statistics: [
    { label: 'Total Test', value: formatNumber(1234567) },
    { label: 'Pourcentage', value: '85%' },
    { label: 'Statut', value: 'Actif' }
  ],
  tables: [
    {
      title: 'Tableau de Test 1',
      headers: ['Colonne 1', 'Colonne 2', 'Colonne 3'],
      data: [
        ['Donnée 1', formatNumber(1000), 'Statut A'],
        ['Donnée 2', formatNumber(2000), 'Statut B'],
        ['Donnée 3', formatNumber(3000), 'Statut C']
      ]
    },
    {
      title: 'Tableau de Test 2',
      headers: ['Nom', 'Valeur', 'Date'],
      data: [
        ['Test 1', '100', '2024-01-01'],
        ['Test 2', '200', '2024-01-02'],
        ['Test 3', '300', '2024-01-03']
      ]
    }
  ]
}

export default function ExportTest() {
  const [isExporting, setIsExporting] = useState(false)
  const [message, setMessage] = useState<string | null>(null)

  const handleTestExport = async (type: 'pdf' | 'excel') => {
    setIsExporting(true)
    setMessage(null)

    try {
      // Valider les données
      if (!validateExportData(testData)) {
        throw new Error('Données de test invalides')
      }

      // Générer le nom de fichier
      const fileName = generateFileName('test_export', type)

      // Exporter
      if (type === 'pdf') {
        exportToPDF(testData, fileName)
      } else {
        exportToExcel(testData, fileName)
      }

      setMessage(`✅ Export ${type.toUpperCase()} réussi ! Fichier: ${fileName}`)
    } catch (error) {
      console.error('Erreur export:', error)
      setMessage(`❌ Erreur lors de l'export ${type.toUpperCase()}: ${error instanceof Error ? error.message : 'Erreur inconnue'}`)
    } finally {
      setIsExporting(false)
    }
  }

  return (
    <div className="p-6 bg-white rounded-lg shadow">
      <h2 className="text-xl font-bold mb-4">🧪 Test des Fonctions d'Export</h2>
      
      <div className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <button
            onClick={() => handleTestExport('pdf')}
            disabled={isExporting}
            className="bg-red-600 hover:bg-red-700 disabled:bg-red-300 text-white px-4 py-2 rounded-lg"
          >
            {isExporting ? 'Export en cours...' : '📄 Test Export PDF'}
          </button>
          
          <button
            onClick={() => handleTestExport('excel')}
            disabled={isExporting}
            className="bg-green-600 hover:bg-green-700 disabled:bg-green-300 text-white px-4 py-2 rounded-lg"
          >
            {isExporting ? 'Export en cours...' : '📊 Test Export Excel'}
          </button>
        </div>

        {message && (
          <div className={`p-3 rounded-lg ${
            message.includes('✅') ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
          }`}>
            {message}
          </div>
        )}

        <div className="mt-6">
          <h3 className="font-semibold mb-2">Données de test utilisées:</h3>
          <pre className="bg-gray-100 p-3 rounded text-sm overflow-auto">
            {JSON.stringify(testData, null, 2)}
          </pre>
        </div>
      </div>
    </div>
  )
} 