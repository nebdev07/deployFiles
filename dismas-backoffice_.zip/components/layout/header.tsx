"use client"

import { useAuth } from "../../app/providers"
import { BellIcon, UserCircleIcon } from "@heroicons/react/24/outline"
import { useMemo, useState } from "react"
import { useRouter } from "next/navigation"
import { useAnneesScolaires } from "@/hooks/use-annees-scolaires"

export default function Header() {
  const { user, logout } = useAuth()
  const [showUserMenu, setShowUserMenu] = useState(false)
  const router = useRouter()
  const { anneesScolaires } = useAnneesScolaires()

  const anneeScolaireCourante = useMemo(() => {
    const courante = anneesScolaires.find((a) => a.estCourante)
    if (courante) return courante
    return anneesScolaires[0]
  }, [anneesScolaires])

  const codeAnneeScolaire =
    anneeScolaireCourante?.code?.trim() || anneeScolaireCourante?.libelle?.trim() || null

  const libelleStructure =
    user?.structure?.libelle?.trim() ||
    "Ministère de l'Éducation Nationale"

  const handleLogout = () => {
    logout()
    setShowUserMenu(false)
    // ✅ CORRECTION: Redirection immédiate vers la page d'accueil
    router.push("/")
  }

  return (
    <header className="header grid grid-cols-[1fr_auto_1fr] items-center gap-3 sm:gap-4">
      <div className="min-w-0" aria-hidden="true" />

      {/* Centre : code année scolaire courante + libellé structure */}
      <div
        className="flex flex-col items-center justify-center text-center min-w-0 max-w-[100vw] px-2"
        aria-label={
          codeAnneeScolaire
            ? `Année scolaire ${codeAnneeScolaire}, ${libelleStructure}`
            : libelleStructure
        }
      >
        <span className="header-year-display max-w-full truncate px-1">
          {codeAnneeScolaire ?? "—"}
        </span>
        <span className="mt-1.5 text-xs sm:text-sm font-medium text-gray-700 max-w-full truncate px-2">
          {libelleStructure}
        </span>
      </div>

      {/* Actions */}
      <div className="flex items-center justify-end space-x-2 sm:space-x-4 min-w-0">
        {/* Notifications */}
        <button className="relative p-2 text-gray-400 hover:text-gray-600 transition-colors">
          <BellIcon className="h-6 w-6" />
          <span className="absolute top-0 right-0 h-2 w-2 bg-red-500 rounded-full"></span>
        </button>

        {/* User menu */}
        <div className="relative">
          <button
            onClick={() => setShowUserMenu(!showUserMenu)}
            className="flex items-center space-x-2 p-2 rounded-lg hover:bg-gray-100 transition-colors"
          >
            <UserCircleIcon className="h-8 w-8 text-gray-400" />
            <div className="text-left">
              <p className="text-sm font-medium text-gray-900">
                {user?.prenoms} {user?.nom}
              </p>
              <p className="text-xs text-gray-500">{user?.role.libelle}</p>
            </div>
          </button>

          {/* Dropdown menu */}
          {showUserMenu && (
            <div className="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-lg border border-gray-200 z-50">
              <div className="py-1">
                <button
                  onClick={() => {
                    setShowUserMenu(false)
                    router.push("/profil")
                  }}
                  className="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                >
                  Mon profil
                </button>
                <button
                  onClick={() => {
                    setShowUserMenu(false)
                    router.push("/profil")
                  }}
                  className="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                >
                  Paramètres
                </button>
                <hr className="my-1" />
                <button
                  onClick={handleLogout}
                  className="block w-full text-left px-4 py-2 text-sm text-red-600 hover:bg-red-50"
                >
                  Se déconnecter
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </header>
  )
}
