"use client"

import { useState } from "react"
import Link from "next/link"
import { usePathname, useSearchParams } from "next/navigation"
import { useAuth } from "../../app/providers"
import {
  HomeIcon,
  CubeIcon,
  TruckIcon,
  ArrowsRightLeftIcon,
  ArrowUturnLeftIcon,
  ExclamationTriangleIcon,
  ClipboardDocumentListIcon,
  ChartBarIcon,
  UserGroupIcon,
  CogIcon,
  Bars3Icon,
  XMarkIcon,
  ShoppingCartIcon,
  DocumentTextIcon,
  UserCircleIcon,
  QueueListIcon,
  BuildingLibraryIcon,
} from "@heroicons/react/24/outline"
import Logo from "../ui/logo"
import { canShowMenuItem } from "@/lib/utils/functionality-permissions"
import {
  hidesGlobalParametreMenu,
  isParametragesTerritoireOnlyRole,
  STRUCTURES_SCOLAIRES_ROLE_CODES,
} from "@/lib/utils/role-codes"
import type { ComponentType } from "react"

type MenuItem = {
  name: string
  href: string
  icon: ComponentType<{ className?: string }>
  roles: string[]
  /** Si renseigné et que la session contient des functionalityPermissions, exiger CODE:READ */
  functionalityReadCode?: string
  /** Si renseigné (avec permissions), afficher si au moins un de ces codes a READ */
  functionalityReadCodesAnyOf?: string[]
  /** Si vrai, ne jamais utiliser le fallback par rôle (RBAC strict requis). */
  strictRbacRead?: boolean
}

const menuItems: MenuItem[] = [
  {
    name: "Tableau de bord",
    href: "/dashboard",
    icon: HomeIcon,
    roles: [
      "ADMIN",
      "DAF",
      "DRENA",
      "IEPP",
      "CPPP",
      "CPS",
      "DIRECTEUR",
      "INTENDANT",
      "INTENDENT",
      "INFORMATICIEN",
      "MAITRE",
      "COGES",
      "DPFC",
      "CABINET",
    ],
    functionalityReadCode: "DASHBOARD",
    strictRbacRead: true,
  },
  {
    name: "Tableau de répartition",
    href: "/planification/repartition",
    icon: DocumentTextIcon,
    roles: ["ADMIN", "DAF", "DRENA", "IEPP", "CPPP", "CPS", "INTENDANT", "INTENDENT", "DIRECTEUR", "INFORMATICIEN", "CABINET"],
    functionalityReadCode: "TABLEAU_REPARTITION",
    strictRbacRead: true,
  },
  {
    name: "Commande",
    href: "/commandes",
    icon: ShoppingCartIcon,
    roles: ["ADMIN", "DAF"],
    functionalityReadCode: "COMMANDE_FOURNISSEUR",
  },
  {
    name: "Récupération",
    href: "/retours",
    icon: ArrowUturnLeftIcon,
    roles: ["ADMIN", "DAF", "DRENA", "IEPP", "CPPP", "CPS", "INTENDANT", "INTENDENT", "DIRECTEUR", "INFORMATICIEN", "MAITRE"],
    functionalityReadCode: "RETOUR_MANUEL",
  },
  {
    name: "Expression des besoins",
    href: "/besoins",
    icon: ClipboardDocumentListIcon,
    roles: ["ADMIN", "DAF", "DRENA", "IEPP", "CPPP", "CPS", "INTENDANT", "INTENDENT", "DIRECTEUR", "INFORMATICIEN", "CABINET"],
    functionalityReadCode: "BESOIN",
  },
  {
    name: "Réception",
    href: "/receptions",
    icon: TruckIcon,
    roles: ["ADMIN", "DAF", "DRENA", "IEPP", "CPPP", "CPS", "INTENDANT", "INTENDENT", "DIRECTEUR", "INFORMATICIEN", "CABINET"],
    functionalityReadCode: "MOUVEMENT",
  },
  {
    name: "Stock",
    href: "/stocks",
    icon: CubeIcon,
    roles: ["ADMIN", "DAF", "DRENA", "IEPP", "CPPP", "CPS", "INTENDANT", "INTENDENT", "DIRECTEUR", "INFORMATICIEN", "CABINET"],
    functionalityReadCode: "MOUVEMENT",
  },
  {
    name: "Distribution",
    href: "/distribution",
    icon: TruckIcon,
    roles: ["ADMIN", "DAF", "DRENA", "IEPP", "CPPP", "CPS", "INTENDANT", "INTENDENT", "DIRECTEUR", "INFORMATICIEN", "MAITRE"],
    functionalityReadCode: "MANUEL_DISTRIBUTION",
  },
  {
    name: "Régulation",
    href: "/regulation/inter-etablissements",
    icon: ArrowsRightLeftIcon,
    roles: ["ADMIN", "DAF", "DRENA", "IEPP", "CPPP", "CPS", "INTENDANT", "INTENDENT", "DIRECTEUR", "INFORMATICIEN", "MAITRE", "COGES"],
    functionalityReadCode: "REGULATION",
  },
  {
    name: "Rapport",
    href: "/rapports",
    icon: ChartBarIcon,
    roles: ["ADMIN", "DAF", "DRENA", "IEPP", "CPPP", "CPS", "INTENDANT", "INTENDENT", "DIRECTEUR", "INFORMATICIEN", "CABINET"],
    functionalityReadCode: "RAPPORT",
  },
  {
    name: "Plainte",
    href: "/plaintes",
    icon: ExclamationTriangleIcon,
    roles: ["ADMIN", "DAF", "DRENA", "IEPP", "CPPP", "CPS", "INTENDANT", "INTENDENT", "DIRECTEUR", "INFORMATICIEN", "COGES"],
    functionalityReadCode: "PLAINTE",
  },
  {
    name: "Enquête",
    href: "/enquetes",
    icon: ClipboardDocumentListIcon,
    roles: ["ADMIN", "DAF", "DRENA", "IEPP", "CPPP", "CPS", "INTENDANT", "INTENDENT", "DIRECTEUR", "INFORMATICIEN", "COGES"],
    functionalityReadCode: "ENQUETE_SATISFACTION",
  },
  {
    name: "Utilisateur",
    href: "/users",
    icon: UserGroupIcon,
    roles: ["ADMIN", "DAF", "DRENA", "IEPP", "CPPP", "CPS", "INTENDANT", "INTENDENT", "DIRECTEUR", "INFORMATICIEN"],
    functionalityReadCode: "USER",
  },
  {
    /** Territoire structures : RBAC {@code STRUCTURE_ADMINISTRATIVE:READ} (ex. accord possible à une EPP depuis le paramétrage des rôles). */
    name: "Structures scolaires",
    href: "/admin/parametrages?tab=territoire",
    icon: BuildingLibraryIcon,
    roles: [...STRUCTURES_SCOLAIRES_ROLE_CODES],
    functionalityReadCode: "STRUCTURE_ADMINISTRATIVE",
  },
  {
    name: "Paramètre",
    href: "/admin/parametrages",
    icon: CogIcon,
    roles: ["ADMIN", "DAF", "DPFC"],
    functionalityReadCodesAnyOf: [
      "FONCTIONALITE",
      "VIEW_DRENA",
      "VIEW_IEPP",
      "VIEW_EPP",
      "DRENA",
      "IEPP",
      "EPP",
    ],
  },
  {
    name: "Profil",
    href: "/profil",
    icon: UserCircleIcon,
    roles: [
      "ADMIN",
      "DAF",
      "DRENA",
      "IEPP",
      "CPPP",
      "CPS",
      "DIRECTEUR",
      "INTENDANT",
      "INTENDENT",
      "INFORMATICIEN",
      "MAITRE",
      "COGES",
      "DPFC",
      "CABINET",
    ],
  },
  {
    name: "Monitoring",
    href: "/admin",
    icon: CogIcon,
    roles: ["ADMIN"],
    functionalityReadCode: "MONITORING",
    strictRbacRead: true,
  },
  {
    name: "Journal d'activité",
    href: "/logs",
    icon: QueueListIcon,
    roles: ["ADMIN", "DAF"],
    functionalityReadCode: "JOURNAL_ACTIVITE",
  },
]

function menuItemIsActive(
  pathname: string | null,
  searchParams: URLSearchParams | null,
  href: string,
  userRoleCode: string,
): boolean {
  const rc = (userRoleCode || "").toUpperCase()
  const normalizedPath = pathname?.replace(/\/+$/, "") || "/"
  const [pathPart, queryPart] = href.split("?")
  const normalizedHrefPath = pathPart.replace(/\/+$/, "")

  // Page unique /admin/parametrages : éviter double surlignage Structures vs Paramètre
  if (normalizedPath === "/admin/parametrages") {
    const tab = searchParams?.get("tab") ?? undefined
    if (href.includes("tab=territoire")) {
      if (tab === "territoire") return true
      if (isParametragesTerritoireOnlyRole(rc) && (tab === undefined || tab === null || tab === "")) {
        return true
      }
      return false
    }
    if (!queryPart && (href === "/admin/parametrages" || href === "/admin/parametrages/")) {
      return true
    }
  }

  if (queryPart && searchParams) {
    const expected = new URLSearchParams(queryPart)
    if (normalizedPath !== normalizedHrefPath) return false
    for (const [k, v] of expected.entries()) {
      if (searchParams.get(k) !== v) return false
    }
    return true
  }
  const normalizedHref = href.replace(/\/+$/, "")
  return (
    normalizedPath === normalizedHref ||
    (normalizedHref !== "/dashboard" &&
      normalizedHref !== "/besoins" &&
      normalizedHref !== "/admin" &&
      normalizedPath.startsWith(`${normalizedHref}/`))
  )
}

export default function Sidebar() {
  const { user } = useAuth()
  const pathname = usePathname()
  const searchParams = useSearchParams()
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)

  // ✅ CORRECTION: Vérification après tous les hooks
  if (!user) {
    return (
      <div className="w-64 bg-white border-r border-gray-200">
        <div className="p-4">
          <p className="text-gray-600">Chargement...</p>
        </div>
      </div>
    )
  }

  const filteredMenuItems = menuItems.filter((item) => {
    const userRoleCode = (user.role?.code || "").toUpperCase()
    // DRENA / IEPP / équipe EPP : pas d’entrée « Paramètre » (catalogues / RBAC) — seulement « Structures scolaires ».
    if (item.name === "Paramètre" && hidesGlobalParametreMenu(userRoleCode)) {
      return false
    }
    if (item.strictRbacRead) {
      const perms = user.functionalityPermissions
      if (!perms?.length) {
        return false
      }
      if (item.functionalityReadCodesAnyOf?.length) {
        return item.functionalityReadCodesAnyOf.some((code) =>
          perms.some((p) => p.toUpperCase() === `${code}:READ`.toUpperCase()),
        )
      }
      if (item.functionalityReadCode) {
        return perms.some((p) => p.toUpperCase() === `${item.functionalityReadCode}:READ`.toUpperCase())
      }
      return false
    }
    return canShowMenuItem(
      userRoleCode,
      item.roles,
      user.functionalityPermissions,
      item.functionalityReadCode,
      item.functionalityReadCodesAnyOf,
    )
  })

  const SidebarContent = ({ hideLogo = false }: { hideLogo?: boolean }) => (
    <div className="flex h-full min-h-0 flex-col">
      {/* Logo (masqué sur mobile : déjà affiché dans la barre du drawer) */}
      {!hideLogo && (
        <div className="flex shrink-0 items-center border-b border-gray-200 px-6 py-4">
          <Logo size="sm" showText={true} />
        </div>
      )}

      {/* User Info */}
      <div className="shrink-0 px-6 py-4 border-b border-gray-200 bg-gray-50">
        <div className="flex items-center">
          <div className="w-10 h-10 bg-gradient-to-r from-orange-400 to-green-400 rounded-full flex items-center justify-center">
            <span className="text-white font-semibold text-sm">
              {user.prenoms.charAt(0)}
              {user.nom.charAt(0)}
            </span>
          </div>
          <div className="ml-3">
            <p className="text-sm font-medium text-gray-900">
              {user.prenoms} {user.nom}
            </p>
            <p className="text-xs text-gray-500">{user.role.libelle}</p>
            {user.structure && <p className="text-xs text-gray-400">{user.structure.libelle}</p>}
          </div>
        </div>
      </div>

      {/* Navigation — zone scrollable (important sur petit écran / fenêtre basse) */}
      <nav className="min-h-0 flex-1 space-y-1 overflow-y-auto overflow-x-hidden px-4 py-4 overscroll-contain touch-pan-y">
        {filteredMenuItems.map((item) => {
          const userRoleCode = (user.role?.code || "").toUpperCase()
          // /admin (Monitoring) : actif uniquement sur la page exacte, pas sur /admin/parametrages etc.
          const isActive = menuItemIsActive(pathname, searchParams, item.href, userRoleCode)
          return (
            <Link
              key={item.name}
              href={item.href}
              aria-current={isActive ? "page" : undefined}
              className={`flex items-center px-3 py-2 text-sm font-medium rounded-lg transition-colors ${
                isActive
                  ? "bg-orange-600 text-white shadow-sm"
                  : "text-gray-600 hover:bg-gray-100 hover:text-gray-900"
              }`}
              onClick={() => setIsMobileMenuOpen(false)}
            >
              <item.icon className={`h-5 w-5 mr-3 ${isActive ? "text-white" : ""}`} />
              {item.name}
            </Link>
          )
        })}
      </nav>

      {/* Footer */}
      <div className="shrink-0 px-6 py-4 border-t border-gray-200">
        <p className="text-xs text-gray-500 text-center">
          MENA - République de Côte d'Ivoire
          <br />
          Version 1.0.0
        </p>
      </div>
    </div>
  )

  return (
    <>
      {/* Mobile menu button */}
      <button
        onClick={() => setIsMobileMenuOpen(true)}
        className="lg:hidden fixed top-4 left-4 z-50 p-2 bg-white rounded-lg shadow-lg border"
      >
        <Bars3Icon className="h-6 w-6 text-gray-600" />
      </button>

      {/* Desktop Sidebar */}
      <div className="z-40 hidden bg-white border-r border-gray-200 lg:fixed lg:inset-y-0 lg:flex lg:w-64 lg:flex-col lg:min-h-0">
        <SidebarContent />
      </div>

      {/* Mobile Sidebar — colonne flex + min-h-0 pour que le nav interne puisse défiler */}
      {isMobileMenuOpen && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div className="fixed inset-0 bg-black bg-opacity-50" onClick={() => setIsMobileMenuOpen(false)} />
          <div className="fixed inset-y-0 left-0 flex h-full max-h-[100dvh] w-[min(100%,16rem)] flex-col bg-white shadow-xl">
            <div className="flex shrink-0 items-center justify-between border-b border-gray-200 px-4 py-3">
              <Logo size="sm" showText={true} />
              <button
                type="button"
                onClick={() => setIsMobileMenuOpen(false)}
                className="rounded-lg p-2 hover:bg-gray-100"
                aria-label="Fermer le menu"
              >
                <XMarkIcon className="h-6 w-6 text-gray-600" />
              </button>
            </div>
            <div className="min-h-0 flex-1 overflow-hidden">
              <SidebarContent hideLogo />
            </div>
          </div>
        </div>
      )}
    </>
  )
}
