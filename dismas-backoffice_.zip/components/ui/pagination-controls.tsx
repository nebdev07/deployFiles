/**
 * Composant de contrôles de pagination
 * Utilise les composants UI existants pour une interface cohérente
 */

import React, { useId } from 'react';
import {
  ChevronLeftIcon,
  ChevronRightIcon,
  ChevronDoubleLeftIcon,
  ChevronDoubleRightIcon,
} from '@heroicons/react/24/outline';

interface PaginationControlsProps {
  currentPage: number;
  totalPages: number;
  pageSize: number;
  totalCount: number;
  onPageChange: (page: number) => void;
  onPageSizeChange: (size: number) => void;
  loading?: boolean;
}

const PAGE_SIZE_OPTIONS = [5, 10, 20, 50];

export default function PaginationControls({
  currentPage,
  totalPages,
  pageSize,
  totalCount,
  onPageChange,
  onPageSizeChange,
  loading = false,
}: PaginationControlsProps) {
  const pageSizeFieldId = useId();
  const safeTotalPages = Math.max(1, totalPages);
  // Calculer les éléments affichés
  const startItem = totalCount > 0 ? (currentPage - 1) * pageSize + 1 : 0;
  const endItem = Math.min(currentPage * pageSize, totalCount);

  // Générer les numéros de pages à afficher
  const getPageNumbers = () => {
    const pages: (number | string)[] = [];
    const maxVisiblePages = 5;
    const tp = safeTotalPages;

    if (tp <= maxVisiblePages) {
      for (let i = 1; i <= tp; i++) {
        pages.push(i);
      }
    } else {
      if (currentPage <= 3) {
        for (let i = 1; i <= 4; i++) {
          pages.push(i);
        }
        pages.push('...');
        pages.push(tp);
      } else if (currentPage >= tp - 2) {
        pages.push(1);
        pages.push('...');
        for (let i = tp - 3; i <= tp; i++) {
          pages.push(i);
        }
      } else {
        pages.push(1);
        pages.push('...');
        for (let i = currentPage - 1; i <= currentPage + 1; i++) {
          pages.push(i);
        }
        pages.push('...');
        pages.push(tp);
      }
    }

    return pages;
  };

  const pageNumbers = getPageNumbers();

  if (safeTotalPages <= 1) {
    return (
      <div className="flex items-center justify-between px-4 py-3 bg-white border-t border-gray-200 sm:px-6">
        <div className="flex items-center text-sm text-gray-700">
          <span>
            Affichage de {startItem} à {endItem} sur {totalCount} résultats
          </span>
        </div>
        <div className="flex items-center space-x-2">
          <label htmlFor={pageSizeFieldId} className="text-sm text-gray-700">
            Éléments par page:
          </label>
          <select
            id={pageSizeFieldId}
            value={pageSize}
            onChange={(e) => onPageSizeChange(Number(e.target.value))}
            className="border border-gray-300 rounded px-2 py-1 text-sm"
            disabled={loading}
          >
            {PAGE_SIZE_OPTIONS.map((size) => (
              <option key={size} value={size}>
                {size}
              </option>
            ))}
          </select>
        </div>
      </div>
    );
  }

  return (
    <div className="flex items-center justify-between px-4 py-3 bg-white border-t border-gray-200 sm:px-6">
      {/* Informations sur les résultats */}
      <div className="flex items-center text-sm text-gray-700">
        <span>
          Affichage de {startItem} à {endItem} sur {totalCount} résultats
        </span>
      </div>

      {/* Contrôles de pagination */}
      <div className="flex items-center space-x-4">
        {/* Sélecteur de taille de page */}
        <div className="flex items-center space-x-2">
          <label htmlFor={pageSizeFieldId} className="text-sm text-gray-700">
            Éléments par page:
          </label>
          <select
            id={pageSizeFieldId}
            value={pageSize}
            onChange={(e) => onPageSizeChange(Number(e.target.value))}
            className="border border-gray-300 rounded px-2 py-1 text-sm"
            disabled={loading}
          >
            {PAGE_SIZE_OPTIONS.map((size) => (
              <option key={size} value={size}>
                {size}
              </option>
            ))}
          </select>
        </div>

        {/* Boutons de navigation */}
        <div className="flex items-center space-x-1">
          {/* Première page */}
          <button
            onClick={() => onPageChange(1)}
            disabled={currentPage === 1 || loading}
            className="p-2 text-gray-500 hover:text-gray-700 disabled:opacity-50 disabled:cursor-not-allowed"
            title="Première page"
          >
            <ChevronDoubleLeftIcon className="h-4 w-4" />
          </button>

          {/* Page précédente */}
          <button
            onClick={() => onPageChange(currentPage - 1)}
            disabled={currentPage === 1 || loading}
            className="p-2 text-gray-500 hover:text-gray-700 disabled:opacity-50 disabled:cursor-not-allowed"
            title="Page précédente"
          >
            <ChevronLeftIcon className="h-4 w-4" />
          </button>

          {/* Numéros de pages */}
          <div className="flex items-center space-x-1">
            {pageNumbers.map((page, index) => {
              if (page === '...') {
                return (
                  <span key={`ellipsis-${index}`} className="px-3 py-2 text-gray-500">
                    ...
                  </span>
                );
              }

              const pageNum = page as number;
              const isCurrentPage = pageNum === currentPage;

              return (
                <button
                  key={pageNum}
                  onClick={() => onPageChange(pageNum)}
                  disabled={loading}
                  className={`px-3 py-2 text-sm font-medium rounded-md transition-colors ${
                    isCurrentPage
                      ? 'bg-orange-600 text-white'
                      : 'text-gray-700 hover:bg-gray-100 disabled:opacity-50'
                  }`}
                >
                  {pageNum}
                </button>
              );
            })}
          </div>

          {/* Page suivante */}
          <button
            onClick={() => onPageChange(currentPage + 1)}
            disabled={currentPage === safeTotalPages || loading}
            className="p-2 text-gray-500 hover:text-gray-700 disabled:opacity-50 disabled:cursor-not-allowed"
            title="Page suivante"
          >
            <ChevronRightIcon className="h-4 w-4" />
          </button>

          {/* Dernière page */}
          <button
            onClick={() => onPageChange(safeTotalPages)}
            disabled={currentPage === safeTotalPages || loading}
            className="p-2 text-gray-500 hover:text-gray-700 disabled:opacity-50 disabled:cursor-not-allowed"
            title="Dernière page"
          >
            <ChevronDoubleRightIcon className="h-4 w-4" />
          </button>
        </div>
      </div>
    </div>
  );
}
