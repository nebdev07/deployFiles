'use client';

import React, { useCallback, useEffect, useId, useLayoutEffect, useMemo, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { ChevronDownIcon, MagnifyingGlassIcon } from '@heroicons/react/24/outline';

export type StructureOption = {
  id: number;
  code: string;
  libelle: string;
};

type SearchableStructureSelectProps = {
  id?: string;
  value: string;
  onChange: (value: string) => void;
  options: StructureOption[];
  /** Libellé quand aucune valeur (option vide) */
  emptyLabel: string;
  disabled?: boolean;
  /** Texte du champ de filtre *dans* le panneau ouvert (pas de champ séparé dans le formulaire) */
  filterPlaceholder?: string;
};

/**
 * Liste déroulante type « select » avec filtre de recherche intégré au panneau ouvert.
 * Le panneau est rendu en portail (position fixe) pour ne pas être rogné par les modales scrollables.
 */
export function SearchableStructureSelect({
  id,
  value,
  onChange,
  options,
  emptyLabel,
  disabled = false,
  filterPlaceholder = 'Filtrer la liste…',
}: SearchableStructureSelectProps) {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState('');
  const [mounted, setMounted] = useState(false);
  const [panelBox, setPanelBox] = useState<{ top: number; left: number; width: number } | null>(null);
  const rootRef = useRef<HTMLDivElement>(null);
  const panelRef = useRef<HTMLDivElement>(null);
  const searchInputRef = useRef<HTMLInputElement>(null);
  const uid = useId();
  const filterInputId = id ? `${id}-filter` : `structure-search-${uid}`;

  useEffect(() => {
    setMounted(true);
  }, []);

  const selected = useMemo(
    () => options.find((o) => String(o.id) === value),
    [options, value],
  );

  const displayValue = selected ? `${selected.code} — ${selected.libelle}` : '';

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return options;
    return options.filter(
      (o) =>
        o.code.toLowerCase().includes(q) ||
        (o.libelle && o.libelle.toLowerCase().includes(q)),
    );
  }, [options, query]);

  const updatePanelPosition = useCallback(() => {
    if (!rootRef.current) return;
    const r = rootRef.current.getBoundingClientRect();
    setPanelBox({ top: r.bottom + 4, left: r.left, width: r.width });
  }, []);

  useLayoutEffect(() => {
    if (!open) {
      setPanelBox(null);
      return;
    }
    updatePanelPosition();
  }, [open, updatePanelPosition]);

  useEffect(() => {
    if (!open) return;
    updatePanelPosition();
    window.addEventListener('resize', updatePanelPosition);
    window.addEventListener('scroll', updatePanelPosition, true);
    return () => {
      window.removeEventListener('resize', updatePanelPosition);
      window.removeEventListener('scroll', updatePanelPosition, true);
    };
  }, [open, updatePanelPosition]);

  useEffect(() => {
    if (!open) return;
    setQuery('');
    const t = window.setTimeout(() => searchInputRef.current?.focus(), 0);
    return () => window.clearTimeout(t);
  }, [open]);

  useEffect(() => {
    setQuery('');
  }, [options]);

  useEffect(() => {
    if (!open) return;
    const onDoc = (e: MouseEvent) => {
      const t = e.target as Node;
      if (rootRef.current?.contains(t) || panelRef.current?.contains(t)) return;
      setOpen(false);
    };
    document.addEventListener('mousedown', onDoc);
    return () => document.removeEventListener('mousedown', onDoc);
  }, [open]);

  const pick = (idStr: string) => {
    onChange(idStr);
    setOpen(false);
  };

  const toggle = () => {
    if (disabled) return;
    setOpen((o) => !o);
  };

  const dropdown =
    mounted &&
    open &&
    !disabled &&
    panelBox &&
    createPortal(
      <div
        ref={panelRef}
        style={{
          position: 'fixed',
          top: panelBox.top,
          left: panelBox.left,
          width: panelBox.width,
          zIndex: 10050,
        }}
        className="rounded-lg border border-gray-200 bg-white shadow-lg ring-1 ring-black/5"
        role="listbox"
      >
        <div className="border-b border-gray-100 p-2">
          <label className="sr-only" htmlFor={filterInputId}>
            Filtrer
          </label>
          <div className="relative">
            <MagnifyingGlassIcon
              className="pointer-events-none absolute left-2.5 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400"
              aria-hidden
            />
            <input
              ref={searchInputRef}
              id={filterInputId}
              type="search"
              autoComplete="off"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Escape') {
                  e.stopPropagation();
                  setOpen(false);
                }
              }}
              placeholder={filterPlaceholder}
              className="w-full rounded-md border border-gray-200 py-2 pl-9 pr-3 text-sm focus:border-orange-400 focus:outline-none focus:ring-2 focus:ring-orange-500/30"
            />
          </div>
        </div>
        <ul className="max-h-60 overflow-y-auto py-1">
          <li>
            <button
              type="button"
              role="option"
              aria-selected={value === ''}
              className="w-full px-3 py-2 text-left text-sm text-gray-500 hover:bg-orange-50"
              onClick={() => pick('')}
            >
              {emptyLabel}
            </button>
          </li>
          {filtered.length === 0 ? (
            <li className="px-3 py-4 text-center text-sm text-gray-500">Aucun résultat</li>
          ) : (
            filtered.map((o) => (
              <li key={o.id}>
                <button
                  type="button"
                  role="option"
                  aria-selected={String(o.id) === value}
                  className={`w-full px-3 py-2 text-left text-sm hover:bg-orange-50 ${
                    String(o.id) === value ? 'bg-orange-50 font-medium text-orange-900' : 'text-gray-900'
                  }`}
                  onClick={() => pick(String(o.id))}
                >
                  <span className="block truncate">
                    {o.code} — {o.libelle}
                  </span>
                </button>
              </li>
            ))
          )}
        </ul>
      </div>,
      document.body,
    );

  return (
    <div ref={rootRef} className="relative w-full">
      <button
        id={id}
        type="button"
        disabled={disabled}
        onClick={toggle}
        onKeyDown={(e) => {
          if (e.key === 'Escape' && open) {
            e.preventDefault();
            setOpen(false);
          }
        }}
        className={`input-field flex w-full items-center justify-between gap-2 text-left ${
          disabled ? 'cursor-not-allowed opacity-60' : 'cursor-pointer'
        }`}
        aria-haspopup="listbox"
        aria-expanded={open}
      >
        <span className={`min-w-0 flex-1 truncate ${!value ? 'text-gray-500' : 'text-gray-900'}`}>
          {value ? displayValue : emptyLabel}
        </span>
        <ChevronDownIcon
          className={`h-5 w-5 shrink-0 text-gray-500 transition-transform ${open ? 'rotate-180' : ''}`}
          aria-hidden
        />
      </button>
      {dropdown}
    </div>
  );
}
