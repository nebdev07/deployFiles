import Image from "next/image"
import { getLogoPath } from "@/lib/utils/asset-paths"

interface LogoProps {
  size?: "sm" | "md" | "lg" | "xl"
  showText?: boolean
  className?: string
}

const sizeClasses = {
  sm: "w-8 h-8",
  md: "w-12 h-12",
  lg: "w-16 h-16",
  xl: "w-20 h-20"
}

/** Logo officiel MENA (PNG avec transparence préféré). */
const MINISTRY_LOGO_FILE = "MINISTERE EDUCATION NATIONALE new.png"

export default function Logo({ size = "md", showText = true, className = "" }: LogoProps) {
  const sizeClass = sizeClasses[size]
  
  return (
    <div className={`flex items-center ${className}`}>
      <div className={`${sizeClass} relative flex-shrink-0`}>
        <Image
          src={getLogoPath(MINISTRY_LOGO_FILE)}
          alt="Ministère de l'Éducation Nationale — DISMAS"
          fill
          className="object-contain"
          priority
        />
      </div>
      {showText && (
        <div className="ml-3">
          <h1 className={`font-bold text-gray-900 ${size === 'sm' ? 'text-base' : size === 'md' ? 'text-lg' : size === 'lg' ? 'text-xl' : 'text-2xl'}`}>
            DISMAS
          </h1>
          <p className="text-xs text-gray-500">Côte d'Ivoire</p>
        </div>
      )}
    </div>
  )
}

