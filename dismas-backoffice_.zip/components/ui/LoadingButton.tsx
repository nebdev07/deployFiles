"use client"

import type { ButtonHTMLAttributes, ReactNode } from "react"

type LoadingButtonProps = {
  loading?: boolean
  children: ReactNode
  /** Classes de base (ex. btn-primary) — `disabled` et état chargement sont fusionnés */
  className?: string
} & Omit<ButtonHTMLAttributes<HTMLButtonElement>, "disabled"> & {
  disabled?: boolean
}

/**
 * Bouton qui se désactive dès le premier clic lorsque `loading` est true
 * (à utiliser avec un état `loading` / `busy` pendant l’appel API).
 */
export default function LoadingButton({
  loading = false,
  disabled,
  children,
  className = "",
  type = "button",
  ...rest
}: LoadingButtonProps) {
  const isDisabled = Boolean(disabled || loading)
  return (
    <button type={type} disabled={isDisabled} className={className} {...rest}>
      {children}
    </button>
  )
}
