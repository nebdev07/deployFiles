"use client"

import { useState, useCallback } from "react"
import toast from "react-hot-toast"
import { TruckIcon } from "@heroicons/react/24/outline"
import type { Matiere } from "@/lib/types/entities"
import { useNiveauxScolaires } from "@/hooks/use-niveaux-scolaires"
import { mouvementService } from "@/lib/services/mouvement.service"
import { regulationV2Service } from "@/lib/services/regulation-v2.service"

export interface StockAlimentationDafPanelProps {
  /** PK entrepôt DAF (stock national / don direct). */
  dafStructureId: number
  anneeScolaireId: number
  matieres: Matiere[]
  matieresLoading: boolean
  consultationOnly?: boolean
}

export default function StockAlimentationDafPanel({
  dafStructureId,
  anneeScolaireId,
  matieres,
  matieresLoading,
  consultationOnly = false,
}: StockAlimentationDafPanelProps) {
  const { niveauxScolaires, loading: niveauxLoading } = useNiveauxScolaires()
  const [destStructureId, setDestStructureId] = useState("")
  const [matiereId, setMatiereId] = useState("")
  const [niveauId, setNiveauId] = useState("")
  const [quantite, setQuantite] = useState("")
  const [commentaire, setCommentaire] = useState("")
  const [loadingDispo, setLoadingDispo] = useState(false)
  const [loadingDon, setLoadingDon] = useState(false)
  const [stockDafDisponible, setStockDafDisponible] = useState<number | null>(null)

  const matIdNum = Number(matiereId)
  const nivIdNum = Number(niveauId)
  const canQueryDispo =
    Number.isFinite(matIdNum) &&
    matIdNum > 0 &&
    Number.isFinite(nivIdNum) &&
    nivIdNum > 0

  const loadDispoDaf = useCallback(async () => {
    if (!canQueryDispo) {
      toast.error("Choisissez une matière et un niveau.")
      return
    }
    setLoadingDispo(true)
    setStockDafDisponible(null)
    try {
      const r = await mouvementService.getStockDisponible(
        dafStructureId,
        matIdNum,
        nivIdNum,
        anneeScolaireId
      )
      if (r.success && r.data) {
        setStockDafDisponible(r.data.quantiteDisponible ?? 0)
        toast.success("Stock DAF (entrepôt) chargé")
      } else {
        toast.error(r.message || "Lecture du stock impossible")
      }
    } catch (e: unknown) {
      toast.error(e instanceof Error ? e.message : "Erreur")
    } finally {
      setLoadingDispo(false)
    }
  }, [anneeScolaireId, canQueryDispo, dafStructureId, matIdNum, nivIdNum])

  const handleDon = async () => {
    const dest = Number(destStructureId)
    const q = Number(quantite)
    if (!dest || !matIdNum || !nivIdNum || !q || q <= 0) {
      toast.error("Renseignez l’ID structure destination, la matière, le niveau et une quantité valide.")
      return
    }
    setLoadingDon(true)
    try {
      const r = await regulationV2Service.donDafDirect({
        dafId: dafStructureId,
        destStructureId: dest,
        matiereId: matIdNum,
        niveauId: nivIdNum,
        quantite: q,
        anneeScolaireId,
        commentaire: commentaire.trim() || undefined,
      })
      if (r.hasError) {
        toast.error(r.status?.message ?? "Erreur")
        return
      }
      toast.success("Alimentation enregistrée (débit stock DAF, crédit structure destination).")
      setStockDafDisponible(null)
    } catch (e: unknown) {
      toast.error(e instanceof Error ? e.message : "Erreur")
    } finally {
      setLoadingDon(false)
    }
  }

  return (
    <div className="rounded-lg border border-amber-200 bg-amber-50/60 p-6 text-left">
      <div className="flex items-start gap-3">
        <TruckIcon className="h-8 w-8 shrink-0 text-amber-700" />
        <div>
          <h3 className="text-lg font-semibold text-gray-900">Alimenter une structure (stock national DAF)</h3>
          <p className="mt-1 text-sm text-gray-700 max-w-3xl">
            Crédite le stock d’une <strong>DRENA</strong>, d’une <strong>IEPP</strong> ou d’une <strong>EPP</strong> à partir
            de l’entrepôt DAF. Même règle métier que la régulation <code className="rounded bg-white/80 px-1 text-xs">don DAF
            direct</code> (débit entrepôt, crédit destination). Indiquez l’identifiant de structure administrative de la
            cible.
          </p>
        </div>
      </div>
      <div className="mt-5 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        <div className="sm:col-span-2 lg:col-span-1">
          <label className="block text-xs font-medium text-gray-600">ID structure destination (DRENA, IEPP ou EPP)</label>
          <input
            type="number"
            className="input-field mt-0.5 w-full"
            value={destStructureId}
            onChange={(e) => setDestStructureId(e.target.value)}
            disabled={consultationOnly}
            min={1}
          />
        </div>
        <div>
          <label className="block text-xs font-medium text-gray-600">Matière</label>
          <select
            className="input-field mt-0.5 w-full"
            value={matiereId}
            onChange={(e) => {
              setMatiereId(e.target.value)
              setStockDafDisponible(null)
            }}
            disabled={consultationOnly || matieresLoading}
          >
            <option value="">—</option>
            {matieres
              .filter((m) => typeof m.id === "number" && m.id > 0)
              .map((m) => (
                <option key={m.id} value={m.id}>
                  {m.libelle || m.code || `Matière #${m.id}`}
                </option>
              ))}
          </select>
        </div>
        <div>
          <label className="block text-xs font-medium text-gray-600">Niveau</label>
          <select
            className="input-field mt-0.5 w-full"
            value={niveauId}
            onChange={(e) => {
              setNiveauId(e.target.value)
              setStockDafDisponible(null)
            }}
            disabled={consultationOnly || niveauxLoading}
          >
            <option value="">—</option>
            {niveauxScolaires
              .filter((n) => typeof n.id === "number" && n.id > 0)
              .map((n) => (
                <option key={n.id} value={n.id}>
                  {n.libelle || n.code || `Niveau #${n.id}`}
                </option>
              ))}
          </select>
        </div>
        <div>
          <label className="block text-xs font-medium text-gray-600">Quantité</label>
          <input
            type="number"
            className="input-field mt-0.5 w-full"
            value={quantite}
            onChange={(e) => setQuantite(e.target.value)}
            disabled={consultationOnly}
            min={1}
          />
        </div>
        <div className="sm:col-span-2">
          <label className="block text-xs font-medium text-gray-600">Commentaire (optionnel)</label>
          <input
            type="text"
            className="input-field mt-0.5 w-full"
            value={commentaire}
            onChange={(e) => setCommentaire(e.target.value)}
            disabled={consultationOnly}
          />
        </div>
      </div>
      <div className="mt-4 flex flex-wrap items-center gap-3">
        <button
          type="button"
          className="btn-secondary"
          onClick={() => void loadDispoDaf()}
          disabled={consultationOnly || !canQueryDispo || loadingDispo}
        >
          {loadingDispo ? "Chargement…" : "Consulter stock DAF (ligne)"}
        </button>
        {stockDafDisponible != null && (
          <span className="text-sm text-gray-800">
            Disponible entrepôt (cette matière / niveau / année) :{" "}
            <strong className="text-amber-900">{stockDafDisponible}</strong>
          </span>
        )}
        {!consultationOnly && (
          <button
            type="button"
            className="btn-primary"
            onClick={() => void handleDon()}
            disabled={loadingDon}
          >
            {loadingDon ? "Enregistrement…" : "Valider l’alimentation"}
          </button>
        )}
      </div>
    </div>
  )
}
