/**
 * Configuration PM2 pour le déploiement du backoffice DISMAS sur le VPS.
 * Même structure que arc-nwanyo-ui (/var/www/ui).
 * Répertoire de déploiement sur le VPS : /var/www/dismas
 */
module.exports = {
  apps: [
    {
      name: 'dismas-backoffice',
      script: 'npm',
      args: 'run start -- -p 3002',
      cwd: '/var/www/dismas',
      interpreter: 'node',
      instances: 1,
      autorestart: true,
      watch: false,
      max_memory_restart: '1G',
      env: {
        NODE_ENV: 'production',
        PORT: 3002,
      },
      error_file: '/var/www/dismas/logs/err.log',
      out_file: '/var/www/dismas/logs/out.log',
      log_file: '/var/www/dismas/logs/combined.log',
      time: true,
    },
  ],
};
