// Script autonome intelligent avec correction d'erreurs automatique
const puppeteer = require('puppeteer');
const fs = require('fs');
const path = require('path');

// Configuration des utilisateurs
const users = [
  { role: 'ADMIN', login: 'admin', password: 'admin123' },
  { role: 'DAF', login: 'daf.kouame', password: 'daf123' },
  { role: 'DRENA', login: 'drena.kone', password: 'drena123' },
  { role: 'IEPP', login: 'iepp.assi', password: 'iepp123' },
  { role: 'DIRECTEUR', login: 'dir.kouadio', password: 'dir123' }
];

// Pages AUTORISÉES par rôle (basé sur l'analyse du code)
const authorizedPages = {
  ADMIN: [
    { path: '/dashboard', name: 'Dashboard_Vue_Nationale' },
    { path: '/besoins', name: 'Besoins_Consolidation_Validation' },
    { path: '/stocks', name: 'Stocks_Vue_Complete_Entrepot' },
    { path: '/users', name: 'Users_Liste_Complete' },
    { path: '/commandes', name: 'Commandes_Acces_Autorise' },
    { path: '/admin', name: 'Admin_Monitoring_Systeme' },
    { path: '/admin/parametrages', name: 'Parametrages_Configuration' },
    { path: '/distribution', name: 'Distribution_Vue_Generale' },
    { path: '/regulation', name: 'Regulation_Vue_Generale' },
    { path: '/retours', name: 'Retours_Vue_Generale' },
    { path: '/plaintes', name: 'Plaintes_Vue_Generale' },
    { path: '/enquetes', name: 'Enquetes_Vue_Generale' },
    { path: '/rapports', name: 'Rapports_Vue_Generale' }
  ],
  
  DAF: [
    { path: '/dashboard', name: 'Dashboard_Vue_Financiere' },
    { path: '/besoins', name: 'Besoins_Consolidation_Validation' },
    { path: '/stocks', name: 'Stocks_Vue_Complete_Entrepot' },
    { path: '/users', name: 'Users_Liste_Complete' },
    { path: '/commandes', name: 'Commandes_Gestion_Financiere' },
    { path: '/admin/parametrages', name: 'Parametrages_Configuration' },
    { path: '/distribution', name: 'Distribution_Vue_Generale' },
    { path: '/regulation', name: 'Regulation_Vue_Generale' },
    { path: '/retours', name: 'Retours_Vue_Generale' },
    { path: '/plaintes', name: 'Plaintes_Vue_Generale' },
    { path: '/enquetes', name: 'Enquetes_Vue_Generale' },
    { path: '/rapports', name: 'Rapports_Vue_Generale' }
  ],
  
  DRENA: [
    { path: '/dashboard', name: 'Dashboard_Vue_Regionale' },
    { path: '/besoins', name: 'Besoins_Consolidation_DRENA' },
    { path: '/stocks', name: 'Stocks_Vue_Regionale_Filtree' },
    { path: '/users', name: 'Users_Filtrage_Regional' },
    { path: '/distribution', name: 'Distribution_Vue_Regionale' },
    { path: '/regulation', name: 'Regulation_Vue_Regionale' },
    { path: '/retours', name: 'Retours_Vue_Regionale' },
    { path: '/plaintes', name: 'Plaintes_Vue_Regionale' },
    { path: '/enquetes', name: 'Enquetes_Vue_Regionale' },
    { path: '/rapports', name: 'Rapports_Vue_Regionale' }
  ],
  
  IEPP: [
    { path: '/dashboard', name: 'Dashboard_Vue_Circonscription' },
    { path: '/besoins', name: 'Besoins_Consolidation_IEPP' },
    { path: '/stocks', name: 'Stocks_Vue_Circonscription' },
    { path: '/users', name: 'Users_Filtrage_IEPP' },
    { path: '/distribution', name: 'Distribution_Validation_IEPP' },
    { path: '/regulation', name: 'Regulation_Vue_IEPP' },
    { path: '/retours', name: 'Retours_Vue_IEPP' },
    { path: '/plaintes', name: 'Plaintes_Vue_IEPP' },
    { path: '/enquetes', name: 'Enquetes_Vue_IEPP' },
    { path: '/rapports', name: 'Rapports_Vue_IEPP' }
  ],
  
  DIRECTEUR: [
    { path: '/dashboard', name: 'Dashboard_Vue_Ecole' },
    { path: '/besoins', name: 'Besoins_Saisie_EPP' },
    { path: '/stocks', name: 'Stocks_Vue_Ecole_Seule' },
    { path: '/users', name: 'Users_Profil_Personnel' },
    { path: '/distribution', name: 'Distribution_Confirmation_EPP' },
    { path: '/regulation', name: 'Regulation_Vue_EPP' },
    { path: '/retours', name: 'Retours_Vue_EPP' },
    { path: '/plaintes', name: 'Plaintes_Depot_Suivi' },
    { path: '/enquetes', name: 'Enquetes_Reponse_EPP' },
    { path: '/rapports', name: 'Rapports_Vue_EPP' }
  ]
};

// Pages avec accès restreint à éviter
const restrictedPages = {
  DRENA: ['/commandes', '/admin', '/admin/parametrages'],
  IEPP: ['/commandes', '/admin', '/admin/parametrages'],
  DIRECTEUR: ['/commandes', '/admin', '/admin/parametrages']
};

class AutonomousCapture {
  constructor() {
    this.browser = null;
    this.currentPage = null;
    this.capturesDir = './captures';
    this.successCount = 0;
    this.errorCount = 0;
    this.retryCount = 3;
  }

  async init() {
    console.log('🤖 SCRIPT AUTONOME INTELLIGENT - CORRECTION D\'ERREURS AUTOMATIQUE');
    console.log('🔧 Détecte et corrige automatiquement les erreurs de navigation');
    console.log('🚫 Ignore les pages d\'accès restreint selon les rôles');
    console.log('🔄 Continue malgré les déconnexions et erreurs\n');

    // Créer dossier captures
    if (!fs.existsSync(this.capturesDir)) {
      fs.mkdirSync(this.capturesDir);
      console.log('📁 Dossier captures créé\n');
    }

    // Lancer navigateur
    this.browser = await puppeteer.launch({ 
      headless: false,
      defaultViewport: { width: 1920, height: 1080 },
      slowMo: 50,
      args: ['--no-sandbox', '--disable-web-security']
    });

    console.log('✅ Navigateur lancé\n');
  }

  async isPageAccessible(url) {
    try {
      const response = await this.currentPage.goto(url, { 
        waitUntil: 'domcontentloaded', 
        timeout: 10000 
      });
      
      await this.currentPage.waitForTimeout(2000);
      
      // Vérifier si on a une page d'accès restreint
      const content = await this.currentPage.content();
      const isRestricted = content.includes('Accès Restreint') || 
                          content.includes('Access Denied') ||
                          content.includes('Non autorisé') ||
                          response.status() === 403;
      
      return !isRestricted;
    } catch (error) {
      return false;
    }
  }

  async smartLogin(user) {
    console.log(`🔑 Connexion intelligente pour ${user.role}...`);
    
    for (let attempt = 1; attempt <= this.retryCount; attempt++) {
      try {
        // Aller à la page de login
        await this.currentPage.goto('http://localhost:3000', { 
          waitUntil: 'domcontentloaded',
          timeout: 15000 
        });
        await this.currentPage.waitForTimeout(2000);

        // Vérifier si déjà connecté
        const currentUrl = this.currentPage.url();
        if (currentUrl.includes('dashboard')) {
          console.log('   ✅ Déjà connecté');
          return true;
        }

        // Stratégies multiples de connexion
        const loginStrategies = [
          // Stratégie 1: Sélecteurs CSS classiques
          async () => {
            await this.currentPage.waitForSelector('input[type="text"]', { timeout: 5000 });
            await this.currentPage.type('input[type="text"]', user.login, { delay: 30 });
            await this.currentPage.type('input[type="password"]', user.password, { delay: 30 });
            await this.currentPage.click('button[type="submit"]');
          },
          
          // Stratégie 2: Par position des éléments
          async () => {
            const inputs = await this.currentPage.$$('input');
            const buttons = await this.currentPage.$$('button');
            
            if (inputs.length >= 2 && buttons.length >= 1) {
              await inputs[0].type(user.login, { delay: 30 });
              await inputs[1].type(user.password, { delay: 30 });
              await buttons[0].click();
            }
          },
          
          // Stratégie 3: Sélecteurs génériques
          async () => {
            await this.currentPage.evaluate((login, password) => {
              const inputs = document.querySelectorAll('input');
              if (inputs.length >= 2) {
                inputs[0].value = login;
                inputs[1].value = password;
                
                const buttons = document.querySelectorAll('button');
                if (buttons.length > 0) {
                  buttons[0].click();
                }
              }
            }, user.login, user.password);
          }
        ];

        // Essayer chaque stratégie
        for (const strategy of loginStrategies) {
          try {
            await strategy();
            
            // Attendre la redirection
            await this.currentPage.waitForTimeout(3000);
            
            const newUrl = this.currentPage.url();
            if (newUrl.includes('dashboard') || newUrl !== 'http://localhost:3000/') {
              console.log(`   ✅ Connexion réussie (tentative ${attempt})`);
              return true;
            }
          } catch (strategyError) {
            continue; // Essayer la stratégie suivante
          }
        }

        console.log(`   ⚠️  Tentative ${attempt} échouée, retry...`);
        await this.currentPage.waitForTimeout(1000);
        
      } catch (error) {
        console.log(`   ❌ Erreur tentative ${attempt}: ${error.message}`);
      }
    }

    console.log('   ❌ Connexion échouée après toutes les tentatives');
    return false;
  }

  async smartCapture(user, pageConfig) {
    const maxRetries = 2;
    
    for (let attempt = 1; attempt <= maxRetries; attempt++) {
      try {
        console.log(`   📱 [Tentative ${attempt}] ${pageConfig.name}...`);
        
        // Vérifier l'accès à la page
        const isAccessible = await this.isPageAccessible(`http://localhost:3000${pageConfig.path}`);
        
        if (!isAccessible) {
          console.log(`   🚫 Page restreinte ignorée: ${pageConfig.path}`);
          return { success: false, reason: 'restricted' };
        }

        // Attendre le chargement complet
        await this.currentPage.waitForTimeout(3000);

        // Vérifier si on est toujours connecté
        const currentUrl = this.currentPage.url();
        if (currentUrl.includes('login') || currentUrl === 'http://localhost:3000/') {
          console.log('   🔄 Déconnexion détectée, reconnexion...');
          const reconnected = await this.smartLogin(user);
          if (!reconnected) {
            throw new Error('Reconnexion échouée');
          }
          
          // Retenter la navigation
          await this.currentPage.goto(`http://localhost:3000${pageConfig.path}`, { 
            waitUntil: 'domcontentloaded' 
          });
          await this.currentPage.waitForTimeout(3000);
        }

        // Scroll vers le haut pour capture complète
        await this.currentPage.evaluate(() => {
          window.scrollTo(0, 0);
        });
        await this.currentPage.waitForTimeout(1000);

        // Capture
        const filename = `${user.role}_${pageConfig.name}.png`;
        await this.currentPage.screenshot({ 
          path: path.join(this.capturesDir, filename),
          fullPage: true,
          quality: 85
        });

        console.log(`   ✅ ${filename}`);
        this.successCount++;
        return { success: true };

      } catch (error) {
        console.log(`   ⚠️  Tentative ${attempt} échouée: ${error.message}`);
        
        if (attempt < maxRetries) {
          // Attendre avant retry
          await this.currentPage.waitForTimeout(2000);
          
          // Tenter une reconnexion si nécessaire
          try {
            await this.smartLogin(user);
          } catch (loginError) {
            // Ignore les erreurs de reconnexion
          }
        }
      }
    }

    console.log(`   ❌ Échec définitif pour ${pageConfig.name}`);
    this.errorCount++;
    return { success: false, reason: 'error' };
  }

  async captureUser(user) {
    console.log(`${'='.repeat(70)}`);
    console.log(`🔐 RÔLE: ${user.role} (${user.login})`);
    console.log(`${'='.repeat(70)}`);

    this.currentPage = await this.browser.newPage();
    
    try {
      // Connexion intelligente
      const loginSuccess = await this.smartLogin(user);
      if (!loginSuccess) {
        console.log(`❌ Impossible de connecter ${user.role}, passage au suivant\n`);
        return;
      }

      // Obtenir les pages autorisées pour ce rôle
      const userPages = authorizedPages[user.role] || [];
      const restricted = restrictedPages[user.role] || [];
      
      // Filtrer les pages restreintes
      const allowedPages = userPages.filter(page => 
        !restricted.includes(page.path)
      );

      console.log(`📸 ${allowedPages.length} pages autorisées à capturer`);
      console.log(`🚫 ${restricted.length} pages restreintes ignorées\n`);

      // Capturer chaque page
      for (let i = 0; i < allowedPages.length; i++) {
        const pageConfig = allowedPages[i];
        console.log(`[${i + 1}/${allowedPages.length}] ${pageConfig.path}`);
        
        const result = await this.smartCapture(user, pageConfig);
        
        // Petite pause entre les captures
        await this.currentPage.waitForTimeout(500);
      }

      console.log(`✅ Terminé pour ${user.role}\n`);

    } catch (error) {
      console.log(`❌ Erreur globale ${user.role}: ${error.message}\n`);
      this.errorCount++;
    } finally {
      await this.currentPage.close();
    }
  }

  async run() {
    try {
      await this.init();

      for (let i = 0; i < users.length; i++) {
        const user = users[i];
        await this.captureUser(user);
      }

    } catch (error) {
      console.log(`💥 Erreur fatale: ${error.message}`);
    } finally {
      if (this.browser) {
        await this.browser.close();
        console.log('🌐 Navigateur fermé');
      }

      // Rapport final
      console.log('\n' + '='.repeat(70));
      console.log('📊 RAPPORT FINAL');
      console.log('='.repeat(70));
      console.log(`✅ Captures réussies: ${this.successCount}`);
      console.log(`❌ Erreurs/Restrictions: ${this.errorCount}`);
      console.log(`📁 Dossier: ${this.capturesDir}`);
      console.log('='.repeat(70));
    }
  }
}

// Lancement du script autonome
console.log('🚀 Lancement du script autonome dans 3 secondes...\n');

setTimeout(async () => {
  const capture = new AutonomousCapture();
  await capture.run();
}, 3000);