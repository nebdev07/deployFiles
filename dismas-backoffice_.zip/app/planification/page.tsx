"use client"

import { useState } from "react"
import MainLayout from "../../components/layout/main-layout"
import { useAuth } from "../providers"
import {
  CalculatorIcon,
  DocumentTextIcon,
  EyeIcon,
  ArrowDownTrayIcon,
  CheckCircleIcon,
  ClockIcon,
  ExclamationTriangleIcon,
  UserGroupIcon,
  BuildingOfficeIcon,
  MapIcon,
  ChartBarIcon,
} from "@heroicons/react/24/outline"

// Données mockées de la planification
const mockPlanification = {
  annee_scolaire: "2024-2025",
  statut_global: "EN_COURS",
  date_debut: "2024-09-01",
  date_fin: "2024-12-31",
  
  // Étapes du processus
  etapes: [
    {
      id: 1,
      nom: "Expression des Besoins",
      description: "Saisie des besoins par les EPP",
      statut: "TERMINEE",
      date_debut: "2024-09-01",
      date_fin: "2024-09-15",
      progression: 100,
      responsable: "DIRECTEUR",
    },
    {
      id: 2,
      nom: "Consolidation IEPP",
      description: "Consolidation des besoins par IEPP",
      statut: "TERMINEE",
      date_debut: "2024-09-16",
      date_fin: "2024-09-25",
      progression: 100,
      responsable: "IEPP",
    },
    {
      id: 3,
      nom: "Consolidation DRENA",
      description: "Consolidation des besoins par DRENA",
      statut: "TERMINEE",
      date_debut: "2024-09-26",
      date_fin: "2024-10-05",
      progression: 100,
      responsable: "DRENA",
    },
    {
      id: 4,
      nom: "Validation Nationale",
      description: "Validation des besoins par la DAF",
      statut: "TERMINEE",
      date_debut: "2024-10-06",
      date_fin: "2024-10-10",
      progression: 100,
      responsable: "DAF",
    },
    {
      id: 5,
      nom: "Commande Manuels",
      description: "Saisie des commandes par la DAF",
      statut: "EN_COURS",
      date_debut: "2024-10-11",
      date_fin: "2024-10-25",
      progression: 75,
      responsable: "DAF",
    },
    {
      id: 6,
      nom: "Génération Tableau Répartition",
      description: "Génération du tableau de répartition",
      statut: "EN_COURS",
      date_debut: "2024-10-20",
      date_fin: "2024-10-30",
      progression: 60,
      responsable: "DAF",
    },
    {
      id: 7,
      nom: "Validation Répartition",
      description: "Validation du tableau de répartition",
      statut: "EN_ATTENTE",
      date_debut: "2024-10-31",
      date_fin: "2024-11-05",
      progression: 0,
      responsable: "DAF",
    },
    {
      id: 8,
      nom: "Distribution",
      description: "Distribution des manuels selon le tableau",
      statut: "EN_ATTENTE",
      date_debut: "2024-11-06",
      date_fin: "2024-12-15",
      progression: 0,
      responsable: "LIBRAIRE",
    },
  ],

  // Statistiques globales
  statistiques: {
    total_effectifs: 3200000,
    total_manuels_requis: 12800000,
    total_manuels_commandes: 1455000,
    couverture_globale: 78,
    epp_participantes: 1250,
    iepp_participantes: 45,
    drena_participantes: 10,
    commandes_en_cours: 2,
    commandes_terminees: 1,
  },

  // Alertes et notifications
  alertes: [
    {
      id: 1,
      type: "WARNING",
      message: "Délai critique pour la consolidation DRENA Bouaké",
      date: "2024-10-20",
      priorite: "HAUTE",
    },
    {
      id: 2,
      type: "INFO",
      message: "Commande CMD-2024-001 validée et transmise au fournisseur",
      date: "2024-10-19",
      priorite: "MOYENNE",
    },
    {
      id: 3,
      type: "SUCCESS",
      message: "Expression des besoins terminée pour 95% des EPP",
      date: "2024-10-18",
      priorite: "BASSE",
    },
  ],
}

export default function PlanificationPage() {
  const { user } = useAuth()
  const [activeTab, setActiveTab] = useState("processus")

  // ✅ CORRECTION: Vérification après tous les hooks
  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <p className="text-gray-600">Chargement...</p>
        </div>
      </div>
    )
  }

  const getStatusIcon = (statut: string) => {
    switch (statut) {
      case "TERMINEE":
        return <CheckCircleIcon className="h-5 w-5 text-green-600" />
      case "EN_COURS":
        return <ClockIcon className="h-5 w-5 text-blue-600" />
      case "EN_ATTENTE":
        return <ExclamationTriangleIcon className="h-5 w-5 text-yellow-600" />
      default:
        return <ExclamationTriangleIcon className="h-5 w-5 text-gray-600" />
    }
  }

  const getStatusBadge = (statut: string) => {
    const baseClasses = "px-2 py-1 text-xs font-medium rounded-full"
    switch (statut) {
      case "TERMINEE":
        return <span className={`${baseClasses} bg-green-100 text-green-800`}>Terminée</span>
      case "EN_COURS":
        return <span className={`${baseClasses} bg-blue-100 text-blue-800`}>En cours</span>
      case "EN_ATTENTE":
        return <span className={`${baseClasses} bg-yellow-100 text-yellow-800`}>En attente</span>
      default:
        return <span className={`${baseClasses} bg-gray-100 text-gray-800`}>Inconnu</span>
    }
  }

  const getAlertIcon = (type: string) => {
    switch (type) {
      case "WARNING":
        return <ExclamationTriangleIcon className="h-5 w-5 text-yellow-600" />
      case "INFO":
        return <ClockIcon className="h-5 w-5 text-blue-600" />
      case "SUCCESS":
        return <CheckCircleIcon className="h-5 w-5 text-green-600" />
      default:
        return <ExclamationTriangleIcon className="h-5 w-5 text-gray-600" />
    }
  }

  const formatNumber = (num: number) => {
    return new Intl.NumberFormat('fr-FR').format(num)
  }

  const tabs = [
    { id: "processus", name: "Processus", icon: CalculatorIcon },
    { id: "statistiques", name: "Statistiques", icon: ChartBarIcon },
    { id: "alertes", name: "Alertes", icon: ExclamationTriangleIcon },
  ]

  return (
    <MainLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Planification</h1>
            <p className="text-gray-600">
              Gestion du processus de planification des manuels scolaires
            </p>
          </div>
          
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              {getStatusIcon(mockPlanification.statut_global)}
              {getStatusBadge(mockPlanification.statut_global)}
            </div>
            <span className="text-sm text-gray-500">
              {mockPlanification.date_debut} - {mockPlanification.date_fin}
            </span>
          </div>
        </div>

        {/* Tabs */}
        <div className="border-b border-gray-200">
          <nav className="-mb-px flex space-x-8">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`py-2 px-1 border-b-2 font-medium text-sm flex items-center space-x-2 ${
                  activeTab === tab.id
                    ? "border-orange-500 text-orange-600"
                    : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
                }`}
              >
                <tab.icon className="h-4 w-4" />
                <span>{tab.name}</span>
              </button>
            ))}
          </nav>
        </div>

        {/* Content */}
        <div className="space-y-6">
          {activeTab === "processus" && (
            <div className="space-y-6">
              {/* Timeline du processus */}
              <div className="bg-white rounded-lg shadow">
                <div className="px-6 py-4 border-b border-gray-200">
                  <h3 className="text-lg font-medium text-gray-900">Timeline du Processus</h3>
                </div>
                <div className="p-6">
                  <div className="space-y-6">
                    {mockPlanification.etapes.map((etape, index) => (
                      <div key={etape.id} className="flex items-start space-x-4">
                        {/* Timeline dot */}
                        <div className="flex-shrink-0">
                          <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                            etape.statut === "TERMINEE" ? "bg-green-500" :
                            etape.statut === "EN_COURS" ? "bg-blue-500" :
                            "bg-gray-300"
                          }`}>
                            {getStatusIcon(etape.statut)}
                          </div>
                          {index < mockPlanification.etapes.length - 1 && (
                            <div className="w-0.5 h-12 bg-gray-300 mx-auto mt-2"></div>
                          )}
                        </div>

                        {/* Étape content */}
                        <div className="flex-1 bg-gray-50 rounded-lg p-4">
                          <div className="flex items-center justify-between mb-2">
                            <h4 className="font-medium text-gray-900">{etape.nom}</h4>
                            {getStatusBadge(etape.statut)}
                          </div>
                          <p className="text-sm text-gray-600 mb-3">{etape.description}</p>
                          
                          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                            <div>
                              <span className="text-gray-500">Responsable:</span>
                              <span className="ml-1 font-medium">{etape.responsable}</span>
                            </div>
                            <div>
                              <span className="text-gray-500">Début:</span>
                              <span className="ml-1 font-medium">{etape.date_debut}</span>
                            </div>
                            <div>
                              <span className="text-gray-500">Fin:</span>
                              <span className="ml-1 font-medium">{etape.date_fin}</span>
                            </div>
                            <div>
                              <span className="text-gray-500">Progression:</span>
                              <span className="ml-1 font-medium">{etape.progression}%</span>
                            </div>
                          </div>

                          {/* Progress bar */}
                          <div className="mt-3">
                            <div className="w-full bg-gray-200 rounded-full h-2">
                              <div 
                                className={`h-2 rounded-full ${
                                  etape.statut === "TERMINEE" ? "bg-green-600" :
                                  etape.statut === "EN_COURS" ? "bg-blue-600" :
                                  "bg-gray-400"
                                }`}
                                style={{ width: `${etape.progression}%` }}
                              ></div>
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === "statistiques" && (
            <div className="space-y-6">
              {/* Statistiques globales */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <div className="bg-white rounded-lg shadow p-6">
                  <div className="flex items-center">
                    <div className="flex-shrink-0">
                      <UserGroupIcon className="h-8 w-8 text-blue-600" />
                    </div>
                    <div className="ml-4">
                      <p className="text-sm font-medium text-gray-500">Effectifs Totaux</p>
                      <p className="text-2xl font-semibold text-gray-900">
                        {formatNumber(mockPlanification.statistiques.total_effectifs)}
                      </p>
                    </div>
                  </div>
                </div>

                <div className="bg-white rounded-lg shadow p-6">
                  <div className="flex items-center">
                    <div className="flex-shrink-0">
                      <DocumentTextIcon className="h-8 w-8 text-green-600" />
                    </div>
                    <div className="ml-4">
                      <p className="text-sm font-medium text-gray-500">Manuels Requis</p>
                      <p className="text-2xl font-semibold text-gray-900">
                        {formatNumber(mockPlanification.statistiques.total_manuels_requis)}
                      </p>
                    </div>
                  </div>
                </div>

                <div className="bg-white rounded-lg shadow p-6">
                  <div className="flex items-center">
                    <div className="flex-shrink-0">
                      <BuildingOfficeIcon className="h-8 w-8 text-orange-600" />
                    </div>
                    <div className="ml-4">
                      <p className="text-sm font-medium text-gray-500">Structures</p>
                      <p className="text-2xl font-semibold text-gray-900">
                        {mockPlanification.statistiques.epp_participantes} EPP
                      </p>
                    </div>
                  </div>
                </div>

                <div className="bg-white rounded-lg shadow p-6">
                  <div className="flex items-center">
                    <div className="flex-shrink-0">
                      <CalculatorIcon className="h-8 w-8 text-purple-600" />
                    </div>
                    <div className="ml-4">
                      <p className="text-sm font-medium text-gray-500">Couverture</p>
                      <p className="text-2xl font-semibold text-gray-900">
                        {mockPlanification.statistiques.couverture_globale}%
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Détail des structures */}
              <div className="bg-white rounded-lg shadow">
                <div className="px-6 py-4 border-b border-gray-200">
                  <h3 className="text-lg font-medium text-gray-900">Participation par Niveau</h3>
                </div>
                <div className="p-6">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div className="text-center">
                      <div className="text-3xl font-bold text-blue-600">
                        {mockPlanification.statistiques.epp_participantes}
                      </div>
                      <div className="text-sm text-gray-500">Écoles Primaires</div>
                    </div>
                    <div className="text-center">
                      <div className="text-3xl font-bold text-green-600">
                        {mockPlanification.statistiques.iepp_participantes}
                      </div>
                      <div className="text-sm text-gray-500">IEPP</div>
                    </div>
                    <div className="text-center">
                      <div className="text-3xl font-bold text-orange-600">
                        {mockPlanification.statistiques.drena_participantes}
                      </div>
                      <div className="text-sm text-gray-500">DRENA</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === "alertes" && (
            <div className="space-y-6">
              {mockPlanification.alertes.map((alerte) => (
                <div key={alerte.id} className="bg-white rounded-lg shadow p-6">
                  <div className="flex items-start space-x-4">
                    <div className="flex-shrink-0">
                      {getAlertIcon(alerte.type)}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <h4 className="font-medium text-gray-900">{alerte.message}</h4>
                        <span className="text-sm text-gray-500">{alerte.date}</span>
                      </div>
                      <div className="mt-2">
                        <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                          alerte.priorite === "HAUTE" ? "bg-red-100 text-red-800" :
                          alerte.priorite === "MOYENNE" ? "bg-yellow-100 text-yellow-800" :
                          "bg-green-100 text-green-800"
                        }`}>
                          {alerte.priorite}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </MainLayout>
  )
} 