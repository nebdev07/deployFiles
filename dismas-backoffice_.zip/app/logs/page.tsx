"use client"

import { useCallback, useEffect, useState } from "react"
import MainLayout from "@/components/layout/main-layout"
import PaginationControls from "@/components/ui/pagination-controls"
import { useAuth } from "@/app/providers"
import { canAccessLogsPage } from "@/lib/utils/functionality-permissions"
import { logsService, type LogRow } from "@/lib/services/logs.service"
import { formatDateTime } from "@/lib/utils/user-mapping"
import {
  ArrowPathIcon,
  QueueListIcon,
  ShieldExclamationIcon,
} from "@heroicons/react/24/outline"
import toast from "react-hot-toast"

function pickStr(row: LogRow, ...keys: string[]): string {
  for (const k of keys) {
    const v = row[k]
    if (v != null && String(v).trim() !== "") return String(v)
  }
  return "—"
}

export default function LogsPage() {
  const { user } = useAuth()
  const allowed = user ? canAccessLogsPage(user.role?.code, user.functionalityPermissions) : false

  const [rows, setRows] = useState<LogRow[]>([])
  const [total, setTotal] = useState(0)
  const [loading, setLoading] = useState(true)
  const [currentPage, setCurrentPage] = useState(1)
  const [pageSize, setPageSize] = useState(10)
  const [archivingId, setArchivingId] = useState<number | null>(null)

  const load = useCallback(async () => {
    if (!allowed) return
    setLoading(true)
    try {
      const res = await logsService.list(currentPage - 1, pageSize)
      if (res.hasError) {
        toast.error(res.status?.message || "Impossible de charger le journal")
        setRows([])
        setTotal(0)
        return
      }
      setRows(res.items ?? [])
      setTotal(typeof res.count === "number" ? Number(res.count) : res.items?.length ?? 0)
    } catch (e: unknown) {
      const msg = e && typeof e === "object" && "message" in e ? String((e as { message?: string }).message) : "Erreur chargement"
      toast.error(msg)
      setRows([])
      setTotal(0)
    } finally {
      setLoading(false)
    }
  }, [allowed, currentPage, pageSize])

  useEffect(() => {
    void load()
  }, [load])

  const handleArchive = async (row: LogRow) => {
    const id = row.id
    if (id == null) return
    if (!window.confirm("Archiver cette entrée du journal ? Elle ne sera plus affichée dans la liste courante.")) return
    setArchivingId(id)
    try {
      const res = await logsService.archive(id)
      if (res.hasError) {
        toast.error(res.status?.message || "Archivage impossible")
        return
      }
      toast.success("Entrée archivée")
      await load()
    } catch (e: unknown) {
      const msg = e && typeof e === "object" && "message" in e ? String((e as { message?: string }).message) : "Erreur"
      toast.error(msg)
    } finally {
      setArchivingId(null)
    }
  }

  const handlePageSizeChange = (size: number) => {
    setPageSize(size)
    setCurrentPage(1)
  }

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p className="text-gray-600">Chargement…</p>
      </div>
    )
  }

  if (!allowed) {
    return (
      <MainLayout>
        <div className="text-center py-16 max-w-lg mx-auto">
          <ShieldExclamationIcon className="h-16 w-16 text-amber-500 mx-auto mb-4" />
          <h2 className="text-xl font-semibold text-gray-900 mb-2">Accès restreint</h2>
          <p className="text-gray-600">
            Accès réservé : permission journal d&apos;activité (lecture) ou profils DAF / ADMIN selon paramétrage
            historique.
          </p>
        </div>
      </MainLayout>
    )
  }

  const totalPages = total <= 0 ? 0 : Math.ceil(total / pageSize)

  return (
    <MainLayout>
      <div className="space-y-6">
        <div className="relative overflow-hidden rounded-2xl border border-gray-200/80 bg-white shadow-sm">
          <div className="absolute inset-0 bg-gradient-to-br from-slate-50/90 via-white to-orange-50/50 pointer-events-none" />
          <div className="relative flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 p-6 sm:p-8">
            <div className="flex gap-4">
              <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl bg-gradient-to-br from-slate-700 to-slate-900 text-white shadow-lg">
                <QueueListIcon className="h-8 w-8" />
              </div>
              <div>
                <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-gray-900">Journal d&apos;activité</h1>
                <p className="mt-1 text-gray-600 max-w-2xl">
                  Historique des actions applicatives. L&apos;archivage masque l&apos;entrée (suppression logique).
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={() => void load()}
              className="btn-outline inline-flex items-center shrink-0"
              disabled={loading || archivingId != null}
            >
              <ArrowPathIcon className={`h-5 w-5 mr-2 ${loading ? "animate-spin" : ""}`} />
              Actualiser
            </button>
          </div>
        </div>

        <div className="card border-0 shadow-md ring-1 ring-gray-100 overflow-hidden">
          <div className="overflow-x-auto -mx-px">
            <table className="table min-w-[880px]">
              <thead className="bg-gradient-to-r from-gray-50 to-slate-50/80">
                <tr>
                  <th className="!font-semibold text-gray-700">Date</th>
                  <th className="!font-semibold text-gray-700">Matricule</th>
                  <th className="!font-semibold text-gray-700">Action</th>
                  <th className="!font-semibold text-gray-700">Entité</th>
                  <th className="!font-semibold text-gray-700">Détails</th>
                  <th className="!font-semibold text-gray-700">IP</th>
                  <th className="!font-semibold text-gray-700 text-right">Archiver</th>
                </tr>
              </thead>
              <tbody>
                {loading ? (
                  <tr>
                    <td colSpan={7} className="text-center py-10 text-gray-500">
                      <ArrowPathIcon className="h-5 w-5 animate-spin inline mr-2" />
                      Chargement…
                    </td>
                  </tr>
                ) : rows.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="text-center py-10 text-gray-500">
                      Aucune entrée pour cette page.
                    </td>
                  </tr>
                ) : (
                  rows.map((row) => (
                    <tr key={row.id ?? pickStr(row, "createdat", "dateAction")}>
                      <td className="whitespace-nowrap text-sm text-gray-800">
                        {formatDateTime(
                          pickStr(row, "dateAction", "dateEvenement", "createdat") !== "—"
                            ? pickStr(row, "dateAction", "dateEvenement", "createdat")
                            : undefined,
                        )}
                      </td>
                      <td className="text-sm">
                        <span className="font-medium text-gray-900">{pickStr(row, "login")}</span>
                        {row.userId != null && (
                          <span className="block text-xs text-gray-500 font-mono">id {row.userId}</span>
                        )}
                      </td>
                      <td className="text-sm text-gray-900">{pickStr(row, "action")}</td>
                      <td className="text-sm text-gray-700">{pickStr(row, "entity", "entite")}</td>
                      <td className="text-sm text-gray-600 max-w-[280px]">
                        <span className="line-clamp-2" title={pickStr(row, "details")}>
                          {pickStr(row, "details")}
                        </span>
                      </td>
                      <td className="text-xs font-mono text-gray-500">{pickStr(row, "ip", "ipAdresse")}</td>
                      <td className="text-right">
                        {row.id != null ? (
                          <button
                            type="button"
                            className="btn-outline text-xs py-1 px-2"
                            disabled={archivingId === row.id || loading}
                            onClick={() => void handleArchive(row)}
                          >
                            {archivingId === row.id ? (
                              <ArrowPathIcon className="h-4 w-4 animate-spin inline" />
                            ) : (
                              "Archiver"
                            )}
                          </button>
                        ) : (
                          "—"
                        )}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>

        {!loading && total > 0 && (
          <PaginationControls
            currentPage={currentPage}
            totalPages={Math.max(1, totalPages)}
            pageSize={pageSize}
            totalCount={total}
            onPageChange={setCurrentPage}
            onPageSizeChange={handlePageSizeChange}
            loading={loading || archivingId != null}
          />
        )}
      </div>
    </MainLayout>
  )
}
