"use client"

import { useCallback, useEffect, useState } from "react"
import MainLayout from "../../components/layout/main-layout"
import { useAuth } from "../providers"
import {
  PlusIcon,
  ExclamationTriangleIcon,
  CheckCircleIcon,
  ClockIcon,
  XCircleIcon,
  MagnifyingGlassIcon,
  PencilIcon,
  TrashIcon,
} from "@heroicons/react/24/outline"
import { plainteService, type PlainteRow } from "@/lib/services/plainte.service"
import { ParametrageService } from "@/lib/services/parametrage.service"
import type { StructureAdministrative } from "@/lib/types/entities"
import toast from "react-hot-toast"
import { canAccessPlaintesPage } from "@/lib/utils/functionality-permissions"

const parametrageService = new ParametrageService()

function formatInstant(iso?: string | null): string {
  if (!iso) return "—"
  const d = new Date(iso)
  return Number.isNaN(d.getTime()) ? iso : d.toLocaleString("fr-FR")
}

function formatDateOnly(iso?: string | null): string {
  if (!iso) return "—"
  const d = new Date(iso)
  return Number.isNaN(d.getTime()) ? iso : d.toLocaleDateString("fr-FR")
}

const TYPE_OPTIONS = [
  { value: "MANQUE_MANUEL", label: "Manque de manuel" },
  { value: "RETARD_DISTRIBUTION", label: "Retard de distribution" },
  { value: "QUALITE_MANUEL", label: "Qualité du manuel" },
  { value: "AUTRE", label: "Autre" },
]

export default function PlaintesPage() {
  const { user, isLoading: authLoading } = useAuth()
  const [plaintes, setPlaintes] = useState<PlainteRow[]>([])
  const [structuresEpp, setStructuresEpp] = useState<StructureAdministrative[]>([])
  const [loading, setLoading] = useState(true)
  const [selectedPlainte, setSelectedPlainte] = useState<PlainteRow | null>(null)
  const [editingPlainte, setEditingPlainte] = useState<PlainteRow | null>(null)
  const [showModal, setShowModal] = useState(false)
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedFilter, setSelectedFilter] = useState("all")

  const [formNom, setFormNom] = useState("")
  const [formTel, setFormTel] = useState("")
  const [formEmail, setFormEmail] = useState("")
  const [formStructureId, setFormStructureId] = useState<number | "">("")
  const [formType, setFormType] = useState("MANQUE_MANUEL")
  const [formPriorite, setFormPriorite] = useState("MOYENNE")
  const [formObjet, setFormObjet] = useState("")
  const [formDescription, setFormDescription] = useState("")

  const loadData = useCallback(async () => {
    setLoading(true)
    try {
      const [pRes, sRes] = await Promise.all([plainteService.list({}), parametrageService.getStructuresByType("EPP")])
      setPlaintes(pRes.items ?? [])
      setStructuresEpp(sRes.items ?? [])
    } catch (e: unknown) {
      const msg = e && typeof e === "object" && "message" in e ? String((e as { message?: string }).message) : "Erreur chargement"
      toast.error(msg)
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    if (!user || authLoading) return
    void loadData()
  }, [user, authLoading, loadData])

  const resetCreateForm = () => {
    setFormNom("")
    setFormTel("")
    setFormEmail("")
    setFormStructureId("")
    setFormType("MANQUE_MANUEL")
    setFormPriorite("MOYENNE")
    setFormObjet("")
    setFormDescription("")
  }

  const openCreateModal = () => {
    resetCreateForm()
    setShowModal(true)
  }

  const submitCreate = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!formStructureId || !formObjet.trim() || !formDescription.trim()) {
      toast.error("Structure, objet et description sont requis")
      return
    }
    try {
      await plainteService.create({
        structureId: Number(formStructureId),
        motif: formType,
        objet: formObjet.trim(),
        description: formDescription.trim(),
        nomPlaignant: formNom.trim() || undefined,
        contactPlaignant: formTel.trim() || undefined,
        emailPlaignant: formEmail.trim() || undefined,
        priorite: formPriorite,
      })
      toast.success("Plainte enregistrée")
      setShowModal(false)
      await loadData()
    } catch (err: unknown) {
      const msg = err && typeof err === "object" && "message" in err ? String((err as { message?: string }).message) : "Erreur"
      toast.error(msg)
    }
  }

  const submitEdit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!editingPlainte?.id) return
    try {
      await plainteService.update({
        id: editingPlainte.id,
        motif: editingPlainte.motif,
        statut: editingPlainte.statut,
        priorite: editingPlainte.priorite,
        resolution: editingPlainte.resolution,
        objet: editingPlainte.objet,
        description: editingPlainte.description,
        assigneeA: editingPlainte.assigneeA,
      })
      toast.success("Plainte mise à jour")
      setEditingPlainte(null)
      setSelectedPlainte(null)
      await loadData()
    } catch (err: unknown) {
      const msg = err && typeof err === "object" && "message" in err ? String((err as { message?: string }).message) : "Erreur"
      toast.error(msg)
    }
  }

  const handleDelete = async (p: PlainteRow) => {
    if (!p.id || !confirm("Supprimer cette plainte ?")) return
    try {
      await plainteService.remove(p.id)
      toast.success("Plainte supprimée")
      setSelectedPlainte(null)
      await loadData()
    } catch (err: unknown) {
      const msg = err && typeof err === "object" && "message" in err ? String((err as { message?: string }).message) : "Erreur"
      toast.error(msg)
    }
  }

  if (authLoading || !user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <p className="text-gray-600">{authLoading ? "Chargement..." : "Non connecté"}</p>
        </div>
      </div>
    )
  }

  if (!canAccessPlaintesPage(user.role.code, user.functionalityPermissions)) {
    return (
      <MainLayout>
        <div className="text-center py-12">
          <h2 className="text-xl font-semibold text-gray-900 mb-2">Accès restreint</h2>
          <p className="text-gray-600">Vous n&apos;avez pas les droits pour les plaintes (PLAINTE:READ).</p>
        </div>
      </MainLayout>
    )
  }

  const getStatusIcon = (statut?: string) => {
    switch (statut) {
      case "RESOLUE":
        return <CheckCircleIcon className="h-5 w-5 text-green-600" />
      case "EN_TRAITEMENT":
        return <ClockIcon className="h-5 w-5 text-yellow-600" />
      case "DEPOSEE":
        return <ExclamationTriangleIcon className="h-5 w-5 text-blue-600" />
      case "ESCALADEE":
        return <ExclamationTriangleIcon className="h-5 w-5 text-red-600" />
      case "FERMEE":
        return <XCircleIcon className="h-5 w-5 text-gray-600" />
      default:
        return <ClockIcon className="h-5 w-5 text-gray-600" />
    }
  }

  const getStatusBadge = (statut?: string) => {
    switch (statut) {
      case "RESOLUE":
        return "badge-success"
      case "EN_TRAITEMENT":
        return "badge-warning"
      case "DEPOSEE":
        return "badge-info"
      case "ESCALADEE":
        return "badge-error"
      case "FERMEE":
        return "badge-info"
      default:
        return "badge-info"
    }
  }

  const getPriorityBadge = (priorite?: string) => {
    switch (priorite) {
      case "URGENTE":
        return "bg-red-100 text-red-800"
      case "HAUTE":
        return "bg-orange-100 text-orange-800"
      case "MOYENNE":
        return "bg-yellow-100 text-yellow-800"
      case "BASSE":
        return "bg-green-100 text-green-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const typeLabel = (code?: string) => TYPE_OPTIONS.find((t) => t.value === code)?.label ?? (code || "").replace(/_/g, " ")

  const filteredPlaintes = plaintes.filter((plainte) => {
    const lib = plainte.structureLibelle ?? ""
    const code = plainte.structureCode ?? ""
    const objet = plainte.objet ?? ""
    const matchesSearch =
      (plainte.codeSuivi ?? "").toLowerCase().includes(searchTerm.toLowerCase()) ||
      (plainte.nomPlaignant ?? "").toLowerCase().includes(searchTerm.toLowerCase()) ||
      objet.toLowerCase().includes(searchTerm.toLowerCase()) ||
      lib.toLowerCase().includes(searchTerm.toLowerCase()) ||
      code.toLowerCase().includes(searchTerm.toLowerCase())

    const matchesFilter =
      selectedFilter === "all" || plainte.statut === selectedFilter || plainte.priorite === selectedFilter

    return matchesSearch && matchesFilter
  })

  const totalPlaintes = plaintes.length
  const plaintesResolues = plaintes.filter((p) => p.statut === "RESOLUE").length
  const plaintesEnTraitement = plaintes.filter((p) => p.statut === "EN_TRAITEMENT").length
  const plaintesEnAttente = plaintes.filter((p) => p.statut === "DEPOSEE").length

  return (
    <MainLayout>
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Gestion des Plaintes</h1>
            <p className="text-gray-600">Suivi et traitement des plaintes des usagers</p>
          </div>
          <button type="button" onClick={openCreateModal} className="btn-primary mt-4 sm:mt-0">
            <PlusIcon className="h-5 w-5 mr-2" />
            Nouvelle Plainte
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <div className="stat-card">
            <div className="flex items-center">
              <div className="p-3 rounded-lg bg-blue-50 text-blue-600">
                <ExclamationTriangleIcon className="h-6 w-6" />
              </div>
              <div className="ml-4">
                <p className="stat-label">Total Plaintes</p>
                <p className="stat-value">{totalPlaintes}</p>
              </div>
            </div>
          </div>

          <div className="stat-card">
            <div className="flex items-center">
              <div className="p-3 rounded-lg bg-green-50 text-green-600">
                <CheckCircleIcon className="h-6 w-6" />
              </div>
              <div className="ml-4">
                <p className="stat-label">Résolues</p>
                <p className="stat-value">{plaintesResolues}</p>
              </div>
            </div>
          </div>

          <div className="stat-card">
            <div className="flex items-center">
              <div className="p-3 rounded-lg bg-yellow-50 text-yellow-600">
                <ClockIcon className="h-6 w-6" />
              </div>
              <div className="ml-4">
                <p className="stat-label">En Traitement</p>
                <p className="stat-value">{plaintesEnTraitement}</p>
              </div>
            </div>
          </div>

          <div className="stat-card">
            <div className="flex items-center">
              <div className="p-3 rounded-lg bg-orange-50 text-orange-600">
                <ExclamationTriangleIcon className="h-6 w-6" />
              </div>
              <div className="ml-4">
                <p className="stat-label">En Attente</p>
                <p className="stat-value">{plaintesEnAttente}</p>
              </div>
            </div>
          </div>
        </div>

        <div className="card">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-4 sm:space-y-0">
            <div className="flex items-center space-x-4">
              <div className="relative">
                <MagnifyingGlassIcon className="h-5 w-5 text-gray-400 absolute left-3 top-1/2 transform -translate-y-1/2" />
                <input
                  type="text"
                  className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500"
                  placeholder="Rechercher une plainte..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <select
                className="px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500"
                value={selectedFilter}
                onChange={(e) => setSelectedFilter(e.target.value)}
              >
                <option value="all">Tous les statuts</option>
                <option value="DEPOSEE">Déposées</option>
                <option value="EN_TRAITEMENT">En traitement</option>
                <option value="ESCALADEE">Escaladées</option>
                <option value="RESOLUE">Résolues</option>
                <option value="FERMEE">Fermées</option>
              </select>
            </div>
          </div>
        </div>

        <div className="card">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Plaintes Récentes</h3>
          {loading ? (
            <p className="text-gray-600">Chargement des plaintes…</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="table">
                <thead>
                  <tr>
                    <th>Code Suivi</th>
                    <th>Plaignant</th>
                    <th>Objet</th>
                    <th>École Concernée</th>
                    <th>Type</th>
                    <th>Priorité</th>
                    <th>Statut</th>
                    <th>Date Dépôt</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredPlaintes.map((plainte) => (
                    <tr key={plainte.id}>
                      <td className="font-medium text-orange-600">{plainte.codeSuivi}</td>
                      <td>
                        <div>
                          <p className="font-medium">{plainte.nomPlaignant ?? "—"}</p>
                          <p className="text-sm text-gray-500">{plainte.contactPlaignant ?? ""}</p>
                        </div>
                      </td>
                      <td>
                        <div>
                          <p className="font-medium">{plainte.objet ?? "—"}</p>
                          <p className="text-sm text-gray-500">{typeLabel(plainte.motif)}</p>
                        </div>
                      </td>
                      <td>
                        <div>
                          <p className="font-medium">{plainte.structureLibelle ?? "—"}</p>
                          <p className="text-sm text-gray-500">{plainte.structureCode ?? ""}</p>
                        </div>
                      </td>
                      <td>
                        <span className="badge-info">{typeLabel(plainte.motif)}</span>
                      </td>
                      <td>
                        <span
                          className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getPriorityBadge(plainte.priorite)}`}
                        >
                          {plainte.priorite ?? "—"}
                        </span>
                      </td>
                      <td>
                        <span className={`${getStatusBadge(plainte.statut)} flex items-center`}>
                          {getStatusIcon(plainte.statut)}
                          <span className="ml-1">{(plainte.statut ?? "").replace(/_/g, " ")}</span>
                        </span>
                      </td>
                      <td>{formatDateOnly(plainte.dateEmission)}</td>
                      <td>
                        <div className="flex flex-wrap gap-2">
                          <button
                            type="button"
                            onClick={() => setSelectedPlainte(plainte)}
                            className="text-orange-600 hover:text-orange-800 font-medium text-sm"
                          >
                            Détails
                          </button>
                          <button
                            type="button"
                            onClick={() => setEditingPlainte({ ...plainte })}
                            className="text-blue-600 hover:text-blue-800 font-medium text-sm inline-flex items-center"
                          >
                            <PencilIcon className="h-4 w-4 mr-0.5" />
                            Modifier
                          </button>
                          <button
                            type="button"
                            onClick={() => handleDelete(plainte)}
                            className="text-red-600 hover:text-red-800 font-medium text-sm inline-flex items-center"
                          >
                            <TrashIcon className="h-4 w-4 mr-0.5" />
                            Supprimer
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
              {!loading && filteredPlaintes.length === 0 && (
                <p className="text-gray-500 mt-4">Aucune plainte à afficher.</p>
              )}
            </div>
          )}
        </div>

        {selectedPlainte && !editingPlainte && (
          <div className="modal-overlay" onClick={() => setSelectedPlainte(null)}>
            <div className="modal-content max-w-3xl" onClick={(e) => e.stopPropagation()}>
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold">Détails de la Plainte</h3>
                <button type="button" onClick={() => setSelectedPlainte(null)} className="text-gray-400 hover:text-gray-600">
                  <XCircleIcon className="h-6 w-6" />
                </button>
              </div>

              <div className="space-y-6">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm font-medium text-gray-500">Code de Suivi</p>
                    <p className="text-lg font-bold text-orange-600">{selectedPlainte.codeSuivi}</p>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-500">Statut</p>
                    <span className={`${getStatusBadge(selectedPlainte.statut)} flex items-center w-fit`}>
                      {getStatusIcon(selectedPlainte.statut)}
                      <span className="ml-1">{(selectedPlainte.statut ?? "").replace(/_/g, " ")}</span>
                    </span>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-500">Priorité</p>
                    <span
                      className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getPriorityBadge(selectedPlainte.priorite)}`}
                    >
                      {selectedPlainte.priorite ?? "—"}
                    </span>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-500">Date de Dépôt</p>
                    <p className="text-sm text-gray-900">{formatInstant(selectedPlainte.dateEmission)}</p>
                  </div>
                </div>

                <div>
                  <h4 className="text-sm font-medium text-gray-900 mb-2">Informations du Plaignant</h4>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm font-medium text-gray-500">Nom</p>
                      <p className="text-sm text-gray-900">{selectedPlainte.nomPlaignant ?? "—"}</p>
                    </div>
                    <div>
                      <p className="text-sm font-medium text-gray-500">Téléphone</p>
                      <p className="text-sm text-gray-900">{selectedPlainte.contactPlaignant ?? "—"}</p>
                    </div>
                    {selectedPlainte.emailPlaignant && (
                      <div>
                        <p className="text-sm font-medium text-gray-500">Email</p>
                        <p className="text-sm text-gray-900">{selectedPlainte.emailPlaignant}</p>
                      </div>
                    )}
                  </div>
                </div>

                <div>
                  <h4 className="text-sm font-medium text-gray-900 mb-2">Détails de la Plainte</h4>
                  <div className="space-y-3">
                    <div>
                      <p className="text-sm font-medium text-gray-500">Objet</p>
                      <p className="text-sm text-gray-900">{selectedPlainte.objet ?? "—"}</p>
                    </div>
                    <div>
                      <p className="text-sm font-medium text-gray-500">Description</p>
                      <p className="text-sm text-gray-900">{selectedPlainte.description}</p>
                    </div>
                    <div>
                      <p className="text-sm font-medium text-gray-500">École Concernée</p>
                      <p className="text-sm text-gray-900">{selectedPlainte.structureLibelle ?? "—"}</p>
                    </div>
                    <div>
                      <p className="text-sm font-medium text-gray-500">Assignée à</p>
                      <p className="text-sm text-gray-900">{selectedPlainte.assigneeName ?? "Non assignée"}</p>
                    </div>
                  </div>
                </div>

                {selectedPlainte.resolution && (
                  <div>
                    <h4 className="text-sm font-medium text-gray-900 mb-2">Résolution</h4>
                    <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                      <p className="text-sm text-gray-900">{selectedPlainte.resolution}</p>
                      <p className="text-xs text-gray-500 mt-2">Résolue le {formatInstant(selectedPlainte.dateResolution)}</p>
                    </div>
                  </div>
                )}
              </div>

              <div className="flex justify-end space-x-3 mt-6">
                <button type="button" onClick={() => setSelectedPlainte(null)} className="btn-outline">
                  Fermer
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setEditingPlainte({ ...selectedPlainte })
                    setSelectedPlainte(null)
                  }}
                  className="btn-primary"
                >
                  Modifier
                </button>
              </div>
            </div>
          </div>
        )}

        {editingPlainte && (
          <div className="modal-overlay" onClick={() => setEditingPlainte(null)}>
            <div className="modal-content max-w-lg" onClick={(e) => e.stopPropagation()}>
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold">Modifier la plainte</h3>
                <button type="button" onClick={() => setEditingPlainte(null)} className="text-gray-400 hover:text-gray-600">
                  <XCircleIcon className="h-6 w-6" />
                </button>
              </div>
              <form onSubmit={submitEdit} className="space-y-4">
                <div className="form-group">
                  <label className="form-label">Statut</label>
                  <select
                    className="input-field"
                    value={editingPlainte.statut ?? "DEPOSEE"}
                    onChange={(e) => setEditingPlainte({ ...editingPlainte, statut: e.target.value })}
                  >
                    <option value="DEPOSEE">Déposée</option>
                    <option value="EN_TRAITEMENT">En traitement</option>
                    <option value="ESCALADEE">Escaladée</option>
                    <option value="RESOLUE">Résolue</option>
                    <option value="FERMEE">Fermée</option>
                  </select>
                </div>
                <div className="form-group">
                  <label className="form-label">Priorité</label>
                  <select
                    className="input-field"
                    value={editingPlainte.priorite ?? "MOYENNE"}
                    onChange={(e) => setEditingPlainte({ ...editingPlainte, priorite: e.target.value })}
                  >
                    <option value="BASSE">Basse</option>
                    <option value="MOYENNE">Moyenne</option>
                    <option value="HAUTE">Haute</option>
                    <option value="URGENTE">Urgente</option>
                  </select>
                </div>
                <div className="form-group">
                  <label className="form-label">Objet</label>
                  <input
                    type="text"
                    className="input-field"
                    value={editingPlainte.objet ?? ""}
                    onChange={(e) => setEditingPlainte({ ...editingPlainte, objet: e.target.value })}
                  />
                </div>
                <div className="form-group">
                  <label className="form-label">Description</label>
                  <textarea
                    className="input-field"
                    rows={3}
                    value={editingPlainte.description ?? ""}
                    onChange={(e) => setEditingPlainte({ ...editingPlainte, description: e.target.value })}
                  />
                </div>
                <div className="form-group">
                  <label className="form-label">Résolution (optionnel)</label>
                  <textarea
                    className="input-field"
                    rows={3}
                    value={editingPlainte.resolution ?? ""}
                    onChange={(e) => setEditingPlainte({ ...editingPlainte, resolution: e.target.value })}
                  />
                </div>
                <div className="flex justify-end space-x-3">
                  <button type="button" onClick={() => setEditingPlainte(null)} className="btn-outline">
                    Annuler
                  </button>
                  <button type="submit" className="btn-primary">
                    Enregistrer
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {showModal && (
          <div className="modal-overlay" onClick={() => setShowModal(false)}>
            <div className="modal-content max-w-lg" onClick={(e) => e.stopPropagation()}>
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold">Nouvelle Plainte</h3>
                <button type="button" onClick={() => setShowModal(false)} className="text-gray-400 hover:text-gray-600">
                  <XCircleIcon className="h-6 w-6" />
                </button>
              </div>

              <form onSubmit={submitCreate} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="form-group">
                    <label className="form-label">Nom du Plaignant</label>
                    <input type="text" className="input-field" value={formNom} onChange={(e) => setFormNom(e.target.value)} />
                  </div>
                  <div className="form-group">
                    <label className="form-label">Téléphone</label>
                    <input type="tel" className="input-field" value={formTel} onChange={(e) => setFormTel(e.target.value)} />
                  </div>
                </div>

                <div className="form-group">
                  <label className="form-label">Email (optionnel)</label>
                  <input type="email" className="input-field" value={formEmail} onChange={(e) => setFormEmail(e.target.value)} />
                </div>

                <div className="form-group">
                  <label className="form-label">École Concernée</label>
                  <select
                    className="input-field"
                    required
                    value={formStructureId}
                    onChange={(e) => setFormStructureId(e.target.value ? Number(e.target.value) : "")}
                  >
                    <option value="">Sélectionner une école</option>
                    {structuresEpp.map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.libelle} ({s.code})
                      </option>
                    ))}
                  </select>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="form-group">
                    <label className="form-label">Type de Plainte</label>
                    <select className="input-field" required value={formType} onChange={(e) => setFormType(e.target.value)}>
                      {TYPE_OPTIONS.map((t) => (
                        <option key={t.value} value={t.value}>
                          {t.label}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div className="form-group">
                    <label className="form-label">Priorité</label>
                    <select className="input-field" required value={formPriorite} onChange={(e) => setFormPriorite(e.target.value)}>
                      <option value="BASSE">Basse</option>
                      <option value="MOYENNE">Moyenne</option>
                      <option value="HAUTE">Haute</option>
                      <option value="URGENTE">Urgente</option>
                    </select>
                  </div>
                </div>

                <div className="form-group">
                  <label className="form-label">Objet de la Plainte</label>
                  <input type="text" className="input-field" required value={formObjet} onChange={(e) => setFormObjet(e.target.value)} />
                </div>

                <div className="form-group">
                  <label className="form-label">Description Détaillée</label>
                  <textarea
                    className="input-field"
                    rows={4}
                    required
                    value={formDescription}
                    onChange={(e) => setFormDescription(e.target.value)}
                    placeholder="Décrivez en détail le problème rencontré..."
                  />
                </div>

                <div className="flex justify-end space-x-3">
                  <button type="button" onClick={() => setShowModal(false)} className="btn-outline">
                    Annuler
                  </button>
                  <button type="submit" className="btn-primary">
                    Déposer la Plainte
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    </MainLayout>
  )
}
