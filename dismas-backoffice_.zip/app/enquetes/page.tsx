"use client"

import { useCallback, useEffect, useMemo, useState } from "react"
import MainLayout from "../../components/layout/main-layout"
import { useAuth } from "../providers"
import { PlusIcon, ChartBarIcon, EyeIcon, PencilIcon, TrashIcon } from "@heroicons/react/24/outline"
import { enqueteSatisfactionService, type EnqueteSatisfactionRow } from "@/lib/services/enquete-satisfaction.service"
import { ParametrageService } from "@/lib/services/parametrage.service"
import { anneeScolaireService } from "@/lib/services/annee-scolaire.service"
import type { AnneeScolaire, StructureAdministrative } from "@/lib/types/entities"
import toast from "react-hot-toast"
import { canAccessEnquetesPage } from "@/lib/utils/functionality-permissions"

const parametrageService = new ParametrageService()

const TYPE_REPONDANT = [
  { value: "PARENTS", label: "Parents" },
  { value: "DIRECTEURS", label: "Directeurs" },
  { value: "MAITRES", label: "Maîtres" },
  { value: "COGES", label: "COGES" },
] as const

/** Contraintes varchar backend : q1 ≤10, q2 ≤9, q3 ≤15 */
const Q1_OPTIONS = [
  { value: "TRES_BON", label: "Très satisfait" },
  { value: "SATISFAIT", label: "Satisfait" },
  { value: "MOYEN", label: "Moyen" },
  { value: "FAIBLE", label: "Faible" },
  { value: "INSAT", label: "Insatisfait" },
]

const Q2_OPTIONS = [
  { value: "BON_ETAT", label: "Bon état" },
  { value: "MOYEN", label: "Moyen" },
  { value: "MAUVAIS", label: "Mauvais" },
]

const Q3_OPTIONS = [
  { value: "A_L_HEURE", label: "À l'heure" },
  { value: "EN_RETARD", label: "En retard" },
  { value: "NON_CONCERNE", label: "Non concerné" },
]

function q1Score(v?: string | null): number {
  switch (v) {
    case "TRES_BON":
      return 5
    case "SATISFAIT":
      return 4
    case "MOYEN":
      return 3
    case "FAIBLE":
      return 2
    case "INSAT":
      return 1
    default:
      return 0
  }
}

function formatInstant(iso?: string | null): string {
  if (!iso) return "—"
  const d = new Date(iso)
  return Number.isNaN(d.getTime()) ? iso : d.toLocaleString("fr-FR")
}

export default function EnquetesPage() {
  const { user, isLoading: authLoading } = useAuth()
  const [rows, setRows] = useState<EnqueteSatisfactionRow[]>([])
  const [structuresEpp, setStructuresEpp] = useState<StructureAdministrative[]>([])
  const [annees, setAnnees] = useState<AnneeScolaire[]>([])
  const [loading, setLoading] = useState(true)
  const [selected, setSelected] = useState<EnqueteSatisfactionRow | null>(null)
  const [editing, setEditing] = useState<EnqueteSatisfactionRow | null>(null)
  const [showModal, setShowModal] = useState(false)
  const [showResults, setShowResults] = useState(false)

  const [formAnneeId, setFormAnneeId] = useState<number | "">("")
  const [formStructureId, setFormStructureId] = useState<number | "">("")
  const [formType, setFormType] = useState<string>("PARENTS")
  const [formQ1, setFormQ1] = useState("SATISFAIT")
  const [formQ2, setFormQ2] = useState("BON_ETAT")
  const [formQ3, setFormQ3] = useState("A_L_HEURE")
  const [formQ4, setFormQ4] = useState(true)
  const [formQ5, setFormQ5] = useState("")

  const loadData = useCallback(async () => {
    setLoading(true)
    try {
      const [rRes, sRes, aRes] = await Promise.all([
        enqueteSatisfactionService.list({}),
        parametrageService.getStructuresByType("EPP"),
        anneeScolaireService.getAnneesScolaires(),
      ])
      setRows(rRes.items ?? [])
      setStructuresEpp(sRes.items ?? [])
      setAnnees(aRes.items ?? [])
    } catch (e: unknown) {
      const msg = e && typeof e === "object" && "message" in e ? String((e as { message?: string }).message) : "Erreur chargement"
      toast.error(msg)
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    if (!user || authLoading) return
    void loadData()
  }, [user, authLoading, loadData])

  const totalEnquetes = rows.length
  const totalReponses = rows.length
  const scoreMoyenGlobal = useMemo(() => {
    if (rows.length === 0) return 0
    const s = rows.reduce((acc, r) => acc + q1Score(r.q1Processus), 0)
    return s / rows.length
  }, [rows])

  const resetForm = () => {
    setFormAnneeId("")
    setFormStructureId("")
    setFormType("PARENTS")
    setFormQ1("SATISFAIT")
    setFormQ2("BON_ETAT")
    setFormQ3("A_L_HEURE")
    setFormQ4(true)
    setFormQ5("")
  }

  const openCreate = () => {
    resetForm()
    const courante = annees.find((a) => a.estCourante)
    if (courante?.id) setFormAnneeId(courante.id)
    setShowModal(true)
  }

  const submitCreate = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!formAnneeId || !formStructureId) {
      toast.error("Année scolaire et structure sont requis")
      return
    }
    try {
      await enqueteSatisfactionService.create({
        anneeScolaireId: Number(formAnneeId),
        structureId: Number(formStructureId),
        typeRepondant: formType,
        q1Processus: formQ1,
        q2EtatManuels: formQ2,
        q3DateMouvement: formQ3,
        q4ManuelsComplets: formQ4,
        q5Suggestions: formQ5.trim() || undefined,
      })
      toast.success("Réponse enregistrée")
      setShowModal(false)
      await loadData()
    } catch (err: unknown) {
      const msg = err && typeof err === "object" && "message" in err ? String((err as { message?: string }).message) : "Erreur"
      toast.error(msg)
    }
  }

  const submitEdit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!editing?.id) return
    try {
      await enqueteSatisfactionService.update({
        id: editing.id,
        anneeScolaireId: editing.anneeScolaireId,
        structureId: editing.structureId,
        typeRepondant: editing.typeRepondant,
        q1Processus: editing.q1Processus,
        q2EtatManuels: editing.q2EtatManuels,
        q3DateMouvement: editing.q3DateMouvement,
        q4ManuelsComplets: editing.q4ManuelsComplets,
        q5Suggestions: editing.q5Suggestions,
      })
      toast.success("Enquête mise à jour")
      setEditing(null)
      setSelected(null)
      await loadData()
    } catch (err: unknown) {
      const msg = err && typeof err === "object" && "message" in err ? String((err as { message?: string }).message) : "Erreur"
      toast.error(msg)
    }
  }

  const handleDelete = async (r: EnqueteSatisfactionRow) => {
    if (!r.id || !confirm("Supprimer cette réponse d'enquête ?")) return
    try {
      await enqueteSatisfactionService.remove(r.id)
      toast.success("Supprimé")
      setSelected(null)
      await loadData()
    } catch (err: unknown) {
      const msg = err && typeof err === "object" && "message" in err ? String((err as { message?: string }).message) : "Erreur"
      toast.error(msg)
    }
  }

  const typeLabel = (v?: string | null) => TYPE_REPONDANT.find((t) => t.value === v)?.label ?? v ?? "—"

  if (authLoading || !user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <p className="text-gray-600">{authLoading ? "Chargement..." : "Non connecté"}</p>
        </div>
      </div>
    )
  }

  if (!canAccessEnquetesPage(user.role.code, user.functionalityPermissions)) {
    return (
      <MainLayout>
        <div className="text-center py-12">
          <h2 className="text-xl font-semibold text-gray-900 mb-2">Accès restreint</h2>
          <p className="text-gray-600">Vous n&apos;avez pas les droits pour les enquêtes (ENQUETE_SATISFACTION:READ).</p>
        </div>
      </MainLayout>
    )
  }

  return (
    <MainLayout>
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Enquêtes de Satisfaction</h1>
            <p className="text-gray-600">Réponses collectées (qualité de distribution, manuels, délais)</p>
          </div>
          <button type="button" onClick={openCreate} className="btn-primary mt-4 sm:mt-0">
            <PlusIcon className="h-5 w-5 mr-2" />
            Nouvelle réponse
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <div className="stat-card">
            <div className="flex items-center">
              <div className="p-3 rounded-lg bg-blue-50 text-blue-600">
                <ChartBarIcon className="h-6 w-6" />
              </div>
              <div className="ml-4">
                <p className="stat-label">Réponses enregistrées</p>
                <p className="stat-value">{totalEnquetes}</p>
              </div>
            </div>
          </div>

          <div className="stat-card">
            <div className="flex items-center">
              <div className="p-3 rounded-lg bg-green-50 text-green-600">
                <ChartBarIcon className="h-6 w-6" />
              </div>
              <div className="ml-4">
                <p className="stat-label">Types de répondants</p>
                <p className="stat-value">{new Set(rows.map((r) => r.typeRepondant).filter(Boolean)).size}</p>
              </div>
            </div>
          </div>

          <div className="stat-card">
            <div className="flex items-center">
              <div className="p-3 rounded-lg bg-purple-50 text-purple-600">
                <ChartBarIcon className="h-6 w-6" />
              </div>
              <div className="ml-4">
                <p className="stat-label">Total réponses</p>
                <p className="stat-value">{totalReponses}</p>
              </div>
            </div>
          </div>

          <div className="stat-card">
            <div className="flex items-center">
              <div className="p-3 rounded-lg bg-orange-50 text-orange-600">
                <ChartBarIcon className="h-6 w-6" />
              </div>
              <div className="ml-4">
                <p className="stat-label">Score moyen (Q1)</p>
                <p className="stat-value">{scoreMoyenGlobal > 0 ? scoreMoyenGlobal.toFixed(1) : "—"}/5</p>
              </div>
            </div>
          </div>
        </div>

        <div className="card">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Réponses d&apos;enquête</h3>
          {loading ? (
            <p className="text-gray-600">Chargement…</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="table">
                <thead>
                  <tr>
                    <th>Année</th>
                    <th>Structure</th>
                    <th>Type</th>
                    <th>Date réponse</th>
                    <th>Satisfaction (Q1)</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {rows.map((row) => (
                    <tr key={row.id}>
                      <td>{row.anneeScolaireCode ?? row.anneeScolaireId ?? "—"}</td>
                      <td>
                        <div>
                          <p className="font-medium">{row.structureLibelle ?? "—"}</p>
                          <p className="text-sm text-gray-500">{row.structureCode ?? ""}</p>
                        </div>
                      </td>
                      <td>
                        <span className="badge-info">{typeLabel(row.typeRepondant)}</span>
                      </td>
                      <td>{formatInstant(row.dateReponse)}</td>
                      <td>
                        <span className="font-medium">{q1Score(row.q1Processus).toFixed(0)}/5</span>
                        <span className="text-gray-500 text-sm ml-1">({row.q1Processus})</span>
                      </td>
                      <td>
                        <div className="flex flex-wrap gap-2">
                          <button
                            type="button"
                            onClick={() => {
                              setSelected(row)
                              setShowResults(true)
                            }}
                            className="text-indigo-600 hover:text-indigo-800 font-medium text-sm inline-flex items-center"
                          >
                            <EyeIcon className="h-4 w-4 mr-0.5" />
                            Voir
                          </button>
                          <button
                            type="button"
                            onClick={() => setEditing({ ...row })}
                            className="text-blue-600 hover:text-blue-800 font-medium text-sm inline-flex items-center"
                          >
                            <PencilIcon className="h-4 w-4 mr-0.5" />
                            Modifier
                          </button>
                          <button
                            type="button"
                            onClick={() => handleDelete(row)}
                            className="text-red-600 hover:text-red-800 font-medium text-sm inline-flex items-center"
                          >
                            <TrashIcon className="h-4 w-4 mr-0.5" />
                            Supprimer
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
              {rows.length === 0 && <p className="text-gray-500 mt-4">Aucune réponse pour le moment.</p>}
            </div>
          )}
        </div>

        {showModal && (
          <div className="modal-overlay" onClick={() => setShowModal(false)}>
            <div className="modal-content max-w-lg" onClick={(e) => e.stopPropagation()}>
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold">Nouvelle réponse d&apos;enquête</h3>
                <button type="button" onClick={() => setShowModal(false)} className="text-gray-400 hover:text-gray-600">
                  ×
                </button>
              </div>
              <form onSubmit={submitCreate} className="space-y-4">
                <div className="form-group">
                  <label className="form-label">Année scolaire</label>
                  <select
                    className="input-field"
                    required
                    value={formAnneeId}
                    onChange={(e) => setFormAnneeId(e.target.value ? Number(e.target.value) : "")}
                  >
                    <option value="">Sélectionner</option>
                    {annees.map((a) => (
                      <option key={a.id} value={a.id}>
                        {a.code ?? a.libelle} {a.estCourante ? "(courante)" : ""}
                      </option>
                    ))}
                  </select>
                </div>
                <div className="form-group">
                  <label className="form-label">Structure (EPP)</label>
                  <select
                    className="input-field"
                    required
                    value={formStructureId}
                    onChange={(e) => setFormStructureId(e.target.value ? Number(e.target.value) : "")}
                  >
                    <option value="">Sélectionner</option>
                    {structuresEpp.map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.libelle} ({s.code})
                      </option>
                    ))}
                  </select>
                </div>
                <div className="form-group">
                  <label className="form-label">Type de répondant</label>
                  <select className="input-field" value={formType} onChange={(e) => setFormType(e.target.value)}>
                    {TYPE_REPONDANT.map((t) => (
                      <option key={t.value} value={t.value}>
                        {t.label}
                      </option>
                    ))}
                  </select>
                </div>
                <div className="form-group">
                  <label className="form-label">Satisfaction du processus (Q1)</label>
                  <select className="input-field" value={formQ1} onChange={(e) => setFormQ1(e.target.value)}>
                    {Q1_OPTIONS.map((o) => (
                      <option key={o.value} value={o.value}>
                        {o.label}
                      </option>
                    ))}
                  </select>
                </div>
                <div className="form-group">
                  <label className="form-label">État des manuels (Q2)</label>
                  <select className="input-field" value={formQ2} onChange={(e) => setFormQ2(e.target.value)}>
                    {Q2_OPTIONS.map((o) => (
                      <option key={o.value} value={o.value}>
                        {o.label}
                      </option>
                    ))}
                  </select>
                </div>
                <div className="form-group">
                  <label className="form-label">Délais / mouvement (Q3)</label>
                  <select className="input-field" value={formQ3} onChange={(e) => setFormQ3(e.target.value)}>
                    {Q3_OPTIONS.map((o) => (
                      <option key={o.value} value={o.value}>
                        {o.label}
                      </option>
                    ))}
                  </select>
                </div>
                <div className="form-group flex items-center space-x-2">
                  <input id="q4" type="checkbox" checked={formQ4} onChange={(e) => setFormQ4(e.target.checked)} />
                  <label htmlFor="q4">Manuels complets (Q4)</label>
                </div>
                <div className="form-group">
                  <label className="form-label">Suggestions (Q5)</label>
                  <textarea className="input-field" rows={3} value={formQ5} onChange={(e) => setFormQ5(e.target.value)} />
                </div>
                <div className="flex justify-end space-x-3">
                  <button type="button" onClick={() => setShowModal(false)} className="btn-outline">
                    Annuler
                  </button>
                  <button type="submit" className="btn-primary">
                    Enregistrer
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {showResults && selected && (
          <div className="modal-overlay" onClick={() => setShowResults(false)}>
            <div className="modal-content max-w-lg" onClick={(e) => e.stopPropagation()}>
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold">Détail réponse #{selected.id}</h3>
                <button type="button" onClick={() => setShowResults(false)} className="text-gray-400 hover:text-gray-600">
                  ×
                </button>
              </div>
              <div className="space-y-2 text-sm">
                <p>
                  <span className="font-medium">Année :</span> {selected.anneeScolaireCode ?? selected.anneeScolaireId}
                </p>
                <p>
                  <span className="font-medium">Structure :</span> {selected.structureLibelle} ({selected.structureCode})
                </p>
                <p>
                  <span className="font-medium">Répondant :</span> {typeLabel(selected.typeRepondant)}
                </p>
                <p>
                  <span className="font-medium">Date :</span> {formatInstant(selected.dateReponse)}
                </p>
                <hr className="my-2" />
                <p>
                  <span className="font-medium">Q1 :</span> {selected.q1Processus}
                </p>
                <p>
                  <span className="font-medium">Q2 :</span> {selected.q2EtatManuels}
                </p>
                <p>
                  <span className="font-medium">Q3 :</span> {selected.q3DateMouvement}
                </p>
                <p>
                  <span className="font-medium">Q4 :</span> {selected.q4ManuelsComplets ? "Oui" : "Non"}
                </p>
                <p>
                  <span className="font-medium">Q5 :</span> {selected.q5Suggestions ?? "—"}
                </p>
              </div>
              <div className="flex justify-end mt-4">
                <button type="button" onClick={() => setShowResults(false)} className="btn-outline">
                  Fermer
                </button>
              </div>
            </div>
          </div>
        )}

        {editing && (
          <div className="modal-overlay" onClick={() => setEditing(null)}>
            <div className="modal-content max-w-lg" onClick={(e) => e.stopPropagation()}>
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold">Modifier la réponse #{editing.id}</h3>
                <button type="button" onClick={() => setEditing(null)} className="text-gray-400 hover:text-gray-600">
                  ×
                </button>
              </div>
              <form onSubmit={submitEdit} className="space-y-4">
                <div className="form-group">
                  <label className="form-label">Type répondant</label>
                  <select
                    className="input-field"
                    value={editing.typeRepondant ?? ""}
                    onChange={(e) => setEditing({ ...editing, typeRepondant: e.target.value })}
                  >
                    {TYPE_REPONDANT.map((t) => (
                      <option key={t.value} value={t.value}>
                        {t.label}
                      </option>
                    ))}
                  </select>
                </div>
                <div className="form-group">
                  <label className="form-label">Q1</label>
                  <select
                    className="input-field"
                    value={editing.q1Processus ?? ""}
                    onChange={(e) => setEditing({ ...editing, q1Processus: e.target.value })}
                  >
                    {Q1_OPTIONS.map((o) => (
                      <option key={o.value} value={o.value}>
                        {o.label}
                      </option>
                    ))}
                  </select>
                </div>
                <div className="form-group">
                  <label className="form-label">Q2</label>
                  <select
                    className="input-field"
                    value={editing.q2EtatManuels ?? ""}
                    onChange={(e) => setEditing({ ...editing, q2EtatManuels: e.target.value })}
                  >
                    {Q2_OPTIONS.map((o) => (
                      <option key={o.value} value={o.value}>
                        {o.label}
                      </option>
                    ))}
                  </select>
                </div>
                <div className="form-group">
                  <label className="form-label">Q3</label>
                  <select
                    className="input-field"
                    value={editing.q3DateMouvement ?? ""}
                    onChange={(e) => setEditing({ ...editing, q3DateMouvement: e.target.value })}
                  >
                    {Q3_OPTIONS.map((o) => (
                      <option key={o.value} value={o.value}>
                        {o.label}
                      </option>
                    ))}
                  </select>
                </div>
                <div className="form-group flex items-center space-x-2">
                  <input
                    id="eq4"
                    type="checkbox"
                    checked={!!editing.q4ManuelsComplets}
                    onChange={(e) => setEditing({ ...editing, q4ManuelsComplets: e.target.checked })}
                  />
                  <label htmlFor="eq4">Manuels complets (Q4)</label>
                </div>
                <div className="form-group">
                  <label className="form-label">Q5</label>
                  <textarea
                    className="input-field"
                    rows={3}
                    value={editing.q5Suggestions ?? ""}
                    onChange={(e) => setEditing({ ...editing, q5Suggestions: e.target.value })}
                  />
                </div>
                <div className="flex justify-end space-x-3">
                  <button type="button" onClick={() => setEditing(null)} className="btn-outline">
                    Annuler
                  </button>
                  <button type="submit" className="btn-primary">
                    Enregistrer
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    </MainLayout>
  )
}
