import { redirect } from "next/navigation"

/** Ancienne URL : tout le contenu est sous /admin/parametrages?tab=permissions */
export default function ParametragesPermissionsRedirectPage() {
  redirect("/admin/parametrages?tab=permissions")
}
