"use client"

import { useState, useEffect, useMemo, useCallback, Suspense } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import MainLayout from "../../../components/layout/main-layout"
import { ParametragesRbacPermissionsPanel } from "@/components/parametrages/ParametragesRbacPermissionsPanel"
import {
  ParametrageListPagination,
  PARAMETRAGE_LIST_PAGE_SIZE,
} from "@/components/parametrages/ParametrageListPagination"
import { ParametragesTerritorialStructuresPanel } from "@/components/parametrages/ParametragesTerritorialStructuresPanel"
import { useAuth } from "../../providers"
import { useMatieres, useMatiereOperations } from "../../../hooks/use-matieres"
import { useNiveauxScolaires, useNiveauScolaireOperations } from "../../../hooks/use-niveaux-scolaires"
import { useRolesCrud, useRoleOperations } from "../../../hooks/use-roles-crud"
import { useCatalogues, useCatalogueOperations, useCatalogueMatieres } from "../../../hooks/use-catalogues"
import { useAnneesScolaires, useAnneeScolaireOperations } from "../../../hooks/use-annees-scolaires"
import { useMatieresByCatalogue } from "../../../hooks/use-catalogue-matieres"
import { Matiere, NiveauScolaire, Role, Catalogue, AnneeScolaire, CatalogueMatiere } from "@/lib/types/entities"
import { RbacMatrixService } from "@/lib/services/rbac-matrix.service"
import toast from "react-hot-toast"
import { isEppSchoolOperationalRole, isParametragesTerritoireOnlyRole } from "@/lib/utils/role-codes"
import { hasFunctionalityPermission } from "@/lib/utils/functionality-permissions"
import { normalizeRoleCodeForStorage } from "@/lib/rbac-workflow-helpers"
import {
  CogIcon,
  BookOpenIcon,
  AcademicCapIcon,
  DocumentTextIcon,
  BuildingOfficeIcon,
  UserGroupIcon,
  ServerIcon,
  PlusIcon,
  PencilIcon,
  EyeIcon,
  PhotoIcon,
  MagnifyingGlassIcon,
  TrashIcon,
  ArrowPathIcon,
  CalendarIcon,
  CheckIcon,
  XMarkIcon,
  ShieldCheckIcon,
} from "@heroicons/react/24/outline"

// ==================== FONCTIONS UTILITAIRES ====================

// Composant Tooltip personnalisé
const Tooltip = ({ children, content, position = "top" }: { children: React.ReactNode, content: string, position?: "top" | "bottom" | "left" | "right" }) => {
  const [isVisible, setIsVisible] = useState(false)

  return (
    <div 
      className="relative inline-block"
      onMouseEnter={() => setIsVisible(true)}
      onMouseLeave={() => setIsVisible(false)}
    >
      {children}
      {isVisible && (
        <div className={`
          absolute z-50 px-2 py-1 text-xs text-white bg-gray-900 rounded shadow-lg whitespace-nowrap
          ${position === "top" ? "bottom-full left-1/2 transform -translate-x-1/2 mb-1" : ""}
          ${position === "bottom" ? "top-full left-1/2 transform -translate-x-1/2 mt-1" : ""}
          ${position === "left" ? "right-full top-1/2 transform -translate-y-1/2 mr-1" : ""}
          ${position === "right" ? "left-full top-1/2 transform -translate-y-1/2 ml-1" : ""}
        `}>
          {content}
          <div className={`
            absolute w-0 h-0 border-4 border-transparent
            ${position === "top" ? "top-full left-1/2 transform -translate-x-1/2 border-t-gray-900" : ""}
            ${position === "bottom" ? "bottom-full left-1/2 transform -translate-x-1/2 border-b-gray-900" : ""}
            ${position === "left" ? "left-full top-1/2 transform -translate-y-1/2 border-l-gray-900" : ""}
            ${position === "right" ? "right-full top-1/2 transform -translate-y-1/2 border-r-gray-900" : ""}
          `} />
        </div>
      )}
    </div>
  )
}

// Fonction pour formater les dates du backend (jj/MM/aaaa HH:mm:ss)
const formatBackendDate = (dateString?: string): string => {
  if (!dateString) return 'N/A'
  
  try {
    // Le backend envoie au format "dd/MM/yyyy HH:mm:ss"
    const [datePart, timePart] = dateString.split(' ')
    const [day, month, year] = datePart.split('/')
    
    // Créer une date valide
    const date = new Date(`${year}-${month.padStart(2, '0')}-${day.padStart(2, '0')}T${timePart}`)
    
    if (isNaN(date.getTime())) {
      return dateString // Retourner la chaîne originale si le parsing échoue
    }
    
    // Formater en français
    return date.toLocaleDateString('fr-FR', {
      day: '2-digit',
      month: '2-digit', 
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    })
  } catch (error) {
    console.warn('Erreur lors du formatage de la date:', error)
    return dateString
  }
}

// ==================== DONNÉES MOCKÉES ====================


// Classes/Niveaux
const mockNiveaux = [
  {
    id: 1,
    code: "CP1",
    libelle: "Cours Préparatoire 1ère année",
    cycle: "PRIMAIRE",
    age_min: 6,
    age_max: 7,
    ordre: 1,
    actif: true,
  },
  {
    id: 2,
    code: "CP2",
    libelle: "Cours Préparatoire 2ème année",
    cycle: "PRIMAIRE",
    age_min: 7,
    age_max: 8,
    ordre: 2,
    actif: true,
  },
  {
    id: 3,
    code: "CE1",
    libelle: "Cours Élémentaire 1ère année",
    cycle: "PRIMAIRE",
    age_min: 8,
    age_max: 9,
    ordre: 3,
    actif: true,
  },
  {
    id: 4,
    code: "CE2",
    libelle: "Cours Élémentaire 2ème année",
    cycle: "PRIMAIRE",
    age_min: 9,
    age_max: 10,
    ordre: 4,
    actif: true,
  },
  {
    id: 5,
    code: "CM1",
    libelle: "Cours Moyen 1ère année",
    cycle: "PRIMAIRE",
    age_min: 10,
    age_max: 11,
    ordre: 5,
    actif: true,
  },
  {
    id: 6,
    code: "CM2",
    libelle: "Cours Moyen 2ème année",
    cycle: "PRIMAIRE",
    age_min: 11,
    age_max: 12,
    ordre: 6,
    actif: true,
  },
]

// Matières
const mockMatieres = [
  { id: 1, code: "FR", libelle: "Français", couleur: "#3b82f6", coefficient: 4, heures_semaine: 8, actif: true },
  { id: 2, code: "MATH", libelle: "Mathématiques", couleur: "#ef4444", coefficient: 4, heures_semaine: 6, actif: true },
  { id: 3, code: "ANGLAIS", libelle: "Anglais", couleur: "#8b5cf6", coefficient: 2, heures_semaine: 3, actif: true },
  {
    id: 4,
    code: "SCIENCES",
    libelle: "Sciences d'Observation",
    couleur: "#10b981",
    coefficient: 2,
    heures_semaine: 3,
    actif: true,
  },
  {
    id: 5,
    code: "HIST-GEO",
    libelle: "Histoire-Géographie",
    couleur: "#f59e0b",
    coefficient: 2,
    heures_semaine: 3,
    actif: true,
  },
  {
    id: 6,
    code: "EPS",
    libelle: "Éducation Physique et Sportive",
    couleur: "#06b6d4",
    coefficient: 1,
    heures_semaine: 2,
    actif: true,
  },
]

// Rôles
const mockRoles = [
  {
    id: 1,
    code: "ADMIN",
    libelle: "Administrateur Système",
    description: "Accès complet au système",
    permissions: ["ALL"],
    actif: true,
  },
  {
    id: 2,
    code: "DAF",
    libelle: "Direction Affaires Financières",
    description: "Gestion financière et marchés",
    permissions: ["FINANCE", "MARCHES"],
    actif: true,
  },
  {
    id: 3,
    code: "DPFC",
    libelle: "Direction Pédagogie Formation",
    description: "Gestion pédagogique",
    permissions: ["PEDAGOGIE", "OUVRAGES"],
    actif: true,
  },
  {
    id: 4,
    code: "DRENA",
    libelle: "Directeur Régional",
    description: "Gestion régionale",
    permissions: ["REGIONAL"],
    actif: true,
  },
  {
    id: 5,
    code: "IEPP",
    libelle: "Inspecteur Primaire",
    description: "Inspection primaire",
    permissions: ["INSPECTION"],
    actif: true,
  },
]

// Configuration Système
const mockConfig = [
  {
    id: 1,
    cle: "ANNEE_SCOLAIRE_COURANTE",
    valeur: "2024-2025",
    type: "STRING",
    categorie: "GENERAL",
    description: "Année scolaire active",
  },
  {
    id: 2,
    cle: "SEUIL_STOCK_CRITIQUE",
    valeur: "500",
    type: "INTEGER",
    categorie: "STOCK",
    description: "Seuil d'alerte stock",
  },
  {
    id: 3,
    cle: "DELAI_TRAITEMENT_PLAINTE",
    valeur: "7",
    type: "INTEGER",
    categorie: "WORKFLOW",
    description: "Délai traitement plainte (jours)",
  },
  {
    id: 4,
    cle: "COULEUR_PRIMAIRE_CI",
    valeur: "#FF6600",
    type: "STRING",
    categorie: "THEME",
    description: "Orange Côte d'Ivoire",
  },
  {
    id: 5,
    cle: "COULEUR_SECONDAIRE_CI",
    valeur: "#00A651",
    type: "STRING",
    categorie: "THEME",
    description: "Vert Côte d'Ivoire",
  },
]

const PARAM_TAB_QUERY_IDS = new Set([
  "catalogues",
  "matieres",
  "niveaux",
  "annees",
  "roles",
  "permissions",
  "territoire",
  "config",
])

const rbacMatrixService = new RbacMatrixService()

function ParametragesPageContent() {
  const { user } = useAuth()
  const router = useRouter()
  const searchParams = useSearchParams()
  const [activeTab, setActiveTab] = useState("catalogues")
  const [searchTerm, setSearchTerm] = useState("")
  const [catalogueListPage, setCatalogueListPage] = useState(0)
  const [matiereListPage, setMatiereListPage] = useState(0)
  const [niveauListPage, setNiveauListPage] = useState(0)
  const [anneeListPage, setAnneeListPage] = useState(0)
  const [roleListPage, setRoleListPage] = useState(0)
  /** Après création d’un rôle : ouvrir l’onglet Permissions avec ce rôle présélectionné */
  const [matrixInitialRoleId, setMatrixInitialRoleId] = useState<number | null>(null)

  const consumeMatrixInitialRole = useCallback(() => {
    setMatrixInitialRoleId(null)
  }, [])

  useEffect(() => {
    setCatalogueListPage(0)
    setMatiereListPage(0)
    setNiveauListPage(0)
    setAnneeListPage(0)
    setRoleListPage(0)
  }, [searchTerm])
  const [showModal, setShowModal] = useState(false)
  const [selectedItem, setSelectedItem] = useState<any>(null)
  const [modalType, setModalType] = useState("")

  useEffect(() => {
    const rc = user?.role.code.toUpperCase() ?? ""
    const territoireOnly = isParametragesTerritoireOnlyRole(rc)
    if (territoireOnly) {
      setActiveTab("territoire")
      const t = searchParams.get("tab")
      if (t !== "territoire") {
        router.replace("/admin/parametrages?tab=territoire", { scroll: false })
      }
      return
    }
    const t = searchParams.get("tab")
    if (t && PARAM_TAB_QUERY_IDS.has(t)) {
      setActiveTab(t)
    } else if (!t) {
      setActiveTab("catalogues")
    }
  }, [searchParams, user?.role.code, router])

  // Hooks pour la gestion des matières
  const { 
    matieres, 
    loading: matieresLoading, 
    error: matieresError, 
    refreshMatieres,
    searchMatieres: searchMatieresData 
  } = useMatieres()
  
  const { 
    loading: operationLoading, 
    createMatiere, 
    updateMatiere, 
    deleteMatiere 
  } = useMatiereOperations()
  
  // Hooks pour la gestion des niveaux scolaires
  const { 
    niveauxScolaires, 
    loading: niveauxLoading, 
    error: niveauxError, 
    refreshNiveauxScolaires,
    searchNiveauxScolaires: searchNiveauxScolairesData 
  } = useNiveauxScolaires()
  
  const { 
    loading: niveauOperationLoading, 
    createNiveauScolaire, 
    updateNiveauScolaire, 
    deleteNiveauScolaire 
  } = useNiveauScolaireOperations()
  
  // État local pour les modals matières
  const [isCreatingMatiere, setIsCreatingMatiere] = useState(false)
  const [isUpdatingMatiere, setIsUpdatingMatiere] = useState(false)
  const [isDeletingMatiere, setIsDeletingMatiere] = useState(false)
  const [matiereStatusUpdatingId, setMatiereStatusUpdatingId] = useState<number | null>(null)
  
  // État local pour les modals niveaux scolaires
  const [isCreatingNiveau, setIsCreatingNiveau] = useState(false)
  const [isUpdatingNiveau, setIsUpdatingNiveau] = useState(false)
  const [isDeletingNiveau, setIsDeletingNiveau] = useState(false)

  // Hooks pour la gestion des rôles
  const { 
    roles, 
    loading: rolesLoading, 
    error: rolesError, 
    refreshRoles,
    searchRoles: searchRolesData 
  } = useRolesCrud()
  
  const { 
    loading: roleOperationLoading, 
    createRole, 
    updateRole, 
    deleteRole 
  } = useRoleOperations()
  
  // État local pour les modals rôles
  const [isCreatingRole, setIsCreatingRole] = useState(false)
  const [isUpdatingRole, setIsUpdatingRole] = useState(false)
  const [isDeletingRole, setIsDeletingRole] = useState(false)
  const [roleStatusUpdatingId, setRoleStatusUpdatingId] = useState<number | null>(null)
  /** Nombre de fonctionnalités RBAC (lignes matrice), pour le badge de l’onglet Permissions */
  const [permissionFonctionCount, setPermissionFonctionCount] = useState(0)

  useEffect(() => {
    if (!roles.length) return
    const roleId = roles[0]?.id
    if (!roleId) return
    let cancelled = false
    rbacMatrixService
      .loadMatrix(roleId)
      .then((res) => {
        if (cancelled || res.hasError) return
        const snap = res.items?.[0] as { rows?: unknown[] } | undefined
        if (snap?.rows && Array.isArray(snap.rows)) {
          setPermissionFonctionCount(snap.rows.length)
        }
      })
      .catch(() => {})
    return () => {
      cancelled = true
    }
  }, [roles])

  // Hooks pour la gestion des catalogues
  const { 
    catalogues, 
    loading: cataloguesLoading, 
    error: cataloguesError, 
    refreshCatalogues,
    searchCatalogues: searchCataloguesData 
  } = useCatalogues()
  
  const { 
    loading: catalogueOperationLoading, 
    createCatalogue, 
    updateCatalogue, 
    deleteCatalogue 
  } = useCatalogueOperations()
  
  // État local pour les modals catalogues
  const [isCreatingCatalogue, setIsCreatingCatalogue] = useState(false)
  const [isUpdatingCatalogue, setIsUpdatingCatalogue] = useState(false)
  const [isDeletingCatalogue, setIsDeletingCatalogue] = useState(false)

  // Hooks pour la gestion des années scolaires
  const { 
    anneesScolaires, 
    loading: anneesLoading, 
    error: anneesError, 
    refreshAnneesScolaires,
    searchAnneesScolaires: searchAnneesScolairesData 
  } = useAnneesScolaires()
  
  const { 
    loading: anneeOperationLoading, 
    createAnneeScolaire, 
    updateAnneeScolaire, 
    deleteAnneeScolaire,
    setAnneeScolaireCourante 
  } = useAnneeScolaireOperations()
  
  // État local pour les modals années scolaires
  const [isCreatingAnnee, setIsCreatingAnnee] = useState(false)
  const [isUpdatingAnnee, setIsUpdatingAnnee] = useState(false)
  const [isDeletingAnnee, setIsDeletingAnnee] = useState(false)

  // État local pour le formulaire de catalogue (année et actif)
  const [catalogueAnneeId, setCatalogueAnneeId] = useState<string>("")
  const [catalogueActif, setCatalogueActif] = useState<boolean>(true)
  const [catalogueStatusUpdatingId, setCatalogueStatusUpdatingId] = useState<number | null>(null)

  // Année scolaire courante (ou, à défaut, première de la liste)
  const currentCatalogueAnnee = useMemo(
    () => anneesScolaires.find((a: any) => a.estCourante) || anneesScolaires[0] || null,
    [anneesScolaires]
  )

  // Synchroniser l'état local du formulaire catalogue quand on ouvre la modale ou que la sélection change
  useEffect(() => {
    if (modalType === "catalogue") {
      if (selectedItem) {
        setCatalogueAnneeId(selectedItem.anneeScolaireId ? String(selectedItem.anneeScolaireId) : "")
        setCatalogueActif(!!selectedItem.active)
      } else {
        const defAnnee = currentCatalogueAnnee
        setCatalogueAnneeId(defAnnee ? String(defAnnee.id) : "")
        setCatalogueActif(true)
      }
    }
  }, [modalType, selectedItem, currentCatalogueAnnee])

  // Hook pour récupérer les matières associées au catalogue en cours de modification
  const { 
    matieres: matieresAssociees, 
    loading: matieresAssocieesLoading, 
    fetchMatieresByCatalogue,
    resetMatieres
  } = useMatieresByCatalogue()


  // Fonctions CRUD pour les matières
  const handleCreateMatiere = async (formData: FormData) => {
    const libelle = (formData.get('libelle') as string || '').trim()
    const description = (formData.get('description') as string || undefined) || undefined
    const isActif = formData.get('isActif') === 'true'

    if (!libelle) {
      toast.error('Le libellé est obligatoire')
      return
    }

    // Générer automatiquement un code à partir du libellé
    const words = libelle
      .toUpperCase()
      .replace(/[^A-Z0-9\s]/g, ' ')
      .split(/\s+/)
      .filter(Boolean)
    const baseCode =
      (words[0]?.slice(0, 3) || 'MAT') +
      (words[1]?.charAt(0) || '')
    const code = baseCode || 'MAT'

    const matiereData = {
      code,
      libelle,
      description,
      isActif,
    }
    
    setIsCreatingMatiere(true)
    const result = await createMatiere(matiereData)
    setIsCreatingMatiere(false)
    
    if (result.success) {
      setShowModal(false)
      setSelectedItem(null)
      await refreshMatieres()
    }
  }

  const handleToggleMatiereActif = async (matiere: Matiere, nextActive: boolean) => {
    if (!matiere.id) return
    try {
      setMatiereStatusUpdatingId(matiere.id)
      await updateMatiere(matiere.id, {
        code: matiere.code,
        libelle: matiere.libelle,
        description: matiere.description,
        isActif: nextActive,
      })
      toast.success(nextActive ? "Ouvrage activé" : "Ouvrage désactivé")
      refreshMatieres()
    } catch (error) {
      console.error("Erreur lors du changement de statut de l'ouvrage:", error)
      toast.error("Erreur lors du changement de statut de l'ouvrage")
    } finally {
      setMatiereStatusUpdatingId(null)
    }
  }
  
  const handleUpdateMatiere = async (formData: FormData) => {
    if (!selectedItem?.id) return
    
    const matiereData = {
      code: selectedItem.code as string,
      libelle: formData.get('libelle') as string,
      description: formData.get('description') as string || undefined,
      isActif: formData.get('isActif') === 'true',
    }
    
    if (!matiereData.libelle) {
      toast.error('Le libellé est obligatoire')
      return
    }
    
    setIsUpdatingMatiere(true)
    const result = await updateMatiere(selectedItem.id, matiereData)
    setIsUpdatingMatiere(false)
    
    if (result.success) {
      setShowModal(false)
      setSelectedItem(null)
      await refreshMatieres()
    }
  }
  
  const handleDeleteMatiere = async () => {
    if (!selectedItem?.id) return
    
    setIsDeletingMatiere(true)
    const result = await deleteMatiere(selectedItem.id)
    setIsDeletingMatiere(false)
    
    if (result.success) {
      setShowModal(false)
      setSelectedItem(null)
      await refreshMatieres()
    }
  }
  
  // Fonction pour la recherche des matières
  const handleSearchMatieres = async (term: string) => {
    setSearchTerm(term)
    if (term.trim()) {
      await searchMatieresData(term)
    } else {
      await refreshMatieres()
    }
  }

  // Fonctions CRUD pour les niveaux scolaires
  const handleCreateNiveau = async (formData: FormData) => {
    const niveauData = {
      code: formData.get('code') as string,
      libelle: formData.get('libelle') as string,
      ordre: parseInt(formData.get('ordre') as string),
    }
    
    if (!niveauData.code || !niveauData.libelle || !niveauData.ordre) {
      toast.error('Le code, le libellé et l\'ordre sont obligatoires')
      return
    }
    
    setIsCreatingNiveau(true)
    const result = await createNiveauScolaire(niveauData)
    setIsCreatingNiveau(false)
    
    if (result.success) {
      setShowModal(false)
      setSelectedItem(null)
      await refreshNiveauxScolaires()
    }
  }
  
  const handleUpdateNiveau = async (formData: FormData) => {
    if (!selectedItem?.id) return
    
    const niveauData = {
      code: formData.get('code') as string,
      libelle: formData.get('libelle') as string,
      ordre: parseInt(formData.get('ordre') as string),
    }
    
    if (!niveauData.code || !niveauData.libelle || !niveauData.ordre) {
      toast.error('Le code, le libellé et l\'ordre sont obligatoires')
      return
    }
    
    setIsUpdatingNiveau(true)
    const result = await updateNiveauScolaire(selectedItem.id, niveauData)
    setIsUpdatingNiveau(false)
    
    if (result.success) {
      setShowModal(false)
      setSelectedItem(null)
      await refreshNiveauxScolaires()
    }
  }
  
  const handleDeleteNiveau = async () => {
    if (!selectedItem?.id) return
    
    setIsDeletingNiveau(true)
    const result = await deleteNiveauScolaire(selectedItem.id)
    setIsDeletingNiveau(false)
    
    if (result.success) {
      setShowModal(false)
      setSelectedItem(null)
      await refreshNiveauxScolaires()
    }
  }
  
  // Fonction pour la recherche des niveaux scolaires
  const handleSearchNiveaux = async (term: string) => {
    setSearchTerm(term)
    if (term.trim()) {
      await searchNiveauxScolairesData(term)
    } else {
      await refreshNiveauxScolaires()
    }
  }

  // Fonctions CRUD pour les rôles
  const handleCreateRole = async (formData: FormData) => {
    const rawCode = formData.get("code") as string
    const roleData = {
      code: normalizeRoleCodeForStorage(rawCode),
      libelle: (formData.get("libelle") as string)?.trim() || "",
      description: (formData.get("description") as string)?.trim() || undefined,
    }

    if (!roleData.code || !roleData.libelle) {
      toast.error("Le code et le libellé sont obligatoires (code non valide après normalisation)")
      return
    }

    setIsCreatingRole(true)
    const result = await createRole(roleData)
    setIsCreatingRole(false)

    if (result.success) {
      setShowModal(false)
      setSelectedItem(null)
      await refreshRoles()
      const created: any = result.data
      const newId =
        typeof created?.id === "number"
          ? created.id
          : Array.isArray(created) && typeof created[0]?.id === "number"
            ? created[0].id
            : undefined
      if (newId != null && newId > 0) {
        setMatrixInitialRoleId(newId)
        setActiveTab("permissions")
        router.replace("/admin/parametrages?tab=permissions", { scroll: false })
      }
    }
  }
  
  const handleUpdateRole = async (formData: FormData) => {
    if (!selectedItem?.id) return
    
    const roleData = {
      code: formData.get('code') as string,
      libelle: formData.get('libelle') as string,
      description: formData.get('description') as string || undefined,
    }
    
    if (!roleData.code || !roleData.libelle) {
      toast.error('Le code et le libellé sont obligatoires')
      return
    }
    
    setIsUpdatingRole(true)
    const result = await updateRole(selectedItem.id, roleData)
    setIsUpdatingRole(false)
    
    if (result.success) {
      setShowModal(false)
      setSelectedItem(null)
      await refreshRoles()
    }
  }
  
  const handleDeleteRole = async () => {
    if (!selectedItem?.id) return
    
    setIsDeletingRole(true)
    const result = await deleteRole(selectedItem.id)
    setIsDeletingRole(false)
    
    if (result.success) {
      setShowModal(false)
      setSelectedItem(null)
      await refreshRoles()
    }
  }

  const handleToggleRoleActif = async (role: Role, nextActive: boolean) => {
    if (!role.id) return
    try {
      setRoleStatusUpdatingId(role.id)
      const result = await updateRole(role.id, { isActive: nextActive } as any)
      if (!result.success) {
        throw new Error(result.error || 'Erreur lors de la mise à jour')
      }
      toast.success(nextActive ? "Rôle activé" : "Rôle désactivé")
      await refreshRoles()
    } catch (error) {
      console.error("Erreur lors du changement de statut du rôle:", error)
      toast.error("Erreur lors du changement de statut du rôle")
    } finally {
      setRoleStatusUpdatingId(null)
    }
  }
  
  // Fonction pour la recherche des rôles
  const handleSearchRoles = async (term: string) => {
    setSearchTerm(term)
    if (term.trim()) {
      await searchRolesData(term)
    } else {
      await refreshRoles()
    }
  }

  // Fonctions pour les catalogues
  const handleCreateCatalogue = async (data: any) => {
    setIsCreatingCatalogue(true)
    try {
      const result = await createCatalogue(data)
      if (!result.success) return
      toast.success("Catalogue créé avec succès")
      setShowModal(false)
      refreshCatalogues()
    } catch (error) {
      console.error("Erreur lors de la création du catalogue:", error)
      toast.error("Erreur lors de la création du catalogue")
    } finally {
      setIsCreatingCatalogue(false)
    }
  }

  const handleUpdateCatalogue = async (data: any) => {
    setIsUpdatingCatalogue(true)
    try {
      const result = await updateCatalogue(selectedItem.id, data)
      if (!result.success) return
      toast.success("Catalogue modifié avec succès")
      setShowModal(false)
      refreshCatalogues()
    } catch (error) {
      console.error("Erreur lors de la modification du catalogue:", error)
      toast.error("Erreur lors de la modification du catalogue")
    } finally {
      setIsUpdatingCatalogue(false)
    }
  }

  const handleDeleteCatalogue = async () => {
    setIsDeletingCatalogue(true)
    try {
      await deleteCatalogue(selectedItem.id)
      toast.success("Catalogue supprimé avec succès")
      setShowModal(false)
      refreshCatalogues()
    } catch (error) {
      console.error("Erreur lors de la suppression du catalogue:", error)
      toast.error("Erreur lors de la suppression du catalogue")
    } finally {
      setIsDeletingCatalogue(false)
    }
  }

  const handleToggleCatalogueActif = async (catalogue: Catalogue, nextActive: boolean) => {
    if (!catalogue.id) return
    try {
      setCatalogueStatusUpdatingId(catalogue.id)
      const result = await updateCatalogue(catalogue.id, { active: nextActive })
      if (!result.success) return
      toast.success(nextActive ? "Catalogue activé" : "Catalogue désactivé")
      refreshCatalogues()
    } catch (error) {
      console.error("Erreur lors du changement de statut du catalogue:", error)
      toast.error("Erreur lors du changement de statut du catalogue")
    } finally {
      setCatalogueStatusUpdatingId(null)
    }
  }

  // Fonctions pour les années scolaires
  const handleCreateAnneeScolaire = async (data: any) => {
    setIsCreatingAnnee(true)
    try {
      await createAnneeScolaire(data)
      toast.success("Année scolaire créée avec succès")
      setShowModal(false)
      refreshAnneesScolaires()
    } catch (error) {
      console.error("Erreur lors de la création de l'année scolaire:", error)
      toast.error("Erreur lors de la création de l'année scolaire")
    } finally {
      setIsCreatingAnnee(false)
    }
  }

  const handleUpdateAnneeScolaire = async (data: any) => {
    setIsUpdatingAnnee(true)
    try {
      await updateAnneeScolaire(selectedItem.id, data)
      toast.success("Année scolaire modifiée avec succès")
      setShowModal(false)
      refreshAnneesScolaires()
    } catch (error) {
      console.error("Erreur lors de la modification de l'année scolaire:", error)
      toast.error("Erreur lors de la modification de l'année scolaire")
    } finally {
      setIsUpdatingAnnee(false)
    }
  }

  const handleDeleteAnneeScolaire = async () => {
    setIsDeletingAnnee(true)
    try {
      await deleteAnneeScolaire(selectedItem.id)
      toast.success("Année scolaire supprimée avec succès")
      setShowModal(false)
      refreshAnneesScolaires()
    } catch (error) {
      console.error("Erreur lors de la suppression de l'année scolaire:", error)
      toast.error("Erreur lors de la suppression de l'année scolaire")
    } finally {
      setIsDeletingAnnee(false)
    }
  }

  const handleSetAnneeCourante = async (anneeId: number) => {
    try {
      await setAnneeScolaireCourante(anneeId)
      toast.success("Année scolaire courante définie avec succès")
      refreshAnneesScolaires()
    } catch (error) {
      console.error("Erreur lors de la définition de l'année courante:", error)
      toast.error("Erreur lors de la définition de l'année courante")
    }
  }

  const tabs = [
    { id: "catalogues", name: "Catalogues", icon: BookOpenIcon, count: catalogues.length },
    { id: "matieres", name: "Matières", icon: DocumentTextIcon, count: matieres.length },
    { id: "niveaux", name: "Classes & Niveaux", icon: AcademicCapIcon, count: niveauxScolaires.length },
    { id: "annees", name: "Années Scolaires", icon: CalendarIcon, count: anneesScolaires.length },
    { id: "roles", name: "Rôles", icon: UserGroupIcon, count: roles.length },
    {
      id: "permissions",
      name: "Permissions",
      icon: ShieldCheckIcon,
      count: permissionFonctionCount,
    },
    { id: "territoire", name: "DRENA / IEPP / EPP", icon: BuildingOfficeIcon },
    { id: "config", name: "Configuration", icon: ServerIcon, count: mockConfig.length },
  ]

  const flatFilteredCatalogues = useMemo(() => {
    const q = searchTerm.trim().toLowerCase()
    const filtered = !q
      ? [...catalogues]
      : catalogues.filter((catalogue) => {
          const anneeLabel = catalogue.anneeScolaireLibelle || catalogue.anneeScolaire?.libelle || "Non définie"
          return (
            (catalogue.libelle || "").toLowerCase().includes(q) ||
            (catalogue.code || "").toLowerCase().includes(q) ||
            (catalogue.niveauScolaireLibelle || "").toLowerCase().includes(q) ||
            anneeLabel.toLowerCase().includes(q)
          )
        })
    filtered.sort((a, b) => (a.libelle || "").localeCompare(b.libelle || "", "fr", { sensitivity: "base" }))
    return filtered
  }, [catalogues, searchTerm])

  const groupedCataloguesByYear = useMemo(() => {
    const start = catalogueListPage * PARAMETRAGE_LIST_PAGE_SIZE
    const pageSlice = flatFilteredCatalogues.slice(start, start + PARAMETRAGE_LIST_PAGE_SIZE)
    const grouped = pageSlice.reduce((acc, catalogue) => {
      const yearLabel = catalogue.anneeScolaireLibelle || catalogue.anneeScolaire?.libelle || "Non définie"
      if (!acc[yearLabel]) acc[yearLabel] = []
      acc[yearLabel].push(catalogue)
      return acc
    }, {} as Record<string, Catalogue[]>)

    return Object.entries(grouped).sort(([a], [b]) => {
      if (a === "Non définie") return 1
      if (b === "Non définie") return -1
      return b.localeCompare(a, "fr", { numeric: true, sensitivity: "base" })
    })
  }, [flatFilteredCatalogues, catalogueListPage])

  const orderedNiveauxScolaires = useMemo(
    () =>
      [...niveauxScolaires].sort(
        (a, b) =>
          (a.ordre ?? Number.MAX_SAFE_INTEGER) - (b.ordre ?? Number.MAX_SAFE_INTEGER) ||
          (a.libelle ?? "").localeCompare(b.libelle ?? "", "fr", { sensitivity: "base" })
      ),
    [niveauxScolaires]
  )

  const orderedMatieres = useMemo(
    () =>
      [...matieres].sort(
        (a, b) =>
          Number(b.isActif ?? true) - Number(a.isActif ?? true) ||
          (a.libelle ?? "").localeCompare(b.libelle ?? "", "fr", { sensitivity: "base" })
      ),
    [matieres]
  )

  const orderedRoles = useMemo(
    () =>
      [...roles].sort(
        (a, b) =>
          Number(b.isActive ?? true) - Number(a.isActive ?? true) ||
          (a.libelle ?? "").localeCompare(b.libelle ?? "", "fr", { sensitivity: "base" })
      ),
    [roles]
  )

  const orderedAnneesScolaires = useMemo(
    () =>
      [...anneesScolaires].sort(
        (a, b) =>
          Number(b.estCourante ?? false) - Number(a.estCourante ?? false) ||
          (b.libelle ?? "").localeCompare(a.libelle ?? "", "fr", { numeric: true, sensitivity: "base" })
      ),
    [anneesScolaires]
  )

  const paginatedNiveauxScolaires = useMemo(() => {
    const s = niveauListPage * PARAMETRAGE_LIST_PAGE_SIZE
    return orderedNiveauxScolaires.slice(s, s + PARAMETRAGE_LIST_PAGE_SIZE)
  }, [orderedNiveauxScolaires, niveauListPage])

  const paginatedMatieres = useMemo(() => {
    const s = matiereListPage * PARAMETRAGE_LIST_PAGE_SIZE
    return orderedMatieres.slice(s, s + PARAMETRAGE_LIST_PAGE_SIZE)
  }, [orderedMatieres, matiereListPage])

  const paginatedRoles = useMemo(() => {
    const s = roleListPage * PARAMETRAGE_LIST_PAGE_SIZE
    return orderedRoles.slice(s, s + PARAMETRAGE_LIST_PAGE_SIZE)
  }, [orderedRoles, roleListPage])

  const filteredAnneesForList = useMemo(() => {
    const q = searchTerm.trim().toLowerCase()
    if (!q) return orderedAnneesScolaires
    return orderedAnneesScolaires.filter(
      (a) =>
        (a.libelle || "").toLowerCase().includes(q) ||
        (a.code || "").toLowerCase().includes(q),
    )
  }, [orderedAnneesScolaires, searchTerm])

  const paginatedAnneesScolaires = useMemo(() => {
    const s = anneeListPage * PARAMETRAGE_LIST_PAGE_SIZE
    return filteredAnneesForList.slice(s, s + PARAMETRAGE_LIST_PAGE_SIZE)
  }, [filteredAnneesForList, anneeListPage])

  const orderedConfig = useMemo(
    () =>
      [...mockConfig].sort(
        (a, b) =>
          (a.categorie ?? "").localeCompare(b.categorie ?? "", "fr", { sensitivity: "base" }) ||
          (a.cle ?? "").localeCompare(b.cle ?? "", "fr", { sensitivity: "base" })
      ),
    []
  )

  const roleCodeUpper = user?.role.code.toUpperCase() ?? ""
  const structureTerritoryRead = hasFunctionalityPermission(
    user?.functionalityPermissions,
    "STRUCTURE_ADMINISTRATIVE",
    "READ",
  )
  const canAccessParametrages =
    !!user &&
    (["ADMIN", "DAF", "DPFC"].includes(roleCodeUpper) ||
      (isParametragesTerritoireOnlyRole(roleCodeUpper) &&
        (!isEppSchoolOperationalRole(roleCodeUpper) || structureTerritoryRead)))

  if (!user || !canAccessParametrages) {
    return (
      <MainLayout>
        <div className="text-center py-12">
          <CogIcon className="h-16 w-16 text-gray-400 mx-auto mb-4" />
          <h2 className="text-xl font-semibold text-gray-900 mb-2">Accès Restreint</h2>
          <p className="text-gray-600">
            Accès réservé aux profils paramétreur (ADMIN, DAF, DPFC), à la consultation territoriale (DRENA,
            inspection IEPP / intendant / CPS), ou à l&apos;équipe établissement disposant de la permission lecture
            « Structure administrative » (accordée via les rôles et fonctionnalités).
          </p>
        </div>
      </MainLayout>
    )
  }

  const openModal = (type: string, item: any = null) => {
    setModalType(type)
    setSelectedItem(item)
    setShowModal(true)
    
    // Si on ouvre un modal lié à un catalogue, réinitialiser et récupérer ses matières associées
    if ((type === "catalogue" || type === "catalogue-detail") && item?.id) {
      // Réinitialiser les données avant de charger les nouvelles
      resetMatieres()
      // Charger les nouvelles données
      fetchMatieresByCatalogue(item.id)
    } else if (type === "catalogue" && !item) {
      // Si c'est un nouveau catalogue, réinitialiser les données
      resetMatieres()
    }
  }

  const closeModal = () => {
    setShowModal(false)
    setSelectedItem(null)
    setModalType("")
    
    // Nettoyer les données des matières associées quand on ferme le modal
    resetMatieres()
  }

  return (
    <MainLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="bg-gradient-to-r from-orange-500 to-green-500 rounded-lg p-6 text-white">
          <h1 className="text-2xl font-bold">Paramétrages DISMAS</h1>
          <p className="text-orange-100">Configuration du système de distribution des manuels scolaires</p>
          <p className="text-sm text-orange-100 mt-1">
            République de Côte d'Ivoire • Ministère de l'Éducation Nationale
          </p>
        </div>

        {/* Tabs */}
        <div className="border-b border-gray-200">
          <nav className="-mb-px flex space-x-8 overflow-x-auto">
            {(isParametragesTerritoireOnlyRole(roleCodeUpper)
              ? tabs.filter((t) => t.id === "territoire")
              : tabs
            ).map((tab) => (
              <button
                key={tab.id}
                type="button"
                onClick={() => {
                  setActiveTab(tab.id)
                  router.replace(`/admin/parametrages?tab=${encodeURIComponent(tab.id)}`, { scroll: false })
                }}
                className={`flex items-center py-2 px-1 border-b-2 font-medium text-sm whitespace-nowrap ${
                  activeTab === tab.id
                    ? "border-orange-500 text-orange-600"
                    : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
                }`}
              >
                <tab.icon className="h-5 w-5 mr-2 flex-shrink-0" />
                {tab.name}
                {typeof (tab as { count?: number }).count === "number" && (
                  <span className="ml-2 bg-gray-100 text-gray-600 py-0.5 px-2 rounded-full text-xs">
                    {(tab as { count: number }).count}
                  </span>
                )}
              </button>
            ))}
          </nav>
        </div>


        {/* Niveaux Tab */}
        {activeTab === "niveaux" && (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-lg font-semibold text-gray-900">Classes & Niveaux Scolaires</h2>
                <p className="text-gray-600">Configuration des niveaux du système éducatif ivoirien</p>
                {niveauxLoading && <p className="text-sm text-blue-600">🔄 Chargement des données...</p>}
                {niveauxError && <p className="text-sm text-red-600">❌ {niveauxError}</p>}
              </div>
              {(user?.role.code === "ADMIN" || user?.role.code === "DAF") && (
                <div className="flex items-center space-x-2">
                  <button 
                    onClick={refreshNiveauxScolaires} 
                    className="btn-outline"
                    disabled={niveauxLoading}
                    title="Actualiser la liste"
                  >
                    <ArrowPathIcon className="h-5 w-5 mr-2" />
                    Actualiser
                  </button>
                  <button 
                    onClick={() => openModal("niveau")} 
                    className="btn-primary"
                    disabled={niveauxLoading}
                  >
                <PlusIcon className="h-5 w-5 mr-2" />
                Nouveau Niveau
              </button>
                </div>
              )}
            </div>

            {/* Barre de recherche */}
            <div className="card">
              <div className="relative">
                <MagnifyingGlassIcon className="h-5 w-5 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                <input
                  type="text"
                  className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 w-full"
                  placeholder="Rechercher un niveau scolaire..."
                  value={searchTerm}
                  onChange={(e) => handleSearchNiveaux(e.target.value)}
                  disabled={niveauxLoading}
                />
              </div>
            </div>

            {/* Liste des niveaux scolaires */}
            {niveauxLoading ? (
              <div className="text-center py-12">
                <ArrowPathIcon className="h-12 w-12 animate-spin text-orange-500 mx-auto mb-4" />
                <p className="text-gray-600">Chargement des niveaux scolaires...</p>
              </div>
            ) : niveauxScolaires.length === 0 ? (
              <div className="text-center py-12">
                <AcademicCapIcon className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-900 mb-2">Aucun niveau scolaire</h3>
                <p className="text-gray-600">
                  {searchTerm ? 'Aucun niveau scolaire trouvé pour cette recherche' : 'Aucun niveau scolaire configuré'}
                </p>
                {(user?.role.code === "ADMIN" || user?.role.code === "DAF") && !searchTerm && (
                  <button 
                    onClick={() => openModal("niveau")} 
                    className="btn-primary mt-4"
                  >
                    <PlusIcon className="h-5 w-5 mr-2" />
                    Créer le premier niveau scolaire
                  </button>
                )}
              </div>
            ) : (
              <>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {paginatedNiveauxScolaires.map((niveau) => (
                  <div key={niveau.id} className="card hover:shadow-lg transition-shadow">
                    <div className="flex items-center mb-4">
                      <div className="w-12 h-12 rounded-lg flex items-center justify-center text-white font-bold bg-purple-500">
                        {niveau.ordre || 0}
                      </div>
                      <div className="ml-4 flex-1">
                        <h3 className="font-semibold text-gray-900">{niveau.libelle}</h3>
                        <p className="text-sm text-gray-500 font-mono">{niveau.code}</p>
                      </div>
                    </div>

                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between items-center">
                        <span className="text-gray-600">Cycle:</span>
                        <span className="font-medium text-gray-900">PRIMAIRE</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-gray-600">Âge:</span>
                        <span className="font-medium text-gray-900">
                          6 - 12 ans
                        </span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-gray-600">Statut:</span>
                        <span className="badge badge-success">
                          Active
                        </span>
                      </div>
                    </div>

                    {(user?.role.code === "ADMIN" || user?.role.code === "DAF") && (
                      <div className="flex space-x-2 mt-4 pt-4 border-t">
                        <button 
                          onClick={() => openModal("niveau", niveau)} 
                          className="flex-1 btn-primary text-sm py-2"
                          disabled={niveauOperationLoading}
                        >
                          <PencilIcon className="h-4 w-4 mr-1" />
                          Modifier
                        </button>
                        <button 
                          onClick={() => openModal("delete-niveau", niveau)} 
                          className="flex-1 btn-danger text-sm py-2"
                          disabled={niveauOperationLoading}
                        >
                          <TrashIcon className="h-4 w-4 mr-1" />
                          Supprimer
                        </button>
                      </div>
                    )}
                  </div>
                ))}
              </div>
              <ParametrageListPagination
                pageIndex={niveauListPage}
                pageSize={PARAMETRAGE_LIST_PAGE_SIZE}
                total={orderedNiveauxScolaires.length}
                loading={niveauxLoading}
                onPageChange={setNiveauListPage}
              />
              </>
            )}
          </div>
        )}

        {/* Matières Tab */}
        {activeTab === "matieres" && (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-lg font-semibold text-gray-900">Ouvrages & Disciplines</h2>
                <p className="text-gray-600">Configuration des ouvrages enseignés</p>
                {matieresLoading && <p className="text-sm text-blue-600">🔄 Chargement des données...</p>}
                {matieresError && <p className="text-sm text-red-600">❌ {matieresError}</p>}
              </div>
              {(user?.role.code === "ADMIN" || user?.role.code === "DAF") && (
                <div className="flex items-center space-x-2">
                  <button 
                    onClick={refreshMatieres} 
                    className="btn-outline"
                    disabled={matieresLoading}
                    title="Actualiser la liste"
                  >
                    <ArrowPathIcon className="h-5 w-5 mr-2" />
                    Actualiser
                  </button>
                  <button 
                    onClick={() => openModal("matiere")} 
                    className="btn-primary"
                    disabled={matieresLoading}
                  >
                    <PlusIcon className="h-5 w-5 mr-2" />
                    Nouvel Ouvrage
                  </button>
                </div>
              )}
            </div>

            {/* Barre de recherche */}
            <div className="card">
              <div className="relative">
                <MagnifyingGlassIcon className="h-5 w-5 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                <input
                  type="text"
                  className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 w-full"
                  placeholder="Rechercher un ouvrage..."
                  value={searchTerm}
                  onChange={(e) => handleSearchMatieres(e.target.value)}
                  disabled={matieresLoading}
                />
              </div>
            </div>

            {/* Liste des matières */}
            {matieresLoading ? (
              <div className="text-center py-12">
                <ArrowPathIcon className="h-12 w-12 animate-spin text-orange-500 mx-auto mb-4" />
                <p className="text-gray-600">Chargement des ouvrages...</p>
              </div>
            ) : matieres.length === 0 ? (
              <div className="text-center py-12">
                <DocumentTextIcon className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-900 mb-2">Aucun ouvrage</h3>
                <p className="text-gray-600">
                  {searchTerm ? 'Aucun ouvrage trouvé pour cette recherche' : 'Aucun ouvrage configuré'}
                </p>
                {(user?.role.code === "ADMIN" || user?.role.code === "DAF") && !searchTerm && (
                  <button 
                    onClick={() => openModal("matiere")} 
                    className="btn-primary mt-4"
                  >
                    <PlusIcon className="h-5 w-5 mr-2" />
                    Créer le premier ouvrage
                  </button>
                )}
              </div>
            ) : (
              <>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {paginatedMatieres.map((matiere) => (
                  <div key={matiere.id} className="card hover:shadow-lg transition-shadow">
                    <div className="mb-4 flex flex-col sm:flex-row sm:items-start sm:justify-between gap-3">
                      <div className="flex items-start gap-3 min-w-0">
                        <div className="w-12 h-12 rounded-lg flex items-center justify-center text-white font-bold bg-orange-500 shrink-0">
                          {matiere.code.substring(0, 2)}
                        </div>
                        <div className="min-w-0">
                          <h3 className="font-semibold text-gray-900 truncate">{matiere.libelle}</h3>
                          <p className="text-sm text-gray-500 font-mono truncate">{matiere.code}</p>
                        </div>
                      </div>

                      <div className="flex flex-col sm:items-end items-start gap-2 w-full sm:w-auto">
                        <span
                          className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                            matiere.isActif === false ? "bg-red-100 text-red-800" : "bg-green-100 text-green-800"
                          }`}
                          title={matiere.isActif === false ? "Ouvrage désactivé" : "Ouvrage actif"}
                        >
                          {matiere.isActif === false ? "Inactif" : "Actif"}
                        </span>

                        {(user?.role.code === "ADMIN" || user?.role.code === "DAF") && (
                          <div className="flex w-full sm:w-auto rounded-md shadow-sm border border-gray-200 overflow-hidden">
                            <button
                              type="button"
                              onClick={() => handleToggleMatiereActif(matiere, true)}
                              disabled={operationLoading || matiereStatusUpdatingId === matiere.id}
                              className={`flex-1 sm:flex-none px-2.5 py-1 text-xs font-medium ${
                                matiere.isActif === false
                                  ? "bg-white text-gray-700 hover:bg-gray-50"
                                  : "bg-green-600 text-white"
                              }`}
                            >
                              Actif
                            </button>
                            <button
                              type="button"
                              onClick={() => handleToggleMatiereActif(matiere, false)}
                              disabled={operationLoading || matiereStatusUpdatingId === matiere.id}
                              className={`flex-1 sm:flex-none px-2.5 py-1 text-xs font-medium ${
                                matiere.isActif === false
                                  ? "bg-red-600 text-white"
                                  : "bg-white text-gray-700 hover:bg-gray-50"
                              }`}
                            >
                              Inactif
                            </button>
                          </div>
                        )}
                      </div>
                    </div>

                    {matiere.description && (
                      <div className="mb-4">
                        <p className="text-sm text-gray-600">{matiere.description}</p>
                      </div>
                    )}

                    {/* Statut affiché dans l'en-tête */}

                    {(user?.role.code === "ADMIN" || user?.role.code === "DAF") && (
                      <div className="flex space-x-2 mt-4 pt-4 border-t">
                        <button 
                          onClick={() => openModal("matiere", matiere)} 
                          className="flex-1 btn-primary text-sm py-2"
                          disabled={operationLoading}
                        >
                          <PencilIcon className="h-4 w-4 mr-1" />
                          Modifier
                        </button>
                        <button 
                          onClick={() => openModal("delete-matiere", matiere)} 
                          className="flex-1 btn-danger text-sm py-2"
                          disabled={operationLoading}
                        >
                          <TrashIcon className="h-4 w-4 mr-1" />
                          Supprimer
                        </button>
                      </div>
                    )}
                  </div>
                ))}
              </div>
              <ParametrageListPagination
                pageIndex={matiereListPage}
                pageSize={PARAMETRAGE_LIST_PAGE_SIZE}
                total={orderedMatieres.length}
                loading={matieresLoading}
                onPageChange={setMatiereListPage}
              />
              </>
            )}
          </div>
        )}

        {/* Territoire DRENA / IEPP / EPP */}
        {activeTab === "territoire" && <ParametragesTerritorialStructuresPanel user={user} />}

        {/* Rôles Tab */}
        {activeTab === "roles" && (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-lg font-semibold text-gray-900">Rôles & Permissions</h2>
                <p className="text-gray-600">Gestion des profils utilisateurs</p>
                {rolesLoading && <p className="text-sm text-blue-600">🔄 Chargement des données...</p>}
                {rolesError && <p className="text-sm text-red-600">❌ {rolesError}</p>}
              </div>
              {(user?.role.code === "ADMIN" || user?.role.code === "DAF") && (
                <div className="flex items-center space-x-2">
                  <button 
                    onClick={refreshRoles} 
                    className="btn-outline"
                    disabled={rolesLoading}
                    title="Actualiser la liste"
                  >
                    <ArrowPathIcon className="h-5 w-5 mr-2" />
                    Actualiser
                  </button>
                  <button 
                    onClick={() => openModal("role")} 
                    className="btn-primary"
                    disabled={rolesLoading}
                  >
                <PlusIcon className="h-5 w-5 mr-2" />
                Nouveau Rôle
              </button>
                </div>
              )}
            </div>

            {/* Barre de recherche */}
            <div className="card">
              <div className="relative">
                <MagnifyingGlassIcon className="h-5 w-5 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                <input
                  type="text"
                  className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 w-full"
                  placeholder="Rechercher un rôle..."
                  value={searchTerm}
                  onChange={(e) => handleSearchRoles(e.target.value)}
                  disabled={rolesLoading}
                />
              </div>
            </div>

            {/* Liste des rôles */}
            {rolesLoading ? (
              <div className="text-center py-12">
                <ArrowPathIcon className="h-12 w-12 animate-spin text-orange-500 mx-auto mb-4" />
                <p className="text-gray-600">Chargement des rôles...</p>
              </div>
            ) : roles.length === 0 ? (
              <div className="text-center py-12">
                <UserGroupIcon className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-900 mb-2">Aucun rôle</h3>
                <p className="text-gray-600">
                  {searchTerm ? 'Aucun rôle trouvé pour cette recherche' : 'Aucun rôle configuré'}
                </p>
                {(user?.role.code === "ADMIN" || user?.role.code === "DAF") && !searchTerm && (
                  <button 
                    onClick={() => openModal("role")} 
                    className="btn-primary mt-4"
                  >
                    <PlusIcon className="h-5 w-5 mr-2" />
                    Créer le premier rôle
                  </button>
                )}
              </div>
            ) : (
              <>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {paginatedRoles.map((role) => (
                  <div key={role.id} className="card hover:shadow-lg transition-shadow">
                    <div className="mb-4 flex flex-col sm:flex-row sm:items-start sm:justify-between gap-3">
                      <div className="min-w-0">
                        <h3 className="font-semibold text-gray-900 truncate">{role.libelle}</h3>
                        <p className="text-sm text-gray-500 font-mono truncate">{role.code}</p>
                      </div>

                      <div className="flex flex-col sm:items-end items-start gap-2 w-full sm:w-auto">
                        <span
                          className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                            role.isActive === false ? "bg-red-100 text-red-800" : "bg-green-100 text-green-800"
                          }`}
                          title={role.isActive === false ? "Rôle désactivé" : "Rôle actif"}
                        >
                          {role.isActive === false ? "Inactif" : "Actif"}
                        </span>

                        {(user?.role.code === "ADMIN" || user?.role.code === "DAF") && (
                          <div className="flex w-full sm:w-auto rounded-md shadow-sm border border-gray-200 overflow-hidden">
                            <button
                              type="button"
                              onClick={() => handleToggleRoleActif(role, true)}
                              disabled={roleOperationLoading || roleStatusUpdatingId === role.id}
                              className={`flex-1 sm:flex-none px-2.5 py-1 text-xs font-medium ${
                                role.isActive === false
                                  ? "bg-white text-gray-700 hover:bg-gray-50"
                                  : "bg-green-600 text-white"
                              }`}
                            >
                              Actif
                            </button>
                            <button
                              type="button"
                              onClick={() => handleToggleRoleActif(role, false)}
                              disabled={roleOperationLoading || roleStatusUpdatingId === role.id}
                              className={`flex-1 sm:flex-none px-2.5 py-1 text-xs font-medium ${
                                role.isActive === false
                                  ? "bg-red-600 text-white"
                                  : "bg-white text-gray-700 hover:bg-gray-50"
                              }`}
                            >
                              Inactif
                            </button>
                          </div>
                        )}
                      </div>
                    </div>

                    {role.description && (
                  <div className="mb-4">
                        <p className="text-sm text-gray-600">{role.description}</p>
                      </div>
                    )}

                    {(user?.role.code === "ADMIN" || user?.role.code === "DAF") && (
                      <div className="flex space-x-2 pt-4 border-t">
                        <button 
                          onClick={() => openModal("role", role)} 
                          className="flex-1 btn-primary text-sm py-2"
                          disabled={roleOperationLoading}
                        >
                          <PencilIcon className="h-4 w-4 mr-1" />
                          Modifier
                        </button>
                        <button 
                          onClick={() => openModal("delete-role", role)} 
                          className="flex-1 btn-danger text-sm py-2"
                          disabled={roleOperationLoading}
                        >
                          <TrashIcon className="h-4 w-4 mr-1" />
                          Supprimer
                        </button>
                      </div>
                    )}
                  </div>
                ))}
              </div>
              <ParametrageListPagination
                pageIndex={roleListPage}
                pageSize={PARAMETRAGE_LIST_PAGE_SIZE}
                total={orderedRoles.length}
                loading={rolesLoading}
                onPageChange={setRoleListPage}
              />
              </>
            )}
          </div>
        )}

        {/* Permissions (RBAC) — même cadre que les autres onglets */}
        {activeTab === "permissions" && (
          <ParametragesRbacPermissionsPanel
            roles={orderedRoles}
            rolesLoading={rolesLoading}
            rolesError={rolesError}
            onFonctionCountChange={setPermissionFonctionCount}
            matrixInitialRoleId={matrixInitialRoleId}
            onMatrixInitialRoleConsumed={consumeMatrixInitialRole}
            canManageRoles={user?.role.code === "ADMIN" || user?.role.code === "DAF"}
            onGoToCreateRole={() => {
              setActiveTab("roles")
              router.replace("/admin/parametrages?tab=roles", { scroll: false })
              openModal("role")
            }}
          />
        )}

        {/* Catalogues Tab */}
        {activeTab === "catalogues" && (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-lg font-semibold text-gray-900">Catalogues de Matières</h2>
                <p className="text-gray-600">Gestion des catalogues par niveau et année scolaire</p>
                {cataloguesLoading && <p className="text-sm text-blue-600">🔄 Chargement des données...</p>}
                {cataloguesError && <p className="text-sm text-red-600">❌ {cataloguesError}</p>}
              </div>
              {(user?.role.code === "ADMIN" || user?.role.code === "DAF") && (
                <div className="flex items-center space-x-2">
                  <button 
                    onClick={refreshCatalogues} 
                    className="btn-outline"
                    disabled={cataloguesLoading}
                    title="Actualiser la liste"
                  >
                    <ArrowPathIcon className="h-5 w-5 mr-2" />
                    Actualiser
                  </button>
                  <button 
                    onClick={() => openModal("catalogue")} 
                    className="btn-primary"
                    disabled={cataloguesLoading}
                  >
                    <PlusIcon className="h-5 w-5 mr-2" />
                    Nouveau Catalogue
                  </button>
                </div>
              )}
            </div>

            {/* Barre de recherche */}
            <div className="card">
              <div className="relative">
                <MagnifyingGlassIcon className="h-5 w-5 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                <input
                  type="text"
                  className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 w-full"
                  placeholder="Rechercher un catalogue..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  disabled={cataloguesLoading}
                />
              </div>
            </div>

            {/* Liste des catalogues */}
            {cataloguesLoading ? (
              <div className="text-center py-12">
                <ArrowPathIcon className="h-12 w-12 animate-spin text-orange-500 mx-auto mb-4" />
                <p className="text-gray-600">Chargement des catalogues...</p>
              </div>
            ) : flatFilteredCatalogues.length === 0 ? (
              <div className="text-center py-12">
                <BookOpenIcon className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-900 mb-2">Aucun catalogue</h3>
                <p className="text-gray-600">
                  {searchTerm ? 'Aucun catalogue trouvé pour cette recherche' : 'Aucun catalogue configuré'}
                </p>
                {(user?.role.code === "ADMIN" || user?.role.code === "DAF") && !searchTerm && (
                  <button 
                    onClick={() => openModal("catalogue")} 
                    className="btn-primary mt-4"
                  >
                    <PlusIcon className="h-5 w-5 mr-2" />
                      Créer le premier catalogue
                  </button>
                )}
              </div>
            ) : (
              <>
              <div className="space-y-8">
                {groupedCataloguesByYear.map(([yearLabel, yearCatalogues]) => (
                  <div key={yearLabel} className="space-y-4">
                    <div className="flex items-center justify-between border-b border-gray-200 pb-2">
                      <h3 className="text-base font-semibold text-gray-900">Année scolaire {yearLabel}</h3>
                      <span className="text-sm text-gray-500">{yearCatalogues.length} catalogue(s)</span>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                      {yearCatalogues.map((catalogue) => (
                  <div key={catalogue.id} className="bg-white border border-gray-200 rounded-lg p-6 hover:shadow-md transition-shadow">
                    {/* Header simple et pro */}
                    <div className="mb-4 flex flex-col sm:flex-row sm:items-start sm:justify-between gap-3">
                      <div className="min-w-0">
                        <h3 className="text-lg font-semibold text-gray-900 mb-1 truncate">{catalogue.libelle}</h3>
                        <p className="text-sm text-gray-500 font-mono truncate">{catalogue.code}</p>
                      </div>

                      <div className="flex flex-col sm:items-end items-start gap-2 w-full sm:w-auto">
                        <span
                          className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                            catalogue.active === false ? "bg-red-100 text-red-800" : "bg-green-100 text-green-800"
                          }`}
                          title={catalogue.active === false ? "Catalogue désactivé" : "Catalogue actif"}
                        >
                          {catalogue.active === false ? "Inactif" : "Actif"}
                        </span>

                        {(user?.role.code === "ADMIN" || user?.role.code === "DAF") && (
                          <div className="flex w-full sm:w-auto rounded-md shadow-sm border border-gray-200 overflow-hidden">
                            <button
                              type="button"
                              onClick={() => handleToggleCatalogueActif(catalogue, true)}
                              disabled={catalogueOperationLoading || catalogueStatusUpdatingId === catalogue.id}
                              className={`flex-1 sm:flex-none px-2.5 py-1 text-xs font-medium ${
                                catalogue.active === false
                                  ? "bg-white text-gray-700 hover:bg-gray-50"
                                  : "bg-green-600 text-white"
                              }`}
                            >
                              Actif
                            </button>
                            <button
                              type="button"
                              onClick={() => handleToggleCatalogueActif(catalogue, false)}
                              disabled={catalogueOperationLoading || catalogueStatusUpdatingId === catalogue.id}
                              className={`flex-1 sm:flex-none px-2.5 py-1 text-xs font-medium ${
                                catalogue.active === false
                                  ? "bg-red-600 text-white"
                                  : "bg-white text-gray-700 hover:bg-gray-50"
                              }`}
                            >
                              Inactif
                            </button>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Informations essentielles */}
                    <div className="space-y-3 mb-6">
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-gray-600">Année Scolaire</span>
                        <span className="text-sm font-medium text-gray-900">
                          {catalogue.anneeScolaireLibelle || catalogue.anneeScolaire?.libelle || 'Non définie'}
                        </span>
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-gray-600">Niveau Scolaire</span>
                        <span className="text-sm font-medium text-gray-900">
                          {catalogue.niveauScolaireLibelle || 'Non défini'}
                        </span>
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-gray-600">Matières</span>
                        <span className="text-sm font-medium text-gray-900">
                          {catalogue.nombreMatieres || catalogue.matieres?.length || 0}
                        </span>
                      </div>
                    </div>

                    {(user?.role.code === "ADMIN" || user?.role.code === "DAF") && (
                      <div className="flex space-x-2 mt-4 pt-4 border-t">
                        <button 
                          onClick={() => openModal("catalogue-detail", catalogue)} 
                          className="flex-1 btn-outline text-sm py-2"
                          disabled={catalogueOperationLoading}
                        >
                          <EyeIcon className="h-4 w-4 mr-1" />
                          Voir
                        </button>
                        <button 
                          onClick={() => openModal("catalogue", catalogue)} 
                          className="flex-1 btn-primary text-sm py-2"
                          disabled={catalogueOperationLoading}
                        >
                          <PencilIcon className="h-4 w-4 mr-1" />
                          Modifier
                        </button>
                        <button 
                          onClick={() => openModal("delete-catalogue", catalogue)} 
                          className="flex-1 btn-danger text-sm py-2"
                          disabled={catalogueOperationLoading}
                        >
                          <TrashIcon className="h-4 w-4 mr-1" />
                          Supprimer
                        </button>
                      </div>
                    )}
                  </div>
                ))}
                    </div>
                  </div>
                ))}
                    </div>
              <ParametrageListPagination
                pageIndex={catalogueListPage}
                pageSize={PARAMETRAGE_LIST_PAGE_SIZE}
                total={flatFilteredCatalogues.length}
                loading={cataloguesLoading}
                onPageChange={setCatalogueListPage}
              />
              </>
            )}
          </div>
        )}

        {/* Années Scolaires Tab */}
        {activeTab === "annees" && (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-lg font-semibold text-gray-900">Années Scolaires</h2>
                <p className="text-gray-600">Gestion des années académiques</p>
                {anneesLoading && <p className="text-sm text-blue-600">🔄 Chargement des données...</p>}
                {anneesError && <p className="text-sm text-red-600">❌ {anneesError}</p>}
              </div>
              {(user?.role.code === "ADMIN" || user?.role.code === "DAF") && (
                <div className="flex items-center space-x-2">
                  <button 
                    onClick={refreshAnneesScolaires} 
                    className="btn-outline"
                    disabled={anneesLoading}
                    title="Actualiser la liste"
                  >
                    <ArrowPathIcon className="h-5 w-5 mr-2" />
                    Actualiser
                  </button>
                  <button 
                    onClick={() => openModal("annee")} 
                    className="btn-primary"
                    disabled={anneesLoading}
                  >
                    <PlusIcon className="h-5 w-5 mr-2" />
                    Nouvelle Année
                  </button>
                </div>
              )}
            </div>

            {/* Barre de recherche */}
            <div className="card">
              <div className="relative">
                <MagnifyingGlassIcon className="h-5 w-5 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                <input
                  type="text"
                  className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 w-full"
                  placeholder="Rechercher une année scolaire..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  disabled={anneesLoading}
                />
              </div>
            </div>

            {/* Liste des années scolaires */}
            {anneesLoading ? (
              <div className="text-center py-12">
                <ArrowPathIcon className="h-12 w-12 animate-spin text-orange-500 mx-auto mb-4" />
                <p className="text-gray-600">Chargement des années scolaires...</p>
              </div>
            ) : filteredAnneesForList.length === 0 ? (
              <div className="text-center py-12">
                <CalendarIcon className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-900 mb-2">Aucune année scolaire</h3>
                <p className="text-gray-600">
                  {searchTerm ? 'Aucune année trouvée pour cette recherche' : 'Aucune année scolaire configurée'}
                </p>
                {(user?.role.code === "ADMIN" || user?.role.code === "DAF") && !searchTerm && (
                  <button 
                    onClick={() => openModal("annee")} 
                    className="btn-primary mt-4"
                  >
                    <PlusIcon className="h-5 w-5 mr-2" />
                    Créer la première année
                  </button>
                )}
              </div>
            ) : (
              <>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {paginatedAnneesScolaires.map((annee) => (
                  <div key={annee.id} className={`card hover:shadow-lg transition-shadow ${annee.estCourante ? 'ring-2 ring-blue-500' : ''}`}>
                    <div className="flex items-center mb-4">
                      <div className="w-12 h-12 rounded-lg flex items-center justify-center text-white font-bold bg-green-500">
                        {annee.code.substring(0, 2)}
                      </div>
                      <div className="ml-4 flex-1">
                        <h3 className="font-semibold text-gray-900">{annee.libelle}</h3>
                        <p className="text-sm text-gray-500 font-mono">{annee.code}</p>
                      </div>
                      <div className="text-right">
                        {annee.estCourante ? (
                          <span className="badge badge-success">
                            Année Courante
                          </span>
                        ) : (
                          <button
                            onClick={() => handleSetAnneeCourante(annee.id!)}
                            className="btn-outline text-xs py-1 px-2"
                          >
                            Définir Courante
                          </button>
                        )}
                      </div>
                    </div>

                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between items-center">
                        <span className="text-gray-600">Début:</span>
                        <span className="font-medium text-gray-900">
                          {new Date(annee.dateDebut).toLocaleDateString('fr-FR')}
                        </span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-gray-600">Fin:</span>
                        <span className="font-medium text-gray-900">
                          {new Date(annee.dateFin).toLocaleDateString('fr-FR')}
                        </span>
                      </div>
                    </div>

                    {(user?.role.code === "ADMIN" || user?.role.code === "DAF") && (
                      <div className="flex space-x-2 pt-4 border-t">
                        <button 
                          onClick={() => openModal("annee", annee)} 
                          className="flex-1 btn-primary text-sm py-2"
                          disabled={anneeOperationLoading}
                        >
                    <PencilIcon className="h-4 w-4 mr-1" />
                    Modifier
                  </button>
                        <button 
                          onClick={() => openModal("delete-annee", annee)} 
                          className="flex-1 btn-danger text-sm py-2"
                          disabled={anneeOperationLoading}
                        >
                          <TrashIcon className="h-4 w-4 mr-1" />
                          Supprimer
                  </button>
                      </div>
                    )}
                </div>
              ))}
            </div>
              <ParametrageListPagination
                pageIndex={anneeListPage}
                pageSize={PARAMETRAGE_LIST_PAGE_SIZE}
                total={filteredAnneesForList.length}
                loading={anneesLoading}
                onPageChange={setAnneeListPage}
              />
              </>
            )}
          </div>
        )}

        {/* Configuration Tab */}
        {activeTab === "config" && (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-lg font-semibold text-gray-900">Configuration Système</h2>
                <p className="text-gray-600">Paramètres globaux de DISMAS</p>
              </div>
              <button onClick={() => openModal("config")} className="btn-primary">
                <PlusIcon className="h-5 w-5 mr-2" />
                Nouveau Paramètre
              </button>
            </div>

            <div className="card">
              <div className="overflow-x-auto">
                <table className="table">
                  <thead>
                    <tr>
                      <th>Catégorie</th>
                      <th>Clé</th>
                      <th>Valeur</th>
                      <th>Type</th>
                      <th>Description</th>
                      <th>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {orderedConfig.map((config) => (
                      <tr key={config.id}>
                        <td>
                          <span
                            className={`badge ${
                              config.categorie === "GENERAL"
                                ? "badge-info"
                                : config.categorie === "STOCK"
                                  ? "badge-warning"
                                  : config.categorie === "WORKFLOW"
                                    ? "badge-success"
                                    : "badge-purple"
                            }`}
                          >
                            {config.categorie}
                          </span>
                        </td>
                        <td className="font-mono text-sm">{config.cle}</td>
                        <td>
                          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
                            {config.valeur}
                          </span>
                        </td>
                        <td>
                          <span className="badge badge-info">{config.type}</span>
                        </td>
                        <td className="text-sm text-gray-600 max-w-xs">{config.description}</td>
                        <td>
                          <button
                            onClick={() => openModal("config", config)}
                            className="text-orange-600 hover:text-orange-800"
                          >
                            <PencilIcon className="h-4 w-4" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* Modal Universel */}
        {showModal && (
          <div className="modal-overlay" onClick={closeModal}>
            <div className="modal-content max-w-4xl" onClick={(e) => e.stopPropagation()}>
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-semibold">
                  {modalType === "delete-matiere" || modalType === "delete-niveau" || modalType === "delete-role" || modalType === "delete-catalogue" || modalType === "delete-annee" ? "Supprimer" : (selectedItem ? (modalType === "catalogue-detail" ? "Détail du" : "Modifier") : "Nouveau")}{" "}
                  {modalType === "ouvrage"
                    ? "Ouvrage"
                    : modalType === "niveau"
                      ? "Niveau Scolaire"
                      : modalType === "delete-niveau"
                        ? "Niveau Scolaire"
                        : modalType === "matiere"
                          ? "Matière"
                          : modalType === "delete-matiere"
                            ? "Matière"
                            : modalType === "role"
                              ? "Rôle"
                              : modalType === "delete-role"
                                ? "Rôle"
                                : modalType === "catalogue" || modalType === "catalogue-detail"
                                  ? "Catalogue"
                                  : modalType === "delete-catalogue"
                                    ? "Catalogue"
                                    : modalType === "annee"
                                      ? "Année Scolaire"
                                      : modalType === "delete-annee"
                                        ? "Année Scolaire"
                                        : modalType === "structure"
                                          ? "Structure"
                                          : "Paramètre"}
                </h3>
                <button onClick={closeModal} className="text-gray-400 hover:text-gray-600">
                  ×
                </button>
              </div>


              {/* Formulaire Niveau Scolaire */}
              {modalType === "niveau" && (
                <form 
                  className="space-y-4"
                  onSubmit={async (e) => {
                    e.preventDefault()
                    const formData = new FormData(e.currentTarget)
                    if (selectedItem) {
                      await handleUpdateNiveau(formData)
                    } else {
                      await handleCreateNiveau(formData)
                    }
                  }}
                >
                  <div className="form-group">
                    <label className="form-label">Code *</label>
                    <input 
                      type="text" 
                      name="code"
                      className="input-field font-mono" 
                      defaultValue={selectedItem?.code || ""}
                      placeholder="Ex: CP1, CE1, CM2"
                      required 
                      disabled={isCreatingNiveau || isUpdatingNiveau}
                    />
                    <p className="text-xs text-gray-500 mt-1">Code unique pour identifier le niveau scolaire</p>
                  </div>
                  <div className="form-group">
                    <label className="form-label">Libellé *</label>
                    <input 
                      type="text" 
                      name="libelle"
                      className="input-field" 
                      defaultValue={selectedItem?.libelle || ""}
                      placeholder="Ex: Cours Préparatoire 1ère année"
                      required 
                      disabled={isCreatingNiveau || isUpdatingNiveau}
                    />
                  </div>
                  <div className="form-group">
                    <label className="form-label">Ordre *</label>
                    <input 
                      type="number" 
                      name="ordre"
                      className="input-field" 
                      defaultValue={selectedItem?.ordre || ""}
                      placeholder="Ex: 1 pour CP1, 2 pour CP2, etc."
                      min="1"
                      max="20"
                      required 
                      disabled={isCreatingNiveau || isUpdatingNiveau}
                    />
                    <p className="text-xs text-gray-500 mt-1">Ordre de progression dans la scolarité (1 = niveau le plus bas)</p>
                  </div>
                  <div className="flex justify-end space-x-3 pt-6 border-t">
                    <button 
                      type="button" 
                      onClick={closeModal} 
                      className="btn-outline"
                      disabled={isCreatingNiveau || isUpdatingNiveau}
                    >
                      Annuler
                    </button>
                    <button 
                      type="submit" 
                      className="btn-primary"
                      disabled={isCreatingNiveau || isUpdatingNiveau}
                    >
                      {isCreatingNiveau || isUpdatingNiveau ? (
                        <>
                          <ArrowPathIcon className="h-4 w-4 mr-2 animate-spin" />
                          {selectedItem ? "Modification..." : "Création..."}
                        </>
                      ) : (
                        selectedItem ? "Modifier" : "Créer"
                      )}
                    </button>
                  </div>
                </form>
              )}

              {/* Modal de confirmation de suppression niveau */}
              {modalType === "delete-niveau" && selectedItem && (
                <div className="space-y-4">
                  <div className="text-center">
                    <TrashIcon className="h-16 w-16 text-red-500 mx-auto mb-4" />
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">
                      Supprimer le niveau scolaire
                    </h3>
                    <p className="text-gray-600 mb-4">
                      Êtes-vous sûr de vouloir supprimer le niveau scolaire <strong>{selectedItem.libelle}</strong> ?
                    </p>
                    <p className="text-sm text-red-600">
                      Cette action est irréversible et peut affecter les manuels et distributions associés.
                    </p>
                  </div>
                  
                  <div className="flex justify-end space-x-3 pt-6 border-t">
                    <button 
                      type="button" 
                      onClick={closeModal} 
                      className="btn-outline"
                      disabled={isDeletingNiveau}
                    >
                      Annuler
                    </button>
                    <button 
                      onClick={handleDeleteNiveau}
                      className="btn-danger"
                      disabled={isDeletingNiveau}
                    >
                      {isDeletingNiveau ? (
                        <>
                          <ArrowPathIcon className="h-4 w-4 mr-2 animate-spin" />
                          Suppression...
                        </>
                      ) : (
                        <>
                          <TrashIcon className="h-4 w-4 mr-2" />
                          Supprimer
                        </>
                      )}
                    </button>
                  </div>
                </div>
              )}

              {/* Formulaire Rôle */}
              {modalType === "role" && (
                <form 
                  className="space-y-4"
                  onSubmit={async (e) => {
                    e.preventDefault()
                    const formData = new FormData(e.currentTarget)
                    if (selectedItem) {
                      await handleUpdateRole(formData)
                    } else {
                      await handleCreateRole(formData)
                    }
                  }}
                >
                  <div className="form-group">
                    <label className="form-label">Code *</label>
                    <input 
                      type="text" 
                      name="code"
                      className="input-field font-mono" 
                      defaultValue={selectedItem?.code || ""}
                      placeholder="Ex: ADMIN, DRENA, IEPP"
                      required 
                      disabled={isCreatingRole || isUpdatingRole}
                    />
                    <p className="text-xs text-gray-500 mt-1">Code unique pour identifier le rôle</p>
                  </div>
                  <div className="form-group">
                    <label className="form-label">Libellé *</label>
                    <input 
                      type="text" 
                      name="libelle"
                      className="input-field" 
                      defaultValue={selectedItem?.libelle || ""}
                      placeholder="Ex: Administrateur, Directeur Régional"
                      required 
                      disabled={isCreatingRole || isUpdatingRole}
                    />
                  </div>
                  {/* Niveau d'accès: masqué (non utilisé dans le contexte) */}
                  <div className="form-group">
                    <label className="form-label">Description</label>
                    <textarea 
                      name="description"
                      className="input-field" 
                      rows={3}
                      defaultValue={selectedItem?.description || ""}
                      placeholder="Description du rôle et de ses responsabilités (optionnel)"
                      disabled={isCreatingRole || isUpdatingRole}
                    ></textarea>
                  </div>
                  <div className="flex justify-end space-x-3 pt-6 border-t">
                    <button 
                      type="button" 
                      onClick={closeModal} 
                      className="btn-outline"
                      disabled={isCreatingRole || isUpdatingRole}
                    >
                      Annuler
                    </button>
                    <button 
                      type="submit" 
                      className="btn-primary"
                      disabled={isCreatingRole || isUpdatingRole}
                    >
                      {isCreatingRole || isUpdatingRole ? (
                        <>
                          <ArrowPathIcon className="h-4 w-4 mr-2 animate-spin" />
                          {selectedItem ? "Modification..." : "Création..."}
                        </>
                      ) : (
                        selectedItem ? "Modifier" : "Créer"
                      )}
                    </button>
                  </div>
                </form>
              )}

              {/* Modal de confirmation de suppression rôle */}
              {modalType === "delete-role" && selectedItem && (
                <div className="space-y-4">
                  <div className="text-center">
                    <TrashIcon className="h-16 w-16 text-red-500 mx-auto mb-4" />
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">
                      Supprimer le rôle
                    </h3>
                    <p className="text-gray-600 mb-4">
                      Êtes-vous sûr de vouloir supprimer le rôle <strong>{selectedItem.libelle}</strong> ?
                    </p>
                    <p className="text-sm text-red-600">
                      Cette action est irréversible et peut affecter les utilisateurs associés à ce rôle.
                    </p>
                  </div>
                  
                  <div className="flex justify-end space-x-3 pt-6 border-t">
                    <button 
                      type="button" 
                      onClick={closeModal} 
                      className="btn-outline"
                      disabled={isDeletingRole}
                    >
                      Annuler
                    </button>
                    <button 
                      onClick={handleDeleteRole}
                      className="btn-danger"
                      disabled={isDeletingRole}
                    >
                      {isDeletingRole ? (
                        <>
                          <ArrowPathIcon className="h-4 w-4 mr-2 animate-spin" />
                          Suppression...
                        </>
                      ) : (
                        <>
                          <TrashIcon className="h-4 w-4 mr-2" />
                          Supprimer
                        </>
                      )}
                    </button>
                  </div>
                </div>
              )}

              {/* Modal de détail du catalogue */}
              {modalType === "catalogue-detail" && selectedItem && (
                <div className="space-y-6">
                  {/* Informations principales */}
                  <div className="bg-white border border-gray-200 rounded-lg p-6">
                    <div className="mb-6">
                      <h4 className="text-xl font-semibold text-gray-900 mb-2">{selectedItem.libelle}</h4>
                      <p className="text-sm text-gray-500 font-mono">{selectedItem.code}</p>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                        <label className="text-sm font-medium text-gray-600">Année Scolaire</label>
                        <p className="text-lg text-gray-900 mt-1">
                          {selectedItem.anneeScolaireLibelle || selectedItem.anneeScolaire?.libelle || 'Non définie'}
                        </p>
                      </div>
                      
                      <div>
                        <label className="text-sm font-medium text-gray-600">Niveau Scolaire</label>
                        <p className="text-lg text-gray-900 mt-1">
                          {selectedItem.niveauScolaireLibelle || 'Non défini'}
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* Liste des matières associées */}
                  <div className="bg-white border border-gray-200 rounded-lg p-6">
                    <div className="flex items-center justify-between mb-4">
                      <h5 className="text-lg font-semibold text-gray-900">Matières associées</h5>
                      {!matieresAssocieesLoading && (
                        <span className="px-3 py-1 bg-blue-100 text-blue-700 text-sm rounded-full font-medium">
                          {matieresAssociees.length} matière(s)
                        </span>
                      )}
                    </div>

                    {matieresAssocieesLoading ? (
                      <div className="flex items-center justify-center py-8">
                        <ArrowPathIcon className="h-6 w-6 animate-spin text-blue-500 mr-2" />
                        <span className="text-sm text-gray-600">Chargement des matières...</span>
                      </div>
                    ) : matieresAssociees.length > 0 ? (
                      <div className="space-y-3">
                        {matieresAssociees.map((catalogueMatiere, index) => (
                          <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                            <div className="flex items-center">
                              <div className="w-8 h-8 bg-blue-100 text-blue-700 rounded-full flex items-center justify-center text-sm font-medium mr-3">
                                {index + 1}
                              </div>
                              <div>
                                <p className="font-medium text-gray-900">
                                  {catalogueMatiere.matiereLibelle || catalogueMatiere.matiere?.libelle || 'Matière inconnue'}
                                </p>
                                <p className="text-sm text-gray-500">
                                  Code: {catalogueMatiere.matiereCode || catalogueMatiere.matiere?.code || 'N/A'}
                                </p>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="text-center py-8">
                        <DocumentTextIcon className="h-12 w-12 text-gray-300 mx-auto mb-3" />
                        <p className="text-gray-500">Aucune matière associée à ce catalogue</p>
                      </div>
                    )}
                  </div>

                  {/* Actions */}
                  <div className="flex justify-end space-x-3 pt-6 border-t border-gray-200">
                    <button 
                      type="button" 
                      onClick={closeModal} 
                      className="flex items-center px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-md transition-colors"
                      title="Fermer"
                    >
                      <XMarkIcon className="h-4 w-4 mr-2" />
                      Fermer
                    </button>
                    {(user?.role.code === "ADMIN" || user?.role.code === "DAF") && (
                      <button 
                        onClick={() => {
                          closeModal()
                          setTimeout(() => openModal("catalogue", selectedItem), 100)
                        }}
                        className="flex items-center px-4 py-2 text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 rounded-md transition-colors"
                        title="Modifier le catalogue"
                      >
                        <PencilIcon className="h-4 w-4 mr-2" />
                        Modifier
                      </button>
                    )}
                  </div>
                </div>
              )}

              {/* Formulaire Catalogue */}
              {modalType === "catalogue" && (
                <form 
                  className="space-y-4"
                  onSubmit={async (e) => {
                    e.preventDefault()
                    const formData = new FormData(e.currentTarget)
                    const niveauId = parseInt(formData.get('niveauScolaireId') as string)
                    const anneeId = catalogueAnneeId ? parseInt(catalogueAnneeId) : parseInt(formData.get('anneeScolaireId') as string)

                    // Génération automatique du code pour les créations.
                    // Pour une mise à jour, on conserve le code existant.
                    let code = selectedItem?.code as string | undefined
                    if (!selectedItem) {
                      const niveau = niveauxScolaires.find((n) => n.id === niveauId)
                      const annee = anneesScolaires.find((a) => a.id === anneeId)
                      const niveauCode = (niveau?.code || 'CAT').toUpperCase()
                      const anneeCode = (annee?.code || annee?.libelle || 'ANNEE').toString().toUpperCase().replace(/\s+/g, '')
                      code = `CAT-${niveauCode}-${anneeCode}`
                    }

                    const catalogueData = {
                      code: code || "",
                      libelle: formData.get('libelle') as string,
                      niveauScolaireId: niveauId,
                      anneeScolaireId: anneeId,
                      matiereIds: Array.from(formData.getAll('matiereIds')).map(id => parseInt(id as string)),
                      active: catalogueActif
                    }
                    if (selectedItem) {
                      await handleUpdateCatalogue(catalogueData)
                    } else {
                      await handleCreateCatalogue(catalogueData)
                    }
                  }}
                >
                  <div className="form-group">
                    <label className="form-label">Code *</label>
                    <input 
                      type="text" 
                      name="code"
                      className="input-field font-mono" 
                      defaultValue={selectedItem?.code || ""}
                      placeholder="Généré automatiquement (ex: CAT-CP1-2024-2025)"
                      required 
                      disabled
                    />
                    <p className="text-xs text-gray-500 mt-1">Code unique pour identifier le catalogue</p>
                  </div>
                  <div className="form-group">
                    <label className="form-label">Libellé *</label>
                    <input 
                      type="text" 
                      name="libelle"
                      className="input-field" 
                      defaultValue={selectedItem?.libelle || ""}
                      placeholder="Ex: Catalogue CP1 2024-2025"
                      required 
                      disabled={isCreatingCatalogue || isUpdatingCatalogue}
                    />
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="form-group">
                      <label className="form-label">Niveau Scolaire *</label>
                      <select 
                        name="niveauScolaireId"
                        className="input-field" 
                        defaultValue={selectedItem ? String(selectedItem.niveauScolaireId) : ""}
                        required 
                        disabled={isCreatingCatalogue || isUpdatingCatalogue}
                      >
                        <option value="">Sélectionner un niveau</option>
                        {niveauxScolaires.map((niveau) => (
                          <option key={niveau.id} value={String(niveau.id)}>
                            {niveau.libelle} ({niveau.code})
                          </option>
                        ))}
                      </select>
                    </div>
                    <div className="form-group">
                      <label className="form-label">Année Scolaire *</label>
                      <select 
                        name="anneeScolaireId"
                        className="input-field" 
                        value={catalogueAnneeId}
                        onChange={(e) => {
                          const value = e.target.value
                          setCatalogueAnneeId(value)
                          const isCurrent =
                            currentCatalogueAnnee && value === String(currentCatalogueAnnee.id)
                          if (!isCurrent && catalogueActif) {
                            toast.error(
                              "Seuls les catalogues de l'année scolaire courante peuvent être actifs."
                            )
                            setCatalogueActif(false)
                          }
                        }}
                        required 
                        disabled={isCreatingCatalogue || isUpdatingCatalogue}
                      >
                        <option value="">Sélectionner une année</option>
                        {anneesScolaires.map((annee) => (
                          <option key={annee.id} value={String(annee.id)}>
                            {annee.code}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>
                  <div className="form-group">
                    <label className="flex items-center space-x-3">
                      <input 
                        type="checkbox" 
                        name="active"
                          checked={catalogueActif}
                          onChange={(e) => {
                            const checked = e.target.checked
                            const isCurrent =
                              currentCatalogueAnnee &&
                              catalogueAnneeId === String(currentCatalogueAnnee.id)
                            if (checked && !isCurrent) {
                              toast.error(
                                "Impossible d'activer un catalogue pour une année non courante."
                              )
                              setCatalogueActif(false)
                              return
                            }
                            setCatalogueActif(checked)
                          }}
                        className="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 rounded focus:ring-blue-500"
                        disabled={isCreatingCatalogue || isUpdatingCatalogue}
                      />
                      <span className="form-label mb-0">Catalogue actif</span>
                    </label>
                    {/* <p className="text-xs text-gray-500 mt-1">Un catalogue actif peut être utilisé pour les réceptions</p> */}
                  </div>
                  <div className="form-group">
                    <label className="form-label">Matières à inclure</label>
                    {matieresAssocieesLoading ? (
                      <div className="flex items-center justify-center py-8 bg-gray-50 rounded-lg border border-gray-200">
                        <ArrowPathIcon className="h-5 w-5 animate-spin text-blue-500 mr-2" />
                        <span className="text-sm text-gray-600">Chargement des matières associées...</span>
                      </div>
                    ) : (
                      <div className="bg-gray-50 rounded-lg border border-gray-200 p-4">
                        <div className="mb-3">
                          <p className="text-sm text-gray-600">
                            Sélectionnez les matières à inclure dans ce catalogue
                            {!matieresAssocieesLoading && matieresAssociees.length > 0 && (
                              <span className="ml-2 px-2 py-1 bg-green-100 text-green-700 text-xs rounded-full">
                                {matieresAssociees.length} associée(s)
                              </span>
                            )}
                          </p>
                        </div>
                        <div className="max-h-60 overflow-y-auto space-y-2">
                          {matieres
                            // Pour la création/édition de catalogue, n'afficher que les matières actives
                            .filter((matiere) => matiere.isActif !== false)
                            .map((matiere) => {
                            // Vérifier si cette matière est associée au catalogue
                            const isAssociated = matieresAssociees.some(
                              (catalogueMatiere) => {
                                // Essayer différentes propriétés pour la comparaison
                                return catalogueMatiere.matiereId === matiere.id || 
                                       catalogueMatiere.matiere?.id === matiere.id ||
                                       (catalogueMatiere.matiereId && matiere.id && catalogueMatiere.matiereId.toString() === matiere.id.toString())
                              }
                            )
                            
                            return (
                              <label key={matiere.id} className="flex items-center p-3 bg-white rounded-lg border border-gray-200 hover:bg-gray-50 cursor-pointer transition-colors">
                                <input
                                  type="checkbox"
                                  name="matiereIds"
                                  value={matiere.id}
                                  defaultChecked={isAssociated}
                                  className="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 rounded focus:ring-blue-500"
                                  disabled={isCreatingCatalogue || isUpdatingCatalogue}
                                />
                    <div className="ml-3 flex-1">
                      <p className="text-sm font-medium text-gray-900">{matiere.libelle}</p>
                      <p className="text-xs text-gray-500">Code: {matiere.code}</p>
                    </div>
                                {isAssociated && (
                                  <span className="px-2 py-1 bg-green-100 text-green-700 text-xs rounded-full font-medium">
                                    Associée
                                  </span>
                                )}
                              </label>
                            )
                          })}
                        </div>
                      </div>
                    )}
                  </div>
                  <div className="flex justify-end space-x-3 pt-6 border-t border-gray-200">
                    <button 
                      type="button" 
                      onClick={closeModal} 
                      className="flex items-center px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-md transition-colors"
                      disabled={isCreatingCatalogue || isUpdatingCatalogue}
                      title="Annuler"
                    >
                      <XMarkIcon className="h-4 w-4 mr-2" />
                      Annuler
                    </button>
                    <button 
                      type="submit" 
                      className="flex items-center px-4 py-2 text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 rounded-md transition-colors disabled:opacity-50"
                      disabled={isCreatingCatalogue || isUpdatingCatalogue}
                      title={selectedItem ? "Modifier le catalogue" : "Créer le catalogue"}
                    >
                      {isCreatingCatalogue || isUpdatingCatalogue ? (
                        <>
                          <ArrowPathIcon className="h-4 w-4 mr-2 animate-spin" />
                          {selectedItem ? "Modification..." : "Création..."}
                        </>
                      ) : (
                        <>
                          <CheckIcon className="h-4 w-4 mr-2" />
                          {selectedItem ? "Modifier" : "Créer"}
                        </>
                      )}
                    </button>
                  </div>
                </form>
              )}

              {/* Modal de confirmation de suppression catalogue */}
              {modalType === "delete-catalogue" && selectedItem && (
                <div className="space-y-4">
                  <div className="text-center">
                    <TrashIcon className="h-16 w-16 text-red-500 mx-auto mb-4" />
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">
                      Supprimer le catalogue
                    </h3>
                    <p className="text-gray-600 mb-4">
                      Êtes-vous sûr de vouloir supprimer le catalogue <strong>{selectedItem.libelle}</strong> ?
                    </p>
                    <p className="text-sm text-red-600">
                      Cette action est irréversible et peut affecter les manuels associés.
                    </p>
                  </div>
                  
                  <div className="flex justify-end space-x-3 pt-6 border-t border-gray-200">
                    <button 
                      type="button" 
                      onClick={closeModal} 
                      className="flex items-center px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-md transition-colors"
                      disabled={isDeletingCatalogue}
                      title="Annuler"
                    >
                      <XMarkIcon className="h-4 w-4 mr-2" />
                      Annuler
                    </button>
                    <button 
                      onClick={handleDeleteCatalogue}
                      className="flex items-center px-4 py-2 text-sm font-medium text-white bg-red-600 hover:bg-red-700 rounded-md transition-colors disabled:opacity-50"
                      disabled={isDeletingCatalogue}
                      title="Supprimer le catalogue"
                    >
                      {isDeletingCatalogue ? (
                        <>
                          <ArrowPathIcon className="h-4 w-4 mr-2 animate-spin" />
                          Suppression...
                        </>
                      ) : (
                        <>
                          <TrashIcon className="h-4 w-4 mr-2" />
                          Supprimer
                        </>
                      )}
                    </button>
                  </div>
                </div>
              )}

              {/* Formulaire Année Scolaire */}
              {modalType === "annee" && (
                <form 
                  className="space-y-4"
                  onSubmit={async (e) => {
                    e.preventDefault()
                    const formData = new FormData(e.currentTarget)
                    const anneeData = {
                      code: formData.get('code') as string,
                      libelle: formData.get('libelle') as string,
                      dateDebut: formData.get('dateDebut') as string,
                      dateFin: formData.get('dateFin') as string,
                      estCourante: formData.get('estCourante') === 'true'
                    }
                    if (selectedItem) {
                      await handleUpdateAnneeScolaire(anneeData)
                    } else {
                      await handleCreateAnneeScolaire(anneeData)
                    }
                  }}
                >
                  <div className="form-group">
                    <label className="form-label">Code *</label>
                    <input 
                      type="text" 
                      name="code"
                      className="input-field font-mono" 
                      defaultValue={selectedItem?.code || ""}
                      placeholder="Ex: 2024-2025"
                      required 
                      disabled={isCreatingAnnee || isUpdatingAnnee}
                    />
                    <p className="text-xs text-gray-500 mt-1">Code unique pour identifier l'année scolaire</p>
                  </div>
                  <div className="form-group">
                    <label className="form-label">Libellé *</label>
                    <input 
                      type="text" 
                      name="libelle"
                      className="input-field" 
                      defaultValue={selectedItem?.libelle || ""}
                      placeholder="Ex: Année Scolaire 2024-2025"
                      required 
                      disabled={isCreatingAnnee || isUpdatingAnnee}
                    />
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="form-group">
                      <label className="form-label">Date de Début *</label>
                      <input 
                        type="date" 
                        name="dateDebut"
                        className="input-field" 
                        defaultValue={selectedItem?.dateDebut ? new Date(selectedItem.dateDebut).toISOString().split('T')[0] : ""}
                        required 
                        disabled={isCreatingAnnee || isUpdatingAnnee}
                      />
                    </div>
                    <div className="form-group">
                      <label className="form-label">Date de Fin *</label>
                      <input 
                        type="date" 
                        name="dateFin"
                        className="input-field" 
                        defaultValue={selectedItem?.dateFin ? new Date(selectedItem.dateFin).toISOString().split('T')[0] : ""}
                        required 
                        disabled={isCreatingAnnee || isUpdatingAnnee}
                      />
                    </div>
                  </div>
                  <div className="form-group">
                    <label className="form-label">Statut</label>
                    <div className="flex items-center space-x-4">
                      <label className="flex items-center">
                        <input
                          type="radio"
                          name="estCourante"
                          value="true"
                          defaultChecked={selectedItem?.estCourante === true}
                          className="mr-2 text-blue-600 focus:ring-blue-500"
                          disabled={isCreatingAnnee || isUpdatingAnnee}
                        />
                        <span className="text-blue-600 font-medium">Année Courante</span>
                      </label>
                      <label className="flex items-center">
                        <input
                          type="radio"
                          name="estCourante"
                          value="false"
                          defaultChecked={selectedItem?.estCourante !== true}
                          className="mr-2 text-gray-600 focus:ring-gray-500"
                          disabled={isCreatingAnnee || isUpdatingAnnee}
                        />
                        <span className="text-gray-600 font-medium">Année Archivée</span>
                      </label>
                    </div>
                    <p className="text-xs text-gray-500 mt-1">Une seule année peut être courante à la fois</p>
                  </div>
                  <div className="flex justify-end space-x-3 pt-6 border-t">
                    <button 
                      type="button" 
                      onClick={closeModal} 
                      className="btn-outline"
                      disabled={isCreatingAnnee || isUpdatingAnnee}
                    >
                      Annuler
                    </button>
                    <button 
                      type="submit" 
                      className="btn-primary"
                      disabled={isCreatingAnnee || isUpdatingAnnee}
                    >
                      {isCreatingAnnee || isUpdatingAnnee ? (
                        <>
                          <ArrowPathIcon className="h-4 w-4 mr-2 animate-spin" />
                          {selectedItem ? "Modification..." : "Création..."}
                        </>
                      ) : (
                        selectedItem ? "Modifier" : "Créer"
                      )}
                    </button>
                  </div>
                </form>
              )}

              {/* Modal de confirmation de suppression année scolaire */}
              {modalType === "delete-annee" && selectedItem && (
                <div className="space-y-4">
                  <div className="text-center">
                    <TrashIcon className="h-16 w-16 text-red-500 mx-auto mb-4" />
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">
                      Supprimer l'année scolaire
                    </h3>
                    <p className="text-gray-600 mb-4">
                      Êtes-vous sûr de vouloir supprimer l'année scolaire <strong>{selectedItem.libelle}</strong> ?
                    </p>
                    <p className="text-sm text-red-600">
                      Cette action est irréversible et peut affecter les catalogues associés.
                    </p>
                  </div>
                  
                  <div className="flex justify-end space-x-3 pt-6 border-t">
                    <button 
                      type="button" 
                      onClick={closeModal} 
                      className="btn-outline"
                      disabled={isDeletingAnnee}
                    >
                      Annuler
                    </button>
                    <button 
                      onClick={handleDeleteAnneeScolaire}
                      className="btn-danger"
                      disabled={isDeletingAnnee}
                    >
                      {isDeletingAnnee ? (
                        <>
                          <ArrowPathIcon className="h-4 w-4 mr-2 animate-spin" />
                          Suppression...
                        </>
                      ) : (
                        <>
                          <TrashIcon className="h-4 w-4 mr-2" />
                          Supprimer
                        </>
                      )}
                    </button>
                  </div>
                </div>
              )}

              {/* Formulaire Matière */}
              {modalType === "matiere" && (
                <form 
                  className="space-y-4"
                  onSubmit={async (e) => {
                    e.preventDefault()
                    const formData = new FormData(e.currentTarget)
                    if (selectedItem) {
                      await handleUpdateMatiere(formData)
                    } else {
                      await handleCreateMatiere(formData)
                    }
                  }}
                >
                  <div className="form-group">
                    <label className="form-label">Code *</label>
                    <input 
                      type="text" 
                      name="code"
                      className="input-field font-mono" 
                      defaultValue={selectedItem?.code || ""}
                      placeholder="Généré automatiquement à partir du libellé"
                      required 
                      disabled
                    />
                    <p className="text-xs text-gray-500 mt-1">
                      Le code est généré automatiquement à partir du libellé.
                    </p>
                  </div>
                  <div className="form-group">
                    <label className="form-label">Libellé *</label>
                    <input 
                      type="text" 
                      name="libelle"
                      className="input-field" 
                      defaultValue={selectedItem?.libelle || ""}
                      placeholder="Ex: Mathématiques, Français, Physique"
                      required 
                      disabled={isCreatingMatiere || isUpdatingMatiere}
                    />
                  </div>
                  <div className="form-group">
                    <label className="form-label">Description</label>
                    <textarea 
                      name="description"
                      className="input-field" 
                      rows={3}
                      defaultValue={selectedItem?.description || ""}
                      placeholder="Description de l'ouvrage (optionnel)"
                      disabled={isCreatingMatiere || isUpdatingMatiere}
                    ></textarea>
                  </div>
                  <div className="form-group">
                    <label className="form-label">Statut</label>
                    <div className="flex items-center space-x-4">
                      <label className="flex items-center">
                        <input
                          type="radio"
                          name="isActif"
                          value="true"
                          defaultChecked={selectedItem?.isActif !== false}
                          className="mr-2 text-green-600 focus:ring-green-500"
                          disabled={isCreatingMatiere || isUpdatingMatiere}
                        />
                        <span className="text-green-600 font-medium">Active</span>
                      </label>
                      <label className="flex items-center">
                        <input
                          type="radio"
                          name="isActif"
                          value="false"
                          defaultChecked={selectedItem?.isActif === false}
                          className="mr-2 text-red-600 focus:ring-red-500"
                          disabled={isCreatingMatiere || isUpdatingMatiere}
                        />
                        <span className="text-red-600 font-medium">Inactive</span>
                      </label>
                    </div>
                    <p className="text-xs text-gray-500 mt-1">Un ouvrage inactive ne sera pas disponible pour les manuels</p>
                  </div>
                  <div className="flex justify-end space-x-3 pt-6 border-t">
                    <button 
                      type="button" 
                      onClick={closeModal} 
                      className="btn-outline"
                      disabled={isCreatingMatiere || isUpdatingMatiere}
                    >
                      Annuler
                    </button>
                    <button 
                      type="submit" 
                      className="btn-primary"
                      disabled={isCreatingMatiere || isUpdatingMatiere}
                    >
                      {isCreatingMatiere || isUpdatingMatiere ? (
                        <>
                          <ArrowPathIcon className="h-4 w-4 mr-2 animate-spin" />
                          {selectedItem ? "Modification..." : "Création..."}
                        </>
                      ) : (
                        selectedItem ? "Modifier" : "Créer"
                      )}
                    </button>
                  </div>
                </form>
              )}

              {/* Modal de confirmation de suppression */}
              {modalType === "delete-matiere" && selectedItem && (
                <div className="space-y-4">
                  <div className="text-center">
                    <TrashIcon className="h-16 w-16 text-red-500 mx-auto mb-4" />
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">
                      Supprimer l'ouvrage
                    </h3>
                    <p className="text-gray-600 mb-4">
                      Êtes-vous sûr de vouloir supprimer l'ouvrage <strong>{selectedItem.libelle}</strong> ?
                    </p>
                    <p className="text-sm text-red-600">
                      Cette action est irréversible et peut affecter les manuels associés.
                    </p>
                  </div>
                  
                  <div className="flex justify-end space-x-3 pt-6 border-t">
                    <button 
                      type="button" 
                      onClick={closeModal} 
                      className="btn-outline"
                      disabled={isDeletingMatiere}
                    >
                      Annuler
                    </button>
                    <button 
                      onClick={handleDeleteMatiere}
                      className="btn-danger"
                      disabled={isDeletingMatiere}
                    >
                      {isDeletingMatiere ? (
                        <>
                          <ArrowPathIcon className="h-4 w-4 mr-2 animate-spin" />
                          Suppression...
                        </>
                      ) : (
                        <>
                          <TrashIcon className="h-4 w-4 mr-2" />
                          Supprimer
                        </>
                      )}
                    </button>
                  </div>
                </div>
              )}

              {/* Autres formulaires simplifiés */}
              {modalType !== "matiere" && modalType !== "delete-matiere" && modalType !== "niveau" && modalType !== "delete-niveau" && modalType !== "role" && modalType !== "delete-role" && modalType !== "catalogue" && modalType !== "catalogue-detail" && modalType !== "delete-catalogue" && modalType !== "annee" && modalType !== "delete-annee" && (
                <form className="space-y-4">
                  <div className="form-group">
                    <label className="form-label">Code *</label>
                    <input type="text" className="input-field font-mono" required />
                  </div>
                  <div className="form-group">
                    <label className="form-label">Libellé *</label>
                    <input type="text" className="input-field" required />
                  </div>
                  <div className="form-group">
                    <label className="form-label">Description</label>
                    <textarea className="input-field" rows={3}></textarea>
                  </div>
                  <div className="flex justify-end space-x-3 pt-6 border-t">
                    <button type="button" onClick={closeModal} className="btn-outline">
                      Annuler
                    </button>
                    <button type="submit" className="btn-primary">
                      {selectedItem ? "Modifier" : "Créer"}
                    </button>
                  </div>
                </form>
              )}
            </div>
          </div>
        )}
      </div>
    </MainLayout>
  )
}

export default function ParametragesPage() {
  return (
    <Suspense
      fallback={
        <MainLayout>
          <div className="flex min-h-[40vh] items-center justify-center text-gray-600">
            Chargement des paramétrages…
          </div>
        </MainLayout>
      }
    >
      <ParametragesPageContent />
    </Suspense>
  )
}
