"use client"

import { logger } from '@/lib/utils/logger'

import { useState, useEffect, useRef } from "react"
import MainLayout from "../../components/layout/main-layout"
import { useAuth } from "../providers"
import {
  PlusIcon,
  ArrowsRightLeftIcon,
  CheckCircleIcon,
  ClockIcon,
  XCircleIcon,
  ExclamationTriangleIcon,
} from "@heroicons/react/24/outline"
import { regulationService, type RegulationDto, isRegulationMultiLevelEnabled } from "@/lib/services/regulation.service"
import { regulationV2Service, type RegulationV2PendingRow } from "@/lib/services/regulation-v2.service"
import { formatRegulationReferenceForDisplay } from "@/lib/regulation-display"
import RegulationV2IeppDemandeModal from "@/components/modals/RegulationV2IeppDemandeModal"
import { dashboardService } from "@/lib/services/dashboard.service"
import { structuresService, type Iepp } from "@/lib/services/structures.service"
import type { AnneeScolaire } from "@/lib/types/entities"
import { useAnneesScolaires } from "@/hooks/use-annees-scolaires"
import ProgrammerRegulationModal from "@/components/modals/ProgrammerRegulationModal"
import ValiderRegulationModal from "@/components/modals/ValiderRegulationModal"
import DetailsRegulationModal from "@/components/modals/DetailsRegulationModal"
import RedistribuerStockModal from "@/components/modals/RedistribuerStockModal"
import RedistribuerStockModalV2 from "@/components/modals/RedistribuerStockModalV2"
import RedistribuerHubStockModalV2 from "@/components/modals/RedistribuerHubStockModalV2"
import { toast } from "sonner"
import type { ApiResponse } from "@/lib/types/api"
import { regulationTierActionBlockedReason } from "@/lib/utils/regulation-valider-eligibility"
import { getApiErrorMessage } from "@/lib/utils/api-error-message"
import { canAccessRegulationPage } from "@/lib/utils/functionality-permissions"

/** Extrait les IEPP de la réponse `POST /dashboard/drena/activites` (items[] ou item, camelCase / snake_case). */
function extractIeppChoicesFromDrenaActivitesPayload(r: ApiResponse<unknown>): Array<{
  ieppId: number
  ieppCode: string
  ieppLibelle: string
}> {
  const out: Array<{ ieppId: number; ieppCode: string; ieppLibelle: string }> = []
  const seen = new Set<number>()
  const rawItems = r.items as unknown
  const rows: unknown[] = Array.isArray(rawItems) ? rawItems : rawItems != null ? [rawItems] : []
  const itemSingular = (r as { item?: unknown }).item
  if (rows.length === 0 && itemSingular != null) rows.push(itemSingular)

  for (const row of rows) {
    if (row == null || typeof row !== "object") continue
    const o = row as Record<string, unknown>
    let iepps = o.iepps
    if (!Array.isArray(iepps) && Array.isArray(o.iepp_list)) iepps = o.iepp_list
    if (!Array.isArray(iepps)) continue
    for (const raw of iepps) {
      if (raw == null || typeof raw !== "object") continue
      const x = raw as Record<string, unknown>
      const id = Number(x.ieppId ?? x.iepp_id)
      if (!Number.isFinite(id) || id <= 0) continue
      if (seen.has(id)) continue
      seen.add(id)
      out.push({
        ieppId: id,
        ieppCode: String(x.ieppCode ?? x.iepp_code ?? ""),
        ieppLibelle: String(x.ieppLibelle ?? x.iepp_libelle ?? ""),
      })
    }
  }
  return out
}

// Types pour les listes EPP excédentaires / déficitaires (réponses API)
type EppExcedentaireItem = {
  eppId: number
  eppCode: string
  eppLibelle: string
  combinaisonsExcedentaires: Array<{
    matiereId: number
    matiereCode: string
    matiereLibelle: string
    niveauId: number
    niveauCode: string
    niveauLibelle: string
    effectifClasse: number
    quantiteRecueTotale: number
    excedent: number
  }>
  nombreCombinaisons: number
  totalExcedentaire: number
}

type EppDeficitaireItem = {
  eppId: number
  eppCode: string
  eppLibelle: string
  combinaisonsDeficitaires: Array<{
    matiereId: number
    matiereCode: string
    matiereLibelle: string
    niveauId: number
    niveauCode: string
    niveauLibelle: string
    effectifClasse: number
    quantiteRecueTotale: number
    deficit: number
  }>
  nombreCombinaisons: number
}

/** Agrégat DRENA : IEPP avec liste d’EPP (excédent / déficit) — même principe que l’IEPP qui liste les EPP */
type IeppAggRowExcedent = {
  ieppId: number
  ieppCode: string
  ieppLibelle: string
  eppExcedentaires: EppExcedentaireItem[]
}

type IeppAggRowDeficit = {
  ieppId: number
  ieppCode: string
  ieppLibelle: string
  eppDeficitaires: EppDeficitaireItem[]
}

// Données mockées des régulations (désactivées - sera remplacé par vraies données)
const mockRegulations_DISABLED = [
  {
    id: 1,
    reference: "REG-2024-001",
    type_regulation: "INTERNE",
    structure_source: {
      code: "EPP-COC-01",
      libelle: "EPP Cocody Centre",
      type: "EPP",
    },
    structure_destination: {
      code: "EPP-YOP-01",
      libelle: "EPP Yopougon Maroc",
      type: "EPP",
    },
    drena_source: {
      code: "DRENA-ABJ",
      libelle: "DRENA Abidjan",
    },
    drena_destination: {
      code: "DRENA-ABJ",
      libelle: "DRENA Abidjan",
    },
    motif: "Excédent de manuels CP1 à Cocody, déficit à Yopougon",
    statut: "APPROUVEE",
    date_demande: "2024-10-25",
    date_approbation: "2024-10-26",
    demande_par: "KOUADIO Adjoua",
    approuve_par: "ASSI Marie-Claire",
    manuels: [
      {
        titre: "Livre de Français CP1",
        quantite_demandee: 20,
        quantite_approuvee: 20,
        quantite_transferee: 20,
      },
      { titre: "Mathématiques CP1", quantite_demandee: 20, quantite_approuvee: 20, quantite_transferee: 20 },
      {
        titre: "Cahier d'Exercices Français CP1",
        quantite_demandee: 20,
        quantite_approuvee: 20,
        quantite_transferee: 20,
      },
      {
        titre: "Cahier d'Exercices Mathématiques CP1",
        quantite_demandee: 20,
        quantite_approuvee: 20,
        quantite_transferee: 20,
      },
    ],
  },
  {
    id: 2,
    reference: "REG-2024-002",
    type_regulation: "INTERNE",
    structure_source: {
      code: "EPP-YOP-01",
      libelle: "EPP Yopougon Maroc",
      type: "EPP",
    },
    structure_destination: {
      code: "EPP-YOP-02",
      libelle: "EPP Yopougon Niangon",
      type: "EPP",
    },
    drena_source: {
      code: "DRENA-ABJ",
      libelle: "DRENA Abidjan",
    },
    drena_destination: {
      code: "DRENA-ABJ",
      libelle: "DRENA Abidjan",
    },
    motif: "Répartition entre écoles Yopougon",
    statut: "EN_COURS",
    date_demande: "2024-10-26",
    demande_par: "TRAORE Seydou",
    manuels: [
      { titre: "Français CP2", quantite_demandee: 15, quantite_approuvee: 15, quantite_transferee: 0 },
      { titre: "Mathématiques CP2", quantite_demandee: 15, quantite_approuvee: 15, quantite_transferee: 0 },
    ],
  },
  {
    id: 3,
    reference: "REG-2024-003",
    type_regulation: "INTERNE",
    structure_source: {
      code: "EPP-BK-01",
      libelle: "EPP Bouaké Centre",
      type: "EPP",
    },
    structure_destination: {
      code: "EPP-BK-02",
      libelle: "EPP Bouaké Koko",
      type: "EPP",
    },
    drena_source: {
      code: "DRENA-BK",
      libelle: "DRENA Bouaké",
    },
    drena_destination: {
      code: "DRENA-BK",
      libelle: "DRENA Bouaké",
    },
    motif: "Demande urgente pour distribution CE1",
    statut: "DEMANDEE",
    date_demande: "2024-10-27",
    demande_par: "BAMBA Moussa",
    manuels: [
      { titre: "Français CE1", quantite_demandee: 25, quantite_approuvee: 0, quantite_transferee: 0 },
      { titre: "Mathématiques CE1", quantite_demandee: 25, quantite_approuvee: 0, quantite_transferee: 0 },
    ],
  },
  {
    id: 4,
    reference: "REG-2024-004",
    type_regulation: "EXTERNE",
    structure_source: {
      code: "EPP-ABJ-01",
      libelle: "EPP Abidjan Plateau",
      type: "EPP",
    },
    structure_destination: {
      code: "EPP-BK-03",
      libelle: "EPP Bouaké Sakassou",
      type: "EPP",
    },
    drena_source: {
      code: "DRENA-ABJ",
      libelle: "DRENA Abidjan",
    },
    drena_destination: {
      code: "DRENA-BK",
      libelle: "DRENA Bouaké",
    },
    motif: "Transfert inter-DRENA : excédent Abidjan vers déficit Bouaké",
    statut: "DEMANDEE",
    date_demande: "2024-10-28",
    demande_par: "KOUASSI Jean",
    manuels: [
      { titre: "Français CP1", quantite_demandee: 50, quantite_approuvee: 0, quantite_transferee: 0 },
      { titre: "Mathématiques CP1", quantite_demandee: 50, quantite_approuvee: 0, quantite_transferee: 0 },
      { titre: "Français CP2", quantite_demandee: 30, quantite_approuvee: 0, quantite_transferee: 0 },
    ],
  },
]

export default function RegulationPage() {
  const { user } = useAuth()
  const { anneesScolaires, loading: anneesLoading } = useAnneesScolaires()
  const anneesScolairesAvecId = anneesScolaires.filter(
    (a): a is AnneeScolaire & { id: number } => typeof a.id === "number"
  )
  const [regulations, setRegulations] = useState<RegulationDto[]>([])
  const [loading, setLoading] = useState(true)
  const [selectedRegulation, setSelectedRegulation] = useState<RegulationDto | null>(null)
  const [selectedRegulationForValidation, setSelectedRegulationForValidation] = useState<RegulationDto | null>(null)
  const [activeTab, setActiveTab] = useState("regulations")
  /** Sous-vue de l'historique : récupérations encore programmées vs opérations déjà réalisées / validées */
  const [historySubTab, setHistorySubTab] = useState<"programmees" | "realisees">("realisees")
  const [anneeScolaireId, setAnneeScolaireId] = useState<number | null>(null)
  const [eppExcedentaires, setEppExcedentaires] = useState<EppExcedentaireItem[]>([])
  const [eppDeficitaires, setEppDeficitaires] = useState<EppDeficitaireItem[]>([])
  const [ieppAggExcedentaires, setIeppAggExcedentaires] = useState<IeppAggRowExcedent[]>([])
  const [ieppAggDeficitaires, setIeppAggDeficitaires] = useState<IeppAggRowDeficit[]>([])
  const [loadingExcedentaires, setLoadingExcedentaires] = useState(false)
  const [loadingDeficitaires, setLoadingDeficitaires] = useState(false)

  // Modals
  const [showProgrammerModal, setShowProgrammerModal] = useState(false)
  const [showValiderModal, setShowValiderModal] = useState(false)
  const [showDetailsModal, setShowDetailsModal] = useState(false)
  const [showRedistribuerModal, setShowRedistribuerModal] = useState(false)
  const [showRedistribuerModalV2, setShowRedistribuerModalV2] = useState(false)
  const [showRegulationV2IeppModal, setShowRegulationV2IeppModal] = useState(false)
  const [v2PendingRows, setV2PendingRows] = useState<RegulationV2PendingRow[]>([])
  const [v2PendingLoading, setV2PendingLoading] = useState(false)
  const [hubModalScope, setHubModalScope] = useState<null | "DRENA_IEPP" | "DAF_DRENA">(null)
  const [selectedEPPForRedistribution, setSelectedEPPForRedistribution] = useState<number | undefined>(undefined)
  const retryCountRef = useRef(0)

  const roleCode = (user?.role?.code ?? "").trim().toUpperCase()
  const isIeppUser = roleCode === "IEPP"
  const isDrenaUser = roleCode === "DRENA"
  const isDafUser = roleCode === "DAF"
  const canActRegulation = ["IEPP", "DRENA", "DAF", "ADMIN"].includes(roleCode)

  const [dafDrenaList, setDafDrenaList] = useState<Array<{ id: number; code: string; libelle: string }>>([])
  const [selectedDafDrenaId, setSelectedDafDrenaId] = useState<number | null>(null)
  const [ieppChoices, setIeppChoices] = useState<Array<{ ieppId: number; ieppCode: string; ieppLibelle: string }>>([])
  const [selectedIeppId, setSelectedIeppId] = useState<number | null>(null)

  /**
   * Périmètre DRENA pour dashboard / listes IEPP : préférer la PK `structure_administrative`
   * (alignée sur la session backend), puis id métier `drena`.
   */
  const drenaStructureIdForChildren = isDrenaUser
    ? (user as { structureAdministrativeId?: number }).structureAdministrativeId ??
      (user as { drena?: { id: number } }).drena?.id ??
      user?.structure?.id ??
      null
    : selectedDafDrenaId

  const effectiveIeppId: number | null = isIeppUser
    ? (user as { structureAdministrativeId?: number }).structureAdministrativeId ?? user?.structure?.id ?? null
    : selectedIeppId

  /** La programmation DRENA/DAF porte sur tout le périmètre ; seul l’IEPP doit cibler un IEPP précis. */
  const canOpenProgrammerModal =
    isDafUser ||
    (isDrenaUser && drenaStructureIdForChildren != null) ||
    (isIeppUser && effectiveIeppId != null) ||
    (!isDafUser && !isDrenaUser && !isIeppUser && effectiveIeppId != null)

  const excedentDeficitTabPrefix =
    isDafUser ? "DRENA" : isDrenaUser ? "IEPP" : "EPP"

  // Définir l'année scolaire par défaut (courante ou première)
  useEffect(() => {
    if (anneesScolaires.length > 0 && anneeScolaireId === null) {
      const courante = anneesScolaires.find((a: { estCourante?: boolean }) => a.estCourante)
      setAnneeScolaireId(courante?.id ?? anneesScolaires[0]?.id ?? null)
    }
  }, [anneesScolaires, anneeScolaireId])

  useEffect(() => {
    if (!isDafUser || !user) return
    let cancelled = false
    dashboardService
      .listNationalDrenas()
      .then((r) => {
        if (cancelled) return
        const raw = r.items as unknown
        const list = Array.isArray(raw) ? raw : raw != null ? [raw] : []
        setDafDrenaList(list as Array<{ id: number; code: string; libelle: string }>)
      })
      .catch(() => {
        if (!cancelled) setDafDrenaList([])
      })
    return () => {
      cancelled = true
    }
  }, [isDafUser, user])

  useEffect(() => {
    if (!anneeScolaireId || drenaStructureIdForChildren == null || (!isDrenaUser && !isDafUser)) {
      if (!isIeppUser) setIeppChoices([])
      return
    }
    let cancelled = false

    const mapIeppList = (list: Iepp[]) =>
      list.map((x) => ({
        ieppId: x.id,
        ieppCode: x.code,
        ieppLibelle: x.libelle,
      }))

    const loadFromStructureService = async () => {
      const r = await structuresService.getIeppsByDrena(drenaStructureIdForChildren)
      if (cancelled) return
      const raw = (r.items ?? []) as unknown
      const list: Iepp[] =
        Array.isArray(raw) && raw.length > 0 && Array.isArray((raw as Iepp[][])[0])
          ? (raw as Iepp[][]).flat()
          : (raw as Iepp[])
      setIeppChoices(mapIeppList(list))
    }

    ;(async () => {
      try {
        const r = await dashboardService.getDrenaActivites(drenaStructureIdForChildren, anneeScolaireId)
        if (cancelled) return
        const fromPayload = extractIeppChoicesFromDrenaActivitesPayload(r)
        if (fromPayload.length > 0) {
          setIeppChoices(fromPayload)
          return
        }
        await loadFromStructureService()
      } catch {
        if (cancelled) return
        try {
          await loadFromStructureService()
        } catch {
          if (!cancelled) setIeppChoices([])
        }
      }
    })()

    return () => {
      cancelled = true
    }
  }, [anneeScolaireId, drenaStructureIdForChildren, isDafUser, isDrenaUser, isIeppUser])

  useEffect(() => {
    if (isDafUser) setSelectedIeppId(null)
  }, [selectedDafDrenaId, isDafUser])

  // Charger les régulations au montage et quand le filtre territorial (IEPP / DRENA DAF) ou l’année change
  useEffect(() => {
    if (user) {
      retryCountRef.current = 0
      loadRegulations()
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user, selectedIeppId, selectedDafDrenaId, anneeScolaireId])

  const drenaScopeForAggregates =
    isDrenaUser || (isDafUser && selectedDafDrenaId != null) ? drenaStructureIdForChildren : null

  const loadEppExcedentaires = async () => {
    if (!effectiveIeppId || !anneeScolaireId) return
    setLoadingExcedentaires(true)
    try {
      const response = await regulationService.getEppExcedentaires(effectiveIeppId, anneeScolaireId)
      if (response.items && Array.isArray(response.items)) {
        setEppExcedentaires(response.items as EppExcedentaireItem[])
      } else {
        setEppExcedentaires([])
      }
    } catch (e: unknown) {
      console.error("Erreur chargement EPP excédentaires:", e)
      toast.error("Erreur lors du chargement des EPP excédentaires")
      setEppExcedentaires([])
    } finally {
      setLoadingExcedentaires(false)
    }
  }

  const loadIeppAggExcedentairesDrena = async () => {
    if (!drenaScopeForAggregates || !anneeScolaireId) return
    setLoadingExcedentaires(true)
    try {
      const response = await regulationService.getIeppExcedentairesByDrena(
        drenaScopeForAggregates,
        anneeScolaireId
      )
      const raw = response.items as unknown
      const list = Array.isArray(raw) ? raw : raw != null ? [raw] : []
      setIeppAggExcedentaires(list as IeppAggRowExcedent[])
    } catch (e: unknown) {
      console.error("Erreur chargement IEPP excédentaires (DRENA):", e)
      toast.error("Erreur lors du chargement des IEPP excédentaires")
      setIeppAggExcedentaires([])
    } finally {
      setLoadingExcedentaires(false)
    }
  }

  const loadEppDeficitaires = async () => {
    if (!effectiveIeppId || !anneeScolaireId) return
    setLoadingDeficitaires(true)
    try {
      const response = await regulationService.getEppDeficitaires(effectiveIeppId, anneeScolaireId)
      if (response.items && Array.isArray(response.items)) {
        setEppDeficitaires(response.items as EppDeficitaireItem[])
      } else {
        setEppDeficitaires([])
      }
    } catch (e: unknown) {
      console.error("Erreur chargement EPP déficitaires:", e)
      toast.error("Erreur lors du chargement des EPP déficitaires")
      setEppDeficitaires([])
    } finally {
      setLoadingDeficitaires(false)
    }
  }

  const loadIeppAggDeficitairesDrena = async () => {
    if (!drenaScopeForAggregates || !anneeScolaireId) return
    setLoadingDeficitaires(true)
    try {
      const response = await regulationService.getIeppDeficitairesByDrena(
        drenaScopeForAggregates,
        anneeScolaireId
      )
      const raw = response.items as unknown
      const list = Array.isArray(raw) ? raw : raw != null ? [raw] : []
      setIeppAggDeficitaires(list as IeppAggRowDeficit[])
    } catch (e: unknown) {
      console.error("Erreur chargement IEPP déficitaires (DRENA):", e)
      toast.error("Erreur lors du chargement des IEPP déficitaires")
      setIeppAggDeficitaires([])
    } finally {
      setLoadingDeficitaires(false)
    }
  }

  // Charger excédentaires / déficitaires quand on change d'onglet ou d'année
  useEffect(() => {
    if (activeTab !== "excedentaires" || !anneeScolaireId) return
    if (isIeppUser && effectiveIeppId) {
      loadEppExcedentaires()
      return
    }
    if ((isDrenaUser || isDafUser) && drenaScopeForAggregates) {
      loadIeppAggExcedentairesDrena()
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeTab, anneeScolaireId, effectiveIeppId, drenaScopeForAggregates, isIeppUser, isDrenaUser, isDafUser])
  useEffect(() => {
    if (activeTab !== "deficitaires" || !anneeScolaireId) return
    if (isIeppUser && effectiveIeppId) {
      loadEppDeficitaires()
      return
    }
    if ((isDrenaUser || isDafUser) && drenaScopeForAggregates) {
      loadIeppAggDeficitairesDrena()
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeTab, anneeScolaireId, effectiveIeppId, drenaScopeForAggregates, isIeppUser, isDrenaUser, isDafUser])

  const loadV2PendingLines = async () => {
    try {
      setV2PendingLoading(true)
      const r = await regulationV2Service.listerLignesEnAttente()
      if (!r.hasError && Array.isArray(r.items)) {
        setV2PendingRows(r.items as RegulationV2PendingRow[])
      } else {
        setV2PendingRows([])
      }
    } catch {
      setV2PendingRows([])
    } finally {
      setV2PendingLoading(false)
    }
  }

  const loadRegulations = async () => {
    if (typeof window === "undefined") return
    
    setLoading(true)
    try {
      const filters: Partial<RegulationDto> = {}
      const drenaSaPk =
        (user as { structureAdministrativeId?: number }).structureAdministrativeId ?? user?.structure?.id

      if (anneeScolaireId != null) {
        const y = Number(anneeScolaireId)
        if (Number.isFinite(y) && y > 0) filters.anneeScolaireId = y
      }

      if (isIeppUser && drenaSaPk) {
        filters.ieppId = drenaSaPk
      } else if (isDrenaUser && drenaSaPk) {
        // Un seul filtre : `ieppId` précis OU périmètre DRENA (PK structure_administrative — colonne `regulation.drena_id`).
        if (selectedIeppId != null) {
          filters.ieppId = selectedIeppId
        } else {
          filters.drenaId = drenaSaPk
        }
      } else if (isDafUser && selectedDafDrenaId != null) {
        if (selectedIeppId != null) {
          filters.ieppId = selectedIeppId
        } else {
          filters.drenaId = selectedDafDrenaId
        }
      }
      
      const response = await regulationService.getByCriteria(filters, 0, 100)
      if (response.items) {
        setRegulations(response.items)
      }
    } catch (error: any) {
      console.error("Erreur lors du chargement des régulations:", error)
      // Si c'est une erreur "Utilisateur non connecté" et qu'on n'a pas encore réessayé 3 fois
      if (error?.message?.includes("Utilisateur non connecté") && retryCountRef.current < 3) {
        retryCountRef.current++
        console.warn(`Token non disponible, réessai ${retryCountRef.current}/3 dans 500ms...`)
        setTimeout(() => {
          if (user) {
            loadRegulations()
          }
        }, 500)
        return
      }
      // Afficher l'erreur seulement si ce n'est pas une erreur d'authentification ou après 3 tentatives
      if (!error?.message?.includes("Utilisateur non connecté")) {
        toast.error(error?.message || "Erreur lors du chargement des régulations")
      }
    } finally {
      setLoading(false)
      void loadV2PendingLines()
    }
  }

  // ✅ CORRECTION: Vérification après tous les hooks
  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <p className="text-gray-600">Chargement...</p>
        </div>
      </div>
    )
  }

  if (!canAccessRegulationPage(user.role.code, user.functionalityPermissions)) {
    return (
      <MainLayout>
        <div className="text-center py-12">
          <h2 className="text-xl font-semibold text-gray-900 mb-2">Accès restreint</h2>
          <p className="text-gray-600">Vous n&apos;avez pas les droits pour la régulation (REGULATION:READ).</p>
        </div>
      </MainLayout>
    )
  }

  const getStatusIcon = (statut?: string) => {
    const s = (statut ?? "").trim().toUpperCase()
    switch (s) {
      case "TERMINEE":
        return <CheckCircleIcon className="h-5 w-5 text-green-600" />
      case "VALIDE":
        return <CheckCircleIcon className="h-5 w-5 text-blue-600" />
      case "PROGRAMMEE":
      case "PROGRAMMÉE":
        return <ClockIcon className="h-5 w-5 text-yellow-600" />
      case "EN_ATTENTE_ACCORDS":
        return <ClockIcon className="h-5 w-5 text-amber-600" />
      case "ANNULEE":
        return <XCircleIcon className="h-5 w-5 text-red-600" />
      default:
        return <ClockIcon className="h-5 w-5 text-gray-600" />
    }
  }

  const getStatusBadge = (statut?: string) => {
    const s = (statut ?? "").trim().toUpperCase()
    switch (s) {
      case "TERMINEE":
        return "badge-success"
      case "VALIDE":
        return "badge-info"
      case "PROGRAMMEE":
      case "PROGRAMMÉE":
        return "badge-warning"
      case "EN_ATTENTE_ACCORDS":
        return "badge-warning"
      case "ANNULEE":
        return "badge-error"
      default:
        return "badge-info"
    }
  }

  const totalRegulations = regulations.length
  const regulationsValidees = regulations.filter((r) => r.statut === "VALIDE").length
  const regulationsProgrammees = regulations.filter((r) => r.statut === "PROGRAMMEE").length
  const regulationsTerminees = regulations.filter((r) => r.statut === "TERMINEE").length

  /** Normalise le type (casse / espaces) pour le filtrage */
  const normalizeRegulationType = (t?: string | null) => (t ?? "").trim().toUpperCase()

  /**
   * Récupération stocks EPP : toutes les lignes métier RECUPERATION (programmée, terminée ou annulée).
   * Une fois validée, la récupération passe en TERMINEE : elle reste ici pour l'historique de programmation.
   */
  const regulationsRecuperationListe = regulations.filter(
    (r) => normalizeRegulationType(r.type) === "RECUPERATION"
  )

  /**
   * Redistributions IEPP → EPP et autres opérations hors récupération planifiée.
   * Données anciennes sans type : affichées ici pour ne pas les perdre.
   */
  const regulationsRealiseesListe = regulations.filter((r) => {
    const t = normalizeRegulationType(r.type)
    if (t === "REDISTRIBUTION") return true
    if (t === "RECUPERATION") return false
    // type vide / inconnu : historique général (ex. données avant typage)
    return true
  })

  /** PK SA source pour les modals hub (DRENA ou DAF selon le flux) */
  const hubStockModalHubId =
    hubModalScope === "DAF_DRENA"
      ? user?.structure?.id ?? 0
      : isDrenaUser
        ? user?.structure?.id ?? 0
        : selectedDafDrenaId ?? 0

  const isStatutProgrammee = (statut?: string | null) => {
    const s = (statut ?? "").trim().toUpperCase()
    return s === "PROGRAMMEE" || s === "PROGRAMMÉE"
  }

  const formatRegulationType = (type?: string, commentaire?: string | null) => {
    const c = (commentaire ?? "").trim()
    if (type === "REDISTRIBUTION" && c.includes("[DRENA→IEPP]")) return "Redistribution DRENA → IEPP"
    if (type === "REDISTRIBUTION" && c.includes("[DAF→DRENA]")) return "Redistribution DAF → DRENA"
    switch (type) {
      case "RECUPERATION":
        return "Récupération (stocks EPP)"
      case "REDISTRIBUTION":
        return "Redistribution IEPP → EPP"
      case "REGULATION_V2_EPP":
        return "Régulation (IEPP → EPP, accords multi-sources)"
      case "REGULATION_V2_IEPP":
        return "Régulation (IEPP → IEPP)"
      case "REGULATION_V2_DAF_DIRECT":
        return "Don DAF direct"
      default:
        return type ?? "—"
    }
  }

  const handleValiderRegulation = (regulation: RegulationDto) => {
    setSelectedRegulationForValidation(regulation)
    setShowValiderModal(true)
  }

  const handleAnnulerRegulation = async (regulation: RegulationDto) => {
    const tierBlock = regulationTierActionBlockedReason(roleCode, regulation)
    if (tierBlock) {
      toast.error(tierBlock)
      return
    }
    if (!confirm("Êtes-vous sûr de vouloir annuler cette régulation ?")) {
      return
    }

    const raison = prompt("Raison de l'annulation:")
    if (!raison) {
      return
    }

    try {
      const response = await regulationService.annulerRegulation(regulation.id!, raison)
      if (response.hasError) {
        toast.error(response.status?.message || "Erreur lors de l'annulation")
      } else {
        toast.success("Régulation annulée avec succès")
        loadRegulations()
      }
    } catch (error: any) {
      console.error("Erreur lors de l'annulation:", error)
      toast.error(error?.message || "Erreur lors de l'annulation")
    }
  }

  const handleVoirDetails = (regulation: RegulationDto) => {
    setSelectedRegulation(regulation)
    setShowDetailsModal(true)
  }

  const canUserExecuteV2Demande = (r: RegulationDto) =>
    normalizeRegulationType(r.type) === "REGULATION_V2_EPP" &&
    (r.statut ?? "").trim().toUpperCase() === "EN_ATTENTE_ACCORDS" &&
    (roleCode === "ADMIN" || (user != null && r.initieePar != null && Number(r.initieePar) === user.id))

  const handleExecuterDemandeV2 = async (regulation: RegulationDto) => {
    if (!regulation.id) return
    if (!confirm("Exécuter cette demande ? Seules les lignes acceptées seront transférées.")) return
    try {
      const res = await regulationV2Service.executerDemande(regulation.id)
      if (res.hasError) {
        toast.error(res.status?.message || "Exécution impossible")
        return
      }
      toast.success("Demande exécutée")
      await loadRegulations()
    } catch (e: unknown) {
      console.error(e)
      toast.error(getApiErrorMessage(e, "Erreur lors de l’exécution"), { duration: 10_000 })
    }
  }

  const handleV2ApprouverLigne = async (ligneId: number) => {
    try {
      const res = await regulationV2Service.approuverLigne(ligneId)
      if (res.hasError) {
        toast.error(res.status?.message || "Refus serveur")
        return
      }
      toast.success("Ligne acceptée")
      await loadV2PendingLines()
      await loadRegulations()
    } catch (e: unknown) {
      console.error(e)
      toast.error(getApiErrorMessage(e, "Erreur lors de l’acceptation de la ligne"), { duration: 8000 })
    }
  }

  const handleV2RefuserLigne = async (ligneId: number) => {
    if (!confirm("Refuser cette ligne ? Elle ne sera pas exécutée.")) return
    try {
      const res = await regulationV2Service.refuserLigne(ligneId)
      if (res.hasError) {
        toast.error(res.status?.message || "Refus serveur")
        return
      }
      toast.success("Ligne refusée")
      await loadV2PendingLines()
      await loadRegulations()
    } catch (e: unknown) {
      console.error(e)
      toast.error(getApiErrorMessage(e, "Erreur lors du refus de la ligne"), { duration: 8000 })
    }
  }

  return (
    <MainLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Régulation des Stocks</h1>
            <p className="text-gray-600">Transferts de manuels entre structures</p>
          </div>
          {canActRegulation && (
            <button
              onClick={() => setShowProgrammerModal(true)}
              className="btn-primary mt-4 sm:mt-0"
              disabled={!canOpenProgrammerModal}
              title={
                !canOpenProgrammerModal
                  ? isIeppUser || (!isDafUser && !isDrenaUser)
                    ? "Sélectionnez un IEPP ou vérifiez votre rattachement structure"
                    : isDrenaUser
                      ? "Périmètre DRENA indisponible"
                      : undefined
                  : undefined
              }
            >
              <PlusIcon className="h-5 w-5 mr-2" />
              Programmation de récupération
            </button>
          )}
        </div>

        {canActRegulation && (
          <div className="card p-4">
            <h3 className="text-sm font-semibold text-gray-900 mb-2">
              Régulation — lignes en attente de votre accord (structure source)
            </h3>
            {v2PendingLoading ? (
              <p className="text-sm text-gray-500">Chargement…</p>
            ) : v2PendingRows.length === 0 ? (
              <p className="text-sm text-gray-500">Aucune ligne en attente pour votre structure.</p>
            ) : (
              <div className="overflow-x-auto">
                <table className="table text-sm">
                  <thead>
                    <tr>
                      <th>Réf. régulation</th>
                      <th>Matière</th>
                      <th>Niveau</th>
                      <th className="text-right">Qté</th>
                      <th>Structure destinataire</th>
                      <th>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {v2PendingRows.map((row) => (
                      <tr key={row.ligneId}>
                        <td className="font-mono text-xs">{formatRegulationReferenceForDisplay(row.reference) || "—"}</td>
                        <td>
                          {row.matiereLibelle?.trim()
                            ? row.matiereCode
                              ? `${row.matiereLibelle} (${row.matiereCode})`
                              : row.matiereLibelle
                            : "—"}
                        </td>
                        <td>
                          {row.niveauLibelle?.trim()
                            ? row.niveauCode
                              ? `${row.niveauLibelle} (${row.niveauCode})`
                              : row.niveauLibelle
                            : "—"}
                        </td>
                        <td className="text-right">{row.quantite}</td>
                        <td>
                          {row.structureDestLibelle?.trim()
                            ? row.structureDestCode
                              ? `${row.structureDestLibelle} (${row.structureDestCode})`
                              : row.structureDestLibelle
                            : "—"}
                        </td>
                        <td>
                          <div className="flex flex-wrap gap-2">
                            <button
                              type="button"
                              onClick={() => void handleV2RefuserLigne(row.ligneId)}
                              className="rounded-md border border-red-600 bg-red-600 px-3 py-1.5 text-xs font-medium text-white hover:bg-red-700"
                            >
                              Refuser
                            </button>
                            <button
                              type="button"
                              onClick={() => void handleV2ApprouverLigne(row.ligneId)}
                              className="rounded-md border border-emerald-600 bg-emerald-600 px-3 py-1.5 text-xs font-medium text-white hover:bg-emerald-700"
                            >
                              Accepter
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}

        {(isDafUser || isDrenaUser) && (
          <div className="card p-4 space-y-3">
            <p className="text-sm text-gray-600">
              Les onglets Excédentaires / Déficitaires listent tout le périmètre (IEPP puis EPP) dès qu&apos;une DRENA
              est connue — sans obliger à choisir un IEPP. Le filtre IEPP reste utile pour l&apos;historique des
              régulations ciblé. La programmation de récupération DRENA/DAF reste accessible sans sélection
              d&apos;IEPP. {isDafUser && "En tant que DAF, choisissez d&apos;abord une DRENA dans la liste."}
            </p>
            {isDafUser && (
              <div className="flex flex-col sm:flex-row sm:items-center gap-2">
                <label className="text-sm font-medium text-gray-700 shrink-0">DRENA</label>
                <select
                  className="input-field max-w-xl"
                  value={selectedDafDrenaId ?? ""}
                  onChange={(e) => setSelectedDafDrenaId(e.target.value ? Number(e.target.value) : null)}
                >
                  <option value="">— Choisir une DRENA —</option>
                  {dafDrenaList.map((d) => (
                    <option key={d.id} value={d.id}>
                      {d.libelle ?? d.code}
                    </option>
                  ))}
                </select>
              </div>
            )}
            {(isDrenaUser || (isDafUser && selectedDafDrenaId)) && (
              <div className="flex flex-col sm:flex-row sm:items-center gap-2">
                <label className="text-sm font-medium text-gray-700 shrink-0">IEPP</label>
                <select
                  className="input-field max-w-xl"
                  value={selectedIeppId ?? ""}
                  onChange={(e) => setSelectedIeppId(e.target.value ? Number(e.target.value) : null)}
                >
                  <option value="">— Choisir un IEPP —</option>
                  {ieppChoices.map((i) => (
                    <option key={i.ieppId} value={i.ieppId}>
                      {i.ieppLibelle} ({i.ieppCode})
                    </option>
                  ))}
                </select>
              </div>
            )}
          </div>
        )}

        {/* Tabs */}
        <div className="border-b border-gray-200">
          <nav className="-mb-px flex space-x-8">
            <button
              onClick={() => setActiveTab("excedentaires")}
              className={`py-2 px-1 border-b-2 font-medium text-sm ${
                activeTab === "excedentaires"
                  ? "border-orange-500 text-orange-600"
                  : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
              }`}
            >
              {excedentDeficitTabPrefix} Excédentaires
            </button>
            <button
              onClick={() => setActiveTab("deficitaires")}
              className={`py-2 px-1 border-b-2 font-medium text-sm ${
                activeTab === "deficitaires"
                  ? "border-orange-500 text-orange-600"
                  : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
              }`}
            >
              {excedentDeficitTabPrefix} Déficitaires
            </button>
            <button
              onClick={() => setActiveTab("regulations")}
              className={`py-2 px-1 border-b-2 font-medium text-sm ${
                activeTab === "regulations"
                  ? "border-orange-500 text-orange-600"
                  : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
              }`}
            >
              Historique régulation
            </button>
          </nav>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <div className="stat-card">
            <div className="flex items-center">
              <div className="p-3 rounded-lg bg-blue-50 text-blue-600">
                <ArrowsRightLeftIcon className="h-6 w-6" />
              </div>
              <div className="ml-4">
                <p className="stat-label">Total Régulations</p>
                <p className="stat-value">{totalRegulations}</p>
              </div>
            </div>
          </div>

          <div className="stat-card">
            <div className="flex items-center">
              <div className="p-3 rounded-lg bg-green-50 text-green-600">
                <CheckCircleIcon className="h-6 w-6" />
              </div>
              <div className="ml-4">
                <p className="stat-label">Terminées</p>
                <p className="stat-value">{regulationsTerminees}</p>
              </div>
            </div>
          </div>

          <div className="stat-card">
            <div className="flex items-center">
              <div className="p-3 rounded-lg bg-blue-50 text-blue-600">
                <CheckCircleIcon className="h-6 w-6" />
              </div>
              <div className="ml-4">
                <p className="stat-label">Validées</p>
                <p className="stat-value">{regulationsValidees}</p>
              </div>
            </div>
          </div>

          <div className="stat-card">
            <div className="flex items-center">
              <div className="p-3 rounded-lg bg-yellow-50 text-yellow-600">
                <ClockIcon className="h-6 w-6" />
              </div>
              <div className="ml-4">
                <p className="stat-label">Programmées</p>
                <p className="stat-value">{regulationsProgrammees}</p>
              </div>
            </div>
          </div>
        </div>

        {/* Contenu conditionnel selon l'onglet actif */}
        {activeTab === "regulations" && (
          <div className="card">
            <div className="flex flex-col gap-4 mb-4">
              <div>
                <h3 className="text-lg font-semibold text-gray-900">Historique des régulations</h3>
                <p className="text-sm text-gray-600 mt-1">
                  <span className="font-medium text-gray-800">Récupération stocks EPP</span> : historique des programmations (en attente, terminées ou annulées).{" "}
                  <span className="font-medium text-gray-800">Redistributions</span> : transferts IEPP → EPP enregistrés (hors récupération planifiée).
                </p>
              </div>
              <div className="flex flex-wrap gap-2 border-b border-gray-200 pb-2">
                <button
                  type="button"
                  onClick={() => setHistorySubTab("programmees")}
                  className={`rounded-lg px-4 py-2 text-sm font-medium transition-colors ${
                    historySubTab === "programmees"
                      ? "bg-orange-600 text-white shadow-sm"
                      : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                  }`}
                >
                  Récupération stocks EPP
                  {regulationsRecuperationListe.length > 0 && (
                    <span
                      className={`ml-2 rounded-full px-2 py-0.5 text-xs ${
                        historySubTab === "programmees" ? "bg-white/20" : "bg-gray-200 text-gray-800"
                      }`}
                    >
                      {regulationsRecuperationListe.length}
                    </span>
                  )}
                </button>
                <button
                  type="button"
                  onClick={() => setHistorySubTab("realisees")}
                  className={`rounded-lg px-4 py-2 text-sm font-medium transition-colors ${
                    historySubTab === "realisees"
                      ? "bg-orange-600 text-white shadow-sm"
                      : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                  }`}
                >
                  Redistributions
                  {regulationsRealiseesListe.length > 0 && (
                    <span
                      className={`ml-2 rounded-full px-2 py-0.5 text-xs ${
                        historySubTab === "realisees" ? "bg-white/20" : "bg-gray-200 text-gray-800"
                      }`}
                    >
                      {regulationsRealiseesListe.length}
                    </span>
                  )}
                </button>
              </div>
            </div>
            {loading ? (
              <div className="text-center py-8">
                <p className="text-gray-600">Chargement...</p>
              </div>
            ) : historySubTab === "programmees" ? (
              regulationsRecuperationListe.length === 0 ? (
                <div className="text-center py-8 rounded-lg bg-gray-50 border border-dashed border-gray-200">
                  <p className="text-gray-600">Aucune récupération planifiée enregistrée (type RECUPERATION).</p>
                  <p className="text-sm text-gray-500 mt-1">
                    Utilisez « Programmation de récupération » pour en créer une. Les redistributions figurent dans l&apos;autre onglet.
                  </p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="table">
                    <thead>
                      <tr>
                        <th>Référence</th>
                        <th>Type</th>
                        <th>Date de récupération prévue</th>
                        <th>Taux</th>
                        <th>Date de programmation</th>
                        <th>Statut</th>
                        <th>Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {regulationsRecuperationListe.map((regulation) => {
                        const tierActionBlockReason = regulationTierActionBlockedReason(roleCode, regulation)
                        return (
                        <tr key={regulation.id}>
                          <td className="font-medium">{regulation.reference}</td>
                          <td className="text-sm text-gray-700">{formatRegulationType(regulation.type, regulation.commentaire)}</td>
                          <td>
                            {regulation.dateRecuperation
                              ? new Date(regulation.dateRecuperation).toLocaleDateString("fr-FR")
                              : "—"}
                          </td>
                          <td>
                            {regulation.tauxRecuperation != null
                              ? `${(regulation.tauxRecuperation * 100).toFixed(0)}%`
                              : "100%"}
                          </td>
                          <td>
                            {regulation.dateRegulation
                              ? new Date(regulation.dateRegulation).toLocaleDateString("fr-FR")
                              : "—"}
                          </td>
                          <td>
                            <span className={`${getStatusBadge(regulation.statut)} flex items-center`}>
                              {getStatusIcon(regulation.statut)}
                              <span className="ml-1">{regulation.statut || "—"}</span>
                            </span>
                          </td>
                          <td>
                            <div className="flex flex-wrap gap-2">
                              <button
                                onClick={() => handleVoirDetails(regulation)}
                                className="text-orange-600 hover:text-orange-800 font-medium text-sm"
                              >
                                Détails
                              </button>
                              {canActRegulation && isStatutProgrammee(regulation.statut) && (
                                <>
                                  <button
                                    type="button"
                                    onClick={() => handleValiderRegulation(regulation)}
                                    disabled={!!tierActionBlockReason}
                                    title={tierActionBlockReason ?? undefined}
                                    className={`font-medium text-sm ${
                                      tierActionBlockReason
                                        ? "text-gray-400 cursor-not-allowed"
                                        : "text-blue-600 hover:text-blue-800"
                                    }`}
                                  >
                                    Valider
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => handleAnnulerRegulation(regulation)}
                                    disabled={!!tierActionBlockReason}
                                    title={tierActionBlockReason ?? undefined}
                                    className={`font-medium text-sm ${
                                      tierActionBlockReason
                                        ? "text-gray-400 cursor-not-allowed"
                                        : "text-red-600 hover:text-red-800"
                                    }`}
                                  >
                                    Annuler
                                  </button>
                                </>
                              )}
                            </div>
                          </td>
                        </tr>
                      )})}
                    </tbody>
                  </table>
                </div>
              )
            ) : regulationsRealiseesListe.length === 0 ? (
              <div className="text-center py-8 rounded-lg bg-gray-50 border border-dashed border-gray-200">
                <p className="text-gray-600">Aucune redistribution ou autre opération hors récupération planifiée.</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="table">
                  <thead>
                    <tr>
                      <th>Référence</th>
                      <th>Type</th>
                      <th>Source / destination</th>
                      <th>Date de Récupération</th>
                      <th>Taux</th>
                      <th>Date validation</th>
                      <th>Statut</th>
                      <th>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {regulationsRealiseesListe.map((regulation) => (
                      <tr key={regulation.id}>
                        <td className="font-medium">{regulation.reference}</td>
                        <td className="text-sm text-gray-700">{formatRegulationType(regulation.type, regulation.commentaire)}</td>
                        <td className="text-sm text-gray-600">
                          {normalizeRegulationType(regulation.type) === "REGULATION_V2_EPP" ||
                          normalizeRegulationType(regulation.type) === "REGULATION_V2_IEPP" ? (
                            <span>Flux multi-structures — détail dans « Détails »</span>
                          ) : regulation.type === "REDISTRIBUTION" &&
                            (regulation.sourceId != null || regulation.destinationId != null) ? (
                            <span>Transfert IEPP → EPP — détail dans « Détails »</span>
                          ) : (
                            <span className="text-gray-400">—</span>
                          )}
                        </td>
                        <td>
                          {regulation.dateRecuperation
                            ? new Date(regulation.dateRecuperation).toLocaleDateString("fr-FR")
                            : "—"}
                        </td>
                        <td>
                          {regulation.tauxRecuperation != null
                            ? `${(regulation.tauxRecuperation * 100).toFixed(0)}%`
                            : "—"}
                        </td>
                        <td>
                          {regulation.dateValidation
                            ? new Date(regulation.dateValidation).toLocaleDateString("fr-FR")
                            : "—"}
                        </td>
                        <td>
                          <span className={`${getStatusBadge(regulation.statut)} flex items-center`}>
                            {getStatusIcon(regulation.statut)}
                            <span className="ml-1">{regulation.statut || "—"}</span>
                          </span>
                        </td>
                        <td>
                          <div className="flex flex-wrap gap-2">
                            <button
                              onClick={() => handleVoirDetails(regulation)}
                              className="text-orange-600 hover:text-orange-800 font-medium text-sm"
                            >
                              Détails
                            </button>
                            {canUserExecuteV2Demande(regulation) && (
                              <button
                                type="button"
                                onClick={() => void handleExecuterDemandeV2(regulation)}
                                className="text-emerald-700 hover:text-emerald-900 font-medium text-sm"
                              >
                                Exécuter
                              </button>
                            )}
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}

        {activeTab === "excedentaires" && (
          <div className="card">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-4">
              <h3 className="text-lg font-semibold text-gray-900">
                {excedentDeficitTabPrefix} Excédentaires
              </h3>
              <div className="flex items-center gap-2">
                <label className="text-sm text-gray-600">Année scolaire :</label>
                <select
                  value={anneeScolaireId ?? ""}
                  onChange={(e) => setAnneeScolaireId(e.target.value ? Number(e.target.value) : null)}
                  className="border border-gray-300 rounded px-3 py-1.5 text-sm"
                  disabled={anneesLoading || anneesScolaires.length === 0}
                >
                  <option value="">—</option>
                  {anneesScolairesAvecId.map((a) => (
                    <option key={a.id} value={a.id}>{a.libelle ?? a.id}</option>
                  ))}
                </select>
              </div>
            </div>
            <p className="text-sm text-gray-600 mb-4">
              {isIeppUser
                ? "EPP où la quantité reçue dépasse l'effectif de classe (par matière et niveau) sur l'année sélectionnée."
                : "Par IEPP : EPP où la quantité reçue dépasse l'effectif de classe (comme la vue IEPP, mais pour tout le périmètre DRENA)."}
            </p>
            {loadingExcedentaires ? (
              <p className="text-gray-500">Chargement...</p>
            ) : isIeppUser ? (
              eppExcedentaires.length === 0 ? (
                <div className="p-4 bg-gray-50 rounded-lg text-gray-600 text-sm">
                  Aucun EPP excédentaire pour cette année, ou veuillez sélectionner une année scolaire.
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-4 py-2 text-left text-xs font-medium text-gray-600">EPP</th>
                        <th className="px-4 py-2 text-left text-xs font-medium text-gray-600">Matière</th>
                        <th className="px-4 py-2 text-left text-xs font-medium text-gray-600">Niveau</th>
                        <th className="px-4 py-2 text-right text-xs font-medium text-gray-600">Effectif classe</th>
                        <th className="px-4 py-2 text-right text-xs font-medium text-gray-600">Quantité reçue</th>
                        <th className="px-4 py-2 text-right text-xs font-medium text-gray-600">Excédent</th>
                        <th className="px-4 py-2 text-right text-xs font-medium text-gray-600">Total EPP</th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {eppExcedentaires.flatMap((epp) =>
                        epp.combinaisonsExcedentaires.map((c, i) => (
                          <tr key={`${epp.eppId}-${c.matiereId}-${c.niveauId}-${i}`}>
                            {i === 0 ? (
                              <td rowSpan={epp.combinaisonsExcedentaires.length} className="px-4 py-2 text-sm font-medium text-gray-900 align-top">
                                {epp.eppCode} — {epp.eppLibelle}
                              </td>
                            ) : null}
                            <td className="px-4 py-2 text-sm text-gray-700">{c.matiereLibelle}</td>
                            <td className="px-4 py-2 text-sm text-gray-700">{c.niveauLibelle}</td>
                            <td className="px-4 py-2 text-sm text-right">{c.effectifClasse}</td>
                            <td className="px-4 py-2 text-sm text-right">{c.quantiteRecueTotale}</td>
                            <td className="px-4 py-2 text-sm text-right font-medium text-amber-700">{c.excedent}</td>
                            {i === 0 ? (
                              <td rowSpan={epp.combinaisonsExcedentaires.length} className="px-4 py-2 text-sm text-right font-medium align-top">
                                {epp.totalExcedentaire}
                              </td>
                            ) : null}
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              )
            ) : !drenaScopeForAggregates ? (
              <div className="p-4 bg-gray-50 rounded-lg text-gray-600 text-sm">
                {isDafUser ? "Sélectionnez une DRENA pour afficher les excédents." : "Périmètre DRENA indisponible."}
              </div>
            ) : ieppAggExcedentaires.length === 0 ? (
              <div className="p-4 bg-gray-50 rounded-lg text-gray-600 text-sm">
                Aucun IEPP avec EPP excédentaires pour cette année.
              </div>
            ) : (
              <div className="space-y-8">
                {ieppAggExcedentaires.map((iepp) => (
                  <div key={iepp.ieppId}>
                    <h4 className="text-sm font-semibold text-gray-800 mb-2">
                      {iepp.ieppLibelle} ({iepp.ieppCode})
                    </h4>
                    <div className="overflow-x-auto">
                      <table className="min-w-full divide-y divide-gray-200">
                        <thead className="bg-gray-50">
                          <tr>
                            <th className="px-4 py-2 text-left text-xs font-medium text-gray-600">EPP</th>
                            <th className="px-4 py-2 text-left text-xs font-medium text-gray-600">Matière</th>
                            <th className="px-4 py-2 text-left text-xs font-medium text-gray-600">Niveau</th>
                            <th className="px-4 py-2 text-right text-xs font-medium text-gray-600">Effectif classe</th>
                            <th className="px-4 py-2 text-right text-xs font-medium text-gray-600">Quantité reçue</th>
                            <th className="px-4 py-2 text-right text-xs font-medium text-gray-600">Excédent</th>
                            <th className="px-4 py-2 text-right text-xs font-medium text-gray-600">Total EPP</th>
                          </tr>
                        </thead>
                        <tbody className="bg-white divide-y divide-gray-200">
                          {(iepp.eppExcedentaires ?? []).flatMap((epp) =>
                            (epp.combinaisonsExcedentaires ?? []).map((c, i) => (
                              <tr key={`${iepp.ieppId}-${epp.eppId}-${c.matiereId}-${c.niveauId}-${i}`}>
                                {i === 0 ? (
                                  <td rowSpan={epp.combinaisonsExcedentaires.length} className="px-4 py-2 text-sm font-medium text-gray-900 align-top">
                                    {epp.eppCode} — {epp.eppLibelle}
                                  </td>
                                ) : null}
                                <td className="px-4 py-2 text-sm text-gray-700">{c.matiereLibelle}</td>
                                <td className="px-4 py-2 text-sm text-gray-700">{c.niveauLibelle}</td>
                                <td className="px-4 py-2 text-sm text-right">{c.effectifClasse}</td>
                                <td className="px-4 py-2 text-sm text-right">{c.quantiteRecueTotale}</td>
                                <td className="px-4 py-2 text-sm text-right font-medium text-amber-700">{c.excedent}</td>
                                {i === 0 ? (
                                  <td rowSpan={epp.combinaisonsExcedentaires.length} className="px-4 py-2 text-sm text-right font-medium align-top">
                                    {epp.totalExcedentaire}
                                  </td>
                                ) : null}
                              </tr>
                            ))
                          )}
                        </tbody>
                      </table>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {activeTab === "deficitaires" && (
          <div className="card">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-4">
              <h3 className="text-lg font-semibold text-gray-900">
                {excedentDeficitTabPrefix} Déficitaires
              </h3>
              <div className="flex items-center gap-2 flex-wrap">
                <label className="text-sm text-gray-600">Année scolaire :</label>
                <select
                  value={anneeScolaireId ?? ""}
                  onChange={(e) => setAnneeScolaireId(e.target.value ? Number(e.target.value) : null)}
                  className="border border-gray-300 rounded px-3 py-1.5 text-sm"
                  disabled={anneesLoading || anneesScolaires.length === 0}
                >
                  <option value="">—</option>
                  {anneesScolairesAvecId.map((a) => (
                    <option key={a.id} value={a.id}>{a.libelle ?? a.id}</option>
                  ))}
                </select>
                {canActRegulation && effectiveIeppId && isIeppUser && (
                  <>
                    <button
                      onClick={() => {
                        setSelectedEPPForRedistribution(undefined)
                        setShowRedistribuerModalV2(true)
                      }}
                      className="btn-primary"
                    >
                      <PlusIcon className="h-5 w-5 mr-2" />
                      Redistribuer du Stock (Avancé)
                    </button>
                    {anneeScolaireId != null && (
                      <button
                        type="button"
                        onClick={() => setShowRegulationV2IeppModal(true)}
                        className="btn-outline border-orange-300 text-orange-900"
                      >
                        <ArrowsRightLeftIcon className="h-5 w-5 mr-2 inline" />
                        Demande manuelle (multi-EPP)
                      </button>
                    )}
                  </>
                )}
                {isRegulationMultiLevelEnabled() &&
                  canActRegulation &&
                  isDrenaUser &&
                  user?.structure?.id &&
                  anneeScolaireId != null && (
                    <button
                      type="button"
                      onClick={() => setHubModalScope("DRENA_IEPP")}
                      className="btn-outline border-violet-300 text-violet-800"
                    >
                      Hub DRENA → IEPP (détail)
                    </button>
                  )}
                {isRegulationMultiLevelEnabled() &&
                  canActRegulation &&
                  isDafUser &&
                  selectedDafDrenaId != null &&
                  user?.structure?.id &&
                  anneeScolaireId != null && (
                    <>
                      <button
                        type="button"
                        onClick={() => setHubModalScope("DRENA_IEPP")}
                        className="btn-outline border-violet-300 text-violet-800"
                        title="Utilise la DRENA sélectionnée comme hub source"
                      >
                        Hub DRENA → IEPP (détail)
                      </button>
                      <button
                        type="button"
                        onClick={() => setHubModalScope("DAF_DRENA")}
                        className="btn-outline border-indigo-300 text-indigo-800"
                      >
                        Hub DAF → DRENA (détail)
                      </button>
                    </>
                  )}
              </div>
            </div>
            <p className="text-sm text-gray-600 mb-4">
              {isIeppUser
                ? "EPP pour lesquels l'effectif classe dépasse la quantité reçue, par matière/niveau."
                : "Par IEPP : EPP déficitaires (même logique que la vue IEPP), pour tout le périmètre DRENA sélectionné."}
            </p>
            {loadingDeficitaires ? (
              <p className="text-gray-500">Chargement...</p>
            ) : isIeppUser ? (
              eppDeficitaires.length === 0 ? (
                <div className="p-4 bg-gray-50 rounded-lg text-gray-600 text-sm">
                  Aucun EPP déficitaire pour cette année, ou veuillez sélectionner une année scolaire.
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-4 py-2 text-left text-xs font-medium text-gray-600">EPP</th>
                        <th className="px-4 py-2 text-left text-xs font-medium text-gray-600">Matière</th>
                        <th className="px-4 py-2 text-left text-xs font-medium text-gray-600">Niveau</th>
                        <th className="px-4 py-2 text-right text-xs font-medium text-gray-600">Effectif classe</th>
                        <th className="px-4 py-2 text-right text-xs font-medium text-gray-600">Reçu</th>
                        <th className="px-4 py-2 text-right text-xs font-medium text-gray-600">Déficit</th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {eppDeficitaires.flatMap((epp) =>
                        epp.combinaisonsDeficitaires.map((c, i) => (
                          <tr key={`${epp.eppId}-${c.matiereId}-${c.niveauId}-${i}`}>
                            {i === 0 ? (
                              <td rowSpan={epp.combinaisonsDeficitaires.length} className="px-4 py-2 text-sm font-medium text-gray-900 align-top">
                                {epp.eppCode} — {epp.eppLibelle}
                              </td>
                            ) : null}
                            <td className="px-4 py-2 text-sm text-gray-700">{c.matiereLibelle}</td>
                            <td className="px-4 py-2 text-sm text-gray-700">{c.niveauLibelle}</td>
                            <td className="px-4 py-2 text-sm text-right">{c.effectifClasse}</td>
                            <td className="px-4 py-2 text-sm text-right">{c.quantiteRecueTotale}</td>
                            <td className="px-4 py-2 text-sm text-right font-medium text-red-700">{c.deficit}</td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              )
            ) : !drenaScopeForAggregates ? (
              <div className="p-4 bg-gray-50 rounded-lg text-gray-600 text-sm">
                {isDafUser ? "Sélectionnez une DRENA pour afficher les déficits." : "Périmètre DRENA indisponible."}
              </div>
            ) : ieppAggDeficitaires.length === 0 ? (
              <div className="p-4 bg-gray-50 rounded-lg text-gray-600 text-sm">
                Aucun IEPP avec EPP déficitaires pour cette année.
              </div>
            ) : (
              <div className="space-y-8">
                {ieppAggDeficitaires.map((iepp) => (
                  <div key={iepp.ieppId}>
                    <h4 className="text-sm font-semibold text-gray-800 mb-2">
                      {iepp.ieppLibelle} ({iepp.ieppCode})
                    </h4>
                    <div className="overflow-x-auto">
                      <table className="min-w-full divide-y divide-gray-200">
                        <thead className="bg-gray-50">
                          <tr>
                            <th className="px-4 py-2 text-left text-xs font-medium text-gray-600">EPP</th>
                            <th className="px-4 py-2 text-left text-xs font-medium text-gray-600">Matière</th>
                            <th className="px-4 py-2 text-left text-xs font-medium text-gray-600">Niveau</th>
                            <th className="px-4 py-2 text-right text-xs font-medium text-gray-600">Effectif classe</th>
                            <th className="px-4 py-2 text-right text-xs font-medium text-gray-600">Reçu</th>
                            <th className="px-4 py-2 text-right text-xs font-medium text-gray-600">Déficit</th>
                          </tr>
                        </thead>
                        <tbody className="bg-white divide-y divide-gray-200">
                          {(iepp.eppDeficitaires ?? []).flatMap((epp) =>
                            (epp.combinaisonsDeficitaires ?? []).map((c, i) => (
                              <tr key={`${iepp.ieppId}-${epp.eppId}-${c.matiereId}-${c.niveauId}-${i}`}>
                                {i === 0 ? (
                                  <td rowSpan={epp.combinaisonsDeficitaires.length} className="px-4 py-2 text-sm font-medium text-gray-900 align-top">
                                    {epp.eppCode} — {epp.eppLibelle}
                                  </td>
                                ) : null}
                                <td className="px-4 py-2 text-sm text-gray-700">{c.matiereLibelle}</td>
                                <td className="px-4 py-2 text-sm text-gray-700">{c.niveauLibelle}</td>
                                <td className="px-4 py-2 text-sm text-right">{c.effectifClasse}</td>
                                <td className="px-4 py-2 text-sm text-right">{c.quantiteRecueTotale}</td>
                                <td className="px-4 py-2 text-sm text-right font-medium text-red-700">{c.deficit}</td>
                              </tr>
                            ))
                          )}
                        </tbody>
                      </table>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Modals */}
        <ProgrammerRegulationModal
          isOpen={showProgrammerModal}
          ieppStructureId={effectiveIeppId ?? undefined}
          onClose={() => setShowProgrammerModal(false)}
          onSuccess={() => {
            loadRegulations()
            setShowProgrammerModal(false)
          }}
        />

        <ValiderRegulationModal
          isOpen={showValiderModal}
          regulation={selectedRegulationForValidation}
          onClose={() => {
            setShowValiderModal(false)
            setSelectedRegulationForValidation(null)
          }}
          onSuccess={() => {
            loadRegulations()
            setShowValiderModal(false)
            setSelectedRegulationForValidation(null)
          }}
        />

        <DetailsRegulationModal
          isOpen={showDetailsModal}
          regulationId={selectedRegulation?.id || null}
          onClose={() => {
            setShowDetailsModal(false)
            setSelectedRegulation(null)
          }}
        />

        <RedistribuerStockModal
          isOpen={showRedistribuerModal}
          eppId={selectedEPPForRedistribution}
          onClose={() => {
            setShowRedistribuerModal(false)
            setSelectedEPPForRedistribution(undefined)
          }}
          onSuccess={() => {
            loadRegulations()
            setShowRedistribuerModal(false)
            setSelectedEPPForRedistribution(undefined)
          }}
        />

        <RedistribuerStockModalV2
          isOpen={showRedistribuerModalV2}
          eppId={selectedEPPForRedistribution}
          ieppStructureId={effectiveIeppId ?? undefined}
          onClose={() => {
            setShowRedistribuerModalV2(false)
            setSelectedEPPForRedistribution(undefined)
          }}
          onSuccess={() => {
            loadRegulations()
            setShowRedistribuerModalV2(false)
            setSelectedEPPForRedistribution(undefined)
          }}
        />

        {effectiveIeppId != null && anneeScolaireId != null && (
          <RegulationV2IeppDemandeModal
            isOpen={showRegulationV2IeppModal}
            ieppId={effectiveIeppId}
            anneeScolaireId={anneeScolaireId}
            onClose={() => setShowRegulationV2IeppModal(false)}
            onSuccess={() => {
              void loadRegulations()
              void loadV2PendingLines()
            }}
          />
        )}

        {hubModalScope != null && anneeScolaireId != null && hubStockModalHubId > 0 && (
          <RedistribuerHubStockModalV2
            isOpen
            scope={hubModalScope}
            hubStructureId={hubStockModalHubId}
            drenaDestinationId={hubModalScope === "DAF_DRENA" ? selectedDafDrenaId ?? undefined : undefined}
            anneeScolaireId={anneeScolaireId}
            onClose={() => setHubModalScope(null)}
            onSuccess={() => {
              loadRegulations()
              setHubModalScope(null)
            }}
          />
        )}
      </div>
    </MainLayout>
  )
}
