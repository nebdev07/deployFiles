"use client"

import { useEffect, useMemo, useState } from "react"
import MainLayout from "@/components/layout/main-layout"
import { useAuth } from "../../providers"
import { useAnneesScolaires } from "@/hooks/use-annees-scolaires"
import type { AnneeScolaire } from "@/lib/types/entities"
import { regulationService, type RegulationDto } from "@/lib/services/regulation.service"
import { dashboardService } from "@/lib/services/dashboard.service"
import { structuresService } from "@/lib/services/structures.service"
import { matiereService } from "@/lib/services/matiere.service"
import { niveauScolaireService } from "@/lib/services/niveau-scolaire.service"
import {
  regulationV2Service,
  type RegulationV2PendingRow,
  type RegulationV2SuiviLigneRow,
} from "@/lib/services/regulation-v2.service"
import {
  parseAgregatItems,
  flattenExcedents,
  mobilisationKey,
  recordToMobilisationEntries,
  validateMobilisationAgainstAgregat,
  validateMobilisationAgainstExcedent,
  buildCreerDemandeSources,
  mobilisedSumForCombo,
  type AgregatDeficitRow,
  type ExcedentFlatRow,
} from "@/lib/regulation-v2-mobilisation"
import { engagedByMatiereNiveauFromSuivi, engagedBySourceKeyFromSuivi } from "@/lib/regulation-v2-engaged"
import { toast } from "sonner"
import { getApiErrorMessage } from "@/lib/utils/api-error-message"
import { canAccessRegulationPage } from "@/lib/utils/functionality-permissions"
import {
  ArrowsRightLeftIcon,
  CheckCircleIcon,
  ChevronDownIcon,
  ClipboardDocumentListIcon,
} from "@heroicons/react/24/outline"
import { RegulationV2AjustementModal } from "@/components/regulation-v2/RegulationV2AjustementModal"
import { RegulationV2IeppValidationModal } from "@/components/regulation-v2/RegulationV2IeppValidationModal"
import { formatRegulationReferenceForDisplay } from "@/lib/regulation-display"
import PaginationControls from "@/components/ui/pagination-controls"

/** Ligne agrégée DRENA (déficits ou excédents par IEPP). */
type DrenaIeppOptionRow = {
  ieppId: number
  ieppCode?: string
  ieppLibelle?: string
}

type EppExcRow = {
  eppId: number
  eppCode: string
  eppLibelle: string
  combinaisonsExcedentaires: Array<{
    matiereId: number
    matiereLibelle: string
    niveauId: number
    niveauLibelle: string
    excedent: number
  }>
}

type DrenaCombDeficit = {
  matiereId: number
  niveauId: number
  matiereLibelle?: string
  niveauLibelle?: string
  deficit: number
}

type DrenaEppDeficitaire = {
  eppId: number
  eppCode?: string
  eppLibelle?: string
  combinaisonsDeficitaires?: DrenaCombDeficit[]
}

type DrenaIeppDeficitBundle = DrenaIeppOptionRow & {
  eppDeficitaires: DrenaEppDeficitaire[]
}

type DrenaIeppExcBundle = DrenaIeppOptionRow & {
  eppExcedentaires: EppExcRow[]
}

/** Une ligne du tableau synthèse DRENA : même agrégation matière+niveau que l’IEPP, mais par IEPP du périmètre. */
type DrenaOverviewRow = {
  ieppId: number
  ieppCode?: string
  ieppLibelle?: string
  matiereId: number
  niveauId: number
  matiereLibelle: string
  niveauLibelle: string
  besoinTotal: number
  excedentTotal: number
}

/** Ligne besoins DRENA multi-IEPP (même structure que l’agrégat IEPP + repartition EPP). */
type DrenaBesoinsAgregatRow = AgregatDeficitRow & {
  ieppId: number
  ieppLibelle?: string
  ieppCode?: string
}

/** Ligne excédentaire DRENA multi-IEPP (périmètre). */
type DrenaExcedentFlatRow = ExcedentFlatRow & { ieppId: number; ieppLibelle?: string }

type DrenaMobExcBlock = {
  ieppId: number
  ieppLibelle?: string
  eppChoices: Array<{ eppId: number; lib: string; code: string }>
  rows: DrenaExcedentFlatRow[]
}

type DrenaBesoinsIeppBlock = {
  ieppId: number
  ieppLibelle?: string
  ieppCode?: string
  rows: DrenaBesoinsAgregatRow[]
}

function numFromUnknown(v: unknown): number {
  const n = typeof v === "number" ? v : Number(v)
  return Number.isFinite(n) ? n : 0
}

function parseDrenaDeficitBundles(items: unknown[]): DrenaIeppDeficitBundle[] {
  const out: DrenaIeppDeficitBundle[] = []
  for (const raw of items) {
    if (raw == null || typeof raw !== "object") continue
    const r = raw as Record<string, unknown>
    const ieppId = numFromUnknown(r.ieppId ?? r.iepp_id)
    if (ieppId <= 0) continue
    const eppsRaw = r.eppDeficitaires ?? r.epp_deficitaires
    if (!Array.isArray(eppsRaw)) continue
    const eppDeficitaires: DrenaEppDeficitaire[] = []
    for (const er of eppsRaw) {
      if (er == null || typeof er !== "object") continue
      const e = er as Record<string, unknown>
      const eppId = numFromUnknown(e.eppId ?? e.epp_id)
      const eppLibelle =
        e.eppLibelle != null ? String(e.eppLibelle) : e.epp_libelle != null ? String(e.epp_libelle) : undefined
      const eppCode = e.eppCode != null ? String(e.eppCode) : e.epp_code != null ? String(e.epp_code) : undefined
      const combsRaw = e.combinaisonsDeficitaires ?? e.combinaisons_deficitaires
      const combinaisonsDeficitaires: DrenaCombDeficit[] = []
      if (Array.isArray(combsRaw)) {
        for (const c of combsRaw) {
          if (c == null || typeof c !== "object") continue
          const x = c as Record<string, unknown>
          const matiereId = numFromUnknown(x.matiereId ?? x.matiere_id)
          const niveauId = numFromUnknown(x.niveauId ?? x.niveau_id)
          if (matiereId <= 0 || niveauId <= 0) continue
          combinaisonsDeficitaires.push({
            matiereId,
            niveauId,
            matiereLibelle: x.matiereLibelle != null ? String(x.matiereLibelle) : x.matiere_libelle != null ? String(x.matiere_libelle) : undefined,
            niveauLibelle: x.niveauLibelle != null ? String(x.niveauLibelle) : x.niveau_libelle != null ? String(x.niveau_libelle) : undefined,
            deficit: Math.max(0, numFromUnknown(x.deficit)),
          })
        }
      }
      if (combinaisonsDeficitaires.length > 0) eppDeficitaires.push({ eppId, eppCode, eppLibelle, combinaisonsDeficitaires })
    }
    if (eppDeficitaires.length === 0) continue
    out.push({
      ieppId,
      ieppCode: r.ieppCode != null ? String(r.ieppCode) : r.iepp_code != null ? String(r.iepp_code) : undefined,
      ieppLibelle: r.ieppLibelle != null ? String(r.ieppLibelle) : r.iepp_libelle != null ? String(r.iepp_libelle) : undefined,
      eppDeficitaires,
    })
  }
  return out
}

function parseDrenaExcedentBundles(items: unknown[]): DrenaIeppExcBundle[] {
  const out: DrenaIeppExcBundle[] = []
  for (const raw of items) {
    if (raw == null || typeof raw !== "object") continue
    const r = raw as Record<string, unknown>
    const ieppId = numFromUnknown(r.ieppId ?? r.iepp_id)
    if (ieppId <= 0) continue
    const eppsRaw = r.eppExcedentaires ?? r.epp_excedentaires
    if (!Array.isArray(eppsRaw)) continue
    const eppExcedentaires: EppExcRow[] = []
    for (const er of eppsRaw) {
      if (er == null || typeof er !== "object") continue
      const e = er as Record<string, unknown>
      const eppId = numFromUnknown(e.eppId ?? e.epp_id)
      const eppCode = String(e.eppCode ?? e.epp_code ?? "")
      const eppLibelle = String(e.eppLibelle ?? e.epp_libelle ?? "")
      const combsRaw = e.combinaisonsExcedentaires ?? e.combinaisons_excedentaires
      const combinaisonsExcedentaires: EppExcRow["combinaisonsExcedentaires"] = []
      if (Array.isArray(combsRaw)) {
        for (const c of combsRaw) {
          if (c == null || typeof c !== "object") continue
          const x = c as Record<string, unknown>
          const matiereId = numFromUnknown(x.matiereId ?? x.matiere_id)
          const niveauId = numFromUnknown(x.niveauId ?? x.niveau_id)
          if (matiereId <= 0 || niveauId <= 0) continue
          const excedent = Math.max(0, numFromUnknown(x.excedent))
          if (excedent <= 0) continue
          combinaisonsExcedentaires.push({
            matiereId,
            niveauId,
            matiereLibelle: String(x.matiereLibelle ?? x.matiere_libelle ?? ""),
            niveauLibelle: String(x.niveauLibelle ?? x.niveau_libelle ?? ""),
            excedent,
          })
        }
      }
      if (combinaisonsExcedentaires.length > 0) {
        eppExcedentaires.push({ eppId, eppCode, eppLibelle, combinaisonsExcedentaires })
      }
    }
    if (eppExcedentaires.length === 0) continue
    out.push({
      ieppId,
      ieppCode: r.ieppCode != null ? String(r.ieppCode) : r.iepp_code != null ? String(r.iepp_code) : undefined,
      ieppLibelle: r.ieppLibelle != null ? String(r.ieppLibelle) : r.iepp_libelle != null ? String(r.iepp_libelle) : undefined,
      eppExcedentaires,
    })
  }
  return out
}

function buildDrenaOverviewRows(defBundles: DrenaIeppDeficitBundle[], excBundles: DrenaIeppExcBundle[]): DrenaOverviewRow[] {
  type Acc = {
    ieppId: number
    ieppCode?: string
    ieppLibelle?: string
    matiereId: number
    niveauId: number
    matiereLibelle: string
    niveauLibelle: string
    besoinTotal: number
    excedentTotal: number
  }
  const byKey = new Map<string, Acc>()
  const keyOf = (ieppId: number, matiereId: number, niveauId: number) => `${ieppId}-${matiereId}-${niveauId}`

  for (const b of defBundles) {
    for (const epp of b.eppDeficitaires) {
      for (const c of epp.combinaisonsDeficitaires ?? []) {
        const k = keyOf(b.ieppId, c.matiereId, c.niveauId)
        const prev = byKey.get(k)
        const add = c.deficit
        if (prev) {
          prev.besoinTotal += add
        } else {
          byKey.set(k, {
            ieppId: b.ieppId,
            ieppCode: b.ieppCode,
            ieppLibelle: b.ieppLibelle,
            matiereId: c.matiereId,
            niveauId: c.niveauId,
            matiereLibelle: c.matiereLibelle?.trim() || "—",
            niveauLibelle: c.niveauLibelle?.trim() || "—",
            besoinTotal: add,
            excedentTotal: 0,
          })
        }
      }
    }
  }

  for (const b of excBundles) {
    for (const epp of b.eppExcedentaires) {
      for (const c of epp.combinaisonsExcedentaires ?? []) {
        const k = keyOf(b.ieppId, c.matiereId, c.niveauId)
        const prev = byKey.get(k)
        const add = c.excedent
        if (prev) {
          prev.excedentTotal += add
        } else {
          byKey.set(k, {
            ieppId: b.ieppId,
            ieppCode: b.ieppCode,
            ieppLibelle: b.ieppLibelle,
            matiereId: c.matiereId,
            niveauId: c.niveauId,
            matiereLibelle: c.matiereLibelle?.trim() || "—",
            niveauLibelle: c.niveauLibelle?.trim() || "—",
            besoinTotal: 0,
            excedentTotal: add,
          })
        }
      }
    }
  }

  return [...byKey.values()].sort((a, b) => {
    const la = (a.ieppLibelle ?? a.ieppCode ?? "").localeCompare(b.ieppLibelle ?? b.ieppCode ?? "", "fr")
    if (la !== 0) return la
    const lm = a.matiereLibelle.localeCompare(b.matiereLibelle, "fr")
    if (lm !== 0) return lm
    return a.niveauLibelle.localeCompare(b.niveauLibelle, "fr")
  })
}

function buildDrenaConsolidatedAgregats(defBundles: DrenaIeppDeficitBundle[]): DrenaBesoinsAgregatRow[] {
  type Rep = Map<number, { eppLibelle?: string; deficit: number }>
  type Acc = {
    ieppId: number
    ieppLibelle?: string
    ieppCode?: string
    matiereId: number
    niveauId: number
    matiereLibelle?: string
    niveauLibelle?: string
    deficitTotal: number
    rep: Rep
  }
  const byKey = new Map<string, Acc>()
  for (const b of defBundles) {
    for (const epp of b.eppDeficitaires) {
      for (const c of epp.combinaisonsDeficitaires ?? []) {
        const def = Math.max(0, c.deficit)
        if (def <= 0) continue
        const k = `${b.ieppId}-${c.matiereId}-${c.niveauId}`
        let row = byKey.get(k)
        if (!row) {
          row = {
            ieppId: b.ieppId,
            ieppLibelle: b.ieppLibelle,
            ieppCode: b.ieppCode,
            matiereId: c.matiereId,
            niveauId: c.niveauId,
            matiereLibelle: c.matiereLibelle,
            niveauLibelle: c.niveauLibelle,
            deficitTotal: 0,
            rep: new Map(),
          }
          byKey.set(k, row)
        }
        row.deficitTotal += def
        const prev = row.rep.get(epp.eppId)?.deficit ?? 0
        const lab = epp.eppLibelle?.trim() || undefined
        row.rep.set(epp.eppId, { eppLibelle: lab, deficit: prev + def })
      }
    }
  }
  return [...byKey.values()]
    .map((r) => ({
      ieppId: r.ieppId,
      ieppLibelle: r.ieppLibelle,
      ieppCode: r.ieppCode,
      matiereId: r.matiereId,
      niveauId: r.niveauId,
      matiereLibelle: r.matiereLibelle,
      niveauLibelle: r.niveauLibelle,
      deficitTotal: r.deficitTotal,
      repartitionParEpp: [...r.rep.entries()]
        .map(([eppId, v]) => ({ eppId, eppLibelle: v.eppLibelle, deficit: v.deficit }))
        .sort((a, b) => (a.eppLibelle ?? `EPP ${a.eppId}`).localeCompare(b.eppLibelle ?? `EPP ${b.eppId}`, "fr")),
    }))
    .sort((a, b) => {
      const li = (a.ieppLibelle ?? a.ieppCode ?? "").localeCompare(b.ieppLibelle ?? b.ieppCode ?? "", "fr")
      if (li !== 0) return li
      const lm = (a.matiereLibelle ?? "").localeCompare(b.matiereLibelle ?? "", "fr")
      if (lm !== 0) return lm
      return (a.niveauLibelle ?? "").localeCompare(b.niveauLibelle ?? "", "fr")
    })
}

function flattenDrenaExcWithIepp(excBundles: DrenaIeppExcBundle[]): DrenaExcedentFlatRow[] {
  const rows: DrenaExcedentFlatRow[] = []
  for (const b of excBundles) {
    for (const e of b.eppExcedentaires) {
      for (const c of e.combinaisonsExcedentaires ?? []) {
        const excedent = Number(c.excedent ?? 0) || 0
        if (excedent <= 0) continue
        rows.push({
          eppId: e.eppId,
          matiereId: c.matiereId,
          niveauId: c.niveauId,
          matiereLibelle: String(c.matiereLibelle ?? ""),
          niveauLibelle: String(c.niveauLibelle ?? ""),
          excedent,
          ieppId: b.ieppId,
          ieppLibelle: b.ieppLibelle,
        })
      }
    }
  }
  return rows.sort((a, b) => {
    const li = (a.ieppLibelle ?? "").localeCompare(b.ieppLibelle ?? "", "fr")
    if (li !== 0) return li
    return a.matiereLibelle.localeCompare(b.matiereLibelle, "fr")
  })
}

function normalizeItems<T>(r: { items?: unknown }): T[] {
  const raw = r.items
  if (Array.isArray(raw)) return raw as T[]
  if (raw != null) return [raw as T]
  return []
}

function clientTotalPages(totalCount: number, pageSize: number): number {
  const ps = pageSize > 0 ? pageSize : 10
  return Math.max(1, Math.ceil(totalCount / ps))
}

function sliceClientPage<T>(items: T[], page: number, pageSize: number): T[] {
  const ps = pageSize > 0 ? pageSize : 10
  const tp = clientTotalPages(items.length, ps)
  const p = Math.min(Math.max(1, page), tp)
  const start = (p - 1) * ps
  return items.slice(start, start + ps)
}

/** Rôles rattachés à une EPP : on n’affiche pas le nom des autres écoles (source / destination). */
function hidePeerEppNamesForRole(roleCode: string): boolean {
  const rc = roleCode.trim().toUpperCase()
  return rc === "DIRECTEUR" || rc === "MAITRE" || rc === "COGES"
}

function formatPendingLigneLibelles(
  l: RegulationV2PendingRow,
  opts?: { hidePeerEppNames?: boolean }
): string {
  const mat = l.matiereLibelle?.trim()
    ? l.matiereCode
      ? `${l.matiereLibelle} (${l.matiereCode})`
      : l.matiereLibelle
    : null
  const niv = l.niveauLibelle?.trim()
    ? l.niveauCode
      ? `${l.niveauLibelle} (${l.niveauCode})`
      : l.niveauLibelle
    : null
  if (opts?.hidePeerEppNames) {
    const parts = [mat && niv ? `${mat} — ${niv}` : mat || niv, `qté ${l.quantite}`] as (string | false | null)[]
    return parts.filter(Boolean).join(" · ")
  }
  const dest = l.structureDestLibelle?.trim()
    ? l.structureDestCode
      ? `${l.structureDestLibelle} (${l.structureDestCode})`
      : l.structureDestLibelle
    : null
  const src = l.structureSourceLibelle?.trim()
    ? l.structureSourceCode
      ? `${l.structureSourceLibelle} (${l.structureSourceCode})`
      : l.structureSourceLibelle
    : null
  const cote = l.cote === "DESTINATION" ? "DESTINATION" : "SOURCE"
  const parts =
    cote === "DESTINATION"
      ? ([mat && niv ? `${mat} — ${niv}` : mat || niv, src && `depuis ${src}`, `qté ${l.quantite}`] as (string | false | null)[])
      : ([mat && niv ? `${mat} — ${niv}` : mat || niv, dest && `vers ${dest}`, `qté ${l.quantite}`] as (string | false | null)[])
  return parts.filter(Boolean).join(" · ")
}

function libelleStatutLigneV2(code: string | undefined): string {
  const c = (code ?? "").trim().toUpperCase()
  if (c === "EN_ATTENTE") return "En attente d’accord"
  if (c === "ACCEPTE") return "Accepté"
  if (c === "REFUSE") return "Refusé"
  return code?.trim() ? code : "—"
}

function statutLigneV2Upper(code: string | undefined): string {
  return (code ?? "").trim().toUpperCase()
}

function badgeClassStatutLigneV2(code: string | undefined): string {
  const c = (code ?? "").trim().toUpperCase()
  if (c === "ACCEPTE") return "bg-emerald-100 text-emerald-900"
  if (c === "REFUSE") return "bg-red-100 text-red-900"
  if (c === "EN_ATTENTE") return "bg-amber-100 text-amber-900"
  return "bg-gray-100 text-gray-800"
}

function fmtStructureV2Suivi(
  libelle: string | undefined,
  code: string | undefined,
  structureId: number | undefined
): string {
  const l = libelle?.trim()
  if (l && code) return `${l} (${code})`
  if (l) return l
  if (code?.trim()) return code.trim()
  if (structureId != null) return `#${structureId}`
  return "—"
}

type SuiviLignesEppGroupe = {
  structureSourceId: number
  label: string
  rows: RegulationV2SuiviLigneRow[]
}

/** Un EPP source = une structure fille ; panneau repliable (dropdown). */
function SuiviEppSourceAccordion({ group, defaultOpen }: { group: SuiviLignesEppGroupe; defaultOpen: boolean }) {
  const [open, setOpen] = useState(defaultOpen)
  return (
    <div className="rounded-lg border border-gray-200 overflow-hidden bg-white">
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        aria-expanded={open}
        className="flex w-full cursor-pointer items-center gap-3 border-l-4 border-l-orange-600 bg-gray-50 px-3 py-2.5 text-left text-sm hover:bg-gray-100"
      >
        <ChevronDownIcon
          aria-hidden
          className={`h-5 w-5 shrink-0 text-gray-500 transition-transform ${open ? "rotate-180" : ""}`}
        />
        <span className="min-w-0 flex-1 font-semibold text-gray-900">{group.label}</span>
        <span className="shrink-0 rounded-full bg-orange-100 px-2 py-0.5 text-xs font-medium text-orange-900">
          {group.rows.length} ligne{group.rows.length === 1 ? "" : "s"}
        </span>
      </button>
      {open ? (
        <div className="overflow-x-auto border-t border-gray-200">
          <table className="min-w-full text-sm">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-3 py-2 text-left">Réf. demande</th>
                <th className="px-3 py-2 text-left">EPP destination</th>
                <th className="px-3 py-2 text-left">Matière</th>
                <th className="px-3 py-2 text-left">Niveau</th>
                <th className="px-3 py-2 text-right">Qté</th>
                <th className="px-3 py-2 text-left">Statut ligne</th>
              </tr>
            </thead>
            <tbody>
              {group.rows.map((row) => {
                const dstDisp = fmtStructureV2Suivi(
                  row.structureDestLibelle,
                  row.structureDestCode,
                  row.structureDestId
                )
                const mat = row.matiereLibelle?.trim()
                  ? row.matiereCode
                    ? `${row.matiereLibelle} (${row.matiereCode})`
                    : row.matiereLibelle
                  : row.matiereCode ?? "—"
                const niv = row.niveauLibelle?.trim()
                  ? row.niveauCode
                    ? `${row.niveauLibelle} (${row.niveauCode})`
                    : row.niveauLibelle
                  : row.niveauCode ?? "—"
                return (
                  <tr key={row.ligneId} className="border-t border-gray-100">
                    <td className="px-3 py-2 whitespace-nowrap">
                      {formatRegulationReferenceForDisplay(row.reference) || `REG-${row.regulationId}`}
                    </td>
                    <td className="px-3 py-2 text-gray-800">{dstDisp}</td>
                    <td className="px-3 py-2">{mat}</td>
                    <td className="px-3 py-2">{niv}</td>
                    <td className="px-3 py-2 text-right font-medium">{row.quantite}</td>
                    <td className="px-3 py-2">
                      <span
                        className={`inline-flex rounded px-2 py-0.5 text-xs font-medium ${badgeClassStatutLigneV2(row.statutLigne)}`}
                      >
                        {libelleStatutLigneV2(row.statutLigne)}
                      </span>
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
      ) : null}
    </div>
  )
}

export default function RegulationV2Page() {
  const { user } = useAuth()
  const { anneesScolaires } = useAnneesScolaires()
  const anneesAvecId = anneesScolaires.filter((a): a is AnneeScolaire & { id: number } => typeof a.id === "number")
  const [anneeScolaireId, setAnneeScolaireId] = useState<number | null>(null)
  const [eppExc, setEppExc] = useState<EppExcRow[]>([])
  const [agregats, setAgregats] = useState<AgregatDeficitRow[]>([])
  const [loadingLists, setLoadingLists] = useState(false)
  /** Onglets IEPP : besoins agrégés → saisie mobilisation → prévisualisation / envoi / exécution */
  const [ieppSubTab, setIeppSubTab] = useState<"besoins" | "mobilisation" | "finalisation">("besoins")
  /** Quantités à récupérer : clé `eppId-matiereId-niveauId` */
  const [mobilisationQty, setMobilisationQty] = useState<Record<string, number>>({})
  const [filterMatiereId, setFilterMatiereId] = useState<string>("")
  const [filterNiveauId, setFilterNiveauId] = useState<string>("")
  const [v2Regs, setV2Regs] = useState<RegulationDto[]>([])
  const [suiviLignes, setSuiviLignes] = useState<RegulationV2SuiviLigneRow[]>([])
  const [loadingSuiviLignes, setLoadingSuiviLignes] = useState(false)
  const [pendingLignes, setPendingLignes] = useState<RegulationV2PendingRow[]>([])
  const [dafForm, setDafForm] = useState({
    destStructureId: "",
    matiereId: "",
    niveauId: "",
    quantite: "",
    commentaire: "",
  })
  const [dafDestinationScope, setDafDestinationScope] = useState<"DRENA" | "IEPP" | "EPP">("DRENA")
  const [dafDestinationOptions, setDafDestinationOptions] = useState<
    Array<{ id: number; label: string; type: "DRENA" | "IEPP" | "EPP" }>
  >([])
  const [dafMatieres, setDafMatieres] = useState<Array<{ id: number; code?: string; libelle?: string }>>([])
  const [dafNiveaux, setDafNiveaux] = useState<Array<{ id: number; code?: string; libelle?: string }>>([])
  const [loadingDafDestinations, setLoadingDafDestinations] = useState(false)
  const [loadingDafReferences, setLoadingDafReferences] = useState(false)
  const [ajustementModal, setAjustementModal] = useState<{ regulationId: number; reference?: string } | null>(null)
  const [drenaIeppOptions, setDrenaIeppOptions] = useState<DrenaIeppOptionRow[]>([])
  const [drenaSelectedIeppId, setDrenaSelectedIeppId] = useState<number | null>(null)
  const [loadingDrenaIeppOptions, setLoadingDrenaIeppOptions] = useState(false)
  const [dafDrenaOptions, setDafDrenaOptions] = useState<Array<{ id: number; code: string; libelle: string }>>([])
  const [selectedDafDrenaId, setSelectedDafDrenaId] = useState<number | null>(null)
  const [loadingDafDrenaOptions, setLoadingDafDrenaOptions] = useState(false)
  const [drenaDefBundles, setDrenaDefBundles] = useState<DrenaIeppDeficitBundle[]>([])
  const [drenaExcBundles, setDrenaExcBundles] = useState<DrenaIeppExcBundle[]>([])
  const [drenaDashFilterIeppId, setDrenaDashFilterIeppId] = useState<string>("")
  const [drenaDashFilterMatiereId, setDrenaDashFilterMatiereId] = useState<string>("")
  const [drenaDashFilterNiveauId, setDrenaDashFilterNiveauId] = useState<string>("")
  const [besoinsAgPage, setBesoinsAgPage] = useState(1)
  const [besoinsAgPageSize, setBesoinsAgPageSize] = useState(10)
  const [mobSynthPage, setMobSynthPage] = useState(1)
  const [mobSynthPageSize, setMobSynthPageSize] = useState(10)
  const [mobExcPage, setMobExcPage] = useState(1)
  const [mobExcPageSize, setMobExcPageSize] = useState(10)
  const [previewPage, setPreviewPage] = useState(1)
  const [previewPageSize, setPreviewPageSize] = useState(10)
  const [v2RegsPage, setV2RegsPage] = useState(1)
  const [v2RegsPageSize, setV2RegsPageSize] = useState(10)
  const [pendingPage, setPendingPage] = useState(1)
  const [pendingPageSize, setPendingPageSize] = useState(10)
  const [pendingDestPage, setPendingDestPage] = useState(1)
  const [pendingDestPageSize, setPendingDestPageSize] = useState(10)
  const [suiviGroupsPage, setSuiviGroupsPage] = useState(1)
  const [suiviGroupsPageSize, setSuiviGroupsPageSize] = useState(5)
  /** DRENA périmètre : filtre EPP par IEPP excédentaire (clé = ieppId). */
  const [drenaMobEppFilterByIepp, setDrenaMobEppFilterByIepp] = useState<Record<string, string>>({})
  /** DRENA besoins par IEPP : filtres matière / niveau locaux (clé = ieppId). */
  const [drenaBesoinsMatiereByIepp, setDrenaBesoinsMatiereByIepp] = useState<Record<string, string>>({})
  const [drenaBesoinsNiveauByIepp, setDrenaBesoinsNiveauByIepp] = useState<Record<string, string>>({})
  const [validationIeppModal, setValidationIeppModal] = useState<{ regulationId: number; reference?: string } | null>(
    null
  )

  const roleCode = (user?.role?.code ?? "").trim().toUpperCase()
  const effectiveIeppId: number | null =
    roleCode === "IEPP"
      ? (user as { structureAdministrativeId?: number }).structureAdministrativeId ?? user?.structure?.id ?? null
      : null
  const drenaStructureId: number | null =
    roleCode === "DRENA"
      ? (user as { structureAdministrativeId?: number }).structureAdministrativeId ?? user?.structure?.id ?? null
      : null
  const dafStructureId: number | null = roleCode === "DAF" ? user?.structure?.id ?? null : null
  const drenaScopeId: number | null =
    roleCode === "DRENA" ? drenaStructureId : roleCode === "DAF" ? selectedDafDrenaId : null

  /** IEPP pour lequel on calcule déficits / excédents EPP et les demandes EPP→EPP (IEPP connecté ou IEPP choisi par la DRENA). */
  const mobilisationIeppId = useMemo((): number | null => {
    if (roleCode === "IEPP") return effectiveIeppId
    if (roleCode === "DRENA") return drenaSelectedIeppId
    return null
  }, [roleCode, effectiveIeppId, drenaSelectedIeppId])

  const showV2IeppMobilisationWizard = useMemo(() => {
    if (!anneeScolaireId) return false
    if (roleCode === "IEPP") return effectiveIeppId != null
    if (roleCode === "DRENA") return drenaStructureId != null
    if (roleCode === "DAF") return drenaScopeId != null
    return false
  }, [anneeScolaireId, roleCode, effectiveIeppId, drenaStructureId, drenaScopeId])

  useEffect(() => {
    if (anneesAvecId.length > 0 && anneeScolaireId === null) {
      const courante = anneesAvecId.find((a) => a.estCourante)
      setAnneeScolaireId(courante?.id ?? anneesAvecId[0]?.id ?? null)
    }
  }, [anneesAvecId, anneeScolaireId])

  const flatExcRows = useMemo(() => flattenExcedents(eppExc), [eppExc])

  const drenaExcAllFlat = useMemo(() => flattenDrenaExcWithIepp(drenaExcBundles), [drenaExcBundles])

  const isCrossIeppMobilisation = useMemo(
    () => (roleCode === "DRENA" || roleCode === "DAF") && mobilisationIeppId != null,
    [roleCode, mobilisationIeppId]
  )

  const drenaExcForSelectedDestination = useMemo((): DrenaExcedentFlatRow[] => {
    if (!isCrossIeppMobilisation || mobilisationIeppId == null) return []
    const destinationCombos = new Set(agregats.map((a) => `${a.matiereId}-${a.niveauId}`))
    return drenaExcAllFlat.filter(
      (r) => r.ieppId !== mobilisationIeppId && destinationCombos.has(`${r.matiereId}-${r.niveauId}`)
    )
  }, [isCrossIeppMobilisation, mobilisationIeppId, agregats, drenaExcAllFlat])

  const flatExcForMobilisation = useMemo((): ExcedentFlatRow[] => {
    if (roleCode === "DRENA" && mobilisationIeppId == null) return drenaExcAllFlat
    if (isCrossIeppMobilisation) return drenaExcForSelectedDestination
    return flatExcRows
  }, [roleCode, mobilisationIeppId, isCrossIeppMobilisation, drenaExcForSelectedDestination, drenaExcAllFlat, flatExcRows])

  const mobilisationEntries = useMemo(
    () => recordToMobilisationEntries(mobilisationQty, flatExcForMobilisation),
    [mobilisationQty, flatExcForMobilisation]
  )

  const excRowsForMobFilters = useMemo(() => {
    if (roleCode === "DRENA" && mobilisationIeppId == null) return drenaExcAllFlat
    if (isCrossIeppMobilisation) return drenaExcForSelectedDestination
    return flatExcRows
  }, [roleCode, mobilisationIeppId, isCrossIeppMobilisation, drenaExcForSelectedDestination, drenaExcAllFlat, flatExcRows])

  const matiereFilterOptions = useMemo(() => {
    const m = new Map<number, string>()
    for (const r of excRowsForMobFilters) {
      if (!m.has(r.matiereId)) m.set(r.matiereId, r.matiereLibelle)
    }
    return [...m.entries()].sort((a, b) => a[1].localeCompare(b[1]))
  }, [excRowsForMobFilters])

  const niveauFilterOptions = useMemo(() => {
    const m = new Map<number, string>()
    for (const r of excRowsForMobFilters) {
      if (filterMatiereId && String(r.matiereId) !== filterMatiereId) continue
      if (!m.has(r.niveauId)) m.set(r.niveauId, r.niveauLibelle)
    }
    return [...m.entries()].sort((a, b) => a[1].localeCompare(b[1]))
  }, [excRowsForMobFilters, filterMatiereId])

  const filteredExcFlat = useMemo(() => {
    return flatExcRows.filter((r) => {
      if (filterMatiereId && String(r.matiereId) !== filterMatiereId) return false
      if (filterNiveauId && String(r.niveauId) !== filterNiveauId) return false
      return true
    })
  }, [flatExcRows, filterMatiereId, filterNiveauId])

  const drenaOverviewAllRows = useMemo(
    () => buildDrenaOverviewRows(drenaDefBundles, drenaExcBundles),
    [drenaDefBundles, drenaExcBundles]
  )

  const drenaDashMatiereFilterOptions = useMemo(() => {
    const mp = new Map<number, string>()
    for (const r of drenaOverviewAllRows) {
      if (drenaDashFilterIeppId && String(r.ieppId) !== drenaDashFilterIeppId) continue
      if (!mp.has(r.matiereId)) mp.set(r.matiereId, r.matiereLibelle)
    }
    return [...mp.entries()].sort((a, b) => a[1].localeCompare(b[1], "fr"))
  }, [drenaOverviewAllRows, drenaDashFilterIeppId])

  const drenaDashNiveauFilterOptions = useMemo(() => {
    const mp = new Map<number, string>()
    for (const r of drenaOverviewAllRows) {
      if (drenaDashFilterIeppId && String(r.ieppId) !== drenaDashFilterIeppId) continue
      if (drenaDashFilterMatiereId && String(r.matiereId) !== drenaDashFilterMatiereId) continue
      if (!mp.has(r.niveauId)) mp.set(r.niveauId, r.niveauLibelle)
    }
    return [...mp.entries()].sort((a, b) => a[1].localeCompare(b[1], "fr"))
  }, [drenaOverviewAllRows, drenaDashFilterIeppId, drenaDashFilterMatiereId])

  const drenaOverviewFilteredRows = useMemo(() => {
    return drenaOverviewAllRows.filter((r) => {
      if (drenaDashFilterIeppId && String(r.ieppId) !== drenaDashFilterIeppId) return false
      if (drenaDashFilterMatiereId && String(r.matiereId) !== drenaDashFilterMatiereId) return false
      if (drenaDashFilterNiveauId && String(r.niveauId) !== drenaDashFilterNiveauId) return false
      return true
    })
  }, [drenaOverviewAllRows, drenaDashFilterIeppId, drenaDashFilterMatiereId, drenaDashFilterNiveauId])

  const drenaConsolidatedAgregats = useMemo(
    () => buildDrenaConsolidatedAgregats(drenaDefBundles),
    [drenaDefBundles]
  )

  const drenaConsolidatedAgregatsFiltered = useMemo(() => {
    if (roleCode !== "DRENA") return [] as DrenaBesoinsAgregatRow[]
    return drenaConsolidatedAgregats.filter((r) => {
      if (drenaDashFilterIeppId && String(r.ieppId) !== drenaDashFilterIeppId) return false
      if (drenaDashFilterMatiereId && String(r.matiereId) !== drenaDashFilterMatiereId) return false
      if (drenaDashFilterNiveauId && String(r.niveauId) !== drenaDashFilterNiveauId) return false
      return true
    })
  }, [roleCode, drenaConsolidatedAgregats, drenaDashFilterIeppId, drenaDashFilterMatiereId, drenaDashFilterNiveauId])

  const drenaBesoinIeppBlocks = useMemo((): DrenaBesoinsIeppBlock[] => {
    if (roleCode !== "DRENA" || mobilisationIeppId != null) return []
    const byIepp = new Map<number, DrenaBesoinsIeppBlock>()
    for (const row of drenaConsolidatedAgregatsFiltered) {
      const br = row as DrenaBesoinsAgregatRow
      const iid = br.ieppId
      let b = byIepp.get(iid)
      if (!b) {
        b = { ieppId: iid, ieppLibelle: br.ieppLibelle, ieppCode: br.ieppCode, rows: [] }
        byIepp.set(iid, b)
      }
      b.rows.push(br)
    }
    for (const b of byIepp.values()) {
      b.rows.sort((a, c) => {
        const lm = (a.matiereLibelle ?? "").localeCompare(c.matiereLibelle ?? "", "fr")
        if (lm !== 0) return lm
        return (a.niveauLibelle ?? "").localeCompare(c.niveauLibelle ?? "", "fr")
      })
    }
    return [...byIepp.values()].sort((a, b) =>
      (a.ieppLibelle ?? a.ieppCode ?? "").localeCompare(b.ieppLibelle ?? b.ieppCode ?? "", "fr")
    )
  }, [roleCode, mobilisationIeppId, drenaConsolidatedAgregatsFiltered])

  const besoinsTabAgregats = useMemo((): AgregatDeficitRow[] => {
    if (roleCode === "DRENA" && mobilisationIeppId == null) {
      return drenaConsolidatedAgregatsFiltered
    }
    return agregats
  }, [roleCode, mobilisationIeppId, drenaConsolidatedAgregatsFiltered, agregats])

  const besoinsAgregatsPaged = useMemo(
    () => sliceClientPage(besoinsTabAgregats, besoinsAgPage, besoinsAgPageSize),
    [besoinsTabAgregats, besoinsAgPage, besoinsAgPageSize]
  )

  const mobSynthSource = useMemo(() => {
    if (roleCode === "DRENA" && mobilisationIeppId == null) {
      return drenaConsolidatedAgregatsFiltered
    }
    if (mobilisationIeppId == null) return [] as AgregatDeficitRow[]
    return agregats
  }, [roleCode, mobilisationIeppId, agregats, drenaConsolidatedAgregatsFiltered])

  const mobSynthPaged = useMemo(
    () => sliceClientPage(mobSynthSource, mobSynthPage, mobSynthPageSize),
    [mobSynthSource, mobSynthPage, mobSynthPageSize]
  )

  const filteredDrenaMultiExc = useMemo(() => {
    const source = isCrossIeppMobilisation ? drenaExcForSelectedDestination : drenaExcAllFlat
    return source.filter((r) => {
      if (filterMatiereId && String(r.matiereId) !== filterMatiereId) return false
      if (filterNiveauId && String(r.niveauId) !== filterNiveauId) return false
      return true
    })
  }, [isCrossIeppMobilisation, drenaExcForSelectedDestination, drenaExcAllFlat, filterMatiereId, filterNiveauId])

  const drenaEppLabelMap = useMemo(() => {
    const m = new Map<number, { lib: string; code: string }>()
    for (const b of drenaExcBundles) {
      for (const e of b.eppExcedentaires) {
        m.set(e.eppId, { lib: e.eppLibelle?.trim() || `EPP ${e.eppId}`, code: e.eppCode?.trim() || "—" })
      }
    }
    for (const b of drenaDefBundles) {
      for (const e of b.eppDeficitaires) {
        if (!m.has(e.eppId)) {
          m.set(e.eppId, { lib: e.eppLibelle?.trim() || `EPP ${e.eppId}`, code: e.eppCode?.trim() || "—" })
        }
      }
    }
    return m
  }, [drenaExcBundles, drenaDefBundles])

  const drenaMobExcBlocks = useMemo((): DrenaMobExcBlock[] => {
    if (roleCode !== "DRENA" || mobilisationIeppId != null) return []
    const byIepp = new Map<number, DrenaMobExcBlock>()
    for (const row of filteredDrenaMultiExc) {
      const iid = row.ieppId
      let block = byIepp.get(iid)
      if (!block) {
        block = { ieppId: iid, ieppLibelle: row.ieppLibelle, eppChoices: [], rows: [] }
        byIepp.set(iid, block)
      }
      block.rows.push(row)
      if (!block.eppChoices.some((x) => x.eppId === row.eppId)) {
        const meta = drenaEppLabelMap.get(row.eppId)
        block.eppChoices.push({
          eppId: row.eppId,
          lib: meta?.lib ?? `EPP ${row.eppId}`,
          code: meta?.code ?? "—",
        })
      }
    }
    for (const b of byIepp.values()) {
      b.eppChoices.sort((a, c) => a.lib.localeCompare(c.lib, "fr"))
    }
    return [...byIepp.values()].sort((a, b) =>
      (a.ieppLibelle ?? `IEPP ${a.ieppId}`).localeCompare(b.ieppLibelle ?? `IEPP ${b.ieppId}`, "fr")
    )
  }, [roleCode, mobilisationIeppId, filteredDrenaMultiExc, drenaEppLabelMap])

  const mobExcSourceRows = useMemo(() => {
    if ((roleCode === "DRENA" || roleCode === "DAF") && (mobilisationIeppId == null || isCrossIeppMobilisation)) {
      return filteredDrenaMultiExc
    }
    return filteredExcFlat
  }, [roleCode, mobilisationIeppId, isCrossIeppMobilisation, filteredDrenaMultiExc, filteredExcFlat])

  const mobExcPaged = useMemo(
    () => sliceClientPage(mobExcSourceRows, mobExcPage, mobExcPageSize),
    [mobExcSourceRows, mobExcPage, mobExcPageSize]
  )

  useEffect(() => {
    setBesoinsAgPage(1)
  }, [drenaDashFilterIeppId, drenaDashFilterMatiereId, drenaDashFilterNiveauId])

  useEffect(() => {
    setBesoinsAgPage(1)
    setMobSynthPage(1)
  }, [agregats.length, mobilisationIeppId, anneeScolaireId, drenaConsolidatedAgregatsFiltered.length])

  useEffect(() => {
    setMobExcPage(1)
  }, [filterMatiereId, filterNiveauId, mobilisationIeppId, anneeScolaireId, roleCode, filteredDrenaMultiExc.length])

  useEffect(() => {
    setDrenaMobEppFilterByIepp({})
  }, [drenaExcBundles])

  useEffect(() => {
    setDrenaBesoinsMatiereByIepp({})
    setDrenaBesoinsNiveauByIepp({})
  }, [drenaDefBundles])

  useEffect(() => {
    setV2RegsPage(1)
  }, [v2Regs.length, mobilisationIeppId, anneeScolaireId])

  useEffect(() => {
    setPendingPage(1)
    setPendingDestPage(1)
  }, [pendingLignes.length])

  const loadDrenaIeppOptions = async () => {
    if (!drenaScopeId || !anneeScolaireId || (roleCode !== "DRENA" && roleCode !== "DAF")) return
    setLoadingDrenaIeppOptions(true)
    try {
      const [excRes, defRes] = await Promise.all([
        regulationService.getIeppExcedentairesByDrena(drenaScopeId, anneeScolaireId),
        regulationService.getIeppDeficitairesByDrena(drenaScopeId, anneeScolaireId),
      ])
      if (defRes.hasError) {
        toast.error(defRes.status?.message ?? "Impossible de charger les déficits IEPP (DRENA)")
      }
      if (excRes.hasError) {
        toast.error(excRes.status?.message ?? "Impossible de charger les excédents IEPP (DRENA)")
      }
      const defBundles = parseDrenaDeficitBundles(defRes.hasError ? [] : normalizeItems(defRes))
      const excBundles = parseDrenaExcedentBundles(excRes.hasError ? [] : normalizeItems(excRes))
      setDrenaDefBundles(defBundles)
      setDrenaExcBundles(excBundles)

      const m = new Map<number, DrenaIeppOptionRow>()
      const upsert = (row: DrenaIeppOptionRow) => {
        if (row.ieppId <= 0) return
        const prev = m.get(row.ieppId)
        if (!prev) {
          m.set(row.ieppId, { ...row })
          return
        }
        const lib = row.ieppLibelle?.trim() ? row.ieppLibelle : prev.ieppLibelle
        const code = row.ieppCode?.trim() ? row.ieppCode : prev.ieppCode
        m.set(row.ieppId, { ieppId: row.ieppId, ieppLibelle: lib, ieppCode: code })
      }
      for (const row of excBundles) upsert(row)
      for (const row of defBundles) upsert(row)
      const list = [...m.values()].sort((a, b) =>
        (a.ieppLibelle ?? a.ieppCode ?? "").localeCompare(b.ieppLibelle ?? b.ieppCode ?? "", "fr")
      )
      setDrenaIeppOptions(list)
      setDrenaSelectedIeppId((prev) => (prev != null && list.some((x) => x.ieppId === prev) ? prev : null))
    } catch (e: unknown) {
      console.error(e)
      toast.error(getApiErrorMessage(e, "Impossible de charger la liste des IEPP (DRENA)"))
      setDrenaIeppOptions([])
      setDrenaDefBundles([])
      setDrenaExcBundles([])
    } finally {
      setLoadingDrenaIeppOptions(false)
    }
  }

  const loadLists = async () => {
    if (!mobilisationIeppId || !anneeScolaireId) return
    setLoadingLists(true)
    try {
      const [xRes, aRes] = await Promise.all([
        regulationService.getEppExcedentaires(mobilisationIeppId, anneeScolaireId),
        regulationV2Service.getAgregatDeficitsIepp(mobilisationIeppId, anneeScolaireId),
      ])
      setEppExc(normalizeItems<EppExcRow>(xRes))
      if (aRes.hasError) {
        toast.error(aRes.status?.message ?? "Agrégat déficits indisponible")
        setAgregats([])
      } else {
        setAgregats(parseAgregatItems(normalizeItems(aRes)))
      }
    } catch (e: unknown) {
      console.error(e)
      toast.error(getApiErrorMessage(e, "Impossible de charger excédents / besoins agrégés"))
    } finally {
      setLoadingLists(false)
    }
  }

  const loadV2Regs = async () => {
    if (!mobilisationIeppId || !anneeScolaireId) return
    try {
      const r = await regulationService.getByCriteria({ ieppId: mobilisationIeppId, anneeScolaireId }, 0, 200)
      const all = normalizeItems<RegulationDto>(r)
      setV2Regs(
        all.filter(
          (x) =>
            (x.type ?? "").toUpperCase().includes("REGULATION_V2") &&
            ["EN_ATTENTE_ACCORDS", "EN_ATTENTE_VALIDATION_IEPP"].includes((x.statut ?? "").toUpperCase())
        )
      )
    } catch {
      setV2Regs([])
    }
  }

  const loadPending = async () => {
    if (!["DIRECTEUR", "MAITRE", "COGES", "IEPP"].includes(roleCode)) return
    try {
      const r = await regulationV2Service.listerLignesEnAttente()
      setPendingLignes(normalizeItems<RegulationV2PendingRow>(r))
    } catch {
      setPendingLignes([])
    }
  }

  const loadSuiviLignesIepp = async () => {
    if (!mobilisationIeppId || !anneeScolaireId) return
    if (roleCode !== "IEPP" && roleCode !== "DRENA" && roleCode !== "DAF") return
    setLoadingSuiviLignes(true)
    try {
      const r = await regulationV2Service.listerSuiviLignesIepp(mobilisationIeppId, anneeScolaireId)
      if (r.hasError) {
        setSuiviLignes([])
        toast.error(r.status?.message ?? "Suivi des lignes indisponible")
        return
      }
      setSuiviLignes(normalizeItems<RegulationV2SuiviLigneRow>(r))
    } catch (e: unknown) {
      setSuiviLignes([])
      toast.error(getApiErrorMessage(e, "Suivi des lignes indisponible"))
    } finally {
      setLoadingSuiviLignes(false)
    }
  }

  useEffect(() => {
    if (user && mobilisationIeppId && anneeScolaireId && (roleCode === "IEPP" || roleCode === "DRENA" || roleCode === "DAF")) {
      void loadLists()
      void loadV2Regs()
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user, mobilisationIeppId, anneeScolaireId, roleCode])

  useEffect(() => {
    if (user) void loadPending()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user, roleCode])

  useEffect(() => {
    if (user && roleCode === "DAF") {
      setLoadingDafDrenaOptions(true)
      void dashboardService
        .listNationalDrenas()
        .then((res) => {
          const list = normalizeItems<{ id: number; code: string; libelle: string }>(res)
          setDafDrenaOptions(list)
          setSelectedDafDrenaId((prev) => (prev != null && list.some((x) => x.id === prev) ? prev : null))
        })
        .catch((e: unknown) => {
          setDafDrenaOptions([])
          setSelectedDafDrenaId(null)
          toast.error(getApiErrorMessage(e, "Impossible de charger les DRENA"))
        })
        .finally(() => setLoadingDafDrenaOptions(false))
    } else {
      setDafDrenaOptions([])
      setSelectedDafDrenaId(null)
      setLoadingDafDrenaOptions(false)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user, roleCode])

  useEffect(() => {
    if (roleCode === "DRENA" && anneeScolaireId) {
      setDrenaSelectedIeppId(null)
      setMobilisationQty({})
      setDrenaDashFilterIeppId("")
      setDrenaDashFilterMatiereId("")
      setDrenaDashFilterNiveauId("")
      setBesoinsAgPage(1)
    }
    if (roleCode === "DAF" && anneeScolaireId) {
      setDrenaSelectedIeppId(null)
      setMobilisationQty({})
      setDrenaDashFilterIeppId("")
      setDrenaDashFilterMatiereId("")
      setDrenaDashFilterNiveauId("")
      setBesoinsAgPage(1)
    }
  }, [anneeScolaireId, roleCode])

  useEffect(() => {
    if (roleCode !== "DAF") return
    setDrenaSelectedIeppId(null)
    setMobilisationQty({})
  }, [roleCode, selectedDafDrenaId])

  useEffect(() => {
    if (roleCode !== "DAF") return
    setDafForm((prev) => ({ ...prev, destStructureId: "" }))
  }, [roleCode, selectedDafDrenaId, dafDestinationScope])

  useEffect(() => {
    if (roleCode !== "DAF") return
    let cancelled = false
    setLoadingDafReferences(true)
    Promise.all([matiereService.getMatieres(), niveauScolaireService.getNiveauxScolaires()])
      .then(([matRes, nivRes]) => {
        if (cancelled) return
        const matieres = normalizeItems<{ id: number; code?: string; libelle?: string }>(matRes)
          .filter((m) => Number(m.id) > 0)
          .sort((a, b) => String(a.libelle ?? "").localeCompare(String(b.libelle ?? ""), "fr"))
        const niveaux = normalizeItems<{ id: number; code?: string; libelle?: string }>(nivRes)
          .filter((n) => Number(n.id) > 0)
          .sort((a, b) => String(a.libelle ?? "").localeCompare(String(b.libelle ?? ""), "fr"))
        setDafMatieres(matieres)
        setDafNiveaux(niveaux)
      })
      .catch(() => {
        if (cancelled) return
        setDafMatieres([])
        setDafNiveaux([])
      })
      .finally(() => {
        if (!cancelled) setLoadingDafReferences(false)
      })
    return () => {
      cancelled = true
    }
  }, [roleCode])

  useEffect(() => {
    if (roleCode !== "DAF" || !selectedDafDrenaId) {
      setDafDestinationOptions([])
      setLoadingDafDestinations(false)
      return
    }
    let cancelled = false
    setLoadingDafDestinations(true)
    ;(async () => {
      try {
        if (dafDestinationScope === "DRENA") {
          const drena = dafDrenaOptions.find((d) => d.id === selectedDafDrenaId)
          const label = drena ? `${drena.libelle || drena.code} (${drena.code || "DRENA"})` : `DRENA #${selectedDafDrenaId}`
          if (!cancelled) {
            setDafDestinationOptions([{ id: selectedDafDrenaId, label, type: "DRENA" }])
          }
          return
        }

        const ieppRes = await structuresService.getIeppsByDrena(selectedDafDrenaId)
        const iepps = normalizeItems<{ id: number; code?: string; libelle?: string }>(ieppRes).filter((i) => Number(i.id) > 0)

        if (dafDestinationScope === "IEPP") {
          const options = iepps
            .map((i) => ({
              id: Number(i.id),
              label: `${i.libelle || `IEPP #${i.id}`} (${i.code || "IEPP"})`,
              type: "IEPP" as const,
            }))
            .sort((a, b) => a.label.localeCompare(b.label, "fr"))
          if (!cancelled) setDafDestinationOptions(options)
          return
        }

        const eppOptions: Array<{ id: number; label: string; type: "EPP" }> = []
        for (const iepp of iepps) {
          const ieppId = Number(iepp.id)
          if (!Number.isFinite(ieppId) || ieppId <= 0) continue
          const eppRes = await structuresService.getEppsByIepp(ieppId)
          const epps = normalizeItems<{ id: number; code?: string; libelle?: string }>(eppRes).filter((e) => Number(e.id) > 0)
          for (const epp of epps) {
            eppOptions.push({
              id: Number(epp.id),
              label: `${epp.libelle || `EPP #${epp.id}`} (${epp.code || "EPP"}) — ${iepp.libelle || `IEPP #${ieppId}`}`,
              type: "EPP",
            })
          }
        }
        if (!cancelled) {
          setDafDestinationOptions(eppOptions.sort((a, b) => a.label.localeCompare(b.label, "fr")))
        }
      } catch {
        if (!cancelled) setDafDestinationOptions([])
      } finally {
        if (!cancelled) setLoadingDafDestinations(false)
      }
    })()
    return () => {
      cancelled = true
    }
  }, [roleCode, selectedDafDrenaId, dafDestinationScope, dafDrenaOptions])

  useEffect(() => {
    if (
      user &&
      (roleCode === "DRENA" || roleCode === "DAF") &&
      drenaScopeId &&
      anneeScolaireId
    ) {
      void loadDrenaIeppOptions()
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user, roleCode, drenaScopeId, anneeScolaireId])

  useEffect(() => {
    if (
      user &&
      mobilisationIeppId &&
      anneeScolaireId &&
      (roleCode === "IEPP" || roleCode === "DRENA") &&
      (ieppSubTab === "finalisation" || ieppSubTab === "mobilisation")
    ) {
      void loadSuiviLignesIepp()
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user, roleCode, mobilisationIeppId, anneeScolaireId, ieppSubTab])

  useEffect(() => {
    if (roleCode === "DRENA" && mobilisationIeppId == null) {
      setSuiviLignes([])
    }
  }, [roleCode, mobilisationIeppId])

  const engagedByCombo = useMemo(() => engagedByMatiereNiveauFromSuivi(suiviLignes), [suiviLignes])
  const engagedBySourceKey = useMemo(() => engagedBySourceKeyFromSuivi(suiviLignes), [suiviLignes])

  const mobilisationValidation = useMemo(() => {
    const agg = validateMobilisationAgainstAgregat(agregats, mobilisationEntries, engagedByCombo)
    if (!agg.ok) return agg
    return validateMobilisationAgainstExcedent(mobilisationEntries, flatExcForMobilisation, engagedBySourceKey)
  }, [agregats, mobilisationEntries, engagedByCombo, engagedBySourceKey, flatExcForMobilisation])

  const suiviLignesSorted = useMemo(() => {
    return [...suiviLignes].sort((a, b) => {
      const refA = (a.reference ?? "").localeCompare(b.reference ?? "", "fr")
      if (refA !== 0) return refA
      return (a.ligneId ?? 0) - (b.ligneId ?? 0)
    })
  }, [suiviLignes])

  /** Regroupement par EPP source (structure fille sous l’IEPP). */
  const lignesAccepteesPourDemande = (regulationId: number) =>
    suiviLignes.filter((l) => l.regulationId === regulationId && statutLigneV2Upper(l.statutLigne) === "ACCEPTE")

  const suiviLignesParEppSource = useMemo(() => {
    const m = new Map<number, RegulationV2SuiviLigneRow[]>()
    for (const row of suiviLignesSorted) {
      const sid = row.structureSourceId
      const key = typeof sid === "number" && Number.isFinite(sid) ? sid : -1
      if (!m.has(key)) m.set(key, [])
      m.get(key)!.push(row)
    }
    const groups = [...m.entries()].map(([structureSourceId, rows]) => {
      const sortedRows = [...rows].sort((a, b) => {
        const refA = (a.reference ?? "").localeCompare(b.reference ?? "", "fr")
        if (refA !== 0) return refA
        return (a.ligneId ?? 0) - (b.ligneId ?? 0)
      })
      const head = sortedRows[0]
      const label = fmtStructureV2Suivi(
        head?.structureSourceLibelle,
        head?.structureSourceCode,
        structureSourceId === -1 ? undefined : structureSourceId
      )
      return { structureSourceId, label, rows: sortedRows }
    })
    groups.sort((a, b) => a.label.localeCompare(b.label, "fr"))
    return groups
  }, [suiviLignesSorted])

  const previewSources = useMemo(() => {
    try {
      if (mobilisationEntries.length === 0) return []
      if (!mobilisationValidation.ok) return []
      return buildCreerDemandeSources(agregats, mobilisationEntries, engagedByCombo)
    } catch {
      return []
    }
  }, [agregats, mobilisationEntries, mobilisationValidation, engagedByCombo])

  const previewSourcesPaged = useMemo(
    () => sliceClientPage(previewSources, previewPage, previewPageSize),
    [previewSources, previewPage, previewPageSize]
  )

  useEffect(() => {
    setPreviewPage(1)
  }, [previewSources.length, mobilisationIeppId])

  const v2RegsPaged = useMemo(
    () => sliceClientPage(v2Regs, v2RegsPage, v2RegsPageSize),
    [v2Regs, v2RegsPage, v2RegsPageSize]
  )

  const v2RegsEnAttenteValidationIepp = useMemo(
    () => v2Regs.filter((r) => (r.statut ?? "").trim().toUpperCase() === "EN_ATTENTE_VALIDATION_IEPP"),
    [v2Regs]
  )

  const validationIeppModalLignes = useMemo((): RegulationV2SuiviLigneRow[] => {
    if (validationIeppModal == null) return []
    return suiviLignes.filter(
      (l) =>
        l.regulationId === validationIeppModal.regulationId && statutLigneV2Upper(l.statutLigne) === "EN_ATTENTE"
    )
  }, [validationIeppModal, suiviLignes])

  const pendingLignesSource = useMemo(
    () => pendingLignes.filter((l) => l.cote !== "DESTINATION"),
    [pendingLignes]
  )
  const pendingLignesDest = useMemo(
    () => pendingLignes.filter((l) => l.cote === "DESTINATION"),
    [pendingLignes]
  )
  const pendingLignesSourcePaged = useMemo(
    () => sliceClientPage(pendingLignesSource, pendingPage, pendingPageSize),
    [pendingLignesSource, pendingPage, pendingPageSize]
  )
  const pendingLignesDestPaged = useMemo(
    () => sliceClientPage(pendingLignesDest, pendingDestPage, pendingDestPageSize),
    [pendingLignesDest, pendingDestPage, pendingDestPageSize]
  )

  const suiviGroupsPaged = useMemo(
    () => sliceClientPage(suiviLignesParEppSource, suiviGroupsPage, suiviGroupsPageSize),
    [suiviLignesParEppSource, suiviGroupsPage, suiviGroupsPageSize]
  )

  useEffect(() => {
    setSuiviGroupsPage(1)
  }, [suiviLignesParEppSource.length, mobilisationIeppId, anneeScolaireId])

  const handleSubmitMobilisationDemande = async () => {
    if (!mobilisationIeppId || !anneeScolaireId) {
      toast.error("Contexte IEPP ou année manquant")
      return
    }
    const entries = recordToMobilisationEntries(mobilisationQty, flatExcForMobilisation)
    const vAgg = validateMobilisationAgainstAgregat(agregats, entries, engagedByCombo)
    if (!vAgg.ok) {
      toast.error(vAgg.message)
      return
    }
    const vExc = validateMobilisationAgainstExcedent(entries, flatExcForMobilisation, engagedBySourceKey)
    if (!vExc.ok) {
      toast.error(vExc.message)
      return
    }
    if (entries.length === 0) {
      toast.error("Saisissez au moins une quantité à récupérer sur un excédent")
      return
    }
    let sources: ReturnType<typeof buildCreerDemandeSources>
    try {
      sources = buildCreerDemandeSources(agregats, entries, engagedByCombo)
    } catch (e: unknown) {
      toast.error(getApiErrorMessage(e, "Erreur de construction des lignes"))
      return
    }
    if (sources.length === 0) {
      toast.error("Aucune ligne de transfert générée (vérifiez les besoins agrégés et la répartition déficit)")
      return
    }
    try {
      const submitAsDrenaScope = roleCode === "DRENA" || roleCode === "DAF"
      const r = submitAsDrenaScope
        ? await regulationV2Service.creerDemandeEppDrena({
            ieppId: mobilisationIeppId,
            anneeScolaireId,
            sources,
            commentaire:
              roleCode === "DRENA"
                ? "Régulation — mobilisation DRENA (sources EPP multi-IEPP du ressort)"
                : "Régulation — mobilisation DAF pilotée sur périmètre DRENA",
          })
        : await regulationV2Service.creerDemandeEpp({
        ieppId: mobilisationIeppId,
        anneeScolaireId,
        sources,
        commentaire:
          roleCode === "DRENA"
            ? "Régulation — mobilisation DRENA (IEPP sélectionné, déficits / excédents par EPP)"
            : "Régulation — mobilisation IEPP (besoins agrégés → excédents)",
      })
      if (r.hasError) {
        toast.error(r.status?.message ?? "Erreur création demande")
        return
      }
      toast.success(
        roleCode === "DRENA"
          ? "Demande enregistrée — en attente de validation par l’IEPP destinataire avant transmission aux EPP."
          : roleCode === "DAF"
            ? "Demande enregistrée — flux DAF/DRENA envoyé avec succès."
          : "Demande créée"
      )
      setMobilisationQty({})
      setIeppSubTab("finalisation")
      await loadV2Regs()
      await loadPending()
      await loadLists()
      await loadSuiviLignesIepp()
    } catch (e: unknown) {
      toast.error(getApiErrorMessage(e, "Erreur"))
    }
  }

  const handleExecuter = async (regulationId: number) => {
    try {
      const r = await regulationV2Service.executerDemande(regulationId)
      if (r.hasError) {
        toast.error(r.status?.message ?? "Exécution impossible")
        return
      }
      toast.success("Demande exécutée")
      await loadV2Regs()
      await loadLists()
      await loadSuiviLignesIepp()
    } catch (e: unknown) {
      toast.error(getApiErrorMessage(e, "Exécution impossible"), { duration: 10_000 })
    }
  }

  const handleApprouver = async (ligneId: number) => {
    try {
      const r = await regulationV2Service.approuverLigne(ligneId)
      if (r.hasError) {
        toast.error(r.status?.message ?? "Refus")
        return
      }
      toast.success("Ligne acceptée")
      await loadPending()
      await loadSuiviLignesIepp()
    } catch (e: unknown) {
      toast.error(getApiErrorMessage(e, "Erreur"), { duration: 8000 })
    }
  }

  const handleRefuser = async (ligneId: number) => {
    if (!confirm("Refuser cette ligne ? Elle ne sera pas exécutée.")) return
    try {
      const r = await regulationV2Service.refuserLigne(ligneId)
      if (r.hasError) {
        toast.error(r.status?.message ?? "Erreur")
        return
      }
      toast.success("Ligne refusée")
      await loadPending()
      await loadSuiviLignesIepp()
    } catch (e: unknown) {
      toast.error(getApiErrorMessage(e, "Erreur"), { duration: 8000 })
    }
  }

  const eppById = useMemo(() => {
    const m = new Map<number, { lib: string; code: string }>()
    for (const e of eppExc) {
      m.set(e.eppId, { lib: e.eppLibelle, code: e.eppCode })
    }
    return m
  }, [eppExc])

  const eppMetaForMob = useMemo(() => {
    const m = new Map<number, { lib: string; code: string }>()
    for (const [id, v] of drenaEppLabelMap) m.set(id, v)
    for (const [id, v] of eppById) m.set(id, v)
    return m
  }, [drenaEppLabelMap, eppById])

  const handleDonDaf = async () => {
    if (!dafStructureId || !anneeScolaireId) {
      toast.error("Contexte DAF ou année manquant")
      return
    }
    const dest = Number(dafForm.destStructureId)
    const matiereId = Number(dafForm.matiereId)
    const niveauId = Number(dafForm.niveauId)
    const quantite = Number(dafForm.quantite)
    if (!dest || !matiereId || !niveauId || !quantite) {
      toast.error("Remplissez tous les champs numériques")
      return
    }
    try {
      const r = await regulationV2Service.donDafDirect({
        dafId: dafStructureId,
        destStructureId: dest,
        matiereId,
        niveauId,
        quantite,
        anneeScolaireId,
        commentaire: dafForm.commentaire || undefined,
      })
      if (r.hasError) {
        toast.error(r.status?.message ?? "Erreur")
        return
      }
      toast.success("Don DAF enregistré")
      setDafForm((prev) => ({ ...prev, quantite: "", commentaire: "" }))
    } catch (e: unknown) {
      toast.error(getApiErrorMessage(e, "Erreur"))
    }
  }

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p className="text-gray-600">Chargement…</p>
      </div>
    )
  }

  if (!canAccessRegulationPage(user.role.code, user.functionalityPermissions)) {
    return (
      <MainLayout>
        <div className="text-center py-12">
          <h2 className="text-xl font-semibold text-gray-900 mb-2">Accès restreint</h2>
          <p className="text-gray-600">Vous n&apos;avez pas les droits pour la régulation (REGULATION:READ).</p>
        </div>
      </MainLayout>
    )
  }

  return (
    <MainLayout>
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
          <div>
            <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
              <ArrowsRightLeftIcon className="h-8 w-8 text-orange-600" />
              Régulation
            </h1>
            <p className="text-gray-600 text-sm">
              {roleCode === "DRENA" ? (
                <>
                  La DRENA pilote la régulation entre les IEPP du périmètre : les volumes affichés sont toujours{" "}
                  <span className="font-medium text-gray-800">sommés à partir des EPP</span> de chaque IEPP ; les
                  demandes et accords restent au niveau EPP.
                </>
              ) : (
                <>
                  Agrégat déficits → mobilisation excédents → demande multi-sources, accords EPP, exécution.
                </>
              )}
            </p>
          </div>
        </div>

        <div className="card p-4 flex flex-wrap gap-4 items-end">
          {roleCode === "DAF" && (
            <div>
              <label className="text-sm font-medium text-gray-700">DRENA</label>
              <select
                className="input-field min-w-[260px]"
                value={selectedDafDrenaId ?? ""}
                onChange={(e) => setSelectedDafDrenaId(e.target.value ? Number(e.target.value) : null)}
                disabled={loadingDafDrenaOptions}
              >
                <option value="">— Choisir une DRENA —</option>
                {dafDrenaOptions.map((d) => (
                  <option key={d.id} value={d.id}>
                    {d.libelle || d.code}
                  </option>
                ))}
              </select>
            </div>
          )}
          <div>
            <label className="text-sm font-medium text-gray-700">Année scolaire</label>
            <select
              className="input-field mt-1"
              value={anneeScolaireId ?? ""}
              onChange={(e) => setAnneeScolaireId(e.target.value ? Number(e.target.value) : null)}
            >
              {anneesAvecId.map((a) => (
                <option key={a.id} value={a.id}>
                  {a.libelle ?? a.code ?? a.id}
                </option>
              ))}
            </select>
          </div>
        </div>

        {showV2IeppMobilisationWizard && (
          <section id="drena-assistant-regulation" className="card p-0 overflow-hidden scroll-mt-4">
            <div className="px-6 pt-6 border-b border-gray-100">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div className="min-w-0 flex-1">
                  <h2 className="text-lg font-semibold text-gray-900">
                    {roleCode === "DRENA" ? "DRENA — " : ""}Régulation EPP→EPP
                  </h2>
                  <p className="text-sm text-gray-600 mt-1">
                    {roleCode === "DRENA" ? (
                      mobilisationIeppId != null ? (
                        <>
                          Même écran que l&apos;IEPP : besoins agrégés (détail EPP), mobilisation avec saisie des quantités,
                          envoi et suivi. IEPP piloté :{" "}
                          <span className="font-medium text-gray-800">
                            {drenaIeppOptions.find((x) => x.ieppId === mobilisationIeppId)?.ieppLibelle?.trim() ?? "—"}
                          </span>
                          .
                        </>
                      ) : (
                        <>
                          Vue périmètre DRENA : onglet 1 = tous les besoins agrégés par IEPP (détail EPP) ; onglet 2 =
                          excédents par IEPP excédentaire (filtre EPP par IEPP) avec saisie « à récupérer » sur tout le
                          ressort. Pour la synthèse plafond, l&apos;envoi et le suivi, choisissez l&apos;IEPP{" "}
                          <span className="font-medium text-gray-800">destinataire (déficits)</span> dans l&apos;en-tête.
                        </>
                      )
                    ) : (
                      "Référence besoins → saisie sur excédents → suivi / exécution."
                    )}
                  </p>
                  {(roleCode === "DRENA" || roleCode === "DAF") && drenaScopeId && anneeScolaireId ? (
                    <div className="mt-3 max-w-xl">
                      <label className="text-xs font-medium text-gray-600">
                        IEPP destinataire — déficits (synthèse, envoi de la demande, suivi)
                      </label>
                      <select
                        className="input-field mt-1 w-full"
                        value={drenaSelectedIeppId ?? ""}
                        disabled={loadingDrenaIeppOptions}
                        onChange={(e) => {
                          const v = e.target.value ? Number(e.target.value) : NaN
                          setDrenaSelectedIeppId(Number.isFinite(v) && v > 0 ? v : null)
                          setMobilisationQty({})
                          setEppExc([])
                          setAgregats([])
                          setIeppSubTab("besoins")
                        }}
                      >
                        <option value="">
                          — Tous IEPP
                        </option>
                        {drenaIeppOptions.map((o) => (
                          <option key={o.ieppId} value={o.ieppId}>
                            {o.ieppLibelle?.trim() || o.ieppCode?.trim() || `IEPP #${o.ieppId}`}
                          </option>
                        ))}
                      </select>
                      {!loadingDrenaIeppOptions && drenaIeppOptions.length === 0 ? (
                        <p className="text-xs text-amber-800 mt-1">Aucun IEPP avec déficits ou excédents sur cette année.</p>
                      ) : null}
                    </div>
                  ) : null}
                </div>
                {roleCode === "DRENA" && drenaSelectedIeppId != null ? (
                  <button
                    type="button"
                    className="btn-secondary text-sm shrink-0"
                    onClick={() => {
                      setDrenaSelectedIeppId(null)
                      setMobilisationQty({})
                      setEppExc([])
                      setAgregats([])
                    }}
                  >
                    Tous IEPP
                  </button>
                ) : null}
              </div>
              <nav className="flex flex-wrap gap-2 mt-4 -mb-px" aria-label="Étapes IEPP" role="tablist">
                {(
                  [
                    { id: "besoins" as const, label: "1. Besoins de référence" },
                    { id: "mobilisation" as const, label: "2. Mobilisation excédents" },
                    { id: "finalisation" as const, label: "3. Envoi & suivi" },
                  ] as const
                ).map((t) => (
                  <button
                    key={t.id}
                    type="button"
                    role="tab"
                    aria-selected={ieppSubTab === t.id}
                    onClick={() => setIeppSubTab(t.id)}
                    className={`px-4 py-2 text-sm font-medium rounded-t-lg border border-b-0 transition-colors outline-none focus-visible:ring-2 focus-visible:ring-orange-500 focus-visible:ring-offset-1 ${
                      ieppSubTab === t.id
                        ? "bg-orange-600 border-orange-600 text-white shadow-sm font-semibold z-[1] -mb-px"
                        : "bg-gray-50 border-transparent text-gray-600 hover:bg-gray-100 hover:text-gray-900 border-b-gray-200"
                    }`}
                  >
                    {t.label}
                  </button>
                ))}
              </nav>
            </div>

            <div className="p-6 space-y-6">
              {(roleCode === "DRENA" && mobilisationIeppId == null && loadingDrenaIeppOptions) ||
              ((roleCode === "IEPP" || mobilisationIeppId != null) && loadingLists) ? (
                <p className="text-gray-500">
                  {roleCode === "DRENA" && mobilisationIeppId == null && loadingDrenaIeppOptions
                    ? "Chargement des agrégats du périmètre DRENA…"
                    : "Chargement des besoins agrégés et des excédents…"}
                </p>
              ) : (
                <>
                  {ieppSubTab === "besoins" && (
                    <div className="space-y-3">
                      <p className="text-sm text-gray-600">
                        {roleCode === "DRENA" && mobilisationIeppId == null
                          ? "Tous les IEPP du ressort : même tableau que l’IEPP (besoin total par matière / niveau, détail par EPP déficitaire). Filtrez par IEPP, matière ou niveau."
                          : roleCode === "DRENA"
                            ? "IEPP sélectionné : somme des déficits des EPP par matière et niveau (référence mobilisation), identique au compte IEPP."
                            : "Somme des déficits EPP par matière / niveau (référence pour l’étape mobilisation)."}
                      </p>
                      {roleCode === "DRENA" && mobilisationIeppId == null ? (
                        <div className="flex flex-wrap gap-3 items-end">
                          <div>
                            <label className="text-xs font-medium text-gray-600">Filtrer — IEPP</label>
                            <select
                              className="input-field mt-1 min-w-[220px]"
                              value={drenaDashFilterIeppId}
                              onChange={(e) => {
                                setDrenaDashFilterIeppId(e.target.value)
                                setDrenaDashFilterMatiereId("")
                                setDrenaDashFilterNiveauId("")
                              }}
                            >
                              <option value="">Tous les IEPP</option>
                              {drenaIeppOptions.map((o) => (
                                <option key={o.ieppId} value={String(o.ieppId)}>
                                  {o.ieppLibelle?.trim() || o.ieppCode?.trim() || `IEPP #${o.ieppId}`}
                                </option>
                              ))}
                            </select>
                          </div>
                          <div>
                            <label className="text-xs font-medium text-gray-600">Filtrer — matière</label>
                            <select
                              className="input-field mt-1 min-w-[200px]"
                              value={drenaDashFilterMatiereId}
                              onChange={(e) => {
                                setDrenaDashFilterMatiereId(e.target.value)
                                setDrenaDashFilterNiveauId("")
                              }}
                            >
                              <option value="">Toutes</option>
                              {drenaDashMatiereFilterOptions.map(([id, lib]) => (
                                <option key={id} value={String(id)}>
                                  {lib}
                                </option>
                              ))}
                            </select>
                          </div>
                          <div>
                            <label className="text-xs font-medium text-gray-600">Filtrer — niveau</label>
                            <select
                              className="input-field mt-1 min-w-[200px]"
                              value={drenaDashFilterNiveauId}
                              onChange={(e) => setDrenaDashFilterNiveauId(e.target.value)}
                            >
                              <option value="">Tous</option>
                              {drenaDashNiveauFilterOptions.map(([id, lib]) => (
                                <option key={id} value={String(id)}>
                                  {lib}
                                </option>
                              ))}
                            </select>
                          </div>
                          <button
                            type="button"
                            className="btn-secondary text-sm"
                            onClick={() => {
                              setDrenaDashFilterIeppId("")
                              setDrenaDashFilterMatiereId("")
                              setDrenaDashFilterNiveauId("")
                            }}
                          >
                            Réinitialiser filtres
                          </button>
                        </div>
                      ) : null}
                      {besoinsTabAgregats.length === 0 ? (
                        <p className="text-sm text-gray-500 border border-dashed border-gray-200 rounded-lg p-4">
                          {roleCode === "DRENA" && mobilisationIeppId == null
                            ? drenaConsolidatedAgregats.length === 0
                              ? "Aucun besoin agrégé pour cette année sur les IEPP du périmètre."
                              : "Aucune ligne ne correspond aux filtres."
                            : "Aucun besoin agrégé pour cette année."}
                        </p>
                      ) : roleCode === "DRENA" && mobilisationIeppId == null && drenaBesoinIeppBlocks.length > 0 ? (
                        <div className="space-y-6">
                          {drenaBesoinIeppBlocks.map((block) => {
                            const ikey = String(block.ieppId)
                            const matSel = drenaBesoinsMatiereByIepp[ikey] ?? ""
                            const nivSel = drenaBesoinsNiveauByIepp[ikey] ?? ""
                            const matOpts = [...new Map(block.rows.map((r) => [r.matiereId, r.matiereLibelle ?? "—"]))]
                              .sort((a, b) => String(a[1]).localeCompare(String(b[1]), "fr"))
                            const nivOpts = [
                              ...new Map(
                                block.rows
                                  .filter((r) => !matSel || String(r.matiereId) === matSel)
                                  .map((r) => [r.niveauId, r.niveauLibelle ?? "—"])
                              ),
                            ].sort((a, b) => String(a[1]).localeCompare(String(b[1]), "fr"))
                            const filteredRows = block.rows.filter((r) => {
                              if (matSel && String(r.matiereId) !== matSel) return false
                              if (nivSel && String(r.niveauId) !== nivSel) return false
                              return true
                            })
                            const ieppTitle =
                              block.ieppLibelle?.trim() || block.ieppCode?.trim() || `IEPP #${block.ieppId}`
                            return (
                              <div
                                key={block.ieppId}
                                className="rounded-lg border border-gray-200 overflow-hidden bg-white shadow-sm"
                              >
                                <div className="flex flex-wrap items-end justify-between gap-3 px-3 py-2.5 bg-gray-50 border-b border-gray-100">
                                  <h4 className="text-sm font-semibold text-gray-900">{ieppTitle}</h4>
                                  <div className="flex flex-wrap gap-2 items-end">
                                    <div>
                                      <label className="text-xs font-medium text-gray-600">Matière</label>
                                      <select
                                        className="input-field text-sm min-w-[180px] mt-1"
                                        value={matSel}
                                        onChange={(e) => {
                                          const v = e.target.value
                                          setDrenaBesoinsMatiereByIepp((prev) => ({ ...prev, [ikey]: v }))
                                          setDrenaBesoinsNiveauByIepp((prev) => ({ ...prev, [ikey]: "" }))
                                        }}
                                      >
                                        <option value="">Toutes</option>
                                        {matOpts.map(([id, lib]) => (
                                          <option key={id} value={String(id)}>
                                            {lib}
                                          </option>
                                        ))}
                                      </select>
                                    </div>
                                    <div>
                                      <label className="text-xs font-medium text-gray-600">Niveau</label>
                                      <select
                                        className="input-field text-sm min-w-[180px] mt-1"
                                        value={nivSel}
                                        onChange={(e) =>
                                          setDrenaBesoinsNiveauByIepp((prev) => ({
                                            ...prev,
                                            [ikey]: e.target.value,
                                          }))
                                        }
                                      >
                                        <option value="">Tous</option>
                                        {nivOpts.map(([id, lib]) => (
                                          <option key={id} value={String(id)}>
                                            {lib}
                                          </option>
                                        ))}
                                      </select>
                                    </div>
                                  </div>
                                </div>
                                {filteredRows.length === 0 ? (
                                  <p className="text-sm text-gray-500 px-3 py-4">Aucune ligne avec ces filtres.</p>
                                ) : (
                                  <div className="overflow-x-auto">
                                    <table className="min-w-full text-sm">
                                      <thead className="bg-gray-50">
                                        <tr>
                                          <th className="px-3 py-2 text-left">Matière</th>
                                          <th className="px-3 py-2 text-left">Niveau</th>
                                          <th className="px-3 py-2 text-right">Besoin total</th>
                                          <th className="px-3 py-2 text-left">Détail par EPP déficitaire</th>
                                        </tr>
                                      </thead>
                                      <tbody>
                                        {filteredRows.map((a) => (
                                          <tr
                                            key={`${block.ieppId}-${a.matiereId}-${a.niveauId}`}
                                            className="border-t border-gray-100"
                                          >
                                            <td className="px-3 py-2">{a.matiereLibelle ?? "—"}</td>
                                            <td className="px-3 py-2">{a.niveauLibelle ?? "—"}</td>
                                            <td className="px-3 py-2 text-right font-semibold text-red-800">
                                              {a.deficitTotal}
                                            </td>
                                            <td className="px-3 py-2 text-gray-600 text-xs">
                                              {(a.repartitionParEpp ?? [])
                                                .map(
                                                  (r) =>
                                                    `${r.eppLibelle?.trim() || "EPP"} (${r.deficit})`
                                                )
                                                .join(" · ") || "—"}
                                            </td>
                                          </tr>
                                        ))}
                                      </tbody>
                                    </table>
                                  </div>
                                )}
                              </div>
                            )
                          })}
                        </div>
                      ) : (
                        <div className="rounded-lg border border-gray-200 overflow-hidden bg-white">
                          <div className="overflow-x-auto">
                            <table className="min-w-full text-sm">
                              <thead className="bg-gray-50">
                                <tr>
                                  {roleCode === "DRENA" && mobilisationIeppId == null ? (
                                    <th className="px-3 py-2 text-left">IEPP</th>
                                  ) : null}
                                  <th className="px-3 py-2 text-left">Matière</th>
                                  <th className="px-3 py-2 text-left">Niveau</th>
                                  <th className="px-3 py-2 text-right">Besoin total</th>
                                  <th className="px-3 py-2 text-left">Détail par EPP déficitaire</th>
                                </tr>
                              </thead>
                              <tbody>
                                {besoinsAgregatsPaged.map((a) => {
                                  const br = a as DrenaBesoinsAgregatRow
                                  const rowKey =
                                    roleCode === "DRENA" && mobilisationIeppId == null
                                      ? `${br.ieppId}-${a.matiereId}-${a.niveauId}`
                                      : `${a.matiereId}-${a.niveauId}`
                                  return (
                                    <tr key={rowKey} className="border-t border-gray-100">
                                      {roleCode === "DRENA" && mobilisationIeppId == null ? (
                                        <td className="px-3 py-2 font-medium text-gray-900">
                                          {br.ieppLibelle?.trim() || br.ieppCode?.trim() || `IEPP #${br.ieppId}`}
                                        </td>
                                      ) : null}
                                      <td className="px-3 py-2">{a.matiereLibelle ?? "—"}</td>
                                      <td className="px-3 py-2">{a.niveauLibelle ?? "—"}</td>
                                      <td className="px-3 py-2 text-right font-semibold text-red-800">{a.deficitTotal}</td>
                                      <td className="px-3 py-2 text-gray-600 text-xs">
                                        {(a.repartitionParEpp ?? [])
                                          .map(
                                            (r) =>
                                              `${r.eppLibelle?.trim() || "EPP"} (${r.deficit})`
                                          )
                                          .join(" · ") || "—"}
                                      </td>
                                    </tr>
                                  )
                                })}
                              </tbody>
                            </table>
                          </div>
                          <PaginationControls
                            currentPage={besoinsAgPage}
                            totalPages={clientTotalPages(besoinsTabAgregats.length, besoinsAgPageSize)}
                            pageSize={besoinsAgPageSize}
                            totalCount={besoinsTabAgregats.length}
                            onPageChange={setBesoinsAgPage}
                            onPageSizeChange={(s) => {
                              setBesoinsAgPageSize(s)
                              setBesoinsAgPage(1)
                            }}
                          />
                        </div>
                      )}
                    </div>
                  )}

                  {ieppSubTab === "mobilisation" && (
                    <div className="space-y-4">
                      <p className="text-sm text-gray-600">
                        {roleCode === "DRENA" && mobilisationIeppId == null ? (
                          <>
                            Chaque IEPP excédentaire du ressort : menu déroulant pour n&apos;afficher qu&apos;un EPP ou
                            tous, puis saisie des quantités « À récupérer » par ligne (sources sur tout le périmètre).
                            L&apos;envoi de la demande et la synthèse besoin / déjà en demande utilisent l&apos;IEPP
                            destinataire sélectionné dans l&apos;en-tête.
                          </>
                        ) : (
                          <>
                            Quantités à prélever sur l’excédent par EPP ; la synthèse contrôle le plafond par matière /
                            niveau. La mobilisation peut être{" "}
                            <span className="font-medium text-gray-800">partielle</span> : il n’est pas obligatoire de
                            couvrir tout le besoin agrégé tant que, pour chaque matière / niveau, la somme mobilisée ne dépasse
                            pas le déficit de référence (les quantités non couvertes restent visibles dans la colonne
                            « Reste »).
                          </>
                        )}
                      </p>
                      <div className="flex flex-wrap gap-3 items-end">
                        <div>
                          <label className="text-xs font-medium text-gray-600">Filtrer — matière</label>
                          <select
                            className="input-field mt-1 min-w-[200px]"
                            value={filterMatiereId}
                            onChange={(e) => {
                              setFilterMatiereId(e.target.value)
                              setFilterNiveauId("")
                            }}
                          >
                            <option value="">Toutes</option>
                            {matiereFilterOptions.map(([id, lib]) => (
                              <option key={id} value={String(id)}>
                                {lib}
                              </option>
                            ))}
                          </select>
                        </div>
                        <div>
                          <label className="text-xs font-medium text-gray-600">Filtrer — niveau</label>
                          <select
                            className="input-field mt-1 min-w-[200px]"
                            value={filterNiveauId}
                            onChange={(e) => setFilterNiveauId(e.target.value)}
                          >
                            <option value="">Tous</option>
                            {niveauFilterOptions.map(([id, lib]) => (
                              <option key={id} value={String(id)}>
                                {lib}
                              </option>
                            ))}
                          </select>
                        </div>
                        <button
                          type="button"
                          className="btn-secondary text-sm"
                          onClick={() => {
                            setFilterMatiereId("")
                            setFilterNiveauId("")
                          }}
                        >
                          Réinitialiser filtres
                        </button>
                      </div>

                      {mobSynthSource.length > 0 && (
                        <div className="rounded-lg border border-gray-200 bg-gray-50 overflow-hidden">
                          <div className="p-3 pb-0">
                            <h3 className="text-sm font-semibold text-gray-900 mb-2">Synthèse besoin vs mobilisé</h3>
                            <p className="text-xs text-gray-500 mb-2">
                              « Déjà en demande » inclut les quantités des demandes en attente d&apos;accord ou déjà
                              acceptées par au moins une source, pour éviter de sur-mobiliser.
                            </p>
                          </div>
                          <div className="overflow-x-auto px-3">
                            <table className="min-w-full text-xs">
                              <thead>
                                <tr className="text-left text-gray-600">
                                  <th className="pr-2 py-1">Matière / niveau</th>
                                  <th className="text-right px-2 py-1">Besoin</th>
                                  <th className="text-right px-2 py-1">Satisfait (saisi)</th>
                                  <th className="text-right px-2 py-1">En cours demande</th>
                                  <th className="text-right px-2 py-1">Total</th>
                                  <th className="text-right px-2 py-1">Reste</th>
                                </tr>
                              </thead>
                              <tbody>
                                {mobSynthPaged.map((a) => {
                                  const comboK = `${a.matiereId}-${a.niveauId}`
                                  const pendingCombo = engagedByCombo.get(comboK) ?? 0
                                  const mob = mobilisedSumForCombo(mobilisationEntries, a.matiereId, a.niveauId)
                                  const total = mob + pendingCombo
                                  const reste = Math.max(0, a.deficitTotal - total)
                                  return (
                                    <tr key={`s-${a.matiereId}-${a.niveauId}`} className="border-t border-gray-200">
                                      <td className="py-1 pr-2">
                                        {a.matiereLibelle ?? "—"} — {a.niveauLibelle ?? "—"}
                                      </td>
                                      <td className="text-right px-2 py-1">{a.deficitTotal}</td>
                                      <td className="text-right px-2 py-1 font-medium text-emerald-800">{mob}</td>
                                      <td className="text-right px-2 py-1 text-amber-900">{pendingCombo}</td>
                                      <td className="text-right px-2 py-1 font-semibold text-gray-800">{total}</td>
                                      <td
                                        className={`text-right px-2 py-1 font-semibold ${
                                          reste === 0 ? "text-emerald-700" : "text-amber-800"
                                        }`}
                                      >
                                        {reste}
                                      </td>
                                    </tr>
                                  )
                                })}
                              </tbody>
                            </table>
                          </div>
                          <PaginationControls
                            currentPage={mobSynthPage}
                            totalPages={clientTotalPages(mobSynthSource.length, mobSynthPageSize)}
                            pageSize={mobSynthPageSize}
                            totalCount={mobSynthSource.length}
                            onPageChange={setMobSynthPage}
                            onPageSizeChange={(s) => {
                              setMobSynthPageSize(s)
                              setMobSynthPage(1)
                            }}
                          />
                        </div>
                      )}

                      {roleCode === "DRENA" && mobilisationIeppId == null ? (
                        drenaMobExcBlocks.length === 0 ? (
                          <p className="text-sm text-gray-500">Aucune ligne excédentaire avec les filtres choisis.</p>
                        ) : (
                          <div className="space-y-6">
                            {drenaMobExcBlocks.map((block) => {
                              const filterEpp = drenaMobEppFilterByIepp[String(block.ieppId)] ?? ""
                              const rows = block.rows.filter((r) => !filterEpp || String(r.eppId) === filterEpp)
                              const ieppTitle = block.ieppLibelle?.trim() || `IEPP #${block.ieppId}`
                              return (
                                <div
                                  key={block.ieppId}
                                  className="rounded-lg border border-gray-200 overflow-hidden bg-white shadow-sm"
                                >
                                  <div className="flex flex-wrap items-center justify-between gap-3 px-3 py-2.5 bg-gray-50 border-b border-gray-100">
                                    <h4 className="text-sm font-semibold text-gray-900">{ieppTitle}</h4>
                                    <div className="flex flex-wrap items-center gap-2">
                                      <label className="text-xs font-medium text-gray-600 whitespace-nowrap">
                                        Filtrer par EPP
                                      </label>
                                      <select
                                        className="input-field text-sm min-w-[220px]"
                                        value={filterEpp}
                                        onChange={(e) =>
                                          setDrenaMobEppFilterByIepp((prev) => ({
                                            ...prev,
                                            [String(block.ieppId)]: e.target.value,
                                          }))
                                        }
                                      >
                                        <option value="">Tous les EPP</option>
                                        {block.eppChoices.map((o) => (
                                          <option key={o.eppId} value={String(o.eppId)}>
                                            {o.lib} ({o.code})
                                          </option>
                                        ))}
                                      </select>
                                    </div>
                                  </div>
                                  {rows.length === 0 ? (
                                    <p className="text-sm text-gray-500 px-3 py-4">Aucune ligne avec ce filtre EPP.</p>
                                  ) : (
                                    <div className="overflow-x-auto">
                                      <table className="min-w-full text-sm">
                                        <thead className="bg-gray-50">
                                          <tr>
                                            <th className="px-3 py-2 text-left">EPP source</th>
                                            <th className="px-3 py-2 text-left">Matière / niveau</th>
                                            <th className="px-3 py-2 text-right">Excédent</th>
                                            <th className="px-3 py-2 text-right">En demande</th>
                                            <th className="px-3 py-2 text-right">À récupérer</th>
                                          </tr>
                                        </thead>
                                        <tbody>
                                          {rows.map((row) => {
                                            const meta = eppMetaForMob.get(row.eppId)
                                            const k = mobilisationKey(row.eppId, row.matiereId, row.niveauId)
                                            const v = mobilisationQty[k] ?? ""
                                            const engagedHere = engagedBySourceKey.get(k) ?? 0
                                            const maxPick = Math.max(0, row.excedent - engagedHere)
                                            return (
                                              <tr key={`${block.ieppId}-${k}`} className="border-t border-gray-100">
                                                <td className="px-3 py-2">
                                                  {meta?.lib ?? "EPP"}{" "}
                                                  <span className="text-gray-500">({meta?.code ?? "—"})</span>
                                                </td>
                                                <td className="px-3 py-2 text-gray-700">
                                                  {row.matiereLibelle} — {row.niveauLibelle}
                                                </td>
                                                <td className="px-3 py-2 text-right text-amber-800">{row.excedent}</td>
                                                <td className="px-3 py-2 text-right text-amber-900 text-xs">
                                                  {engagedHere > 0 ? engagedHere : "—"}
                                                </td>
                                                <td className="px-3 py-2 text-right">
                                                  <input
                                                    type="number"
                                                    min={0}
                                                    max={maxPick}
                                                    className="input-field w-24 text-right"
                                                    value={v}
                                                    onChange={(e) => {
                                                      const n = e.target.value === "" ? 0 : Number(e.target.value)
                                                      const q = Number.isFinite(n) ? Math.max(0, Math.floor(n)) : 0
                                                      setMobilisationQty((prev) => {
                                                        const next = { ...prev }
                                                        if (q <= 0) delete next[k]
                                                        else next[k] = Math.min(q, maxPick)
                                                        return next
                                                      })
                                                    }}
                                                  />
                                                </td>
                                              </tr>
                                            )
                                          })}
                                        </tbody>
                                      </table>
                                    </div>
                                  )}
                                </div>
                              )
                            })}
                          </div>
                        )
                      ) : mobExcSourceRows.length === 0 ? (
                        <p className="text-sm text-gray-500">Aucune ligne excédentaire avec les filtres choisis.</p>
                      ) : (
                        <div className="rounded-lg border border-gray-200 overflow-hidden bg-white">
                          {isCrossIeppMobilisation ? (
                            <p className="px-3 py-2 text-xs text-indigo-900 bg-indigo-50 border-b border-indigo-100">
                              Sources affichées : IEPP excédentaires du ressort (hors IEPP destinataire), limitées aux
                              matières/niveaux déficitaires de l&apos;IEPP sélectionné.
                            </p>
                          ) : null}
                          <div className="overflow-x-auto">
                            <table className="min-w-full text-sm">
                              <thead className="bg-gray-50">
                                <tr>
                                  {isCrossIeppMobilisation ? (
                                    <th className="px-3 py-2 text-left">IEPP source</th>
                                  ) : null}
                                  <th className="px-3 py-2 text-left">EPP source</th>
                                  <th className="px-3 py-2 text-left">Matière / niveau</th>
                                  <th className="px-3 py-2 text-right">Excédent</th>
                                  <th className="px-3 py-2 text-right">En demande</th>
                                  <th className="px-3 py-2 text-right">À récupérer</th>
                                </tr>
                              </thead>
                              <tbody>
                                {mobExcPaged.map((row) => {
                                  const meta = eppMetaForMob.get(row.eppId)
                                  const k = mobilisationKey(row.eppId, row.matiereId, row.niveauId)
                                  const v = mobilisationQty[k] ?? ""
                                  const engagedHere = engagedBySourceKey.get(k) ?? 0
                                  const maxPick = Math.max(0, row.excedent - engagedHere)
                                  const rowCross = row as DrenaExcedentFlatRow
                                  return (
                                    <tr key={k} className="border-t border-gray-100">
                                      {isCrossIeppMobilisation ? (
                                        <td className="px-3 py-2 text-gray-700">
                                          {rowCross.ieppLibelle?.trim() || `IEPP #${rowCross.ieppId}`}
                                        </td>
                                      ) : null}
                                      <td className="px-3 py-2">
                                        {meta?.lib ?? "EPP"}{" "}
                                        <span className="text-gray-500">({meta?.code ?? "—"})</span>
                                      </td>
                                      <td className="px-3 py-2 text-gray-700">
                                        {row.matiereLibelle} — {row.niveauLibelle}
                                      </td>
                                      <td className="px-3 py-2 text-right text-amber-800">{row.excedent}</td>
                                      <td className="px-3 py-2 text-right text-amber-900 text-xs">
                                        {engagedHere > 0 ? engagedHere : "—"}
                                      </td>
                                      <td className="px-3 py-2 text-right">
                                        <input
                                          type="number"
                                          min={0}
                                          max={maxPick}
                                          className="input-field w-24 text-right"
                                          value={v}
                                          onChange={(e) => {
                                            const n = e.target.value === "" ? 0 : Number(e.target.value)
                                            const q = Number.isFinite(n) ? Math.max(0, Math.floor(n)) : 0
                                            setMobilisationQty((prev) => {
                                              const next = { ...prev }
                                              if (q <= 0) delete next[k]
                                              else next[k] = Math.min(q, maxPick)
                                              return next
                                            })
                                          }}
                                        />
                                      </td>
                                    </tr>
                                  )
                                })}
                              </tbody>
                            </table>
                          </div>
                          <PaginationControls
                            currentPage={mobExcPage}
                            totalPages={clientTotalPages(mobExcSourceRows.length, mobExcPageSize)}
                            pageSize={mobExcPageSize}
                            totalCount={mobExcSourceRows.length}
                            onPageChange={setMobExcPage}
                            onPageSizeChange={(s) => {
                              setMobExcPageSize(s)
                              setMobExcPage(1)
                            }}
                          />
                        </div>
                      )}

                      <div className="flex flex-wrap gap-2 items-center">
                        <button
                          type="button"
                          className="btn-primary disabled:opacity-50"
                          disabled={mobilisationIeppId == null}
                          title={
                            mobilisationIeppId == null
                              ? "Sélectionnez d'abord l'IEPP destinataire dans l'en-tête."
                              : "Envoyer la demande"
                          }
                          onClick={() => void handleSubmitMobilisationDemande()}
                        >
                          Envoyer la demande
                        </button>
                        <button
                          type="button"
                          className="btn-secondary text-sm"
                          disabled={mobilisationIeppId == null}
                          onClick={() => setIeppSubTab("finalisation")}
                        >
                          Passer au suivi sans envoyer
                        </button>
                      </div>
                      {(roleCode === "DRENA" || roleCode === "DAF") && mobilisationIeppId == null ? (
                        <p className="text-sm text-amber-900 bg-amber-50 border border-amber-100 rounded-lg px-3 py-2">
                          Choisissez l&apos;IEPP <span className="font-medium">destinataire (déficits)</span> dans
                          l&apos;en-tête pour activer l&apos;envoi et le suivi. Les quantités saisies sont conservées.
                        </p>
                      ) : null}
                    </div>
                  )}

                  {ieppSubTab === "finalisation" && (
                    <div className="space-y-4">
                      {roleCode === "DRENA" && mobilisationIeppId == null ? (
                        <p className="text-sm text-amber-900 bg-amber-50 border border-amber-100 rounded-lg px-3 py-2">
                          Sélectionnez l&apos;IEPP <span className="font-medium">destinataire (déficits)</span> dans
                          l&apos;en-tête pour afficher le suivi par EPP source, le brouillon mobilisation et
                          l&apos;exécution des demandes (même périmètre qu&apos;un compte IEPP).
                        </p>
                      ) : (
                        <>
                      <div>
                        <h3 className="text-sm font-semibold text-gray-900 mb-2">
                          Suivi par EPP source (déplier) — destination, matière / niveau, accord
                        </h3>
                        {loadingSuiviLignes ? (
                          <p className="text-sm text-gray-500">Chargement du suivi…</p>
                        ) : suiviLignesSorted.length === 0 ? (
                          <p className="text-sm text-gray-500">Aucune demande en attente d&apos;accord pour cette année.</p>
                        ) : (
                          <div className="space-y-2">
                            {suiviGroupsPaged.map((g, idx) => (
                              <SuiviEppSourceAccordion
                                key={g.structureSourceId}
                                group={g}
                                defaultOpen={suiviGroupsPage === 1 && idx === 0}
                              />
                            ))}
                            <PaginationControls
                              currentPage={suiviGroupsPage}
                              totalPages={clientTotalPages(suiviLignesParEppSource.length, suiviGroupsPageSize)}
                              pageSize={suiviGroupsPageSize}
                              totalCount={suiviLignesParEppSource.length}
                              onPageChange={setSuiviGroupsPage}
                              onPageSizeChange={(s) => {
                                setSuiviGroupsPageSize(s)
                                setSuiviGroupsPage(1)
                              }}
                            />
                          </div>
                        )}
                        <p className="text-xs text-gray-500 mt-2">
                          Exécution : dès qu’au moins une ligne est acceptée, l’initiateur (ou admin) peut exécuter : les
                          transferts portent sur les lignes acceptées uniquement ; les lignes encore « En attente » sont
                          alors clôturées comme refusées. Ajustement des quantités : lignes acceptées uniquement, même si
                          d’autres sources n’ont pas encore répondu.
                        </p>
                      </div>

                      {mobilisationEntries.length === 0 ? (
                        <p className="text-sm text-gray-500">Aucune saisie mobilisation à prévisualiser.</p>
                      ) : (
                        <>
                          <h4 className="text-xs font-semibold text-gray-700 uppercase tracking-wide">
                            Brouillon (non envoyé)
                          </h4>
                          {mobilisationValidation.ok ? (
                            <p className="text-sm text-emerald-800 bg-emerald-50 border border-emerald-100 rounded-lg px-3 py-2">
                              Cohérent — {previewSources.length} ligne(s) générée(s).
                            </p>
                          ) : (
                            <p className="text-sm text-red-800 bg-red-50 border border-red-100 rounded-lg px-3 py-2">
                              {"message" in mobilisationValidation ? mobilisationValidation.message : "Incohérence"}
                            </p>
                          )}
                          {previewSources.length > 0 && (
                            <div className="rounded-lg border border-gray-200 overflow-hidden bg-white">
                              <div className="overflow-x-auto max-h-56 overflow-y-auto">
                                <table className="min-w-full text-xs">
                                  <thead className="bg-gray-50 sticky top-0">
                                    <tr>
                                      <th className="px-2 py-1 text-left">Source → Dest</th>
                                      <th className="px-2 py-1 text-left">M / N</th>
                                      <th className="px-2 py-1 text-right">Qté</th>
                                    </tr>
                                  </thead>
                                  <tbody>
                                    {previewSourcesPaged.map((s, i) => {
                                      const sMeta = eppById.get(s.structureSourceId)
                                      const dMeta = eppById.get(s.structureDestId)
                                      const dRep = agregats
                                        .find((a) => a.matiereId === s.matiereId && a.niveauId === s.niveauId)
                                        ?.repartitionParEpp?.find((x) => x.eppId === s.structureDestId)
                                      const destLabel = dMeta?.lib ?? dRep?.eppLibelle ?? "EPP destinataire"
                                      const aggRow = agregats.find(
                                        (a) => a.matiereId === s.matiereId && a.niveauId === s.niveauId
                                      )
                                      const mnLabel = `${aggRow?.matiereLibelle ?? "Matière"} — ${aggRow?.niveauLibelle ?? "Niveau"}`
                                      return (
                                        <tr key={`${s.structureSourceId}-${s.structureDestId}-${s.matiereId}-${s.niveauId}-${i}`} className="border-t border-gray-100">
                                          <td className="px-2 py-1">
                                            {sMeta?.lib ?? "EPP source"} → {destLabel}
                                          </td>
                                          <td className="px-2 py-1 text-gray-600">{mnLabel}</td>
                                          <td className="px-2 py-1 text-right">{s.quantite}</td>
                                        </tr>
                                      )
                                    })}
                                  </tbody>
                                </table>
                              </div>
                              <PaginationControls
                                currentPage={previewPage}
                                totalPages={clientTotalPages(previewSources.length, previewPageSize)}
                                pageSize={previewPageSize}
                                totalCount={previewSources.length}
                                onPageChange={setPreviewPage}
                                onPageSizeChange={(s) => {
                                  setPreviewPageSize(s)
                                  setPreviewPage(1)
                                }}
                              />
                            </div>
                          )}
                        </>
                      )}

                      {mobilisationIeppId != null && v2RegsEnAttenteValidationIepp.length > 0 ? (
                        <div className="rounded-lg border border-amber-200 bg-amber-50/60 p-4 space-y-3">
                          <h3 className="text-sm font-semibold text-amber-950">
                            Validation IEPP (laissez-passer DRENA → EPP)
                          </h3>
                          <p className="text-xs text-amber-900">
                            Ces demandes ont été initiées par la DRENA. L&apos;IEPP destinataire doit les valider (ou
                            ajuster les quantités) avant qu&apos;elles n&apos;apparaissent chez les EPP sources pour accord.
                          </p>
                          <ul className="space-y-2 text-sm">
                            {v2RegsEnAttenteValidationIepp.map((r) => {
                              const rid = r.id
                              const rc = (user?.role?.code ?? "").trim().toUpperCase()
                              const peutPiloter = rc === "IEPP"
                              return (
                                <li
                                  key={rid ?? r.reference}
                                  className="flex flex-wrap items-center justify-between gap-2 border border-amber-100 rounded-lg bg-white px-3 py-2"
                                >
                                  <span className="font-medium text-gray-900">
                                    {formatRegulationReferenceForDisplay(r.reference) || `Demande #${rid}`}
                                  </span>
                                  <button
                                    type="button"
                                    className="btn-secondary text-xs"
                                    onClick={() =>
                                      rid != null &&
                                      setValidationIeppModal({
                                        regulationId: rid,
                                        reference: r.reference?.trim() || undefined,
                                      })
                                    }
                                  >
                                    {peutPiloter ? "Détails / ajuster / transmettre" : "Voir le détail"}
                                  </button>
                                </li>
                              )
                            })}
                          </ul>
                        </div>
                      ) : null}

                      <div className="border-t border-gray-200 pt-4">
                        <h3 className="font-medium text-gray-900 mb-2 flex items-center gap-2">
                          <ClipboardDocumentListIcon className="h-5 w-5 text-orange-600" />
                          Exécuter une demande
                        </h3>
                        <div className="rounded-lg border border-gray-200 overflow-hidden bg-white">
                          <ul className="space-y-2 text-sm p-2">
                            {v2RegsPaged.map((r) => {
                              const rc = (user?.role?.code ?? "").trim().toUpperCase()
                              const canExecute =
                                rc === "ADMIN" || (user?.id != null && r.initieePar != null && r.initieePar === user.id)
                              const rid = r.id
                              const suiviContientDemande =
                                rid != null && suiviLignes.some((l) => l.regulationId === rid)
                              const peutExecuterOuAjuster =
                                rid != null &&
                                suiviContientDemande &&
                                lignesAccepteesPourDemande(rid).length > 0
                              const peutAjusterOuExecuter = canExecute && peutExecuterOuAjuster
                              return (
                                <li
                                  key={r.id}
                                  className="flex flex-wrap items-center gap-2 justify-between border border-gray-100 rounded p-2"
                                >
                                  <span>
                                    {formatRegulationReferenceForDisplay(r.reference) || `Demande #${r.id}`}
                                    {canExecute && (
                                      <span className="ml-2 text-orange-700 text-xs font-medium">Initiateur</span>
                                    )}
                                  </span>
                                  {canExecute && (
                                    <span className="flex flex-wrap gap-2">
                                      {peutAjusterOuExecuter ? (
                                        <button
                                          type="button"
                                          className="btn-secondary text-xs"
                                          onClick={() =>
                                            rid != null &&
                                            setAjustementModal({
                                              regulationId: rid,
                                              reference: r.reference?.trim() || undefined,
                                            })
                                          }
                                        >
                                          Ajuster les quantités
                                        </button>
                                      ) : null}
                                      <button
                                        type="button"
                                        className="btn-secondary text-xs"
                                        disabled={!peutAjusterOuExecuter}
                                        title={
                                          !suiviContientDemande
                                            ? "Chargez le suivi (onglet) ou attendez le chargement des lignes."
                                            : !peutExecuterOuAjuster
                                              ? "Au moins une ligne acceptée est requise pour exécuter ou ajuster."
                                              : "Exécute les lignes acceptées ; les lignes encore en attente seront refusées automatiquement."
                                        }
                                        onClick={() => r.id != null && void handleExecuter(r.id)}
                                      >
                                        Exécuter
                                      </button>
                                    </span>
                                  )}
                                </li>
                              )
                            })}
                            {v2Regs.length === 0 && <li className="text-gray-500">Aucune demande en attente d&apos;accord.</li>}
                          </ul>
                          {v2Regs.length > 0 ? (
                            <PaginationControls
                              currentPage={v2RegsPage}
                              totalPages={clientTotalPages(v2Regs.length, v2RegsPageSize)}
                              pageSize={v2RegsPageSize}
                              totalCount={v2Regs.length}
                              onPageChange={setV2RegsPage}
                              onPageSizeChange={(s) => {
                                setV2RegsPageSize(s)
                                setV2RegsPage(1)
                              }}
                            />
                          ) : null}
                        </div>
                      </div>
                        </>
                      )}
                    </div>
                  )}
                </>
              )}
            </div>
          </section>
        )}

        {["DIRECTEUR", "MAITRE", "COGES", "IEPP"].includes(roleCode) && (
          <section className="card p-6 space-y-6">
            <div>
              <h2 className="text-lg font-semibold text-gray-900 flex items-center gap-2">
                <CheckCircleIcon className="h-6 w-6 text-orange-600" />
                Accords et suivi des lignes
              </h2>
              <p className="text-sm text-gray-600 mt-1">
                Les accords (accepter / refuser) sont donnés par l&apos;EPP excédentaire (source). Si votre EPP est
                destinataire, les lignes apparaissent ci-dessous à titre informatif.
              </p>
            </div>
            <div className="space-y-2">
              <h3 className="text-sm font-semibold text-gray-800">Excédent (source) — à traiter</h3>
              {pendingLignesSource.length === 0 ? (
                <p className="text-sm text-gray-500">Aucune ligne à traiter en tant que source.</p>
              ) : (
                <div className="rounded-lg border border-gray-200 overflow-hidden">
                  <ul className="divide-y divide-gray-100">
                    {pendingLignesSourcePaged.map((l) => (
                      <li key={l.ligneId} className="py-2 px-2 flex flex-wrap justify-between gap-2 text-sm">
                        <span>
                          {l.reference?.trim()
                            ? `Réf. ${formatRegulationReferenceForDisplay(l.reference)}`
                            : "Ligne en attente"}{" "}
                          —{" "}
                          {formatPendingLigneLibelles(l, { hidePeerEppNames: hidePeerEppNamesForRole(roleCode) })}
                          {l.statutDemande?.trim() &&
                            (l.statutDemande ?? "").trim().toUpperCase() === "EN_ATTENTE_VALIDATION_IEPP" && (
                              <span className="ml-2 text-xs text-amber-800 bg-amber-50 px-1.5 py-0.5 rounded">
                                Demande : validation IEPP en cours
                              </span>
                            )}
                        </span>
                        {l.peutAccorder ? (
                          <div className="flex gap-2 shrink-0">
                            <button
                              type="button"
                              className="rounded-md border border-red-600 bg-red-600 px-3 py-1.5 text-xs font-medium text-white hover:bg-red-700"
                              onClick={() => void handleRefuser(l.ligneId)}
                            >
                              Refuser
                            </button>
                            <button
                              type="button"
                              className="rounded-md border border-emerald-600 bg-emerald-600 px-3 py-1.5 text-xs font-medium text-white hover:bg-emerald-700"
                              onClick={() => void handleApprouver(l.ligneId)}
                            >
                              Accepter
                            </button>
                          </div>
                        ) : null}
                      </li>
                    ))}
                  </ul>
                  <PaginationControls
                    currentPage={pendingPage}
                    totalPages={clientTotalPages(pendingLignesSource.length, pendingPageSize)}
                    pageSize={pendingPageSize}
                    totalCount={pendingLignesSource.length}
                    onPageChange={setPendingPage}
                    onPageSizeChange={(s) => {
                      setPendingPageSize(s)
                      setPendingPage(1)
                    }}
                  />
                </div>
              )}
            </div>
            <div className="space-y-2">
              <h3 className="text-sm font-semibold text-gray-800">Bénéficiaire (destination) — suivi</h3>
              {pendingLignesDest.length === 0 ? (
                <p className="text-sm text-gray-500">Aucune ligne en attente pour votre structure en tant que destinataire.</p>
              ) : (
                <div className="rounded-lg border border-gray-200 overflow-hidden bg-gray-50/50">
                  <ul className="divide-y divide-gray-100">
                    {pendingLignesDestPaged.map((l) => (
                      <li key={l.ligneId} className="py-2 px-2 flex flex-wrap justify-between gap-2 text-sm">
                        <span>
                          {l.reference?.trim()
                            ? `Réf. ${formatRegulationReferenceForDisplay(l.reference)}`
                            : "Ligne"}{" "}
                          —{" "}
                          {formatPendingLigneLibelles(l, { hidePeerEppNames: hidePeerEppNamesForRole(roleCode) })}
                          {l.statutDemande?.trim() && (
                            <span className="ml-2 text-xs text-gray-600">
                              (
                              {(l.statutDemande ?? "").trim().toUpperCase() === "EN_ATTENTE_VALIDATION_IEPP"
                                ? "validation IEPP en cours"
                                : "en attente d'accord des EPP sources"}
                              )
                            </span>
                          )}
                        </span>
                      </li>
                    ))}
                  </ul>
                  <PaginationControls
                    currentPage={pendingDestPage}
                    totalPages={clientTotalPages(pendingLignesDest.length, pendingDestPageSize)}
                    pageSize={pendingDestPageSize}
                    totalCount={pendingLignesDest.length}
                    onPageChange={setPendingDestPage}
                    onPageSizeChange={(s) => {
                      setPendingDestPageSize(s)
                      setPendingDestPage(1)
                    }}
                  />
                </div>
              )}
            </div>
          </section>
        )}

        {roleCode === "DAF" && dafStructureId && (
          <section className="card p-6 space-y-4">
            <h2 className="text-lg font-semibold text-gray-900">DAF — régulation nationale (don direct)</h2>
            <p className="text-sm text-gray-600">
              Le DAF pilote les transferts sur son périmètre national : choisissez la DRENA, le niveau de destination,
              la matière et le niveau scolaire, sans saisie d&apos;IDs techniques.
            </p>
            <div className="rounded-xl border border-indigo-100 bg-indigo-50/50 p-3 text-sm text-indigo-900">
              <span className="font-semibold">Contexte :</span>{" "}
              {selectedDafDrenaId
                ? `DRENA sélectionnée #${selectedDafDrenaId} • Destination ${dafDestinationScope}`
                : "Sélectionnez une DRENA pour charger les structures disponibles."}
            </div>
            <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-3">
              <div>
                <label className="text-xs text-gray-500">Niveau destination</label>
                <select
                  className="input-field w-full"
                  value={dafDestinationScope}
                  onChange={(e) => setDafDestinationScope(e.target.value as "DRENA" | "IEPP" | "EPP")}
                >
                  <option value="DRENA">DRENA</option>
                  <option value="IEPP">IEPP</option>
                  <option value="EPP">EPP</option>
                </select>
              </div>
              <div>
                <label className="text-xs text-gray-500">Structure destination</label>
                <select
                  className="input-field w-full"
                  value={dafForm.destStructureId}
                  onChange={(e) => setDafForm((f) => ({ ...f, destStructureId: e.target.value }))}
                  disabled={!selectedDafDrenaId || loadingDafDestinations}
                >
                  <option value="">
                    {loadingDafDestinations
                      ? "Chargement des structures..."
                      : !selectedDafDrenaId
                        ? "Sélectionner une DRENA d'abord"
                        : "Choisir une destination"}
                  </option>
                  {dafDestinationOptions.map((opt) => (
                    <option key={`${opt.type}-${opt.id}`} value={opt.id}>
                      {opt.label}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="text-xs text-gray-500">Matière</label>
                <select
                  className="input-field w-full"
                  value={dafForm.matiereId}
                  onChange={(e) => setDafForm((f) => ({ ...f, matiereId: e.target.value }))}
                  disabled={loadingDafReferences}
                >
                  <option value="">{loadingDafReferences ? "Chargement..." : "Choisir une matière"}</option>
                  {dafMatieres.map((m) => (
                    <option key={m.id} value={m.id}>
                      {m.libelle || `Matière #${m.id}`}{m.code ? ` (${m.code})` : ""}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="text-xs text-gray-500">Niveau scolaire</label>
                <select
                  className="input-field w-full"
                  value={dafForm.niveauId}
                  onChange={(e) => setDafForm((f) => ({ ...f, niveauId: e.target.value }))}
                  disabled={loadingDafReferences}
                >
                  <option value="">{loadingDafReferences ? "Chargement..." : "Choisir un niveau"}</option>
                  {dafNiveaux.map((n) => (
                    <option key={n.id} value={n.id}>
                      {n.libelle || `Niveau #${n.id}`}{n.code ? ` (${n.code})` : ""}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="text-xs text-gray-500">Quantité</label>
                <input
                  type="number"
                  min={1}
                  className="input-field w-full"
                  value={dafForm.quantite}
                  onChange={(e) => setDafForm((f) => ({ ...f, quantite: e.target.value }))}
                />
              </div>
              <div className="sm:col-span-2">
                <label className="text-xs text-gray-500">Commentaire</label>
                <input
                  className="input-field w-full"
                  value={dafForm.commentaire}
                  onChange={(e) => setDafForm((f) => ({ ...f, commentaire: e.target.value }))}
                />
              </div>
            </div>
            <button
              type="button"
              className="btn-primary"
              onClick={() => void handleDonDaf()}
              disabled={!selectedDafDrenaId || !dafForm.destStructureId || !dafForm.matiereId || !dafForm.niveauId || !dafForm.quantite}
            >
              Valider le don
            </button>
          </section>
        )}

        {!["IEPP", "DRENA", "DAF", "DIRECTEUR", "MAITRE", "COGES", "ADMIN"].includes(roleCode) && (
          <div className="card p-6 text-gray-600 text-sm">
            Votre profil ({roleCode || "—"}) n&apos;est pas couvert par les écrans ci-dessus. Utilisez le menu
            &quot;Régulation&quot; ou contactez l&apos;administrateur.
          </div>
        )}
      </div>

      <RegulationV2AjustementModal
        open={ajustementModal != null}
        onClose={() => setAjustementModal(null)}
        regulationId={ajustementModal?.regulationId ?? 0}
        referenceLabel={ajustementModal?.reference}
        lignesAcceptees={
          ajustementModal != null ? lignesAccepteesPourDemande(ajustementModal.regulationId) : []
        }
        onSaved={async () => {
          await loadSuiviLignesIepp()
          await loadV2Regs()
        }}
      />

      <RegulationV2IeppValidationModal
        open={validationIeppModal != null}
        onClose={() => setValidationIeppModal(null)}
        regulationId={validationIeppModal?.regulationId ?? 0}
        referenceLabel={validationIeppModal?.reference}
        lignesEnAttente={validationIeppModalLignes}
        allowActions={(user?.role?.code ?? "").trim().toUpperCase() === "IEPP"}
        onSaved={async () => {
          await loadSuiviLignesIepp()
          await loadV2Regs()
          await loadPending()
        }}
      />
    </MainLayout>
  )
}
