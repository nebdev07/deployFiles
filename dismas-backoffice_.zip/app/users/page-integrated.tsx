"use client"

import { useState, useEffect } from "react"
import MainLayout from "../../components/layout/main-layout"
import { useAuth } from "../providers"
import { useUsers } from "../../hooks/use-users"
import { usersService } from "@/lib/services/users.service"
import UserModal from "../../components/modals/UserModal"
import { User } from "@/lib/types/entities"
import { canAccessUsersManagementPage } from "@/lib/utils/functionality-permissions"
import {
  PlusIcon,
  UserGroupIcon,
  PencilIcon,
  TrashIcon,
  EyeIcon,
  MagnifyingGlassIcon,
  UserCircleIcon,
  ArrowPathIcon,
  CheckCircleIcon,
  XCircleIcon,
  LockClosedIcon,
  LockOpenIcon,
} from "@heroicons/react/24/outline"

export default function UsersPageIntegrated() {
  const { user } = useAuth()
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedUser, setSelectedUser] = useState<User | null>(null)
  const [showUserModal, setShowUserModal] = useState(false)
  const [isEditing, setIsEditing] = useState(false)
  const [showDetails, setShowDetails] = useState(false)

  // Utilisation du hook pour gérer les utilisateurs avec l'API
  const {
    users,
    loading,
    error,
    totalCount,
    totalPages,
    currentPage,
    pageSize,
    loadUsers,
    searchUsers,
    refreshUsers,
  } = useUsers()

  useEffect(() => {
    if (!user) return
    void loadUsers(undefined, 1, pageSize)
  }, [user?.id, loadUsers, pageSize])
  
  // ✅ Fonctions de gestion des utilisateurs (utilisant directement le service)
  const createUser = async (userData: User): Promise<boolean> => {
    try {
      const response = await usersService.createUser(userData as any);
      if (response.items && response.items.length > 0) {
        await refreshUsers();
        return true;
      }
      return false;
    } catch (error) {
      console.error('Erreur création utilisateur:', error);
      return false;
    }
  };
  
  const updateUser = async (userData: User): Promise<boolean> => {
    try {
      if (!userData.id) {
        console.error('ID utilisateur manquant pour la mise à jour');
        return false;
      }
      const response = await usersService.updateUser(userData.id, userData as any);
      if (response.items && response.items.length > 0) {
        await refreshUsers();
        return true;
      }
      return false;
    } catch (error) {
      console.error('Erreur mise à jour utilisateur:', error);
      return false;
    }
  };
  
  const deleteUser = async (userId: number): Promise<boolean> => {
    try {
      const response = await usersService.deleteUser(userId);
      if (response.items && response.items.length > 0) {
        await refreshUsers();
        return true;
      }
      return false;
    } catch (error) {
      console.error('Erreur suppression utilisateur:', error);
      return false;
    }
  };
  
  const toggleUserStatus = async (userId: number): Promise<boolean> => {
    try {
      // TODO: Implémenter toggleUserStatus dans le service si nécessaire
      await refreshUsers();
      return true;
    } catch (error) {
      console.error('Erreur toggle status utilisateur:', error);
      return false;
    }
  };
  
  const toggleUserLock = async (userId: number): Promise<boolean> => {
    try {
      // TODO: Implémenter toggleUserLock dans le service si nécessaire
      await refreshUsers();
      return true;
    } catch (error) {
      console.error('Erreur toggle lock utilisateur:', error);
      return false;
    }
  };
  
  const resetLoginAttempts = async (userId: number): Promise<boolean> => {
    try {
      // TODO: Implémenter resetLoginAttempts dans le service si nécessaire
      await refreshUsers();
      return true;
    } catch (error) {
      console.error('Erreur reset login attempts:', error);
      return false;
    }
  };

  // Vérification des permissions
  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <p className="text-gray-600">Chargement...</p>
        </div>
      </div>
    )
  }

  if (!canAccessUsersManagementPage(user.role.code, user.functionalityPermissions)) {
    return (
      <MainLayout>
        <div className="flex items-center justify-center h-64">
          <div className="text-center">
            <UserGroupIcon className="mx-auto h-12 w-12 text-gray-400" />
            <h3 className="mt-2 text-sm font-medium text-gray-900">Accès Restreint</h3>
            <p className="mt-1 text-sm text-gray-500">
              Droits utilisateurs (lecture) requis, ou profil autorisé par défaut (administration / territoire).
            </p>
          </div>
        </div>
      </MainLayout>
    )
  }

  const handleCreateUser = () => {
    setSelectedUser(null)
    setIsEditing(false)
    setShowUserModal(true)
  }

  const handleEditUser = (userToEdit: User) => {
    setSelectedUser(userToEdit)
    setIsEditing(true)
    setShowUserModal(true)
  }

  const handleViewUser = (userToView: User) => {
    setSelectedUser(userToView)
    setShowDetails(true)
  }

  const handleDeleteUser = async (userId: number) => {
    if (confirm("Êtes-vous sûr de vouloir supprimer cet utilisateur ?")) {
      await deleteUser(userId)
    }
  }

  const handleSaveUser = async (userData: User): Promise<boolean> => {
    if (isEditing && selectedUser) {
      const userToUpdate = { ...userData, id: selectedUser.id }
      return await updateUser(userToUpdate)
    } else {
      return await createUser(userData)
    }
  }

  const handleSearch = async (term: string) => {
    setSearchTerm(term)
    if (term.trim()) {
      await searchUsers(term)
    } else {
      await loadUsers(undefined, 1, pageSize)
    }
  }

  const handleToggleStatus = async (userToToggle: User) => {
    if (userToToggle.id) {
      await toggleUserStatus(userToToggle.id)
    }
  }

  const handleToggleLock = async (userToToggle: User) => {
    if (userToToggle.id) {
      await toggleUserLock(userToToggle.id)
    }
  }

  const handleResetLoginAttempts = async (userToReset: User) => {
    if (userToReset.id) {
      await resetLoginAttempts(userToReset.id)
    }
  }

  // Filtrer les utilisateurs selon la hiérarchie
  const getFilteredUsers = () => {
    let filteredUsers = users

    // Filtrage hiérarchique selon le rôle de l'utilisateur connecté
    if (user.role.code.toUpperCase() === "DRENA") {
      // DRENA ne voit que ses IEPP et EPP
      filteredUsers = users.filter((u) => 
        u.roleCode === "IEPP" || 
        u.roleCode === "CPPP" ||
        u.roleCode === "EPP" || 
        (u.roleCode === "DRENA" && u.id === user.id)
      )
    } else if (
      user.role.code.toUpperCase() === "IEPP" ||
      user.role.code.toUpperCase() === "CPPP" ||
      user.role.code.toUpperCase() === "INTENDANT" ||
      user.role.code.toUpperCase() === "INTENDENT"
    ) {
      // Inspection / appui IEPP : EPP rattachées + comptes inspection du même périmètre (simplifié)
      filteredUsers = users.filter((u) => 
        u.roleCode === "EPP" || 
        ((u.roleCode === "IEPP" || u.roleCode === "CPPP") && u.id === user.id)
      )
    } else if (user.role.code.toUpperCase() === "DIRECTEUR") {
      // École : ne voit que lui-même
      filteredUsers = users.filter((u) => u.id === user.id)
    }

    return filteredUsers
  }

  const filteredUsers = getFilteredUsers()

  return (
    <MainLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Gestion des Utilisateurs</h1>
            <p className="text-gray-600">
              {totalCount} utilisateur{totalCount > 1 ? "s" : ""} • Page {currentPage}
              {totalPages > 0 ? ` / ${totalPages}` : ""}
            </p>
          </div>
          <div className="flex items-center space-x-3">
            <button
              onClick={refreshUsers}
              className="btn-secondary flex items-center"
              disabled={loading}
            >
              <ArrowPathIcon className={`h-4 w-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
              Actualiser
            </button>
            <button onClick={handleCreateUser} className="btn-primary flex items-center">
              <PlusIcon className="h-4 w-4 mr-2" />
              Nouvel Utilisateur
            </button>
          </div>
        </div>

        {/* Barre de recherche */}
        <div className="flex items-center space-x-4">
          <div className="flex-1 relative">
            <MagnifyingGlassIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
            <input
              type="text"
              placeholder="Rechercher par nom, email ou matricule..."
              value={searchTerm}
              onChange={(e) => handleSearch(e.target.value)}
              className="input-field pl-10"
            />
          </div>
        </div>

        {/* Message d'erreur */}
        {error && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-4">
            <div className="flex">
              <XCircleIcon className="h-5 w-5 text-red-400" />
              <div className="ml-3">
                <h3 className="text-sm font-medium text-red-800">Erreur</h3>
                <p className="text-sm text-red-700 mt-1">{error}</p>
              </div>
            </div>
          </div>
        )}

        {/* Tableau des utilisateurs */}
        <div className="bg-white shadow-sm rounded-lg border border-gray-200">
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Matricule
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Rôle
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Statut
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Dernière Connexion
                  </th>
                  <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {loading ? (
                  <tr>
                    <td colSpan={5} className="px-6 py-12 text-center">
                      <div className="flex items-center justify-center">
                        <ArrowPathIcon className="h-6 w-6 animate-spin text-gray-400" />
                        <span className="ml-2 text-gray-500">Chargement des utilisateurs...</span>
                      </div>
                    </td>
                  </tr>
                ) : filteredUsers.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="px-6 py-12 text-center">
                      <UserGroupIcon className="mx-auto h-12 w-12 text-gray-400" />
                      <h3 className="mt-2 text-sm font-medium text-gray-900">Aucun utilisateur</h3>
                      <p className="mt-1 text-sm text-gray-500">
                        {searchTerm ? 'Aucun utilisateur ne correspond à votre recherche.' : 'Commencez par créer un nouvel utilisateur.'}
                      </p>
                    </td>
                  </tr>
                ) : (
                  filteredUsers.map((userItem) => (
                    <tr key={userItem.id} className="hover:bg-gray-50">
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center">
                          <div className="h-10 w-10 flex-shrink-0">
                            <div className="h-10 w-10 rounded-full bg-orange-100 flex items-center justify-center">
                              <span className="text-orange-600 font-bold text-sm">
                                {userItem.firstName?.charAt(0)}{userItem.lastName?.charAt(0)}
                              </span>
                            </div>
                          </div>
                          <div className="ml-4">
                            <div className="text-sm font-medium text-gray-900">
                              {userItem.firstName} {userItem.lastName}
                            </div>
                            <div className="text-sm text-gray-500">{userItem.email}</div>
                            <div className="text-xs text-gray-400">{userItem.login}</div>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-900">{userItem.fonction || 'N/A'}</div>
                        <div className="text-sm text-gray-500">{userItem.roleCode}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center space-x-2">
                          {userItem.isActive ? (
                            <CheckCircleIcon className="h-5 w-5 text-green-500" />
                          ) : (
                            <XCircleIcon className="h-5 w-5 text-red-500" />
                          )}
                          <span className={`text-sm ${userItem.isActive ? 'text-green-700' : 'text-red-700'}`}>
                            {userItem.isActive ? 'Actif' : 'Inactif'}
                          </span>
                          {userItem.isLocked && (
                            <LockClosedIcon className="h-4 w-4 text-red-500" title="Compte verrouillé" />
                          )}
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {(userItem as any).lastConnectionDate ? new Date((userItem as any).lastConnectionDate).toLocaleDateString('fr-FR') : 'Jamais'}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                        <div className="flex items-center justify-end space-x-2">
                          <button
                            onClick={() => handleViewUser(userItem)}
                            className="text-blue-600 hover:text-blue-800"
                            title="Voir les détails"
                          >
                            <EyeIcon className="h-4 w-4" />
                          </button>
                          <button
                            onClick={() => handleEditUser(userItem)}
                            className="text-indigo-600 hover:text-indigo-800"
                            title="Modifier"
                          >
                            <PencilIcon className="h-4 w-4" />
                          </button>
                          <button
                            onClick={() => handleToggleStatus(userItem)}
                            className={userItem.isActive ? "text-orange-600 hover:text-orange-800" : "text-green-600 hover:text-green-800"}
                            title={userItem.isActive ? "Désactiver" : "Activer"}
                          >
                            {userItem.isActive ? <XCircleIcon className="h-4 w-4" /> : <CheckCircleIcon className="h-4 w-4" />}
                          </button>
                          {userItem.loginAttempts > 0 && (
                            <button
                              onClick={() => handleResetLoginAttempts(userItem)}
                              className="text-yellow-600 hover:text-yellow-800"
                              title="Réinitialiser les tentatives"
                            >
                              <ArrowPathIcon className="h-4 w-4" />
                            </button>
                          )}
                          <button
                            onClick={() => handleDeleteUser(userItem.id!)}
                            className="text-red-600 hover:text-red-800"
                            title="Supprimer"
                          >
                            <TrashIcon className="h-4 w-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Modal de création/modification */}
        <UserModal
          isOpen={showUserModal}
          onClose={() => setShowUserModal(false)}
          onSave={handleSaveUser}
          user={selectedUser}
          title={isEditing ? "Modifier l'utilisateur" : "Nouvel utilisateur"}
        />

        {/* Modal de détails */}
        {showDetails && selectedUser && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-3 sm:p-4">
            <div className="bg-white rounded-lg shadow-xl w-[min(80vw,1440px)] max-w-none max-h-[92vh] overflow-y-auto">
              <div className="flex items-center justify-between p-5 sm:p-6 border-b border-gray-200">
                <h3 className="text-xl sm:text-2xl font-semibold text-gray-900">Détails de l&apos;utilisateur</h3>
                <button
                  onClick={() => setShowDetails(false)}
                  className="text-gray-400 hover:text-gray-600"
                >
                  ×
                </button>
              </div>

              <div className="p-5 sm:p-8 space-y-6 text-base">
                <div className="flex items-center gap-4">
                  <div className="h-16 w-16 sm:h-20 sm:w-20 shrink-0 bg-orange-100 rounded-full flex items-center justify-center">
                    <span className="text-orange-600 font-bold text-2xl sm:text-3xl">
                      {selectedUser.firstName?.charAt(0)}{selectedUser.lastName?.charAt(0)}
                    </span>
                  </div>
                  <div className="min-w-0">
                    <h4 className="text-2xl sm:text-3xl font-bold text-gray-900 break-words">
                      {selectedUser.firstName} {selectedUser.lastName}
                    </h4>
                    <p className="text-gray-600 text-base sm:text-lg mt-1">{selectedUser.fonction}</p>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-5 sm:gap-6">
                  <div className="min-w-0">
                    <p className="text-sm font-semibold text-gray-500 uppercase tracking-wide">Email</p>
                    <p className="text-base sm:text-lg text-gray-900 mt-1 break-all">{selectedUser.email}</p>
                  </div>
                  <div className="min-w-0">
                    <p className="text-sm font-semibold text-gray-500 uppercase tracking-wide">Matricule</p>
                    <p className="text-base sm:text-lg text-gray-900 mt-1 break-all font-mono">{selectedUser.login}</p>
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-gray-500 uppercase tracking-wide">Rôle</p>
                    <p className="text-base sm:text-lg text-gray-900 mt-1">{selectedUser.roleCode}</p>
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-gray-500 uppercase tracking-wide">Statut</p>
                    <p className="text-base sm:text-lg text-gray-900 mt-1">
                      {selectedUser.isActive ? 'Actif' : 'Inactif'}
                    </p>
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-gray-500 uppercase tracking-wide">Type</p>
                    <p className="text-base sm:text-lg text-gray-900 mt-1">
                      {selectedUser.isLdapUser ? 'LDAP' : 'Local'}
                    </p>
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-gray-500 uppercase tracking-wide">Dernière connexion</p>
                    <p className="text-base sm:text-lg text-gray-900 mt-1">
                      {(selectedUser as any).lastConnectionDate ? new Date((selectedUser as any).lastConnectionDate).toLocaleString('fr-FR') : 'Jamais'}
                    </p>
                  </div>
                </div>

                <div className="flex justify-end space-x-3 pt-4 border-t border-gray-200">
                  <button
                    onClick={() => setShowDetails(false)}
                    className="btn-secondary"
                  >
                    Fermer
                  </button>
                  <button
                    onClick={() => {
                      setShowDetails(false)
                      handleEditUser(selectedUser)
                    }}
                    className="btn-primary"
                  >
                    Modifier
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </MainLayout>
  )
}