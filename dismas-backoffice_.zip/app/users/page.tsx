"use client"

import { logger } from '@/lib/utils/logger'

import { useState, useMemo, useEffect } from "react"
import MainLayout from "../../components/layout/main-layout"
import { useAuth } from "../providers"
import { useUsers } from "../../hooks/use-users"
import CreateUserForm from "../../components/forms/CreateUserForm"
import DeleteConfirmationModal from "../../components/modals/DeleteConfirmationModal"
import PaginationControls from "../../components/ui/pagination-controls"
import { User, CreateUserRequest, LegacyUser, UserFilters } from "@/lib/types/entities"
import { usersService } from "@/lib/services/users.service"
import { structuresService, Iepp, Epp } from "@/lib/services/structures.service"
import type { UserCreationPreset } from "@/components/forms/CreateUserForm"
import { 
  mapUsersToListItems, 
  filterUsersByHierarchy, 
  getRoleColor, 
  formatDate,
  formatHierarchyCompoundCode,
  UserListItem,
  collectIeppOccupiedKeys,
  collectEppDirectorCounts,
  matchesStructureHierarchySearch,
  isIeppStructureOccupied,
  isEppDirectorCapacityReached,
  isHierarchyManagedChildRow,
  isIeppInspectionRole,
} from "@/lib/utils/user-mapping"
import { isIntendantRole } from "@/lib/utils/role-codes"
import { canAccessUsersManagementPage } from "@/lib/utils/functionality-permissions"
import { formatErrorForLog, getApiErrorMessage } from "@/lib/utils/api-error-message"
import toast from "react-hot-toast"
import {
  PlusIcon,
  UserGroupIcon,
  PencilIcon,
  TrashIcon,
  EyeIcon,
  EyeSlashIcon,
  MagnifyingGlassIcon,
  UserCircleIcon,
  ArrowPathIcon,
  LockClosedIcon,
  KeyIcon,
  ShieldCheckIcon,
  NoSymbolIcon,
  CheckCircleIcon,
  BuildingOffice2Icon,
  AcademicCapIcon,
} from "@heroicons/react/24/outline"

// Hook pour récupérer les données utilisateurs depuis le backend
const useBackendUsers = () => {
  const {
    users,
    loading,
    error,
    currentPage,
    pageSize,
    totalCount,
    totalPages,
    setPage,
    setPageSize,
    loadUsers,
    refreshUsers,
  } = useUsers();

  return {
    users,
    loading,
    error,
    currentPage,
    pageSize,
    totalCount,
    totalPages,
    setPage,
    setPageSize,
    loadUsers,
    refreshUsers,
  };
};

export default function UsersPage() {
  const { user } = useAuth()
  const {
    users,
    loading,
    error,
    currentPage,
    pageSize,
    totalCount,
    totalPages,
    setPage,
    setPageSize,
    loadUsers,
    refreshUsers,
  } = useBackendUsers()
  const [selectedUser, setSelectedUser] = useState<UserListItem | null>(null)
  const [showModal, setShowModal] = useState(false)
  const [showDetails, setShowDetails] = useState(false)
  const [showEditModal, setShowEditModal] = useState(false)
  const [showDeleteModal, setShowDeleteModal] = useState(false)
  const [searchTerm, setSearchTerm] = useState("")
  const [debouncedSearch, setDebouncedSearch] = useState("")
  const [selectedFilter, setSelectedFilter] = useState("all")
  const [isCreatingUser, setIsCreatingUser] = useState(false)
  const [isUpdatingUser, setIsUpdatingUser] = useState(false)
  const [isDeletingUser, setIsDeletingUser] = useState(false)
  const [unlockingId, setUnlockingId] = useState<number | null>(null)
  const [togglingActiveId, setTogglingActiveId] = useState<number | null>(null)
  const [showResetPasswordModal, setShowResetPasswordModal] = useState(false)
  const [resetPasswordValue, setResetPasswordValue] = useState("")
  const [showResetPasswordPlain, setShowResetPasswordPlain] = useState(false)
  const [isResettingPassword, setIsResettingPassword] = useState(false)

  /** Création / MAJ / suppression / reset MDP en cours — désactive les autres actions liste pour éviter les doubles clics */
  const blockConcurrentUserMutations =
    isCreatingUser || isUpdatingUser || isDeletingUser || isResettingPassword

  const [childIepps, setChildIepps] = useState<Iepp[]>([])
  const [childEpps, setChildEpps] = useState<Epp[]>([])
  const [hierarchyLoading, setHierarchyLoading] = useState(false)
  /** Pagination locale du tableau « structures rattachées » (IEPP / EPP), indépendante de la liste utilisateurs */
  const [hierarchyPage, setHierarchyPage] = useState(1)
  const [hierarchyPageSize, setHierarchyPageSize] = useState(10)
  /** Recherche locale sur code / libellé (tableau structures) */
  const [hierarchySearch, setHierarchySearch] = useState("")
  /** Liste élargie (chargement dédié) pour savoir quelles structures IEPP/EPP sont déjà pourvues */
  const [occupancyUsers, setOccupancyUsers] = useState<User[]>([])
  const [creationPreset, setCreationPreset] = useState<UserCreationPreset | null>(null)

  const isAdmin = user?.role.code === "ADMIN" || user?.role.code === "DAF"

  useEffect(() => {
    const t = window.setTimeout(() => setDebouncedSearch(searchTerm), 380)
    return () => window.clearTimeout(t)
  }, [searchTerm])

  const listFilters = useMemo((): UserFilters => {
    const f: UserFilters = { isDeleted: false }
    if (debouncedSearch.trim()) {
      f.quickSearch = debouncedSearch.trim()
    }
    if (selectedFilter === "actif") {
      f.isActive = true
    } else if (selectedFilter === "inactif") {
      f.isActive = false
    } else if (selectedFilter === "verrouille") {
      f.isLocked = true
    }
    if (["ADMIN", "DRENA", "IEPP", "CPPP", "DIRECTEUR", "INTENDANT"].includes(selectedFilter)) {
      f.roleCode = selectedFilter
    }
    return f
  }, [debouncedSearch, selectedFilter])
  const canCreateUsers =
    isAdmin ||
    user?.role.code === "DRENA" ||
    isIeppInspectionRole(user?.role.code) ||
    user?.role.code === "DIRECTEUR" ||
    user?.role.code === "INFORMATICIEN"
  const showHierarchyPanel =
    user?.role.code === "DRENA" ||
    isIeppInspectionRole(user?.role.code) ||
    user?.role.code === "CPS" ||
    user?.role.code === "INTENDANT" ||
    user?.role.code === "INTENDENT"

  const connectedUserId = user?.id
  const sessionLegacy = (user ?? null) as unknown as LegacyUser | null

  const canPerformUserManagementAction = (target: UserListItem): boolean => {
    if (isAdmin) return true
    const role = user?.role?.code
    if (
      role === "DRENA" ||
      isIeppInspectionRole(role) ||
      role === "CPS" ||
      role === "INTENDANT" ||
      role === "INTENDENT" ||
      role === "DIRECTEUR" ||
      role === "INFORMATICIEN"
    ) {
      return isHierarchyManagedChildRow(
        role,
        sessionLegacy?.drena?.code,
        sessionLegacy?.iepp?.code,
        connectedUserId,
        target,
        sessionLegacy?.epp?.code,
      )
    }
    return false
  }

  const editHierarchyLocks = useMemo(() => {
    if (!user || !selectedUser) return { lockDrena: false, lockIepp: false, lockEpp: false }
    const rc = user.role?.code
    if (rc === "ADMIN" || rc === "DAF") return { lockDrena: false, lockIepp: false, lockEpp: false }
    const managed = isHierarchyManagedChildRow(
      rc,
      sessionLegacy?.drena?.code,
      sessionLegacy?.iepp?.code,
      connectedUserId,
      selectedUser,
      sessionLegacy?.epp?.code,
    )
    if (!managed) return { lockDrena: false, lockIepp: false, lockEpp: false }
    if (rc === "DRENA") return { lockDrena: true, lockIepp: false, lockEpp: false }
    if (isIeppInspectionRole(rc)) return { lockDrena: true, lockIepp: true, lockEpp: false }
    if (rc === "CPS" || rc === "INTENDANT" || rc === "INTENDENT")
      return { lockDrena: true, lockIepp: true, lockEpp: false }
    if (rc === "DIRECTEUR") return { lockDrena: true, lockIepp: true, lockEpp: true }
    if (rc === "INFORMATICIEN") return { lockDrena: true, lockIepp: true, lockEpp: true }
    return { lockDrena: false, lockIepp: false, lockEpp: false }
  }, [
    user,
    selectedUser,
    sessionLegacy?.drena?.code,
    sessionLegacy?.iepp?.code,
    sessionLegacy?.epp?.code,
    connectedUserId,
  ])

  const openCreateUserModal = (preset: UserCreationPreset | null) => {
    setCreationPreset(preset)
    setShowModal(true)
  }

  const closeCreateModal = () => {
    setShowModal(false)
    setCreationPreset(null)
  }

  // Fonction pour gérer la création d'utilisateur
  const handleCreateUser = async (userData: any) => {
    try {
      setIsCreatingUser(true);
      logger.log('Création d\'utilisateur:', userData);
      
      // Vérifier si le login existe déjà
      const loginExists = await usersService.checkLoginExists(userData.login);
      if (loginExists) {
        toast.error('Ce matricule existe déjà. Veuillez en choisir un autre.');
        return;
      }
      
      // Vérifier si l'email existe déjà
      const emailExists = await usersService.checkEmailExists(userData.email);
      if (emailExists) {
        toast.error('Cet email existe déjà. Veuillez en choisir un autre.');
        return;
      }
      
      // Appeler l'API pour créer l'utilisateur
      const response = await usersService.createUser(userData);
      
      if (response.items && response.items.length > 0) {
        // Fermer le modal et recharger la liste
        closeCreateModal();
        // Recharger la liste des utilisateurs
        await refreshUsers();
        
        // Afficher un message de succès
        toast.success('Utilisateur créé avec succès !');
        logger.log('Utilisateur créé:', response.items[0]);
      } else {
        const hint = response.status?.message?.trim();
        toast.error(
          hint || 'La création a réussi mais aucun utilisateur n’a été renvoyé par le serveur.'
        );
      }
      
    } catch (error: unknown) {
      logger.error('Erreur lors de la création de l\'utilisateur:\n', formatErrorForLog(error));
      toast.error(
        getApiErrorMessage(error, 'Erreur lors de la création de l\'utilisateur') ||
          'Erreur lors de la création de l\'utilisateur'
      );
    } finally {
      setIsCreatingUser(false);
    }
  };

  // Fonction pour gérer la modification d'utilisateur
  const handleUpdateUser = async (userData: any) => {
    if (
      selectedUser &&
      userData?.id === selectedUser.id &&
      !canPerformUserManagementAction(selectedUser)
    ) {
      toast.error("Modification non autorisée pour cet utilisateur.");
      return;
    }
    try {
      setIsUpdatingUser(true);
      logger.log('Modification d\'utilisateur:', userData);

      // Appeler l'API pour modifier l'utilisateur
      const response = await usersService.updateUser(userData.id, userData);
      
      if (response.items && response.items.length > 0) {
        // Fermer le modal et recharger la liste
        setShowEditModal(false);
        setSelectedUser(null);
        await refreshUsers();
        
        // Afficher un message de succès
        toast.success('Utilisateur modifié avec succès !');
        logger.log('Utilisateur modifié:', response.items[0]);
      } else {
        toast.error('Erreur lors de la modification de l\'utilisateur');
      }
      
    } catch (error: unknown) {
      logger.error('Erreur lors de la modification de l\'utilisateur:\n', formatErrorForLog(error));
      toast.error(
        getApiErrorMessage(error, 'Erreur lors de la modification de l\'utilisateur') ||
          'Erreur lors de la modification de l\'utilisateur'
      );
    } finally {
      setIsUpdatingUser(false);
    }
  };

  const handleUnlockUser = async (u: UserListItem, opts?: { closeDetails?: boolean }) => {
    if (!canPerformUserManagementAction(u)) return
    const ok = window.confirm(
      `Déverrouiller le compte de ${u.firstName} ${u.lastName} (${u.login}) ?\nL’utilisateur pourra à nouveau se connecter.`
    )
    if (!ok) return
    setUnlockingId(u.id)
    try {
      const response = await usersService.unlockUser(u.id)
      if (response.hasError) {
        toast.error(response.status?.message || "Impossible de déverrouiller le compte")
        return
      }
      toast.success("Compte déverrouillé avec succès")
      await refreshUsers()
      if (opts?.closeDetails) setShowDetails(false)
    } catch (e: any) {
      toast.error(e?.message || "Erreur lors du déverrouillage")
    } finally {
      setUnlockingId(null)
    }
  }

  const handleToggleUserActive = async (u: UserListItem) => {
    if (!canPerformUserManagementAction(u)) return
    const next = !u.isActive
    setTogglingActiveId(u.id)
    try {
      const response = await usersService.updateUser(u.id, { isActive: next } as Partial<CreateUserRequest>)
      if (response.hasError) {
        toast.error(response.status?.message || "Impossible de modifier le statut")
        return
      }
      toast.success(next ? "Utilisateur activé" : "Utilisateur désactivé")
      await refreshUsers()
    } catch (e: any) {
      toast.error(e?.message || "Erreur lors de la mise à jour")
    } finally {
      setTogglingActiveId(null)
    }
  }

  const openResetPasswordFromDetails = () => {
    setResetPasswordValue("")
    setShowResetPasswordPlain(false)
    setShowResetPasswordModal(true)
  }

  const handleResetPasswordSubmit = async () => {
    if (!selectedUser) return
    if (!canPerformUserManagementAction(selectedUser)) return
    const pwd = resetPasswordValue.trim()
    if (pwd.length < 6) {
      toast.error("Le mot de passe doit contenir au moins 6 caractères")
      return
    }
    setIsResettingPassword(true)
    try {
      const response = await usersService.updateUser(selectedUser.id, {
        password: pwd,
        isDefaultPassword: true,
      } as Partial<CreateUserRequest> & { password: string })
      if (response.hasError) {
        toast.error(response.status?.message || "Impossible de réinitialiser le mot de passe")
        return
      }
      toast.success("Mot de passe réinitialisé. Communiquez-le à l’utilisateur de façon sécurisée.")
      setShowResetPasswordModal(false)
      setResetPasswordValue("")
      setShowResetPasswordPlain(false)
    } catch (e: any) {
      toast.error(e?.message || "Erreur lors de la réinitialisation")
    } finally {
      setIsResettingPassword(false)
    }
  }

  const handleDeleteUser = async () => {
    if (!selectedUser) return
    if (!canPerformUserManagementAction(selectedUser)) {
      toast.error("Action non autorisée pour cet utilisateur.")
      return
    }

    try {
      setIsDeletingUser(true);
      logger.log('Suppression d\'utilisateur:', selectedUser.id);
      
      // Appeler l'API pour supprimer l'utilisateur
      const response = await usersService.deleteUser(selectedUser.id);
      
      if (response.items) {
        // Fermer le modal et recharger la liste
        setShowDeleteModal(false);
        setSelectedUser(null);
        await refreshUsers();
        
        // Afficher un message de succès
        toast.success('Utilisateur supprimé avec succès !');
        logger.log('Utilisateur supprimé');
      } else {
        toast.error('Erreur lors de la suppression de l\'utilisateur');
      }
      
    } catch (error) {
      logger.error('Erreur lors de la suppression de l\'utilisateur:', error);
      toast.error('Erreur lors de la suppression de l\'utilisateur');
    } finally {
      setIsDeletingUser(false);
    }
  };

  const handleSearch = (term: string) => {
    setSearchTerm(term)
  }

  // IEPP rattachés à la DRENA / EPP rattachées à l’IEPP (structures « enfants »)
  useEffect(() => {
    if (!user) return
    const role = user.role?.code
    const drenaId = sessionLegacy?.drena?.id
    const ieppId = sessionLegacy?.iepp?.id
    if (role === "DRENA" && drenaId) {
      setHierarchyLoading(true)
      structuresService
        .getIeppsByDrena(drenaId)
        .then((res) => {
          const raw = res.items
          const flat = Array.isArray(raw) ? (Array.isArray(raw[0]) ? (raw as unknown as Iepp[][]).flat() : (raw as unknown as Iepp[])) : []
          setChildIepps(flat)
          setChildEpps([])
        })
        .catch(() => {
          setChildIepps([])
        })
        .finally(() => setHierarchyLoading(false))
      return
    }
    if (isIeppInspectionRole(role) && ieppId) {
      setHierarchyLoading(true)
      structuresService
        .getEppsByIepp(ieppId)
        .then((res) => {
          const raw = res.items
          const flat = Array.isArray(raw) ? (Array.isArray(raw[0]) ? (raw as unknown as Epp[][]).flat() : (raw as unknown as Epp[])) : []
          setChildEpps(flat)
          setChildIepps([])
        })
        .catch(() => setChildEpps([]))
        .finally(() => setHierarchyLoading(false))
      return
    }
    setChildIepps([])
    setChildEpps([])
  }, [user, sessionLegacy?.drena?.id, sessionLegacy?.iepp?.id])

  useEffect(() => {
    if (!showHierarchyPanel || !user) {
      setOccupancyUsers([])
      return
    }
    let cancelled = false
    usersService
      .getUsersForStructureOccupancy(8000)
      .then((list) => {
        if (!cancelled) setOccupancyUsers(list)
      })
      .catch(() => {
        if (!cancelled) setOccupancyUsers([])
      })
    return () => {
      cancelled = true
    }
  }, [showHierarchyPanel, user?.id, sessionLegacy?.drena?.id, sessionLegacy?.iepp?.id])

  // Conversion + périmètre hiérarchique (les filtres actif / rôle / recherche sont côté serveur)
  const tableRows = useMemo(() => {
    if (!user) return [] as UserListItem[]
    const list = mapUsersToListItems(users)
    const currentUserItem = {
      id: user.id || 0,
      firstName: (user as any).prenoms || (user as any).firstName || '',
      lastName: (user as any).nom || (user as any).lastName || '',
      email: user.email || '',
      login: user.login || '',
      role: user.role || { id: 0, code: '', libelle: '' },
      structure: { code: '', libelle: '', type: '' },
      isActive: true,
      telephone: '',
      drenaCode: sessionLegacy?.drena?.code,
      ieppCode: sessionLegacy?.iepp?.code,
      eppCode: sessionLegacy?.epp?.code,
    } as UserListItem
    return filterUsersByHierarchy(list, currentUserItem)
  }, [user, users, sessionLegacy?.drena?.code, sessionLegacy?.iepp?.code, sessionLegacy?.epp?.code])

  const filteredTotalCount = totalCount
  const filteredTotalPages = totalPages

  const occupancyUsersForStructures = useMemo(() => {
    if (occupancyUsers.length > 0) return occupancyUsers
    return users
  }, [occupancyUsers, users])

  const availableChildIepps = useMemo(() => {
    const occ = collectIeppOccupiedKeys(occupancyUsersForStructures)
    return childIepps
      .filter((row) => !isIeppStructureOccupied(row, occ))
      .filter((row) => matchesStructureHierarchySearch(row, hierarchySearch))
  }, [childIepps, occupancyUsersForStructures, hierarchySearch])

  const availableChildEpps = useMemo(() => {
    const directorCounts = collectEppDirectorCounts(occupancyUsersForStructures)
    return childEpps
      .filter((row) => !isEppDirectorCapacityReached(row, directorCounts))
      .filter((row) => matchesStructureHierarchySearch(row, hierarchySearch))
  }, [childEpps, occupancyUsersForStructures, hierarchySearch])

  const hierarchyRowCount =
    user?.role.code === "DRENA"
      ? availableChildIepps.length
      : isIeppInspectionRole(user?.role.code)
        ? availableChildEpps.length
        : 0
  const hierarchyTotalPages =
    hierarchyRowCount === 0 ? 0 : Math.ceil(hierarchyRowCount / hierarchyPageSize)

  const paginatedChildIepps = useMemo(() => {
    const start = (hierarchyPage - 1) * hierarchyPageSize
    return availableChildIepps.slice(start, start + hierarchyPageSize)
  }, [availableChildIepps, hierarchyPage, hierarchyPageSize])

  const paginatedChildEpps = useMemo(() => {
    const start = (hierarchyPage - 1) * hierarchyPageSize
    return availableChildEpps.slice(start, start + hierarchyPageSize)
  }, [availableChildEpps, hierarchyPage, hierarchyPageSize])

  useEffect(() => {
    setHierarchyPage(1)
  }, [hierarchySearch, childIepps.length, childEpps.length, user?.role?.code])

  useEffect(() => {
    if (hierarchyTotalPages <= 0) return
    if (hierarchyPage > hierarchyTotalPages) {
      setHierarchyPage(hierarchyTotalPages)
    }
  }, [hierarchyTotalPages, hierarchyPage])

  const handleHierarchyPageSizeChange = (size: number) => {
    setHierarchyPageSize(size)
    setHierarchyPage(1)
  }

  useEffect(() => {
    setPage(1)
  }, [selectedFilter, debouncedSearch, setPage])

  useEffect(() => {
    if (!user) return
    void loadUsers(listFilters, currentPage, pageSize)
  }, [user?.id, listFilters, currentPage, pageSize, loadUsers])

  useEffect(() => {
    if (filteredTotalPages <= 0) return
    if (currentPage > filteredTotalPages) {
      setPage(filteredTotalPages)
    }
  }, [filteredTotalPages, currentPage, setPage])

  // ✅ Vérification session après tous les hooks
  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <p className="text-gray-600">Chargement...</p>
        </div>
      </div>
    )
  }

  if (!canAccessUsersManagementPage(user.role.code, user.functionalityPermissions)) {
    return (
      <MainLayout>
        <div className="text-center py-12">
          <ShieldCheckIcon className="h-16 w-16 text-gray-400 mx-auto mb-4" />
          <h2 className="text-xl font-semibold text-gray-900 mb-2">Accès restreint</h2>
          <p className="text-gray-600">Vous n&apos;avez pas les droits pour la gestion des utilisateurs (USER:READ).</p>
        </div>
      </MainLayout>
    )
  }

  // Statistiques calculées sur les utilisateurs filtrés
  const totalUsers = totalCount
  const activeUsers = tableRows.filter((u) => u.isActive).length
  const inactiveUsers = tableRows.filter((u) => !u.isActive).length
  const lockedUsers = tableRows.filter((u) => !!u.isLocked).length

  // Stats par rôle (page courante — le total filtré est « Total utilisateurs »)
  const statsByRole = tableRows.reduce(
    (acc, row) => {
      acc[row.role.code] = (acc[row.role.code] || 0) + 1
      return acc
    },
    {} as Record<string, number>,
  )

  return (
    <MainLayout>
      <div className="space-y-8">
        {/* Header */}
        <div className="relative overflow-hidden rounded-2xl border border-gray-200/80 bg-white shadow-sm">
          <div className="absolute inset-0 bg-gradient-to-br from-orange-50/90 via-white to-green-50/70 pointer-events-none" />
          <div className="relative flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6 p-6 sm:p-8">
            <div className="flex gap-4">
              <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl bg-gradient-to-br from-orange-500 to-orange-600 text-white shadow-lg shadow-orange-500/25">
                <ShieldCheckIcon className="h-8 w-8" />
              </div>
              <div>
                <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-gray-900">
                  Gestion des utilisateurs
                </h1>
                <p className="mt-1 text-gray-600 max-w-xl">
                  Créez des comptes, contrôlez l’accès, déverrouillez les utilisateurs bloqués et agissez en toute sécurité.
                </p>
                {loading && (
                  <p className="mt-2 text-sm text-orange-600 flex items-center gap-2">
                    <ArrowPathIcon className="h-4 w-4 animate-spin" /> Chargement des données…
                  </p>
                )}
                {error && <p className="mt-2 text-sm text-red-600">{error}</p>}
              </div>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <button
                onClick={refreshUsers}
                className="btn-outline inline-flex items-center"
                disabled={loading || blockConcurrentUserMutations}
                title="Actualiser la liste"
                type="button"
              >
                <ArrowPathIcon className="h-5 w-5 mr-2" />
                Actualiser
              </button>
              {canCreateUsers && (
                <button
                  onClick={() => {
                    if (user?.role.code === "DRENA" && sessionLegacy?.drena?.id) {
                      openCreateUserModal({
                        roleCode: "",
                        drenaId: String(sessionLegacy?.drena.id),
                        lockDrena: true,
                        lockRole: false,
                        source: "fromHeader",
                      })
                    } else if (isIeppInspectionRole(user?.role.code) && sessionLegacy?.drena?.id && sessionLegacy?.iepp?.id) {
                      openCreateUserModal({
                        roleCode: "",
                        drenaId: String(sessionLegacy?.drena.id),
                        ieppId: String(sessionLegacy?.iepp.id),
                        lockDrena: true,
                        lockIepp: true,
                        lockRole: false,
                        source: "fromHeader",
                      })
                    } else if (
                      (user?.role.code === "DIRECTEUR" || user?.role.code === "INFORMATICIEN") &&
                      sessionLegacy?.drena?.id &&
                      sessionLegacy?.iepp?.id &&
                      sessionLegacy?.epp?.id
                    ) {
                      openCreateUserModal({
                        roleCode: "",
                        drenaId: String(sessionLegacy.drena.id),
                        ieppId: String(sessionLegacy.iepp.id),
                        eppId: String(sessionLegacy.epp.id),
                        lockDrena: true,
                        lockIepp: true,
                        lockEpp: true,
                        lockRole: false,
                        source: "fromHeader",
                      })
                    } else if (user?.role.code === "DIRECTEUR" || user?.role.code === "INFORMATICIEN") {
                      toast.error(
                        "Rattachement incomplet : une DRENA, une IEPP et une EPP sont requises sur votre compte pour créer un utilisateur d'équipe établissement.",
                      )
                    } else {
                      openCreateUserModal(null)
                    }
                  }}
                  className="btn-primary inline-flex items-center shadow-md shadow-orange-500/20"
                  type="button"
                  disabled={loading || hierarchyLoading || blockConcurrentUserMutations}
                >
                  <PlusIcon className="h-5 w-5 mr-2" />
                  Nouvel utilisateur
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-5 gap-4 md:gap-6">
          <div className="stat-card">
            <div className="flex items-center">
              <div className="p-3 rounded-lg bg-blue-50 text-blue-600">
                <UserGroupIcon className="h-6 w-6" />
              </div>
              <div className="ml-4">
                <p className="stat-label">Total Utilisateurs</p>
                <p className="stat-value">{totalUsers}</p>
              </div>
            </div>
          </div>

          <div className="stat-card">
            <div className="flex items-center">
              <div className="p-3 rounded-lg bg-green-50 text-green-600">
                <UserCircleIcon className="h-6 w-6" />
              </div>
              <div className="ml-4">
                <p className="stat-label">Actifs</p>
                <p className="stat-value">{activeUsers}</p>
              </div>
            </div>
          </div>

          <div className="stat-card">
            <div className="flex items-center">
              <div className="p-3 rounded-lg bg-red-50 text-red-600">
                <UserCircleIcon className="h-6 w-6" />
              </div>
              <div className="ml-4">
                <p className="stat-label">Inactifs</p>
                <p className="stat-value">{inactiveUsers}</p>
              </div>
            </div>
          </div>

          <div className="stat-card ring-1 ring-amber-100/80">
            <div className="flex items-center">
              <div className="p-3 rounded-xl bg-amber-50 text-amber-700">
                <LockClosedIcon className="h-6 w-6" />
              </div>
              <div className="ml-4">
                <p className="stat-label">Verrouillés</p>
                <p className="stat-value">{lockedUsers}</p>
              </div>
            </div>
          </div>

          <div className="stat-card">
            <div className="flex items-center">
              <div className="p-3 rounded-lg bg-purple-50 text-purple-600">
                <UserGroupIcon className="h-6 w-6" />
              </div>
              <div className="ml-4">
                <p className="stat-label">Directeurs</p>
                <p className="stat-value">{statsByRole.DIRECTEUR || 0}</p>
              </div>
            </div>
          </div>
        </div>

        {/* Répartition par rôle */}
        <div className="card border-0 shadow-md ring-1 ring-gray-100">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Répartition par rôle</h3>
          <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
            {Object.entries(statsByRole).map(([role, count]) => (
              <div
                key={role}
                className="text-center p-4 rounded-xl bg-gradient-to-b from-gray-50 to-white border border-gray-100/80"
              >
                <div className="text-2xl font-bold bg-gradient-to-r from-orange-600 to-green-600 bg-clip-text text-transparent">{count}</div>
                <div className="text-sm text-gray-600 font-medium">{role}</div>
              </div>
            ))}
          </div>
        </div>

        {showHierarchyPanel && (
          <div className="card border-0 shadow-md ring-1 ring-gray-100 overflow-hidden">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 px-1 pb-3 border-b border-gray-100">
              <div className="flex items-center gap-3">
                <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-emerald-50 text-emerald-700">
                  {user?.role.code === "DRENA" ? (
                    <AcademicCapIcon className="h-6 w-6" />
                  ) : (
                    <BuildingOffice2Icon className="h-6 w-6" />
                  )}
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-gray-900">
                    {user?.role.code === "DRENA" ? "IEPP de votre DRENA" : "EPP de votre IEPP"}
                  </h3>
                  <p className="text-sm text-gray-500">
                    IEPP : masquées dès qu&apos;un inspecteur (rôle IEPP) est rattaché. EPP : affichées tant qu&apos;il
                    reste moins de deux comptes directeur ; au-delà, la ligne disparaît de cette liste.
                  </p>
                </div>
              </div>
            </div>
            <div className="px-1 pt-3 flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
              <div className="relative flex-1 max-w-md">
                <MagnifyingGlassIcon className="h-5 w-5 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                <input
                  type="search"
                  className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-xl bg-white text-sm focus:outline-none focus:ring-2 focus:ring-orange-500/30 focus:border-orange-300"
                  placeholder="Rechercher par code ou libellé…"
                  value={hierarchySearch}
                  onChange={(e) => setHierarchySearch(e.target.value)}
                  aria-label="Rechercher dans les structures"
                />
              </div>
              <p className="text-xs text-gray-500 sm:max-w-md sm:text-right">
                Liste filtrée : comptes existants détectés à partir des utilisateurs chargés (hors recherche du tableau
                principal).
              </p>
            </div>
            <div className="overflow-x-auto -mx-px mt-2">
              {hierarchyLoading ? (
                <div className="flex items-center justify-center py-10 text-gray-500 gap-2">
                  <ArrowPathIcon className="h-5 w-5 animate-spin" />
                  Chargement des structures…
                </div>
              ) : user?.role.code === "DRENA" ? (
                childIepps.length === 0 ? (
                  <p className="text-sm text-gray-500 py-6 text-center">Aucun IEPP enregistré pour votre DRENA.</p>
                ) : availableChildIepps.length === 0 ? (
                  <p className="text-sm text-gray-500 py-6 text-center px-2">
                    {hierarchySearch.trim()
                      ? "Aucun IEPP ne correspond à cette recherche (ou tous ont déjà un compte inspecteur)."
                      : "Tous les IEPP listés ont déjà un compte inspecteur associé."}
                  </p>
                ) : (
                  <table className="table min-w-[640px]">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="!font-semibold">Code</th>
                        <th className="!font-semibold">Libellé</th>
                        <th className="!font-semibold text-right">Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      {paginatedChildIepps.map((row) => (
                        <tr key={row.id}>
                          <td className="font-mono text-sm">{row.code}</td>
                          <td>{row.libelle}</td>
                          <td className="text-right">
                            <button
                              type="button"
                              className="btn-outline text-sm py-1.5 px-3 inline-flex items-center gap-1"
                              onClick={() => {
                                if (!sessionLegacy?.drena?.id) return
                                openCreateUserModal({
                                  roleCode: "",
                                  drenaId: String(sessionLegacy?.drena.id),
                                  ieppId: String(row.id),
                                  lockDrena: true,
                                  lockIepp: true,
                                  lockRole: false,
                                  source: "fromRow",
                                })
                              }}
                              disabled={loading || hierarchyLoading || blockConcurrentUserMutations}
                            >
                              <PlusIcon className="h-4 w-4" />
                              Nouvel utilisateur
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                )
              ) : childEpps.length === 0 ? (
                <p className="text-sm text-gray-500 py-6 text-center">Aucune EPP rattachée à votre IEPP.</p>
              ) : availableChildEpps.length === 0 ? (
                <p className="text-sm text-gray-500 py-6 text-center px-2">
                  {hierarchySearch.trim()
                    ? "Aucune EPP ne correspond à cette recherche (ou chacune a déjà deux comptes directeur)."
                    : "Toutes les EPP listées ont déjà deux comptes directeur (plafond atteint)."}
                </p>
              ) : (
                <table className="table min-w-[640px]">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="!font-semibold">Code</th>
                      <th className="!font-semibold">Libellé</th>
                      <th className="!font-semibold text-right">Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    {paginatedChildEpps.map((row) => (
                      <tr key={row.id}>
                        <td className="font-mono text-sm">{row.code}</td>
                        <td>{row.libelle}</td>
                        <td className="text-right">
                          <button
                            type="button"
                            className="btn-outline text-sm py-1.5 px-3 inline-flex items-center gap-1"
                            onClick={() => {
                              if (!sessionLegacy?.drena?.id || !sessionLegacy?.iepp?.id) return
                              openCreateUserModal({
                                roleCode: "",
                                drenaId: String(sessionLegacy?.drena.id),
                                ieppId: String(sessionLegacy?.iepp.id),
                                eppId: String(row.id),
                                lockDrena: true,
                                lockIepp: true,
                                lockEpp: true,
                                lockRole: false,
                                source: "fromRow",
                              })
                            }}
                            disabled={loading || hierarchyLoading || blockConcurrentUserMutations}
                          >
                            <PlusIcon className="h-4 w-4" />
                            Nouvel utilisateur
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </div>
            {!hierarchyLoading && hierarchyRowCount > 0 && (
              <PaginationControls
                currentPage={hierarchyPage}
                totalPages={Math.max(1, hierarchyTotalPages)}
                pageSize={hierarchyPageSize}
                totalCount={hierarchyRowCount}
                onPageChange={setHierarchyPage}
                onPageSizeChange={handleHierarchyPageSizeChange}
                loading={hierarchyLoading || blockConcurrentUserMutations}
              />
            )}
          </div>
        )}

        {/* Filtres et recherche */}
        <div className="card border-0 shadow-md ring-1 ring-gray-100">
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
            <div className="relative flex-1 max-w-md">
              <MagnifyingGlassIcon className="h-5 w-5 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                type="text"
                className="w-full pl-10 pr-4 py-2.5 border border-gray-200 rounded-xl bg-gray-50/80 focus:outline-none focus:ring-2 focus:ring-orange-500/40 focus:border-orange-300 transition-shadow"
                placeholder="Rechercher par nom, matricule, email…"
                value={searchTerm}
                onChange={(e) => handleSearch(e.target.value)}
                disabled={loading}
              />
            </div>
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-sm text-gray-500 hidden sm:inline">Filtrer :</span>
              <select
                className="px-3 py-2.5 border border-gray-200 rounded-xl bg-white focus:outline-none focus:ring-2 focus:ring-orange-500/40 text-sm font-medium text-gray-800 min-w-[200px]"
                value={selectedFilter}
                onChange={(e) => setSelectedFilter(e.target.value)}
              >
                <option value="all">Tous les utilisateurs</option>
                <option value="actif">Comptes actifs</option>
                <option value="inactif">Comptes inactifs</option>
                <option value="verrouille">Comptes verrouillés</option>
                <option value="ADMIN">Administrateurs</option>
                <option value="DRENA">DRENA</option>
                <option value="IEPP">IEPP</option>
                <option value="CPPP">CPPP</option>
                <option value="DIRECTEUR">Directeurs</option>
                <option value="INTENDANT">Intendants</option>
              </select>
            </div>
          </div>
        </div>

        {/* Liste des utilisateurs */}
        <div className="card border-0 shadow-md ring-1 ring-gray-100 overflow-hidden">
          <div className="px-1 pb-4 border-b border-gray-100 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
            <h3 className="text-lg font-semibold text-gray-900">Liste des utilisateurs</h3>
            <p className="text-sm text-gray-500">
              {filteredTotalCount === 0
                ? "Aucun compte ne correspond au filtre"
                : `${filteredTotalCount} compte(s) — page ${currentPage} / ${filteredTotalPages}`}
            </p>
          </div>
          <div className="overflow-x-auto -mx-px">
            <table className="table min-w-[920px]">
              <thead className="bg-gradient-to-r from-gray-50 to-orange-50/30">
                <tr>
                  <th className="!font-semibold text-gray-700">Matricule</th>
                  <th className="!font-semibold text-gray-700">Email</th>
                  <th className="!font-semibold text-gray-700">Rôle</th>
                  <th className="!font-semibold text-gray-700">Structure</th>
                  <th className="!font-semibold text-gray-700">Sécurité</th>
                  <th className="!font-semibold text-gray-700">Statut</th>
                  <th className="!font-semibold text-gray-700 text-right">Actions</th>
                </tr>
              </thead>
              <tbody>
                {loading ? (
                  <tr>
                    <td colSpan={7} className="text-center py-8">
                      <div className="flex items-center justify-center">
                        <ArrowPathIcon className="h-5 w-5 animate-spin mr-2" />
                        Chargement des utilisateurs...
                      </div>
                    </td>
                  </tr>
                ) : tableRows.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="text-center py-8">
                      <div className="text-gray-500">
                        {searchTerm ? 'Aucun utilisateur trouvé pour cette recherche' : 'Aucun utilisateur disponible'}
                      </div>
                    </td>
                  </tr>
                ) : (
                  tableRows.map((utilisateur) => (
                    <tr key={utilisateur.id}>
                      <td>
                        <div className="flex items-center">
                          <div className="h-10 w-10 bg-orange-100 rounded-full flex items-center justify-center">
                            <span className="text-orange-600 font-semibold text-sm">
                              {utilisateur.firstName.charAt(0)}
                              {utilisateur.lastName.charAt(0)}
                            </span>
                          </div>
                          <div className="ml-3">
                            <p className="font-medium">
                              {utilisateur.firstName} {utilisateur.lastName}
                            </p>
                            <p className="text-sm text-gray-500">{utilisateur.login}</p>
                          </div>
                        </div>
                      </td>
                      <td>
                        <div>
                          <p className="font-medium">{utilisateur.email}</p>
                          <p className="text-sm text-gray-500">{utilisateur.telephone || '-'}</p>
                        </div>
                      </td>
                      <td>
                        <span
                          className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getRoleColor(utilisateur.role.code)}`}
                        >
                          {utilisateur.role.libelle}
                        </span>
                      </td>
                      <td>
                        <div>
                          <p className="font-medium">{utilisateur.structure.libelle}</p>
                          <p className="text-sm text-gray-500">{utilisateur.structure.code}</p>
                        </div>
                      </td>
                        {/* <td>
                          {formatDate(utilisateur.lastConnectionDate)}
                        </td> */}
                      <td>
                        <div className="flex flex-col gap-1">
                          {utilisateur.isLocked ? (
                            <span className="inline-flex items-center gap-1 w-fit px-2 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800 border border-red-200">
                              <LockClosedIcon className="h-3.5 w-3.5" />
                              Verrouillé
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1 w-fit px-2 py-0.5 rounded-full text-xs font-medium bg-emerald-50 text-emerald-800 border border-emerald-100">
                              <CheckCircleIcon className="h-3.5 w-3.5" />
                              OK
                            </span>
                          )}
                          {typeof utilisateur.loginAttempts === "number" && (
                            <span className="text-xs text-gray-500">
                              Tentatives : {utilisateur.loginAttempts}
                            </span>
                          )}
                        </div>
                      </td>
                      <td>
                        <span className={utilisateur.isActive ? "badge-success" : "badge-error"}>
                          {utilisateur.isActive ? "Actif" : "Inactif"}
                        </span>
                      </td>
                      <td>
                        <div className="flex items-center justify-end flex-wrap gap-1">
                          <button
                            onClick={() => {
                              setSelectedUser(utilisateur)
                              setShowDetails(true)
                            }}
                            className="p-1.5 rounded-lg text-blue-600 hover:bg-blue-50 transition-colors disabled:opacity-50"
                            title="Voir détails"
                            disabled={loading || blockConcurrentUserMutations}
                            type="button"
                          >
                            <EyeIcon className="h-4 w-4" />
                          </button>
                          {canPerformUserManagementAction(utilisateur) && utilisateur.isLocked && (
                            <button
                              onClick={() => handleUnlockUser(utilisateur)}
                              className="p-1.5 rounded-lg text-amber-700 hover:bg-amber-50 transition-colors disabled:opacity-50"
                              title="Déverrouiller le compte"
                              disabled={loading || blockConcurrentUserMutations || unlockingId === utilisateur.id}
                              type="button"
                            >
                              {unlockingId === utilisateur.id ? (
                                <ArrowPathIcon className="h-4 w-4 animate-spin" />
                              ) : (
                                <KeyIcon className="h-4 w-4" />
                              )}
                            </button>
                          )}
                          {canPerformUserManagementAction(utilisateur) && (
                            <>
                              <button
                                onClick={() => {
                                  setSelectedUser(utilisateur);
                                  setShowEditModal(true);
                                }}
                                className="p-1.5 rounded-lg text-orange-600 hover:bg-orange-50 transition-colors disabled:opacity-50"
                                title="Modifier"
                                disabled={loading || blockConcurrentUserMutations}
                                type="button"
                              >
                                <PencilIcon className="h-4 w-4" />
                              </button>
                              <button
                                onClick={() => handleToggleUserActive(utilisateur)}
                                className={`p-1.5 rounded-lg transition-colors disabled:opacity-50 ${
                                  utilisateur.isActive
                                    ? "text-red-600 hover:bg-red-50"
                                    : "text-green-600 hover:bg-green-50"
                                }`}
                                title={utilisateur.isActive ? "Désactiver le compte" : "Activer le compte"}
                                disabled={loading || blockConcurrentUserMutations || togglingActiveId === utilisateur.id}
                                type="button"
                              >
                                {togglingActiveId === utilisateur.id ? (
                                  <ArrowPathIcon className="h-4 w-4 animate-spin text-gray-500" />
                                ) : utilisateur.isActive ? (
                                  <NoSymbolIcon className="h-4 w-4 text-red-600" />
                                ) : (
                                  <CheckCircleIcon className="h-4 w-4 text-green-600" />
                                )}
                              </button>
                              <button 
                                onClick={() => {
                                  setSelectedUser(utilisateur);
                                  setShowDeleteModal(true);
                                }}
                                className="p-1.5 rounded-lg text-red-600 hover:bg-red-50 transition-colors disabled:opacity-50" 
                                title="Supprimer"
                                disabled={loading || blockConcurrentUserMutations}
                                type="button"
                              >
                                <TrashIcon className="h-4 w-4" />
                              </button>
                            </>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Pagination */}
        {!loading && filteredTotalCount > 0 && (
          <PaginationControls
            currentPage={currentPage}
            totalPages={Math.max(1, filteredTotalPages)}
            pageSize={pageSize}
            totalCount={filteredTotalCount}
            onPageChange={setPage}
            onPageSizeChange={setPageSize}
            loading={loading || blockConcurrentUserMutations}
          />
        )}

        {/* Modal détails utilisateur */}
        {showDetails && selectedUser && (
          <div
            className="modal-overlay"
            onClick={() => {
              if (!isResettingPassword) setShowDetails(false)
            }}
          >
            <div
              className="modal-content !max-w-none !w-[80vw] mx-3 sm:mx-5 max-h-[92vh] overflow-y-auto p-0 border-0 shadow-2xl ring-1 ring-gray-200/80"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="relative bg-gradient-to-br from-orange-500 via-orange-600 to-amber-600 px-6 py-6 text-white">
                <div className="absolute inset-0 bg-[url('data:image/svg+xml,%3Csvg width=\'60\' height=\'60\' viewBox=\'0 0 60 60\' xmlns=\'http://www.w3.org/2000/svg\'%3E%3Cg fill=\'none\' fill-rule=\'evenodd\'%3E%3Cg fill=\'%23ffffff\' fill-opacity=\'0.06\'%3E%3Cpath d=\'M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z\'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E')] opacity-90" />
                <div className="relative flex items-start justify-between gap-4">
                  <div className="flex items-center gap-4 min-w-0">
                    <div className="h-16 w-16 shrink-0 rounded-2xl bg-white/20 backdrop-blur-sm flex items-center justify-center ring-2 ring-white/30 shadow-lg">
                      <span className="text-2xl font-bold tracking-tight">
                        {selectedUser.firstName.charAt(0)}
                        {selectedUser.lastName.charAt(0)}
                      </span>
                    </div>
                    <div className="min-w-0">
                      <h3 className="text-xl font-bold tracking-tight truncate">
                        {selectedUser.firstName} {selectedUser.lastName}
                      </h3>
                      <p className="text-orange-100 text-sm mt-0.5">{selectedUser.role.libelle}</p>
                      <p className="text-white/90 text-sm font-mono truncate mt-1">@{selectedUser.login}</p>
                      <div className="text-white/90 text-xs mt-2 space-y-2 max-w-xl text-left">
                        <div className="rounded-lg bg-white/10 px-2.5 py-2 ring-1 ring-white/15">
                          <p className="text-[10px] font-semibold uppercase tracking-wide text-orange-100/85">
                            {isIeppInspectionRole(selectedUser.role.code) || isIntendantRole(selectedUser.role.code)
                              ? "Inspection / appui (IEPP)"
                              : selectedUser.role.code === "DIRECTEUR"
                                ? "Établissement (EPP)"
                                : "Structure"}
                          </p>
                          <p className="mt-0.5 font-medium text-white leading-snug">{selectedUser.structure?.libelle}</p>
                        </div>
                        {(isIeppInspectionRole(selectedUser.role.code) || isIntendantRole(selectedUser.role.code)) &&
                          selectedUser.drenaLibelle && (
                          <div className="rounded-lg bg-white/10 px-2.5 py-2 ring-1 ring-white/15">
                            <p className="text-[10px] font-semibold uppercase tracking-wide text-orange-100/85">
                              DRENA de rattachement
                            </p>
                            <p className="mt-0.5 text-orange-50/95 leading-snug">{selectedUser.drenaLibelle}</p>
                          </div>
                        )}
                        {selectedUser.role.code === "DIRECTEUR" &&
                          (selectedUser.ieppLibelle || selectedUser.drenaLibelle) && (
                            <div className="space-y-2">
                              {selectedUser.ieppLibelle && (
                                <div className="rounded-lg bg-white/10 px-2.5 py-2 ring-1 ring-white/15">
                                  <p className="text-[10px] font-semibold uppercase tracking-wide text-orange-100/85">
                                    IEPP de rattachement
                                  </p>
                                  <p className="mt-0.5 text-orange-50/95 leading-snug">{selectedUser.ieppLibelle}</p>
                                </div>
                              )}
                              {selectedUser.ieppLibelle && selectedUser.drenaLibelle && (
                                <div className="flex items-center gap-2 px-1 text-orange-200/70" aria-hidden>
                                  <span className="h-px flex-1 border-t border-dashed border-white/35" />
                                  <span className="text-[10px] uppercase tracking-wider shrink-0">puis</span>
                                  <span className="h-px flex-1 border-t border-dashed border-white/35" />
                                </div>
                              )}
                              {selectedUser.drenaLibelle && (
                                <div className="rounded-lg bg-white/10 px-2.5 py-2 ring-1 ring-white/15">
                                  <p className="text-[10px] font-semibold uppercase tracking-wide text-orange-100/85">
                                    DRENA de rattachement
                                  </p>
                                  <p className="mt-0.5 text-orange-50/95 leading-snug">{selectedUser.drenaLibelle}</p>
                                </div>
                              )}
                            </div>
                          )}
                      </div>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => setShowDetails(false)}
                    className="shrink-0 rounded-xl p-2 text-white/90 hover:bg-white/15 transition-colors"
                    aria-label="Fermer"
                  >
                    <span className="text-2xl leading-none">×</span>
                  </button>
                </div>
              </div>

              <div className="p-6 sm:p-8 space-y-6 bg-gradient-to-b from-gray-50/80 to-white">
                <div className="grid grid-cols-1 xl:grid-cols-12 gap-8">
                  <div className="xl:col-span-8 space-y-4 min-w-0">
                    <h4 className="text-sm font-semibold text-gray-700 flex items-center gap-2">
                      <UserCircleIcon className="h-5 w-5 text-orange-500" aria-hidden />
                      Coordonnées
                    </h4>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="rounded-xl border border-gray-100 bg-white p-4 shadow-sm min-w-0">
                        <p className="text-xs font-semibold uppercase tracking-wide text-gray-400">Matricule</p>
                        <p className="mt-1 text-sm text-gray-900 font-mono break-all">
                          {selectedUser.login?.trim() ? selectedUser.login : "—"}
                        </p>
                      </div>
                      <div className="rounded-xl border border-gray-100 bg-white p-4 shadow-sm min-w-0">
                        <p className="text-xs font-semibold uppercase tracking-wide text-gray-400">Téléphone</p>
                        <p className="mt-1 text-sm text-gray-900 font-mono">{selectedUser.telephone || "—"}</p>
                      </div>
                      <div className="rounded-xl border border-gray-100 bg-white p-4 shadow-sm md:col-span-2 min-w-0">
                        <p className="text-xs font-semibold uppercase tracking-wide text-gray-400">Email</p>
                        <p className="mt-1 text-sm text-gray-900 break-words">{selectedUser.email}</p>
                      </div>
                    </div>
                    <div className="rounded-xl border border-gray-200 bg-white p-4 shadow-sm">
                      <p className="text-xs font-semibold uppercase tracking-wide text-gray-400">Affectation principale</p>
                      <div className="mt-2 flex flex-wrap items-center gap-2">
                        <span className="inline-flex items-center rounded-full bg-orange-100 px-2.5 py-0.5 text-xs font-semibold text-orange-900">
                          {selectedUser.role.code}
                        </span>
                        <span className="text-xs text-gray-500 uppercase">{selectedUser.structure.type}</span>
                      </div>
                      <p className="mt-2 text-base font-semibold text-gray-900">{selectedUser.structure.libelle}</p>
                      <p className="text-xs text-gray-500 font-mono mt-0.5">{selectedUser.structure.code}</p>
                    </div>
                  </div>
                  <div className="xl:col-span-4 space-y-3 min-w-[280px]">
                    <h4 className="text-sm font-semibold text-gray-700 flex items-center gap-2">
                      <BuildingOffice2Icon className="h-5 w-5 text-emerald-600" aria-hidden />
                      Rattachement territorial
                    </h4>
                    <div className="rounded-xl border border-emerald-200 bg-gradient-to-b from-emerald-50/80 to-white p-4 shadow-sm min-w-0">
                      <ol className="space-y-3 text-sm">
                        {selectedUser.drenaLibelle && (
                          <li className="relative pl-3 border-l-2 border-emerald-300">
                            <p className="text-[10px] font-bold uppercase tracking-wider text-emerald-700">DRENA</p>
                            <p className="font-medium text-gray-900">{selectedUser.drenaLibelle}</p>
                            {selectedUser.drenaCode && (
                              <p className="text-xs text-gray-500 font-mono mt-0.5">{selectedUser.drenaCode}</p>
                            )}
                          </li>
                        )}
                        {selectedUser.ieppLibelle && (
                          <li className="relative pl-3 border-l-2 border-emerald-300">
                            <p className="text-[10px] font-bold uppercase tracking-wider text-emerald-700">IEPP</p>
                            <p className="font-medium text-gray-900">{selectedUser.ieppLibelle}</p>
                            {selectedUser.ieppCode && (
                              <p className="text-xs text-gray-500 font-mono mt-0.5">{selectedUser.ieppCode}</p>
                            )}
                          </li>
                        )}
                        {selectedUser.eppLibelle && (
                          <li className="relative pl-3 border-l-2 border-emerald-300">
                            <p className="text-[10px] font-bold uppercase tracking-wider text-emerald-700">EPP</p>
                            <p className="font-medium text-gray-900">{selectedUser.eppLibelle}</p>
                            {selectedUser.eppCode && (
                              <p className="text-xs text-gray-500 font-mono mt-0.5">{selectedUser.eppCode}</p>
                            )}
                          </li>
                        )}
                        {!selectedUser.drenaLibelle &&
                          !selectedUser.ieppLibelle &&
                          !selectedUser.eppLibelle && (
                            <li className="text-sm text-gray-500 italic">Aucune hiérarchie DRENA / IEPP / EPP renseignée.</li>
                          )}
                      </ol>
                    </div>
                    <div className="grid grid-cols-1 gap-3">
                      <div className="rounded-xl border border-gray-100 bg-white p-3 shadow-sm">
                        <p className="text-xs font-semibold uppercase tracking-wide text-gray-400">Dernière connexion</p>
                        <p className="mt-1 text-sm text-gray-900">{formatDate(selectedUser.lastConnectionDate)}</p>
                      </div>
                      {selectedUser.createdAt && (
                        <div className="rounded-xl border border-gray-100 bg-white p-3 shadow-sm">
                          <p className="text-xs font-semibold uppercase tracking-wide text-gray-400">Compte créé le</p>
                          <p className="mt-1 text-sm text-gray-900">{formatDate(selectedUser.createdAt)}</p>
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                <div
                  className={`rounded-2xl border p-4 sm:p-5 ${
                    selectedUser.isLocked
                      ? "border-red-200 bg-gradient-to-br from-red-50 to-white"
                      : "border-gray-200 bg-gradient-to-br from-slate-50 to-white"
                  }`}
                >
                  <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <div
                        className={`flex h-11 w-11 items-center justify-center rounded-xl ${
                          selectedUser.isLocked ? "bg-red-100 text-red-700" : "bg-emerald-100 text-emerald-700"
                        }`}
                      >
                        {selectedUser.isLocked ? (
                          <LockClosedIcon className="h-6 w-6" />
                        ) : (
                          <ShieldCheckIcon className="h-6 w-6" />
                        )}
                      </div>
                      <div>
                        <p className="text-sm font-semibold text-gray-900">Sécurité du compte</p>
                        <p className="text-xs text-gray-600 mt-0.5">
                          {selectedUser.isLocked
                            ? "Ce compte est verrouillé (tentatives échouées ou action administrateur)."
                            : "Compte non verrouillé — l’utilisateur peut se connecter normalement."}
                        </p>
                        {typeof selectedUser.loginAttempts === "number" && (
                          <p className="text-xs text-gray-500 mt-1">
                            Tentatives de connexion enregistrées :{" "}
                            <span className="font-medium text-gray-800">{selectedUser.loginAttempts}</span>
                          </p>
                        )}
                      </div>
                    </div>
                    <div className="flex flex-wrap gap-2 justify-end">
                      <span
                        className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold ${
                          selectedUser.isActive ? "bg-green-100 text-green-800" : "bg-gray-200 text-gray-700"
                        }`}
                      >
                        {selectedUser.isActive ? "Compte actif" : "Compte inactif"}
                      </span>
                      {selectedUser.isLocked && (
                        <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold bg-red-100 text-red-800">
                          Verrouillé
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                <div className="flex flex-col-reverse sm:flex-row sm:justify-end sm:items-center gap-2 pt-1 border-t border-gray-100">
                  <button
                    type="button"
                    onClick={() => setShowDetails(false)}
                    className="btn-outline w-full sm:w-auto"
                    disabled={isResettingPassword}
                  >
                    Fermer
                  </button>
                  {canPerformUserManagementAction(selectedUser) && (
                    <div className="flex flex-col sm:flex-row gap-2 w-full sm:w-auto">
                      {selectedUser.isLocked && (
                        <button
                          type="button"
                          onClick={() => {
                            void handleUnlockUser(selectedUser, { closeDetails: true })
                          }}
                          disabled={loading || blockConcurrentUserMutations || unlockingId === selectedUser.id}
                          className="inline-flex items-center justify-center gap-2 px-4 py-2 rounded-xl border border-amber-200 bg-amber-50 text-amber-900 font-medium text-sm hover:bg-amber-100 transition-colors disabled:opacity-50"
                        >
                          {unlockingId === selectedUser.id ? (
                            <ArrowPathIcon className="h-4 w-4 animate-spin" />
                          ) : (
                            <KeyIcon className="h-4 w-4" />
                          )}
                          Déverrouiller
                        </button>
                      )}
                      <button
                        type="button"
                        onClick={() => {
                          openResetPasswordFromDetails()
                        }}
                        disabled={blockConcurrentUserMutations || togglingActiveId === selectedUser.id}
                        className="inline-flex items-center justify-center gap-2 px-4 py-2 rounded-xl border border-gray-200 bg-white text-gray-800 font-medium text-sm hover:bg-gray-50 shadow-sm disabled:opacity-50 disabled:cursor-not-allowed"
                      >
                        <KeyIcon className="h-4 w-4 text-gray-500" />
                        Nouveau mot de passe
                      </button>
                      <button
                        type="button"
                        onClick={() => handleToggleUserActive(selectedUser)}
                        disabled={loading || blockConcurrentUserMutations || togglingActiveId === selectedUser.id}
                        className={`inline-flex items-center justify-center gap-2 px-4 py-2 rounded-xl border font-medium text-sm disabled:opacity-50 ${
                          selectedUser.isActive
                            ? "border-red-200 bg-red-50 text-red-800 hover:bg-red-100"
                            : "border-green-200 bg-green-50 text-green-800 hover:bg-green-100"
                        }`}
                      >
                        {togglingActiveId === selectedUser.id ? (
                          <ArrowPathIcon className="h-4 w-4 animate-spin text-gray-600" />
                        ) : selectedUser.isActive ? (
                          <NoSymbolIcon className="h-4 w-4 text-red-600" />
                        ) : (
                          <CheckCircleIcon className="h-4 w-4 text-green-600" />
                        )}
                        {selectedUser.isActive ? "Désactiver" : "Activer"}
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setShowDetails(false)
                          setShowEditModal(true)
                        }}
                        disabled={loading || blockConcurrentUserMutations || togglingActiveId === selectedUser.id}
                        className="btn-primary inline-flex items-center justify-center gap-2 shadow-md shadow-orange-500/20 disabled:opacity-60"
                      >
                        <PencilIcon className="h-4 w-4" />
                        Modifier
                      </button>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Modal réinitialisation mot de passe (admin) */}
        {showResetPasswordModal && selectedUser && canPerformUserManagementAction(selectedUser) && (
          <div
            className="modal-overlay z-[60]"
            onClick={() => {
              if (isResettingPassword) return
              setShowResetPasswordModal(false)
              setShowResetPasswordPlain(false)
            }}
          >
            <div
              className="modal-content max-w-md p-0 overflow-hidden border-0 shadow-2xl ring-1 ring-gray-200"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="bg-gradient-to-r from-slate-800 to-slate-900 px-6 py-5 text-white">
                <h3 className="text-lg font-semibold flex items-center gap-2">
                  <KeyIcon className="h-6 w-6 text-amber-300" />
                  Définir un mot de passe
                </h3>
                <p className="text-sm text-slate-300 mt-1">
                  Pour {selectedUser.firstName} {selectedUser.lastName} — minimum 6 caractères. Communiquez le mot de passe par un canal sécurisé.
                </p>
              </div>
              <div className="p-6 space-y-4 bg-white">
                <div>
                  <label htmlFor="reset-pwd" className="block text-sm font-medium text-gray-700 mb-1.5">
                    Nouveau mot de passe
                  </label>
                  <div className="relative">
                    <input
                      id="reset-pwd"
                      type={showResetPasswordPlain ? "text" : "password"}
                      autoComplete="new-password"
                      className="w-full px-4 py-2.5 pr-11 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-orange-500/40 focus:border-orange-300"
                      value={resetPasswordValue}
                      onChange={(e) => setResetPasswordValue(e.target.value)}
                      disabled={isResettingPassword}
                      placeholder="Au moins 6 caractères"
                    />
                    <button
                      type="button"
                      className="absolute right-2 top-1/2 -translate-y-1/2 rounded-lg p-1.5 text-gray-500 hover:bg-gray-100 hover:text-gray-700 focus:outline-none focus:ring-2 focus:ring-orange-500/40"
                      onClick={() => setShowResetPasswordPlain((v) => !v)}
                      disabled={isResettingPassword}
                      aria-label={showResetPasswordPlain ? "Masquer le mot de passe" : "Afficher le mot de passe"}
                      title={showResetPasswordPlain ? "Masquer" : "Afficher"}
                    >
                      {showResetPasswordPlain ? (
                        <EyeSlashIcon className="h-5 w-5" aria-hidden />
                      ) : (
                        <EyeIcon className="h-5 w-5" aria-hidden />
                      )}
                    </button>
                  </div>
                </div>
                <div className="flex flex-col-reverse sm:flex-row sm:justify-end gap-2 pt-2">
                  <button
                    type="button"
                    className="btn-outline w-full sm:w-auto"
                    disabled={isResettingPassword}
                    onClick={() => {
                      setShowResetPasswordModal(false)
                      setResetPasswordValue("")
                      setShowResetPasswordPlain(false)
                    }}
                  >
                    Annuler
                  </button>
                  <button
                    type="button"
                    className="btn-primary w-full sm:w-auto inline-flex items-center justify-center gap-2"
                    disabled={isResettingPassword || resetPasswordValue.trim().length < 6}
                    onClick={handleResetPasswordSubmit}
                  >
                    {isResettingPassword ? (
                      <>
                        <ArrowPathIcon className="h-4 w-4 animate-spin" />
                        Enregistrement…
                      </>
                    ) : (
                      "Enregistrer"
                    )}
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Modal modification utilisateur */}
        {showEditModal && selectedUser && (
          <div
            className="modal-overlay"
            onClick={() => {
              if (!isUpdatingUser) {
                setShowEditModal(false)
                setSelectedUser(null)
              }
            }}
          >
            <div
              className="modal-content !max-w-none !w-[80vw] mx-3 sm:mx-5 max-h-[92vh] overflow-y-auto p-0"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="bg-gradient-to-r from-orange-500 to-amber-600 px-5 sm:px-7 py-4 text-white flex items-start justify-between gap-3">
                <div>
                  <h3 className="text-xl sm:text-2xl font-bold tracking-tight">Modifier l&apos;utilisateur</h3>
                  <p className="text-sm sm:text-base text-orange-100 mt-1">
                    Coordonnées, profil et rattachement DRENA / IEPP / EPP
                  </p>
                </div>
                <button 
                  onClick={() => {
                    setShowEditModal(false);
                    setSelectedUser(null);
                  }} 
                  className="shrink-0 rounded-lg p-1.5 text-white/90 hover:bg-white/15"
                  disabled={isUpdatingUser}
                  type="button"
                  aria-label="Fermer"
                >
                  <span className="text-2xl leading-none">×</span>
                </button>
              </div>
              <div className="p-5 sm:p-8">
              <CreateUserForm
                key={`edit-user-${selectedUser.id}`}
                editUser={selectedUser}
                creatorRoleCode={user?.role.code}
                editHierarchyLocks={editHierarchyLocks}
                onSubmit={handleUpdateUser}
                onCancel={() => {
                  setShowEditModal(false);
                  setSelectedUser(null);
                }}
                loading={isUpdatingUser}
              />
              </div>
            </div>
          </div>
        )}

        {/* Modal confirmation suppression */}
        {showDeleteModal && selectedUser && (
          <DeleteConfirmationModal
            user={selectedUser}
            onConfirm={handleDeleteUser}
            onCancel={() => {
              setShowDeleteModal(false);
              setSelectedUser(null);
            }}
            loading={isDeletingUser}
          />
        )}

        {/* Modal nouvel utilisateur */}
        {showModal && (
          <div
            className="modal-overlay"
            onClick={() => {
              if (!isCreatingUser) closeCreateModal()
            }}
          >
            <div
              className="modal-content !max-w-none !w-[80vw] mx-3 sm:mx-5 max-h-[92vh] overflow-y-auto p-0"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="bg-gradient-to-r from-orange-500 to-amber-600 px-5 sm:px-7 py-4 text-white flex items-start justify-between gap-3">
                <div>
                  <h3 className="text-xl sm:text-2xl font-bold tracking-tight">Nouvel utilisateur</h3>
                  <p className="text-sm sm:text-base text-orange-100 mt-1">
                    Création d&apos;un compte et rattachement à la structure compétente
                  </p>
                </div>
                <button 
                  onClick={closeCreateModal} 
                  className="shrink-0 rounded-lg p-1.5 text-white/90 hover:bg-white/15"
                  disabled={isCreatingUser}
                  type="button"
                  aria-label="Fermer"
                >
                  <span className="text-2xl leading-none">×</span>
                </button>
              </div>
              <div className="p-5 sm:p-8">
              <CreateUserForm
                key={creationPreset ? JSON.stringify(creationPreset) : "create-default"}
                onSubmit={handleCreateUser}
                onCancel={closeCreateModal}
                loading={isCreatingUser}
                creatorRoleCode={user?.role.code}
                creationPreset={creationPreset}
              />
              </div>
            </div>
          </div>
        )}
      </div>
    </MainLayout>
  )
}
