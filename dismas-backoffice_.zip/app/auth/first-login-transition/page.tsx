"use client"

import { useEffect } from "react"
import { useRouter } from "next/navigation"
import Logo from "@/components/ui/logo"

export default function FirstLoginTransitionPage() {
  const router = useRouter()

  useEffect(() => {
    const shouldTransition = typeof window !== "undefined" && localStorage.getItem("first_login_transition_pending") === "true"
    if (!shouldTransition) {
      router.replace("/auth/login")
      return
    }

    const timeout = setTimeout(() => {
      localStorage.removeItem("first_login_transition_pending")
      router.replace("/auth/change-password")
    }, 1400)

    return () => clearTimeout(timeout)
  }, [router])

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-green-50 flex items-center justify-center px-4">
      <div className="max-w-md w-full text-center">
        <div className="flex justify-center mb-5">
          <Logo size="xl" showText={false} />
        </div>
        <div className="card">
          <div className="flex flex-col items-center py-4">
            <div className="h-12 w-12 rounded-full border-4 border-orange-200 border-t-orange-600 animate-spin" />
            <h2 className="mt-4 text-lg font-semibold text-gray-900">Préparation de votre espace</h2>
            <p className="mt-2 text-sm text-gray-600">
              Première connexion détectée, redirection vers le changement de mot de passe...
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}

