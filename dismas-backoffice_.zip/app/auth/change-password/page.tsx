"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import toast from "react-hot-toast"

import { authService } from "@/lib/services/auth.service"
import Logo from "@/components/ui/logo"

export default function ChangePasswordPage() {
  const router = useRouter()

  const [login, setLogin] = useState("")
  const [currentPassword, setCurrentPassword] = useState("")
  const [newPassword, setNewPassword] = useState("")
  const [confirmPassword, setConfirmPassword] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)
  /** Affiché après succès pendant la navigation vers la page de connexion */
  const [isRedirecting, setIsRedirecting] = useState(false)

  // Login depuis localStorage ; mot de passe actuel depuis sessionStorage (saisi à l’écran de connexion)
  useEffect(() => {
    if (typeof window !== "undefined") {
      const pendingLogin = localStorage.getItem("pending_first_login_login")
      if (pendingLogin) {
        setLogin(pendingLogin)
      }
      const pendingPassword = sessionStorage.getItem("pending_first_login_password")
      if (pendingPassword) {
        setCurrentPassword(pendingPassword)
      }
    }
  }, [])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (isSubmitting || isRedirecting) return

    if (!login || !currentPassword || !newPassword || !confirmPassword) {
      toast.error("Veuillez renseigner tous les champs obligatoires")
      return
    }

    if (newPassword.length < 6) {
      toast.error("Le nouveau mot de passe doit contenir au moins 6 caractères")
      return
    }

    if (newPassword !== confirmPassword) {
      toast.error("Les mots de passe ne correspondent pas")
      return
    }

    try {
      setIsSubmitting(true)

      const response = await authService.changePasswordFirstLogin({
        login,
        currentPassword,
        newPassword,
      })

      if (!response.hasError) {
        setIsRedirecting(true)
        if (typeof window !== "undefined") {
          sessionStorage.removeItem("pending_first_login_password")
          localStorage.removeItem("pending_first_login_login")
        }
        toast.success("Mot de passe modifié avec succès. Veuillez vous reconnecter.")
        router.push("/auth/login")
      } else {
        toast.error(response.status?.message || "Erreur lors de la modification du mot de passe")
      }
    } catch (error) {
      console.error("Erreur lors du changement de mot de passe:", error)
      const backendMessage =
        (error as any)?.message ||
        (error as any)?.details?.status?.message ||
        "Erreur lors de la modification du mot de passe"
      toast.error(backendMessage)
    } finally {
      setIsSubmitting(false)
    }
  }

  const showTransitionLoader = isSubmitting || isRedirecting

  return (
    <div className="relative min-h-screen bg-gradient-to-br from-orange-50 to-green-50 flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
      {showTransitionLoader && (
        <div
          className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-white/85 backdrop-blur-sm"
          aria-live="polite"
          aria-busy="true"
        >
          <div className="h-12 w-12 rounded-full border-4 border-orange-200 border-t-orange-600 animate-spin" />
          <p className="mt-6 text-sm font-medium text-gray-800">
            {isRedirecting ? "Redirection vers la page de connexion…" : "Enregistrement en cours…"}
          </p>
          <p className="mt-2 text-xs text-gray-500 max-w-xs text-center">
            Veuillez patienter quelques instants.
          </p>
        </div>
      )}
      <div className="max-w-md w-full space-y-8">
        <div className="text-center">
          <div className="flex justify-center mb-4">
            <Logo size="xl" showText={false} />
          </div>
          <h2 className="text-2xl font-bold text-gray-900">Changement de mot de passe</h2>
          <p className="mt-2 text-sm text-gray-600">
            Première connexion détectée. Veuillez définir un nouveau mot de passe.
          </p>
        </div>

        <div className="card">
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label className="form-label">Matricule</label>
              <input
                type="text"
                className="input-field"
                value={login}
                onChange={(e) => setLogin(e.target.value)}
              />
            </div>
            <div>
              <label htmlFor="currentPassword" className="form-label">
                Mot de passe actuel
              </label>
              <input
                id="currentPassword"
                type="password"
                autoComplete="current-password"
                className="input-field"
                value={currentPassword}
                onChange={(e) => setCurrentPassword(e.target.value)}
              />
            </div>
            <div>
              <label htmlFor="newPassword" className="form-label">
                Nouveau mot de passe
              </label>
              <input
                id="newPassword"
                name="newPassword"
                type="password"
                required
                className="input-field"
                placeholder="Entrez votre nouveau mot de passe"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
              />
            </div>

            <div>
              <label htmlFor="confirmPassword" className="form-label">
                Confirmer le nouveau mot de passe
              </label>
              <input
                id="confirmPassword"
                name="confirmPassword"
                type="password"
                required
                className="input-field"
                placeholder="Confirmez votre nouveau mot de passe"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
              />
            </div>

            <div className="flex items-center justify-between">
              <button
                type="button"
                className="btn-outline"
                onClick={() => router.push("/")}
                disabled={isSubmitting || isRedirecting}
              >
                Annuler
              </button>
              <button
                type="submit"
                className="btn-primary"
                disabled={isSubmitting || isRedirecting}
              >
                {isSubmitting ? "Enregistrement..." : "Enregistrer"}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  )
}

