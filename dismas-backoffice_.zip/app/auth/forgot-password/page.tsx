"use client"

import { FormEvent, useState } from "react"
import { useRouter } from "next/navigation"
import toast from "react-hot-toast"
import Logo from "@/components/ui/logo"
import { authService } from "@/lib/services/auth.service"

export default function ForgotPasswordPage() {
  const router = useRouter()
  const [step, setStep] = useState<1 | 2>(1)
  const [loading, setLoading] = useState(false)
  const [email, setEmail] = useState("")
  const [otpCode, setOtpCode] = useState("")
  const [newPassword, setNewPassword] = useState("")
  const [confirmPassword, setConfirmPassword] = useState("")

  const handleSendOtp = async (e: FormEvent) => {
    e.preventDefault()
    if (loading) return
    if (!email.trim()) {
      toast.error("Veuillez renseigner votre email")
      return
    }

    setLoading(true)
    try {
      const response = await authService.sendPasswordChangeOtp(email.trim())
      if (response.hasError) {
        toast.error(response.status?.message || "Impossible d'envoyer le code OTP")
        return
      }
      toast.success("Code OTP envoyé sur votre email")
      setStep(2)
    } catch (error: any) {
      toast.error(error?.message || "Erreur lors de l'envoi du code OTP")
    } finally {
      setLoading(false)
    }
  }

  const handleResetPassword = async (e: FormEvent) => {
    e.preventDefault()
    if (loading) return

    if (!otpCode.trim() || !newPassword || !confirmPassword) {
      toast.error("Veuillez renseigner tous les champs")
      return
    }
    if (newPassword.length < 6) {
      toast.error("Le nouveau mot de passe doit contenir au moins 6 caractères")
      return
    }
    if (newPassword !== confirmPassword) {
      toast.error("La confirmation du mot de passe ne correspond pas")
      return
    }

    setLoading(true)
    try {
      const response = await authService.changePasswordWithOtp({
        email: email.trim(),
        newPassword,
        otpCode: otpCode.trim(),
      })
      if (response.hasError) {
        toast.error(response.status?.message || "Erreur lors du changement de mot de passe")
        return
      }
      toast.success("Mot de passe modifié avec succès")
      router.push("/auth/login")
    } catch (error: any) {
      toast.error(error?.message || "Erreur lors du changement de mot de passe")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-green-50 flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full space-y-8">
        <div className="text-center">
          <div className="flex justify-center mb-4">
            <Logo size="xl" showText={false} />
          </div>
          <h2 className="text-2xl font-bold text-gray-900">Mot de passe oublié</h2>
          <p className="mt-2 text-sm text-gray-600">
            {step === 1 ? "Recevez un code OTP pour réinitialiser votre mot de passe." : "Saisissez le code OTP et votre nouveau mot de passe."}
          </p>
        </div>

        <div className="card">
          {step === 1 ? (
            <form onSubmit={handleSendOtp} className="space-y-4">
              <div className="form-group">
                <label className="form-label">Email</label>
                <input
                  type="email"
                  className="input-field"
                  placeholder="exemple@domaine.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                />
              </div>
              <div className="flex justify-between">
                <button type="button" className="btn-outline" onClick={() => router.push("/auth/login")} disabled={loading}>
                  Retour
                </button>
                <button type="submit" className="btn-primary" disabled={loading}>
                  {loading ? "Envoi..." : "Envoyer le code OTP"}
                </button>
              </div>
            </form>
          ) : (
            <form onSubmit={handleResetPassword} className="space-y-4">
              <div className="form-group">
                <label className="form-label">Email</label>
                <input type="email" className="input-field bg-gray-50" value={email} readOnly />
              </div>
              <div className="form-group">
                <label className="form-label">Code OTP</label>
                <input
                  className="input-field"
                  placeholder="Entrez le code reçu"
                  value={otpCode}
                  onChange={(e) => setOtpCode(e.target.value)}
                  required
                />
              </div>
              <div className="form-group">
                <label className="form-label">Nouveau mot de passe</label>
                <input
                  type="password"
                  className="input-field"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  required
                />
              </div>
              <div className="form-group">
                <label className="form-label">Confirmer le mot de passe</label>
                <input
                  type="password"
                  className="input-field"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  required
                />
              </div>
              <div className="flex justify-between">
                <button type="button" className="btn-outline" onClick={() => setStep(1)} disabled={loading}>
                  Précédent
                </button>
                <button type="submit" className="btn-primary" disabled={loading}>
                  {loading ? "Validation..." : "Réinitialiser"}
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  )
}

