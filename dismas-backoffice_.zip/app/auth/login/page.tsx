"use client"

import type React from "react"
import LoginForm from "../../../components/auth/LoginForm"
import Logo from "../../../components/ui/logo"

export default function LoginPage() {

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-green-50 flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full space-y-8">
        {/* Header */}
        <div className="text-center">
          <div className="flex justify-center mb-4">
            <Logo size="xl" showText={false} />
          </div>
          <h2 className="text-3xl font-bold text-gray-900">DISMAS</h2>
          <p className="mt-2 text-sm text-gray-600">Distribution des Manuels Scolaires</p>
          <p className="text-xs text-gray-500">Ministère de l'Éducation Nationale - Côte d'Ivoire</p>
        </div>

        {/* Formulaire de connexion */}
        <div className="card">
          <LoginForm />

          {/* Comptes de test */}
          {/* <div className="mt-6 pt-6 border-t border-gray-200">
            <h3 className="text-sm font-medium text-gray-700 mb-3">Comptes de test :</h3>
            <div className="space-y-2 text-xs text-gray-600">
              <div className="flex justify-between">
                <span>Admin :</span>
                <span className="font-mono">admin / admin123</span>
              </div>
              <div className="flex justify-between">
                <span>DAF :</span>
                <span className="font-mono">daf.kouame / daf123</span>
              </div>
              <div className="flex justify-between">
                <span>IEPP :</span>
                <span className="font-mono">iepp.assi / iepp123</span>
              </div>
              <div className="flex justify-between">
                <span>Directeur :</span>
                <span className="font-mono">dir.kouadio / dir123</span>
              </div>
            </div>
          </div> */}
        </div>

        {/* Footer */}
        <div className="text-center text-xs text-gray-500">
          <p>© 2024 DISMAS - Tous droits réservés</p>
          <p className="mt-1">Développé pour le MENAET</p>
        </div>
      </div>
    </div>
  )
}
