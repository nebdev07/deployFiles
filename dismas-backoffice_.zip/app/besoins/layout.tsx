import { Suspense } from "react"

export default function BesoinsLayout({ children }: { children: React.ReactNode }) {
  return (
    <Suspense
      fallback={
        <div className="flex min-h-[30vh] items-center justify-center text-gray-500 text-sm">
          Chargement du module besoins…
        </div>
      }
    >
      {children}
    </Suspense>
  )
}
