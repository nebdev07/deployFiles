"use client"

import { useCallback, useDeferredValue, useEffect, useMemo, useState } from "react"
import Link from "next/link"
import MainLayout from "@/components/layout/main-layout"
import { BesoinsSubNav } from "@/components/besoins/BesoinsSubNav"
import { useAuth } from "@/app/providers"
import { canAccessSyntheseCatalogueBesoinsPage } from "@/lib/utils/functionality-permissions"
import { isIeppTerritoryMenuRole } from "@/lib/utils/role-codes"
import { besoinsService, BesoinResponse } from "@/lib/services/besoins.service"
import { anneeScolaireService } from "@/lib/services/annee-scolaire.service"
import toast from "react-hot-toast"
import {
  ArrowLeftIcon,
  ArrowPathIcon,
  BookOpenIcon,
  ChartBarSquareIcon,
} from "@heroicons/react/24/outline"
import {
  BesoinsKpiSkeletonGrid,
  BesoinsSectionLoader,
  BesoinsTableSkeleton,
} from "@/components/besoins/BesoinsLoadingState"

type LigneAgregee = {
  matiereKey: string
  matiereLibelle: string
  matiereCode: string
  quantiteConsolidee: number
  quantiteApprouvee: number
  nombreBesoinsIepp: number
}

type BlocNiveau = {
  niveauKey: string
  niveauLibelle: string
  lignes: LigneAgregee[]
  totalConsolide: number
  totalApprouve: number
}

const ORDRE_NIVEAUX = [
  "CP1",
  "CP2",
  "CE1",
  "CE2",
  "CM1",
  "CM2",
  "6E",
  "5E",
  "4E",
  "3E",
  "2ND",
  "1ERE",
  "TLE",
]

function normaliserNiveau(code?: string, libelle?: string): string {
  const raw = (code || libelle || "—").trim()
  return raw.replace(/\s+/g, "").toUpperCase() || "—"
}

function cleTriNiveau(niveauLibelle: string): number {
  const n = normaliserNiveau(niveauLibelle, niveauLibelle)
  const i = ORDRE_NIVEAUX.indexOf(n)
  if (i >= 0) return i
  return 1000
}

function quantiteConsolideeDetail(d: {
  quantiteConsolidee?: number
  quantiteNet?: number
  quantiteBrute?: number
}): number {
  return d.quantiteConsolidee ?? d.quantiteNet ?? d.quantiteBrute ?? 0
}

function filtrerBesoinsSynthese(liste: BesoinResponse[], user: {
  role: { code: string }
  structure?: { id?: number }
  drena?: { id?: number }
}): BesoinResponse[] {
  const role = user.role.code
  const ieppId = user.structure?.id

  const estBesoinIeppConsolideOuApprouve = (b: BesoinResponse) =>
    b.structureType === "IEPP" && (b.statut === "CONSOLIDE" || b.statut === "APPROUVE")

  if (role === "ADMIN" || role === "DAF") {
    return liste.filter(estBesoinIeppConsolideOuApprouve)
  }
  // DRENA : les données sont déjà filtrées côté API (drenaId) ; on ne garde que les besoins IEPP consolidés/approuvés
  if (role === "DRENA") {
    return liste.filter(estBesoinIeppConsolideOuApprouve)
  }
  if (isIeppTerritoryMenuRole(role) && ieppId != null) {
    return liste.filter(
      (b) =>
        estBesoinIeppConsolideOuApprouve(b) &&
        (b.structureId === ieppId || b.structureAdministrativeId === ieppId)
    )
  }
  return []
}

function agregerParNiveauEtMatiere(besoins: BesoinResponse[]): BlocNiveau[] {
  type Acc = {
    matiereLibelle: string
    matiereCode: string
    quantiteConsolidee: number
    quantiteApprouvee: number
    ieppIds: Set<number>
  }

  const parNiveau = new Map<string, Map<string, Acc>>()

  for (const besoin of besoins) {
    const niveauLib =
      besoin.niveauScolaireLibelle ||
      besoin.niveauScolaireCode ||
      "Niveau non renseigné"
    const niveauKey = normaliserNiveau(besoin.niveauScolaireCode, besoin.niveauScolaireLibelle)

    if (!parNiveau.has(niveauKey)) {
      parNiveau.set(niveauKey, new Map())
    }
    const parMatiere = parNiveau.get(niveauKey)!

    for (const d of besoin.besoinDetails || []) {
      const mk = String(d.matiereId ?? d.matiereCode ?? d.matiereLibelle ?? "0")
      const qc = quantiteConsolideeDetail(d)
      const qa = d.quantiteApprouvee ?? 0

      if (!parMatiere.has(mk)) {
        parMatiere.set(mk, {
          matiereLibelle: d.matiereLibelle || d.matiereCode || "Matière",
          matiereCode: d.matiereCode || "",
          quantiteConsolidee: 0,
          quantiteApprouvee: 0,
          ieppIds: new Set(),
        })
      }
      const cell = parMatiere.get(mk)!
      cell.quantiteConsolidee += qc
      cell.quantiteApprouvee += qa
      cell.ieppIds.add(besoin.id)
      if (d.matiereLibelle) cell.matiereLibelle = d.matiereLibelle
      if (d.matiereCode) cell.matiereCode = d.matiereCode
    }
  }

  const blocs: BlocNiveau[] = []

  for (const [niveauKey, matMap] of parNiveau) {
    const first = besoins.find(
      (b) =>
        normaliserNiveau(b.niveauScolaireCode, b.niveauScolaireLibelle) === niveauKey
    )
    const niveauLibelle =
      first?.niveauScolaireLibelle || first?.niveauScolaireCode || niveauKey

    const lignes: LigneAgregee[] = []
    for (const [matiereKey, acc] of matMap) {
      lignes.push({
        matiereKey,
        matiereLibelle: acc.matiereLibelle,
        matiereCode: acc.matiereCode,
        quantiteConsolidee: acc.quantiteConsolidee,
        quantiteApprouvee: acc.quantiteApprouvee,
        nombreBesoinsIepp: acc.ieppIds.size,
      })
    }
    lignes.sort((a, b) =>
      a.matiereLibelle.localeCompare(b.matiereLibelle, "fr", { sensitivity: "base" })
    )

    const totalConsolide = lignes.reduce((s, l) => s + l.quantiteConsolidee, 0)
    const totalApprouve = lignes.reduce((s, l) => s + l.quantiteApprouvee, 0)

    blocs.push({
      niveauKey,
      niveauLibelle,
      lignes,
      totalConsolide,
      totalApprouve,
    })
  }

  blocs.sort((a, b) => {
    const da = cleTriNiveau(a.niveauLibelle)
    const db = cleTriNiveau(b.niveauLibelle)
    if (da !== db) return da - db
    return a.niveauLibelle.localeCompare(b.niveauLibelle, "fr", { sensitivity: "base" })
  })
  return blocs
}

export default function SyntheseCatalogueBesoinsPage() {
  const { user } = useAuth()
  const userAny = user as any
  const [loading, setLoading] = useState(true)
  const [loadingAnnees, setLoadingAnnees] = useState(true)
  const [besoins, setBesoins] = useState<BesoinResponse[]>([])
  const [annees, setAnnees] = useState<{ id: number; libelle?: string; code?: string }[]>([])
  const [filtreAnneeId, setFiltreAnneeId] = useState<number | null>(null)

  const autorise = !!(
    user && canAccessSyntheseCatalogueBesoinsPage(user.role.code, user.functionalityPermissions)
  )

  const chargerAnnees = useCallback(async () => {
    setLoadingAnnees(true)
    try {
      const res = await anneeScolaireService.getAnneesScolairesActives()
      if (!res.hasError && res.items?.length) {
        setAnnees(res.items as unknown as { id: number; libelle?: string; code?: string }[])
      }
    } catch {
      /* silencieux */
    } finally {
      setLoadingAnnees(false)
    }
  }, [])

  const chargerBesoins = useCallback(async () => {
    if (!user || !autorise) return
    if (user.role.code === "DRENA") {
      const drenaId = userAny?.drena?.id
      if (drenaId == null || drenaId <= 0) {
        toast.error("Votre compte DRENA n'est pas rattaché à une structure : impossible de filtrer la synthèse.")
        setBesoins([])
        setLoading(false)
        return
      }
    }
    setLoading(true)
    try {
      const criteria: Record<string, number> = {}
      if (user.role.code === "DRENA" && userAny?.drena?.id != null && userAny.drena.id > 0) {
        criteria.drenaId = userAny.drena.id
      }
      const result = await besoinsService.getByCriteria(criteria, 0, 2000)
      if (result.success && result.data) {
        setBesoins(result.data as unknown as BesoinResponse[])
      } else {
        setBesoins([])
        if (!result.success) toast.error(result.message || "Impossible de charger les besoins")
      }
    } catch (e) {
      setBesoins([])
      toast.error("Erreur réseau lors du chargement des besoins")
    } finally {
      setLoading(false)
    }
  }, [user, autorise])

  useEffect(() => {
    chargerAnnees()
  }, [chargerAnnees])

  useEffect(() => {
    if (autorise) chargerBesoins()
  }, [autorise, chargerBesoins])

  const besoinsFiltres = useMemo(() => {
    let liste = user ? filtrerBesoinsSynthese(besoins, user as any) : []
    if (filtreAnneeId != null) {
      liste = liste.filter((b) => b.anneeScolaireId === filtreAnneeId)
    }
    return liste
  }, [besoins, user, filtreAnneeId])

  const besoinsFiltresDiffere = useDeferredValue(besoinsFiltres)
  const aggregationEnCours =
    !loading && besoinsFiltres !== besoinsFiltresDiffere

  const blocs = useMemo(
    () => agregerParNiveauEtMatiere(besoinsFiltresDiffere),
    [besoinsFiltresDiffere]
  )

  const totaux = useMemo(() => {
    let cons = 0
    let appr = 0
    let matieres = 0
    for (const b of blocs) {
      cons += b.totalConsolide
      appr += b.totalApprouve
      matieres += b.lignes.length
    }
    return {
      totalConsolide: cons,
      totalApprouve: appr,
      nbLignesCatalogue: matieres,
      nbNiveaux: blocs.length,
      nbBesoinsIepp: besoinsFiltresDiffere.length,
    }
  }, [blocs, besoinsFiltresDiffere.length])

  if (!user) {
    return (
      <MainLayout>
        <div className="flex min-h-[40vh] items-center justify-center text-slate-500">
          Chargement de la session…
        </div>
      </MainLayout>
    )
  }

  if (!autorise) {
    return (
      <MainLayout>
        <div className="mx-auto max-w-lg rounded-xl border border-slate-200 bg-white p-8 text-center shadow-sm">
          <h1 className="text-lg font-semibold text-slate-900">Accès restreint</h1>
          <p className="mt-2 text-sm text-slate-600">
            La synthèse catalogue nécessite la permission Besoins (lecture) ou un profil territoire /
            national autorisé par défaut.
          </p>
          <Link
            href="/besoins"
            className="mt-6 inline-flex items-center text-sm font-medium text-orange-600 hover:text-orange-700"
          >
            <ArrowLeftIcon className="mr-1.5 h-4 w-4" />
            Revenir à l&apos;expression des besoins
          </Link>
        </div>
      </MainLayout>
    )
  }

  const perimetre = isIeppTerritoryMenuRole(user.role.code)
      ? "Périmètre : votre IEPP (besoins consolidés ou approuvés)"
      : user.role.code === "DRENA"
        ? `Périmètre : votre DRENA (${userAny?.drena?.libelle || userAny?.drena?.code || "territoire"}) — IEPP consolidés ou approuvés`
        : "Périmètre national : tous les besoins IEPP consolidés ou approuvés"

  return (
    <MainLayout>
      <div className="space-y-6">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Expression des Besoins</h1>
            <p className="text-gray-600">
              Synthèse catalogue — agrégat par niveau et matière
              {user.structure?.libelle ? ` · ${user.structure.libelle}` : ""}
            </p>
            <p className="mt-1 text-xs text-slate-500">{perimetre}</p>
          </div>
          <button
            type="button"
            onClick={() => chargerBesoins()}
            disabled={loading}
            className="inline-flex items-center self-start rounded-lg bg-slate-900 px-3 py-2 text-sm font-medium text-white shadow-sm transition hover:bg-slate-800 disabled:opacity-50"
          >
            <ArrowPathIcon className={`mr-2 h-4 w-4 ${loading ? "animate-spin" : ""}`} />
            Actualiser
          </button>
        </div>

        <BesoinsSubNav roleCode={user.role.code} functionalityPermissions={user.functionalityPermissions} />

        <div className="mx-auto max-w-7xl space-y-8">
          <p className="text-sm leading-relaxed text-slate-600">
            Quantités consolidées et approuvées par couple niveau scolaire × matière, selon le
            périmètre de votre rôle (flux IEPP → DAF).
          </p>

          <div className="flex flex-wrap items-end gap-4 border-b border-slate-200 pb-6">
            <div>
              <label htmlFor="annee" className="flex items-center gap-2 text-xs font-medium text-slate-500">
                Année scolaire
                {loadingAnnees && (
                  <span className="inline-flex h-4 w-4 animate-spin rounded-full border-2 border-orange-200 border-t-orange-600" />
                )}
              </label>
              <select
                id="annee"
                value={filtreAnneeId ?? ""}
                disabled={loadingAnnees}
                onChange={(e) => {
                  const v = e.target.value
                  setFiltreAnneeId(v ? Number(v) : null)
                }}
                className="mt-1 min-w-[200px] rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 shadow-sm focus:border-orange-500 focus:outline-none focus:ring-1 focus:ring-orange-500 disabled:cursor-not-allowed disabled:opacity-60"
              >
                <option value="">Toutes les années</option>
                {annees.map((a) => (
                  <option key={a.id} value={a.id}>
                    {a.libelle || a.code || `Année ${a.id}`}
                  </option>
                ))}
              </select>
            </div>
          </div>

        {loading ? (
          <div className="space-y-6">
            <BesoinsSectionLoader
              title="Récupération des besoins consolidés"
              subtitle="Connexion au serveur, chargement des lignes (peut prendre du temps sur de gros volumes), puis agrégation par niveau et matière."
            />
            <BesoinsKpiSkeletonGrid columns={4} />
            <BesoinsTableSkeleton rows={8} />
          </div>
        ) : (
          <>
        {aggregationEnCours && (
          <div className="flex items-center gap-2 rounded-lg border border-amber-200 bg-amber-50 px-3 py-2 text-xs text-amber-900">
            <span className="inline-flex h-3.5 w-3.5 animate-spin rounded-full border-2 border-amber-300 border-t-amber-700" />
            Mise à jour des totaux et du tableau après changement de filtre…
          </div>
        )}

        {/* KPI */}
        <div
          className={`grid gap-4 sm:grid-cols-2 lg:grid-cols-4 transition-opacity duration-200 ${
            aggregationEnCours ? "opacity-70" : ""
          }`}
        >
          <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
            <div className="flex items-center gap-2 text-xs font-medium uppercase tracking-wide text-slate-500">
              <BookOpenIcon className="h-4 w-4 text-slate-400" />
              Total consolidé
            </div>
            <p className="mt-2 text-2xl font-semibold tabular-nums text-slate-900">
              {totaux.totalConsolide.toLocaleString("fr-FR")}
            </p>
            <p className="mt-1 text-xs text-slate-500">Manuels (somme catalogue)</p>
          </div>
          <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
            <div className="flex items-center gap-2 text-xs font-medium uppercase tracking-wide text-slate-500">
              <ChartBarSquareIcon className="h-4 w-4 text-slate-400" />
              Total approuvé
            </div>
            <p className="mt-2 text-2xl font-semibold tabular-nums text-emerald-700">
              {totaux.totalApprouve.toLocaleString("fr-FR")}
            </p>
            <p className="mt-1 text-xs text-slate-500">Si DAF a déjà posé une quantité approuvée</p>
          </div>
          <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
            <p className="text-xs font-medium uppercase tracking-wide text-slate-500">
              Couples niveau × matière
            </p>
            <p className="mt-2 text-2xl font-semibold tabular-nums text-slate-900">
              {totaux.nbLignesCatalogue}
            </p>
            <p className="mt-1 text-xs text-slate-500">
              Sur {totaux.nbNiveaux} niveau{totaux.nbNiveaux > 1 ? "x" : ""}
            </p>
          </div>
          <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
            <p className="text-xs font-medium uppercase tracking-wide text-slate-500">
              Fiches IEPP retenues
            </p>
            <p className="mt-2 text-2xl font-semibold tabular-nums text-slate-900">
              {totaux.nbBesoinsIepp}
            </p>
            <p className="mt-1 text-xs text-slate-500">Besoins consolidés / approuvés dans le filtre</p>
          </div>
        </div>

        {/* Corps */}
        {blocs.length === 0 ? (
          <div className="rounded-xl border border-dashed border-slate-300 bg-slate-50/80 px-6 py-16 text-center">
            <p className="text-sm font-medium text-slate-800">Aucune donnée à afficher</p>
            <p className="mt-2 text-sm text-slate-600">
              Aucun besoin IEPP consolidé ou approuvé ne correspond aux critères. Vérifiez
              l&apos;année scolaire ou attendez les consolidations.
            </p>
          </div>
        ) : (
          <div className="space-y-6">
            {blocs.map((bloc) => (
              <section
                key={bloc.niveauKey}
                className="overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm"
              >
                <div className="flex flex-col gap-1 border-b border-slate-100 bg-slate-50/90 px-5 py-4 sm:flex-row sm:items-center sm:justify-between">
                  <div>
                    <h2 className="text-base font-semibold text-slate-900">
                      {bloc.niveauLibelle}
                    </h2>
                    <p className="text-xs text-slate-500">
                      {bloc.lignes.length} matière{bloc.lignes.length > 1 ? "s" : ""} dans le
                      catalogue
                    </p>
                  </div>
                  <div className="flex gap-6 text-sm">
                    <div>
                      <span className="text-slate-500">Sous-total consolidé</span>
                      <p className="font-semibold tabular-nums text-slate-900">
                        {bloc.totalConsolide.toLocaleString("fr-FR")}
                      </p>
                    </div>
                    <div>
                      <span className="text-slate-500">Sous-total approuvé</span>
                      <p className="font-semibold tabular-nums text-emerald-700">
                        {bloc.totalApprouve.toLocaleString("fr-FR")}
                      </p>
                    </div>
                  </div>
                </div>
                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-slate-200">
                    <thead>
                      <tr className="bg-white">
                        <th
                          scope="col"
                          className="px-5 py-3 text-left text-xs font-semibold uppercase tracking-wider text-slate-500"
                        >
                          Matière
                        </th>
                        <th
                          scope="col"
                          className="px-5 py-3 text-left text-xs font-semibold uppercase tracking-wider text-slate-500"
                        >
                          Code
                        </th>
                        <th
                          scope="col"
                          className="px-5 py-3 text-right text-xs font-semibold uppercase tracking-wider text-slate-500"
                        >
                          Quantité consolidée
                        </th>
                        <th
                          scope="col"
                          className="px-5 py-3 text-right text-xs font-semibold uppercase tracking-wider text-slate-500"
                        >
                          Quantité approuvée
                        </th>
                        <th
                          scope="col"
                          className="px-5 py-3 text-right text-xs font-semibold uppercase tracking-wider text-slate-500"
                        >
                          % du niveau
                        </th>
                        <th
                          scope="col"
                          className="px-5 py-3 text-right text-xs font-semibold uppercase tracking-wider text-slate-500"
                        >
                          Fiches IEPP
                        </th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {bloc.lignes.map((ligne) => {
                        const pctNiveau =
                          bloc.totalConsolide > 0
                            ? Math.round((ligne.quantiteConsolidee / bloc.totalConsolide) * 1000) / 10
                            : 0
                        return (
                          <tr
                            key={`${bloc.niveauKey}-${ligne.matiereKey}`}
                            className="transition-colors hover:bg-slate-50/80"
                          >
                            <td className="whitespace-nowrap px-5 py-3.5 text-sm font-medium text-slate-900">
                              {ligne.matiereLibelle}
                            </td>
                            <td className="whitespace-nowrap px-5 py-3.5 text-sm text-slate-600">
                              {ligne.matiereCode || "—"}
                            </td>
                            <td className="whitespace-nowrap px-5 py-3.5 text-right text-sm tabular-nums font-medium text-slate-900">
                              {ligne.quantiteConsolidee.toLocaleString("fr-FR")}
                            </td>
                            <td className="whitespace-nowrap px-5 py-3.5 text-right text-sm tabular-nums text-emerald-800">
                              {ligne.quantiteApprouvee > 0
                                ? ligne.quantiteApprouvee.toLocaleString("fr-FR")
                                : "—"}
                            </td>
                            <td className="whitespace-nowrap px-5 py-3.5 text-right text-sm tabular-nums text-slate-600">
                              {bloc.totalConsolide > 0 ? `${pctNiveau} %` : "—"}
                            </td>
                            <td className="whitespace-nowrap px-5 py-3.5 text-right text-sm tabular-nums text-slate-500">
                              {ligne.nombreBesoinsIepp}
                            </td>
                          </tr>
                        )
                      })}
                    </tbody>
                  </table>
                </div>
              </section>
            ))}
          </div>
        )}
          </>
        )}
        </div>
      </div>
    </MainLayout>
  )
}
