"use client"

import { useState, useEffect, useMemo, useCallback, useRef, Fragment, type ChangeEvent } from "react"
import { useSearchParams, useRouter } from "next/navigation"
import MainLayout from "../../components/layout/main-layout"
import { BesoinsSubNav } from "../../components/besoins/BesoinsSubNav"
import { CycleBesoinBar } from "../../components/besoins/CycleBesoinBar"
import { BesoinsDataOverlay } from "../../components/besoins/BesoinsLoadingState"
import { useCycleBesoinContext } from "../../hooks/use-cycle-besoin-context"
import { resolveBesoinsActiveTab } from "../../lib/besoins-nav"
import { useAuth } from "../providers"
// ✅ IMPORT DES DONNÉES COHÉRENTES
import { baseDataCocody, structures, catalogueManuels, calculateBesoinNet } from "../../lib/data-consistency"
import DataCoherenceDashboard from "../../components/data-coherence-dashboard"
// ✅ NOUVEAU : Import du service et du formulaire
import { besoinsService, BesoinData } from "../../lib/services/besoins.service"
import { buildBesoinGetByCriteriaPayload } from "../../lib/besoins-load-criteria"
import { isConsultationOnlyRole } from "@/lib/utils/role-access"
import { isIeppTerritoryMenuRole } from "@/lib/utils/role-codes"
import {
  canAccessBesoinSaisieCreate,
  canAccessBesoinsDafValidationWorkspace,
  canAccessBesoinsIeppConsolidationWorkspace,
  canAccessExpressionManuelleDafBesoinsPanel,
  canSeeBesoinsConsolidationDrenaSection,
  canShowConsolidateValideBesoinButton,
  canShowConsolidationIeppConsoliderAction,
  canShowValidateSaisieBesoinButton,
  canUpdateBesoinSaisieRow,
  canUseBesoinsSuiviParIeppGrouping,
  canUseBesoinsValidationGroupedByIeppList,
  canUseIeppTerritoryConsolidationDataset,
  shouldReloadConsolidationsAfterBesoinRenvoi,
} from "@/lib/utils/functionality-permissions"
import { anneeScolaireService } from "../../lib/services/annee-scolaire.service"
import BesoinForm from "../../components/forms/BesoinForm"
import ApprouverBesoinModal, {
  type ApprobationExcelPrefill,
} from "../../components/modals/ApprouverBesoinModal"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { downloadApprobationTemplateFromBackend } from "@/lib/approbation-besoin-excel"
import ExpressionManuelleDafPanel from "../../components/besoins/ExpressionManuelleDafPanel"
import { BesoinsListPaginationBar, sliceBesoinsPage } from "../../components/besoins/BesoinsListPaginationBar"
import toast from "react-hot-toast"
import {
  PlusIcon,
  ClipboardDocumentListIcon,
  CheckCircleIcon,
  ClockIcon,
  ExclamationTriangleIcon,
  EyeIcon,
  PencilIcon,
  DocumentTextIcon,
  CalculatorIcon,
  UserGroupIcon,
  XMarkIcon,
  TrashIcon,
  ChevronDownIcon,
  ChevronRightIcon,
  ArrowUturnLeftIcon,
  ArrowDownTrayIcon,
  DocumentArrowUpIcon,
} from "@heroicons/react/24/outline"

/** Regroupe les lignes validation DAF (IEPP) de la page courante par DRENA — même logique visuelle que le modal d’approbation. */
function groupValidationGroupesParDrena(
  groupes: Array<{
    structureId: number
    structureLibelle: string
    structureCode: string
    annee: string
    totalManuels: number
    statut: string
    besoins: any[]
  }>
) {
  const m = new Map<string, { key: string; label: string; groupes: typeof groupes }>()
  for (const g of groupes) {
    const b0 = g.besoins?.[0]
    const drenaRaw =
      (typeof b0?._rawData?.drena === "string" && b0._rawData.drena.trim()) ||
      (typeof b0?.drena === "string" && b0.drena.trim()) ||
      ""
    const codePrefix = (g.structureCode || "").split("-")[0]?.trim() || ""
    const key = drenaRaw || codePrefix || "__autres__"
    const label = drenaRaw || (codePrefix ? `DRENA ${codePrefix}` : "Autres")
    if (!m.has(key)) m.set(key, { key, label, groupes: [] })
    m.get(key)!.groupes.push(g)
  }
  return [...m.values()].sort((a, b) =>
    a.label.localeCompare(b.label, "fr", { sensitivity: "base" })
  )
}

// Types pour les données
interface Manuel {
  titre: string
  quantite: number
}

interface Niveau {
  niveau: string
  effectif_garcons: number
  effectif_filles: number
  effectif_total: number
  manuels: Manuel[]
  // Retours récupérés automatiquement depuis le système
  retours_auto?: {
    bon_etat: number
    moyen_etat: number
    total_retournes: number
  }
  // Coefficient des manuels réparables (0-1), par défaut 0.7
  coef_reparable?: number
}

interface FormData {
  niveaux: Niveau[]
}

/** Compare ids structure (API peut renvoyer number | string) */
function sameStructureId(a: unknown, b: unknown): boolean {
  if (a == null || b == null) return false
  return Number(a) === Number(b)
}

/** Type IEPP depuis le DTO besoin brut (codes A010-B005-… n'incluent pas toujours la chaîne "IEPP") */
function besoinRawIsIepp(raw: any): boolean {
  if (!raw) return false
  const t = String(raw.structureType || "").toUpperCase()
  if (t === "IEPP") return true
  const code = String(raw.structureAdministrativeCode || "")
  const lib = String(raw.structureAdministrativeLibelle || "")
  return code.includes("IEPP") || lib.includes("IEPP")
}

function besoinRawIsEpp(raw: any): boolean {
  if (!raw) return false
  return String(raw.structureType || "").toUpperCase() === "EPP"
}

/**
 * Lit une quantité numérique sur un détail de besoin (camelCase ou snake_case).
 */
function readDetailQty(d: any, ...keys: string[]): number | null {
  for (const k of keys) {
    const v = d[k]
    if (v !== undefined && v !== null && v !== "") {
      const n = Number(v)
      if (!Number.isNaN(n)) return n
    }
  }
  return null
}

/**
 * Quantité à afficher pour une ligne matière (modal, listes).
 * En JS, `quantiteConsolidee ?? quantiteNet` retourne 0 si consolidé vaut 0, même lorsque le net est > 0.
 */
function quantiteDetailPourAffichageExemplaires(detail: any, statutBesoin?: string): number {
  const st = String(statutBesoin || "").toUpperCase()
  const cons = readDetailQty(detail, "quantiteConsolidee", "quantite_consolidee")
  const app = readDetailQty(detail, "quantiteApprouvee", "quantite_approuvee")
  const net = readDetailQty(detail, "quantiteNet", "quantite_net")
  const brut = readDetailQty(detail, "quantiteBrute", "quantite_brute")
  if (st === "APPROUVE" || st === "VALIDE_NATIONAL" || st === "VALIDE_DAF") {
    if (app != null) return app
    if (cons != null && cons > 0) return cons
    if (net != null && net > 0) return net
    if (brut != null && brut > 0) return brut
    return app ?? cons ?? net ?? brut ?? 0
  }
  if (st === "CONSOLIDE" || st === "CONSOLIDE_DAF") {
    if (cons != null && cons > 0) return cons
    if (net != null && net > 0) return net
    if (brut != null && brut > 0) return brut
    if (cons != null) return cons
    return net ?? brut ?? 0
  }
  if (net != null && net > 0) return net
  if (brut != null && brut > 0) return brut
  return net ?? brut ?? cons ?? app ?? 0
}

/**
 * Effectif élèves pour un niveau : moyenne des quantités manuel sur les lignes matière de ce niveau
 * (ex. expression manuelle DAF : (100+100+100+100) / 4 = 100).
 */
function effectifElevesParNiveauDepuisDetailsLignes(nivDetails: any[], statutBesoin?: string): number | null {
  if (!Array.isArray(nivDetails) || nivDetails.length === 0) return null
  let sum = 0
  for (const d of nivDetails) {
    sum += quantiteDetailPourAffichageExemplaires(d, statutBesoin)
  }
  return Math.round(sum / nivDetails.length)
}

/**
 * Total manuels pour les listes / totaux : aligné sur le formulaire (colonne « besoin net » en saisie).
 * En SAISI / VALIDE : somme des {@code quantiteNet} (repli sur brut si net absent).
 * Après consolidation / approbation : priorités métier habituelles.
 */
function sumManuelsBesoinPourListe(besoin: {
  statut?: string
  besoinDetails?: any[]
  _rawData?: { besoinDetails?: any[] }
  total_manuels?: number
  total_manuels_nets?: number
}): number {
  const details = besoin._rawData?.besoinDetails || besoin.besoinDetails || []
  if (!details.length) {
    return Number(besoin.total_manuels_nets ?? besoin.total_manuels ?? 0)
  }
  const st = String(besoin.statut || "").toUpperCase()
  if (st === "CONSOLIDE" || st === "CONSOLIDE_DAF") {
    return details.reduce((s: number, d: any) => s + quantiteDetailPourAffichageExemplaires(d, st), 0)
  }
  if (st === "APPROUVE" || st === "VALIDE_NATIONAL" || st === "VALIDE_DAF") {
    return details.reduce((s: number, d: any) => s + quantiteDetailPourAffichageExemplaires(d, st), 0)
  }
  return details.reduce((s: number, d: any) => {
    const net = d.quantiteNet ?? d.quantite_net
    if (net != null && !Number.isNaN(Number(net))) {
      return s + Number(net)
    }
    return s + Number(d.quantiteBrute ?? d.quantite_brute ?? 0)
  }, 0)
}

// Liste des manuels disponibles par niveau
const manuelsDisponibles = {
  CP1: [
    "Livre de Français CP1",
    "Mathématiques CP1",
    "Cahier d'Exercices Français CP1",
    "Cahier d'Exercices Mathématiques CP1",
    "Initiation aux Sciences CP1",
    "Éducation Civique et Morale CP1"
  ],
  CP2: [
    "Français CP2",
    "Mathématiques CP2",
    "Cahier d'Exercices Français CP2",
    "Cahier d'Exercices Mathématiques CP2",
    "Sciences CP2",
    "Éducation Civique et Morale CP2"
  ],
  CE1: [
    "Français CE1",
    "Mathématiques CE1",
    "Cahier d'Exercices Français CE1",
    "Cahier d'Exercices Mathématiques CE1",
    "Sciences CE1",
    "Histoire-Géographie CE1",
    "Éducation Civique et Morale CE1"
  ],
  CE2: [
    "Français CE2",
    "Mathématiques CE2",
    "Cahier d'Exercices Français CE2",
    "Cahier d'Exercices Mathématiques CE2",
    "Sciences CE2",
    "Histoire-Géographie CE2",
    "Éducation Civique et Morale CE2"
  ],
  CM1: [
    "Français CM1",
    "Mathématiques CM1",
    "Histoire-Géographie CM1",
    "Sciences CM1",
    "Cahier d'Exercices Français CM1",
    "Cahier d'Exercices Mathématiques CM1",
    "Éducation Civique et Morale CM1"
  ],
  CM2: [
    "Français CM2",
    "Mathématiques CM2",
    "Histoire-Géographie CM2",
    "Sciences CM2",
    "Cahier d'Exercices Français CM2",
    "Cahier d'Exercices Mathématiques CM2",
    "Éducation Civique et Morale CM2"
  ]
}

// Données mockées des retours (importées depuis le système de retours)
const mockRetours = [
  {
    id: 1,
    reference: "RET-COC-2024-001",
    structure: {
      code: "EPP-COC-01",
      libelle: "EPP Cocody Centre",
      type: "EPP",
    },
    niveau: "CP1",
    classe: "CP1",
    date_retour: "2024-06-25",
    collecte_par: "KOUADIO Adjoua",
    statut: "TERMINE",
    manuels: [
      {
        titre: "Livre de Français CP1",
        quantite_bon_etat: 35,
        quantite_moyen_etat: 8,
        quantite_mauvais_etat: 2,
        quantite_perdue: 0,
      },
      {
        titre: "Mathématiques CP1",
        quantite_bon_etat: 33,
        quantite_moyen_etat: 10,
        quantite_mauvais_etat: 2,
        quantite_perdue: 0,
      },
      {
        titre: "Cahier d'Exercices Français CP1",
        quantite_bon_etat: 38,
        quantite_moyen_etat: 5,
        quantite_mauvais_etat: 2,
        quantite_perdue: 0,
      },
      {
        titre: "Cahier d'Exercices Mathématiques CP1",
        quantite_bon_etat: 36,
        quantite_moyen_etat: 7,
        quantite_mauvais_etat: 2,
        quantite_perdue: 0,
      },
    ],
  },
  {
    id: 2,
    reference: "RET-YOP-2024-001",
    structure: {
      code: "EPP-YOP-01",
      libelle: "EPP Yopougon Maroc",
      type: "EPP",
    },
    niveau: "CP2",
    classe: "CP2",
    date_retour: "2024-06-26",
    collecte_par: "TRAORE Seydou",
    statut: "TERMINE",
    manuels: [
      {
        titre: "Français CP2",
        quantite_bon_etat: 28,
        quantite_moyen_etat: 12,
        quantite_mauvais_etat: 5,
        quantite_perdue: 2,
      },
      {
        titre: "Mathématiques CP2",
        quantite_bon_etat: 30,
        quantite_moyen_etat: 10,
        quantite_mauvais_etat: 5,
        quantite_perdue: 2,
      },
    ],
  },
  {
    id: 3,
    reference: "RET-BK-2024-001",
    structure: {
      code: "EPP-BK-01",
      libelle: "EPP Bouaké Centre",
      type: "EPP",
    },
    niveau: "CE1",
    classe: "CE1",
    date_retour: "2024-07-01",
    collecte_par: "BAMBA Moussa",
    statut: "PLANIFIE",
    manuels: [],
  },
  {
    id: 4,
    reference: "RET-COC-2024-002",
    structure: {
      code: "EPP-COC-01",
      libelle: "EPP Cocody Centre",
      type: "EPP",
    },
    niveau: "CP2",
    classe: "CP2",
    date_retour: "2024-06-28",
    collecte_par: "KOUADIO Adjoua",
    statut: "TERMINE",
    manuels: [
      {
        titre: "Français CP2",
        quantite_bon_etat: 25,
        quantite_moyen_etat: 10,
        quantite_mauvais_etat: 3,
        quantite_perdue: 1,
      },
      {
        titre: "Mathématiques CP2",
        quantite_bon_etat: 28,
        quantite_moyen_etat: 8,
        quantite_mauvais_etat: 2,
        quantite_perdue: 0,
      },
    ],
  },
]

// Données mockées des besoins par structure (basées sur les données cohérentes)
const mockBesoins = [
  {
    id: 1,
    structure: {
      code: "EPP-COC-01",
      libelle: "EPP Cocody Centre", 
      type: "EPP",
    },
    annee_scolaire: "2024-2025",
    statut: "SAISI",
    date_saisie: "2024-10-15",
    saisi_par: "KOUADIO Adjoua",
    niveaux: [
      {
        niveau: "CP1",
        effectif_garcons: 22,
        effectif_filles: 18,
        effectif_total: 40,
        manuels: [
          { code: "FR-CP1-001", titre: "Livre de Français CP1", quantite: 40, besoin_net: calculateBesoinNet(40, baseDataCocody.retours["EPP-COC-01"]?.["FR-CP1-001"]) },
          { code: "MA-CP1-001", titre: "Mathématiques CP1", quantite: 40, besoin_net: calculateBesoinNet(40, baseDataCocody.retours["EPP-COC-01"]?.["MA-CP1-001"]) },
          { code: "FR-CP1-002", titre: "Cahier d'Exercices Français CP1", quantite: 40, besoin_net: calculateBesoinNet(40, baseDataCocody.retours["EPP-COC-01"]?.["FR-CP1-002"]) },
          { code: "MA-CP1-002", titre: "Cahier d'Exercices Mathématiques CP1", quantite: 40, besoin_net: calculateBesoinNet(40, baseDataCocody.retours["EPP-COC-01"]?.["MA-CP1-002"]) },
        ],
      },
      {
        niveau: "CP2", 
        effectif_garcons: 20,
        effectif_filles: 19,
        effectif_total: 39,
        manuels: [
          { code: "FR-CP2-001", titre: "Français CP2", quantite: 39, besoin_net: 39 },
          { code: "MA-CP2-001", titre: "Mathématiques CP2", quantite: 39, besoin_net: 39 },
          { code: "FR-CP2-002", titre: "Cahier d'Exercices Français CP2", quantite: 39, besoin_net: 39 },
          { code: "MA-CP2-002", titre: "Cahier d'Exercices Mathématiques CP2", quantite: 39, besoin_net: 39 },
        ],
      },
    ],
    total_manuels: 316,
    total_manuels_nets: 294, // ✅ Après déduction des retours
  },
  // ✅ AJOUT: EPP Cocody Riviera - VALIDE (pour consolidation IEPP)
  {
    id: 6,
    structure: {
      code: "EPP-COC-02",
      libelle: "EPP Cocody Riviera",
      type: "EPP",
    },
    annee_scolaire: "2024-2025",
    statut: "VALIDE",
    date_saisie: "2024-10-12",
    date_validation: "2024-10-14",
    saisi_par: "DIABATE Aminata",
    niveaux: [
      {
        niveau: "CE1",
        effectif_garcons: 28,
        effectif_filles: 25,
        effectif_total: 53,
        manuels: [
          { titre: "Français CE1", quantite: 53 },
          { titre: "Mathématiques CE1", quantite: 53 },
          { titre: "Découverte du Monde CE1", quantite: 53 },
        ],
      },
      {
        niveau: "CE2",
        effectif_garcons: 24,
        effectif_filles: 27,
        effectif_total: 51,
        manuels: [
          { titre: "Français CE2", quantite: 51 },
          { titre: "Mathématiques CE2", quantite: 51 },
          { titre: "Histoire-Géographie CE2", quantite: 51 },
        ],
      },
    ],
    total_manuels: 312,
  },
  // ✅ AJOUT: EPP Cocody Angré - CONSOLIDE (consolidé par IEPP)
  {
    id: 7,
    structure: {
      code: "EPP-COC-03",
      libelle: "EPP Cocody Angré",
      type: "EPP",
    },
    annee_scolaire: "2024-2025",
    statut: "CONSOLIDE",
    date_saisie: "2024-10-10",
    date_validation: "2024-10-12",
    date_consolidation: "2024-10-18",
    saisi_par: "KONE Ibrahim",
    niveaux: [
      {
        niveau: "CM1",
        effectif_garcons: 30,
        effectif_filles: 32,
        effectif_total: 62,
        manuels: [
          { titre: "Français CM1", quantite: 62 },
          { titre: "Mathématiques CM1", quantite: 62 },
          { titre: "Histoire-Géographie CM1", quantite: 62 },
          { titre: "Sciences CM1", quantite: 62 },
        ],
      },
      {
        niveau: "CM2",
        effectif_garcons: 26,
        effectif_filles: 28,
        effectif_total: 54,
        manuels: [
          { titre: "Français CM2", quantite: 54 },
          { titre: "Mathématiques CM2", quantite: 54 },
          { titre: "Histoire-Géographie CM2", quantite: 54 },
          { titre: "Sciences CM2", quantite: 54 },
        ],
      },
    ],
    total_manuels: 464,
  },
  // ✅ AJOUT: EPP Cocody Danga - APPROUVE (approuvé par DRENA)
  {
    id: 8,
    structure: {
      code: "EPP-COC-04",
      libelle: "EPP Cocody Danga",
      type: "EPP",
    },
    annee_scolaire: "2024-2025",
    statut: "APPROUVE",
    date_saisie: "2024-10-08",
    date_validation: "2024-10-10",
    date_consolidation: "2024-10-16",
    date_approbation: "2024-10-20",
    saisi_par: "OUATTARA Fatoumata",
    niveaux: [
      {
        niveau: "CP1",
        effectif_garcons: 35,
        effectif_filles: 33,
        effectif_total: 68,
        manuels: [
          { titre: "Livre de Français CP1", quantite: 68 },
          { titre: "Mathématiques CP1", quantite: 68 },
          { titre: "Cahier d'Exercices Français CP1", quantite: 68 },
        ],
      },
    ],
    total_manuels: 204,
  },
  {
    id: 2,
    structure: {
      code: "EPP-YOP-01",
      libelle: "EPP Yopougon Maroc",
      type: "EPP",
    },
    annee_scolaire: "2024-2025",
    statut: "VALIDE",
    date_saisie: "2024-10-14",
    saisi_par: "TRAORE Seydou",
    niveaux: [
      {
        niveau: "CP1",
        effectif_garcons: 25,
        effectif_filles: 23,
        effectif_total: 48,
        manuels: [
          { titre: "Livre de Français CP1", quantite: 48 },
          { titre: "Mathématiques CP1", quantite: 48 },
          { titre: "Cahier d'Exercices Français CP1", quantite: 48 },
          { titre: "Cahier d'Exercices Mathématiques CP1", quantite: 48 },
        ],
      },
      {
        niveau: "CE1",
        effectif_garcons: 24,
        effectif_filles: 26,
        effectif_total: 50,
        manuels: [
          { titre: "Français CE1", quantite: 50 },
          { titre: "Mathématiques CE1", quantite: 50 },
          { titre: "Cahier d'Exercices Français CE1", quantite: 50 },
          { titre: "Cahier d'Exercices Mathématiques CE1", quantite: 50 },
        ],
      },
    ],
    total_manuels: 392,
  },
  {
    id: 3,
    structure: {
      code: "EPP-BOU-01",
      libelle: "EPP Bouaké Centre",
      type: "EPP",
    },
    annee_scolaire: "2024-2025",
    statut: "VALIDE_DAF",
    date_saisie: "2024-10-16",
    saisi_par: "KONE Fatou",
    niveaux: [
      {
        niveau: "CP1",
        effectif_garcons: 30,
        effectif_filles: 28,
        effectif_total: 58,
        manuels: [
          { titre: "Livre de Français CP1", quantite: 58 },
          { titre: "Mathématiques CP1", quantite: 58 },
        ],
      },
      {
        niveau: "CE2",
        effectif_garcons: 32,
        effectif_filles: 30,
        effectif_total: 62,
        manuels: [
          { titre: "Français CE2", quantite: 62 },
          { titre: "Mathématiques CE2", quantite: 62 },
        ],
      },
    ],
    total_manuels: 240,
  },
  {
    id: 4,
    structure: {
      code: "EPP-SAN-01",
      libelle: "EPP San-Pédro Centre",
      type: "EPP",
    },
    annee_scolaire: "2024-2025",
    statut: "REGULATION_EFFECTUEE",
    date_saisie: "2024-10-12",
    saisi_par: "DIABATE Issouf",
    niveaux: [
      {
        niveau: "CP1",
        effectif_garcons: 15,
        effectif_filles: 12,
        effectif_total: 27,
        manuels: [
          { titre: "Livre de Français CP1", quantite: 27 },
          { titre: "Mathématiques CP1", quantite: 27 },
        ],
      },
    ],
    total_manuels: 54,
  },
  {
    id: 5,
    structure: {
      code: "EPP-ABO-01",
      libelle: "EPP Abobo Gare",
      type: "EPP",
    },
    annee_scolaire: "2024-2025",
    statut: "APPROUVE",
    date_saisie: "2024-10-18",
    saisi_par: "KOUASSI Marie",
    niveaux: [
      {
        niveau: "CM1",
        effectif_garcons: 28,
        effectif_filles: 25,
        effectif_total: 53,
        manuels: [
          { titre: "Français CM1", quantite: 53 },
          { titre: "Mathématiques CM1", quantite: 53 },
          { titre: "Histoire-Géographie CM1", quantite: 53 },
          { titre: "Sciences CM1", quantite: 53 },
        ],
      },
      {
        niveau: "CM2",
        effectif_garcons: 26,
        effectif_filles: 24,
        effectif_total: 50,
        manuels: [
          { titre: "Français CM2", quantite: 50 },
          { titre: "Mathématiques CM2", quantite: 50 },
          { titre: "Histoire-Géographie CM2", quantite: 50 },
          { titre: "Sciences CM2", quantite: 50 },
        ],
      },
    ],
    total_manuels: 412,
  },
]

// Données de consolidation IEPP
const mockConsolidationIEPP = [
  {
    id: 1,
    iepp: "IEPP Cocody",
    drena: "DRENA Abidjan",
    statut: "CONSOLIDE",
    date_consolidation: "2024-10-20",
    epp_count: 3,
    total_effectifs: 1200,
    total_manuels: 4800,
    besoins: [
      {
        epp: "EPP Cocody Centre",
        effectifs: 79,
        manuels: 316,
        statut: "VALIDE",
      },
      {
        epp: "EPP Cocody Riviera",
        effectifs: 65,
        manuels: 260,
        statut: "VALIDE",
      },
      {
        epp: "EPP Cocody Angré",
        effectifs: 85,
        manuels: 340,
        statut: "VALIDE",
      },
    ],
  },
  {
    id: 2,
    iepp: "IEPP Yopougon",
    drena: "DRENA Abidjan",
    statut: "APPROUVE",
    date_consolidation: "2024-10-22",
    epp_count: 4,
    total_effectifs: 1800,
    total_manuels: 7200,
    besoins: [
      {
        epp: "EPP Yopougon Maroc",
        effectifs: 98,
        manuels: 392,
        statut: "VALIDE_DAF",
      },
      {
        epp: "EPP Yopougon Niangon",
        effectifs: 52,
        manuels: 208,
        statut: "REGULATION_EFFECTUEE",
      },
      {
        epp: "EPP Yopougon Selmer",
        effectifs: 45,
        manuels: 180,
        statut: "VALIDE",
      },
      {
        epp: "EPP Yopougon Port-Bouët",
        effectifs: 38,
        manuels: 152,
        statut: "VALIDE",
      },
    ],
  },
  {
    id: 3,
    iepp: "IEPP Bouaké 1",
    drena: "DRENA Bouaké",
    statut: "VALIDE_DAF",
    date_consolidation: "2024-10-25",
    epp_count: 2,
    total_effectifs: 850,
    total_manuels: 3400,
    besoins: [
      {
        epp: "EPP Bouaké Centre",
        effectifs: 120,
        manuels: 240,
        statut: "VALIDE_DAF",
      },
      {
        epp: "EPP Bouaké Koko",
        effectifs: 42,
        manuels: 168,
        statut: "REGULATION_EFFECTUEE",
      },
    ],
  },
  {
    id: 4,
    iepp: "IEPP Abobo",
    drena: "DRENA Abidjan",
    statut: "EN_COURS",
    date_consolidation: null,
    epp_count: 3,
    total_effectifs: 950,
    total_manuels: 3800,
    besoins: [
      {
        epp: "EPP Abobo Gare",
        effectifs: 103,
        manuels: 412,
        statut: "APPROUVE",
      },
      {
        epp: "EPP Abobo Samaké",
        effectifs: 78,
        manuels: 312,
        statut: "VALIDE",
      },
      {
        epp: "EPP Abobo Avocatier",
        effectifs: 89,
        manuels: 356,
        statut: "SAISI",
      },
    ],
  },
]

// Données de consolidation DRENA
const mockConsolidationDRENA = [
  {
    id: 1,
    drena: "DRENA Abidjan",
    statut: "APPROUVE",
    date_consolidation: "2024-10-28",
    iepp_count: 5,
    total_effectifs: 8500,
    total_manuels: 34000,
    consolidations_iepp: [
      {
        iepp: "IEPP Cocody",
        effectifs: 1200,
        manuels: 4800,
        statut: "CONSOLIDE",
      },
      {
        iepp: "IEPP Yopougon",
        effectifs: 1800,
        manuels: 7200,
        statut: "APPROUVE",
      },
      {
        iepp: "IEPP Abobo",
        effectifs: 2200,
        manuels: 8800,
        statut: "VALIDE_DAF",
      },
      {
        iepp: "IEPP Adjamé",
        effectifs: 1500,
        manuels: 6000,
        statut: "CONSOLIDE",
      },
      {
        iepp: "IEPP Plateau",
        effectifs: 1800,
        manuels: 7200,
        statut: "REGULATION_EFFECTUEE",
      },
    ],
  },
  {
    id: 2,
    drena: "DRENA Bouaké",
    statut: "VALIDE_DAF",
    date_consolidation: "2024-10-30",
    iepp_count: 3,
    total_effectifs: 4200,
    total_manuels: 16800,
    consolidations_iepp: [
      {
        iepp: "IEPP Bouaké 1",
        effectifs: 850,
        manuels: 3400,
        statut: "VALIDE_DAF",
      },
      {
        iepp: "IEPP Bouaké 2",
        effectifs: 1200,
        manuels: 4800,
        statut: "APPROUVE",
      },
      {
        iepp: "IEPP Bouaké 3",
        effectifs: 2150,
        manuels: 8600,
        statut: "CONSOLIDE",
      },
    ],
  },
  {
    id: 3,
    drena: "DRENA San-Pédro",
    statut: "EN_COURS",
    date_consolidation: null,
    iepp_count: 2,
    total_effectifs: 2800,
    total_manuels: 11200,
    consolidations_iepp: [
      {
        iepp: "IEPP San-Pédro 1",
        effectifs: 1500,
        manuels: 6000,
        statut: "VALIDE",
      },
      {
        iepp: "IEPP San-Pédro 2",
        effectifs: 1300,
        manuels: 5200,
        statut: "SAISI",
      },
    ],
  },
]



export default function BesoinsPage() {
  console.log('🔵 [COMPONENT] BesoinsPage - COMPOSANT CHARGÉ')
  const { user } = useAuth()
  const consultationOnly = useMemo(() => isConsultationOnlyRole(user?.role?.code), [user?.role?.code])
  const searchParams = useSearchParams()
  const router = useRouter()
  const functionalityPermissions = user?.functionalityPermissions

  const activeTab = useMemo(
    () =>
      resolveBesoinsActiveTab(
        user?.role?.code ?? "DIRECTEUR",
        searchParams.get("tab"),
        functionalityPermissions,
      ),
    [user?.role?.code, searchParams, functionalityPermissions],
  )
  const [selectedBesoin, setSelectedBesoin] = useState<any>(null)
  const [showModal, setShowModal] = useState(false)
  const [modalType, setModalType] = useState<"view" | "edit" | "new">("view")
  const [besoins, setBesoins] = useState<any[]>([])
  // ✅ CORRECTION: Initialiser avec des tableaux vides, les données seront chargées depuis la BD
  const [consolidationIEPP, setConsolidationIEPP] = useState<any[]>([])
  const [consolidationDRENA, setConsolidationDRENA] = useState<any[]>([])
  const [loadingBesoins, setLoadingBesoins] = useState(true)
  const [showBesoinForm, setShowBesoinForm] = useState(false)
  const [besoinToEdit, setBesoinToEdit] = useState<BesoinData | null>(null)
  const [formData, setFormData] = useState<FormData>({
    niveaux: [
      {
        niveau: "CP1",
        effectif_garcons: 0,
        effectif_filles: 0,
        effectif_total: 0,
        manuels: [],
        retours_auto: { bon_etat: 0, moyen_etat: 0, total_retournes: 0 },
        coef_reparable: 0.7,
      },
    ],
  })
  // ✅ CORRECTION: Renommer pour éviter le conflit avec l'import toast de react-hot-toast
  const [customToast, setCustomToast] = useState<{ type: "success" | "error"; message: string } | null>(null)
  const [showDetailsModal, setShowDetailsModal] = useState(false)
  const [detailsType, setDetailsType] = useState<"iepp" | "drena" | null>(null)
  const [selectedDetails, setSelectedDetails] = useState<any>(null)
  // ✅ NOUVEAU: Filtre pour l'onglet Suivi
  const [filterStatut, setFilterStatut] = useState<string | null>(null)
  const [showDetailsNationaux, setShowDetailsNationaux] = useState(false)
  // ✅ NOUVEAU : État pour le modal d'approbation DAF
  const [showApprouverModal, setShowApprouverModal] = useState(false)
  const [approvalExcelPrefill, setApprovalExcelPrefill] = useState<ApprobationExcelPrefill | null>(null)
  /** Import depuis l’onglet validation : avertissements serveur (ex. qte ramenée) — confirmation avant d’ouvrir le modal. */
  const [pendingApprovalExcelImport, setPendingApprovalExcelImport] = useState<{
    besoinIds: number[]
    prefill: ApprobationExcelPrefill
    warnings: string[]
  } | null>(null)
  const skipApprovalExcelDialogCloseToastRef = useRef(false)
  const approvalExcelImportRef = useRef<HTMLInputElement>(null)
  const clearApprovalExcelPrefill = useCallback(() => setApprovalExcelPrefill(null), [])
  const cancelPendingApprovalExcelImport = useCallback(() => {
    skipApprovalExcelDialogCloseToastRef.current = true
    setPendingApprovalExcelImport((prev) => {
      if (prev) {
        toast("Import annulé. Corrigez le fichier Excel si besoin, puis réimportez.", {
          icon: "⚠️",
          duration: 5000,
        })
      }
      return null
    })
  }, [])
  const onPendingApprovalExcelDialogOpenChange = useCallback((open: boolean) => {
    if (open) return
    if (skipApprovalExcelDialogCloseToastRef.current) {
      skipApprovalExcelDialogCloseToastRef.current = false
      return
    }
    setPendingApprovalExcelImport((prev) => {
      if (prev) {
        toast("Import annulé. Corrigez le fichier Excel si besoin, puis réimportez.", {
          icon: "⚠️",
          duration: 5000,
        })
      }
      return null
    })
  }, [])
  const [besoinsToApprove, setBesoinsToApprove] = useState<number[]>([])
  // ✅ NOUVEAU : Filtre par année scolaire pour l'onglet Suivi
  const [filterAnneeScolaireId, setFilterAnneeScolaireId] = useState<number | null>(null)
  const [anneesScolaires, setAnneesScolaires] = useState<any[]>([])
  const [loadingAnneesScolaires, setLoadingAnneesScolaires] = useState(false)
  // ✅ NOUVEAU : État pour les besoins EPP associés dans le modal
  const [eppBesoinsAssocies, setEppBesoinsAssocies] = useState<any[]>([])
  const [loadingEppBesoins, setLoadingEppBesoins] = useState(false)
  // État pour le dropdown "Matières et quantités" par EPP (index des lignes développées)
  const [expandedBesoinIndices, setExpandedBesoinIndices] = useState<Set<number>>(new Set())
  const [renvoyerLoading, setRenvoyerLoading] = useState<number | null>(null) // id du besoin en cours de renvoi

  /** Pagination client (listes potentiellement très longues : DAF, suivi national, etc.) */
  const [saisieListPage, setSaisieListPage] = useState(1)
  const [saisieListPageSize, setSaisieListPageSize] = useState(25)
  const [validationListPage, setValidationListPage] = useState(1)
  const [validationListPageSize, setValidationListPageSize] = useState(25)
  const [consolidationDrenaPage, setConsolidationDrenaPage] = useState(1)
  const [consolidationDrenaPageSize, setConsolidationDrenaPageSize] = useState(25)
  const [consolidationIeppPage, setConsolidationIeppPage] = useState(1)
  const [consolidationIeppPageSize, setConsolidationIeppPageSize] = useState(25)
  const [suiviListPage, setSuiviListPage] = useState(1)
  const [suiviListPageSize, setSuiviListPageSize] = useState(25)

  const { ctx: cycleBesoinCtx, loading: cycleBesoinLoading, reload: reloadCycleBesoinCtx } =
    useCycleBesoinContext(filterAnneeScolaireId)

  // ✅ FONCTION UTILITAIRE AVANT LES HOOKS QUI L'UTILISENT
  const getRetoursByNiveau = (niveau: string, userStructure?: any) => {
    const retoursTermines = mockRetours.filter(r => r.statut === "TERMINE")
    
    // Filtrer par structure selon le rôle utilisateur
    let retoursFiltres = retoursTermines
    if (userStructure) {
      if (userStructure.type === "EPP") {
        retoursFiltres = retoursTermines.filter(r => r.structure.code === userStructure.code)
      } else if (userStructure.type === "IEPP") {
        // Pour IEPP, récupérer les retours de toutes les EPP de sa circonscription
        retoursFiltres = retoursTermines.filter(r => r.structure.libelle.includes(userStructure.libelle))
      } else if (userStructure.type === "DRENA") {
        // Pour DRENA, récupérer les retours de sa région
        retoursFiltres = retoursTermines.filter(r => r.structure.libelle.includes(userStructure.libelle))
      }
    }
    
    // Filtrer par niveau
    const retoursNiveau = retoursFiltres.filter(r => r.niveau === niveau)
    
    // Agréger les quantités par état
    let totalBonEtat = 0
    let totalMoyenEtat = 0
    let totalRetournes = 0
    
    retoursNiveau.forEach(retour => {
      retour.manuels.forEach(manuel => {
        totalBonEtat += manuel.quantite_bon_etat || 0
        totalMoyenEtat += manuel.quantite_moyen_etat || 0
        totalRetournes += (manuel.quantite_bon_etat || 0) + (manuel.quantite_moyen_etat || 0) + 
                         (manuel.quantite_mauvais_etat || 0) + (manuel.quantite_perdue || 0)
      })
    })
    
    return {
      bon_etat: totalBonEtat,
      moyen_etat: totalMoyenEtat,
      total_retournes: totalRetournes
    }
  }

  // ✅ NOUVEAU : Charger l'année scolaire courante et les années scolaires disponibles
  useEffect(() => {
    const loadAnneesScolaires = async () => {
      try {
        setLoadingAnneesScolaires(true)
        // Charger l'année scolaire courante
        const anneeCouranteResult = await anneeScolaireService.getAnneeScolaireCourante()
        if (!anneeCouranteResult.hasError && anneeCouranteResult.items && anneeCouranteResult.items.length > 0) {
          const anneeCourante = anneeCouranteResult.items[0] as any
          if (anneeCourante && anneeCourante.id) {
            setFilterAnneeScolaireId(anneeCourante.id)
          }
        }
        
        // Charger toutes les années scolaires actives pour le filtre
        const anneesResult = await anneeScolaireService.getAnneesScolairesActives()
        if (!anneesResult.hasError && anneesResult.items) {
          setAnneesScolaires(anneesResult.items)
        }
      } catch (error: any) {
        console.error('Erreur lors du chargement des années scolaires:', error)
        toast.error('Erreur lors du chargement des années scolaires')
      } finally {
        setLoadingAnneesScolaires(false)
      }
    }
    
    loadAnneesScolaires()
  }, [])

  // ✅ NOUVEAU : Charger les besoins depuis l'API au montage
  useEffect(() => {
    if (!user) return
    if (!user.structure?.id && user?.role?.code !== "CABINET") {
      setLoadingBesoins(false)
      return
    }
    loadBesoins()
    if (["DAF", "ADMIN", "DRENA", "CABINET"].includes(user?.role?.code || "")) {
      loadConsolidations()
    }
  }, [user?.structure?.id, user?.role?.code, functionalityPermissions])

  // ✅ NOUVEAU : Fonction pour charger les besoins depuis l'API
  const loadBesoins = async () => {
    console.log('🔵 [LOAD] ========== loadBesoins() DÉBUT ==========')
    console.log('🔵 [LOAD] loadBesoins appelé depuis:', new Error().stack)
    try {
      console.log('🔵 [LOAD] Avant setLoadingBesoins(true)')
      setLoadingBesoins(true)
      console.log('🔵 [LOAD] Après setLoadingBesoins(true)')
    } catch (setStateError: any) {
      console.error('🔴 [LOAD] Erreur lors de setLoadingBesoins:', setStateError)
      // Continuer même si setState échoue
    }
    
    try {
      // DIRECTEUR : structure_administrative de l’EPP. DRENA : drenaId (API + scope serveur sur le territoire).
      const userAny = user as any
      const criteria: Record<string, unknown> = buildBesoinGetByCriteriaPayload({
        roleCode: user?.role?.code,
        structureId:
          user?.structure?.id != null && Number(user.structure.id) > 0
            ? Number(user.structure.id)
            : undefined,
        drenaIdFromProfile:
          user?.role?.code === "DRENA" && userAny?.drena?.id != null && userAny.drena.id > 0
            ? userAny.drena.id
            : undefined,
        functionalityPermissions: user?.functionalityPermissions,
      })
      // IEPP / DAF / ADMIN : pas de filtre structure ici (filtrage métier côté UI ou périmètre national)
      
      console.log('🔵 [LOAD] Role:', user?.role?.code)
      console.log('🔵 [LOAD] Criteria:', criteria)
      
      console.log('🔵 [LOAD] Appel besoinsService.getByCriteria()...')
      let result: { success: boolean; data?: any[]; message: string } | null = null
      
      try {
        result = await besoinsService.getByCriteria(criteria, 0, 100)
      } catch (serviceError: any) {
        console.error('❌ [LOAD] Erreur dans le service getByCriteria():', serviceError)
        result = {
          success: false,
          message: serviceError?.message || serviceError?.toString() || 'Erreur lors de l\'appel au service'
        }
      }
      
      console.log('🟢 [LOAD] Résultat reçu de getByCriteria()')
      console.log('🟢 [LOAD] result (type):', typeof result)
      console.log('🟢 [LOAD] result (valeur):', result)
      console.log('🟢 [LOAD] result === null:', result === null)
      console.log('🟢 [LOAD] result === undefined:', result === undefined)
      console.log('🟢 [LOAD] result (JSON):', result ? JSON.stringify(result, null, 2) : 'null/undefined')
      
      // ✅ CORRECTION : Vérifier que result n'est pas null avant d'accéder à ses propriétés
      if (!result || typeof result !== 'object') {
        console.error('🔴 [LOAD] Erreur: result est null ou invalide')
        console.error('🔴 [LOAD] result:', result)
        console.error('🔴 [LOAD] typeof result:', typeof result)
        toast.error('Erreur lors du chargement des besoins: réponse invalide')
        setBesoins([])
        return
      }
      
      console.log('🟢 [LOAD] result est valide, vérification de result.success')
      
      // ✅ CORRECTION : Vérification supplémentaire avant d'accéder à result.success
      if (!result || typeof result !== 'object') {
        console.error('🔴 [LOAD] Erreur: result est null ou invalide après vérification initiale')
        console.error('🔴 [LOAD] result:', result)
        console.error('🔴 [LOAD] typeof result:', typeof result)
        toast.error('Erreur lors du chargement des besoins: réponse invalide')
        setBesoins([])
        return
      }
      
      console.log('🟢 [LOAD] result.success:', result.success)
      console.log('🟢 [LOAD] result.data:', result.data)
      
      // ✅ CORRECTION : Accès sécurisé à result.success
      const resultSuccess = result?.success
      const resultData = result?.data
      
      if (resultSuccess === true && resultData) {
        // Transformer les données API en format attendu par l'UI
        // ✅ CORRECTION : Utiliser resultData au lieu de result.data
        const besoinsTransformed = resultData.map((besoin: any) => ({
          id: besoin.id,
          structure: {
            code: besoin.structureAdministrativeCode || besoin.structureCode || user?.structure?.code,
            libelle: besoin.structureAdministrativeLibelle || besoin.structureLibelle || user?.structure?.libelle,
            type: besoin.structureType || user?.structure?.type || "EPP",
          },
          annee_scolaire: besoin.anneeScolaireLibelle || besoin.anneeScolaireCode,
          statut: besoin.statut || "SAISI",
          date_saisie: besoin.dateSaisie || new Date().toISOString().split('T')[0],
          saisi_par: besoin.saisiParLibelle || user?.nom + " " + user?.prenoms,
          niveaux: besoin.besoinDetails && besoin.besoinDetails.length > 0 ? [{
            niveau: besoin.niveauScolaireCode || besoin.niveauScolaireLibelle || "CP1",
            effectif_garcons: besoin.effectifGarcons || 0,
            effectif_filles: besoin.effectifFilles || 0,
            effectif_total: besoin.effectifTotal || 0,
            manuels: besoin.besoinDetails.map((detail: any) => ({
              titre: detail.matiereLibelle || detail.matiereCode || "",
              quantite: detail.quantiteBrute || 0,
              besoin_net: detail.quantiteNet || 0,
            })),
          }] : [{
            niveau: besoin.niveauScolaireCode || besoin.niveauScolaireLibelle || "CP1",
            effectif_garcons: besoin.effectifGarcons || 0,
            effectif_filles: besoin.effectifFilles || 0,
            effectif_total: besoin.effectifTotal || 0,
            manuels: [],
          }],
          total_manuels: sumManuelsBesoinPourListe({
            statut: besoin.statut || "SAISI",
            besoinDetails: besoin.besoinDetails || [],
          }),
          total_manuels_nets: besoin.besoinDetails?.reduce((sum: number, d: any) => sum + (d.quantiteNet || 0), 0) || 0,
          // Données brutes pour l'édition (inclure besoinDetails pour les besoins consolidés)
          _rawData: {
            ...besoin,
            besoinDetails: besoin.besoinDetails || [], // S'assurer que besoinDetails est toujours présent
          },
        }))
        
        console.log('🟢 [LOAD] Besoins transformés:', besoinsTransformed.length)
        console.log('🟢 [LOAD] Besoins par statut:', {
          SAISI: besoinsTransformed.filter(b => b.statut === "SAISI").length,
          VALIDE: besoinsTransformed.filter(b => b.statut === "VALIDE").length,
          CONSOLIDE: besoinsTransformed.filter(b => b.statut === "CONSOLIDE").length,
          APPROUVE: besoinsTransformed.filter(b => b.statut === "APPROUVE").length
        })
        setBesoins(besoinsTransformed)
      } else {
        console.warn('🟡 [LOAD] Aucun besoin trouvé ou erreur')
        console.warn('🟡 [LOAD] resultSuccess:', resultSuccess)
        console.warn('🟡 [LOAD] resultData:', resultData)
        console.warn('🟡 [LOAD] result?.message:', result?.message)
        setBesoins([])
      }
    } catch (error: any) {
      console.error('🔴 [LOAD] Erreur dans loadBesoins()')
      console.error('🔴 [LOAD] error (type):', typeof error)
      console.error('🔴 [LOAD] error (valeur):', error)
      console.error('🔴 [LOAD] error (JSON):', JSON.stringify(error, null, 2))
      console.error('🔴 [LOAD] error?.message:', error?.message)
      toast.error('Erreur lors du chargement des besoins')
      setBesoins([])
    } finally {
      console.log('🔵 [LOAD] loadBesoins() - FIN (finally)')
      setLoadingBesoins(false)
    }
  }

  // ✅ TOUS LES HOOKS DOIVENT ÊTRE AVANT LE RETURN CONDITIONNEL
  // Mettre à jour automatiquement les retours quand le niveau change
  useEffect(() => {
    if (user) {
      setFormData(prev => ({
        ...prev,
        niveaux: prev.niveaux.map(niveau => ({
          ...niveau,
          retours_auto: getRetoursByNiveau(niveau.niveau, user?.structure)
        }))
      }))
    }
  }, [user?.structure])

  // ✅ NOUVEAU: Fonction pour filtrer les besoins pour l'onglet Suivi selon le rôle (définie AVANT les useMemo)
  const getBesoinsForSuivi = () => {
    if (!user) return []
    let besoinsFiltres: any[] = []
    
    switch (user.role.code) {
      case "DIRECTEUR":
      case "INFORMATICIEN":
        // Équipe EPP : besoins de l’établissement (tous statuts) dans l’onglet Suivi
        const eppCode = (user as any).epp?.code || user.structure?.code
        const eppStructureId = (user as any).epp?.id || user.structure?.id
        besoinsFiltres = besoins.filter(b => 
          b._rawData?.structureType === "EPP" &&
          (b._rawData?.structureId === eppStructureId || b.structure?.code === eppCode)
        )
        break
      case "IEPP":
        // IEPP voit ses besoins IEPP consolidés (tous statuts) dans l'onglet Suivi
        const ieppStructureId = (user as any).iepp?.id || user.structure?.id
        besoinsFiltres = besoins.filter(b => 
          b._rawData?.structureType === "IEPP" &&
          b._rawData?.structureId === ieppStructureId
        )
        break
      case "DAF":
        // DAF voit tous les besoins IEPP consolidés (tous statuts)
        besoinsFiltres = besoins.filter(b => b._rawData?.structureType === "IEPP")
        break
      case "ADMIN":
        // ADMIN voit tous les besoins IEPP consolidés (tous statuts)
        besoinsFiltres = besoins.filter(b => b._rawData?.structureType === "IEPP")
        break
      case "DRENA":
        // Données déjà limitées au territoire par l’API (scope DRENA) ; ne garder que les lignes IEPP
        besoinsFiltres = besoins.filter(b => b._rawData?.structureType === "IEPP")
        break
      default:
        besoinsFiltres = []
    }
    
    // ✅ NOUVEAU : Appliquer le filtre par année scolaire si sélectionné
    if (filterAnneeScolaireId) {
      besoinsFiltres = besoinsFiltres.filter(b => 
        b._rawData?.anneeScolaireId === filterAnneeScolaireId
      )
    }
    
    // Appliquer le filtre par statut si sélectionné (mais on filtre déjà par APPROUVE, donc ce filtre est redondant)
    if (filterStatut) {
      besoinsFiltres = besoinsFiltres.filter(b => b.statut === filterStatut)
    }
    
    return besoinsFiltres
  }

  // Calcule l'effectif total de manière robuste (ancien + nouveau modèle).
  // IMPORTANT: l'effectif ne doit pas dépendre des quantités nettes de manuels
  // (qui peuvent diminuer avec les retours), sinon on crée une incohérence visuelle.
  const computeEffectifsFromBesoin = (rawData: any, niveaux?: any[], besoinStatut?: string) => {
    const st = String(besoinStatut ?? rawData?.statut ?? "").toUpperCase()
    const details = rawData?.besoinDetails
    void st
    const directTotal = rawData?.effectifTotal ?? rawData?.effectif_total
    if (typeof directTotal === "number" && directTotal > 0) return directTotal

    if (Array.isArray(details) && details.length > 0) {
      const totalByNiveau = new Map<string, number>()
      for (const d of details) {
        const niveauKey = String(
          d.niveauScolaireId ?? d.niveau_scolaire_id ?? d.niveauScolaireCode ?? d.niveauScolaireLibelle ?? "default"
        )
        const totalDetail =
          d.effectifTotalNiveau ??
          d.effectif_total_niveau ??
          d.effectifTotal ??
          d.effectif_total ??
          ((d.effectifGarcons ?? d.effectif_garcons ?? 0) + (d.effectifFilles ?? d.effectif_filles ?? 0))
        if (totalDetail > 0) {
          const current = totalByNiveau.get(niveauKey) ?? 0
          if (totalDetail > current) totalByNiveau.set(niveauKey, totalDetail)
        }
      }
      const fromDetails = Array.from(totalByNiveau.values()).reduce((sum, v) => sum + v, 0)
      if (fromDetails > 0) return fromDetails

      // Dernier fallback legacy: dériver depuis les quantités des lignes si
      // aucun champ effectif n'est fourni par le backend.
      const byNiveau = new Map<string, any[]>()
      for (const d of details) {
        const niveauKey = String(
          d.niveauScolaireId ?? d.niveau_scolaire_id ?? d.niveauScolaireCode ?? d.niveauScolaireLibelle ?? "default"
        )
        if (!byNiveau.has(niveauKey)) byNiveau.set(niveauKey, [])
        byNiveau.get(niveauKey)!.push(d)
      }
      let sumMoyennesNiveaux = 0
      let anyExemplairePositif = false
      for (const nivDetails of byNiveau.values()) {
        for (const d of nivDetails) {
          if (quantiteDetailPourAffichageExemplaires(d, st) > 0) anyExemplairePositif = true
        }
        const moyenne = effectifElevesParNiveauDepuisDetailsLignes(nivDetails, st)
        sumMoyennesNiveaux += moyenne != null ? moyenne : 0
      }
      if (anyExemplairePositif) return sumMoyennesNiveaux
    }

    const fromNiveaux =
      niveaux?.reduce((sum: number, n: any) => sum + (n.effectif_total ?? n.effectifTotal ?? 0), 0) ?? 0
    return fromNiveaux
  }

  // ✅ NOUVEAU: Calcul des statistiques pour l'onglet Suivi (AVANT le return conditionnel pour respecter les règles des Hooks)
  const besoinsSuivi = useMemo(() => {
    if (!user) return []
    return getBesoinsForSuivi()
  }, [besoins, user, filterStatut, filterAnneeScolaireId])
  
  // ✅ Pour DRENA/DAF/IEPP : grouper par IEPP (une ligne par IEPP) pour affichage Suivi — l'IEPP voit sa ligne comme DRENA/DAF
  const suiviParIepp = useMemo(() => {
    if (!user || !canUseBesoinsSuiviParIeppGrouping(user.role.code, functionalityPermissions)) return []
    const byIepp = new Map<number, { id: number; iepp: string; effectifs: number; manuels: number; statut: string; besoins: any[]; annee?: string }>()
    for (const b of besoinsSuivi) {
      const sid = b._rawData?.structureId
      if (!sid) continue
      const libelle = b._rawData?.structureAdministrativeLibelle || b.structure?.libelle || "IEPP"
      if (!byIepp.has(sid)) {
        byIepp.set(sid, { id: sid, iepp: libelle, effectifs: 0, manuels: 0, statut: "SAISI", besoins: [] })
      }
      const row = byIepp.get(sid)!
      row.effectifs += computeEffectifsFromBesoin(b._rawData ?? b, b.niveaux, b.statut)
      const details = b._rawData?.besoinDetails || b.besoinDetails || []
      const manuels =
        details.length > 0
          ? details.reduce((s: number, d: any) => s + quantiteDetailPourAffichageExemplaires(d, b.statut), 0)
          : b.total_manuels || 0
      row.manuels += manuels
      row.besoins.push(b)
      const ordre = { SAISI: 1, VALIDE: 2, CONSOLIDE: 3, APPROUVE: 4 }
      if (ordre[b.statut as keyof typeof ordre] > ordre[row.statut as keyof typeof ordre]) row.statut = b.statut
      if (b.annee_scolaire || b._rawData?.anneeScolaireLibelle) row.annee = b.annee_scolaire || b._rawData?.anneeScolaireLibelle
    }
    return Array.from(byIepp.values())
  }, [besoinsSuivi, user, functionalityPermissions])

  const statsSuivi = useMemo(() => {
    const isParIepp = canUseBesoinsSuiviParIeppGrouping(user?.role?.code, functionalityPermissions)
    const source = isParIepp ? suiviParIepp : besoinsSuivi
    const total = Array.isArray(source) ? source.length : 0
    const saisi = isParIepp ? (suiviParIepp.filter((r: any) => r.statut === "SAISI").length) : (besoinsSuivi.filter(b => b.statut === "SAISI").length)
    const valide = isParIepp ? (suiviParIepp.filter((r: any) => r.statut === "VALIDE").length) : (besoinsSuivi.filter(b => b.statut === "VALIDE").length)
    const consolide = isParIepp ? (suiviParIepp.filter((r: any) => r.statut === "CONSOLIDE").length) : (besoinsSuivi.filter(b => b.statut === "CONSOLIDE").length)
    const approuve = isParIepp ? (suiviParIepp.filter((r: any) => r.statut === "APPROUVE").length) : (besoinsSuivi.filter(b => b.statut === "APPROUVE").length)
    const totalEffectifs = isParIepp ? suiviParIepp.reduce((sum: number, r: any) => sum + (r.effectifs || 0), 0) : besoinsSuivi.reduce((sum, b) => sum + (b.effectifTotal || 0), 0)
    const totalManuels = isParIepp ? suiviParIepp.reduce((sum: number, r: any) => sum + (r.manuels || 0), 0) : besoinsSuivi.reduce((sum, b) => {
      return sum + sumManuelsBesoinPourListe(b)
    }, 0)
    return { total, saisi, valide, consolide, approuve, totalEffectifs, totalManuels }
  }, [besoinsSuivi, suiviParIepp, user?.role?.code, functionalityPermissions])

  // ✅ Regroupement des besoins consolidés par IEPP - AVANT le return conditionnel (règles des Hooks)
  const besoinsValidationGroupesParIepp = useMemo(() => {
    if (!user || !canUseBesoinsValidationGroupedByIeppList(user.role.code, functionalityPermissions)) return []
    const liste = besoins.filter((b: any) => {
      const isConsolide = b.statut === "CONSOLIDE"
      const isIepp = b._rawData?.structureAdministrativeCode?.includes("IEPP") || 
                    b._rawData?.structureAdministrativeLibelle?.includes("IEPP") ||
                    b._rawData?.structureType === "IEPP" || b.structureType === "IEPP"
      return isConsolide && isIepp
    })
    const byKey = new Map<string, { structureId: number; structureLibelle: string; structureCode: string; annee: string; totalManuels: number; totalEffectifs: number; statut: string; besoins: any[] }>()
    for (const b of liste) {
      const rid = b._rawData?.structureId ?? b.structure?.id
      const code = (b._rawData?.structureAdministrativeCode ?? b.structure?.code ?? "").trim()
      const libelle = (b._rawData?.structureAdministrativeLibelle ?? b.structure?.libelle ?? "").trim()
      const groupId = rid ?? (code || libelle || "unknown")
      const annee = (b.annee_scolaire || "").trim().replace(/\s+/g, " ")
      const key = `${groupId}_${annee}`
      const manuels =
        b._rawData?.besoinDetails?.reduce(
          (s: number, d: any) => s + quantiteDetailPourAffichageExemplaires(d, b.statut),
          0,
        ) ?? b.total_manuels ?? 0
      const effectifs = computeEffectifsFromBesoin(b._rawData ?? b, b.niveaux, b.statut)
      if (!byKey.has(key)) {
        byKey.set(key, {
          structureId: (typeof rid === 'number' && rid > 0) ? rid : 0,
          structureLibelle: (b.structure?.libelle ?? b._rawData?.structureAdministrativeLibelle ?? libelle) || "IEPP",
          structureCode: code || (b.structure?.code ?? b._rawData?.structureAdministrativeCode ?? ""),
          annee,
          totalManuels: 0,
          totalEffectifs: 0,
          statut: b.statut || "CONSOLIDE",
          besoins: []
        })
      }
      const g = byKey.get(key)!
      if ((typeof rid === 'number' && rid > 0) && g.structureId === 0) g.structureId = rid
      g.totalManuels += manuels
      g.totalEffectifs += effectifs
      g.besoins.push(b)
    }
    return Array.from(byKey.values())
  }, [besoins, user?.role?.code, functionalityPermissions])

  useEffect(() => {
    setSaisieListPage(1)
  }, [activeTab, besoins.length])

  useEffect(() => {
    setValidationListPage(1)
  }, [activeTab, besoins.length, besoinsValidationGroupesParIepp.length, user?.role?.code])

  useEffect(() => {
    setConsolidationDrenaPage(1)
  }, [activeTab, consolidationDRENA.length])

  useEffect(() => {
    setConsolidationIeppPage(1)
  }, [activeTab, consolidationIEPP.length, besoins.length])

  useEffect(() => {
    setSuiviListPage(1)
  }, [activeTab, filterStatut, filterAnneeScolaireId, besoinsSuivi.length, suiviParIepp.length])

  // ✅ CORRECTION: Vérification après tous les hooks
  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <p className="text-gray-600">Chargement...</p>
        </div>
      </div>
    )
  }


  const getStatusIcon = (statut: string) => {
    switch (statut) {
      case "SAISI":
        return <ClockIcon className="h-5 w-5 text-blue-600" />
      case "VALIDE":
        return <CheckCircleIcon className="h-5 w-5 text-green-600" />
      case "CONSOLIDE":
        return <DocumentTextIcon className="h-5 w-5 text-purple-600" />
      case "APPROUVE":
        return <CheckCircleIcon className="h-5 w-5 text-emerald-600" />
      case "VALIDE_DAF":
        return <CheckCircleIcon className="h-5 w-5 text-blue-600" />
      case "CONSOLIDE_DAF":
        return <DocumentTextIcon className="h-5 w-5 text-indigo-600" />
      case "VALIDE_NATIONAL":
        return <CheckCircleIcon className="h-5 w-5 text-green-700" />
      case "EN_COURS":
        return <ClockIcon className="h-5 w-5 text-orange-600" />
      case "ANNULE":
        return <ExclamationTriangleIcon className="h-5 w-5 text-red-600" />
      case "BROUILLON":
        return <ExclamationTriangleIcon className="h-5 w-5 text-yellow-600" />
      default:
        return <ExclamationTriangleIcon className="h-5 w-5 text-gray-600" />
    }
  }

  const getStatusBadge = (statut: string) => {
    const baseClasses = "px-2 py-1 text-xs font-medium rounded-full"
    switch (statut) {
      case "SAISI":
        return <span className={`${baseClasses} bg-blue-100 text-blue-800`}>Saisi</span>
      case "VALIDE":
        return <span className={`${baseClasses} bg-green-100 text-green-800`}>Validé</span>
      case "CONSOLIDE":
        return <span className={`${baseClasses} bg-purple-100 text-purple-800`}>Consolidé</span>
      case "APPROUVE":
        return <span className={`${baseClasses} bg-emerald-100 text-emerald-800`}>Approuvé</span>
      case "VALIDE_DAF":
        return <span className={`${baseClasses} bg-blue-100 text-blue-800`}>Validé DAF</span>
      case "CONSOLIDE_DAF":
        return <span className={`${baseClasses} bg-indigo-100 text-indigo-800`}>Consolidé DAF</span>
      case "VALIDE_NATIONAL":
        return <span className={`${baseClasses} bg-green-200 text-green-900`}>Validé National</span>
      case "EN_COURS":
        return <span className={`${baseClasses} bg-orange-100 text-orange-800`}>En cours</span>
      case "ANNULE":
        return <span className={`${baseClasses} bg-red-100 text-red-800`}>Annulé</span>
      case "BROUILLON":
        return <span className={`${baseClasses} bg-yellow-100 text-yellow-800`}>Brouillon</span>
      default:
        return <span className={`${baseClasses} bg-gray-100 text-gray-800`}>En attente</span>
    }
  }

  // ✅ NOUVELLE FONCTION: Charger les consolidations depuis la BD pour DAF/ADMIN
  const loadConsolidations = async () => {
    console.log('🔵 [LOAD-CONSOLIDATIONS] ========== loadConsolidations() DÉBUT ==========')
    try {
      // Charger tous les besoins consolidés (ce sont des besoins IEPP créés lors de la consolidation)
      const criteria: any = {
        statut: "CONSOLIDE"
      }
      
      console.log('🔵 [LOAD-CONSOLIDATIONS] Criteria:', criteria)
      const result = await besoinsService.getByCriteria(criteria, 0, 1000)
      
      if (result?.success && result?.data) {
        const besoinsConsolides = result.data
        
        console.log('🟢 [LOAD-CONSOLIDATIONS] Besoins consolidés récupérés:', besoinsConsolides.length)
        
        // ✅ CORRECTION: Les besoins consolidés sont des besoins IEPP (structureId = IEPP)
        // Grouper par IEPP (structureId)
        const consolidationsParIepp = new Map<number, any>()
        
        besoinsConsolides.forEach((besoin: any) => {
          // ✅ FILTRE: Ne garder que les besoins IEPP (structureType = "IEPP" ou structureAdministrativeCode contient "IEPP")
          const isIepp = besoin.structureAdministrativeCode?.includes("IEPP") || 
                        besoin.structureAdministrativeLibelle?.includes("IEPP") ||
                        besoin.structureType === "IEPP"
          
          if (!isIepp) {
            console.log('🔵 [LOAD-CONSOLIDATIONS] Besoin ignoré (pas IEPP):', besoin.id, besoin.structureAdministrativeLibelle)
            return // Ignorer les besoins non-IEPP
          }
          
          const structureId = besoin.structureId
          const structureLibelle = besoin.structureAdministrativeLibelle || "Structure inconnue"
          const structureCode = besoin.structureAdministrativeCode || ""
          
          // ✅ CORRECTION: Les besoins consolidés sont toujours des IEPP
          // Créer ou mettre à jour la consolidation IEPP
          if (!consolidationsParIepp.has(structureId)) {
            consolidationsParIepp.set(structureId, {
              id: structureId,
              iepp: structureLibelle,
              drena: "DRENA " + (structureCode.split("-")[0] || "Inconnue"), // À améliorer avec vraie DRENA depuis la hiérarchie
              statut: besoin.statut || "CONSOLIDE",
              date_consolidation: besoin.dateConsolidation || new Date().toISOString().split('T')[0],
              epp_count: 0,
              total_effectifs: 0,
              total_manuels: 0,
              besoins: []
            })
          }
          
          const consolidation = consolidationsParIepp.get(structureId)!
          const effectifs = besoin.effectifTotal || 0
          // Après consolidation : priorité quantiteConsolidee > quantiteApprouvee > quantiteNet > quantiteBrute (camelCase + snake_case)
          const manuels = besoin.besoinDetails?.reduce((sum: number, d: any) => 
            sum + (d.quantiteConsolidee ?? d.quantiteApprouvee ?? d.quantiteNet ?? d.quantiteBrute ?? d.quantite_brute ?? d.quantite_net ?? 0), 0) || 0
          
          consolidation.total_effectifs += effectifs
          consolidation.total_manuels += manuels
          // epp_count : ne pas incrémenter par ligne besoin IEPP (multi-niveaux ⇒ fausse « école »).
          // Valeur corrigée après la boucle via getConsolidationDetails (nombre d’EPP distinctes).

          // ✅ CORRECTION: Ajouter les détails par niveau/matière
          consolidation.besoins.push({
            epp: structureLibelle + " - " + (besoin.niveauScolaireLibelle || besoin.niveauScolaireCode || ""),
            effectifs: effectifs,
            manuels: manuels,
            statut: besoin.statut || "CONSOLIDE",
            niveau: besoin.niveauScolaireLibelle || besoin.niveauScolaireCode || "",
            besoinDetails: besoin.besoinDetails || []
          })
        })
        
        // ✅ CORRECTION: Grouper les IEPP par DRENA
        // Pour l'instant, on groupe par préfixe du code structure (à améliorer avec vraie hiérarchie)
        const consolidationsParDrena = new Map<string, any>()
        
        consolidationsParIepp.forEach((consolidationIepp) => {
          // Extraire DRENA du code structure (ex: "A010" de "A010-B005-C001-D000")
          const drenaCode = consolidationIepp.drena
          
          if (!consolidationsParDrena.has(drenaCode)) {
            consolidationsParDrena.set(drenaCode, {
              id: consolidationsParDrena.size + 1,
              drena: drenaCode,
              statut: "CONSOLIDE",
              date_consolidation: consolidationIepp.date_consolidation,
              iepp_count: 0,
              total_effectifs: 0,
              total_manuels: 0,
              consolidations_iepp: []
            })
          }
          
          const consolidationDrena = consolidationsParDrena.get(drenaCode)!
          consolidationDrena.iepp_count += 1
          consolidationDrena.total_effectifs += consolidationIepp.total_effectifs
          consolidationDrena.total_manuels += consolidationIepp.total_manuels
          consolidationDrena.consolidations_iepp.push({
            iepp: consolidationIepp.iepp,
            effectifs: consolidationIepp.total_effectifs,
            manuels: consolidationIepp.total_manuels,
            statut: consolidationIepp.statut
          })
        })
        
        // Convertir les Maps en arrays
        const consolidationsIEPPArray = Array.from(consolidationsParIepp.values())
        const consolidationsDRENAArray = Array.from(consolidationsParDrena.values())

        // Nombre réel d’écoles (EPP) par IEPP : même source que « Voir détails » (dédoublonnage structureId)
        try {
          await Promise.all(
            consolidationsIEPPArray.map(async (row: { id: number; epp_count: number }) => {
              if (row.id == null || row.id <= 0) return
              const det = await besoinsService.getConsolidationDetails(row.id)
              if (!det?.success || !Array.isArray(det.data) || det.data.length === 0) {
                row.epp_count = 0
                return
              }
              const ids = new Set<number>()
              for (const b of det.data) {
                const sid = b.structureId ?? b.structureAdministrativeId
                if (typeof sid === "number" && sid > 0) ids.add(sid)
              }
              row.epp_count = ids.size > 0 ? ids.size : det.data.length
            })
          )
        } catch (enrichErr) {
          console.warn("🟡 [LOAD-CONSOLIDATIONS] enrichissement epp_count:", enrichErr)
        }

        console.log('🟢 [LOAD-CONSOLIDATIONS] Consolidations IEPP:', consolidationsIEPPArray.length)
        console.log('🟢 [LOAD-CONSOLIDATIONS] Consolidations DRENA:', consolidationsDRENAArray.length)
        console.log('🟢 [LOAD-CONSOLIDATIONS] Données IEPP:', JSON.stringify(consolidationsIEPPArray, null, 2))
        
        setConsolidationIEPP(consolidationsIEPPArray)
        setConsolidationDRENA(consolidationsDRENAArray)
      } else {
        console.warn('🟡 [LOAD-CONSOLIDATIONS] Aucune consolidation trouvée')
        setConsolidationIEPP([])
        setConsolidationDRENA([])
      }
    } catch (error: any) {
      console.error('🔴 [LOAD-CONSOLIDATIONS] Erreur:', error)
      toast.error('Erreur lors du chargement des consolidations')
      // En cas d'erreur, vider les consolidations pour forcer le rechargement
      setConsolidationIEPP([])
      setConsolidationDRENA([])
    }
    console.log('🔵 [LOAD-CONSOLIDATIONS] ========== loadConsolidations() FIN ==========')
  }

  const getBesoinsByRole = () => {
    switch (user.role.code) {
      case "DIRECTEUR":
      case "INFORMATICIEN":
        // Le besoin est rattaché à l'EPP (école), pas à l'IEPP : inclure si structure = EPP du compte
        const eppCode = (user as any).epp?.code
        const eppStructureId = (user as any).epp?.id
        return besoins.filter(b =>
          (eppStructureId != null && b._rawData?.structureId === eppStructureId) ||
          (eppCode && b.structure?.code === eppCode) ||
          (b.structure?.code === user.structure?.code)
        )
      case "IEPP": {
        // IEPP : EPP rattachées via structureParentId (référentiel A010-B005-C…), pas seulement préfixe "EPP-"
        const ieppStructureId = user.structure?.id ?? (user as any).iepp?.id
        const ieppZone = user.structure?.code?.split("-")[1] || ""
        const besoinsEpp = besoins.filter(b => {
          const raw = b._rawData
          if (!raw) return false
          if (besoinRawIsEpp(raw) && sameStructureId(raw.structureParentId, ieppStructureId)) {
            return true
          }
          // Type parfois absent en DTO : rattachement EPP → IEPP via parentId
          if (
            sameStructureId(raw.structureParentId, ieppStructureId) &&
            !besoinRawIsIepp(raw)
          ) {
            return true
          }
          const code = String(b.structure?.code || raw.structureAdministrativeCode || "")
          return code.startsWith("EPP-") && !!ieppZone && code.includes(ieppZone)
        })
        const besoinsIeppConsolides = besoins.filter(b => {
          const raw = b._rawData
          if (!raw) return false
          const okStatut = b.statut === "CONSOLIDE" || b.statut === "APPROUVE"
          return (
            okStatut &&
            sameStructureId(raw.structureId, ieppStructureId) &&
            besoinRawIsIepp(raw)
          )
        })
        return [...besoinsEpp, ...besoinsIeppConsolides]
      }
      case "DRENA":
        // ✅ CORRECTION: DRENA ne gère plus l'expression des besoins (flux direct IEPP → DAF)
        return []
      case "DAF":
        // ✅ CORRECTION: DAF voit SEULEMENT les besoins CONSOLIDE de type IEPP
        // Filtrer par statut CONSOLIDE ET structure type = IEPP
        return besoins.filter(b => {
          const isConsolide = b.statut === "CONSOLIDE"
          // Identifier les besoins IEPP : structureAdministrativeCode contient "IEPP" ou structureType = "IEPP"
          const isIepp = b._rawData?.structureAdministrativeCode?.includes("IEPP") || 
                        b._rawData?.structureAdministrativeLibelle?.includes("IEPP") ||
                        b._rawData?.structureType === "IEPP" ||
                        b.structureType === "IEPP"
          return isConsolide && isIepp
        })
      case "ADMIN":
      case "CABINET":
        return besoins
      default:
        return []
    }
  }


  const handleNewBesoin = () => {
    if (consultationOnly) {
      toast.error("Création de besoin indisponible en mode consultation.")
      return
    }
    setBesoinToEdit(null)
    setShowBesoinForm(true)
    // Garder l'ancien modal pour compatibilité
    setModalType("new")
    const niveauxInit = [
      {
        niveau: "CP1",
        effectif_garcons: 0,
        effectif_filles: 0,
        effectif_total: 0,
        manuels: [],
        retours_auto: getRetoursByNiveau("CP1", user?.structure),
        coef_reparable: 0.7,
      },
    ]
    setFormData({ niveaux: niveauxInit })
    setShowModal(false) // Désactiver l'ancien modal
  }

  const handleViewBesoin = async (besoinOrGroupe: any) => {
    console.log('🔵 [VIEW-BESOIN] handleViewBesoin appelé')
    // ✅ Groupe par IEPP : charger tous les besoins et fusionner pour affichage
    if (typeof besoinOrGroupe === 'object' && Array.isArray(besoinOrGroupe.besoins) && besoinOrGroupe.besoins.length > 0) {
      const groupe = besoinOrGroupe
      try {
        const ids = groupe.besoins.map((b: any) => b._rawData?.id ?? b.id).filter((id: any) => id != null)
        const results = await Promise.all(ids.map((id: number) => besoinsService.getDetails(id)))
        const loaded = results.filter((r: any) => r.success && r.data).map((r: any) => r.data)
        if (loaded.length === 0) {
          toast.error('Impossible de charger les détails')
          return
        }
        const premier = loaded[0]
        // Enrichir chaque détail avec les effectifs du Besoin parent si le détail ne les a pas
        const besoinDetailsFusionnes = loaded.flatMap((b: any) =>
          (b.besoinDetails || []).map((d: any) => ({
            ...d,
            effectifTotalNiveau:
              d.effectifTotalNiveau ??
              d.effectif_total_niveau ??
              (d.effectifGarcons ?? d.effectif_garcons ?? 0) + (d.effectifFilles ?? d.effectif_filles ?? 0),
            effectifGarcons: d.effectifGarcons ?? d.effectif_garcons ?? b.effectifGarcons ?? b.effectif_garcons ?? 0,
            effectifFilles: d.effectifFilles ?? d.effectif_filles ?? b.effectifFilles ?? b.effectif_filles ?? 0
          }))
        )
        const besoinComplet = {
          ...premier,
          structureAdministrativeLibelle: groupe.structureLibelle,
          structureId: groupe.structureId,
          besoinDetails: besoinDetailsFusionnes,
          effectifTotal: loaded.reduce((s: number, b: any) => s + (b.effectifTotal || 0), 0),
          effectifGarcons: loaded.reduce((s: number, b: any) => s + (b.effectifGarcons || 0), 0),
          effectifFilles: loaded.reduce((s: number, b: any) => s + (b.effectifFilles || 0), 0),
        }
        setSelectedBesoin(besoinComplet)
        setEppBesoinsAssocies([])
        if (groupe.statut === "APPROUVE" && groupe.structureId) {
          setLoadingEppBesoins(true)
          try {
            const eppResult = await besoinsService.getConsolidationDetails(groupe.structureId)
            if (eppResult.success && eppResult.data) {
              setEppBesoinsAssocies(eppResult.data)
            } else setEppBesoinsAssocies([])
          } catch {
            setEppBesoinsAssocies([])
          } finally {
            setLoadingEppBesoins(false)
          }
        }
      } catch (error: any) {
        console.error('🔴 [VIEW-BESOIN] Erreur:', error)
        toast.error('Erreur lors du chargement des détails')
        return
      }
      setModalType("view")
      setShowModal(true)
      return
    }

    const besoin = besoinOrGroupe
    const rawData = besoin._rawData || besoin
    if (rawData?.id) {
      try {
        console.log('🔵 [VIEW-BESOIN] Appel backend pour récupérer les détails du besoin:', rawData.id)
        const detailsResult = await besoinsService.getDetails(rawData.id)
        
        if (detailsResult.success && detailsResult.data) {
          console.log('🟢 [VIEW-BESOIN] Détails récupérés du backend:', detailsResult.data)
          console.log('🟢 [VIEW-BESOIN] BesoinDetails:', detailsResult.data.besoinDetails?.length || 0)
          
          // Utiliser les données complètes du backend
          const besoinComplet = detailsResult.data
          setSelectedBesoin(besoinComplet)
          
          // ✅ NOUVEAU : Si c'est un besoin IEPP approuvé, charger les besoins EPP associés
          if (besoinComplet.statut === "APPROUVE" && besoinComplet.structureType === "IEPP" && besoinComplet.structureId) {
            console.log('🔵 [VIEW-BESOIN] ✅ Condition remplie pour charger les besoins EPP associés')
            console.log('🔵 [VIEW-BESOIN] structureId:', besoinComplet.structureId)
            setLoadingEppBesoins(true)
            try {
              // Utiliser getConsolidationDetails pour récupérer les besoins EPP consolidés
              // Le paramètre attendu est l'ID de la structure IEPP (structureId)
              console.log('🔵 [VIEW-BESOIN] Appel getConsolidationDetails avec structureId:', besoinComplet.structureId)
              const eppBesoinsResult = await besoinsService.getConsolidationDetails(besoinComplet.structureId)
              console.log('🟢 [VIEW-BESOIN] Résultat getConsolidationDetails:', eppBesoinsResult)
              if (eppBesoinsResult.success && eppBesoinsResult.data) {
                console.log('🟢 [VIEW-BESOIN] ✅ Données EPP reçues:', eppBesoinsResult.data.length, 'besoins')
                // Filtrer pour ne garder que les besoins EPP du même niveau et année scolaire
                const eppBesoinsFiltered = eppBesoinsResult.data.filter((b: any) => 
                  b.niveauScolaireId === besoinComplet.niveauScolaireId &&
                  b.anneeScolaireId === besoinComplet.anneeScolaireId &&
                  b.structureType === "EPP"
                )
                console.log('🟢 [VIEW-BESOIN] Besoins EPP filtrés (même niveau/année):', eppBesoinsFiltered.length)
                setEppBesoinsAssocies(eppBesoinsFiltered)
                console.log('🟢 [VIEW-BESOIN] ✅ Besoins EPP associés chargés et définis:', eppBesoinsFiltered.length)
              } else {
                console.warn('🟡 [VIEW-BESOIN] Aucune donnée EPP reçue ou erreur:', eppBesoinsResult.message)
                setEppBesoinsAssocies([])
              }
            } catch (error: any) {
              console.error('🔴 [VIEW-BESOIN] Erreur lors du chargement des besoins EPP associés:', error)
              console.error('🔴 [VIEW-BESOIN] Error stack:', error.stack)
              setEppBesoinsAssocies([])
            } finally {
              setLoadingEppBesoins(false)
            }
          } else {
            console.log('🟡 [VIEW-BESOIN] Condition non remplie pour charger les besoins EPP:')
            console.log('🟡 [VIEW-BESOIN]   - statut === "APPROUVE":', besoinComplet.statut === "APPROUVE")
            console.log('🟡 [VIEW-BESOIN]   - structureType === "IEPP":', besoinComplet.structureType === "IEPP")
            console.log('🟡 [VIEW-BESOIN]   - structureId existe:', !!besoinComplet.structureId)
            console.log('🟡 [VIEW-BESOIN]   - structureId valeur:', besoinComplet.structureId)
            setEppBesoinsAssocies([])
          }
        } else {
          console.warn('🟡 [VIEW-BESOIN] Aucun détail trouvé ou erreur:', detailsResult.message)
          // Utiliser les données existantes en cas d'erreur
          setSelectedBesoin(besoin)
          setEppBesoinsAssocies([])
        }
      } catch (error: any) {
        console.error('🔴 [VIEW-BESOIN] Erreur lors de la récupération des détails:', error)
        // Utiliser les données existantes en cas d'erreur
        setSelectedBesoin(besoin)
        setEppBesoinsAssocies([])
      }
    } else {
      console.warn('🟡 [VIEW-BESOIN] Pas d\'ID trouvé dans le besoin, utilisation des données existantes')
      setSelectedBesoin(besoin)
      setEppBesoinsAssocies([])
    }
    
    setModalType("view")
    setShowModal(true)
  }

  const handleEditBesoin = async (besoin: any) => {
    if (consultationOnly) {
      toast.error("Modification de besoin indisponible en mode consultation.")
      return
    }
    setSelectedBesoin(besoin)
    setLoadingBesoins(true)
    
    try {
      // ✅ NOUVEAU : Charger les détails complets depuis le backend
      const rawData = besoin._rawData || besoin
      if (rawData?.id) {
        const detailsResult = await besoinsService.getDetails(rawData.id)
        
        if (detailsResult.success && detailsResult.data) {
          const besoinComplet = detailsResult.data
          setBesoinToEdit({
            id: besoinComplet.id,
            reference: besoinComplet.reference,
            structureId: besoinComplet.structureId || user?.structure?.id,
            niveauScolaireId: besoinComplet.niveauScolaireId,
            anneeScolaireId: besoinComplet.anneeScolaireId,
            effectifGarcons: besoinComplet.effectifGarcons,
            effectifFilles: besoinComplet.effectifFilles,
            effectifTotal: besoinComplet.effectifTotal,
            statut: besoinComplet.statut,
            commentaire: besoinComplet.commentaire,
            besoinDetails: besoinComplet.besoinDetails || [],
            // Ajouter toutes les autres propriétés pour l'affichage
            structureAdministrativeLibelle: besoinComplet.structureAdministrativeLibelle,
            niveauScolaireLibelle: besoinComplet.niveauScolaireLibelle,
            niveauScolaireCode: besoinComplet.niveauScolaireCode,
            anneeScolaireLibelle: besoinComplet.anneeScolaireLibelle,
            dateSaisie: besoinComplet.dateSaisie,
            saisiParFirstName: besoinComplet.saisiParFirstName,
            saisiParLastName: besoinComplet.saisiParLastName,
            dateValidation: besoinComplet.dateValidation,
            valideParFirstName: besoinComplet.valideParFirstName,
            valideParLastName: besoinComplet.valideParLastName,
            dateConsolidation: besoinComplet.dateConsolidation,
            consolideParFirstName: besoinComplet.consolideParFirstName,
            consolideParLastName: besoinComplet.consolideParLastName,
            dateApprobation: besoinComplet.dateApprobation,
            approuveParFirstName: besoinComplet.approuveParFirstName,
            approuveParLastName: besoinComplet.approuveParLastName,
          } as any)
          setShowBesoinForm(true)
          setShowModal(false) // Désactiver l'ancien modal
        } else {
          toast.error(detailsResult.message || 'Erreur lors du chargement des détails')
        }
      } else {
        // Fallback vers l'ancien modal si pas d'ID
        setModalType("edit")
        setFormData({
          niveaux: besoin.niveaux.map((n: any) => ({
            ...n,
            manuels: n.manuels || [],
          })),
        })
        setShowModal(true)
      }
    } catch (error: any) {
      console.error('Erreur lors du chargement des détails du besoin:', error)
      toast.error('Erreur lors du chargement des détails du besoin')
    } finally {
      setLoadingBesoins(false)
    }
  }

  // ✅ NOUVELLE FONCTION: Consolidation IEPP (appelle le backend)
  const handleConsoliderIEPP = async () => {
    if (consultationOnly) {
      toast.error("Consolidation indisponible en mode consultation.")
      return
    }
    try {
      if (!user?.id || !user?.structure?.id) {
        toast.error('Utilisateur ou structure non trouvé')
        return
      }

      // Récupérer l'année scolaire courante
      const anneeScolaireId = besoins.length > 0 && besoins[0]._rawData?.anneeScolaireId 
        ? besoins[0]._rawData.anneeScolaireId 
        : null

      if (!anneeScolaireId) {
        toast.error('Année scolaire non trouvée')
        return
      }

      console.log('🔵 [CONSOLIDATE-HANDLER] Avant appel service');
      let result: { success: boolean; data?: any[]; message: string } | null = null;
      
      try {
        result = await besoinsService.consolidate(
          user.structure.id, // ieppId
          anneeScolaireId,
          user.id // consolidePar
        ) as { success: boolean; data?: any[]; message: string } | null;
      } catch (serviceError: any) {
        console.error('🔴 [CONSOLIDATE-HANDLER] Erreur lors de l\'appel au service:', serviceError);
        result = {
          success: false,
          message: serviceError?.message || 'Erreur lors de l\'appel au service de consolidation',
        };
      }
      
      console.log('🔵 [CONSOLIDATE-HANDLER] Résultat reçu du service');
      console.log('🔵 [CONSOLIDATE-HANDLER] result (type):', typeof result);
      console.log('🔵 [CONSOLIDATE-HANDLER] result (valeur):', result);
      console.log('🔵 [CONSOLIDATE-HANDLER] result === null:', result === null);
      console.log('🔵 [CONSOLIDATE-HANDLER] result === undefined:', result === undefined);
      
      // ✅ CORRECTION : Vérifier que result n'est pas null/undefined
      if (!result || result === null || result === undefined) {
        console.error('🔴 [CONSOLIDATE-HANDLER] result est null/undefined');
        const errorMessage = 'Erreur: Réponse invalide du serveur';
        try {
          toast.error(errorMessage, {
            duration: 5000,
            position: 'top-right',
            style: {
              backgroundColor: '#fee2e2',
              color: '#991b1b',
              border: '1px solid #fca5a5',
            },
          })
        } catch (toastError: any) {
          console.error('🔴 Erreur lors de l\'appel à toast.error():', toastError)
          showCustomNotification(errorMessage, 'error')
        }
        return
      }
      
      // ✅ CORRECTION : Accès sécurisé à result.success avec optional chaining
      const resultSuccess = result?.success;
      console.log('🔵 [CONSOLIDATE-HANDLER] result.success:', resultSuccess);
      console.log('🔵 [CONSOLIDATE-HANDLER] typeof result.success:', typeof resultSuccess);
      
      if (resultSuccess === true) {
        try {
          toast.success(`✅ Consolidation IEPP réussie - ${result.data?.length || 0} besoin(s) consolidé(s)`, {
            duration: 5000,
            position: 'top-right',
            style: {
              backgroundColor: '#dcfce7',
              color: '#166534',
              border: '1px solid #86efac',
            },
          })
        } catch (toastError: any) {
          console.error('🔴 Erreur lors de l\'appel à toast.success():', toastError)
          showCustomNotification(`✅ Consolidation IEPP réussie - ${result.data?.length || 0} besoin(s) consolidé(s)`, 'success')
        }
        await loadBesoins() // Recharger les besoins
        // ✅ CORRECTION: Recharger aussi les consolidations pour DAF/ADMIN
        if (["DAF", "ADMIN", "DRENA"].includes(user?.role?.code || "")) {
          await loadConsolidations()
        }
      } else {
        const errorMessage = result.message || 'Erreur lors de la consolidation IEPP'
        try {
          toast.error(errorMessage, {
            duration: 5000,
            position: 'top-right',
            style: {
              backgroundColor: '#fee2e2',
              color: '#991b1b',
              border: '1px solid #fca5a5',
            },
          })
        } catch (toastError: any) {
          console.error('🔴 Erreur lors de l\'appel à toast.error():', toastError)
          showCustomNotification(`Erreur: ${errorMessage}`, 'error')
        }
      }
    } catch (error: any) {
      console.error('Erreur lors de la consolidation IEPP:', error)
      const errorMessage = error?.message || error?.toString() || 'Erreur inconnue lors de la consolidation IEPP'
      try {
        toast.error(`Erreur: ${errorMessage}`, {
          duration: 5000,
          position: 'top-right',
          style: {
            backgroundColor: '#fee2e2',
            color: '#991b1b',
            border: '1px solid #fca5a5',
          },
        })
      } catch (toastError: any) {
        console.error('🔴 Erreur lors de l\'appel à toast.error():', toastError)
        showCustomNotification(`Erreur: ${errorMessage}`, 'error')
      }
    }
  }

  // ✅ NOUVELLE FONCTION: Consolidation d'un besoin spécifique (pour le bouton dans la liste)
  const handleConsoliderBesoin = async (besoin: any) => {
    if (consultationOnly) {
      toast.error("Consolidation indisponible en mode consultation.")
      return
    }
    try {
      if (!user?.id || !user?.structure?.id) {
        toast.error('Utilisateur ou structure non trouvé')
        return
      }

      const rawData = besoin._rawData || besoin
      if (!rawData?.id) {
        toast.error('Besoin invalide')
        return
      }

      // Pour consolider un besoin spécifique, on doit consolider tous les besoins VALIDE de l'IEPP
      // Le backend gère la consolidation de tous les besoins EPP d'un IEPP
      const anneeScolaireId = rawData.anneeScolaireId

      if (!anneeScolaireId) {
        toast.error('Année scolaire non trouvée')
        return
      }

      const result = await besoinsService.consolidate(
        user.structure.id, // ieppId
        anneeScolaireId,
        user.id // consolidePar
      )
      
      // ✅ CORRECTION : Vérifier que result n'est pas null/undefined
      if (!result) {
        console.error('🔴 [HANDLER] result est null/undefined');
        const errorMessage = 'Erreur: Réponse invalide du serveur';
        try {
          toast.error(errorMessage, {
            duration: 5000,
            position: 'top-right',
            style: {
              backgroundColor: '#fee2e2',
              color: '#991b1b',
              border: '1px solid #fca5a5',
            },
          })
        } catch (toastError: any) {
          console.error('🔴 Erreur lors de l\'appel à toast.error():', toastError)
          showCustomNotification(errorMessage, 'error')
        }
        return
      }
      
      if (result.success) {
        try {
          toast.success(`✅ Consolidation IEPP réussie - ${result.data?.length || 0} besoin(s) consolidé(s)`, {
            duration: 5000,
            position: 'top-right',
            style: {
              backgroundColor: '#dcfce7',
              color: '#166534',
              border: '1px solid #86efac',
            },
          })
        } catch (toastError: any) {
          console.error('🔴 Erreur lors de l\'appel à toast.success():', toastError)
          showCustomNotification(`✅ Consolidation IEPP réussie - ${result.data?.length || 0} besoin(s) consolidé(s)`, 'success')
        }
        await loadBesoins() // Recharger les besoins
        // ✅ CORRECTION: Recharger aussi les consolidations pour DAF/ADMIN
        if (["DAF", "ADMIN", "DRENA"].includes(user?.role?.code || "")) {
          await loadConsolidations()
        }
      } else {
        const errorMessage = result.message || 'Erreur lors de la consolidation IEPP'
        try {
          toast.error(errorMessage, {
            duration: 5000,
            position: 'top-right',
            style: {
              backgroundColor: '#fee2e2',
              color: '#991b1b',
              border: '1px solid #fca5a5',
            },
          })
        } catch (toastError: any) {
          console.error('🔴 Erreur lors de l\'appel à toast.error():', toastError)
          showCustomNotification(`Erreur: ${errorMessage}`, 'error')
        }
      }
    } catch (error: any) {
      console.error('Erreur lors de la consolidation IEPP:', error)
      const errorMessage = error?.message || error?.toString() || 'Erreur inconnue lors de la consolidation IEPP'
      try {
        toast.error(`Erreur: ${errorMessage}`, {
          duration: 5000,
          position: 'top-right',
          style: {
            backgroundColor: '#fee2e2',
            color: '#991b1b',
            border: '1px solid #fca5a5',
          },
        })
      } catch (toastError: any) {
        console.error('🔴 Erreur lors de l\'appel à toast.error():', toastError)
        showCustomNotification(`Erreur: ${errorMessage}`, 'error')
      }
    }
  }

  const handleConsoliderDRENA = (consolidation: any) => {
    if (consultationOnly) {
      toast.error("Consolidation indisponible en mode consultation.")
      return
    }
    const updatedConsolidations = consolidationDRENA.map(c => 
      c.id === consolidation.id 
        ? { ...c, statut: "CONSOLIDE", date_consolidation: new Date().toISOString().split('T')[0] }
        : c
    )
    setConsolidationDRENA(updatedConsolidations)
    setCustomToast({ type: "success", message: "Consolidation DRENA effectuée avec succès" })
    setTimeout(() => setCustomToast(null), 3000)
  }

  const handleViewDetails = async (item: any, type: "iepp" | "drena") => {
    console.log('🔵 [VIEW-DETAILS] ========== handleViewDetails DÉBUT ==========')
    console.log('🔵 [VIEW-DETAILS] item:', JSON.stringify(item, null, 2))
    console.log('🔵 [VIEW-DETAILS] type:', type)
    console.log('🔵 [VIEW-DETAILS] typeof type:', typeof type)
    console.log('🔵 [VIEW-DETAILS] type === "iepp":', type === "iepp")
    console.log('🔵 [VIEW-DETAILS] user:', user)
    console.log('🔵 [VIEW-DETAILS] user?.structure:', user?.structure)
    console.log('🔵 [VIEW-DETAILS] user?.structure?.id:', user?.structure?.id)
    console.log('🔵 [VIEW-DETAILS] typeof user?.structure?.id:', typeof user?.structure?.id)
    console.log('🔵 [VIEW-DETAILS] Condition type === "iepp":', type === "iepp")
    console.log('🔵 [VIEW-DETAILS] Condition user?.structure?.id:', !!user?.structure?.id)
    console.log('🔵 [VIEW-DETAILS] Condition complète (type === "iepp" && user?.structure?.id):', type === "iepp" && user?.structure?.id)
    
    // Ouvrir le modal d'abord avec les données de base
    console.log('🔵 [VIEW-DETAILS] Ouverture du modal avec données temporaires...')
    setDetailsType(type)
    setSelectedDetails(item) // Données temporaires
    setExpandedBesoinIndices(new Set()) // Réinitialiser les dropdowns
    setShowDetailsModal(true)
    console.log('🟢 [VIEW-DETAILS] Modal ouvert')
    
    // ✅ Pour IEPP : récupérer les détails depuis le backend (item.id = IEPP structureId pour DRENA/DAF)
    const ieppIdToFetch = (type === "iepp" && item?.id) ? item.id : user?.structure?.id
    if (type === "iepp" && ieppIdToFetch) {
      console.log('🟢 [VIEW-DETAILS] ✅ Condition remplie : type === "iepp" && ieppIdToFetch')
      console.log('🔵 [VIEW-DETAILS] Entrée dans le bloc if pour charger les données backend')
      try {
        console.log('🔵 [VIEW-DETAILS] Appel backend pour récupérer les détails de consolidation IEPP')
        console.log('🔵 [VIEW-DETAILS] ieppId:', ieppIdToFetch)
        console.log('🔵 [VIEW-DETAILS] typeof besoinsService:', typeof besoinsService)
        console.log('🔵 [VIEW-DETAILS] typeof besoinsService.getConsolidationDetails:', typeof besoinsService.getConsolidationDetails)
        console.log('🔵 [VIEW-DETAILS] Appel besoinsService.getConsolidationDetails()...')
        const result = await besoinsService.getConsolidationDetails(ieppIdToFetch)
        console.log('🟢 [VIEW-DETAILS] ✅ Appel getConsolidationDetails terminé')
        
        console.log('🔵 [VIEW-DETAILS] Résultat reçu:', result)
        console.log('🔵 [VIEW-DETAILS] result.success:', result.success)
        console.log('🔵 [VIEW-DETAILS] result.data:', result.data)
        console.log('🔵 [VIEW-DETAILS] result.data?.length:', result.data?.length)
        
        if (result.success && result.data && result.data.length > 0) {
          console.log('🟢 [VIEW-DETAILS] Détails récupérés du backend:', result.data.length, 'besoins')
          
          // Transformer les données du backend en format attendu par le modal
          const eppDetails = result.data.map((besoin: any) => {
            console.log('🔵 [VIEW-DETAILS] Traitement besoin:', besoin.structureAdministrativeLibelle || besoin.structureLibelle)
            console.log('🔵 [VIEW-DETAILS] besoin.besoinDetails:', besoin.besoinDetails)
            console.log('🔵 [VIEW-DETAILS] besoin.besoinDetails?.length:', besoin.besoinDetails?.length)
            
            // Statut du besoin EPP (priorité au besoin chargé, pas à la ligne IEPP parente) — normalisé pour l’UI.
            const statutBesoin = String(besoin?.statut ?? item?.statut ?? "SAISI").toUpperCase()
            const isApprouve = ["APPROUVE", "VALIDE_NATIONAL", "VALIDE_DAF"].includes(statutBesoin)
            // Affichage cohérent métier:
            // - APPROUVE -> quantiteApprouvee (y compris 0) ; repli consolidé / net seulement si approuvée absente
            // - sinon    -> priorité quantiteConsolidee
            const qte = (d: any) => {
              if (isApprouve) {
                const qa = d.quantiteApprouvee ?? d.quantite_approuvee
                if (qa !== null && qa !== undefined && !Number.isNaN(Number(qa))) {
                  return Number(qa)
                }
                return Number(
                  d.quantiteConsolidee ??
                    d.quantite_consolidee ??
                    d.quantiteNet ??
                    d.quantite_net ??
                    d.quantiteBrute ??
                    d.quantite_brute ??
                    0,
                )
              }
              return Number(
                d.quantiteConsolidee ??
                  d.quantite_consolidee ??
                  d.quantiteApprouvee ??
                  d.quantite_approuvee ??
                  d.quantiteNet ??
                  d.quantite_net ??
                  d.quantiteBrute ??
                  d.quantite_brute ??
                  0,
              )
            }
            const manuels = besoin.besoinDetails?.reduce((sum: number, d: any) => sum + (qte(d) || 0), 0) || 0
            const matieres = besoin.besoinDetails?.map((detail: any) => {
              const quantiteConsolidee = detail.quantiteConsolidee ?? detail.quantite_consolidee
              const quantiteApprouveeRaw = detail.quantiteApprouvee ?? detail.quantite_approuvee
              const quantiteNetRaw = detail.quantiteNet ?? detail.quantite_net
              const quantiteBruteRaw = detail.quantiteBrute ?? detail.quantite_brute
              const brute = Number(quantiteBruteRaw ?? quantiteConsolidee ?? quantiteApprouveeRaw ?? 0)
              const nette = Number(quantiteNetRaw ?? quantiteConsolidee ?? quantiteApprouveeRaw ?? 0)
              const qaNum =
                quantiteApprouveeRaw !== null && quantiteApprouveeRaw !== undefined && !Number.isNaN(Number(quantiteApprouveeRaw))
                  ? Number(quantiteApprouveeRaw)
                  : undefined
              return {
                matiereLibelle: detail.matiereLibelle || detail.matiereCode || "",
                matiereCode: detail.matiereCode || "",
                niveauScolaireLibelle: detail.niveauScolaireLibelle || detail.niveauScolaireCode || "",
                niveauScolaireCode: detail.niveauScolaireCode || "",
                statutBesoin,
                quantiteConsolidee,
                quantiteApprouvee: qaNum,
                quantiteBrute: brute || nette,
                quantiteNet: nette || brute,
              }
            }) || []
            
            console.log('🔵 [VIEW-DETAILS] Manuels calculés:', manuels)
            console.log('🔵 [VIEW-DETAILS] Matières extraites:', matieres.length)
            
            return {
              epp: besoin.structureAdministrativeLibelle || besoin.structureLibelle || "EPP Non défini",
              effectifs: computeEffectifsFromBesoin(besoin, undefined, besoin.statut),
              manuels: manuels,
              statut: besoin.statut || "SAISI",
              matieres: matieres,
              rawData: besoin
            }
          })
          
          const totalEffectifs = eppDetails.reduce((sum, epp) => sum + epp.effectifs, 0)
          const totalManuels = eppDetails.reduce((sum, epp) => sum + epp.manuels, 0)
          
          // date_consolidation / dateApprobation pour APPROUVE
          const firstBesoin = result.data[0]
          const dateConsol = firstBesoin?.dateConsolidation ?? firstBesoin?.dateApprobation ?? item.date_consolidation
          
          console.log('🟢 [VIEW-DETAILS] Total effectifs:', totalEffectifs)
          console.log('🟢 [VIEW-DETAILS] Total manuels:', totalManuels)
          
          // Construire l'objet selectedDetails avec les données du backend
          const detailsWithBackendData = {
            ...item,
            besoins: eppDetails,
            epp_count: eppDetails.length,
            total_effectifs: totalEffectifs,
            total_manuels: totalManuels,
            date_consolidation: dateConsol ?? item.date_consolidation
          }
          
          console.log('🟢 [VIEW-DETAILS] Données préparées pour le modal:', JSON.stringify(detailsWithBackendData, null, 2))
          setSelectedDetails(detailsWithBackendData)
        } else {
          console.warn('🟡 [VIEW-DETAILS] Aucun détail trouvé ou erreur:', result.message)
          console.warn('🟡 [VIEW-DETAILS] result.data:', result.data)
          // Fallback : transformer item.besoins (raw) en format modal si présents
          let fallback = { ...item }
          if (item.besoins && Array.isArray(item.besoins) && item.besoins.length > 0) {
            const qte = (d: any) => d?.quantiteConsolidee ?? d?.quantiteApprouvee ?? d?.quantiteNet ?? d?.quantiteBrute ?? d?.quantite_brute ?? d?.quantite_net ?? 0
            const transformed = item.besoins.map((b: any) => {
              const raw = b._rawData ?? b
              const details = raw.besoinDetails ?? []
              const manuels = details.length > 0 ? details.reduce((s: number, d: any) => s + (qte(d) || 0), 0) : (raw.total_manuels ?? 0)
              const effectifs = computeEffectifsFromBesoin(raw, b.niveaux, b.statut)
              const matieres = (details || []).map((d: any) => ({
                matiereLibelle: d.matiereLibelle ?? d.matiereCode ?? "",
                matiereCode: d.matiereCode ?? "",
                niveauScolaireLibelle: d.niveauScolaireLibelle ?? d.niveauScolaireCode ?? "",
                niveauScolaireCode: d.niveauScolaireCode ?? "",
                quantiteBrute: qte(d),
                quantiteNet: qte(d)
              }))
              return {
                epp: raw.structureAdministrativeLibelle ?? raw.structureLibelle ?? b.structure?.libelle ?? "EPP",
                effectifs,
                manuels,
                statut: b.statut ?? raw.statut ?? "SAISI",
                matieres,
                rawData: raw
              }
            })
            fallback = {
              ...item,
              besoins: transformed,
              epp_count: transformed.length,
              total_effectifs: transformed.reduce((s: number, e: any) => s + (e.effectifs || 0), 0),
              total_manuels: transformed.reduce((s: number, e: any) => s + (e.manuels || 0), 0)
            }
          }
          setSelectedDetails(fallback)
        }
      } catch (error: any) {
        console.error('🔴 [VIEW-DETAILS] Erreur lors de la récupération des détails:', error)
        console.error('🔴 [VIEW-DETAILS] Error stack:', error.stack)
        // ✅ CORRECTION: Garder les données de l'item en cas d'erreur (pas de perte des besoins EPP)
        setSelectedDetails(item)
      }
    } else {
      console.log('🟡 [VIEW-DETAILS] ⚠️ Condition NON remplie - Pas de chargement backend')
      console.log('🟡 [VIEW-DETAILS] Raison:')
      console.log('🟡 [VIEW-DETAILS]   - type === "iepp" ?', type === "iepp")
      console.log('🟡 [VIEW-DETAILS]   - user?.structure?.id existe ?', !!user?.structure?.id)
      console.log('🟡 [VIEW-DETAILS]   - user?.structure?.id valeur:', user?.structure?.id)
      console.log('🟡 [VIEW-DETAILS] Utilisation des données de l\'item directement')
      // Pour DRENA ou autres types, utiliser les données de l'item directement
      setSelectedDetails(item)
    }
    
    console.log('🔵 [VIEW-DETAILS] ========== handleViewDetails FIN ==========')
  }

  // ✅ NOUVELLE FONCTION: Validation d'un besoin par le DIRECTEUR
  const handleValidateBesoin = async (besoin: any) => {
    if (consultationOnly) {
      toast.error("Validation indisponible en mode consultation.")
      return
    }
    console.log('🔵 [VALIDATE] ========== handleValidateBesoin DÉBUT ==========')
    console.log('🔵 [VALIDATE] besoin:', besoin)
    try {
      const rawData = besoin._rawData || besoin
      if (!rawData.id) {
        toast.error('Besoin invalide')
        return
      }

      if (!user?.id) {
        toast.error('Utilisateur non trouvé')
        return
      }

      const besoinData: BesoinData = {
        id: rawData.id,
        structureId: rawData.structureId || user?.structure?.id,
        niveauScolaireId: rawData.niveauScolaireId,
        anneeScolaireId: rawData.anneeScolaireId,
        effectifGarcons: rawData.effectifGarcons,
        effectifFilles: rawData.effectifFilles,
        effectifTotal: rawData.effectifTotal,
        statut: "VALIDE", // Changer le statut
        commentaire: rawData.commentaire,
      }

      // ✅ CORRECTION : Passer explicitement l'ID utilisateur comme dans les autres appels
      const token = typeof window !== 'undefined' ? localStorage.getItem('auth_token') : null
      
      console.log('🔵 [VALIDATE] Avant appel besoinsService.update()')
      console.log('🔵 [VALIDATE] besoinData:', JSON.stringify(besoinData, null, 2))
      console.log('🔵 [VALIDATE] user.id:', user.id)
      console.log('🔵 [VALIDATE] token présent:', !!token)
      
      let result: { success: boolean; data?: any; message: string } | null = null
      
      try {
        result = await besoinsService.update(besoinData, user.id, token || undefined)
      } catch (serviceError: any) {
        console.error('❌ [VALIDATE] Erreur dans le service:', serviceError)
        result = {
          success: false,
          message: serviceError?.message || serviceError?.toString() || 'Erreur lors de l\'appel au service'
        }
      }
      
      console.log('🔵 [VALIDATE] Après le try/catch interne')
      console.log('🔵 [VALIDATE] result:', result)
      console.log('🔵 [VALIDATE] !result:', !result)
      console.log('🔵 [VALIDATE] typeof result:', typeof result)
      console.log('🔵 [VALIDATE] typeof result !== "object":', typeof result !== "object")
      console.log('🔵 [VALIDATE] Condition (!result || typeof result !== "object"):', (!result || typeof result !== "object"))
      
      // ✅ CORRECTION : Vérifier que result est un objet valide avant d'accéder à ses propriétés
      if (!result || typeof result !== 'object') {
        console.error('🔴 [VALIDATE] Erreur: La réponse du service est invalide:', result)
        toast.error('Aucune réponse valide du serveur. Veuillez réessayer.')
        return
      }
      
      console.log('🟢 [VALIDATE] result est valide, vérification de result.success')
      const resultSuccess = result.success; // Accès sécurisé
      console.log('🟢 [VALIDATE] result.success récupéré:', resultSuccess)
      console.log('🟢 [VALIDATE] typeof result.success:', typeof resultSuccess)
      
      if (resultSuccess === true) {
        console.log('🟢 [VALIDATE] SUCCÈS - result.success === true')
        try {
          const structureLibelle = besoin.structure?.libelle || rawData.structureAdministrativeLibelle || 'le besoin'
          console.log('🟢 [VALIDATE] Avant toast.success()')
          console.log('🟢 [VALIDATE] toast (type):', typeof toast)
          console.log('🟢 [VALIDATE] toast:', toast)
          console.log('🟢 [VALIDATE] toast?.success (type):', typeof toast?.success)
          
          // ✅ CORRECTION : Utiliser directement toast de react-hot-toast (pas de vérification nécessaire)
          toast.success(`Expression de besoins validée pour ${structureLibelle}`)
          console.log('🟢 [VALIDATE] toast.success() appelé')
          
          console.log('🟢 [VALIDATE] Avant loadBesoins()')
          console.log('🟢 [VALIDATE] loadBesoins (type):', typeof loadBesoins)
          console.log('🟢 [VALIDATE] loadBesoins:', loadBesoins)
          
          // ✅ CORRECTION : Vérifier que loadBesoins est une fonction avant de l'appeler
          if (loadBesoins && typeof loadBesoins === 'function') {
            console.log('🟢 [VALIDATE] Appel de loadBesoins()...')
            try {
              await loadBesoins() // Recharger les besoins
              console.log('🟢 [VALIDATE] Besoins rechargés avec succès')
            } catch (loadBesoinsError: any) {
              console.error('🔴 [VALIDATE] Erreur dans loadBesoins()')
              console.error('🔴 [VALIDATE] loadBesoinsError (type):', typeof loadBesoinsError)
              console.error('🔴 [VALIDATE] loadBesoinsError (valeur):', loadBesoinsError)
              console.error('🔴 [VALIDATE] loadBesoinsError?.message:', loadBesoinsError?.message)
              console.error('🔴 [VALIDATE] loadBesoinsError?.stack:', loadBesoinsError?.stack)
              // Ne pas bloquer si le rechargement échoue
            }
          } else {
            console.error('🔴 [VALIDATE] loadBesoins n\'est pas une fonction')
            console.error('🔴 [VALIDATE] loadBesoins:', loadBesoins)
          }
        } catch (loadError: any) {
          console.error('🔴 [VALIDATE] Erreur lors du rechargement des besoins')
          console.error('🔴 [VALIDATE] loadError (type):', typeof loadError)
          console.error('🔴 [VALIDATE] loadError (valeur):', loadError)
          console.error('🔴 [VALIDATE] loadError?.message:', loadError?.message)
          console.error('🔴 [VALIDATE] loadError?.stack:', loadError?.stack)
          // Ne pas bloquer si le rechargement échoue
        }
      } else {
        console.log('🟡 [VALIDATE] ÉCHEC - result.success !== true')
        console.log('🟡 [VALIDATE] result.success:', resultSuccess)
        console.log('🟡 [VALIDATE] result.message:', result?.message)
        const errorMessage = result?.message || 'Erreur lors de la validation'
        toast.error(errorMessage)
      }
    } catch (error: any) {
      console.error('🔴 [VALIDATE] Erreur lors de la validation')
      console.error('🔴 [VALIDATE] error (type):', typeof error)
      console.error('🔴 [VALIDATE] error (valeur):', error)
      console.error('🔴 [VALIDATE] error (JSON):', JSON.stringify(error, null, 2))
      console.error('🔴 [VALIDATE] error?.message:', error?.message)
      console.error('🔴 [VALIDATE] error?.stack:', error?.stack)
      // ✅ CORRECTION : Gérer les erreurs de manière plus robuste
      const errorMessage = error?.message || error?.toString() || 'Erreur inconnue lors de la validation du besoin'
      toast.error(`Erreur: ${errorMessage}`)
    }
    console.log('🔵 [VALIDATE] handleValidateBesoin - FIN')
  }

  /** Renvoyer l'expression d'une EPP pour correction (avant consolidation) - IEPP uniquement */
  const handleRenvoyerPourCorrection = async (besoin: any) => {
    if (consultationOnly) {
      toast.error("Action indisponible en mode consultation.")
      return
    }
    const rawData = besoin.rawData || besoin
    const besoinId = rawData.id
    if (!besoinId) {
      toast.error('Besoin invalide')
      return
    }
    if (!user?.id) {
      toast.error('Utilisateur non trouvé')
      return
    }
    setRenvoyerLoading(besoinId)
    try {
      const token = typeof window !== 'undefined' ? localStorage.getItem('auth_token') : null
      const besoinData: BesoinData = {
        id: besoinId,
        structureId: rawData.structureId,
        niveauScolaireId: rawData.niveauScolaireId,
        anneeScolaireId: rawData.anneeScolaireId,
        effectifGarcons: rawData.effectifGarcons || 0,
        effectifFilles: rawData.effectifFilles || 0,
        effectifTotal: rawData.effectifTotal || 0,
        statut: 'SAISI', // Renvoyer en saisie pour correction
        commentaire: rawData.commentaire,
        besoinDetails: rawData.besoinDetails,
      }
      const result = await besoinsService.update(besoinData, user.id, token || undefined)
      if (result?.success) {
        toast.success(`Expression de ${besoin.epp} renvoyée pour correction`)
        setShowDetailsModal(false)
        await loadBesoins()
        if (shouldReloadConsolidationsAfterBesoinRenvoi(user?.role?.code, functionalityPermissions)) {
          await loadConsolidations()
        }
      } else {
        toast.error(result?.message || 'Erreur lors du renvoi')
      }
    } catch (err: any) {
      toast.error(err?.message || 'Erreur lors du renvoi pour correction')
    } finally {
      setRenvoyerLoading(null)
    }
  }

  // ✅ NOUVELLE FONCTION: Validation DAF d'un besoin consolidé (ouvre le modal)
  const handleValiderDAF = (besoinIds: number[] | any) => {
    if (consultationOnly) {
      toast.error("Approbation indisponible en mode consultation.")
      return
    }
      let ids: number[] = []
      // ✅ Groupe par IEPP : extraire tous les IDs des besoins du groupe
      if (typeof besoinIds === 'object' && Array.isArray(besoinIds.besoins) && besoinIds.besoins.length > 0) {
        ids = besoinIds.besoins
          .map((b: any) => b._rawData?.id ?? b.id)
          .filter((id: any) => id != null)
      } else if (Array.isArray(besoinIds)) {
        ids = besoinIds
      } else if (typeof besoinIds === 'object' && besoinIds.id) {
        ids = [besoinIds.id]
      } else if (typeof besoinIds === 'number') {
        ids = [besoinIds]
      } else {
        const rawData = besoinIds._rawData || besoinIds
        if (rawData?.id) ids = [rawData.id]
        else {
          toast.error('Besoin invalide')
          return
        }
      }

      if (ids.length === 0) {
        toast.error('Aucun besoin sélectionné')
        return
      }

    setBesoinsToApprove(ids)
    setShowApprouverModal(true)
  }

  // ✅ NOUVELLE FONCTION: Effectue l'approbation réelle (appelée depuis le modal)
  const handleApproveConfirm = async (tauxGlobal?: number, quantitesApprouvees?: Map<number, number>, exceptionsEpp?: Map<number, Map<string, number>>) => {
    if (consultationOnly) {
      toast.error("Approbation indisponible en mode consultation.")
      return
    }
    try {
      if (!user?.id) {
        toast.error('Utilisateur non trouvé')
        return
      }

      const token = typeof window !== 'undefined' ? localStorage.getItem('auth_token') : null
      
      console.log('🔵 [APPROVE-HANDLER] Avant appel service')
      let result: { success: boolean; data?: any[]; message: string } | null = null;
      
      try {
        result = await besoinsService.approve(
          besoinsToApprove, 
          user.id, 
          tauxGlobal, 
          quantitesApprouvees,
          exceptionsEpp,
          user.id, 
          token || undefined
        ) as { success: boolean; data?: any[]; message: string } | null;
      } catch (serviceError: any) {
        console.error('🔴 [APPROVE-HANDLER] Erreur lors de l\'appel au service:', serviceError);
        result = {
          success: false,
          message: serviceError?.message || 'Erreur lors de l\'appel au service d\'approbation',
        };
      }
      
      if (!result || result === null || result === undefined) {
        console.error('🔴 [APPROVE-HANDLER] result est null/undefined');
        toast.error('Erreur: Réponse invalide du serveur')
        return
      }
      
      if (result.success === true) {
        toast.success(`✅ ${besoinsToApprove.length} besoin(s) approuvé(s) par DAF - Prêt pour réception`)
        await loadBesoins() // Recharger les besoins
        if (["DAF", "ADMIN", "DRENA"].includes(user?.role?.code || "")) {
          await loadConsolidations()
        }
      } else {
        const errorMessage = result.message || 'Erreur lors de l\'approbation DAF'
        toast.error(errorMessage)
      }
    } catch (error: any) {
      console.error('🔴 Erreur lors de l\'approbation DAF:', error)
      const errorMessage = error?.message || error?.toString() || 'Erreur inconnue lors de l\'approbation DAF'
      toast.error(`Erreur: ${errorMessage}`)
    }
  }

  const collectConsolideBesoinIdsForExport = (): number[] => {
    const consolides = besoins.filter((b: any) => b.statut === "CONSOLIDE")
    return consolides
      .map((b: any) => b._rawData?.id ?? b.id)
      .filter((id: any) => id != null && Number(id) > 0) as number[]
  }

  const handleExportApprovalExcelAllConsolides = async () => {
    if (consultationOnly) {
      toast.error("Approbation indisponible en mode consultation.")
      return
    }
    const ids = collectConsolideBesoinIdsForExport()
    if (ids.length === 0) {
      toast.error("Aucun besoin consolidé à exporter.")
      return
    }
    try {
      await downloadApprobationTemplateFromBackend(ids)
      toast.success(
        `Modèle d’approbation téléchargé. Le serveur ne retient que les besoins IEPP consolidés parmi ${ids.length} id(s) envoyé(s).`,
      )
    } catch (e: unknown) {
      toast.error(e instanceof Error ? e.message : "Export impossible")
    }
  }

  const handleExportApprovalExcelForGroupe = async (groupe: {
    besoins: any[]
    statut?: string
  }) => {
    if (consultationOnly) {
      toast.error("Approbation indisponible en mode consultation.")
      return
    }
    if (groupe.statut !== "CONSOLIDE") {
      toast.error("Export réservé aux groupes encore consolidés.")
      return
    }
    const ids = groupe.besoins
      .map((b: any) => b._rawData?.id ?? b.id)
      .filter((id: any) => id != null && Number(id) > 0) as number[]
    if (ids.length === 0) {
      toast.error("Aucun identifiant de besoin dans ce groupe.")
      return
    }
    try {
      await downloadApprobationTemplateFromBackend(ids)
      toast.success("Modèle d’approbation téléchargé pour ce groupe IEPP.")
    } catch (e: unknown) {
      toast.error(e instanceof Error ? e.message : "Export impossible")
    }
  }

  const confirmPendingApprovalExcelImport = () => {
    const p = pendingApprovalExcelImport
    if (!p) return
    setBesoinsToApprove(p.besoinIds)
    setApprovalExcelPrefill(p.prefill)
    skipApprovalExcelDialogCloseToastRef.current = true
    setPendingApprovalExcelImport(null)
    setShowApprouverModal(true)
    toast.success(
      "Fichier analysé : le formulaire d’approbation s’ouvre avec les quantités validées par le serveur (certaines valeurs ont pu être ajustées).",
      { duration: 6000 },
    )
  }

  const handleApprovalExcelPickedFromValidationTab = async (e: ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0]
    e.target.value = ""
    if (!f) return
    if (consultationOnly) {
      toast.error("Approbation indisponible en mode consultation.")
      return
    }
    try {
      const r = await besoinsService.parseApprovalTemplateExcel(f, [])
      if (!r.success || !r.data) {
        toast.error(r.message || "Analyse du fichier impossible")
        return
      }
      const ids = (r.data.besoinIdsContext ?? []).filter((id) => typeof id === "number" && id > 0)
      if (ids.length === 0) {
        toast.error(
          "Aucun besoin reconnu. Téléchargez le modèle depuis DISMAS (colonne besoin_id) puis réimportez.",
        )
        return
      }
      const prefill: ApprobationExcelPrefill = {
        quantitesApprouvees: r.data.quantitesApprouvees ?? {},
        exceptionsEpp: r.data.exceptionsEpp ?? {},
      }
      const w = Array.isArray(r.data.warnings) ? r.data.warnings.filter(Boolean) : []
      if (w.length > 0) {
        setPendingApprovalExcelImport({ besoinIds: ids, prefill, warnings: w })
        return
      }
      setBesoinsToApprove(ids)
      setApprovalExcelPrefill(prefill)
      setShowApprouverModal(true)
      toast.success("Fichier analysé : le formulaire d’approbation s’ouvre avec les quantités du fichier.")
    } catch (err: unknown) {
      toast.error(err instanceof Error ? err.message : "Import impossible")
    }
  }

  // ✅ NOUVELLE FONCTION: Approuver tous les besoins consolidés (bouton en lot)
  const handleApprouverTous = () => {
    if (consultationOnly) {
      toast.error("Approbation indisponible en mode consultation.")
      return
    }
    // Récupérer tous les besoins avec statut CONSOLIDE
    const besoinsConsolides = besoins.filter(b => b.statut === "CONSOLIDE")
    
    if (besoinsConsolides.length === 0) {
      toast.error('Aucun besoin consolidé à approuver')
      return
    }

    // Extraire les IDs
    const ids = besoinsConsolides
      .map(b => b._rawData?.id || b.id)
      .filter(id => id != null) as number[]

    if (ids.length === 0) {
      toast.error('Aucun ID de besoin valide trouvé')
      return
    }

    // Ouvrir le modal d'approbation avec tous les IDs
    handleValiderDAF(ids)
  }

  // ✅ ANCIENNE FONCTION (désactivée - remplacée par le modal)
  const handleApprouverTous_OLD = async () => {
    try {
      if (!user?.id) {
        toast.error('Utilisateur non trouvé')
        return
      }

      // Récupérer tous les besoins avec statut CONSOLIDE
      const besoinsConsolides = besoins.filter(b => b.statut === "CONSOLIDE")
      
      if (besoinsConsolides.length === 0) {
        toast.error('Aucun besoin consolidé à approuver')
        return
      }

      // Extraire les IDs
      const ids = besoinsConsolides
        .map(b => b._rawData?.id || b.id)
        .filter(id => id != null) as number[]

      if (ids.length === 0) {
        toast.error('Aucun ID de besoin valide trouvé')
        return
      }

      // ✅ CORRECTION: Passer explicitement userId et token comme dans les autres appels
      const token = typeof window !== 'undefined' ? localStorage.getItem('auth_token') : null
      
      console.log('🔵 [APPROVE-ALL-HANDLER] Avant appel service')
      let result: { success: boolean; data?: any[]; message: string } | null = null;
      
      try {
        result = await besoinsService.approve(ids, user.id, undefined, undefined, undefined, user.id, token || undefined) as { success: boolean; data?: any[]; message: string } | null;
      } catch (serviceError: any) {
        console.error('🔴 [APPROVE-ALL-HANDLER] Erreur lors de l\'appel au service:', serviceError);
        result = {
          success: false,
          message: serviceError?.message || 'Erreur lors de l\'appel au service d\'approbation',
        };
      }
      
      console.log('🔵 [APPROVE-ALL-HANDLER] Résultat reçu du service');
      console.log('🔵 [APPROVE-ALL-HANDLER] result (type):', typeof result);
      console.log('🔵 [APPROVE-ALL-HANDLER] result (valeur):', result);
      console.log('🔵 [APPROVE-ALL-HANDLER] result === null:', result === null);
      console.log('🔵 [APPROVE-ALL-HANDLER] result === undefined:', result === undefined);
      
      // ✅ CORRECTION : Vérifier que result n'est pas null/undefined
      if (!result || result === null || result === undefined) {
        console.error('🔴 [APPROVE-ALL-HANDLER] result est null/undefined');
        const errorMessage = 'Erreur: Réponse invalide du serveur';
        try {
          toast.error(errorMessage, {
            duration: 5000,
            position: 'top-right',
            style: {
              backgroundColor: '#fee2e2',
              color: '#991b1b',
              border: '1px solid #fca5a5',
            },
          })
        } catch (toastError: any) {
          console.error('🔴 Erreur lors de l\'appel à toast.error():', toastError)
          showCustomNotification(errorMessage, 'error')
        }
        return
      }
      
      // ✅ CORRECTION : Accès sécurisé à result.success avec optional chaining
      const resultSuccess = result?.success;
      console.log('🔵 [APPROVE-ALL-HANDLER] result.success:', resultSuccess);
      console.log('🔵 [APPROVE-ALL-HANDLER] typeof result.success:', typeof resultSuccess);
      
      if (resultSuccess === true) {
        toast.success(`✅ ${ids.length} besoin(s) approuvé(s) par DAF - Prêt pour réception`)
        await loadBesoins() // Recharger les besoins
        // ✅ CORRECTION: Recharger aussi les consolidations pour DAF/ADMIN
        if (["DAF", "ADMIN", "DRENA"].includes(user?.role?.code || "")) {
          await loadConsolidations()
        }
      } else {
        const errorMessage = result.message || 'Erreur lors de l\'approbation DAF'
        try {
          toast.error(errorMessage, {
            duration: 5000,
            position: 'top-right',
            style: {
              backgroundColor: '#fee2e2',
              color: '#991b1b',
              border: '1px solid #fca5a5',
            },
          })
        } catch (toastError: any) {
          console.error('🔴 Erreur lors de l\'appel à toast.error():', toastError)
          showCustomNotification(`Erreur: ${errorMessage}`, 'error')
        }
      }
    } catch (error: any) {
      console.error('🔴 Erreur lors de l\'approbation DAF:', error)
      const errorMessage = error?.message || error?.toString() || 'Erreur inconnue lors de l\'approbation DAF'
      try {
        toast.error(`Erreur: ${errorMessage}`, {
          duration: 5000,
          position: 'top-right',
          style: {
            backgroundColor: '#fee2e2',
            color: '#991b1b',
            border: '1px solid #fca5a5',
          },
        })
      } catch (toastError: any) {
        console.error('🔴 Erreur lors de l\'appel à toast.error() dans le catch:', toastError)
        showCustomNotification(`Erreur: ${errorMessage}`, 'error')
      }
    }
  }

  // 🏢 NOUVELLE FONCTION: Consolidation DAF par DRENA
  const handleConsolidationDAFParDRENA = (drenaCode: string) => {
    let besoinsConsolides
    if (drenaCode === "TOUTES") {
      besoinsConsolides = besoins.filter(b => b.statut === "CONSOLIDE")
    } else {
      besoinsConsolides = besoins.filter(b => 
        b.statut === "CONSOLIDE" && 
        b.structure.code.includes(drenaCode.split("-")[1]) // Ex: "ABJ" de "DRENA-ABJ"
      )
    }
    
    if (besoinsConsolides.length === 0) {
      setCustomToast({ 
        type: "error", 
        message: `Aucun besoin consolidé pour ${drenaCode}` 
      })
      setTimeout(() => setCustomToast(null), 3000)
      return
    }

    const updatedBesoins = besoins.map(b => 
      besoinsConsolides.includes(b)
        ? { 
            ...b, 
            statut: "CONSOLIDE_DAF", 
            date_consolidation_daf: new Date().toISOString().split('T')[0],
            consolidé_par_daf: user.nom + " " + user.prenoms,
            drena_rattachee: drenaCode
          }
        : b
    )
    
    setBesoins(updatedBesoins)
    setCustomToast({ 
      type: "success", 
      message: drenaCode === "TOUTES" 
        ? `🏢 TOUTES DRENA : ${besoinsConsolides.length} IEPP consolidées par DAF`
        : `🏢 ${drenaCode} : ${besoinsConsolides.length} IEPP consolidées par DAF`
    })
    setTimeout(() => setCustomToast(null), 3000)
  }

  // 🎯 NOUVELLE FONCTION: Validation nationale finale - toutes les DRENA en lot
  const handleValidationNationaleFinale = () => {
    const besoinsConsolidesDaf = besoins.filter(b => b.statut === "CONSOLIDE_DAF")
    
    if (besoinsConsolidesDaf.length === 0) {
      setCustomToast({ 
        type: "error", 
        message: "Aucune consolidation DAF à valider. Consolidez d'abord par DRENA." 
      })
      setTimeout(() => setCustomToast(null), 3000)
      return
    }

    const updatedBesoins = besoins.map(b => 
      b.statut === "CONSOLIDE_DAF" 
        ? { 
            ...b, 
            statut: "VALIDE_NATIONAL", 
            date_validation_nationale: new Date().toISOString().split('T')[0],
            validé_par: user.nom + " " + user.prenoms
          }
        : b
    )
    
    setBesoins(updatedBesoins)
    setCustomToast({ 
      type: "success", 
      message: `🇨🇮 VALIDATION NATIONALE : ${besoinsConsolidesDaf.length} consolidations DAF validées pour toute la Côte d'Ivoire !` 
    })
    setTimeout(() => setCustomToast(null), 5000)
  }

  // 📊 FONCTION: Statistiques nationales agrégées
  const getStatsNationales = () => {
    // Simulation de 5000+ IEPP pour demo
    const besoinsConsolides = besoins.filter(b => b.statut === "CONSOLIDE")
    const besoinsValides = besoins.filter(b => b.statut === "VALIDE_DAF")
    
    return {
      total_iepp: 5234, // Simulation nationale
      iepp_consolides: besoinsConsolides.length + 4821, // Simulation + données réelles
      iepp_validees: besoinsValides.length + 3456, // Simulation
      total_effectifs: 2847362, // Simulation nationale
      total_manuels: 8542086 // Simulation nationale
    }
  }

  // 🗺️ FONCTION: Répartition par DRENA pour vue nationale
  const getRepartitionParDRENA = () => {
    return [
      {
        nom: "DRENA Abidjan",
        code: "DRENA-ABJ",
        iepp_count: 523,
        iepp_consolides: 487,
        effectifs: 284736,
        manuels: 854209
      },
      {
        nom: "DRENA Bouaké",
        code: "DRENA-BKE", 
        iepp_count: 431,
        iepp_consolides: 398,
        effectifs: 197634,
        manuels: 592902
      },
      {
        nom: "DRENA San Pedro",
        code: "DRENA-SPE",
        iepp_count: 387,
        iepp_consolides: 352,
        effectifs: 156429,
        manuels: 469287
      },
      {
        nom: "DRENA Yamoussoukro",
        code: "DRENA-YAM",
        iepp_count: 298,
        iepp_consolides: 267,
        effectifs: 123847,
        manuels: 371541
      },
      {
        nom: "DRENA Korhogo",
        code: "DRENA-KOR",
        iepp_count: 445,
        iepp_consolides: 401,
        effectifs: 189372,
        manuels: 568116
      },
      {
        nom: "DRENA Daloa",
        code: "DRENA-DAL",
        iepp_count: 392,
        iepp_consolides: 356,
        effectifs: 167823,
        manuels: 503469
      },
      {
        nom: "DRENA Gagnoa",
        code: "DRENA-GAG",
        iepp_count: 334,
        iepp_consolides: 298,
        effectifs: 143926,
        manuels: 431778
      },
      {
        nom: "DRENA Bondoukou",
        code: "DRENA-BON",
        iepp_count: 267,
        iepp_consolides: 231,
        effectifs: 112847,
        manuels: 338541
      },
      {
        nom: "DRENA Adzopé",
        code: "DRENA-ADZ",
        iepp_count: 245,
        iepp_consolides: 218,
        effectifs: 98372,
        manuels: 295116
      }
    ]
  }

  // ✅ FONCTION: Obtenir la consolidation IEPP basée sur les besoins validés
  const getConsolidationIEPPByRole = () => {
    console.log('🔵 [GET-CONSOLIDATION] getConsolidationIEPPByRole() appelé')
    
    if (canUseIeppTerritoryConsolidationDataset(user.role.code, functionalityPermissions)) {
      console.log('🔵 [GET-CONSOLIDATION] Périmètre consolidation territoire IEPP')
      
      // Besoins des EPP de la circonscription (exclure les lignes besoin au niveau IEPP déjà agrégées)
      const besoinsEppValides = getBesoinsByRole().filter(b => {
        const raw = b._rawData
        if (!raw || besoinRawIsIepp(raw)) return false
        return ["SAISI", "VALIDE", "CONSOLIDE", "APPROUVE"].includes(b.statut)
      })

      const ieppStructureId = user.structure?.id ?? (user as any).iepp?.id
      // Besoins IEPP consolidés ou approuvés (structure du besoin = IEPP)
      const besoinsIeppConsolides = besoins.filter(b => {
        const raw = b._rawData
        if (!raw) return false
        return (
          (b.statut === "CONSOLIDE" || b.statut === "APPROUVE") &&
          sameStructureId(raw.structureId, ieppStructureId) &&
          besoinRawIsIepp(raw)
        )
      })

      const consolidationRowId =
        ieppStructureId ??
        besoinsIeppConsolides[0]?._rawData?.structureId ??
        besoinsEppValides[0]?._rawData?.structureParentId ??
        (user as any).structureId ??
        (user as any).structure?.id
      
      console.log('🔵 [GET-CONSOLIDATION] besoinsEppValides.length:', besoinsEppValides.length)
      console.log('🔵 [GET-CONSOLIDATION] besoinsIeppConsolides.length:', besoinsIeppConsolides.length)

      // Pas de besoin EPP (valide/consolidé/approuvé) ni de besoin IEPP consolidé : pas de ligne factice
      if (besoinsEppValides.length === 0 && besoinsIeppConsolides.length === 0) {
        return []
      }

      // Pour IEPP: créer une consolidation dynamique avec les EPP (validées, consolidées ou approuvées)
      const eppDetails = besoinsEppValides.map(besoin => {
        const rawData = besoin._rawData || besoin
        console.log('🔵 [CONSOLIDATION] Traitement besoin EPP:', besoin.structure.libelle)
        console.log('🔵 [CONSOLIDATION] rawData.besoinDetails:', rawData.besoinDetails)
        console.log('🔵 [CONSOLIDATION] besoin.niveaux:', besoin.niveaux)
        
        // ✅ CORRECTION: Extraire effectifs - priorité effectifTotal, puis somme besoinDetails, puis niveaux
        const effectifs = computeEffectifsFromBesoin(rawData, besoin.niveaux, besoin.statut)

        // ✅ CORRECTION: Extraire manuels - chaîne de fallback quantiteConsolidee > quantiteApprouvee > quantiteNet > quantiteBrute
        const qManuels = (d: any) => d.quantiteConsolidee ?? d.quantiteApprouvee ?? d.quantiteNet ?? d.quantiteBrute ?? d.quantite_brute ?? d.quantite_net ?? 0
        const manuels = rawData.besoinDetails?.reduce((sum: number, d: any) => sum + qManuels(d), 0) || 
          besoin.total_manuels || 0
        
        // Récupérer les matières et quantités depuis besoinDetails ou niveaux
        let matieres: any[] = []
        if (rawData.besoinDetails && rawData.besoinDetails.length > 0) {
          console.log('🔵 [CONSOLIDATION] Utilisation de rawData.besoinDetails')
          const qVal = (d: any) => d.quantiteConsolidee ?? d.quantiteApprouvee ?? d.quantiteNet ?? d.quantiteBrute ?? d.quantite_brute ?? d.quantite_net ?? 0
          matieres = rawData.besoinDetails.map((detail: any) => {
            const q = qVal(detail)
            return {
              matiereLibelle: detail.matiereLibelle || detail.matiereCode || "",
              matiereCode: detail.matiereCode || "",
              niveauScolaireLibelle: detail.niveauScolaireLibelle || detail.niveauScolaireCode || "",
              niveauScolaireCode: detail.niveauScolaireCode || "",
              quantiteBrute: q || 0,
              quantiteNet: q || 0
            }
          })
        } else if (besoin.niveaux && besoin.niveaux.length > 0 && besoin.niveaux[0].manuels) {
          console.log('🔵 [CONSOLIDATION] Utilisation de niveaux[0].manuels')
          const niv = besoin.niveaux[0]
          matieres = (niv.manuels || []).map((m: any) => ({
            matiereLibelle: m.titre || m.matiereLibelle || "",
            matiereCode: m.matiereCode || "",
            niveauScolaireLibelle: niv.niveau || niv.niveauScolaireLibelle || "",
            niveauScolaireCode: niv.niveau || niv.niveauScolaireCode || "",
            quantiteBrute: m.quantite ?? m.quantiteBrute ?? m.besoin_net ?? m.quantiteNet ?? 0,
            quantiteNet: m.besoin_net ?? m.quantiteNet ?? m.quantite ?? m.quantiteBrute ?? 0
          }))
        }
        
        console.log('🔵 [CONSOLIDATION] Matières extraites:', matieres.length, matieres)
        console.log('🔵 [CONSOLIDATION] Effectifs calculés:', effectifs)
        console.log('🔵 [CONSOLIDATION] Manuels calculés:', manuels)
        
        return {
          epp: rawData.structureAdministrativeLibelle || besoin.structure?.libelle || "EPP Non défini",
          effectifs: effectifs,
          manuels: manuels,
          statut: besoin.statut,
          matieres: matieres,
          rawData: rawData
        }
      })

      const totalEffectifs = eppDetails.reduce((sum, epp) => sum + (epp.effectifs || 0), 0)
      const totalManuels = eppDetails.reduce((sum, epp) => sum + (epp.manuels || 0), 0)

      // ✅ Déterminer le statut : APPROUVE > CONSOLIDE > VALIDE (une fois approuvé, plus de consolidation possible)
      const aDesBesoinsApprouves = besoinsEppValides.some(b => b.statut === "APPROUVE") || besoinsIeppConsolides.some((b: any) => b.statut === "APPROUVE")
      const tousEppConsolides = besoinsEppValides.length > 0 && 
        besoinsEppValides.every(b => b.statut === "CONSOLIDE" || b.statut === "APPROUVE")
      const aDesBesoinsIeppConsolides = besoinsIeppConsolides.length > 0
      
      let statutFinal = "EN_COURS"
      if (aDesBesoinsApprouves) {
        statutFinal = "APPROUVE"
      } else if (tousEppConsolides || aDesBesoinsIeppConsolides) {
        statutFinal = "CONSOLIDE"
      } else if (besoinsEppValides.length > 0) {
        const anySaisi = besoinsEppValides.some(b => b.statut === "SAISI" || b.statut === "BROUILLON")
        const anyValide = besoinsEppValides.some(b => b.statut === "VALIDE")
        statutFinal = anyValide && !anySaisi ? "VALIDE" : "EN_COURS"
      }
      
      // ✅ Date de consolidation ou d'approbation
      const dateConsolidation = besoinsIeppConsolides.length > 0 
        ? (besoinsIeppConsolides[0]._rawData?.dateConsolidation ?? besoinsIeppConsolides[0]._rawData?.dateApprobation ?? new Date().toISOString().split('T')[0])
        : besoinsEppValides.some(b => b.statut === "CONSOLIDE" || b.statut === "APPROUVE")
          ? (besoinsEppValides.find(b => b.statut === "CONSOLIDE" || b.statut === "APPROUVE")?._rawData?.dateConsolidation ?? besoinsEppValides.find(b => b.statut === "APPROUVE")?._rawData?.dateApprobation ?? new Date().toISOString().split('T')[0])
          : null

      // Libellé IEPP affiché : on s'appuie uniquement sur les champs réellement présents à l'exécution
      const ieppLibelle =
        // Forme éventuelle renvoyée par l'API (user.iepp.libelle)
        (user as any).iepp?.libelle
        // Libellé IEPP « plat » si présent sur l'objet user
        ?? (user as any).ieppLibelle
        // Libellé renvoyé par l'API besoins IEPP
        ?? besoinsIeppConsolides[0]?._rawData?.structureAdministrativeLibelle
        // Libellé de la structure portée par la session (forme imbriquée ou plate)
        ?? (user as any).structure?.libelle
        ?? (user as any).structureLibelle
        // Valeur de secours
        ?? "IEPP Non défini"

      // Retourner format compatible avec le modal
      const result = [{
        id: consolidationRowId,
        iepp: ieppLibelle,
        drena: (user as any).drena?.libelle ?? (user as any).drenaLibelle ?? "DRENA",
        statut: statutFinal,
        date_consolidation: dateConsolidation,
        epp_count: eppDetails.length,
        total_effectifs: totalEffectifs,
        total_manuels: totalManuels,
        besoins: eppDetails // ✅ CORRECTION: Ajouter la propriété besoins attendue par le modal
      }]
      console.log('🔵 [GET-CONSOLIDATION] Résultat retourné:', JSON.stringify(result, null, 2))
      console.log('🔵 [GET-CONSOLIDATION] result[0].besoins.length:', result[0].besoins.length)
      console.log('🔵 [GET-CONSOLIDATION] Statut final:', statutFinal)
      return result
    } else {
      // Pour autres rôles: afficher consolidation globale
      return consolidationIEPP
    }
  }

  // ✅ Fonction de notification personnalisée stylée (fallback si toast ne fonctionne pas)
  const showCustomNotification = (message: string, type: 'error' | 'success' | 'info' = 'error') => {
    if (typeof window === 'undefined') return
    
    const colors = {
      error: {
        bg: '#fee2e2',
        border: '#fca5a5',
        text: '#991b1b',
        icon: '❌'
      },
      success: {
        bg: '#d1fae5',
        border: '#6ee7b7',
        text: '#065f46',
        icon: '✅'
      },
      info: {
        bg: '#dbeafe',
        border: '#93c5fd',
        text: '#1e40af',
        icon: 'ℹ️'
      }
    }
    
    const color = colors[type]
    const notification = document.createElement('div')
    notification.style.cssText = `
      position: fixed;
      top: 20px;
      right: 20px;
      background: ${color.bg};
      color: ${color.text};
      border: 2px solid ${color.border};
      border-radius: 12px;
      padding: 16px 20px;
      font-size: 14px;
      font-weight: 500;
      box-shadow: 0 10px 25px rgba(0, 0, 0, 0.15);
      z-index: 10000;
      display: flex;
      align-items: center;
      gap: 12px;
      min-width: 300px;
      max-width: 500px;
      animation: slideIn 0.3s ease-out;
    `
    
    // Ajouter l'animation CSS si elle n'existe pas déjà
    if (!document.getElementById('notification-styles')) {
      const style = document.createElement('style')
      style.id = 'notification-styles'
      style.textContent = `
        @keyframes slideIn {
          from {
            transform: translateX(400px);
            opacity: 0;
          }
          to {
            transform: translateX(0);
            opacity: 1;
          }
        }
        @keyframes slideOut {
          from {
            transform: translateX(0);
            opacity: 1;
          }
          to {
            transform: translateX(400px);
            opacity: 0;
          }
        }
      `
      document.head.appendChild(style)
    }
    
    notification.innerHTML = `
      <span style="font-size: 20px;">${color.icon}</span>
      <span style="flex: 1;">${message}</span>
      <button style="
        background: transparent;
        border: none;
        color: ${color.text};
        cursor: pointer;
        font-size: 20px;
        padding: 0;
        width: 24px;
        height: 24px;
        display: flex;
        align-items: center;
        justify-content: center;
        opacity: 0.7;
        transition: opacity 0.2s;
      " onmouseover="this.style.opacity='1'" onmouseout="this.style.opacity='0.7'" onclick="this.parentElement.remove()">×</button>
    `
    
    document.body.appendChild(notification)
    
    // Auto-suppression après 5 secondes
    setTimeout(() => {
      notification.style.animation = 'slideOut 0.3s ease-out'
      setTimeout(() => {
        if (notification.parentElement) {
          notification.remove()
        }
      }, 300)
    }, 5000)
  }

  // ✅ NOUVEAU : Gestion de la soumission du formulaire BesoinForm
  const handleBesoinFormSubmit = async (besoinData: BesoinData | BesoinData[]) => {
    if (consultationOnly) {
      toast.error("Enregistrement indisponible en mode consultation.")
      return
    }
    // Vérifier que l'utilisateur est connecté
    if (!user) {
      toast.error('Utilisateur non connecté. Veuillez vous reconnecter.')
      return
    }

    // Récupérer le token depuis localStorage
    const token = typeof window !== 'undefined' ? localStorage.getItem('auth_token') : null
    if (!token) {
      toast.error('Token d\'authentification manquant. Veuillez vous reconnecter.')
      return
    }

    try {
      console.log('🔵 [HANDLER] handleBesoinFormSubmit - DÉBUT du try')
      
      // ✅ MODIFIÉ : Le formulaire envoie maintenant toujours un seul besoin (comme les réceptions)
      // Gérer le cas d'un tableau (pour compatibilité) ou d'un objet unique
      const besoinUnique = Array.isArray(besoinData) ? besoinData[0] : besoinData

      // Règle métier: création autorisée uniquement sur l'année scolaire courante.
      if (!besoinToEdit?.id) {
        const anneeCourante = (anneesScolaires || []).find((a: any) => a?.estCourante === true)
        const anneeCouranteId = anneeCourante?.id
        if (anneeCouranteId && besoinUnique?.anneeScolaireId !== anneeCouranteId) {
          toast.error("Création refusée: vous devez sélectionner l'année scolaire courante.")
          return
        }
      }
      
      // Si un tableau est reçu avec plusieurs éléments, on ne prend que le premier
      if (Array.isArray(besoinData) && besoinData.length > 1) {
        console.warn('⚠️ [HANDLER] Tableau de besoins reçu, seul le premier sera traité')
      }
      let result: { success: boolean; data?: any; message: string } | null = null
      
      console.log('🔵 [HANDLER] Avant appel au service')
      console.log('🔵 [HANDLER] besoinToEdit?.id:', besoinToEdit?.id)
      
      try {
        if (besoinToEdit?.id) {
          console.log('🔵 [HANDLER] Appel besoinsService.update()')
          // Mise à jour
          result = await besoinsService.update({ ...besoinUnique, id: besoinToEdit.id }, user.id, token)
          console.log('🟢 [HANDLER] Après besoinsService.update()')
        } else {
          console.log('🔵 [HANDLER] Appel besoinsService.create()')
          // Création
          result = await besoinsService.create(besoinUnique, user.id, token)
          console.log('🟢 [HANDLER] Après besoinsService.create()')
        }
        
        console.log('🟢 [HANDLER] Résultat reçu du service')
        console.log('🟢 [HANDLER] result (type):', typeof result)
        console.log('🟢 [HANDLER] result (valeur):', result)
        console.log('🟢 [HANDLER] result === null:', result === null)
        console.log('🟢 [HANDLER] result === undefined:', result === undefined)
        console.log('🟢 [HANDLER] result (JSON):', result ? JSON.stringify(result, null, 2) : 'null/undefined')
        
      } catch (serviceError: any) {
        console.error('🔴 [HANDLER] Erreur dans le service (catch interne)')
        console.error('🔴 [HANDLER] serviceError (type):', typeof serviceError)
        console.error('🔴 [HANDLER] serviceError (valeur):', serviceError)
        console.error('🔴 [HANDLER] serviceError (JSON):', JSON.stringify(serviceError, null, 2))
        // ✅ CORRECTION : S'assurer que result est défini même en cas d'erreur
        result = {
          success: false,
          message: serviceError?.message || serviceError?.toString() || 'Erreur lors de l\'appel au service'
        }
        console.log('🟡 [HANDLER] result défini après catch:', result)
      }

      console.log('🔵 [HANDLER] Après le try/catch interne')
      console.log('🔵 [HANDLER] result:', result)
      console.log('🔵 [HANDLER] !result:', !result)
      console.log('🔵 [HANDLER] typeof result:', typeof result)
      console.log('🔵 [HANDLER] typeof result !== "object":', typeof result !== 'object')
      console.log('🔵 [HANDLER] Condition (!result || typeof result !== "object"):', (!result || typeof result !== 'object'))

      // ✅ CORRECTION : Vérification robuste que result n'est pas null
      if (!result || typeof result !== 'object') {
        console.error('🔴 [HANDLER] Erreur: La réponse du service est invalide')
        console.error('🔴 [HANDLER] result:', result)
        console.error('🔴 [HANDLER] typeof result:', typeof result)
        toast.error('Aucune réponse valide du serveur. Veuillez réessayer.')
        return
      }

      console.log('🟢 [HANDLER] result est valide, vérification de result.success')
      
      // ✅ CORRECTION : Vérification supplémentaire avant d'accéder à result.success
      let resultSuccess: boolean | undefined = undefined
      try {
        resultSuccess = result?.success
        console.log('🟢 [HANDLER] result.success récupéré:', resultSuccess)
        console.log('🟢 [HANDLER] typeof result.success:', typeof resultSuccess)
      } catch (accessError: any) {
        console.error('🔴 [HANDLER] Erreur lors de l\'accès à result.success:', accessError)
        console.error('🔴 [HANDLER] result à ce moment:', result)
        toast.error('Erreur lors de la lecture de la réponse du serveur')
        return
      }
      
      console.log('🟢 [HANDLER] result.success === true:', resultSuccess === true)

      // ✅ CORRECTION : Vérification que result.success existe
      if (resultSuccess === true) {
        console.log('🟢 [HANDLER] SUCCÈS - result.success === true')
        try {
          console.log('🟢 [HANDLER] Avant toast.success()')
          console.log('🟢 [HANDLER] toast:', typeof toast)
          console.log('🟢 [HANDLER] toast.success:', typeof toast?.success)
          
          // ✅ CORRECTION : Utiliser directement toast de react-hot-toast (pas de vérification nécessaire)
          toast.success(besoinToEdit ? 'Besoin modifié avec succès' : 'Besoin créé avec succès')
          console.log('🟢 [HANDLER] toast.success() appelé')
          
          console.log('🟢 [HANDLER] Avant setShowBesoinForm(false)')
          setShowBesoinForm(false)
          console.log('🟢 [HANDLER] Avant setBesoinToEdit(null)')
          setBesoinToEdit(null)

          console.log('🟢 [HANDLER] Avant loadBesoins()')
          console.log('🟢 [HANDLER] loadBesoins (type):', typeof loadBesoins)
          console.log('🟢 [HANDLER] loadBesoins:', loadBesoins)

          // Recharger la liste avant navigation pour éviter une course (liste figée sur anciennes quantités)
          if (loadBesoins && typeof loadBesoins === 'function') {
            console.log('🟢 [HANDLER] Appel de loadBesoins()...')
            await loadBesoins()
            console.log('🟢 [HANDLER] Besoins rechargés')
          } else {
            console.error('🔴 [HANDLER] loadBesoins n\'est pas une fonction')
            console.error('🔴 [HANDLER] loadBesoins:', loadBesoins)
          }

          console.log('🟢 [HANDLER] Redirection onglet saisie')
          router.push("/besoins?tab=saisie")
        } catch (loadError: any) {
          console.error('🔴 [HANDLER] Erreur lors du rechargement des besoins')
          console.error('🔴 [HANDLER] loadError (type):', typeof loadError)
          console.error('🔴 [HANDLER] loadError (valeur):', loadError)
          console.error('🔴 [HANDLER] loadError (JSON):', JSON.stringify(loadError, null, 2))
          console.error('🔴 [HANDLER] loadError?.message:', loadError?.message)
          console.error('🔴 [HANDLER] loadError?.stack:', loadError?.stack)
          // Ne pas bloquer si le rechargement échoue
        }
      } else {
        console.log('🟡 [HANDLER] ÉCHEC - result.success !== true')
        console.log('🟡 [HANDLER] result.success:', resultSuccess)
        console.log('🟡 [HANDLER] result.message:', result?.message)
        const errorMessage = result?.message || 'Erreur lors de l\'enregistrement'
        console.log('🟡 [HANDLER] Message d\'erreur à afficher:', errorMessage)
        
        // ✅ Affichage du message d'erreur avec toast
        try {
          toast.error(errorMessage, {
            duration: 5000,
            position: 'top-right',
            style: {
              background: '#fee2e2',
              color: '#991b1b',
              border: '1px solid #fca5a5',
              borderRadius: '8px',
              padding: '16px',
              fontSize: '14px',
              fontWeight: '500',
            },
            iconTheme: {
              primary: '#dc2626',
              secondary: '#fee2e2',
            },
          })
        } catch (toastError: any) {
          console.error('🔴 [HANDLER] Erreur lors de l\'appel à toast.error():', toastError)
          // Fallback : notification personnalisée stylée
          showCustomNotification(errorMessage, 'error')
        }
      }
      
      console.log('🟢 [HANDLER] Fin du try principal')
    } catch (error: any) {
      console.error('🔴 [HANDLER] Erreur dans le catch externe')
      console.error('🔴 [HANDLER] error (type):', typeof error)
      console.error('🔴 [HANDLER] error (valeur):', error)
      console.error('🔴 [HANDLER] error (JSON):', JSON.stringify(error, null, 2))
      console.error('🔴 [HANDLER] error?.message:', error?.message)
      console.error('🔴 [HANDLER] error?.toString():', error?.toString())
      // ✅ CORRECTION : Gestion d'erreur robuste
      const errorMessage = error?.message || error?.toString() || 'Erreur inconnue lors de l\'enregistrement du besoin'
      console.error('🔴 [HANDLER] Message d\'erreur final:', errorMessage)
      
      // ✅ Affichage du message d'erreur avec toast
      try {
        toast.error(`Erreur: ${errorMessage}`, {
          duration: 5000,
          position: 'top-right',
          style: {
            background: '#fee2e2',
            color: '#991b1b',
            border: '1px solid #fca5a5',
            borderRadius: '8px',
            padding: '16px',
            fontSize: '14px',
            fontWeight: '500',
          },
          iconTheme: {
            primary: '#dc2626',
            secondary: '#fee2e2',
          },
        })
      } catch (toastError: any) {
        console.error('🔴 [HANDLER] Erreur lors de l\'appel à toast.error():', toastError)
        // Fallback : notification personnalisée stylée
        showCustomNotification(errorMessage, 'error')
      }
    }
    
    console.log('🔵 [HANDLER] handleBesoinFormSubmit - FIN')
  }

  // ✅ ANCIENNE FONCTION (gardée pour compatibilité avec l'ancien modal)
  const handleSaveBesoin = () => {
    if (consultationOnly) {
      toast.error("Enregistrement indisponible en mode consultation.")
      return
    }
    if (modalType === "new") {
      // Rediriger vers le nouveau formulaire
      setShowBesoinForm(true)
      setBesoinToEdit(null)
      setShowModal(false)
    } else if (modalType === "edit") {
      // Rediriger vers le nouveau formulaire avec les données
      const rawData = selectedBesoin?._rawData || selectedBesoin
      if (rawData) {
        setBesoinToEdit({
          id: rawData.id,
          structureId: rawData.structureId || user?.structure?.id,
          niveauScolaireId: rawData.niveauScolaireId,
          anneeScolaireId: rawData.anneeScolaireId,
          effectifGarcons: rawData.effectifGarcons,
          effectifFilles: rawData.effectifFilles,
          effectifTotal: rawData.effectifTotal,
          statut: rawData.statut,
          commentaire: rawData.commentaire,
          besoinDetails: rawData.besoinDetails,
        })
        setShowBesoinForm(true)
        setShowModal(false)
      }
    }
  }

  const addNiveau = () => {
    setFormData(prev => ({
      ...prev,
      niveaux: [
        ...prev.niveaux,
        {
          niveau: "CP1",
          effectif_garcons: 0,
          effectif_filles: 0,
          effectif_total: 0,
          manuels: [],
          retours_auto: getRetoursByNiveau("CP1", user?.structure),
          coef_reparable: 0.7,
        },
      ],
    }))
  }

  const removeNiveau = (index: number) => {
    setFormData(prev => ({
      ...prev,
      niveaux: prev.niveaux.filter((_, i) => i !== index),
    }))
  }

  const updateNiveau = (index: number, field: string, value: any) => {
    setFormData(prev => ({
      ...prev,
      niveaux: prev.niveaux.map((niveau, i) => {
        if (i !== index) return niveau
        const next: Niveau = {
          ...niveau,
          [field]: value,
        }
        // Effectif piloté uniquement par effectif_total (saisie unique)
        if (field === "effectif_total") {
          next.effectif_total = Math.max(0, Number(value) || 0)
          // Conserver la compatibilité du modèle sans exposer la saisie par sexe
          next.effectif_garcons = 0
          next.effectif_filles = 0
        }
        // Clamp des quantités par manuel au nouvel effectif_total
        const eff = next.effectif_total
        if (Array.isArray(next.manuels)) {
          next.manuels = next.manuels.map(m => ({ ...m, quantite: Math.max(0, Math.min(m.quantite || 0, eff)) }))
        }
        // Mise à jour automatique des retours si le niveau change
        if (field === "niveau") {
          next.retours_auto = getRetoursByNiveau(value, user?.structure)
        }
        // Validation du coefficient réparable
        if (field === "coef_reparable") {
          next.coef_reparable = Math.max(0, Math.min(1, Number(value)))
        }
        return next
      }),
    }))
  }

  const addManuel = (niveauIndex: number) => {
    setFormData(prev => ({
      ...prev,
      niveaux: prev.niveaux.map((niveau, i) => 
        i === niveauIndex 
          ? {
              ...niveau,
              manuels: [
                ...niveau.manuels,
                { titre: "", quantite: Math.max(0, niveau.effectif_total) },
              ],
              retours_auto: getRetoursByNiveau(niveau.niveau, user?.structure)
            }
          : niveau
      ),
    }))
  }

  const removeManuel = (niveauIndex: number, manuelIndex: number) => {
    setFormData(prev => ({
      ...prev,
      niveaux: prev.niveaux.map((niveau, i) => 
        i === niveauIndex 
          ? {
              ...niveau,
              manuels: niveau.manuels.filter((_, j) => j !== manuelIndex),
              retours_auto: getRetoursByNiveau(niveau.niveau, user?.structure)
            }
          : niveau
      ),
    }))
  }

  const updateManuelQuantite = (niveauIndex: number, manuelIndex: number, quantite: number) => {
    setFormData(prev => ({
      ...prev,
      niveaux: prev.niveaux.map((niveau, i) => 
        i === niveauIndex 
          ? {
              ...niveau,
              manuels: niveau.manuels.map((manuel, j) => 
                j === manuelIndex 
                  ? { ...manuel, quantite: Math.max(0, Math.min(quantite, niveau.effectif_total)) }
                  : manuel
              ),
              retours_auto: getRetoursByNiveau(niveau.niveau, user?.structure)
            }
          : niveau
      ),
    }))
  }

  const updateManuelTitre = (niveauIndex: number, manuelIndex: number, titre: string) => {
    setFormData(prev => ({
      ...prev,
      niveaux: prev.niveaux.map((niveau, i) => 
        i === niveauIndex 
          ? {
              ...niveau,
              manuels: niveau.manuels.map((manuel, j) => 
                j === manuelIndex 
                  ? { ...manuel, titre, quantite: Math.max(0, niveau.effectif_total) }
                  : manuel
              ),
              retours_auto: getRetoursByNiveau(niveau.niveau, user?.structure)
            }
          : niveau
      ),
    }))
  }

  // Calculs Besoins (brut / net) par niveau
  const computeNiveauMetrics = (niveau: Niveau) => {
    const eff = niveau.effectif_total || 0
    // Calculer le besoin brut basé sur les manuels sélectionnés
    const besoinBrut = niveau.manuels.reduce((sum, manuel) => sum + (manuel.quantite || 0), 0)
    const coef = (typeof niveau.coef_reparable === "number" ? niveau.coef_reparable : 0.7)
    const stockDispo = (niveau.retours_auto?.bon_etat || 0) + coef * (niveau.retours_auto?.moyen_etat || 0)
    const besoinNet = Math.max(0, Math.round(besoinBrut - stockDispo))
    

    
    return { besoinBrut, stockDispo: Math.round(stockDispo), besoinNet }
  }

  return (
    <MainLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Expression des Besoins</h1>
            <p className="text-gray-600">
              Gestion des besoins en manuels scolaires - {user.structure?.libelle || "Système"}
            </p>
          </div>
          
          {canAccessBesoinSaisieCreate(user.role.code, functionalityPermissions) && !consultationOnly && (
            <button
              onClick={handleNewBesoin}
              className="bg-orange-600 hover:bg-orange-700 text-white px-4 py-2 rounded-lg flex items-center space-x-2"
            >
              <PlusIcon className="h-5 w-5" />
              <span>Nouveau Besoin</span>
            </button>
          )}
        </div>

        {/* Toast Notification */}
        {customToast && (
          <div className={`fixed top-4 right-4 z-50 p-4 rounded-lg shadow-lg ${
            customToast.type === "success" ? "bg-green-500 text-white" : "bg-red-500 text-white"
          }`}>
            {customToast.message}
          </div>
        )}

        <BesoinsSubNav roleCode={user.role.code} functionalityPermissions={functionalityPermissions} />

        {canAccessExpressionManuelleDafBesoinsPanel(user.role.code, functionalityPermissions) && (
          <ExpressionManuelleDafPanel
            anneesScolaires={anneesScolaires}
            defaultAnneeId={filterAnneeScolaireId}
            loadingAnnees={loadingAnneesScolaires}
          />
        )}

        {filterAnneeScolaireId != null && user?.structure?.id != null && (
          <CycleBesoinBar
            anneeScolaireId={filterAnneeScolaireId}
            structureType={user.structure?.type}
            roleCode={user.role?.code}
            ctx={cycleBesoinCtx}
            loading={cycleBesoinLoading}
            onReload={reloadCycleBesoinCtx}
          />
        )}

        {/* Content */}
        <div className="relative min-h-[min(70vh,560px)] space-y-6">
          <BesoinsDataOverlay
            visible={Boolean(loadingBesoins && user?.structure?.id)}
            title="Chargement des besoins"
            subtitle="Récupération des données sur le serveur, puis préparation des listes et des indicateurs. Veuillez patienter sur les gros volumes."
          />
          {activeTab === "saisie" && (() => {
            const besoinsSaisieRows = getBesoinsByRole()
            const besoinsSaisiePageRows = sliceBesoinsPage(besoinsSaisieRows, saisieListPage, saisieListPageSize)
            return (
            <div className="space-y-4">
              <div className="bg-white rounded-lg shadow">
                <div className="px-6 py-4 border-b border-gray-200">
                  <h3 className="text-lg font-medium text-gray-900">Besoins Saisis</h3>
                </div>
                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Structure
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Année
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Effectifs
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Manuels
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Statut
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Actions
                        </th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {besoinsSaisiePageRows.map((besoin) => (
                        <tr key={besoin.id} className="hover:bg-gray-50">
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div>
                              <div className="text-sm font-medium text-gray-900">
                                {besoin.structure.libelle}
                              </div>
                              <div className="text-sm text-gray-500">{besoin.structure.code}</div>
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                            {besoin.annee_scolaire}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="text-sm text-gray-900">
                              {besoin._rawData?.effectifTotal || besoin.niveaux?.reduce((sum: number, n: any) => sum + (n.effectif_total || 0), 0) || 0} élèves
                            </div>
                            <div className="text-sm text-gray-500">
                              {besoin.niveaux?.length || 1} niveau{besoin.niveaux?.length !== 1 ? 'x' : ''}
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                            {sumManuelsBesoinPourListe(besoin).toLocaleString()} manuels
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="flex items-center space-x-2">
                              {getStatusIcon(besoin.statut)}
                              {getStatusBadge(besoin.statut)}
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                            <button
                              onClick={() => handleViewBesoin(besoin)}
                              className="text-orange-600 hover:text-orange-900 mr-3"
                            >
                              Voir
                            </button>
                            {/* RBAC : BESOIN:UPDATE ; sans liste permissions → directeur / informaticien */}
                            {canUpdateBesoinSaisieRow(user.role.code, functionalityPermissions) &&
                              besoin.statut === "SAISI" &&
                              !consultationOnly && (
                              <button
                                onClick={() => handleEditBesoin(besoin)}
                                className="text-blue-600 hover:text-blue-900 mr-3"
                              >
                                Modifier
                              </button>
                            )}
                            {canShowValidateSaisieBesoinButton(user.role.code, functionalityPermissions) &&
                              besoin.statut === "SAISI" &&
                              !consultationOnly && (
                              <button
                                onClick={() => handleValidateBesoin(besoin)}
                                className="text-green-600 hover:text-green-900"
                              >
                                Valider
                              </button>
                            )}
                            {canShowConsolidateValideBesoinButton(user.role.code, functionalityPermissions) &&
                              besoin.statut === "VALIDE" &&
                              !consultationOnly && (
                              <button 
                                onClick={() => handleConsoliderBesoin(besoin)}
                                className="text-purple-600 hover:text-purple-900"
                              >
                                Consolider
                              </button>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                <BesoinsListPaginationBar
                  total={besoinsSaisieRows.length}
                  page={saisieListPage}
                  pageSize={saisieListPageSize}
                  onPageChange={setSaisieListPage}
                  onPageSizeChange={(s) => {
                    setSaisieListPageSize(s)
                    setSaisieListPage(1)
                  }}
                  itemLabel="besoins"
                />
              </div>
            </div>
            )
          })()}

          {activeTab === "consolidation" && (
            <div className="space-y-6">
              {/* Consolidation DRENA */}
              {canSeeBesoinsConsolidationDrenaSection(user.role.code, functionalityPermissions) && (() => {
                const drenaRows = consolidationDRENA
                const drenaPageRows = sliceBesoinsPage(drenaRows, consolidationDrenaPage, consolidationDrenaPageSize)
                return (
                <div className="bg-white rounded-lg shadow">
                  <div className="px-6 py-4 border-b border-gray-200">
                    <h3 className="text-lg font-medium text-gray-900">Consolidation DRENA</h3>
                  </div>
                  <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-gray-200">
                      <thead className="bg-gray-50">
                        <tr>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            DRENA
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            IEPP
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Effectifs
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Manuels
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Statut
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Actions
                          </th>
                        </tr>
                      </thead>
                      <tbody className="bg-white divide-y divide-gray-200">
                        {drenaPageRows.map((consolidation) => (
                          <tr key={consolidation.id} className="hover:bg-gray-50">
                            <td className="px-6 py-4 whitespace-nowrap">
                              <div className="text-sm font-medium text-gray-900">
                                {consolidation.drena}
                              </div>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                              {consolidation.iepp_count} IEPP
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                              {consolidation.total_effectifs} élèves
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                              {consolidation.total_manuels} manuels
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <div className="flex items-center space-x-2">
                                {getStatusIcon(consolidation.statut)}
                                {getStatusBadge(consolidation.statut)}
                              </div>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                              <div className="flex space-x-2">
                                <button 
                                  onClick={() => handleViewDetails(consolidation, "drena")}
                                  className="text-blue-600 hover:text-blue-900"
                                >
                                  Voir détails
                                </button>
                                {consolidation.statut !== "CONSOLIDE" ? (
                                  !consultationOnly && (
                                  <button 
                                    onClick={() => handleConsoliderDRENA(consolidation)}
                                    className="text-orange-600 hover:text-orange-900"
                                  >
                                    Consolider
                                  </button>
                                  )
                                ) : (
                                  <span className="text-green-600">Consolidé</span>
                                )}
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                  <BesoinsListPaginationBar
                    total={drenaRows.length}
                    page={consolidationDrenaPage}
                    pageSize={consolidationDrenaPageSize}
                    onPageChange={setConsolidationDrenaPage}
                    onPageSizeChange={(s) => {
                      setConsolidationDrenaPageSize(s)
                      setConsolidationDrenaPage(1)
                    }}
                    itemLabel="lignes"
                  />
                </div>
                )
              })()}
              {/* Consolidation IEPP */}
              {/* ✅ CORRECTION: DRENA supprimé, accès direct IEPP → DAF */}
              {canAccessBesoinsIeppConsolidationWorkspace(user.role.code, functionalityPermissions) && (() => {
                const consolidationsIepp = getConsolidationIEPPByRole()
                const consolidationsIeppPage = sliceBesoinsPage(consolidationsIepp, consolidationIeppPage, consolidationIeppPageSize)
                return (
                <div className="bg-white rounded-lg shadow">
                  <div className="px-6 py-4 border-b border-gray-200 flex justify-between items-center">
                    <h3 className="text-lg font-medium text-gray-900">Consolidation IEPP</h3>
                    {/* ✅ NOUVEAU : Bouton de consolidation en lot */}
                    {/* ✅ Afficher le bouton seulement s'il y a des besoins VALIDE à consolider et aucun déjà CONSOLIDE ou APPROUVE */}
                    {(() => {
                      const consolidationData = consolidationsIepp
                      const hasValideBesoin = getBesoinsByRole().some(b => b.statut === "VALIDE")
                      const isAlreadyConsolidatedOrApproved = consolidationData.length > 0 && 
                        (consolidationData[0].statut === "CONSOLIDE" || consolidationData[0].statut === "APPROUVE")
                      
                      return (
                        canShowConsolidationIeppConsoliderAction(user.role.code, functionalityPermissions) &&
                        !consultationOnly &&
                        hasValideBesoin &&
                        !isAlreadyConsolidatedOrApproved
                      )
                    })() && (
                      <button
                        onClick={handleConsoliderIEPP}
                        className="bg-purple-600 hover:bg-purple-700 text-white px-4 py-2 rounded-md text-sm font-medium flex items-center space-x-2"
                      >
                        <CalculatorIcon className="h-4 w-4" />
                        <span>Consolider Tous les Besoins EPP</span>
                      </button>
                    )}
                  </div>
                  <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-gray-200">
                      <thead className="bg-gray-50">
                        <tr>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            IEPP
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            EPP
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Effectifs
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Manuels
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Statut
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Actions
                          </th>
                        </tr>
                      </thead>
                      <tbody className="bg-white divide-y divide-gray-200">
                        {consolidationsIepp.length === 0 ? (
                              <tr>
                                <td colSpan={6} className="px-6 py-8 text-center text-sm text-gray-500">
                                  Aucune consolidation à afficher pour le moment.
                                </td>
                              </tr>
                            )
                          : (
                          consolidationsIeppPage.map((consolidation) => {
                          return (
                          <tr key={consolidation.id} className="hover:bg-gray-50">
                            <td className="px-6 py-4 whitespace-nowrap">
                              <div className="text-sm font-medium text-gray-900">
                                {consolidation.iepp}
                              </div>
                              {consolidation.drena && <div className="text-sm text-gray-500">{consolidation.drena}</div>}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                              {consolidation.epp_count} écoles
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                              {consolidation.total_effectifs} élèves
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                              {consolidation.total_manuels} manuels
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <div className="flex items-center space-x-2">
                                {getStatusIcon(consolidation.statut)}
                                {getStatusBadge(consolidation.statut)}
                              </div>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                              <div className="flex space-x-2">
                                <button 
                                  onClick={(e) => {
                                    console.log('🔵 [BUTTON-CLICK] ========== CLIC SUR "VOIR DÉTAILS" ==========')
                                    console.log('🔵 [BUTTON-CLICK] Event:', e)
                                    e.preventDefault()
                                    e.stopPropagation()
                                    console.log('🔵 [BUTTON-CLICK] preventDefault et stopPropagation appelés')
                                    console.log('🔵 [BUTTON-CLICK] consolidation:', JSON.stringify(consolidation, null, 2))
                                    console.log('🔵 [BUTTON-CLICK] user:', user)
                                    console.log('🔵 [BUTTON-CLICK] user?.structure:', user?.structure)
                                    console.log('🔵 [BUTTON-CLICK] user?.structure?.id:', user?.structure?.id)
                                    console.log('🔵 [BUTTON-CLICK] typeof handleViewDetails:', typeof handleViewDetails)
                                    console.log('🔵 [BUTTON-CLICK] Appel handleViewDetails(consolidation, "iepp")...')
                                    try {
                                      handleViewDetails(consolidation, "iepp")
                                      console.log('🟢 [BUTTON-CLICK] handleViewDetails appelé avec succès')
                                    } catch (error: any) {
                                      console.error('🔴 [BUTTON-CLICK] Erreur lors de l\'appel handleViewDetails:', error)
                                      console.error('🔴 [BUTTON-CLICK] Error stack:', error.stack)
                                    }
                                    console.log('🔵 [BUTTON-CLICK] ========== FIN DU CLIC ==========')
                                  }}
                                  className="text-blue-600 hover:text-blue-900"
                                >
                                  Voir détails
                                </button>
                                {consolidation.statut === "APPROUVE" ? (
                                  <span className="text-green-700 font-medium">Approuvé</span>
                                ) : consolidation.statut === "CONSOLIDE" ? (
                                  <span className="text-green-600">Consolidé</span>
                                ) : (
                                  canShowConsolidationIeppConsoliderAction(user.role.code, functionalityPermissions) &&
                                  !consultationOnly && (
                                  <button 
                                    onClick={handleConsoliderIEPP}
                                    className="text-orange-600 hover:text-orange-900"
                                  >
                                    Consolider
                                  </button>
                                  )
                                )}
                              </div>
                            </td>
                          </tr>
                          )
                        })
                          )}
                      </tbody>
                    </table>
                  </div>
                  <BesoinsListPaginationBar
                    total={consolidationsIepp.length}
                    page={consolidationIeppPage}
                    pageSize={consolidationIeppPageSize}
                    onPageChange={setConsolidationIeppPage}
                    onPageSizeChange={(s) => {
                      setConsolidationIeppPageSize(s)
                      setConsolidationIeppPage(1)
                    }}
                    itemLabel="lignes"
                  />
                </div>
                )
              })()}

              
            </div>
          )}

          {activeTab === "validation" && (
            <div className="space-y-6">
              <div className="bg-white rounded-lg shadow">
                <div className="px-6 py-4 border-b border-gray-200 flex justify-between items-center">
                  <h3 className="text-lg font-medium text-gray-900">
                    {canUseBesoinsValidationGroupedByIeppList(user.role.code, functionalityPermissions)
                      ? "Validation DAF - Besoins Consolidés IEPP"
                      : "Validation des Besoins"}
                  </h3>
                  {/* ✅ NOUVEAU : Bouton d'approbation en lot */}
                  {canAccessBesoinsDafValidationWorkspace(user.role.code, functionalityPermissions) &&
                    !consultationOnly &&
                    (besoinsValidationGroupesParIepp.some(g => g.statut === "CONSOLIDE") ||
                      getBesoinsByRole().some(b => b.statut === "CONSOLIDE")) && (
                    <div className="flex flex-wrap items-center gap-2">
                      <button
                        type="button"
                        onClick={handleExportApprovalExcelAllConsolides}
                        className="inline-flex items-center gap-2 rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-800 shadow-sm hover:bg-gray-50"
                      >
                        <ArrowDownTrayIcon className="h-4 w-4" />
                        Exporter Excel (tous les consolidés)
                      </button>
                      <input
                        ref={approvalExcelImportRef}
                        type="file"
                        accept=".xlsx,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                        className="hidden"
                        onChange={handleApprovalExcelPickedFromValidationTab}
                      />
                      <button
                        type="button"
                        onClick={() => approvalExcelImportRef.current?.click()}
                        className="inline-flex items-center gap-2 rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-800 shadow-sm hover:bg-gray-50"
                      >
                        <DocumentArrowUpIcon className="h-4 w-4" />
                        Importer Excel (approbation)
                      </button>
                      <button
                        onClick={handleApprouverTous}
                        className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-md text-sm font-medium flex items-center space-x-2"
                      >
                        <CheckCircleIcon className="h-4 w-4" />
                        <span>Approuver Tous les Besoins Consolidés</span>
                      </button>
                    </div>
                  )}
                </div>
                {(() => {
                  const validationGroupedView = canUseBesoinsValidationGroupedByIeppList(user.role.code, functionalityPermissions)
                  const validationRowsFull = validationGroupedView ? besoinsValidationGroupesParIepp : getBesoinsByRole()
                  const validationRowsPage = sliceBesoinsPage(validationRowsFull, validationListPage, validationListPageSize)
                  return (
                    <>
                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Structure
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Année
                        </th>
                        {/* ✅ Masquer la colonne EFFECTIF pour DAF */}
                        {!canUseBesoinsValidationGroupedByIeppList(user.role.code, functionalityPermissions) && (
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Effectifs
                          </th>
                        )}
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Manuels
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Statut
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Actions
                        </th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {validationRowsFull.length === 0 ? (
                        <tr>
                          <td
                            colSpan={validationGroupedView ? 5 : 6}
                            className="px-6 py-4 text-center text-sm text-gray-500"
                          >
                            {validationGroupedView
                              ? "Aucun besoin consolidé à approuver"
                              : "Aucun besoin à valider"}
                          </td>
                        </tr>
                      ) : validationGroupedView ? (
                        groupValidationGroupesParDrena(validationRowsPage).map((drenaBlock) => (
                          <Fragment key={drenaBlock.key}>
                            <tr className="bg-indigo-50/90">
                              <td colSpan={5} className="p-0 align-top">
                                <details className="group border-b border-indigo-100 open:bg-indigo-50/40">
                                  <summary className="flex cursor-pointer list-none flex-wrap items-center justify-between gap-2 px-6 py-3 text-sm font-semibold text-indigo-950 hover:bg-indigo-100/60 [&::-webkit-details-marker]:hidden">
                                    <span className="flex items-center gap-2">
                                      <span className="rounded bg-indigo-600 px-1.5 py-0.5 text-[10px] font-bold uppercase tracking-wide text-white">
                                        DRENA
                                      </span>
                                      {drenaBlock.label}
                                    </span>
                                    <span className="text-xs font-medium text-indigo-800/80">
                                      {drenaBlock.groupes.length} IEPP (page)
                                    </span>
                                  </summary>
                                  <div className="border-t border-indigo-100/80 bg-white">
                                    <table className="min-w-full divide-y divide-gray-200">
                                      <tbody>
                                        {drenaBlock.groupes.map((groupe, idx) => {
                                          const eppLignes = (groupe.besoins || []).filter(
                                            (b: any) =>
                                              b?._rawData?.structureType === "EPP" || b?.structureType === "EPP"
                                          )
                                          const rowKey = `${groupe.structureId}-${groupe.annee}-${idx}`
                                          return (
                                            <Fragment key={rowKey}>
                                              <tr className="hover:bg-gray-50">
                                                <td className="px-6 py-4 whitespace-nowrap">
                                                  <div className="flex items-start gap-2">
                                                    <span className="mt-0.5 inline-flex shrink-0 rounded bg-sky-600 px-1.5 py-0.5 text-[10px] font-bold uppercase tracking-wide text-white">
                                                      IEPP
                                                    </span>
                                                    <div>
                                                      <div className="text-sm font-medium text-gray-900">
                                                        {groupe.structureLibelle}
                                                      </div>
                                                      <div className="text-sm text-gray-500">{groupe.structureCode}</div>
                                                    </div>
                                                  </div>
                                                </td>
                                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                                  {groupe.annee}
                                                </td>
                                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                                  {groupe.totalManuels?.toLocaleString() || 0} manuels
                                                </td>
                                                <td className="px-6 py-4 whitespace-nowrap">
                                                  <div className="flex items-center space-x-2">
                                                    {getStatusIcon(groupe.statut)}
                                                    {getStatusBadge(groupe.statut)}
                                                  </div>
                                                </td>
                                                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                                  {groupe.statut === "CONSOLIDE" && !consultationOnly && (
                                                    <div className="flex flex-wrap gap-2">
                                                      <button
                                                        type="button"
                                                        onClick={() => handleExportApprovalExcelForGroupe(groupe)}
                                                        className="inline-flex items-center gap-1 rounded border border-gray-300 bg-white px-2 py-1 text-xs font-medium text-gray-800 hover:bg-gray-50"
                                                      >
                                                        <ArrowDownTrayIcon className="h-3.5 w-3.5" />
                                                        Excel
                                                      </button>
                                                      <button
                                                        onClick={() => handleValiderDAF(groupe)}
                                                        className="bg-green-600 hover:bg-green-700 text-white px-3 py-1 rounded text-sm"
                                                      >
                                                        ✅ Approuver
                                                      </button>
                                                    </div>
                                                  )}
                                                  {groupe.statut === "APPROUVE" && (
                                                    <span className="text-green-600 font-medium">✅ Approuvé</span>
                                                  )}
                                                  <button
                                                    onClick={() => handleViewBesoin(groupe)}
                                                    className="ml-2 text-blue-600 hover:text-blue-900"
                                                  >
                                                    Voir détails
                                                  </button>
                                                </td>
                                              </tr>
                                              {eppLignes.length > 0 && (
                                                <tr className="bg-amber-50/40">
                                                  <td colSpan={5} className="px-6 py-2">
                                                    <details className="group/epp">
                                                      <summary className="cursor-pointer list-none text-xs font-semibold uppercase tracking-wide text-amber-950 hover:text-amber-800 [&::-webkit-details-marker]:hidden">
                                                        <span className="rounded bg-amber-600 px-1.5 py-0.5 text-[10px] font-bold text-white">
                                                          EPP
                                                        </span>{" "}
                                                        {eppLignes.length} établissement(s)
                                                      </summary>
                                                      <ul className="mt-2 max-h-40 list-disc space-y-1 overflow-y-auto pl-8 text-xs text-gray-800">
                                                        {eppLignes.map((b: any) => (
                                                          <li key={b.id ?? b._rawData?.id}>
                                                            {(b._rawData?.structureAdministrativeLibelle ??
                                                              b.structure?.libelle ??
                                                              `Besoin ${b.id}`) +
                                                              (b._rawData?.structureAdministrativeCode ||
                                                              b.structure?.code
                                                                ? ` · ${b._rawData?.structureAdministrativeCode ?? b.structure?.code}`
                                                                : "")}
                                                          </li>
                                                        ))}
                                                      </ul>
                                                    </details>
                                                  </td>
                                                </tr>
                                              )}
                                            </Fragment>
                                          )
                                        })}
                                      </tbody>
                                    </table>
                                  </div>
                                </details>
                              </td>
                            </tr>
                          </Fragment>
                        ))
                      ) : (
                        validationRowsPage.map((besoin) => (
                          <tr key={besoin.id} className="hover:bg-gray-50">
                            <td className="px-6 py-4 whitespace-nowrap">
                              <div>
                                <div className="text-sm font-medium text-gray-900">{besoin.structure.libelle}</div>
                                <div className="text-sm text-gray-500">{besoin.structure.code}</div>
                              </div>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{besoin.annee_scolaire}</td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <div className="text-sm text-gray-900">
                                {besoin._rawData?.effectifTotal || besoin.niveaux?.reduce((sum: number, n: any) => sum + (n.effectif_total || 0), 0) || 0} élèves
                              </div>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                              {sumManuelsBesoinPourListe(besoin).toLocaleString()} manuels
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <div className="flex items-center space-x-2">
                                {getStatusIcon(besoin.statut)}
                                {getStatusBadge(besoin.statut)}
                              </div>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                              {besoin.statut === "CONSOLIDE" && !consultationOnly && (
                                <div className="flex flex-wrap gap-2">
                                  <button
                                    type="button"
                                    onClick={() =>
                                      handleExportApprovalExcelForGroupe({
                                        besoins: [besoin],
                                        statut: "CONSOLIDE",
                                      })
                                    }
                                    className="inline-flex items-center gap-1 rounded border border-gray-300 bg-white px-2 py-1 text-xs font-medium text-gray-800 hover:bg-gray-50"
                                  >
                                    <ArrowDownTrayIcon className="h-3.5 w-3.5" />
                                    Excel
                                  </button>
                                  <button
                                    onClick={() => handleValiderDAF(besoin)}
                                    className="bg-green-600 hover:bg-green-700 text-white px-3 py-1 rounded text-sm"
                                  >
                                    ✅ Approuver
                                  </button>
                                </div>
                              )}
                              {besoin.statut === "APPROUVE" && <span className="text-green-600 font-medium">✅ Approuvé</span>}
                              <button onClick={() => handleViewBesoin(besoin)} className="ml-2 text-blue-600 hover:text-blue-900">Voir détails</button>
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
                <BesoinsListPaginationBar
                  total={validationRowsFull.length}
                  page={validationListPage}
                  pageSize={validationListPageSize}
                  onPageChange={setValidationListPage}
                  onPageSizeChange={(s) => {
                    setValidationListPageSize(s)
                    setValidationListPage(1)
                  }}
                  itemLabel="lignes"
                />
                    </>
                  )
                })()}
              </div>
              
            </div>
          )}

          {activeTab === "suivi" && (
            <div className="space-y-6">
              {/* En-tête avec titre */}
              <div className="bg-white rounded-lg shadow p-6">
                <h3 className="text-lg font-medium text-gray-900 mb-4">Suivi des Besoins</h3>
                
                {/* Statistiques */}
                <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-4 mb-6">
                  <div className="bg-gray-50 rounded-lg p-4">
                    <div className="text-sm text-gray-600">Total</div>
                    <div className="text-2xl font-bold text-gray-900">{statsSuivi.total}</div>
                  </div>
                  <div className="bg-blue-50 rounded-lg p-4">
                    <div className="text-sm text-blue-600">Saisi</div>
                    <div className="text-2xl font-bold text-blue-900">{statsSuivi.saisi}</div>
                  </div>
                  <div className="bg-green-50 rounded-lg p-4">
                    <div className="text-sm text-green-600">Validé</div>
                    <div className="text-2xl font-bold text-green-900">{statsSuivi.valide}</div>
                  </div>
                  <div className="bg-purple-50 rounded-lg p-4">
                    <div className="text-sm text-purple-600">Consolidé</div>
                    <div className="text-2xl font-bold text-purple-900">{statsSuivi.consolide}</div>
                  </div>
                  <div className="bg-emerald-50 rounded-lg p-4">
                    <div className="text-sm text-emerald-600">Approuvé</div>
                    <div className="text-2xl font-bold text-emerald-900">{statsSuivi.approuve}</div>
                  </div>
                  <div className="bg-orange-50 rounded-lg p-4">
                    <div className="text-sm text-orange-600">Effectifs</div>
                    <div className="text-2xl font-bold text-orange-900">{statsSuivi.totalEffectifs.toLocaleString()}</div>
                  </div>
                  <div className="bg-indigo-50 rounded-lg p-4">
                    <div className="text-sm text-indigo-600">Manuels</div>
                    <div className="text-2xl font-bold text-indigo-900">{statsSuivi.totalManuels.toLocaleString()}</div>
                  </div>
                </div>
                
                {/* ✅ NOUVEAU : Filtre par année scolaire */}
                <div className="mb-4 flex items-center gap-4">
                  <div className="flex-1">
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Année Scolaire
                    </label>
                    <select
                      value={filterAnneeScolaireId || ''}
                      onChange={(e) => setFilterAnneeScolaireId(e.target.value ? parseInt(e.target.value) : null)}
                      className="block w-full md:w-64 px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-orange-500 focus:border-orange-500"
                      disabled={loadingAnneesScolaires}
                    >
                      <option value="">Toutes les années</option>
                      {anneesScolaires.map((annee) => (
                        <option key={annee.id} value={annee.id}>
                          {annee.libelle || annee.code}
                        </option>
                      ))}
                    </select>
                  </div>
                  {loadingAnneesScolaires && (
                    <div className="flex items-center text-sm text-gray-500 mt-6">
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-orange-600 mr-2"></div>
                      Chargement...
                    </div>
                  )}
                </div>
                
                {/* Filtres par statut */}
                <div className="flex flex-wrap gap-2 mb-4">
                  <button
                    onClick={() => setFilterStatut(null)}
                    className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                      filterStatut === null
                        ? "bg-orange-600 text-white"
                        : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                    }`}
                  >
                    Tous
                  </button>
                  <button
                    onClick={() => setFilterStatut("SAISI")}
                    className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                      filterStatut === "SAISI"
                        ? "bg-blue-600 text-white"
                        : "bg-blue-100 text-blue-800 hover:bg-blue-200"
                    }`}
                  >
                    Saisi ({statsSuivi.saisi})
                  </button>
                  <button
                    onClick={() => setFilterStatut("VALIDE")}
                    className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                      filterStatut === "VALIDE"
                        ? "bg-green-600 text-white"
                        : "bg-green-100 text-green-800 hover:bg-green-200"
                    }`}
                  >
                    Validé ({statsSuivi.valide})
                  </button>
                  <button
                    onClick={() => setFilterStatut("CONSOLIDE")}
                    className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                      filterStatut === "CONSOLIDE"
                        ? "bg-purple-600 text-white"
                        : "bg-purple-100 text-purple-800 hover:bg-purple-200"
                    }`}
                  >
                    Consolidé ({statsSuivi.consolide})
                  </button>
                  <button
                    onClick={() => setFilterStatut("APPROUVE")}
                    className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                      filterStatut === "APPROUVE"
                        ? "bg-emerald-600 text-white"
                        : "bg-emerald-100 text-emerald-800 hover:bg-emerald-200"
                    }`}
                  >
                    Approuvé ({statsSuivi.approuve})
                  </button>
                </div>
              </div>
              
              {/* Tableau des besoins - par IEPP pour DRENA/DAF, par besoin pour les autres */}
              <div className="bg-white rounded-lg shadow overflow-hidden">
                {(() => {
                  const suiviParIeppMode = canUseBesoinsSuiviParIeppGrouping(user?.role?.code, functionalityPermissions)
                  const suiviRowsFull = suiviParIeppMode ? suiviParIepp : besoinsSuivi
                  const suiviRowsPage = sliceBesoinsPage(suiviRowsFull, suiviListPage, suiviListPageSize)
                  return (
                    <>
                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        {suiviParIeppMode ? (
                          <>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">IEPP</th>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Année</th>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Statut</th>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Effectifs</th>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Manuels</th>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                          </>
                        ) : (
                          <>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Référence</th>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Structure</th>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Niveau</th>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Année Scolaire</th>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Statut</th>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Effectifs</th>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Manuels</th>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Dates</th>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                          </>
                        )}
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {suiviParIeppMode ? (
                        suiviRowsFull.length === 0 ? (
                          <tr>
                            <td colSpan={6} className="px-6 py-8 text-center text-gray-500">
                              {isIeppTerritoryMenuRole(user?.role?.code)
                                ? "Aucun besoin consolidé ou approuvé"
                                : "Aucun IEPP trouvé"}
                            </td>
                          </tr>
                        ) : (
                          suiviRowsPage.map((row: any) => (
                            <tr key={row.id} className="hover:bg-gray-50">
                              <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{row.iepp}</td>
                              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{row.annee || "-"}</td>
                              <td className="px-6 py-4 whitespace-nowrap">
                                <div className="flex items-center space-x-2">
                                  {getStatusIcon(row.statut)}
                                  {getStatusBadge(row.statut)}
                                </div>
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{row.effectifs} élèves</td>
                              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{row.manuels} manuels</td>
                              <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                <button
                                  onClick={() => handleViewDetails(row, "iepp")}
                                  className="text-orange-600 hover:text-orange-900 flex items-center space-x-1"
                                >
                                  <EyeIcon className="h-4 w-4" />
                                  <span>Voir détails</span>
                                </button>
                              </td>
                            </tr>
                          ))
                        )
                      ) : suiviRowsFull.length === 0 ? (
                        <tr>
                          <td colSpan={9} className="px-6 py-8 text-center text-gray-500">
                            Aucun besoin trouvé
                          </td>
                        </tr>
                      ) : (
                        suiviRowsPage.map((besoin) => (
                          <tr key={besoin.id} className="hover:bg-gray-50">
                            <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                              {besoin._rawData?.reference || `BES-${besoin.id}`}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                              {/* ✅ CORRECTION : Afficher le nom de l'IEPP, pas "Ministère de l'Éducation Nationale" */}
                              {besoin._rawData?.structureAdministrativeLibelle || besoin.structure?.libelle || "N/A"}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                              {besoin._rawData?.niveauScolaireLibelle || besoin._rawData?.niveauScolaireCode || "N/A"}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                              {besoin.annee_scolaire || besoin._rawData?.anneeScolaireLibelle || "N/A"}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <div className="flex items-center space-x-2">
                                {getStatusIcon(besoin.statut)}
                                {getStatusBadge(besoin.statut)}
                              </div>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                              {(() => {
                                // ✅ CORRECTION: Pour les besoins consolidés/approuvés, les effectifs peuvent ne pas être disponibles
                                if (besoin.statut === "CONSOLIDE" || besoin.statut === "APPROUVE") {
                                  const effectifTotal = besoin.effectifTotal || besoin._rawData?.effectifTotal
                                  if (effectifTotal && effectifTotal > 0) {
                                    return `${effectifTotal} élèves`
                                  }
                                  return "N/A"
                                }
                                // Pour les autres besoins, afficher normalement
                                return `${besoin.effectifTotal || besoin._rawData?.effectifTotal || 0} élèves`
                              })()}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                              {sumManuelsBesoinPourListe(besoin).toLocaleString()} manuels
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                              <div className="space-y-1">
                                {besoin.date_saisie && <div>Saisie: {besoin.date_saisie}</div>}
                                {besoin._rawData?.dateConsolidation && <div>Consolidation: {besoin._rawData.dateConsolidation}</div>}
                                {besoin._rawData?.dateApprobation && <div>Approbation: {besoin._rawData.dateApprobation}</div>}
                              </div>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                              <button
                                onClick={() => handleViewBesoin(besoin)}
                                className="text-orange-600 hover:text-orange-900 flex items-center space-x-1"
                              >
                                <EyeIcon className="h-4 w-4" />
                                <span>Voir</span>
                              </button>
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
                <BesoinsListPaginationBar
                  total={suiviRowsFull.length}
                  page={suiviListPage}
                  pageSize={suiviListPageSize}
                  onPageChange={setSuiviListPage}
                  onPageSizeChange={(s) => {
                    setSuiviListPageSize(s)
                    setSuiviListPage(1)
                  }}
                  itemLabel="lignes"
                />
                    </>
                  )
                })()}
              </div>
            </div>
          )}

          {activeTab === "coherence" && (
            <div className="space-y-6">
              <DataCoherenceDashboard
                roleCode={user?.role?.code || ""}
                anneeScolaireId={filterAnneeScolaireId}
                structureId={user?.structure?.id}
                drenaId={(user as any)?.drenaId ?? (user as any)?.drena?.id}
                ieppId={(user as any)?.ieppId ?? (user as any)?.iepp?.id}
              />
            </div>
          )}
        </div>

        {/* Modal */}
        {showModal && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white rounded-lg shadow-xl max-w-4xl w-full mx-4 max-h-[90vh] overflow-y-auto">
              <div className="px-6 py-4 border-b border-gray-200 flex justify-between items-center">
                <h3 className="text-lg font-medium text-gray-900">
                  {modalType === "new" ? "Nouveau Besoin" : 
                   modalType === "edit" ? "Modifier le Besoin" : "Détails du Besoin"}
                </h3>
                <button
                  onClick={() => setShowModal(false)}
                  className="text-gray-400 hover:text-gray-600"
                >
                  <XMarkIcon className="h-6 w-6" />
                </button>
              </div>

              <div className="p-6">
                {modalType === "view" && selectedBesoin ? (
                  <div className="space-y-6">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700">Structure</label>
                        <p className="mt-1 text-sm text-gray-900">
                          {selectedBesoin.structure?.libelle || selectedBesoin.structureAdministrativeLibelle || 'Non définie'}
                        </p>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700">Année Scolaire</label>
                        <p className="mt-1 text-sm text-gray-900">
                          {selectedBesoin.annee_scolaire || selectedBesoin.anneeScolaireLibelle || 'Non définie'}
                        </p>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700">Statut</label>
                        <div className="mt-1 flex items-center space-x-2">
                          {getStatusIcon(selectedBesoin.statut)}
                          {getStatusBadge(selectedBesoin.statut)}
                        </div>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700">
                          {selectedBesoin.statut === "CONSOLIDE" || selectedBesoin.statut === "APPROUVE" 
                            ? "Consolidé par" 
                            : "Saisi par"}
                        </label>
                        <p className="mt-1 text-sm text-gray-900">
                          {(() => {
                            // ✅ CORRECTION: Pour les besoins consolidés/approuvés, utiliser consolidePar
                            if (selectedBesoin.statut === "CONSOLIDE" || selectedBesoin.statut === "APPROUVE") {
                              if (selectedBesoin.consolideParFirstName && selectedBesoin.consolideParLastName) {
                                return `${selectedBesoin.consolideParFirstName} ${selectedBesoin.consolideParLastName}`
                              }
                              if (selectedBesoin.consolideParLogin) {
                                return selectedBesoin.consolideParLogin
                              }
                              if (selectedBesoin.approuveParFirstName && selectedBesoin.approuveParLastName) {
                                return `${selectedBesoin.approuveParFirstName} ${selectedBesoin.approuveParLastName}`
                              }
                              if (selectedBesoin.approuveParLogin) {
                                return selectedBesoin.approuveParLogin
                              }
                            }
                            // Sinon, utiliser saisiPar
                            return selectedBesoin.saisi_par || 
                                   (selectedBesoin.saisiParFirstName && selectedBesoin.saisiParLastName 
                                     ? `${selectedBesoin.saisiParFirstName} ${selectedBesoin.saisiParLastName}` 
                                     : selectedBesoin.saisiParLogin) || 
                                   'Non défini'
                          })()}
                        </p>
                      </div>
                    </div>

                    <div>
                      <h4 className="text-md font-medium text-gray-900 mb-4">
                        {selectedBesoin.besoinDetails ? 'Détails des Matières par Niveau' : 'Niveaux et Manuels'}
                      </h4>
                      <div className="space-y-4">
                        {/* Grouper par niveau et afficher effectifs par niveau */}
                        {selectedBesoin.besoinDetails && selectedBesoin.besoinDetails.length > 0 ? (
                          (() => {
                            const details = selectedBesoin.besoinDetails as any[]
                            const byNiveau = new Map<string, { libelle: string; details: typeof details; effectifTotal: number }>()
                            const niveauxSource = Array.isArray(selectedBesoin.niveaux) ? selectedBesoin.niveaux : []
                            const hasSingleNiveau = niveauxSource.length <= 1
                            for (const d of details) {
                              const nivId = d.niveauScolaireId ?? selectedBesoin.niveauScolaireId ?? 'default'
                              const key = String(nivId)
                              const libelle = d.niveauScolaireLibelle ?? d.niveauScolaireCode ?? selectedBesoin.niveauScolaireLibelle ?? 'Niveau'
                              const niveauMatch = niveauxSource.find((n: any) =>
                                String(n.id ?? n.niveauScolaireId ?? n.niveau_scolaire_id ?? n.niveauCode ?? n.niveauScolaireCode ?? n.niveau ?? "") === key ||
                                (n.niveauCode && n.niveauCode === d.niveauScolaireCode) ||
                                (n.niveauScolaireCode && n.niveauScolaireCode === d.niveauScolaireCode) ||
                                (n.niveau && n.niveau === d.niveauScolaireLibelle)
                              )
                              const effectifTotal =
                                d.effectifTotalNiveau ??
                                d.effectif_total_niveau ??
                                d.effectifTotal ??
                                d.effectif_total ??
                                niveauMatch?.effectif_total ??
                                niveauMatch?.effectifTotal ??
                                (hasSingleNiveau ? (selectedBesoin.effectifTotal ?? selectedBesoin.effectif_total) : undefined) ??
                                ((d.effectifGarcons ?? d.effectif_garcons ?? 0) + (d.effectifFilles ?? d.effectif_filles ?? 0))
                              if (!byNiveau.has(key)) {
                                byNiveau.set(key, { libelle, details: [], effectifTotal })
                              }
                              const entry = byNiveau.get(key)!
                              entry.details.push(d)
                              if (
                                d.effectifTotalNiveau != null ||
                                d.effectif_total_niveau != null ||
                                d.effectifTotal != null ||
                                d.effectif_total != null
                              ) {
                                entry.effectifTotal =
                                  d.effectifTotalNiveau ??
                                  d.effectif_total_niveau ??
                                  d.effectifTotal ??
                                  d.effectif_total ??
                                  entry.effectifTotal
                              }
                            }
                            return Array.from(byNiveau.values()).map(({ libelle, details: nivDetails, effectifTotal: effectifChamps }, nivIdx) => {
                              const avgManuels = effectifElevesParNiveauDepuisDetailsLignes(
                                nivDetails,
                                selectedBesoin.statut,
                              )
                              const hasExemplaires = nivDetails.some(
                                (d) => quantiteDetailPourAffichageExemplaires(d, selectedBesoin.statut) > 0,
                              )
                              const effectifFromChamps = Number(effectifChamps) || 0
                              const effectifAffiche = effectifFromChamps > 0 ? effectifFromChamps : hasExemplaires ? (avgManuels ?? 0) : 0
                              return (
                              <div key={nivIdx} className="border-2 border-orange-200 rounded-lg p-4 bg-orange-50/50">
                                <div className="mb-3">
                                  <h5 className="font-semibold text-orange-800 mb-1">{libelle}</h5>
                                  <div className="text-sm text-gray-700">
                                    {effectifAffiche} élèves
                                  </div>
                                </div>
                                <div className="space-y-2">
                                  {nivDetails.map((detail: any, index: number) => (
                                    <div key={detail.id || index} className="flex justify-between items-center py-2 border-b border-gray-100">
                                      <div className="flex-1">
                                        <span className="text-sm font-medium text-gray-900">{detail.matiereLibelle || detail.matiere?.libelle}</span>
                                        {detail.matiereCode && (
                                          <span className="text-xs text-gray-500 ml-2">({detail.matiereCode})</span>
                                        )}
                                      </div>
                                      <div className="text-right">
                                        <div className="text-sm font-medium text-gray-900">
                                          {quantiteDetailPourAffichageExemplaires(detail, selectedBesoin.statut)} exemplaires
                                        </div>
                                        {detail.quantiteRetourAnneePrecedente > 0 && (
                                          <div className="text-xs text-gray-500">
                                            {(() => {
                                              const selectedCode = (selectedBesoin.annee_scolaire || selectedBesoin.anneeScolaireCode || "").toString().trim()
                                              const displayCode = selectedCode || "année courante"
                                              return `Récup. ${displayCode}: ${detail.quantiteRetourAnneePrecedente}`
                                            })()}
                                          </div>
                                        )}
                                        {selectedBesoin.statut === "APPROUVE" && detail.quantiteApprouvee && detail.quantiteConsolidee && detail.quantiteApprouvee !== detail.quantiteConsolidee && (
                                          <div className="text-xs text-purple-600">Consolidé: {detail.quantiteConsolidee}</div>
                                        )}
                                        {selectedBesoin.statut === "CONSOLIDE" && detail.quantiteConsolidee && detail.quantiteConsolidee !== (detail.quantiteNet || detail.quantiteBrute || 0) && (
                                          <div className="text-xs text-purple-600">Consolidé: {detail.quantiteConsolidee}</div>
                                        )}
                                      </div>
                                    </div>
                                  ))}
                                </div>
                              </div>
                            );
                            })
                          })()
                        ) : null}
                        
                        {/* ✅ NOUVEAU : Section Besoins EPP associés (uniquement pour besoins IEPP approuvés) */}
                        {selectedBesoin.statut === "APPROUVE" && 
                         selectedBesoin.structureType === "IEPP" && (
                          <div className="border-t border-gray-200 pt-6 mt-6">
                            <div className="flex items-center justify-between mb-4">
                              <h4 className="text-md font-medium text-gray-900">
                                📋 Besoins EPP associés
                              </h4>
                              <span className="text-sm text-gray-500">
                                {eppBesoinsAssocies.length} EPP(s)
                              </span>
                            </div>
                            
                            {loadingEppBesoins ? (
                              <div className="text-center py-4">
                                <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-orange-600 mx-auto"></div>
                                <p className="mt-2 text-sm text-gray-600">Chargement des besoins EPP...</p>
                              </div>
                            ) : eppBesoinsAssocies.length > 0 ? (
                              <div className="space-y-4">
                                {/* Tableau des besoins EPP */}
                                <div className="overflow-x-auto">
                                  <table className="min-w-full divide-y divide-gray-200">
                                    <thead className="bg-gray-50">
                                      <tr>
                                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                                          Structure EPP
                                        </th>
                                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                                          Matière
                                        </th>
                                        <th className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase">
                                          Quantité Net
                                        </th>
                                        <th className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase">
                                          Quantité Consolidée
                                        </th>
                                        <th className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase">
                                          Quantité Approuvée
                                        </th>
                                      </tr>
                                    </thead>
                                    <tbody className="bg-white divide-y divide-gray-200">
                                      {eppBesoinsAssocies.map((besoinEpp: any) => {
                                        const detailsEpp = besoinEpp.besoinDetails || []
                                        const detailsIepp = selectedBesoin.besoinDetails || []
                                        
                                        // Créer une map des quantités approuvées IEPP par matière
                                        const quantitesApprouveesIepp = new Map<number, number>()
                                        const quantitesConsolideesIepp = new Map<number, number>()
                                        
                                        detailsIepp.forEach((detail: any) => {
                                          if (detail.matiereId) {
                                            quantitesApprouveesIepp.set(detail.matiereId, detail.quantiteApprouvee || 0)
                                            quantitesConsolideesIepp.set(detail.matiereId, detail.quantiteConsolidee || 0)
                                          }
                                        })
                                        
                                        // Calculer le total consolidé pour toutes les matières
                                        const totalConsolide = Array.from(quantitesConsolideesIepp.values()).reduce((sum, qty) => sum + qty, 0)
                                        
                                        return detailsEpp.map((detailEpp: any, detailIndex: number) => {
                                          const matiereId = detailEpp.matiereId
                                          const quantiteNetEpp = detailEpp.quantiteNet || 0
                                          const quantiteConsolideeEpp = detailEpp.quantiteConsolidee || 0
                                          
                                          // Calculer la quantité approuvée proportionnellement
                                          let quantiteApprouveeEpp = 0
                                          const quantiteApprouveeIepp = quantitesApprouveesIepp.get(matiereId) || 0
                                          const quantiteConsolideeIepp = quantitesConsolideesIepp.get(matiereId) || 0
                                          
                                          // Si une exception existe déjà (quantiteApprouvee dans le besoin EPP), l'utiliser
                                          if (detailEpp.quantiteApprouvee && detailEpp.quantiteApprouvee > 0) {
                                            quantiteApprouveeEpp = detailEpp.quantiteApprouvee
                                          } else if (quantiteConsolideeIepp > 0 && totalConsolide > 0) {
                                            // Calcul proportionnel : (quantiteNet EPP / quantiteConsolidee IEPP) * quantiteApprouvee IEPP
                                            quantiteApprouveeEpp = Math.round(
                                              ((quantiteNetEpp / quantiteConsolideeIepp) * quantiteApprouveeIepp)
                                            )
                                          }
                                          
                                          return (
                                            <tr key={`${besoinEpp.id}-${detailEpp.id || detailIndex}`} className="hover:bg-gray-50">
                                              <td className="px-4 py-3 text-sm text-gray-900">
                                                {detailIndex === 0 ? (
                                                  <span className="font-medium">
                                                    {besoinEpp.structureAdministrativeLibelle || besoinEpp.structureLibelle || 'EPP Non défini'}
                                                  </span>
                                                ) : null}
                                              </td>
                                              <td className="px-4 py-3 text-sm text-gray-900">
                                                {detailEpp.matiereLibelle || detailEpp.matiereCode || `Matière ${matiereId}`}
                                                {detailEpp.matiereCode && (
                                                  <span className="text-xs text-gray-500 ml-1">({detailEpp.matiereCode})</span>
                                                )}
                                              </td>
                                              <td className="px-4 py-3 text-sm text-right text-gray-700">
                                                {quantiteNetEpp.toLocaleString()}
                                              </td>
                                              <td className="px-4 py-3 text-sm text-right text-gray-700">
                                                {quantiteConsolideeEpp.toLocaleString()}
                                              </td>
                                              <td className="px-4 py-3 text-sm text-right">
                                                <span className={`font-medium ${
                                                  quantiteApprouveeEpp > 0 ? 'text-green-700' : 'text-gray-500'
                                                }`}>
                                                  {quantiteApprouveeEpp.toLocaleString()}
                                                </span>
                                                {detailEpp.quantiteApprouvee && detailEpp.quantiteApprouvee > 0 && (
                                                  <span className="ml-1 text-xs text-purple-600" title="Exception EPP">
                                                    ⭐
                                                  </span>
                                                )}
                                              </td>
                                            </tr>
                                          )
                                        })
                                      })}
                                    </tbody>
                                    {/* ✅ Résumé agrégé */}
                                    <tfoot className="bg-gray-50">
                                      <tr>
                                        <td colSpan={2} className="px-4 py-3 text-sm font-medium text-gray-900">
                                          Total
                                        </td>
                                        <td className="px-4 py-3 text-sm text-right font-medium text-gray-900">
                                          {eppBesoinsAssocies.reduce((sum, b) => 
                                            sum + (b.besoinDetails || []).reduce((s: number, d: any) => s + (d.quantiteNet || 0), 0), 0
                                          ).toLocaleString()}
                                        </td>
                                        <td className="px-4 py-3 text-sm text-right font-medium text-gray-900">
                                          {eppBesoinsAssocies.reduce((sum, b) => 
                                            sum + (b.besoinDetails || []).reduce((s: number, d: any) => s + (d.quantiteConsolidee || 0), 0), 0
                                          ).toLocaleString()}
                                        </td>
                                        <td className="px-4 py-3 text-sm text-right font-medium text-green-700">
                                          {(() => {
                                            // Calculer le total des quantités approuvées EPP
                                            let total = 0
                                            const detailsIepp = selectedBesoin.besoinDetails || []
                                            const quantitesApprouveesIepp = new Map<number, number>()
                                            const quantitesConsolideesIepp = new Map<number, number>()
                                            
                                            detailsIepp.forEach((detail: any) => {
                                              if (detail.matiereId) {
                                                quantitesApprouveesIepp.set(detail.matiereId, detail.quantiteApprouvee || 0)
                                                quantitesConsolideesIepp.set(detail.matiereId, detail.quantiteConsolidee || 0)
                                              }
                                            })
                                            
                                            const totalConsolide = Array.from(quantitesConsolideesIepp.values()).reduce((sum, qty) => sum + qty, 0)
                                            
                                            eppBesoinsAssocies.forEach((besoinEpp: any) => {
                                              (besoinEpp.besoinDetails || []).forEach((detailEpp: any) => {
                                                const matiereId = detailEpp.matiereId
                                                const quantiteNetEpp = detailEpp.quantiteNet || 0
                                                const quantiteApprouveeIepp = quantitesApprouveesIepp.get(matiereId) || 0
                                                const quantiteConsolideeIepp = quantitesConsolideesIepp.get(matiereId) || 0
                                                
                                                if (detailEpp.quantiteApprouvee && detailEpp.quantiteApprouvee > 0) {
                                                  total += detailEpp.quantiteApprouvee
                                                } else if (quantiteConsolideeIepp > 0 && totalConsolide > 0) {
                                                  total += Math.round(((quantiteNetEpp / quantiteConsolideeIepp) * quantiteApprouveeIepp))
                                                }
                                              })
                                            })
                                            
                                            return total.toLocaleString()
                                          })()}
                                        </td>
                                      </tr>
                                    </tfoot>
                                  </table>
                                </div>
                                
                                {/* Note informative */}
                                <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
                                  <p className="text-xs text-blue-800">
                                    <span className="font-semibold">💡 Note :</span> Les quantités approuvées EPP sont calculées proportionnellement depuis le besoin IEPP approuvé. 
                                    Les exceptions EPP (⭐) ont priorité sur le calcul proportionnel.
                                  </p>
                                </div>
                              </div>
                            ) : (
                              <p className="text-sm text-gray-500 text-center py-4">
                                Aucun besoin EPP associé trouvé
                              </p>
                            )}
                          </div>
                        )}
                        
                        {selectedBesoin.niveaux && selectedBesoin.niveaux.length > 0 ? (
                          /* Format local avec niveaux */
                          selectedBesoin.niveaux.map((niveau: any, index: number) => (
                            <div key={index} className="border rounded-lg p-4">
                              <div className="flex justify-between items-center mb-3">
                                <h5 className="font-medium text-gray-900">{niveau.niveau}</h5>
                                <div className="text-sm text-gray-600">
                                  {niveau.effectif_total} élèves
                                </div>
                              </div>
                              <div className="space-y-2">
                                {niveau.manuels && niveau.manuels.map((manuel: any, manuelIndex: number) => (
                                  <div key={manuelIndex} className="flex justify-between items-center py-2 border-b border-gray-100">
                                    <span className="text-sm text-gray-700">{manuel.titre}</span>
                                    <span className="text-sm font-medium text-gray-900">{manuel.quantite} exemplaires</span>
                                  </div>
                                ))}
                              </div>
                            </div>
                          ))
                        ) : !(selectedBesoin.besoinDetails && selectedBesoin.besoinDetails.length > 0) ? (
                          <p className="text-sm text-gray-500 italic">Aucun détail disponible</p>
                        ) : null}
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-6">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700">Structure</label>
                        <p className="mt-1 text-sm text-gray-900">
                          {user.structure?.libelle || "Structure non définie"}
                        </p>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700">Année Scolaire</label>
                        <p className="mt-1 text-sm text-gray-900">2024-2025</p>
                      </div>
                    </div>

                    <div>
                      <div className="flex justify-between items-center mb-4">
                        <h4 className="text-md font-medium text-gray-900">Niveaux et Effectifs</h4>
                        <button
                          onClick={addNiveau}
                          className="bg-orange-600 hover:bg-orange-700 text-white px-3 py-1 rounded text-sm"
                        >
                          Ajouter un niveau
                        </button>
                      </div>
                      
                      <div className="space-y-4">
                        {formData.niveaux.map((niveau, index) => (
                          <div key={index} className="border rounded-lg p-4">
                            <div className="flex justify-between items-center mb-4">
                              <div className="flex items-center space-x-4">
                                <div>
                                  <label className="block text-sm font-medium text-gray-700">Niveau</label>
                                  <select
                                    value={niveau.niveau}
                                    onChange={(e) => updateNiveau(index, "niveau", e.target.value)}
                                    className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-orange-500 focus:border-orange-500"
                                  >
                                    <option value="CP1">CP1</option>
                                    <option value="CP2">CP2</option>
                                    <option value="CE1">CE1</option>
                                    <option value="CE2">CE2</option>
                                    <option value="CM1">CM1</option>
                                    <option value="CM2">CM2</option>
                                  </select>
                                </div>
                                <div>
                                  <label className="block text-sm font-medium text-gray-700">Nombre d'élèves</label>
                                  <input
                                    type="number"
                                    min={0}
                                    value={niveau.effectif_total}
                                    onChange={(e) => updateNiveau(index, "effectif_total", parseInt(e.target.value) || 0)}
                                    className="mt-1 block w-28 border-gray-300 rounded-md shadow-sm focus:ring-orange-500 focus:border-orange-500"
                                  />
                                </div>
                              </div>
                              {formData.niveaux.length > 1 && (
                                <button
                                  onClick={() => removeNiveau(index)}
                                  className="text-red-600 hover:text-red-800"
                                >
                                  <TrashIcon className="h-5 w-5" />
                                </button>
                              )}
                            </div>

                            <div>
                              <div className="flex justify-between items-center mb-2">
                                <h5 className="text-sm font-medium text-gray-700">Manuels</h5>
                                <button
                                  onClick={() => addManuel(index)}
                                  className="text-orange-600 hover:text-orange-800 text-sm"
                                >
                                  Ajouter un manuel
                                </button>
                              </div>
                              <div className="space-y-2">
                                {niveau.manuels.map((manuel: any, manuelIndex: number) => (
                                  <div key={manuelIndex} className="flex items-center space-x-2">
                                    <select
                                      value={manuel.titre}
                                      onChange={(e) => updateManuelTitre(index, manuelIndex, e.target.value)}
                                      className="flex-1 border-gray-300 rounded-md shadow-sm focus:ring-orange-500 focus:border-orange-500 text-sm"
                                    >
                                      <option value="">Sélectionner un manuel</option>
                                      {manuelsDisponibles[niveau.niveau as keyof typeof manuelsDisponibles]?.map((titre) => (
                                        <option key={titre} value={titre}>
                                          {titre}
                                        </option>
                                      ))}
                                    </select>
                                    <input
                                      type="number"
                                      value={manuel.quantite}
                                      onChange={(e) => updateManuelQuantite(index, manuelIndex, parseInt(e.target.value) || 0)}
                                      className="w-20 border-gray-300 rounded-md shadow-sm focus:ring-orange-500 focus:border-orange-500 text-sm"
                                      placeholder="Qté"
                                    />
                                    <button
                                      onClick={() => removeManuel(index, manuelIndex)}
                                      className="text-red-600 hover:text-red-800"
                                    >
                                      <TrashIcon className="h-4 w-4" />
                                    </button>
                                  </div>
                                ))}
                              </div>
                              {/* Récupérations automatiques & calculs */}
                              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mt-4">
                                <div>
                                  <label className="block text-xs font-medium text-gray-600">Récupérations bon état (auto)</label>
                                  <input
                                    type="number"
                                    value={niveau.retours_auto?.bon_etat || 0}
                                    disabled
                                    className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-orange-500 focus:border-orange-500 text-sm bg-gray-50"
                                  />
                                </div>
                                <div>
                                  <label className="block text-xs font-medium text-gray-600">Récupérations moy. endommagées (auto)</label>
                                  <input
                                    type="number"
                                    value={niveau.retours_auto?.moyen_etat || 0}
                                    disabled
                                    className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-orange-500 focus:border-orange-500 text-sm bg-gray-50"
                                  />
                                </div>
                              </div>
                              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mt-2">
                                <div>
                                  <label className="block text-xs font-medium text-gray-600">Coef. réparable (0-1)</label>
                                  <input
                                    type="number"
                                    step="0.1"
                                    min="0"
                                    max="1"
                                    value={typeof niveau.coef_reparable === "number" ? niveau.coef_reparable : 0.7}
                                    onChange={(e) => updateNiveau(index, "coef_reparable", parseFloat(e.target.value))}
                                    className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-orange-500 focus:border-orange-500 text-sm"
                                  />
                                </div>
                                <div>
                                  <label className="block text-xs font-medium text-gray-600">Total récupérations</label>
                                  <input
                                    type="number"
                                    value={niveau.retours_auto?.total_retournes || 0}
                                    disabled
                                    className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-orange-500 focus:border-orange-500 text-sm bg-gray-50"
                                  />
                                </div>
                              </div>
                              <div className="mt-3 text-xs text-gray-600">
                                {(() => {
                                  const m = computeNiveauMetrics(niveau)
                                  return (
                                    <div className="flex flex-wrap gap-4">
                                      <span><span className="font-medium">Besoins brut:</span> {m.besoinBrut.toLocaleString()}</span>
                                      <span><span className="font-medium">Stock dispo:</span> {m.stockDispo.toLocaleString()}</span>
                                      <span><span className="font-medium">Besoins net:</span> {m.besoinNet.toLocaleString()}</span>
                                    </div>
                                  )
                                })()}
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                )}
              </div>

              <div className="px-6 py-4 border-t border-gray-200 flex justify-end space-x-3">
                <button
                  onClick={() => setShowModal(false)}
                  className="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-50"
                >
                  Annuler
                </button>
                {modalType !== "view" && !consultationOnly && (
                  <button
                    onClick={handleSaveBesoin}
                    className="px-4 py-2 bg-orange-600 hover:bg-orange-700 text-white rounded-md text-sm font-medium"
                  >
                    {modalType === "new" ? "Créer" : "Enregistrer"}
                  </button>
                )}
              </div>
            </div>
          </div>
        )}

        {/* ✅ NOUVEAU : Modal pour le formulaire BesoinForm */}
        {showBesoinForm && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 overflow-y-auto">
            <div className="bg-white rounded-lg shadow-xl max-w-6xl w-full mx-4 my-8">
              <BesoinForm
                onSubmit={handleBesoinFormSubmit}
                onCancel={() => {
                  setShowBesoinForm(false)
                  setBesoinToEdit(null)
                }}
                loading={loadingBesoins}
                userStructure={user?.structure}
                besoinExistant={besoinToEdit || undefined}
                mode={besoinToEdit ? 'edit' : 'create'}
              />
            </div>
          </div>
        )}

        {/* Modal pour les détails */}
        {showDetailsModal && selectedDetails && (() => {
          console.log('🔵 [MODAL-RENDER] ========== MODAL RENDU ==========')
          console.log('🔵 [MODAL-RENDER] showDetailsModal:', showDetailsModal)
          console.log('🔵 [MODAL-RENDER] selectedDetails:', JSON.stringify(selectedDetails, null, 2))
          console.log('🔵 [MODAL-RENDER] selectedDetails.besoins:', selectedDetails.besoins)
          console.log('🔵 [MODAL-RENDER] selectedDetails.besoins?.length:', selectedDetails.besoins?.length)
          return null
        })()}
        {showDetailsModal && selectedDetails && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white rounded-lg shadow-xl max-w-4xl w-full mx-4 max-h-[90vh] overflow-y-auto">
              <div className="px-6 py-4 border-b border-gray-200">
                <div className="flex justify-between items-center">
                  <h3 className="text-lg font-medium text-gray-900">
                    {detailsType === "iepp" ? "Détails IEPP" : "Détails DRENA"} - {selectedDetails.iepp || selectedDetails.drena}
                  </h3>
                  <button
                    onClick={() => setShowDetailsModal(false)}
                    className="text-gray-400 hover:text-gray-600"
                  >
                    <XMarkIcon className="h-6 w-6" />
                  </button>
                </div>
              </div>

              <div className="p-6">
                {detailsType === "iepp" ? (
                  <div className="space-y-6">
                    <div className="grid grid-cols-2 gap-6">
                      <div>
                        <label className="block text-sm font-medium text-gray-700">IEPP</label>
                        <p className="mt-1 text-sm text-gray-900">{selectedDetails.iepp}</p>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700">DRENA</label>
                        <p className="mt-1 text-sm text-gray-900">{selectedDetails.drena}</p>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700">Statut</label>
                        <div className="mt-1">
                          {getStatusBadge(selectedDetails.statut)}
                        </div>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700">Date de Consolidation</label>
                        <p className="mt-1 text-sm text-gray-900">
                          {selectedDetails.date_consolidation || "Non consolidé"}
                        </p>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700">Nombre d'EPP</label>
                        <p className="mt-1 text-sm text-gray-900">{selectedDetails.epp_count}</p>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700">Total Effectifs</label>
                        <p className="mt-1 text-sm text-gray-900">{selectedDetails.total_effectifs?.toLocaleString()}</p>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700">Total Manuels</label>
                        <p className="mt-1 text-sm text-gray-900">{selectedDetails.total_manuels?.toLocaleString()}</p>
                      </div>
                    </div>

                    <div>
                      <h4 className="text-md font-medium text-gray-900 mb-4">Besoins par EPP</h4>
                      <div className="overflow-x-auto">
                        <table className="min-w-full divide-y divide-gray-200">
                          <thead className="bg-gray-50">
                            <tr>
                              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                EPP
                              </th>
                              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Effectifs
                              </th>
                              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Manuels
                              </th>
                              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Statut
                              </th>
                              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Actions
                              </th>
                            </tr>
                          </thead>
                          <tbody className="bg-white divide-y divide-gray-200">
                            {(() => {
                              console.log('🔵 [MODAL] Affichage du tableau - selectedDetails:', JSON.stringify(selectedDetails, null, 2))
                              console.log('🔵 [MODAL] selectedDetails.besoins:', selectedDetails.besoins)
                              console.log('🔵 [MODAL] selectedDetails.besoins?.length:', selectedDetails.besoins?.length)
                              return null
                            })()}
                            {selectedDetails.besoins && selectedDetails.besoins.length > 0 ? (
                              selectedDetails.besoins.map((besoin: any, index: number) => {
                                console.log('🔵 [MODAL] Affichage besoin EPP:', besoin.epp)
                                console.log('🔵 [MODAL] besoin.matieres:', besoin.matieres)
                                console.log('🔵 [MODAL] besoin.rawData?.besoinDetails:', besoin.rawData?.besoinDetails)
                                
                                const isExpanded = expandedBesoinIndices.has(index)
                                const toggleExpand = () => {
                                  setExpandedBesoinIndices(prev => {
                                    const next = new Set(prev)
                                    if (next.has(index)) next.delete(index)
                                    else next.add(index)
                                    return next
                                  })
                                }
                                const canRenvoyer = besoin.statut === "VALIDE" && selectedDetails?.statut !== "CONSOLIDE"
                                const statutEppRow = String(besoin.statut || "").toUpperCase()
                                const isApprouveAffichage = ["APPROUVE", "VALIDE_NATIONAL", "VALIDE_DAF"].includes(statutEppRow)
                                /** Quantité pour regroupements / libellés : en APPROUVE, priorité absolue à quantiteApprouvee (y compris 0). */
                                const qMat = (m: any) => {
                                  if (isApprouveAffichage) {
                                    const qa = m.quantiteApprouvee ?? m.quantite_approuvee
                                    if (qa !== null && qa !== undefined && !Number.isNaN(Number(qa))) {
                                      return Number(qa)
                                    }
                                  }
                                  return Number(
                                    m.quantiteConsolidee ??
                                      m.quantite_consolidee ??
                                      m.quantiteApprouvee ??
                                      m.quantite_approuvee ??
                                      m.quantiteBrute ??
                                      m.quantite_brute ??
                                      m.quantiteNet ??
                                      m.quantite_net ??
                                      0,
                                  )
                                }
                                const matieresParNiveau = (besoin.matieres || []).reduce((acc: Record<string, any[]>, m: any) => {
                                  const niv = m.niveauScolaireLibelle || m.niveauScolaireCode || "Sans niveau"
                                  if (!acc[niv]) acc[niv] = []
                                  acc[niv].push(m)
                                  return acc
                                }, {})
                                return (
                                  <>
                                    <tr key={index} className="hover:bg-gray-50">
                                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                                        {besoin.epp}
                                      </td>
                                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                        {besoin.effectifs?.toLocaleString()}
                                      </td>
                                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                        {besoin.manuels?.toLocaleString()}
                                      </td>
                                      <td className="px-6 py-4 whitespace-nowrap">
                                        {getStatusBadge(besoin.statut)}
                                      </td>
                                      <td className="px-6 py-4 whitespace-nowrap">
                                        <div className="flex items-center gap-2">
                                          <button
                                            onClick={toggleExpand}
                                            className="inline-flex items-center gap-1 text-sm text-orange-600 hover:text-orange-800 font-medium"
                                          >
                                            {isExpanded ? <ChevronDownIcon className="h-4 w-4" /> : <ChevronRightIcon className="h-4 w-4" />}
                                            Matières et quantités
                                          </button>
                                          {canRenvoyer && !consultationOnly && (
                                            <button
                                              onClick={() => handleRenvoyerPourCorrection(besoin)}
                                              disabled={renvoyerLoading === (besoin.rawData?.id)}
                                              className="inline-flex items-center gap-1 text-sm text-amber-600 hover:text-amber-800 font-medium disabled:opacity-50"
                                              title="Renvoyer pour correction"
                                            >
                                              <ArrowUturnLeftIcon className="h-4 w-4" />
                                              Renvoyer
                                            </button>
                                          )}
                                        </div>
                                      </td>
                                    </tr>
                                    {isExpanded && (
                                      <tr key={`${index}-details`} className="bg-orange-50/50">
                                        <td colSpan={5} className="px-6 py-4">
                                          <div className="ml-4 space-y-4">
                                            <h5 className="text-sm font-semibold text-orange-800">
                                              Matières et quantités par niveau
                                            </h5>
                                            {Object.keys(matieresParNiveau).length > 0 ? (
                                              (Object.entries(matieresParNiveau) as [string, any[]][]).map(([niveau, matieres]) => (
                                                <div key={niveau} className="border-2 border-orange-200 rounded-lg p-3 bg-white">
                                                  <div className="text-sm font-semibold text-orange-800 mb-2">{niveau}</div>
                                                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2">
                                                    {matieres.map((matiere: any, matIndex: number) => (
                                                      <div key={matIndex} className="p-2 rounded border border-orange-100 bg-orange-50/30">
                                                        <div className="text-sm font-medium text-gray-900">
                                                          {matiere.matiereLibelle || matiere.matiereCode || "Matière"}
                                                        </div>
                                                        <div className="text-xs text-gray-600 mt-1">
                                                          {isApprouveAffichage ? (
                                                            <>
                                                              Quantité approuvée:{" "}
                                                              <span className="font-semibold">
                                                                {matiere.quantiteApprouvee != null && !Number.isNaN(Number(matiere.quantiteApprouvee))
                                                                  ? Number(matiere.quantiteApprouvee)
                                                                  : (matiere.quantiteConsolidee ?? qMat(matiere) ?? 0)}
                                                              </span>
                                                              {(matiere.quantiteNet != null || matiere.quantiteBrute != null) && (
                                                                <>
                                                                  {" · "}Besoin net:{" "}
                                                                  <span className="font-medium text-gray-500">
                                                                    {Number(matiere.quantiteNet ?? matiere.quantiteBrute ?? 0)}
                                                                  </span>
                                                                </>
                                                              )}
                                                            </>
                                                          ) : (
                                                            <>
                                                              Quantité consolidée:{" "}
                                                              <span className="font-semibold">{matiere.quantiteConsolidee ?? qMat(matiere) ?? 0}</span>
                                                              {" · "}Nette:{" "}
                                                              <span className="font-semibold">
                                                                {matiere.quantiteNet ?? matiere.quantiteBrute ?? qMat(matiere) ?? 0}
                                                              </span>
                                                            </>
                                                          )}
                                                        </div>
                                                      </div>
                                                    ))}
                                                  </div>
                                                </div>
                                              ))
                                            ) : (
                                              <p className="text-sm text-gray-500">Aucune matière trouvée pour cet EPP.</p>
                                            )}
                                          </div>
                                        </td>
                                      </tr>
                                    )}
                                    {!isExpanded && besoin.matieres && besoin.matieres.length === 0 && (
                                      <tr key={`${index}-no-matiere`} className="bg-yellow-50">
                                        <td colSpan={5} className="px-6 py-4 text-sm text-yellow-700">
                                          ⚠️ Aucune matière trouvée pour cet EPP.
                                        </td>
                                      </tr>
                                    )}
                                  </>
                                )
                              })
                            ) : (
                              <tr>
                                <td colSpan={4} className="px-6 py-4 text-center text-sm text-gray-500">
                                  Aucun besoin EPP validé trouvé pour cette consolidation
                                </td>
                              </tr>
                            )}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-6">
                    <div className="grid grid-cols-2 gap-6">
                      <div>
                        <label className="block text-sm font-medium text-gray-700">DRENA</label>
                        <p className="mt-1 text-sm text-gray-900">{selectedDetails.drena}</p>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700">Statut</label>
                        <div className="mt-1">
                          {getStatusBadge(selectedDetails.statut)}
                        </div>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700">Date de Consolidation</label>
                        <p className="mt-1 text-sm text-gray-900">
                          {selectedDetails.date_consolidation || "Non consolidé"}
                        </p>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700">Nombre d'IEPP</label>
                        <p className="mt-1 text-sm text-gray-900">{selectedDetails.iepp_count}</p>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700">Total Effectifs</label>
                        <p className="mt-1 text-sm text-gray-900">{selectedDetails.total_effectifs?.toLocaleString()}</p>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700">Total Manuels</label>
                        <p className="mt-1 text-sm text-gray-900">{selectedDetails.total_manuels?.toLocaleString()}</p>
                      </div>
                    </div>

                    <div>
                      <h4 className="text-md font-medium text-gray-900 mb-4">Consolidations par IEPP</h4>
                      <div className="overflow-x-auto">
                        <table className="min-w-full divide-y divide-gray-200">
                          <thead className="bg-gray-50">
                            <tr>
                              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                IEPP
                              </th>
                              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Effectifs
                              </th>
                              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Manuels
                              </th>
                              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Statut
                              </th>
                            </tr>
                          </thead>
                          <tbody className="bg-white divide-y divide-gray-200">
                            {selectedDetails.consolidations_iepp?.map((consolidation: any, index: number) => (
                              <tr key={index} className="hover:bg-gray-50">
                                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                                  {consolidation.iepp}
                                </td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                  {consolidation.effectifs?.toLocaleString()}
                                </td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                  {consolidation.manuels?.toLocaleString()}
                                </td>
                                <td className="px-6 py-4 whitespace-nowrap">
                                  {getStatusBadge(consolidation.statut)}
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              <div className="px-6 py-4 border-t border-gray-200 flex justify-end">
                <button
                  onClick={() => setShowDetailsModal(false)}
                  className="px-4 py-2 bg-gray-600 hover:bg-gray-700 text-white rounded-md text-sm font-medium"
                >
                  Fermer
                </button>
              </div>
            </div>
          </div>
        )}

        {/* ✅ NOUVEAU : Modal d'approbation DAF avec taux global et modifications manuelles */}
        <ApprouverBesoinModal
          isOpen={showApprouverModal}
          onClose={() => {
            setShowApprouverModal(false)
            setBesoinsToApprove([])
            setApprovalExcelPrefill(null)
          }}
          besoinIds={besoinsToApprove}
          onApprove={handleApproveConfirm}
          besoins={besoins.filter((b: any) => besoinsToApprove.includes(b._rawData?.id || b.id))}
          excelPrefill={approvalExcelPrefill}
          onExcelPrefillConsumed={clearApprovalExcelPrefill}
        />

        <Dialog open={pendingApprovalExcelImport !== null} onOpenChange={onPendingApprovalExcelDialogOpenChange}>
          <DialogContent className="max-h-[min(92vh,720px)] max-w-2xl gap-0 overflow-hidden border-slate-300 p-0 shadow-xl sm:max-w-2xl">
            <DialogHeader className="border-b border-amber-300 bg-amber-100 px-6 py-5 text-left">
              <DialogTitle className="text-xl font-semibold tracking-tight text-amber-950">
                Avertissements à l’import Excel
              </DialogTitle>
              <DialogDescription asChild>
                <p className="mt-2 text-[15px] font-normal leading-relaxed text-amber-950">
                  Le fichier a été analysé, mais le serveur a corrigé certaines quantités (par exemple ramenées au net
                  EPP ou au consolidé IEPP). La quantité approuvée ne peut pas dépasser la quantité demandée (net EPP ou
                  consolidé IEPP). Vous pouvez ouvrir l’approbation avec les valeurs corrigées, ou annuler puis modifier
                  le fichier et réimporter.
                </p>
              </DialogDescription>
            </DialogHeader>
            <div className="max-h-[min(50vh,420px)] overflow-y-auto bg-white px-6 py-4">
              <p className="mb-4 text-sm font-medium leading-snug text-slate-800">
                Détail par ligne concernée (le numéro indiqué dans le texte est la ligne dans la feuille Excel, sous
                l’en-tête) :
              </p>
              <ul className="space-y-3">
                {(pendingApprovalExcelImport?.warnings ?? []).map((line, i) => (
                  <li
                    key={i}
                    className="flex gap-3 rounded-lg border border-slate-200 bg-slate-50 px-4 py-3.5 text-[15px] leading-relaxed text-gray-900 shadow-sm"
                  >
                    <span
                      className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-amber-600 text-sm font-bold text-white"
                      aria-hidden
                    >
                      {i + 1}
                    </span>
                    <span className="min-w-0 flex-1 break-words">{line}</span>
                  </li>
                ))}
              </ul>
            </div>
            <DialogFooter className="border-t border-slate-200 bg-slate-50 px-6 py-4">
              <button
                type="button"
                onClick={cancelPendingApprovalExcelImport}
                className="inline-flex items-center justify-center rounded-md border border-slate-300 bg-white px-4 py-2 text-sm font-medium text-slate-700 shadow-sm hover:bg-slate-50"
              >
                Annuler l’import
              </button>
              <button
                type="button"
                onClick={confirmPendingApprovalExcelImport}
                className="inline-flex items-center justify-center rounded-md border border-transparent bg-blue-600 px-4 py-2 text-sm font-medium text-white shadow-sm hover:bg-blue-700"
              >
                Continuer vers l’approbation
              </button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </MainLayout>
  )
} 