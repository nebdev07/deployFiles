'use client'

import { useEffect } from 'react'
import { logger } from '@/lib/utils/logger'

/**
 * Page de test pour vérifier la désactivation des logs en production
 * 
 * À supprimer avant le déploiement final !
 */
export default function TestLoggingPage() {
  useEffect(() => {
    // Test du logger
    logger.log('🔍 TEST: logger.log() - NE DEVRAIT PAS APPARAÎTRE EN PRODUCTION')
    logger.info('ℹ️ TEST: logger.info() - NE DEVRAIT PAS APPARAÎTRE EN PRODUCTION')
    logger.warn('⚠️ TEST: logger.warn() - NE DEVRAIT PAS APPARAÎTRE EN PRODUCTION')
    logger.error('❌ TEST: logger.error() - DEVRAIT APPARAÎTRE MÊME EN PRODUCTION')
    
    // Test des console directs (devraient être overridés en production)
    console.log('📝 TEST: console.log() direct - NE DEVRAIT PAS APPARAÎTRE EN PRODUCTION')
    console.warn('⚠️ TEST: console.warn() direct - NE DEVRAIT PAS APPARAÎTRE EN PRODUCTION')
    console.error('❌ TEST: console.error() direct - DEVRAIT APPARAÎTRE EN PRODUCTION')
    
    // Afficher la configuration du logger
    const config = logger.getConfig()
    console.log('⚙️ Configuration Logger:', config)
  }, [])

  const config = logger.getConfig()

  return (
    <div className="min-h-screen bg-gray-50 p-8">
      <div className="max-w-4xl mx-auto">
        <div className="bg-white rounded-lg shadow-lg p-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-6">
            🧪 Test de Logging
          </h1>

          <div className="space-y-6">
            {/* Configuration actuelle */}
            <div className="border-l-4 border-blue-500 bg-blue-50 p-4">
              <h2 className="text-xl font-semibold text-blue-900 mb-3">
                ⚙️ Configuration Actuelle
              </h2>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="font-medium">Environment:</span>
                  <span className="font-mono bg-white px-2 py-1 rounded">
                    {process.env.NODE_ENV || 'development'}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="font-medium">Mode Développement:</span>
                  <span className={`font-bold ${config.isDevelopment ? 'text-green-600' : 'text-red-600'}`}>
                    {config.isDevelopment ? '✅ OUI' : '❌ NON'}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="font-medium">Mode Production:</span>
                  <span className={`font-bold ${config.isProduction ? 'text-red-600' : 'text-green-600'}`}>
                    {config.isProduction ? '⚠️ OUI' : '✅ NON'}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="font-medium">Logs Activés:</span>
                  <span className={`font-bold ${config.enabled ? 'text-green-600' : 'text-red-600'}`}>
                    {config.enabled ? '✅ OUI' : '❌ NON'}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="font-medium">Erreurs en Production:</span>
                  <span className={`font-bold ${config.allowProductionErrors ? 'text-green-600' : 'text-red-600'}`}>
                    {config.allowProductionErrors ? '✅ OUI' : '❌ NON'}
                  </span>
                </div>
              </div>
            </div>

            {/* Instructions */}
            <div className="border-l-4 border-yellow-500 bg-yellow-50 p-4">
              <h2 className="text-xl font-semibold text-yellow-900 mb-3">
                📋 Instructions de Test
              </h2>
              <ol className="list-decimal list-inside space-y-2 text-sm text-yellow-900">
                <li>Ouvrez la <strong>Console du Navigateur</strong> (F12)</li>
                <li>Vérifiez les logs affichés ci-dessus</li>
                <li>Comparez avec les résultats attendus ci-dessous</li>
              </ol>
            </div>

            {/* Résultats attendus - Développement */}
            <div className={`border-l-4 ${config.isDevelopment ? 'border-green-500 bg-green-50' : 'border-gray-300 bg-gray-50'} p-4`}>
              <h2 className="text-xl font-semibold mb-3">
                🟢 Résultats Attendus en DÉVELOPPEMENT
              </h2>
              <div className="space-y-1 text-sm font-mono">
                <div className="flex items-center">
                  <span className="text-green-600 mr-2">✅</span>
                  <span>logger.log() → Affiché</span>
                </div>
                <div className="flex items-center">
                  <span className="text-green-600 mr-2">✅</span>
                  <span>logger.info() → Affiché</span>
                </div>
                <div className="flex items-center">
                  <span className="text-green-600 mr-2">✅</span>
                  <span>logger.warn() → Affiché</span>
                </div>
                <div className="flex items-center">
                  <span className="text-green-600 mr-2">✅</span>
                  <span>logger.error() → Affiché</span>
                </div>
                <div className="flex items-center">
                  <span className="text-green-600 mr-2">✅</span>
                  <span>console.log() → Affiché</span>
                </div>
                <div className="flex items-center">
                  <span className="text-green-600 mr-2">✅</span>
                  <span>console.warn() → Affiché</span>
                </div>
                <div className="flex items-center">
                  <span className="text-green-600 mr-2">✅</span>
                  <span>console.error() → Affiché</span>
                </div>
              </div>
            </div>

            {/* Résultats attendus - Production */}
            <div className={`border-l-4 ${config.isProduction ? 'border-red-500 bg-red-50' : 'border-gray-300 bg-gray-50'} p-4`}>
              <h2 className="text-xl font-semibold mb-3">
                🔴 Résultats Attendus en PRODUCTION
              </h2>
              <div className="space-y-1 text-sm font-mono">
                <div className="flex items-center">
                  <span className="text-red-600 mr-2">❌</span>
                  <span>logger.log() → <strong>Silencieux</strong></span>
                </div>
                <div className="flex items-center">
                  <span className="text-red-600 mr-2">❌</span>
                  <span>logger.info() → <strong>Silencieux</strong></span>
                </div>
                <div className="flex items-center">
                  <span className="text-red-600 mr-2">❌</span>
                  <span>logger.warn() → <strong>Silencieux</strong></span>
                </div>
                <div className="flex items-center">
                  <span className="text-green-600 mr-2">✅</span>
                  <span>logger.error() → <strong>Affiché</strong> (monitoring)</span>
                </div>
                <div className="flex items-center">
                  <span className="text-red-600 mr-2">🚫</span>
                  <span>console.log() → <strong>BLOQUÉ (override)</strong></span>
                </div>
                <div className="flex items-center">
                  <span className="text-red-600 mr-2">🚫</span>
                  <span>console.warn() → <strong>BLOQUÉ (override)</strong></span>
                </div>
                <div className="flex items-center">
                  <span className="text-green-600 mr-2">✅</span>
                  <span>console.error() → <strong>Affiché</strong> (si allowProductionErrors=true)</span>
                </div>
              </div>
            </div>

            {/* Actions */}
            <div className="border-t pt-6">
              <h2 className="text-xl font-semibold text-gray-900 mb-4">
                🎯 Actions de Test
              </h2>
              <div className="space-y-3">
                <button
                  onClick={() => {
                    logger.log('Test manuel: logger.log()')
                    logger.warn('Test manuel: logger.warn()')
                    logger.error('Test manuel: logger.error()')
                  }}
                  className="w-full bg-blue-600 text-white px-4 py-3 rounded-lg hover:bg-blue-700 transition"
                >
                  🧪 Tester logger.*
                </button>
                
                <button
                  onClick={() => {
                    console.log('Test manuel: console.log()')
                    console.warn('Test manuel: console.warn()')
                    console.error('Test manuel: console.error()')
                  }}
                  className="w-full bg-purple-600 text-white px-4 py-3 rounded-lg hover:bg-purple-700 transition"
                >
                  🧪 Tester console.*
                </button>
              </div>
            </div>

            {/* Warning */}
            <div className="border-l-4 border-orange-500 bg-orange-50 p-4">
              <h2 className="text-xl font-semibold text-orange-900 mb-2">
                ⚠️ Important
              </h2>
              <p className="text-sm text-orange-900">
                <strong>Supprimez cette page avant le déploiement final !</strong>
                <br />
                Elle est uniquement destinée aux tests de développement.
              </p>
              <pre className="mt-2 bg-orange-100 p-2 rounded text-xs overflow-x-auto">
                rm app/test-logging/page.tsx
              </pre>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}















