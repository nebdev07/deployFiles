"use client"

import { useCallback, useEffect, useMemo, useState } from "react"
import MainLayout from "../../components/layout/main-layout"
import { useAuth } from "../providers"
import { useAnneesScolaires } from "@/hooks/use-annees-scolaires"
import { useConsultationOnly } from "@/hooks/use-consultation-only"
import {
  rapportService,
  downloadRapportFile,
  RAPPORT_TYPE_OPTIONS,
  type RapportCodeType,
  type RapportRow,
} from "@/lib/services/rapport.service"
import toast from "react-hot-toast"
import { canAccessRapportsPage } from "@/lib/utils/functionality-permissions"
import {
  ChartBarIcon,
  ArrowDownTrayIcon,
  DocumentTextIcon,
  ArrowPathIcon,
} from "@heroicons/react/24/outline"

export default function RapportsPage() {
  const { user } = useAuth()
  const { consultationOnly } = useConsultationOnly()
  const { anneesScolaires, getAnneesScolaires, loading: loadingAnnees } = useAnneesScolaires()

  const [rapports, setRapports] = useState<RapportRow[]>([])
  const [loadingList, setLoadingList] = useState(false)
  const [count, setCount] = useState(0)

  const [showModal, setShowModal] = useState(false)
  const [generating, setGenerating] = useState(false)
  const [selectedAnneeId, setSelectedAnneeId] = useState<number | "">("")
  const [selectedCode, setSelectedCode] = useState<RapportCodeType>("SYNTHESE")
  const [format, setFormat] = useState<"XLSX" | "CSV">("XLSX")
  const [optionalStructureId, setOptionalStructureId] = useState<string>("")

  const role = (user?.role?.code ?? "").toUpperCase()
  const canFilterStructure = ["DAF", "ADMIN", "DPFC"].includes(role)

  const defaultAnneeId = useMemo(() => {
    const courante = anneesScolaires.find((a) => a.estCourante)
    if (courante?.id) return courante.id
    const first = anneesScolaires[0]
    return first?.id
  }, [anneesScolaires])

  useEffect(() => {
    if (selectedAnneeId === "" && defaultAnneeId) {
      setSelectedAnneeId(defaultAnneeId)
    }
  }, [defaultAnneeId, selectedAnneeId])

  const loadRapports = useCallback(async () => {
    setLoadingList(true)
    try {
      const res = await rapportService.list({ index: 0, size: 200 })
      if (res.hasError) {
        toast.error(res.status?.message || "Impossible de charger l’historique")
        setRapports([])
        setCount(0)
        return
      }
      const items = Array.isArray(res.items) ? res.items : []
      setRapports(items)
      const c = (res as unknown as { count?: number }).count
      setCount(typeof c === "number" ? c : items.length)
    } catch (e: unknown) {
      toast.error(e instanceof Error ? e.message : "Erreur réseau")
      setRapports([])
    } finally {
      setLoadingList(false)
    }
  }, [])

  useEffect(() => {
    void loadRapports()
  }, [loadRapports])

  const handleGenerer = async () => {
    if (consultationOnly) {
      toast.error("La génération de rapports n’est pas disponible en mode consultation.")
      return
    }
    if (generating) return
    if (selectedAnneeId === "") {
      toast.error("Choisissez une année scolaire.")
      return
    }
    setGenerating(true)
    try {
      const sidRaw = optionalStructureId.trim()
      const structureId =
        canFilterStructure && sidRaw !== "" ? Number.parseInt(sidRaw, 10) : undefined
      if (canFilterStructure && sidRaw !== "" && Number.isNaN(structureId)) {
        toast.error("Identifiant structure invalide.")
        setGenerating(false)
        return
      }

      const res = await rapportService.generate({
        codeType: selectedCode,
        anneeScolaireId: selectedAnneeId as number,
        structureId: structureId ?? null,
        format,
      })
      if (res.hasError) {
        toast.error(res.status?.message || "Échec de la génération")
        return
      }
      const row = Array.isArray(res.items) ? res.items[0] : undefined
      if (row?.fichierBase64 && row.nomFichier) {
        downloadRapportFile(row)
        toast.success("Rapport généré — téléchargement lancé.")
      } else {
        toast.success("Rapport enregistré.")
      }
      setShowModal(false)
      void loadRapports()
    } catch (e: unknown) {
      toast.error(e instanceof Error ? e.message : "Erreur")
    } finally {
      setGenerating(false)
    }
  }

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <p className="text-gray-600">Chargement...</p>
        </div>
      </div>
    )
  }

  if (!canAccessRapportsPage(user.role.code, user.functionalityPermissions)) {
    return (
      <MainLayout>
        <div className="text-center py-12">
          <h2 className="text-xl font-semibold text-gray-900 mb-2">Accès restreint</h2>
          <p className="text-gray-600">Vous n&apos;avez pas les droits pour les rapports (RAPPORT:READ).</p>
        </div>
      </MainLayout>
    )
  }

  return (
    <MainLayout>
      <div className="p-6 space-y-8 max-w-7xl mx-auto">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Rapports</h1>
            <p className="text-gray-600 mt-1">
              Exports par année scolaire (Excel ou CSV). Aucun rapport financier.
            </p>
          </div>
          {!consultationOnly && (
            <button
              type="button"
              onClick={() => setShowModal(true)}
              disabled={loadingList || generating}
              className="btn-primary inline-flex items-center gap-2 disabled:opacity-60"
            >
              <DocumentTextIcon className="h-5 w-5" />
              Générer un rapport
            </button>
          )}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="rounded-xl border border-gray-200 bg-white p-4 shadow-sm">
            <p className="text-sm text-gray-500">Rapports enregistrés</p>
            <p className="text-2xl font-semibold text-gray-900">{loadingList ? "…" : count}</p>
          </div>
          <div className="rounded-xl border border-gray-200 bg-white p-4 shadow-sm md:col-span-2">
            <p className="text-sm text-gray-700">
              Chaque export crée une trace dans l’historique (référence, titre, année). Le fichier est téléchargé
              immédiatement sur votre poste.
            </p>
          </div>
        </div>

        <div className="rounded-xl border border-gray-200 bg-white shadow-sm overflow-hidden">
          <div className="flex items-center justify-between px-4 py-3 border-b border-gray-100">
            <h2 className="text-lg font-semibold text-gray-900">Historique</h2>
            <button
              type="button"
              onClick={() => void loadRapports()}
              disabled={loadingList || generating}
              className="inline-flex items-center gap-1 text-sm text-indigo-600 hover:text-indigo-800 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <ArrowPathIcon className={`h-4 w-4 ${loadingList ? "animate-spin" : ""}`} />
              Actualiser
            </button>
          </div>
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Référence</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Titre</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Type</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Création</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100 bg-white">
                {loadingList && rapports.length === 0 ? (
                  <tr>
                    <td colSpan={4} className="px-4 py-8 text-center text-gray-500">
                      Chargement…
                    </td>
                  </tr>
                ) : rapports.length === 0 ? (
                  <tr>
                    <td colSpan={4} className="px-4 py-8 text-center text-gray-500">
                      Aucun rapport généré pour l’instant.
                    </td>
                  </tr>
                ) : (
                  rapports.map((r) => (
                    <tr key={r.id ?? r.reference} className="hover:bg-gray-50">
                      <td className="px-4 py-3 text-sm font-mono text-gray-800">{r.reference ?? "—"}</td>
                      <td className="px-4 py-3 text-sm text-gray-900">{r.titre ?? "—"}</td>
                      <td className="px-4 py-3 text-sm">
                        <span className="inline-flex rounded-full bg-indigo-50 px-2.5 py-0.5 text-xs font-medium text-indigo-800">
                          {r.typeRapport ?? "—"}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-sm text-gray-600">
                        {r.dateCreation ? new Date(r.dateCreation).toLocaleString("fr-FR") : "—"}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>

        {showModal && (
          <div className="modal-overlay" onClick={() => !generating && setShowModal(false)}>
            <div className="modal-content max-w-lg w-full" onClick={(e) => e.stopPropagation()}>
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold flex items-center gap-2">
                  <ChartBarIcon className="h-6 w-6 text-indigo-600" />
                  Nouveau rapport
                </h3>
                <button
                  type="button"
                  disabled={generating}
                  onClick={() => setShowModal(false)}
                  className="text-gray-400 hover:text-gray-600"
                >
                  ✕
                </button>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="form-label">Année scolaire</label>
                  <select
                    className="form-select w-full"
                    value={selectedAnneeId === "" ? "" : String(selectedAnneeId)}
                    onChange={(e) => setSelectedAnneeId(e.target.value ? Number(e.target.value) : "")}
                    disabled={loadingAnnees || generating}
                  >
                    {loadingAnnees && <option value="">Chargement…</option>}
                    {!loadingAnnees &&
                      anneesScolaires.map((a) => (
                        <option key={a.id} value={a.id ?? ""}>
                          {a.libelle || a.code || `Année ${a.id}`}
                        </option>
                      ))}
                  </select>
                </div>

                <div>
                  <label className="form-label">Type de rapport</label>
                  <select
                    className="form-select w-full"
                    value={selectedCode}
                    onChange={(e) => setSelectedCode(e.target.value as RapportCodeType)}
                    disabled={generating}
                  >
                    {RAPPORT_TYPE_OPTIONS.map((o) => (
                      <option key={o.code} value={o.code}>
                        {o.label}
                      </option>
                    ))}
                  </select>
                  <p className="text-xs text-gray-500 mt-1">
                    {RAPPORT_TYPE_OPTIONS.find((x) => x.code === selectedCode)?.description}
                  </p>
                </div>

                <div>
                  <label className="form-label">Format</label>
                  <div className="flex gap-4">
                    <label className="inline-flex items-center gap-2 cursor-pointer">
                      <input
                        type="radio"
                        name="fmt"
                        checked={format === "XLSX"}
                        onChange={() => setFormat("XLSX")}
                        disabled={generating}
                      />
                      Excel (.xlsx)
                    </label>
                    <label className="inline-flex items-center gap-2 cursor-pointer">
                      <input
                        type="radio"
                        name="fmt"
                        checked={format === "CSV"}
                        onChange={() => setFormat("CSV")}
                        disabled={generating}
                      />
                      CSV (séparateur ;)
                    </label>
                  </div>
                </div>

                {canFilterStructure && (
                  <div>
                    <label className="form-label">Structure (optionnel)</label>
                    <input
                      type="number"
                      min={1}
                      className="form-input w-full"
                      placeholder="ID structure administrative pour restreindre (laisser vide = national)"
                      value={optionalStructureId}
                      onChange={(e) => setOptionalStructureId(e.target.value)}
                      disabled={generating}
                    />
                    <p className="text-xs text-gray-500 mt-1">
                      Périmètre appliqué automatiquement selon votre profil ; ce champ affine le filtre pour DAF /
                      admin.
                    </p>
                  </div>
                )}

                <div className="flex justify-end gap-2 pt-2">
                  <button type="button" className="btn-outline" disabled={generating} onClick={() => setShowModal(false)}>
                    Annuler
                  </button>
                  <button
                    type="button"
                    className="btn-primary inline-flex items-center gap-2"
                    disabled={generating || selectedAnneeId === ""}
                    onClick={() => void handleGenerer()}
                  >
                    <ArrowDownTrayIcon className="h-5 w-5" />
                    {generating ? "Génération…" : "Générer et télécharger"}
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </MainLayout>
  )
}
