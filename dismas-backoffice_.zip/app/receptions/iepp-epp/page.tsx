"use client"

import { useState } from "react"
import MainLayout from "../../../components/layout/main-layout"
import { useAuth } from "../../providers"
import { canAccessReceptionsModule } from "@/lib/reception-profile-access"
import { toast } from "sonner"
import {
  PlusIcon,
  TruckIcon,
  CheckCircleIcon,
  ClockIcon,
  XCircleIcon,
  DocumentTextIcon,
  CubeIcon,
  BuildingOfficeIcon,
  AcademicCapIcon,
} from "@heroicons/react/24/outline"

// Données mockées des réceptions IEPP → EPP
const mockReceptionsIEPPtoEPP = [
  {
    id: 1,
    reference: "REC-IEPP-EPP-COC-2024-001",
    bordereau: "BL-IEPP-COC-2024-001",
    epp_destinataire: "EPP Cocody Centre",
    date_reception: "2024-10-20",
    statut: "CONFIRMEE",
    confirme_par: "KOUASSI Marie (EPP Cocody Centre)",
    manuels: [
      { 
        code: "FR-CP1-001", 
        titre: "Français CP1", 
        quantite_prevue: 150, 
        quantite_recue: 148,
        ecart: -2
      },
      { 
        code: "MA-CP1-001", 
        titre: "Mathématiques CP1", 
        quantite_prevue: 150, 
        quantite_recue: 150,
        ecart: 0
      },
    ],
    documents: {
      bordereau_livraison: "BL-IEPP-COC-2024-001.pdf",
      fiche_reception: null
    }
  },
  {
    id: 2,
    reference: "REC-IEPP-EPP-COC-2024-002",
    bordereau: "BL-IEPP-COC-2024-002",
    epp_destinataire: "EPP Cocody Riviera",
    date_reception: "2024-10-21",
    statut: "CONFIRMEE",
    confirme_par: "KOUASSI Marie (IEPP Cocody Centre)",
    manuels: [
      { 
        code: "FR-CP2-001", 
        titre: "Français CP2", 
        quantite_prevue: 120, 
        quantite_recue: 118,
        ecart: -2
      },
      { 
        code: "MA-CP2-001", 
        titre: "Mathématiques CP2", 
        quantite_prevue: 120, 
        quantite_recue: 120,
        ecart: 0
      },
    ],
    documents: {
      bordereau_livraison: "BL-IEPP-COC-2024-002.pdf",
      fiche_reception: null
    }
  },
]

export default function ReceptionsIEPPtoEPPPage() {
  const { user } = useAuth()
  const [selectedReception, setSelectedReception] = useState<any>(null)
  const [showModal, setShowModal] = useState(false)
  const [showNouvelleReceptionModal, setShowNouvelleReceptionModal] = useState(false)
  const [receptionFormData, setReceptionFormData] = useState<any>({
    epp_destinataire: "",
    date_reception: new Date().toISOString().split('T')[0],
    bordereau: "",
    bordereauFile: null,
    bordereauFileName: "",
    observations: "",
    manuels: []
  })

  // ✅ CORRECTION: Vérification après tous les hooks
  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <p className="text-gray-600">Chargement...</p>
        </div>
      </div>
    )
  }

  // Vérifier les droits d'accès (aligné menu Réception / MOUVEMENT)
  if (!canAccessReceptionsModule(user.role.code, user.functionalityPermissions)) {
    return (
      <MainLayout>
        <div className="min-h-screen flex items-center justify-center">
          <div className="text-center">
            <XCircleIcon className="h-16 w-16 text-red-500 mx-auto mb-4" />
            <h2 className="text-xl font-semibold text-gray-900 mb-2">Accès Restreint</h2>
            <p className="text-gray-600">Vous n'avez pas les droits pour accéder à ce module.</p>
          </div>
        </div>
      </MainLayout>
    )
  }

  const getReceptionsByRole = () => {
    switch (user.role.code) {
      case "ADMIN":
      case "DAF":
        return mockReceptionsIEPPtoEPP
      case "DRENA":
        // DRENA voit les réceptions de ses IEPP
        return mockReceptionsIEPPtoEPP.filter(r => 
          r.reference.includes(user.structure?.libelle?.split(" ")[1] || "")
        )
      case "IEPP":
        // IEPP voit ses propres réceptions
        return mockReceptionsIEPPtoEPP.filter(r => 
          r.reference.includes(user.structure?.libelle?.split(" ")[1] || "")
        )
      default:
        return []
    }
  }

  const getStatusBadge = (statut: string) => {
    switch (statut) {
      case "CONFIRMEE":
        return <span className="badge-success">✅ Confirmée</span>
      case "EN_ATTENTE":
        return <span className="badge-warning">⏳ En Attente</span>
      case "ANNULEE":
        return <span className="badge-error">❌ Annulée</span>
      default:
        return <span className="badge-secondary">{statut}</span>
    }
  }

  const handleNouvelleReception = () => {
    // Récupérer les quantités disponibles dans le stock IEPP
    const quantitesDisponibles = getQuantitesDisponiblesIEPP()
    
    // Initialiser le formulaire avec les données
    setReceptionFormData({
      epp_destinataire: "",
      date_reception: new Date().toISOString().split('T')[0],
      bordereau: "",
      bordereauFile: null,
      bordereauFileName: "",
      observations: "",
      manuels: quantitesDisponibles
    })
    
    setShowNouvelleReceptionModal(true)
  }

  // ✅ NOUVELLE FONCTION : Récupérer les quantités disponibles dans le stock IEPP
  const getQuantitesDisponiblesIEPP = () => {
    // Simuler la récupération des données depuis le stock IEPP
    // En réalité, cela viendrait d'une API ou d'un store global
    const mockStockIEPP = [
      {
        code: "FR-CP1-001",
        titre: "Français CP1",
        niveau: "CP1",
        quantite_disponible: 500,
        quantite_a_distribuer: 0
      },
      {
        code: "MA-CP1-001",
        titre: "Mathématiques CP1",
        niveau: "CP1",
        quantite_disponible: 500,
        quantite_a_distribuer: 0
      },
      {
        code: "FR-CP2-001",
        titre: "Français CP2",
        niveau: "CP2",
        quantite_disponible: 400,
        quantite_a_distribuer: 0
      },
      {
        code: "MA-CP2-001",
        titre: "Mathématiques CP2",
        niveau: "CP2",
        quantite_disponible: 400,
        quantite_a_distribuer: 0
      }
    ]

    // Transformer en format de réception
    const manuels: Array<{
      code: string;
      titre: string;
      niveau: string;
      quantite_prevue: number;
      quantite_recue: number;
      ecart: number;
    }> = []
    
    mockStockIEPP.forEach(stock => {
      manuels.push({
        code: stock.code,
        titre: stock.titre,
        niveau: stock.niveau,
        quantite_prevue: stock.quantite_disponible,
        quantite_recue: 0, // À remplir par l'utilisateur
        ecart: 0
      })
    })

    return manuels
  }

  const receptions = getReceptionsByRole()

  return (
    <MainLayout>
      <div className="p-6">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
              <AcademicCapIcon className="h-8 w-8 text-gray-700" />
              Réceptions IEPP → EPP
            </h1>
            <p className="text-gray-600 mt-1">
              Distribution des manuels de l'IEPP vers les écoles primaires
            </p>
          </div>
          
          {user.role.code === "IEPP" && (
            <button
              onClick={handleNouvelleReception}
              className="btn-primary flex items-center gap-2"
            >
              <PlusIcon className="h-5 w-5" />
              Nouvelle Distribution
            </button>
          )}
        </div>

        {/* Statistiques */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <div className="card">
            <div className="flex items-center">
              <CubeIcon className="h-8 w-8 text-gray-700" />
              <div className="ml-3">
                <p className="text-sm font-medium text-gray-600">Total Distributions</p>
                <p className="text-2xl font-bold text-gray-900">{receptions.length}</p>
              </div>
            </div>
          </div>
          
          <div className="card">
            <div className="flex items-center">
              <CheckCircleIcon className="h-8 w-8 text-gray-700" />
              <div className="ml-3">
                <p className="text-sm font-medium text-gray-600">Confirmées</p>
                <p className="text-2xl font-bold text-gray-900">
                  {receptions.filter(r => r.statut === "CONFIRMEE").length}
                </p>
              </div>
            </div>
          </div>
          
          <div className="card">
            <div className="flex items-center">
              <ClockIcon className="h-8 w-8 text-gray-700" />
              <div className="ml-3">
                <p className="text-sm font-medium text-gray-600">En Attente</p>
                <p className="text-2xl font-bold text-gray-900">
                  {receptions.filter(r => r.statut === "EN_ATTENTE").length}
                </p>
              </div>
            </div>
          </div>
          
          <div className="card">
            <div className="flex items-center">
              <BuildingOfficeIcon className="h-8 w-8 text-gray-700" />
              <div className="ml-3">
                <p className="text-sm font-medium text-gray-600">IEPP</p>
                <p className="text-2xl font-bold text-gray-900">
                  {user.structure?.libelle || "N/A"}
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Liste des réceptions */}
        <div className="card">
          <div className="card-header">
            <h2 className="card-title">Liste des Distributions IEPP → EPP</h2>
          </div>
          
          <div className="overflow-x-auto">
            <table className="table">
              <thead>
                <tr>
                  <th>Référence</th>
                  <th>Bordereau</th>
                  <th>EPP Destinataire</th>
                  <th>Date Distribution</th>
                  <th>Manuels</th>
                  <th>Statut</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {receptions.map((reception) => (
                  <tr key={reception.id} className="hover:bg-gray-50">
                    <td className="font-medium">{reception.reference}</td>
                    <td>{reception.bordereau}</td>
                    <td>{reception.epp_destinataire}</td>
                    <td>{new Date(reception.date_reception).toLocaleDateString("fr-FR")}</td>
                    <td>
                      <div className="text-sm">
                        {reception.manuels.length} manuel(s)
                        <div className="text-xs text-gray-500">
                          {reception.manuels.map(m => m.titre).join(", ")}
                        </div>
                      </div>
                    </td>
                    <td>{getStatusBadge(reception.statut)}</td>
                    <td>
                      <div className="flex space-x-2">
                        <button
                          onClick={() => setSelectedReception(reception)}
                          className="btn-outline btn-sm"
                        >
                          <DocumentTextIcon className="h-4 w-4" />
                          Détails
                        </button>
                        
                        {reception.statut === "EN_ATTENTE" && user.role.code === "IEPP" && (
                          <button
                            onClick={() => {
                              // Simuler la confirmation
                              toast.success("Distribution confirmée par l'EPP !")
                            }}
                            className="btn-primary btn-sm"
                          >
                            <CheckCircleIcon className="h-4 w-4" />
                            Confirmer
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Modal détails réception */}
        {selectedReception && (
          <div className="modal-overlay" onClick={() => setSelectedReception(null)}>
            <div className="modal-content max-w-4xl" onClick={(e) => e.stopPropagation()}>
              <div className="px-6 py-4 border-b border-orange-200 flex justify-between items-center bg-orange-50/30">
                <h3 className="text-xl font-bold text-orange-800">Détails Distribution IEPP → EPP</h3>
                <button onClick={() => setSelectedReception(null)} className="text-gray-400 hover:text-gray-600">
                  <XCircleIcon className="h-6 w-6" />
                </button>
              </div>

              <div className="p-6 space-y-6">
                <div className="border-2 border-orange-200 rounded-lg p-4 bg-orange-50/50">
                  <h4 className="text-lg font-semibold text-orange-800 mb-4">Informations Générales</h4>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Référence</label>
                      <p className="text-gray-900">{selectedReception.reference}</p>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Bordereau</label>
                      <p className="text-gray-900">{selectedReception.bordereau}</p>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">EPP Destinataire</label>
                      <p className="text-gray-900">{selectedReception.epp_destinataire}</p>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Date Distribution</label>
                      <p className="text-gray-900">
                        {new Date(selectedReception.date_reception).toLocaleDateString("fr-FR")}
                      </p>
                    </div>
                  </div>
                </div>

                <div className="border-2 border-orange-200 rounded-lg p-4 bg-orange-50/50">
                  <h4 className="text-lg font-semibold text-orange-800 mb-4">Manuels Distribués</h4>
                  <div className="overflow-x-auto">
                    <table className="min-w-full bg-white border border-orange-200 rounded-lg">
                      <thead className="bg-orange-50">
                        <tr>
                          <th className="px-4 py-3 text-left text-xs font-medium text-orange-800 uppercase tracking-wider">Code</th>
                          <th className="px-4 py-3 text-left text-xs font-medium text-orange-800 uppercase tracking-wider">Manuel</th>
                          <th className="px-4 py-3 text-left text-xs font-medium text-orange-800 uppercase tracking-wider">Total démandé</th>
                          <th className="px-4 py-3 text-left text-xs font-medium text-orange-800 uppercase tracking-wider">Quantité Reçue</th>
                          <th className="px-4 py-3 text-left text-xs font-medium text-orange-800 uppercase tracking-wider">Écart</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-orange-100">
                        {selectedReception.manuels.map((manuel: any, index: number) => (
                          <tr key={index} className="hover:bg-orange-50/50">
                            <td className="px-4 py-3 text-sm font-medium text-gray-900">{manuel.code}</td>
                            <td className="px-4 py-3 text-sm text-gray-700">{manuel.titre}</td>
                            <td className="px-4 py-3 text-sm text-gray-700">{manuel.quantite_prevue}</td>
                            <td className="px-4 py-3 text-sm text-gray-700">{manuel.quantite_recue}</td>
                            <td className="px-4 py-3 text-sm">
                              <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${manuel.ecart < 0 ? 'bg-red-100 text-red-800' : manuel.ecart > 0 ? 'bg-green-100 text-green-800' : 'bg-orange-100 text-orange-800'}`}>
                                {manuel.ecart > 0 ? '+' : ''}{manuel.ecart}
                              </span>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

                <div className="border-2 border-orange-200 rounded-lg p-4 bg-orange-50/50">
                  <h4 className="text-lg font-semibold text-orange-800 mb-4">Documents</h4>
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <DocumentTextIcon className="h-4 w-4 text-orange-600" />
                      <span className="text-sm text-gray-700">Bordereau de distribution: {selectedReception.documents?.bordereau_livraison || "Non uploadé"}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <DocumentTextIcon className="h-4 w-4 text-orange-600" />
                      <span className="text-sm text-gray-700">Fiche de réception: {selectedReception.documents?.fiche_reception || "Non uploadé"}</span>
                    </div>
                  </div>
                </div>

                {selectedReception.confirme_par && (
                  <div className="border-2 border-orange-200 rounded-lg p-4 bg-orange-50/50">
                    <label className="block text-sm font-medium text-gray-700 mb-1">Confirmé par</label>
                    <p className="text-gray-900">{selectedReception.confirme_par}</p>
                  </div>
                )}

                <div className="flex justify-end pt-4 border-t border-orange-200">
                  <button
                    onClick={() => setSelectedReception(null)}
                    className="px-6 py-2 bg-gray-800 text-white rounded-md hover:bg-gray-900 transition-colors"
                  >
                    Fermer
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ✅ NOUVELLE MODAL : Création de distribution IEPP → EPP */}
        {showNouvelleReceptionModal && receptionFormData && (
          <div className="modal-overlay" onClick={() => setShowNouvelleReceptionModal(false)}>
            <div className="modal-content max-w-6xl max-h-[90vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-bold text-gray-900 flex items-center gap-3">
                  <PlusIcon className="h-6 w-6 text-gray-700" />
                  Nouvelle Distribution IEPP → EPP
                </h3>
                <button 
                  onClick={() => setShowNouvelleReceptionModal(false)} 
                  className="text-gray-400 hover:text-gray-600 transition-colors"
                >
                  <XCircleIcon className="h-6 w-6" />
                </button>
              </div>

              <div className="space-y-8">
                {/* Section 1: Informations de base */}
                <div className="bg-gray-50 rounded-lg p-6">
                  <h4 className="text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2">
                    📋 Informations de Base
                  </h4>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        EPP Destinataire *
                      </label>
                      <input
                        type="text"
                        value={receptionFormData.epp_destinataire}
                        onChange={(e) => setReceptionFormData({...receptionFormData, epp_destinataire: e.target.value})}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-gray-500 focus:border-transparent"
                        placeholder="EPP Cocody Centre"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Date de Distribution *
                      </label>
                      <input
                        type="date"
                        value={receptionFormData.date_reception}
                        onChange={(e) => setReceptionFormData({...receptionFormData, date_reception: e.target.value})}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-gray-500 focus:border-transparent"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Numéro de Bordereau *
                      </label>
                      <input
                        type="text"
                        value={receptionFormData.bordereau}
                        onChange={(e) => setReceptionFormData({...receptionFormData, bordereau: e.target.value})}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-gray-500 focus:border-transparent"
                        placeholder="BL-IEPP-2024-001"
                      />
                    </div>
                  </div>
                </div>

                {/* Section 2: Tableau des manuels */}
                <div className="bg-white rounded-lg border border-gray-200">
                  <div className="px-6 py-4 border-b border-gray-200 bg-gray-50">
                    <h4 className="text-lg font-semibold text-gray-900 flex items-center gap-2">
                      📚 Manuels à Distribuer
                      <span className="text-sm font-normal text-gray-600">
                        (Stock IEPP disponible)
                      </span>
                    </h4>
                  </div>
                  <div className="overflow-x-auto">
                    <table className="min-w-full">
                      <thead className="bg-gray-50">
                        <tr>
                          <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider border-b border-gray-200">
                            Code
                          </th>
                          <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider border-b border-gray-200">
                            Manuel
                          </th>
                          <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider border-b border-gray-200">
                            Niveau
                          </th>
                          <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider border-b border-gray-200">
                            Stock Disponible IEPP
                          </th>
                          <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider border-b border-gray-200">
                            Quantité à Distribuer
                          </th>
                          <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider border-b border-gray-200">
                            Écart
                          </th>
                        </tr>
                      </thead>
                      <tbody className="bg-white divide-y divide-gray-200">
                        {receptionFormData.manuels.map((manuel: any, index: number) => (
                          <tr key={index} className="hover:bg-gray-50 transition-colors">
                            <td className="px-4 py-3 text-sm font-medium text-gray-900">
                              {manuel.code}
                            </td>
                            <td className="px-4 py-3 text-sm text-gray-700">
                              {manuel.titre}
                            </td>
                            <td className="px-4 py-3 text-sm text-gray-700">
                              <span className="inline-flex px-2 py-1 text-xs font-semibold rounded-full bg-gray-100 text-gray-800">
                                {manuel.niveau}
                              </span>
                            </td>
                            <td className="px-4 py-3 text-sm text-gray-700 bg-gray-50 font-medium">
                              {manuel.quantite_prevue}
                            </td>
                            <td className="px-4 py-3">
                              <input
                                type="number"
                                value={manuel.quantite_recue}
                                onChange={(e) => {
                                  const newManuels = [...receptionFormData.manuels]
                                  newManuels[index].quantite_recue = parseInt(e.target.value) || 0
                                  newManuels[index].ecart = newManuels[index].quantite_recue - newManuels[index].quantite_prevue
                                  setReceptionFormData({...receptionFormData, manuels: newManuels})
                                }}
                                className="w-20 px-2 py-1 text-center border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-gray-500 focus:border-transparent"
                                min="0"
                                max={manuel.quantite_prevue}
                              />
                            </td>
                            <td className="px-4 py-3">
                              <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${
                                manuel.ecart < 0 
                                  ? 'bg-red-100 text-red-800' 
                                  : manuel.ecart > 0 
                                    ? 'bg-green-100 text-green-800' 
                                    : 'bg-gray-100 text-gray-800'
                              }`}>
                                {manuel.ecart > 0 ? '+' : ''}{manuel.ecart}
                              </span>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* Section 3: Bordereau de distribution physique */}
                <div className="bg-white rounded-lg border border-gray-200">
                  <div className="px-6 py-4 border-b border-gray-200 bg-gray-50">
                    <h4 className="text-lg font-semibold text-gray-900 flex items-center gap-2">
                      📄 Bordereau de Distribution Physique
                    </h4>
                  </div>
                  <div className="p-6 space-y-6">
                    {/* Bordereau de distribution */}
                    <div className="space-y-3">
                      <label className="block text-sm font-medium text-gray-700 flex items-center gap-2">
                        <span className="text-red-500">*</span>
                        Bordereau de Distribution IEPP
                      </label>
                      <div className="flex items-center gap-3">
                        <input
                          type="file"
                          accept=".pdf,.doc,.docx,.jpg,.jpeg,.png"
                          onChange={(e) => {
                            const file = e.target.files?.[0]
                            if (file) {
                              setReceptionFormData({
                                ...receptionFormData, 
                                bordereauFile: file,
                                bordereauFileName: file.name
                              })
                            }
                          }}
                          className="flex-1 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-gray-500 focus:border-transparent"
                        />
                        {receptionFormData.bordereauFileName && (
                          <span className="inline-flex px-3 py-1 text-sm font-medium text-gray-800 bg-gray-100 rounded-full">
                            ✓ {receptionFormData.bordereauFileName}
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-gray-500">
                        Formats acceptés : PDF, DOC, DOCX, JPG, PNG (Max 5MB)
                      </p>
                    </div>

                    {/* Observations */}
                    <div className="space-y-3">
                      <label className="block text-sm font-medium text-gray-700">
                        Observations (optionnel)
                      </label>
                      <textarea
                        value={receptionFormData.observations}
                        onChange={(e) => setReceptionFormData({...receptionFormData, observations: e.target.value})}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-gray-500 focus:border-transparent"
                        rows={3}
                        placeholder="Observations sur la distribution, conditions de livraison, etc."
                      />
                    </div>
                  </div>
                </div>

                {/* Section 4: Actions */}
                <div className="flex justify-between items-center pt-6 border-t border-gray-200">
                  <div className="text-sm text-gray-600">
                    <span className="text-red-500">*</span> Champs obligatoires
                  </div>
                  
                  <div className="flex gap-3">
                    <button
                      onClick={() => setShowNouvelleReceptionModal(false)}
                      className="px-6 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:border-transparent transition-colors"
                    >
                      Annuler
                    </button>
                    <button
                      onClick={() => {
                        // Validation des champs obligatoires
                        if (!receptionFormData.epp_destinataire || !receptionFormData.bordereau || !receptionFormData.date_reception) {
                          toast.error("Veuillez remplir tous les champs obligatoires")
                          return
                        }
                        
                        if (!receptionFormData.bordereauFile) {
                          toast.error("Veuillez charger le bordereau de distribution physique")
                          return
                        }

                        // Créer la nouvelle distribution
                        const nouvelleDistribution = {
                          id: Date.now(),
                          reference: `REC-IEPP-EPP-${user.structure?.libelle?.split(" ")[1] || "COC"}-${new Date().getFullYear()}-${String(Date.now()).slice(-3)}`,
                          bordereau: receptionFormData.bordereau,
                          epp_destinataire: receptionFormData.epp_destinataire,
                          date_reception: receptionFormData.date_reception,
                          statut: "CONFIRMEE", // Directement confirmée
                          confirme_par: `${user.nom} ${user.prenoms} (${user.structure?.libelle})`,
                          manuels: receptionFormData.manuels,
                          documents: {
                            bordereau_livraison: receptionFormData.bordereauFileName,
                            fiche_reception: null
                          }
                        }
                        
                        // Ajouter à la liste des distributions
                        mockReceptionsIEPPtoEPP.unshift(nouvelleDistribution)
                        
                        // Fermer la modal
                        setShowNouvelleReceptionModal(false)
                        
                        // Message de succès
                        toast.success("Nouvelle distribution créée et confirmée avec succès !")
                      }}
                      className="px-6 py-2 bg-gray-800 text-white rounded-md hover:bg-gray-900 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                      disabled={!receptionFormData.bordereau || !receptionFormData.epp_destinataire || !receptionFormData.date_reception || !receptionFormData.bordereauFile}
                    >
                      Créer la Distribution
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </MainLayout>
  )
}
