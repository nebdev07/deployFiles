import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"
import { Providers } from "./providers"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "DISMAS - Distribution des Manuels Scolaires",
  description:
    "Système de gestion de la distribution des manuels scolaires - Ministère de l'Éducation Nationale, Côte d'Ivoire",
  keywords: "DISMAS, manuels scolaires, Côte d'Ivoire, éducation, distribution",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="fr">
      <body className={inter.className}>
        <Providers>{children}</Providers>
      </body>
    </html>
  )
}
