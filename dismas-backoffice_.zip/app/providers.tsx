"use client"

import { logger } from '@/lib/utils/logger'

import type React from "react"

import { createContext, useContext, useEffect, useState } from "react"
import { Toaster as HotToaster } from "react-hot-toast"
import { Toaster as SonnerToaster } from "sonner"
import { AuthService } from "@/lib/services/auth.service"
import { convertUserToLegacyUser, convertLegacyUserToUser, type User as ApiUser, type LegacyUser } from "@/lib/types/entities"
import { ApiError } from "@/lib/types/api"

// Types pour la compatibilité avec l'existant (éviter la régression)
interface User {
  id: number
  nom: string
  prenoms: string
  email: string
  login: string
  /** Clés FONCTIONALITE:TYPE si le backend les fournit (RBAC fin) */
  functionalityPermissions?: string[]
  role: {
    id: number
    code: string
    libelle: string
    niveau_hierarchique: number
  }
  /**
   * PK `structure_administrative` (session / localStorage) — à utiliser pour les filtres API.
   * `structure.id` peut être un id métier (DRENA, IEPP…) pour l’affichage.
   */
  structureAdministrativeId?: number
  structure?: {
    id: number
    code: string
    libelle: string
    type: string
  }
}

interface AuthContextType {
  user: User | null
  login: (credentials: { login: string; password: string }) => Promise<{ success: boolean; error?: string; mustChangePassword?: boolean }>
  logout: () => void
  refreshUserSession: () => void
  isLoading: boolean
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}

export function Providers({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  
  // Service d'authentification API
  const authService = new AuthService()

  const refreshUserSession = () => {
    const apiSession = authService.getUserSession()
    if (apiSession && apiSession.user) {
      const legacyUser = convertUserToLegacyUser(apiSession.user)
      setUser(legacyUser)
      return
    }
    setUser(null)
  }

  useEffect(() => {
    // Vérifier si l'utilisateur est déjà connecté via l'API
    refreshUserSession()
    setIsLoading(false)
  }, [])

  // Méthode de login API uniquement - Sans fallback mock
  const login = async (credentials: { login: string; password: string }): Promise<{ success: boolean; error?: string; mustChangePassword?: boolean }> => {
    setIsLoading(true)

    try {
      // Validation des credentials
      const validation = authService.validateCredentials(credentials)
      if (!validation.isValid) {
        setIsLoading(false)
        return { success: false, error: validation.error }
      }

      // Appel API
      const response = await authService.login(credentials)
      
      logger.log('🔍 API Response:', response) // Debug
      
      if (response.items && response.items.length > 0) {
        // Connexion réussie via API
        const apiUser = response.items[0]
        
        logger.log('🔍 API User:', apiUser) // Debug
        
        // Sauvegarder la session
        authService.saveUserSession(response)
        
        // Convertir pour la compatibilité
        const legacyUser = convertUserToLegacyUser(apiUser)
        
        logger.log('🔍 Converted Legacy User:', legacyUser) // Debug
        logger.log('🔍 User Role Code after conversion:', legacyUser.role?.code) // Debug
        
        setUser(legacyUser)
        
        const mustChangePassword = !!((apiUser as any).isFirstConnection || (apiUser as any).isDefaultPassword)
        setIsLoading(false)
        return { success: true, mustChangePassword }
      } else {
        // Réponse API sans utilisateur
        logger.warn('API response has no items:', response)
        setIsLoading(false)
        return { success: false, error: "Aucun utilisateur trouvé dans la réponse" }
      }
    } catch (error) {
      // Vérifier si c'est une erreur métier du backend (ApiError)
      if (error && typeof error === 'object' && 'code' in error) {
        const apiError = error as ApiError

        // Première connexion : le backend réutilise le code 918 pour toutes les DISALLOWED_OPERATION
        // (login incorrect, compte verrouillé, etc.). Ne déclencher le flux « changement MDP » que si le
        // message correspond explicitement à la première connexion — pas sur le seul code 918.
        const fullMessage = (apiError as any)?.details?.status?.message || apiError.message || ''
        const msg = fullMessage.toLowerCase()
        const isFirstLoginError =
          msg.includes('première connexion') ||
          msg.includes('premiere connexion') ||
          (msg.includes('connexion utilisateur') && msg.includes('changement mot de passe'))

        if (isFirstLoginError) {
          const details: any = (apiError as any).details
          const apiUser = details?.items && details.items.length > 0 ? (details.items[0] as ApiUser) : undefined

          if (typeof window !== 'undefined') {
            localStorage.setItem('pending_first_login_login', credentials.login)
            try {
              sessionStorage.setItem('pending_first_login_password', credentials.password)
            } catch {
              /* quota / mode privé */
            }
          }

          if (apiUser) {
            const legacyUser = convertUserToLegacyUser(apiUser)
            setUser(legacyUser)

            if (typeof window !== 'undefined' && apiUser.email) {
              localStorage.setItem('pending_first_login_email', apiUser.email)
            }
          }

          setIsLoading(false)
          return { success: true, mustChangePassword: true }
        }

        // Autres erreurs métier classiques
        setIsLoading(false)
        return { success: false, error: apiError.message }
      }
      
      // Erreur de connectivité ou autre - logger seulement celles-ci
      logger.error('Connectivity or other error:', error)
      setIsLoading(false)
      return { success: false, error: "Erreur de connexion au serveur" }
    }
  }

  const logout = async () => {
    try {
      // Nettoyer la session API
      await authService.logout()
    } catch (error) {
      logger.warn('Error during API logout:', error)
    }
    
    // Nettoyer l'état local
    setUser(null)
    setIsLoading(false)
  }

  return (
    <AuthContext.Provider value={{ 
      user, 
      login, 
      logout, 
      refreshUserSession,
      isLoading 
    }}>
      {children}
      <SonnerToaster position="top-right" richColors closeButton duration={6000} />
      <HotToaster
        position="top-right"
        toastOptions={{
          duration: 4000,
          style: {
            background: "#363636",
            color: "#fff",
          },
        }}
      />
    </AuthContext.Provider>
  )
}
