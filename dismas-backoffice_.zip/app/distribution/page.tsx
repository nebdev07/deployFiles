"use client"

import React from "react"
import MainLayout from "../../components/layout/main-layout"
import { useAuth } from "../providers"
import { DistributionPageContent } from "./DistributionPageContent"
import { canAccessDistributionPage } from "@/lib/utils/functionality-permissions"

export default function DistributionPage() {
  const { user } = useAuth()

  if (!user) {
    return React.createElement(
      "div",
      { className: "min-h-screen flex items-center justify-center" },
      React.createElement(
        "div",
        { className: "text-center" },
        React.createElement("p", { className: "text-gray-600" }, "Chargement...")
      )
    )
  }

  if (!canAccessDistributionPage(user.role.code, user.functionalityPermissions)) {
    return React.createElement(
      MainLayout,
      null,
      React.createElement(
        "div",
        { className: "text-center py-12" },
        React.createElement("h2", { className: "text-xl font-semibold text-gray-900 mb-2" }, "Accès restreint"),
        React.createElement(
          "p",
          { className: "text-gray-600" },
          "Vous n'avez pas les droits pour la distribution (MANUEL_DISTRIBUTION:READ).",
        ),
      ),
    )
  }

  return React.createElement(
    MainLayout,
    null,
    React.createElement(DistributionPageContent, { user })
  )
}
