// Script Playwright pour captures automatiques DISMAS
const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');

// Configuration des utilisateurs de test
const users = [
  { role: 'ADMIN', login: 'admin', password: 'admin123' },
  { role: 'DAF', login: 'daf.kouame', password: 'daf123' },
  { role: 'DRENA', login: 'drena.kone', password: 'drena123' },
  { role: 'IEPP', login: 'iepp.assi', password: 'iepp123' },
  { role: 'DIRECTEUR', login: 'dir.kouadio', password: 'dir123' }
];

// Pages à capturer par rôle
const captureConfig = {
  ADMIN: [
    { path: '/dashboard', name: 'Dashboard_Vue_Nationale' },
    { path: '/besoins', name: 'Besoins_Consolidation' },
    { path: '/stocks', name: 'Stocks_Vue_Complete' },
    { path: '/users', name: 'Users_Liste_Complete' },
    { path: '/commandes', name: 'Commandes_Acces_Autorise' },
    { path: '/admin', name: 'Admin_Monitoring' }
  ],
  DAF: [
    { path: '/dashboard', name: 'Dashboard_Vue_Financiere' },
    { path: '/besoins', name: 'Besoins_Validation' },
    { path: '/commandes', name: 'Commandes_Gestion' }
  ],
  DRENA: [
    { path: '/dashboard', name: 'Dashboard_Vue_Regionale' },
    { path: '/besoins', name: 'Besoins_Consolidation_DRENA' },
    { path: '/stocks', name: 'Stocks_Vue_Regionale' },
    { path: '/users', name: 'Users_Filtrage_Regional' },
    { path: '/commandes', name: 'Commandes_Acces_Refuse' }
  ],
  IEPP: [
    { path: '/dashboard', name: 'Dashboard_Vue_Circonscription' },
    { path: '/besoins', name: 'Besoins_Consolidation_IEPP' },
    { path: '/stocks', name: 'Stocks_Vue_Circonscription' },
    { path: '/distribution', name: 'Distribution_Validation_IEPP' },
    { path: '/users', name: 'Users_Filtrage_IEPP' }
  ],
  DIRECTEUR: [
    { path: '/dashboard', name: 'Dashboard_Vue_Ecole' },
    { path: '/besoins', name: 'Besoins_Saisie_EPP' },
    { path: '/stocks', name: 'Stocks_Vue_Ecole' },
    { path: '/distribution', name: 'Distribution_Confirmation_EPP' },
    { path: '/users', name: 'Users_Profil_Seul' },
    { path: '/commandes', name: 'Commandes_Acces_Refuse' },
    { path: '/admin', name: 'Admin_Acces_Refuse' }
  ]
};

async function captureScreenshots() {
  let browser;
  
  try {
    console.log('🚀 Lancement du navigateur...');
    browser = await chromium.launch({ 
      headless: false,
      slowMo: 100 // Ralentir pour debugging
    });
    
    // Créer dossier captures
    const capturesDir = './captures';
    if (!fs.existsSync(capturesDir)) {
      fs.mkdirSync(capturesDir);
      console.log('📁 Dossier captures créé');
    }

    for (const user of users) {
      console.log(`\n🔐 Captures pour le rôle: ${user.role}`);
      
      const context = await browser.newContext({
        viewport: { width: 1920, height: 1080 }
      });
      const page = await context.newPage();

      try {
        // 1. Vérifier que l'app est démarrée
        console.log('  🌐 Connexion à l\'application...');
        await page.goto('http://localhost:3000', { waitUntil: 'networkidle', timeout: 30000 });

        // 2. Vérifier si on est sur la page de login
        try {
          await page.waitForSelector('input[type="text"], input[name="login"], input[placeholder*="login"]', { timeout: 5000 });
        } catch (error) {
          console.log('  ⚠️  Pas de page de login détectée, tentative avec sélecteurs génériques...');
          await page.waitForSelector('input', { timeout: 5000 });
        }

        // 3. Se connecter avec gestion d'erreurs
        console.log(`  🔑 Connexion avec ${user.login}...`);
        
        // Chercher les champs de login avec plusieurs sélecteurs possibles
        const loginSelectors = [
          'input[type="text"]',
          'input[name="login"]', 
          'input[placeholder*="login"]',
          'input[placeholder*="Login"]',
          'input:first-of-type'
        ];
        
        const passwordSelectors = [
          'input[type="password"]',
          'input[name="password"]',
          'input[placeholder*="password"]',
          'input[placeholder*="Password"]'
        ];

        let loginField = null;
        for (const selector of loginSelectors) {
          try {
            loginField = await page.$(selector);
            if (loginField) break;
          } catch (e) { continue; }
        }

        let passwordField = null;
        for (const selector of passwordSelectors) {
          try {
            passwordField = await page.$(selector);
            if (passwordField) break;
          } catch (e) { continue; }
        }

        if (!loginField || !passwordField) {
          throw new Error('Champs de connexion non trouvés');
        }

        await page.fill(loginSelectors[0], user.login);
        await page.fill(passwordSelectors[0], user.password);
        
        // Chercher le bouton de connexion
        const submitSelectors = [
          'button[type="submit"]',
          'button:has-text("Connexion")',
          'button:has-text("Se connecter")',
          'button:has-text("Login")',
          '.btn-primary'
        ];

        let submitted = false;
        for (const selector of submitSelectors) {
          try {
            await page.click(selector);
            submitted = true;
            break;
          } catch (e) { continue; }
        }

        if (!submitted) {
          throw new Error('Bouton de connexion non trouvé');
        }

        await page.waitForLoadState('networkidle', { timeout: 10000 });
        await page.waitForTimeout(3000); // Attendre la redirection

        // 4. Capturer les pages spécifiques au rôle
        const pagesToCapture = captureConfig[user.role] || [];
        console.log(`  📋 ${pagesToCapture.length} pages à capturer`);
        
        for (const pageConfig of pagesToCapture) {
          try {
            console.log(`  📸 Capture: ${pageConfig.name}`);
            
            await page.goto(`http://localhost:3000${pageConfig.path}`, { 
              waitUntil: 'networkidle', 
              timeout: 15000 
            });
            await page.waitForTimeout(4000); // Attendre le chargement des données

            // Faire défiler vers le haut pour capture complète
            await page.evaluate(() => window.scrollTo(0, 0));
            await page.waitForTimeout(1000);

            const filename = `${user.role}_${pageConfig.name}.png`;
            await page.screenshot({ 
              path: path.join(capturesDir, filename),
              fullPage: true,
              quality: 90
            });
            
            console.log(`  ✅ Sauvegardé: ${filename}`);
          } catch (error) {
            console.log(`  ❌ Erreur ${pageConfig.name}: ${error.message}`);
            // Capturer quand même une image d'erreur
            try {
              const errorFilename = `${user.role}_${pageConfig.name}_ERROR.png`;
              await page.screenshot({ 
                path: path.join(capturesDir, errorFilename),
                fullPage: true
              });
              console.log(`  ⚠️  Capture d'erreur sauvegardée: ${errorFilename}`);
            } catch (screenshotError) {
              console.log(`  ❌ Impossible de capturer l'erreur: ${screenshotError.message}`);
            }
          }
        }

      } catch (error) {
        console.log(`❌ Erreur connexion ${user.role}: ${error.message}`);
        console.log(`   Stack: ${error.stack}`);
      } finally {
        await context.close();
        console.log(`  🔒 Session ${user.role} fermée`);
      }
    }

  } catch (globalError) {
    console.log(`❌ Erreur globale: ${globalError.message}`);
    console.log(`   Stack: ${globalError.stack}`);
  } finally {
    if (browser) {
      await browser.close();
      console.log('🌐 Navigateur fermé');
    }
  }
  
  console.log('\n🎉 Script terminé! Vérifiez le dossier ./captures');
}

// Vérification préliminaire
async function checkPrerequisites() {
  console.log('🔍 Vérification des prérequis...');
  
  try {
    // Pour Node.js, on utilise un module HTTP au lieu de fetch
    const http = require('http');
    
    return new Promise((resolve) => {
      const req = http.get('http://localhost:3000', (res) => {
        console.log('✅ Application DISMAS accessible sur port 3000');
        resolve(true);
      });
      
      req.on('error', (error) => {
        console.log('❌ Application non accessible sur port 3000');
        console.log('   Assurez-vous que "npm run dev" est lancé dans un autre terminal');
        console.log(`   Erreur: ${error.message}`);
        resolve(false);
      });
      
      req.setTimeout(5000, () => {
        console.log('❌ Timeout - Application ne répond pas sur port 3000');
        req.destroy();
        resolve(false);
      });
    });
  } catch (error) {
    console.log('❌ Erreur lors de la vérification');
    console.log(`   Erreur: ${error.message}`);
    return false;
  }
}

// Exécuter le script avec vérifications
async function main() {
  const isReady = await checkPrerequisites();
  if (isReady) {
    await captureScreenshots();
  } else {
    console.log('\n🚫 Script arrêté - Prérequis non satisfaits');
    process.exit(1);
  }
}

main().catch(error => {
  console.error('💥 Erreur fatale:', error);
  process.exit(1);
});