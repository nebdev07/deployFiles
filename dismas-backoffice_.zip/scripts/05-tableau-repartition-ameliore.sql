-- =====================================================
-- AMÉLIORATION DU TABLEAU DE RÉPARTITION
-- Intégration des données EPP, IEPP et DRENA
-- =====================================================

-- Table du tableau de répartition principal
CREATE TABLE tableau_repartition (
    id INT PRIMARY KEY AUTO_INCREMENT,
    annee_scolaire INT NOT NULL,
    niveau ENUM('CP1', 'CP2', 'CE1', 'CE2', 'CM1', 'CM2') NOT NULL,
    manuel_id INT NOT NULL,
    total_besoin_consolide INT DEFAULT 0,
    total_commande_daf INT DEFAULT 0,
    total_distribue INT DEFAULT 0,
    total_restant INT DEFAULT 0,
    statut ENUM('EN_COURS', 'TERMINE', 'ANNULE') DEFAULT 'EN_COURS',
    date_creation TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    cree_par INT,
    commentaires TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by INT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    updated_by INT,
    is_deleted BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (manuel_id) REFERENCES manuels(id),
    FOREIGN KEY (cree_par) REFERENCES users(id),
    UNIQUE KEY unique_repartition (annee_scolaire, niveau, manuel_id),
    INDEX idx_annee_scolaire (annee_scolaire),
    INDEX idx_niveau (niveau),
    INDEX idx_manuel_id (manuel_id),
    INDEX idx_statut (statut)
);

-- Table des détails de répartition par structure
CREATE TABLE repartition_details (
    id INT PRIMARY KEY AUTO_INCREMENT,
    tableau_repartition_id INT NOT NULL,
    structure_id INT NOT NULL,
    structure_type ENUM('EPP', 'IEPP', 'DRENA') NOT NULL,
    niveau ENUM('CP1', 'CP2', 'CE1', 'CE2', 'CM1', 'CM2') NOT NULL,
    effectif_garcons INT DEFAULT 0,
    effectif_filles INT DEFAULT 0,
    effectif_total INT DEFAULT 0,
    quantite_demandee INT DEFAULT 0,
    quantite_consolidee_iepp INT DEFAULT 0,
    quantite_consolidee_drena INT DEFAULT 0,
    quantite_approvee_daf INT DEFAULT 0,
    quantite_distribuee INT DEFAULT 0,
    quantite_restante INT DEFAULT 0,
    statut ENUM('SAISI', 'CONSOLIDE_IEPP', 'CONSOLIDE_DRENA', 'APPROUVE_DAF', 'DISTRIBUE', 'TERMINE') DEFAULT 'SAISI',
    date_saisie TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    saisi_par INT,
    date_consolidation_iepp TIMESTAMP NULL,
    consolide_par_iepp INT,
    date_consolidation_drena TIMESTAMP NULL,
    consolide_par_drena INT,
    date_approbation_daf TIMESTAMP NULL,
    approuve_par_daf INT,
    date_distribution TIMESTAMP NULL,
    distribue_par INT,
    commentaires TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by INT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    updated_by INT,
    is_deleted BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (tableau_repartition_id) REFERENCES tableau_repartition(id),
    FOREIGN KEY (structure_id) REFERENCES structures(id),
    FOREIGN KEY (saisi_par) REFERENCES users(id),
    FOREIGN KEY (consolide_par_iepp) REFERENCES users(id),
    FOREIGN KEY (consolide_par_drena) REFERENCES users(id),
    FOREIGN KEY (approuve_par_daf) REFERENCES users(id),
    FOREIGN KEY (distribue_par) REFERENCES users(id),
    INDEX idx_tableau_repartition_id (tableau_repartition_id),
    INDEX idx_structure_id (structure_id),
    INDEX idx_structure_type (structure_type),
    INDEX idx_niveau (niveau),
    INDEX idx_statut (statut)
);

-- Vue pour le tableau de répartition consolidé
CREATE VIEW v_tableau_repartition_consolide AS
SELECT 
    tr.annee_scolaire,
    tr.niveau,
    m.titre as manuel_titre,
    m.matiere,
    tr.total_besoin_consolide,
    tr.total_commande_daf,
    tr.total_distribue,
    tr.total_restant,
    tr.statut,
    tr.date_creation
FROM tableau_repartition tr
JOIN manuels m ON tr.manuel_id = m.id
WHERE tr.is_deleted = FALSE;

-- Vue pour les détails de répartition par structure
CREATE VIEW v_repartition_details_structures AS
SELECT 
    rd.id,
    rd.annee_scolaire,
    s.libelle as structure_libelle,
    s.type as structure_type,
    rd.niveau,
    rd.effectif_garcons,
    rd.effectif_filles,
    rd.effectif_total,
    rd.quantite_demandee,
    rd.quantite_consolidee_iepp,
    rd.quantite_consolidee_drena,
    rd.quantite_approvee_daf,
    rd.quantite_distribuee,
    rd.quantite_restante,
    rd.statut,
    rd.date_saisie,
    rd.date_consolidation_iepp,
    rd.date_consolidation_drena,
    rd.date_approbation_daf,
    rd.date_distribution
FROM repartition_details rd
JOIN structures s ON rd.structure_id = s.id
WHERE rd.is_deleted = FALSE; 