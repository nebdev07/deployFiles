-- =====================================================
-- SCHÉMA HYBRIDE POUR LES DEUX FLOWS DE DISTRIBUTION
-- =====================================================

-- Ajout de nouvelles tables pour supporter les deux flows

-- =====================================================
-- TABLES POUR LE FLOW TOP-DOWN (DISTRIBUTION DIRECTE)
-- =====================================================

-- Table des distributions directes (sans expression de besoins préalable)
CREATE TABLE distributions_directes (
    id INT PRIMARY KEY AUTO_INCREMENT,
    annee_scolaire INT NOT NULL,
    structure_source_id INT NOT NULL,
    structure_destination_id INT NOT NULL,
    manuel_id INT NOT NULL,
    quantite_distribuee INT NOT NULL,
    date_distribution DATE,
    distribue_par INT,
    type_distribution ENUM('INITIALE', 'REGULATION', 'COMPLEMENTAIRE') DEFAULT 'INITIALE',
    statut ENUM('PLANIFIEE', 'EN_COURS', 'TERMINEE', 'ANNULEE') DEFAULT 'PLANIFIEE',
    commentaires TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by INT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    updated_by INT,
    is_deleted BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (structure_source_id) REFERENCES structures(id),
    FOREIGN KEY (structure_destination_id) REFERENCES structures(id),
    FOREIGN KEY (manuel_id) REFERENCES manuels(id),
    FOREIGN KEY (distribue_par) REFERENCES users(id),
    INDEX idx_annee_scolaire (annee_scolaire),
    INDEX idx_structure_destination_id (structure_destination_id),
    INDEX idx_type_distribution (type_distribution),
    INDEX idx_statut (statut)
);

-- Table des distributions aux élèves
CREATE TABLE distributions_eleves (
    id INT PRIMARY KEY AUTO_INCREMENT,
    annee_scolaire INT NOT NULL,
    structure_id INT NOT NULL,
    manuel_id INT NOT NULL,
    niveau ENUM('CP1', 'CP2', 'CE1', 'CE2', 'CM1', 'CM2') NOT NULL,
    classe VARCHAR(10) NOT NULL,
    quantite_distribuee INT NOT NULL,
    date_distribution DATE,
    distribue_par INT,
    statut ENUM('PLANIFIEE', 'EN_COURS', 'TERMINEE', 'ANNULEE') DEFAULT 'PLANIFIEE',
    commentaires TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by INT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    updated_by INT,
    is_deleted BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (structure_id) REFERENCES structures(id),
    FOREIGN KEY (manuel_id) REFERENCES manuels(id),
    FOREIGN KEY (distribue_par) REFERENCES users(id),
    INDEX idx_annee_scolaire (annee_scolaire),
    INDEX idx_structure_id (structure_id),
    INDEX idx_niveau (niveau),
    INDEX idx_statut (statut)
);

-- =====================================================
-- TABLES POUR L'IDENTIFICATION DES BESOINS RÉELS
-- =====================================================

-- Table des besoins réels identifiés après distribution
CREATE TABLE besoins_reels (
    id INT PRIMARY KEY AUTO_INCREMENT,
    annee_scolaire INT NOT NULL,
    structure_id INT NOT NULL,
    niveau ENUM('CP1', 'CP2', 'CE1', 'CE2', 'CM1', 'CM2') NOT NULL,
    manuel_id INT NOT NULL,
    quantite_manquante INT DEFAULT 0,
    quantite_excedantaire INT DEFAULT 0,
    effectif_reel INT DEFAULT 0,
    date_identification DATE,
    identifie_par INT,
    statut ENUM('IDENTIFIE', 'EN_COURS_REGULATION', 'REGULE', 'ANNULE') DEFAULT 'IDENTIFIE',
    commentaires TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by INT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    updated_by INT,
    is_deleted BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (structure_id) REFERENCES structures(id),
    FOREIGN KEY (manuel_id) REFERENCES manuels(id),
    FOREIGN KEY (identifie_par) REFERENCES users(id),
    INDEX idx_annee_scolaire (annee_scolaire),
    INDEX idx_structure_id (structure_id),
    INDEX idx_niveau (niveau),
    INDEX idx_statut (statut)
);

-- =====================================================
-- TABLES POUR LA GESTION DES FLOWS
-- =====================================================

-- Table des stratégies de distribution
CREATE TABLE strategies_distribution (
    id INT PRIMARY KEY AUTO_INCREMENT,
    code VARCHAR(50) NOT NULL UNIQUE,
    libelle VARCHAR(200) NOT NULL,
    description TEXT,
    type_flow ENUM('BOTTOM_UP', 'TOP_DOWN', 'HYBRIDE') NOT NULL,
    active BOOLEAN DEFAULT TRUE,
    parametres JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by INT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    updated_by INT,
    is_deleted BOOLEAN DEFAULT FALSE,
    INDEX idx_code (code),
    INDEX idx_type_flow (type_flow),
    INDEX idx_active (active)
);

-- Table des phases de distribution
CREATE TABLE phases_distribution (
    id INT PRIMARY KEY AUTO_INCREMENT,
    annee_scolaire INT NOT NULL,
    phase ENUM('EXPRESSION_BESOINS', 'COMMANDE', 'DISTRIBUTION_INITIALE', 'DISTRIBUTION_ELEVES', 'IDENTIFICATION_BESOINS_REELS', 'REGULATION') NOT NULL,
    statut ENUM('EN_COURS', 'TERMINEE', 'ANNULEE') DEFAULT 'EN_COURS',
    date_debut DATE,
    date_fin DATE,
    responsable_id INT,
    commentaires TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by INT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    updated_by INT,
    is_deleted BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (responsable_id) REFERENCES users(id),
    INDEX idx_annee_scolaire (annee_scolaire),
    INDEX idx_phase (phase),
    INDEX idx_statut (statut)
);

-- =====================================================
-- VUES POUR LES RAPPORTS HYBRIDES
-- =====================================================

-- Vue pour les statistiques de distribution par flow
CREATE VIEW v_statistiques_distribution_flow AS
SELECT 
    'BOTTOM_UP' as type_flow,
    COUNT(DISTINCT b.structure_id) as nombre_structures,
    SUM(bd.quantite_demandee) as total_demande,
    SUM(bd.quantite_consolidee) as total_consolide,
    SUM(bd.quantite_approvee) as total_approuve
FROM besoins b
LEFT JOIN besoin_details bd ON b.id = bd.besoin_id
WHERE b.is_deleted = FALSE AND b.annee_scolaire = 2024

UNION ALL

SELECT 
    'TOP_DOWN' as type_flow,
    COUNT(DISTINCT dd.structure_destination_id) as nombre_structures,
    SUM(dd.quantite_distribuee) as total_demande,
    SUM(dd.quantite_distribuee) as total_consolide,
    SUM(dd.quantite_distribuee) as total_approuve
FROM distributions_directes dd
WHERE dd.is_deleted = FALSE AND dd.annee_scolaire = 2024;

-- Vue pour les besoins réels après distribution
CREATE VIEW v_besoins_reels_apres_distribution AS
SELECT 
    br.annee_scolaire,
    s.libelle as structure_libelle,
    s.type as structure_type,
    br.niveau,
    m.titre as manuel_titre,
    br.quantite_manquante,
    br.quantite_excedantaire,
    br.effectif_reel,
    br.statut,
    br.date_identification
FROM besoins_reels br
JOIN structures s ON br.structure_id = s.id
JOIN manuels m ON br.manuel_id = m.id
WHERE br.is_deleted = FALSE;

-- =====================================================
-- INSERTION DES DONNÉES DE BASE POUR LES FLOWS
-- =====================================================

-- Insertion des stratégies de distribution
INSERT INTO strategies_distribution (code, libelle, description, type_flow, parametres) VALUES
('FLOW_BOTTOM_UP', 'Flow Bottom-Up', 'Expression des besoins → Commande → Distribution', 'BOTTOM_UP', '{"etapes": ["expression_besoins", "consolidation", "commande", "distribution"]}'),
('FLOW_TOP_DOWN', 'Flow Top-Down', 'Distribution directe → Distribution élèves → Régulation', 'TOP_DOWN', '{"etapes": ["distribution_initiale", "distribution_eleves", "identification_besoins", "regulation"]}'),
('FLOW_HYBRIDE', 'Flow Hybride', 'Combinaison des deux approches selon le contexte', 'HYBRIDE', '{"etapes": ["expression_besoins", "distribution_initiale", "distribution_eleves", "regulation"]}');

-- Insertion des phases de distribution pour l'année 2024-2025
INSERT INTO phases_distribution (annee_scolaire, phase, statut, date_debut, date_fin) VALUES
(2024, 'EXPRESSION_BESOINS', 'TERMINEE', '2024-09-01', '2024-09-30'),
(2024, 'COMMANDE', 'TERMINEE', '2024-10-01', '2024-10-15'),
(2024, 'DISTRIBUTION_INITIALE', 'EN_COURS', '2024-10-16', NULL),
(2024, 'DISTRIBUTION_ELEVES', 'EN_COURS', '2024-10-20', NULL),
(2024, 'IDENTIFICATION_BESOINS_REELS', 'EN_COURS', '2024-11-01', NULL),
(2024, 'REGULATION', 'EN_COURS', '2024-11-15', NULL);

-- =====================================================
-- TRIGGERS POUR LA GESTION AUTOMATIQUE DES FLOWS
-- =====================================================

DELIMITER //

-- Trigger pour mettre à jour les stocks après distribution directe
CREATE TRIGGER update_stocks_after_direct_distribution
AFTER INSERT ON distributions_directes
FOR EACH ROW
BEGIN
    -- Mise à jour du stock de la structure source
    UPDATE stocks 
    SET quantite_disponible = quantite_disponible - NEW.quantite_distribuee,
        updated_at = CURRENT_TIMESTAMP,
        updated_by = NEW.distribue_par
    WHERE structure_id = NEW.structure_source_id 
    AND manuel_id = NEW.manuel_id 
    AND annee_scolaire = NEW.annee_scolaire;
    
    -- Mise à jour du stock de la structure destination
    INSERT INTO stocks (structure_id, manuel_id, annee_scolaire, quantite_disponible, created_by, updated_by)
    VALUES (NEW.structure_destination_id, NEW.manuel_id, NEW.annee_scolaire, NEW.quantite_distribuee, NEW.distribue_par, NEW.distribue_par)
    ON DUPLICATE KEY UPDATE
    quantite_disponible = quantite_disponible + NEW.quantite_distribuee,
    updated_at = CURRENT_TIMESTAMP,
    updated_by = NEW.distribue_par;
END//

-- Trigger pour identifier automatiquement les besoins réels
CREATE TRIGGER identify_real_needs_after_student_distribution
AFTER INSERT ON distributions_eleves
FOR EACH ROW
BEGIN
    DECLARE stock_disponible INT;
    DECLARE effectif_total INT;
    
    -- Récupérer le stock disponible
    SELECT quantite_disponible INTO stock_disponible
    FROM stocks 
    WHERE structure_id = NEW.structure_id 
    AND manuel_id = NEW.manuel_id 
    AND annee_scolaire = NEW.annee_scolaire;
    
    -- Calculer l'effectif total (exemple simplifié)
    SET effectif_total = NEW.quantite_distribuee;
    
    -- Identifier les besoins réels
    IF stock_disponible < effectif_total THEN
        -- Besoin manquant
        INSERT INTO besoins_reels (annee_scolaire, structure_id, niveau, manuel_id, quantite_manquante, effectif_reel, date_identification, identifie_par, statut)
        VALUES (NEW.annee_scolaire, NEW.structure_id, NEW.niveau, NEW.manuel_id, (effectif_total - stock_disponible), effectif_total, CURRENT_DATE, NEW.distribue_par, 'IDENTIFIE');
    ELSEIF stock_disponible > effectif_total THEN
        -- Excédent
        INSERT INTO besoins_reels (annee_scolaire, structure_id, niveau, manuel_id, quantite_excedantaire, effectif_reel, date_identification, identifie_par, statut)
        VALUES (NEW.annee_scolaire, NEW.structure_id, NEW.niveau, NEW.manuel_id, (stock_disponible - effectif_total), effectif_total, CURRENT_DATE, NEW.distribue_par, 'IDENTIFIE');
    END IF;
END//

DELIMITER ;

-- =====================================================
-- INDEX SUPPLEMENTAIRES POUR LES NOUVELLES TABLES
-- =====================================================

CREATE INDEX idx_distributions_directes_annee_destination ON distributions_directes(annee_scolaire, structure_destination_id);
CREATE INDEX idx_distributions_eleves_annee_structure ON distributions_eleves(annee_scolaire, structure_id);
CREATE INDEX idx_besoins_reels_annee_structure ON besoins_reels(annee_scolaire, structure_id);
CREATE INDEX idx_phases_distribution_annee_phase ON phases_distribution(annee_scolaire, phase);

-- =====================================================
-- FIN DU SCHÉMA HYBRIDE
-- =====================================================

-- Affichage des nouvelles tables créées
SELECT 'distributions_directes' as table_name, 'Flow Top-Down' as description
UNION ALL
SELECT 'distributions_eleves', 'Distribution aux élèves'
UNION ALL
SELECT 'besoins_reels', 'Besoins identifiés après distribution'
UNION ALL
SELECT 'strategies_distribution', 'Stratégies de distribution'
UNION ALL
SELECT 'phases_distribution', 'Phases de distribution'; 