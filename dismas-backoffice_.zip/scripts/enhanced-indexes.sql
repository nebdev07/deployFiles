-- RECOMMANDATIONS D'INDEX POUR PERFORMANCE

-- Index pour les recherches fréquentes
CREATE INDEX idx_structure_type ON structure_administrative(type);
CREATE INDEX idx_structure_parent ON structure_administrative(parent_id);
CREATE INDEX idx_structure_region ON structure_administrative(region);

-- Index pour les tables de distribution (supposées)
-- CREATE INDEX idx_distribution_date ON distribution_eleve(date_distribution);
-- CREATE INDEX idx_distribution_structure ON distribution_eleve(structure_id);
-- CREATE INDEX idx_distribution_niveau ON distribution_eleve(niveau_id);

-- Index pour les inventaires (supposés)
-- CREATE INDEX idx_inventaire_structure_manuel ON inventaire_manuel(structure_id, manuel_id);
-- CREATE INDEX idx_inventaire_annee ON inventaire_manuel(annee_scolaire_id);

-- Index pour les plaintes (supposées)
-- CREATE INDEX idx_plainte_statut ON plainte(statut);
-- CREATE INDEX idx_plainte_date ON plainte(date_depot);
-- CREATE INDEX idx_plainte_structure ON plainte(structure_id);
