-- =====================================================
-- DISMAS - SCHÉMA COMPLET DE BASE DE DONNÉES
-- Système de Distribution des Manuels Scolaires - Côte d'Ivoire
-- =====================================================

-- Création de la base de données
CREATE DATABASE IF NOT EXISTS db_dismas CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE db_dismas;

-- =====================================================
-- TABLES DE RÉFÉRENCE
-- =====================================================

-- Années scolaires
CREATE TABLE annee_scolaire (
    id INT PRIMARY KEY AUTO_INCREMENT,
    libelle VARCHAR(20) NOT NULL UNIQUE,
    date_debut DATE NOT NULL,
    date_fin DATE NOT NULL,
    est_active BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    created_by INT,
    updated_by INT,
    is_deleted BOOLEAN DEFAULT FALSE
);

-- Niveaux scolaires
CREATE TABLE niveau_scolaire (
    id INT PRIMARY KEY AUTO_INCREMENT,
    code VARCHAR(10) NOT NULL UNIQUE,
    libelle VARCHAR(50) NOT NULL,
    ordre_affichage INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    is_deleted BOOLEAN DEFAULT FALSE
);

-- Matières
CREATE TABLE matiere (
    id INT PRIMARY KEY AUTO_INCREMENT,
    code VARCHAR(10) NOT NULL UNIQUE,
    libelle VARCHAR(100) NOT NULL,
    couleur_hex VARCHAR(7) DEFAULT '#007bff',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    is_deleted BOOLEAN DEFAULT FALSE
);

-- Types d'ouvrages
CREATE TABLE type_ouvrage (
    id INT PRIMARY KEY AUTO_INCREMENT,
    code VARCHAR(20) NOT NULL UNIQUE,
    libelle VARCHAR(100) NOT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    is_deleted BOOLEAN DEFAULT FALSE
);

-- =====================================================
-- STRUCTURES ADMINISTRATIVES
-- =====================================================

CREATE TABLE structure_administrative (
    id INT PRIMARY KEY AUTO_INCREMENT,
    code VARCHAR(20) NOT NULL UNIQUE,
    libelle VARCHAR(150) NOT NULL,
    type ENUM('MENA', 'DRENA', 'IEPP', 'EPP') NOT NULL,
    parent_id INT NULL,
    region VARCHAR(100),
    departement VARCHAR(100),
    commune VARCHAR(100),
    adresse TEXT,
    telephone VARCHAR(20),
    email VARCHAR(100),
    responsable VARCHAR(100),
    intendant VARCHAR(100),
    effectif_total INT DEFAULT 0,
    date_creation DATE,
    actif BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    created_by INT,
    updated_by INT,
    is_deleted BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (parent_id) REFERENCES structure_administrative(id)
);

-- Nouvelles directions du MENA
INSERT INTO structure_administrative (code, libelle, type, parent_id, region, adresse, telephone, responsable) VALUES
('DPFC-CI', 'Direction de la Pédagogie et de la Formation Continue', 'MENA', 1, 'Abidjan', 'Plateau, Abidjan', '+225 20 21 25 20', 'Directeur DPFC'),
('DESPS-CI', 'Direction des Études, Stratégies, Planification et Statistiques', 'MENA', 1, 'Abidjan', 'Plateau, Abidjan', '+225 20 21 25 25', 'Directeur DESPS'),
('CABINET-CI', 'Cabinet du Ministre', 'MENA', 1, 'Abidjan', 'Plateau, Abidjan', '+225 20 21 25 10', 'Chef de Cabinet');

-- =====================================================
-- GESTION UTILISATEURS
-- =====================================================

CREATE TABLE role (
    id INT PRIMARY KEY AUTO_INCREMENT,
    code VARCHAR(20) NOT NULL UNIQUE,
    libelle VARCHAR(100) NOT NULL,
    niveau_hierarchique INT NOT NULL,
    description TEXT,
    couleur_hex VARCHAR(7) DEFAULT '#6c757d',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    is_deleted BOOLEAN DEFAULT FALSE
);

-- Ajouter les nouveaux rôles
INSERT INTO role (code, libelle, niveau_hierarchique, description, couleur_hex) VALUES
('DPFC', 'Directeur DPFC', 9, 'Direction Pédagogie et Formation', '#8b5cf6'),
('DESPS', 'Directeur DESPS', 9, 'Direction Études et Statistiques', '#06b6d4'),
('CABINET', 'Chef de Cabinet', 10, 'Cabinet Ministériel', '#dc2626'),
('PREFET', 'Préfet de Région', 8, 'Représentant État en région', '#059669'),
('CONTROLEUR', 'Contrôleur Financier', 9, 'Contrôle financier projet', '#d97706'),
('CPS', 'Conseiller Pédagogique Secteur', 6, 'Supervision pédagogique', '#7c3aed'),
('INTENDANT', 'Intendant IEPP', 6, 'Gestion administrative IEPP', '#0891b2'),
('COGES', 'Président COGES', 3, 'Comité Gestion École', '#16a34a');

CREATE TABLE fonctionalite (
    id INT PRIMARY KEY AUTO_INCREMENT,
    code VARCHAR(50) NOT NULL UNIQUE,
    libelle VARCHAR(100) NOT NULL,
    module VARCHAR(50) NOT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    is_deleted BOOLEAN DEFAULT FALSE
);

CREATE TABLE role_fonctionalite (
    id INT PRIMARY KEY AUTO_INCREMENT,
    role_id INT NOT NULL,
    fonctionalite_id INT NOT NULL,
    peut_lire BOOLEAN DEFAULT TRUE,
    peut_creer BOOLEAN DEFAULT FALSE,
    peut_modifier BOOLEAN DEFAULT FALSE,
    peut_supprimer BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (role_id) REFERENCES role(id),
    FOREIGN KEY (fonctionalite_id) REFERENCES fonctionalite(id),
    UNIQUE KEY unique_role_fonctionalite (role_id, fonctionalite_id)
);

CREATE TABLE user (
    id INT PRIMARY KEY AUTO_INCREMENT,
    nom VARCHAR(100) NOT NULL,
    prenoms VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    telephone VARCHAR(20),
    login VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role_id INT NOT NULL,
    structure_id INT,
    photo_profil VARCHAR(255),
    derniere_connexion TIMESTAMP NULL,
    est_actif BOOLEAN DEFAULT TRUE,
    doit_changer_mot_de_passe BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    created_by INT,
    updated_by INT,
    is_deleted BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (role_id) REFERENCES role(id),
    FOREIGN KEY (structure_id) REFERENCES structure_administrative(id)
);

-- =====================================================
-- GESTION DES MANUELS
-- =====================================================

CREATE TABLE manuel (
    id INT PRIMARY KEY AUTO_INCREMENT,
    code VARCHAR(20) NOT NULL UNIQUE,
    titre VARCHAR(200) NOT NULL,
    niveau_id INT NOT NULL,
    matiere_id INT NOT NULL,
    type_ouvrage_id INT NOT NULL,
    editeur VARCHAR(100),
    isbn VARCHAR(20),
    annee_edition YEAR,
    prix_unitaire DECIMAL(10,2),
    poids_grammes INT,
    description TEXT,
    image_couverture VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    created_by INT,
    updated_by INT,
    is_deleted BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (niveau_id) REFERENCES niveau_scolaire(id),
    FOREIGN KEY (matiere_id) REFERENCES matiere(id),
    FOREIGN KEY (type_ouvrage_id) REFERENCES type_ouvrage(id)
);

-- Kits pédagogiques par niveau (quels manuels sont requis)
CREATE TABLE kit_pedagogique (
    id INT PRIMARY KEY AUTO_INCREMENT,
    niveau_id INT NOT NULL,
    manuel_id INT NOT NULL,
    quantite_par_eleve INT DEFAULT 1,
    est_obligatoire BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    is_deleted BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (niveau_id) REFERENCES niveau_scolaire(id),
    FOREIGN KEY (manuel_id) REFERENCES manuel(id),
    UNIQUE KEY unique_niveau_manuel (niveau_id, manuel_id)
);

-- =====================================================
-- GESTION DES STOCKS
-- =====================================================

CREATE TABLE inventaire_manuel (
    id INT PRIMARY KEY AUTO_INCREMENT,
    structure_id INT NOT NULL,
    manuel_id INT NOT NULL,
    annee_scolaire_id INT NOT NULL,
    quantite_initiale INT DEFAULT 0,
    quantite_recue INT DEFAULT 0,
    quantite_distribuee INT DEFAULT 0,
    quantite_retournee INT DEFAULT 0,
    quantite_perdue INT DEFAULT 0,
    quantite_actuelle INT GENERATED ALWAYS AS (quantite_initiale + quantite_recue - quantite_distribuee - quantite_perdue) STORED,
    derniere_maj TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    created_by INT,
    updated_by INT,
    is_deleted BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (structure_id) REFERENCES structure_administrative(id),
    FOREIGN KEY (manuel_id) REFERENCES manuel(id),
    FOREIGN KEY (annee_scolaire_id) REFERENCES annee_scolaire(id),
    UNIQUE KEY unique_structure_manuel_annee (structure_id, manuel_id, annee_scolaire_id)
);

-- =====================================================
-- DISTRIBUTION
-- =====================================================

CREATE TABLE distribution_classe (
    id INT PRIMARY KEY AUTO_INCREMENT,
    reference VARCHAR(50) NOT NULL UNIQUE,
    structure_id INT NOT NULL,
    niveau_id INT NOT NULL,
    classe VARCHAR(20) NOT NULL,
    annee_scolaire_id INT NOT NULL,
    effectif_garcons INT DEFAULT 0,
    effectif_filles INT DEFAULT 0,
    effectif_total INT GENERATED ALWAYS AS (effectif_garcons + effectif_filles) STORED,
    date_distribution DATE NOT NULL,
    distribue_par INT,
    statut ENUM('PLANIFIEE', 'EN_COURS', 'TERMINEE', 'ANNULEE') DEFAULT 'PLANIFIEE',
    observations TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    created_by INT NOT NULL,
    updated_by INT,
    is_deleted BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (structure_id) REFERENCES structure_administrative(id),
    FOREIGN KEY (niveau_id) REFERENCES niveau_scolaire(id),
    FOREIGN KEY (annee_scolaire_id) REFERENCES annee_scolaire(id),
    FOREIGN KEY (distribue_par) REFERENCES user(id),
    FOREIGN KEY (created_by) REFERENCES user(id)
);

CREATE TABLE detail_distribution_classe (
    id INT PRIMARY KEY AUTO_INCREMENT,
    distribution_id INT NOT NULL,
    manuel_id INT NOT NULL,
    quantite_prevue INT NOT NULL,
    quantite_distribuee INT DEFAULT 0,
    quantite_manquante INT GENERATED ALWAYS AS (quantite_prevue - quantite_distribuee) STORED,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    is_deleted BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (distribution_id) REFERENCES distribution_classe(id),
    FOREIGN KEY (manuel_id) REFERENCES manuel(id),
    UNIQUE KEY unique_distribution_manuel (distribution_id, manuel_id)
);

-- =====================================================
-- RÉGULATION
-- =====================================================

CREATE TABLE regulation (
    id INT PRIMARY KEY AUTO_INCREMENT,
    reference VARCHAR(50) NOT NULL UNIQUE,
    type_regulation ENUM('INTERNE', 'EXTERNE') NOT NULL,
    structure_source_id INT NOT NULL,
    structure_destination_id INT NOT NULL,
    motif TEXT NOT NULL,
    statut ENUM('DEMANDEE', 'APPROUVEE', 'EN_COURS', 'TERMINEE', 'REJETEE') DEFAULT 'DEMANDEE',
    date_demande DATE NOT NULL,
    date_approbation DATE NULL,
    date_execution DATE NULL,
    demande_par INT NOT NULL,
    approuve_par INT NULL,
    execute_par INT NULL,
    observations TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    created_by INT NOT NULL,
    updated_by INT,
    is_deleted BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (structure_source_id) REFERENCES structure_administrative(id),
    FOREIGN KEY (structure_destination_id) REFERENCES structure_administrative(id),
    FOREIGN KEY (demande_par) REFERENCES user(id),
    FOREIGN KEY (approuve_par) REFERENCES user(id),
    FOREIGN KEY (execute_par) REFERENCES user(id),
    FOREIGN KEY (created_by) REFERENCES user(id)
);

CREATE TABLE detail_regulation (
    id INT PRIMARY KEY AUTO_INCREMENT,
    regulation_id INT NOT NULL,
    manuel_id INT NOT NULL,
    quantite_demandee INT NOT NULL,
    quantite_approuvee INT DEFAULT 0,
    quantite_transferee INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    is_deleted BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (regulation_id) REFERENCES regulation(id),
    FOREIGN KEY (manuel_id) REFERENCES manuel(id),
    UNIQUE KEY unique_regulation_manuel (regulation_id, manuel_id)
);

-- =====================================================
-- RETOURS DE MANUELS
-- =====================================================

CREATE TABLE retour_manuel (
    id INT PRIMARY KEY AUTO_INCREMENT,
    reference VARCHAR(50) NOT NULL UNIQUE,
    structure_id INT NOT NULL,
    niveau_id INT NOT NULL,
    classe VARCHAR(20) NOT NULL,
    annee_scolaire_id INT NOT NULL,
    date_retour DATE NOT NULL,
    collecte_par INT,
    statut ENUM('PLANIFIE', 'EN_COURS', 'TERMINE') DEFAULT 'PLANIFIE',
    observations TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    created_by INT NOT NULL,
    updated_by INT,
    is_deleted BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (structure_id) REFERENCES structure_administrative(id),
    FOREIGN KEY (niveau_id) REFERENCES niveau_scolaire(id),
    FOREIGN KEY (annee_scolaire_id) REFERENCES annee_scolaire(id),
    FOREIGN KEY (collecte_par) REFERENCES user(id),
    FOREIGN KEY (created_by) REFERENCES user(id)
);

CREATE TABLE detail_retour_manuel (
    id INT PRIMARY KEY AUTO_INCREMENT,
    retour_id INT NOT NULL,
    manuel_id INT NOT NULL,
    quantite_bon_etat INT DEFAULT 0,
    quantite_moyen_etat INT DEFAULT 0,
    quantite_mauvais_etat INT DEFAULT 0,
    quantite_perdue INT DEFAULT 0,
    quantite_totale INT GENERATED ALWAYS AS (quantite_bon_etat + quantite_moyen_etat + quantite_mauvais_etat) STORED,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    is_deleted BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (retour_id) REFERENCES retour_manuel(id),
    FOREIGN KEY (manuel_id) REFERENCES manuel(id),
    UNIQUE KEY unique_retour_manuel (retour_id, manuel_id)
);

-- =====================================================
-- PLAINTES
-- =====================================================

CREATE TABLE plainte (
    id INT PRIMARY KEY AUTO_INCREMENT,
    code_suivi VARCHAR(20) NOT NULL UNIQUE,
    nom_plaignant VARCHAR(100) NOT NULL,
    telephone_plaignant VARCHAR(20),
    email_plaignant VARCHAR(100),
    structure_concernee_id INT,
    type_plainte ENUM('MANQUE_MANUEL', 'RETARD_DISTRIBUTION', 'QUALITE_MANUEL', 'AUTRE') NOT NULL,
    objet VARCHAR(200) NOT NULL,
    description TEXT NOT NULL,
    statut ENUM('DEPOSEE', 'EN_TRAITEMENT', 'ESCALADEE', 'RESOLUE', 'FERMEE') DEFAULT 'DEPOSEE',
    priorite ENUM('BASSE', 'MOYENNE', 'HAUTE', 'URGENTE') DEFAULT 'MOYENNE',
    date_depot TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    date_limite_traitement DATE,
    assigne_a INT NULL,
    resolution TEXT NULL,
    date_resolution TIMESTAMP NULL,
    satisfaction_plaignant ENUM('TRES_SATISFAIT', 'SATISFAIT', 'PEU_SATISFAIT', 'INSATISFAIT') NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    created_by INT,
    updated_by INT,
    is_deleted BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (structure_concernee_id) REFERENCES structure_administrative(id),
    FOREIGN KEY (assigne_a) REFERENCES user(id)
);

-- =====================================================
-- ENQUÊTES DE SATISFACTION
-- =====================================================

CREATE TABLE enquete_satisfaction (
    id INT PRIMARY KEY AUTO_INCREMENT,
    titre VARCHAR(200) NOT NULL,
    description TEXT,
    type_enquete ENUM('PARENTS', 'DIRECTEURS', 'MAITRES', 'COGES') NOT NULL,
    questions JSON NOT NULL,
    date_debut DATE NOT NULL,
    date_fin DATE NOT NULL,
    est_active BOOLEAN DEFAULT TRUE,
    structure_cible_id INT NULL,
    niveau_cible_id INT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    created_by INT NOT NULL,
    updated_by INT,
    is_deleted BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (structure_cible_id) REFERENCES structure_administrative(id),
    FOREIGN KEY (niveau_cible_id) REFERENCES niveau_scolaire(id),
    FOREIGN KEY (created_by) REFERENCES user(id)
);

CREATE TABLE reponse_enquete (
    id INT PRIMARY KEY AUTO_INCREMENT,
    enquete_id INT NOT NULL,
    repondant_nom VARCHAR(100),
    repondant_telephone VARCHAR(20),
    repondant_email VARCHAR(100),
    structure_id INT,
    reponses JSON NOT NULL,
    score_satisfaction DECIMAL(3,2),
    date_reponse TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    is_deleted BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (enquete_id) REFERENCES enquete_satisfaction(id),
    FOREIGN KEY (structure_id) REFERENCES structure_administrative(id)
);

-- =====================================================
-- RAPPORTS ET STATISTIQUES
-- =====================================================

CREATE TABLE rapport (
    id INT PRIMARY KEY AUTO_INCREMENT,
    titre VARCHAR(200) NOT NULL,
    type_rapport ENUM('QUOTIDIEN', 'HEBDOMADAIRE', 'MENSUEL', 'TRIMESTRIEL', 'ANNUEL', 'PERSONNALISE') NOT NULL,
    periode_debut DATE NOT NULL,
    periode_fin DATE NOT NULL,
    structure_id INT,
    contenu JSON NOT NULL,
    fichier_genere VARCHAR(255),
    statut ENUM('EN_COURS', 'TERMINE', 'ERREUR') DEFAULT 'EN_COURS',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    created_by INT NOT NULL,
    is_deleted BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (structure_id) REFERENCES structure_administrative(id),
    FOREIGN KEY (created_by) REFERENCES user(id)
);

-- =====================================================
-- SYSTÈME
-- =====================================================

CREATE TABLE journal_activite (
    id INT PRIMARY KEY AUTO_INCREMENT,
    utilisateur_id INT NOT NULL,
    action VARCHAR(50) NOT NULL,
    entite VARCHAR(50) NOT NULL,
    entite_id INT NOT NULL,
    details TEXT,
    adresse_ip VARCHAR(45),
    user_agent TEXT,
    date_evenement TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (utilisateur_id) REFERENCES user(id)
);

CREATE TABLE notification (
    id INT PRIMARY KEY AUTO_INCREMENT,
    destinataire_id INT NOT NULL,
    titre VARCHAR(200) NOT NULL,
    message TEXT NOT NULL,
    type_notification ENUM('INFO', 'ALERTE', 'ERREUR', 'SUCCES') DEFAULT 'INFO',
    est_lue BOOLEAN DEFAULT FALSE,
    date_lecture TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    is_deleted BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (destinataire_id) REFERENCES user(id)
);

CREATE TABLE parametre_systeme (
    id INT PRIMARY KEY AUTO_INCREMENT,
    cle VARCHAR(100) NOT NULL UNIQUE,
    valeur TEXT NOT NULL,
    description TEXT,
    type_valeur ENUM('STRING', 'INTEGER', 'BOOLEAN', 'JSON') DEFAULT 'STRING',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    updated_by INT,
    FOREIGN KEY (updated_by) REFERENCES user(id)
);

-- =====================================================
-- INDEX POUR PERFORMANCE
-- =====================================================

-- Index sur les colonnes fréquemment utilisées
CREATE INDEX idx_structure_type ON structure_administrative(type);
CREATE INDEX idx_structure_parent ON structure_administrative(parent_id);
CREATE INDEX idx_structure_region ON structure_administrative(region);

CREATE INDEX idx_user_login ON user(login);
CREATE INDEX idx_user_email ON user(email);
CREATE INDEX idx_user_structure ON user(structure_id);
CREATE INDEX idx_user_role ON user(role_id);

CREATE INDEX idx_inventaire_structure ON inventaire_manuel(structure_id);
CREATE INDEX idx_inventaire_manuel ON inventaire_manuel(manuel_id);
CREATE INDEX idx_inventaire_annee ON inventaire_manuel(annee_scolaire_id);

CREATE INDEX idx_distribution_structure ON distribution_classe(structure_id);
CREATE INDEX idx_distribution_niveau ON distribution_classe(niveau_id);
CREATE INDEX idx_distribution_date ON distribution_classe(date_distribution);

CREATE INDEX idx_plainte_statut ON plainte(statut);
CREATE INDEX idx_plainte_code ON plainte(code_suivi);
CREATE INDEX idx_plainte_structure ON plainte(structure_concernee_id);

CREATE INDEX idx_journal_utilisateur ON journal_activite(utilisateur_id);
CREATE INDEX idx_journal_date ON journal_activite(date_evenement);

-- =====================================================
-- VUES MÉTIER
-- =====================================================

CREATE VIEW v_inventaire_global AS
SELECT 
    inv.id as inventaire_id,
    sa.code as structure_code,
    sa.libelle as structure_nom,
    sa.type as structure_type,
    sa.region,
    m.code as manuel_code,
    m.titre as manuel_titre,
    mat.libelle as matiere,
    ns.code as niveau_code,
    ns.libelle as niveau_libelle,
    to_lib.libelle as type_ouvrage,
    inv.quantite_initiale,
    inv.quantite_recue,
    inv.quantite_distribuee,
    inv.quantite_retournee,
    inv.quantite_perdue,
    inv.quantite_actuelle,
    inv.derniere_maj,
    as_lib.libelle as annee_scolaire
FROM inventaire_manuel inv
JOIN structure_administrative sa ON inv.structure_id = sa.id
JOIN manuel m ON inv.manuel_id = m.id
JOIN matiere mat ON m.matiere_id = mat.id
JOIN niveau_scolaire ns ON m.niveau_id = ns.id
JOIN type_ouvrage to_lib ON m.type_ouvrage_id = to_lib.id
JOIN annee_scolaire as_lib ON inv.annee_scolaire_id = as_lib.id
WHERE inv.is_deleted = FALSE;

CREATE VIEW v_suivi_distributions AS
SELECT 
    dc.id as distribution_id,
    dc.reference,
    sa.code as structure_code,
    sa.libelle as structure_nom,
    sa.type as structure_type,
    ns.code as niveau_code,
    ns.libelle as niveau_libelle,
    dc.classe,
    dc.date_distribution,
    dc.effectif_garcons,
    dc.effectif_filles,
    dc.effectif_total,
    dc.statut,
    u.nom as distribue_par_nom,
    u.prenoms as distribue_par_prenoms,
    COUNT(ddc.id) as nombre_manuels,
    SUM(ddc.quantite_prevue) as total_prevu,
    SUM(ddc.quantite_distribuee) as total_distribue,
    SUM(ddc.quantite_manquante) as total_manquant,
    as_lib.libelle as annee_scolaire
FROM distribution_classe dc
JOIN structure_administrative sa ON dc.structure_id = sa.id
JOIN niveau_scolaire ns ON dc.niveau_id = ns.id
LEFT JOIN user u ON dc.distribue_par = u.id
JOIN detail_distribution_classe ddc ON dc.id = ddc.distribution_id
JOIN annee_scolaire as_lib ON dc.annee_scolaire_id = as_lib.id
WHERE dc.is_deleted = FALSE AND ddc.is_deleted = FALSE
GROUP BY dc.id;

-- =====================================================
-- TRIGGERS
-- =====================================================

DELIMITER $$

CREATE TRIGGER tr_distribution_insert AFTER INSERT ON distribution_classe
FOR EACH ROW
BEGIN
    INSERT INTO journal_activite (
        utilisateur_id, action, entite, entite_id, details
    ) VALUES (
        NEW.created_by, 'CREATION', 'DISTRIBUTION_CLASSE', NEW.id,
        CONCAT('Création distribution classe ', NEW.classe, ' - ', NEW.reference)
    );
END$$

CREATE TRIGGER tr_regulation_insert AFTER INSERT ON regulation
FOR EACH ROW
BEGIN
    INSERT INTO journal_activite (
        utilisateur_id, action, entite, entite_id, details
    ) VALUES (
        NEW.created_by, 'CREATION', 'REGULATION', NEW.id,
        CONCAT('Création régulation ', NEW.reference)
    );
END$$

CREATE TRIGGER tr_plainte_insert AFTER INSERT ON plainte
FOR EACH ROW
BEGIN
    INSERT INTO journal_activite (
        utilisateur_id, action, entite, entite_id, details
    ) VALUES (
        COALESCE(NEW.created_by, 1), 'CREATION', 'PLAINTE', NEW.id,
        CONCAT('Nouvelle plainte déposée - Code: ', NEW.code_suivi)
    );
END$$

DELIMITER ;
