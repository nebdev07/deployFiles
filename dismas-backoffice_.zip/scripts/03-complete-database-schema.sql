-- =====================================================
-- SCHEMA COMPLET DE LA PLATEFORME DISMAS
-- Base de données MySQL pour la gestion des manuels scolaires
-- =====================================================

-- Création de la base de données
CREATE DATABASE IF NOT EXISTS dismas_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE dismas_db;

-- =====================================================
-- TABLES DE GESTION DES UTILISATEURS
-- =====================================================

-- Table des rôles
CREATE TABLE roles (
    id INT PRIMARY KEY AUTO_INCREMENT,
    code VARCHAR(50) NOT NULL UNIQUE,
    libelle VARCHAR(100) NOT NULL,
    description TEXT,
    niveau_hierarchie INT NOT NULL DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by INT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    updated_by INT,
    is_deleted BOOLEAN DEFAULT FALSE,
    INDEX idx_code (code),
    INDEX idx_niveau_hierarchie (niveau_hierarchie)
);

-- Table des fonctionnalités
CREATE TABLE fonctionalites (
    id INT PRIMARY KEY AUTO_INCREMENT,
    code VARCHAR(100) NOT NULL UNIQUE,
    libelle VARCHAR(200) NOT NULL,
    description TEXT,
    module VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by INT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    updated_by INT,
    is_deleted BOOLEAN DEFAULT FALSE,
    INDEX idx_code (code),
    INDEX idx_module (module)
);

-- Table de liaison rôles-fonctionnalités
CREATE TABLE role_fonctionalites (
    id INT PRIMARY KEY AUTO_INCREMENT,
    role_id INT NOT NULL,
    fonctionalite_id INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by INT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    updated_by INT,
    is_deleted BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (role_id) REFERENCES roles(id),
    FOREIGN KEY (fonctionalite_id) REFERENCES fonctionalites(id),
    UNIQUE KEY unique_role_fonctionalite (role_id, fonctionalite_id),
    INDEX idx_role_id (role_id),
    INDEX idx_fonctionalite_id (fonctionalite_id)
);

-- Table des utilisateurs
CREATE TABLE users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    matricule VARCHAR(50) UNIQUE,
    nom VARCHAR(100) NOT NULL,
    prenoms VARCHAR(100) NOT NULL,
    email VARCHAR(255) UNIQUE,
    telephone VARCHAR(20),
    role_id INT NOT NULL,
    structure_id INT,
    structure_type ENUM('EPP', 'IEPP', 'DRENA', 'DAF', 'ADMIN') NOT NULL,
    statut ENUM('ACTIF', 'INACTIF', 'SUSPENDU') DEFAULT 'ACTIF',
    derniere_connexion TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by INT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    updated_by INT,
    is_deleted BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (role_id) REFERENCES roles(id),
    INDEX idx_matricule (matricule),
    INDEX idx_email (email),
    INDEX idx_role_id (role_id),
    INDEX idx_structure_id (structure_id),
    INDEX idx_structure_type (structure_type),
    INDEX idx_statut (statut)
);

-- =====================================================
-- TABLES DE GESTION DES STRUCTURES
-- =====================================================

-- Table des structures (EPP, IEPP, DRENA)
CREATE TABLE structures (
    id INT PRIMARY KEY AUTO_INCREMENT,
    code VARCHAR(50) NOT NULL UNIQUE,
    libelle VARCHAR(200) NOT NULL,
    type ENUM('EPP', 'IEPP', 'DRENA', 'DAF') NOT NULL,
    parent_id INT,
    region VARCHAR(100),
    departement VARCHAR(100),
    commune VARCHAR(100),
    adresse TEXT,
    telephone VARCHAR(20),
    email VARCHAR(255),
    directeur_nom VARCHAR(100),
    directeur_telephone VARCHAR(20),
    statut ENUM('ACTIF', 'INACTIF') DEFAULT 'ACTIF',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by INT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    updated_by INT,
    is_deleted BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (parent_id) REFERENCES structures(id),
    INDEX idx_code (code),
    INDEX idx_type (type),
    INDEX idx_parent_id (parent_id),
    INDEX idx_region (region),
    INDEX idx_departement (departement)
);

-- =====================================================
-- TABLES DE GESTION DES MANUELS
-- =====================================================

-- Table des manuels
CREATE TABLE manuels (
    id INT PRIMARY KEY AUTO_INCREMENT,
    titre VARCHAR(300) NOT NULL,
    niveau ENUM('CP1', 'CP2', 'CE1', 'CE2', 'CM1', 'CM2') NOT NULL,
    matiere VARCHAR(100) NOT NULL,
    editeur VARCHAR(100),
    annee_edition INT,
    isbn VARCHAR(20),
    prix_unitaire DECIMAL(10,2),
    description TEXT,
    statut ENUM('ACTIF', 'INACTIF', 'OBSOLETE') DEFAULT 'ACTIF',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by INT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    updated_by INT,
    is_deleted BOOLEAN DEFAULT FALSE,
    INDEX idx_titre (titre),
    INDEX idx_niveau (niveau),
    INDEX idx_matiere (matiere),
    INDEX idx_editeur (editeur),
    INDEX idx_statut (statut)
);

-- =====================================================
-- TABLES DE GESTION DES BESOINS
-- =====================================================

-- Table des besoins (Expression des besoins)
CREATE TABLE besoins (
    id INT PRIMARY KEY AUTO_INCREMENT,
    annee_scolaire INT NOT NULL,
    structure_id INT NOT NULL,
    structure_type ENUM('EPP', 'IEPP', 'DRENA') NOT NULL,
    niveau ENUM('CP1', 'CP2', 'CE1', 'CE2', 'CM1', 'CM2') NOT NULL,
    effectif_garcons INT DEFAULT 0,
    effectif_filles INT DEFAULT 0,
    effectif_total INT DEFAULT 0,
    statut ENUM('SAISI', 'BROUILLON', 'VALIDE', 'EN_COURS', 'CONSOLIDE', 'APPROUVE', 'DISTRIBUTION_EFFECTIVE', 'REGULATION_EFFECTUEE', 'ANNULE') DEFAULT 'SAISI',
    date_saisie TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    saisi_par INT,
    date_validation TIMESTAMP NULL,
    valide_par INT,
    date_consolidation TIMESTAMP NULL,
    consolide_par INT,
    commentaires TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by INT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    updated_by INT,
    is_deleted BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (structure_id) REFERENCES structures(id),
    FOREIGN KEY (saisi_par) REFERENCES users(id),
    FOREIGN KEY (valide_par) REFERENCES users(id),
    FOREIGN KEY (consolide_par) REFERENCES users(id),
    INDEX idx_annee_scolaire (annee_scolaire),
    INDEX idx_structure_id (structure_id),
    INDEX idx_structure_type (structure_type),
    INDEX idx_niveau (niveau),
    INDEX idx_statut (statut),
    INDEX idx_date_saisie (date_saisie)
);

-- Table des détails des besoins (manuels demandés)
CREATE TABLE besoin_details (
    id INT PRIMARY KEY AUTO_INCREMENT,
    besoin_id INT NOT NULL,
    manuel_id INT NOT NULL,
    quantite_demandee INT NOT NULL DEFAULT 0,
    quantite_consolidee INT DEFAULT 0,
    quantite_approvee INT DEFAULT 0,
    quantite_distribuee INT DEFAULT 0,
    commentaires TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by INT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    updated_by INT,
    is_deleted BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (besoin_id) REFERENCES besoins(id),
    FOREIGN KEY (manuel_id) REFERENCES manuels(id),
    INDEX idx_besoin_id (besoin_id),
    INDEX idx_manuel_id (manuel_id)
);

-- =====================================================
-- TABLES DE GESTION DES COMMANDES
-- =====================================================

-- Table des commandes
CREATE TABLE commandes (
    id INT PRIMARY KEY AUTO_INCREMENT,
    numero_commande VARCHAR(50) UNIQUE,
    annee_scolaire INT NOT NULL,
    fournisseur VARCHAR(200),
    date_commande DATE,
    date_livraison_prevue DATE,
    date_livraison_effective DATE,
    montant_total DECIMAL(15,2) DEFAULT 0,
    statut ENUM('DEMANDEE', 'EN_COURS', 'LIVREE', 'ANNULEE', 'TERMINEE') DEFAULT 'DEMANDEE',
    saisi_par INT,
    commentaires TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by INT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    updated_by INT,
    is_deleted BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (saisi_par) REFERENCES users(id),
    INDEX idx_numero_commande (numero_commande),
    INDEX idx_annee_scolaire (annee_scolaire),
    INDEX idx_statut (statut),
    INDEX idx_date_commande (date_commande)
);

-- Table des détails des commandes
CREATE TABLE commande_details (
    id INT PRIMARY KEY AUTO_INCREMENT,
    commande_id INT NOT NULL,
    manuel_id INT NOT NULL,
    quantite_commandee INT NOT NULL,
    prix_unitaire DECIMAL(10,2),
    montant_ligne DECIMAL(15,2),
    quantite_livree INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by INT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    updated_by INT,
    is_deleted BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (commande_id) REFERENCES commandes(id),
    FOREIGN KEY (manuel_id) REFERENCES manuels(id),
    INDEX idx_commande_id (commande_id),
    INDEX idx_manuel_id (manuel_id)
);

-- =====================================================
-- TABLES DE GESTION DES STOCKS
-- =====================================================

-- Table des stocks
CREATE TABLE stocks (
    id INT PRIMARY KEY AUTO_INCREMENT,
    structure_id INT NOT NULL,
    manuel_id INT NOT NULL,
    annee_scolaire INT NOT NULL,
    quantite_disponible INT DEFAULT 0,
    quantite_reservee INT DEFAULT 0,
    quantite_distribuee INT DEFAULT 0,
    quantite_retournee INT DEFAULT 0,
    quantite_perdue INT DEFAULT 0,
    date_derniere_mise_a_jour TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by INT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    updated_by INT,
    is_deleted BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (structure_id) REFERENCES structures(id),
    FOREIGN KEY (manuel_id) REFERENCES manuels(id),
    UNIQUE KEY unique_stock (structure_id, manuel_id, annee_scolaire),
    INDEX idx_structure_id (structure_id),
    INDEX idx_manuel_id (manuel_id),
    INDEX idx_annee_scolaire (annee_scolaire)
);

-- Table des mouvements de stock
CREATE TABLE mouvements_stock (
    id INT PRIMARY KEY AUTO_INCREMENT,
    stock_id INT NOT NULL,
    type_mouvement ENUM('RECEPTION', 'DISTRIBUTION', 'RETOUR', 'REGULATION', 'AJUSTEMENT', 'PERDU') NOT NULL,
    quantite INT NOT NULL,
    quantite_avant INT NOT NULL,
    quantite_apres INT NOT NULL,
    reference_id INT,
    reference_type VARCHAR(50),
    commentaires TEXT,
    date_mouvement TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    effectue_par INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by INT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    updated_by INT,
    is_deleted BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (stock_id) REFERENCES stocks(id),
    FOREIGN KEY (effectue_par) REFERENCES users(id),
    INDEX idx_stock_id (stock_id),
    INDEX idx_type_mouvement (type_mouvement),
    INDEX idx_date_mouvement (date_mouvement),
    INDEX idx_reference_id (reference_id),
    INDEX idx_reference_type (reference_type)
);

-- =====================================================
-- TABLES DE GESTION DE LA DISTRIBUTION
-- =====================================================

-- Table des distributions
CREATE TABLE distributions (
    id INT PRIMARY KEY AUTO_INCREMENT,
    annee_scolaire INT NOT NULL,
    structure_source_id INT NOT NULL,
    structure_destination_id INT NOT NULL,
    manuel_id INT NOT NULL,
    quantite_distribuee INT NOT NULL,
    date_distribution DATE,
    distribue_par INT,
    statut ENUM('PLANIFIEE', 'EN_COURS', 'TERMINEE', 'ANNULEE') DEFAULT 'PLANIFIEE',
    commentaires TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by INT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    updated_by INT,
    is_deleted BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (structure_source_id) REFERENCES structures(id),
    FOREIGN KEY (structure_destination_id) REFERENCES structures(id),
    FOREIGN KEY (manuel_id) REFERENCES manuels(id),
    FOREIGN KEY (distribue_par) REFERENCES users(id),
    INDEX idx_annee_scolaire (annee_scolaire),
    INDEX idx_structure_source_id (structure_source_id),
    INDEX idx_structure_destination_id (structure_destination_id),
    INDEX idx_manuel_id (manuel_id),
    INDEX idx_date_distribution (date_distribution),
    INDEX idx_statut (statut)
);

-- =====================================================
-- TABLES DE GESTION DES RETOURS
-- =====================================================

-- Table des retours
CREATE TABLE retours (
    id INT PRIMARY KEY AUTO_INCREMENT,
    annee_scolaire INT NOT NULL,
    structure_id INT NOT NULL,
    niveau ENUM('CP1', 'CP2', 'CE1', 'CE2', 'CM1', 'CM2') NOT NULL,
    classe VARCHAR(10) NOT NULL,
    date_retour DATE,
    collecte_par INT,
    statut ENUM('EN_COURS', 'TERMINE', 'ANNULE') DEFAULT 'EN_COURS',
    commentaires TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by INT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    updated_by INT,
    is_deleted BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (structure_id) REFERENCES structures(id),
    FOREIGN KEY (collecte_par) REFERENCES users(id),
    INDEX idx_annee_scolaire (annee_scolaire),
    INDEX idx_structure_id (structure_id),
    INDEX idx_niveau (niveau),
    INDEX idx_date_retour (date_retour),
    INDEX idx_statut (statut)
);

-- Table des détails des retours
CREATE TABLE retour_details (
    id INT PRIMARY KEY AUTO_INCREMENT,
    retour_id INT NOT NULL,
    manuel_id INT NOT NULL,
    quantite_bon_etat INT DEFAULT 0,
    quantite_moyen_etat INT DEFAULT 0,
    quantite_mauvais_etat INT DEFAULT 0,
    quantite_perdue INT DEFAULT 0,
    quantite_totale INT DEFAULT 0,
    commentaires TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by INT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    updated_by INT,
    is_deleted BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (retour_id) REFERENCES retours(id),
    FOREIGN KEY (manuel_id) REFERENCES manuels(id),
    INDEX idx_retour_id (retour_id),
    INDEX idx_manuel_id (manuel_id)
);

-- =====================================================
-- TABLES DE GESTION DE LA RÉGULATION
-- =====================================================

-- Table des régulations
CREATE TABLE regulations (
    id INT PRIMARY KEY AUTO_INCREMENT,
    annee_scolaire INT NOT NULL,
    iepp_id INT NOT NULL,
    epp_excedantaire_id INT NOT NULL,
    epp_deficitaire_id INT NOT NULL,
    manuel_id INT NOT NULL,
    quantite_regulee INT NOT NULL,
    date_regulation DATE,
    regule_par INT,
    statut ENUM('PLANIFIEE', 'EN_COURS', 'TERMINEE', 'ANNULEE') DEFAULT 'PLANIFIEE',
    commentaires TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by INT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    updated_by INT,
    is_deleted BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (iepp_id) REFERENCES structures(id),
    FOREIGN KEY (epp_excedantaire_id) REFERENCES structures(id),
    FOREIGN KEY (epp_deficitaire_id) REFERENCES structures(id),
    FOREIGN KEY (manuel_id) REFERENCES manuels(id),
    FOREIGN KEY (regule_par) REFERENCES users(id),
    INDEX idx_annee_scolaire (annee_scolaire),
    INDEX idx_iepp_id (iepp_id),
    INDEX idx_epp_excedantaire_id (epp_excedantaire_id),
    INDEX idx_epp_deficitaire_id (epp_deficitaire_id),
    INDEX idx_manuel_id (manuel_id),
    INDEX idx_date_regulation (date_regulation),
    INDEX idx_statut (statut)
);

-- =====================================================
-- TABLES DE GESTION DES RAPPORTS ET STATISTIQUES
-- =====================================================

-- Table des rapports
CREATE TABLE rapports (
    id INT PRIMARY KEY AUTO_INCREMENT,
    type_rapport ENUM('BESOINS', 'DISTRIBUTION', 'STOCKS', 'RETOURS', 'REGULATION', 'SYNTHESE') NOT NULL,
    annee_scolaire INT NOT NULL,
    structure_id INT,
    periode_debut DATE,
    periode_fin DATE,
    contenu JSON,
    statut ENUM('EN_COURS', 'TERMINE', 'ERREUR') DEFAULT 'EN_COURS',
    genere_par INT,
    date_generation TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by INT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    updated_by INT,
    is_deleted BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (structure_id) REFERENCES structures(id),
    FOREIGN KEY (genere_par) REFERENCES users(id),
    INDEX idx_type_rapport (type_rapport),
    INDEX idx_annee_scolaire (annee_scolaire),
    INDEX idx_structure_id (structure_id),
    INDEX idx_date_generation (date_generation)
);

-- =====================================================
-- TABLES DE GESTION DES PARAMÈTRES
-- =====================================================

-- Table des paramètres système
CREATE TABLE parametres (
    id INT PRIMARY KEY AUTO_INCREMENT,
    code VARCHAR(100) NOT NULL UNIQUE,
    libelle VARCHAR(200) NOT NULL,
    valeur TEXT,
    type ENUM('STRING', 'INTEGER', 'DECIMAL', 'BOOLEAN', 'JSON') DEFAULT 'STRING',
    description TEXT,
    categorie VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by INT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    updated_by INT,
    is_deleted BOOLEAN DEFAULT FALSE,
    INDEX idx_code (code),
    INDEX idx_categorie (categorie)
);

-- =====================================================
-- TABLES DE GESTION DES AUDITS ET LOGS
-- =====================================================

-- Table des logs d'audit
CREATE TABLE audit_logs (
    id INT PRIMARY KEY AUTO_INCREMENT,
    utilisateur_id INT,
    action VARCHAR(100) NOT NULL,
    table_impactee VARCHAR(100),
    id_enregistrement INT,
    anciennes_valeurs JSON,
    nouvelles_valeurs JSON,
    ip_adresse VARCHAR(45),
    user_agent TEXT,
    date_action TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (utilisateur_id) REFERENCES users(id),
    INDEX idx_utilisateur_id (utilisateur_id),
    INDEX idx_action (action),
    INDEX idx_table_impactee (table_impactee),
    INDEX idx_date_action (date_action)
);

-- =====================================================
-- INSERTION DES DONNÉES DE BASE
-- =====================================================

-- Insertion des rôles
INSERT INTO roles (code, libelle, description, niveau_hierarchie) VALUES
('ADMIN', 'Administrateur', 'Administrateur système avec tous les droits', 1),
('DAF', 'Directeur des Affaires Financières', 'Gestion des commandes et approbations', 2),
('DRENA', 'Direction Régionale de l\'Éducation', 'Consolidation régionale des besoins', 3),
('IEPP', 'Inspection de l\'Enseignement Primaire', 'Consolidation départementale des besoins', 4),
('DIRECTEUR', 'Directeur d\'EPP', 'Gestion des besoins au niveau EPP', 5),
('MAITRE', 'Maître', 'Utilisateur basique', 6),
('COGES', 'Comité de Gestion', 'Membre du comité de gestion', 7);

-- Insertion des fonctionnalités
INSERT INTO fonctionalites (code, libelle, description, module) VALUES
('DASHBOARD_VIEW', 'Voir le tableau de bord', 'Accès au tableau de bord', 'DASHBOARD'),
('BESOINS_CREATE', 'Créer des besoins', 'Créer de nouveaux besoins', 'BESOINS'),
('BESOINS_VIEW', 'Voir les besoins', 'Consulter les besoins', 'BESOINS'),
('BESOINS_EDIT', 'Modifier les besoins', 'Modifier les besoins existants', 'BESOINS'),
('BESOINS_VALIDATE', 'Valider les besoins', 'Valider les besoins', 'BESOINS'),
('BESOINS_CONSOLIDATE', 'Consolider les besoins', 'Consolider les besoins', 'BESOINS'),
('COMMANDES_CREATE', 'Créer des commandes', 'Créer de nouvelles commandes', 'COMMANDES'),
('COMMANDES_VIEW', 'Voir les commandes', 'Consulter les commandes', 'COMMANDES'),
('COMMANDES_EDIT', 'Modifier les commandes', 'Modifier les commandes existantes', 'COMMANDES'),
('REPARTITION_VIEW', 'Voir la répartition', 'Consulter le tableau de répartition', 'REPARTITION'),
('STOCKS_VIEW', 'Voir les stocks', 'Consulter les stocks', 'STOCKS'),
('STOCKS_EDIT', 'Modifier les stocks', 'Modifier les stocks', 'STOCKS'),
('DISTRIBUTION_CREATE', 'Créer des distributions', 'Créer de nouvelles distributions', 'DISTRIBUTION'),
('DISTRIBUTION_VIEW', 'Voir les distributions', 'Consulter les distributions', 'DISTRIBUTION'),
('RETOURS_CREATE', 'Créer des retours', 'Créer de nouveaux retours', 'RETOURS'),
('RETOURS_VIEW', 'Voir les retours', 'Consulter les retours', 'RETOURS'),
('REGULATION_CREATE', 'Créer des régulations', 'Créer de nouvelles régulations', 'REGULATION'),
('REGULATION_VIEW', 'Voir les régulations', 'Consulter les régulations', 'REGULATION'),
('USERS_MANAGE', 'Gérer les utilisateurs', 'Gérer les utilisateurs', 'USERS'),
('PARAMETRES_MANAGE', 'Gérer les paramètres', 'Gérer les paramètres système', 'PARAMETRES'),
('RAPPORTS_GENERATE', 'Générer des rapports', 'Générer des rapports', 'RAPPORTS');

-- Insertion des paramètres système
INSERT INTO parametres (code, libelle, valeur, type, description, categorie) VALUES
('ANNEE_SCOLAIRE_COURANTE', 'Année scolaire courante', '2024-2025', 'STRING', 'Année scolaire actuelle', 'SYSTEME'),
('SEUIL_ALERTE_STOCK', 'Seuil d\'alerte stock', '10', 'INTEGER', 'Seuil minimum pour alerte stock', 'STOCKS'),
('ACTIVER_NOTIFICATIONS', 'Activer les notifications', 'true', 'BOOLEAN', 'Activer les notifications système', 'SYSTEME'),
('DELAI_VALIDATION_BESOINS', 'Délai de validation des besoins (jours)', '7', 'INTEGER', 'Délai maximum pour valider les besoins', 'BESOINS');

-- =====================================================
-- INDEX ET CONTRAINTES SUPPLEMENTAIRES
-- =====================================================

-- Index pour optimiser les requêtes fréquentes
CREATE INDEX idx_besoins_annee_structure ON besoins(annee_scolaire, structure_id);
CREATE INDEX idx_stocks_structure_manuel ON stocks(structure_id, manuel_id);
CREATE INDEX idx_distributions_annee_source ON distributions(annee_scolaire, structure_source_id);
CREATE INDEX idx_retours_annee_structure ON retours(annee_scolaire, structure_id);
CREATE INDEX idx_regulations_annee_iepp ON regulations(annee_scolaire, iepp_id);

-- =====================================================
-- VUES UTILES POUR LES RAPPORTS
-- =====================================================

-- Vue pour les statistiques de besoins par structure
CREATE VIEW v_besoins_statistiques AS
SELECT 
    b.annee_scolaire,
    b.structure_id,
    s.libelle as structure_libelle,
    s.type as structure_type,
    b.niveau,
    COUNT(bd.id) as nombre_manuels,
    SUM(bd.quantite_demandee) as total_demande,
    SUM(bd.quantite_consolidee) as total_consolide,
    SUM(bd.quantite_approvee) as total_approuve,
    b.statut
FROM besoins b
JOIN structures s ON b.structure_id = s.id
LEFT JOIN besoin_details bd ON b.id = bd.besoin_id
WHERE b.is_deleted = FALSE
GROUP BY b.id, b.annee_scolaire, b.structure_id, s.libelle, s.type, b.niveau, b.statut;

-- Vue pour les stocks par structure
CREATE VIEW v_stocks_par_structure AS
SELECT 
    s.id as structure_id,
    s.libelle as structure_libelle,
    s.type as structure_type,
    m.titre as manuel_titre,
    m.niveau as manuel_niveau,
    st.annee_scolaire,
    st.quantite_disponible,
    st.quantite_reservee,
    st.quantite_distribuee,
    st.quantite_retournee,
    st.quantite_perdue,
    (st.quantite_disponible + st.quantite_reservee) as stock_total
FROM stocks st
JOIN structures s ON st.structure_id = s.id
JOIN manuels m ON st.manuel_id = m.id
WHERE st.is_deleted = FALSE;

-- =====================================================
-- FIN DU SCHÉMA
-- =====================================================

-- Affichage des tables créées
SHOW TABLES;

-- Affichage des vues créées
SHOW FULL TABLES WHERE Table_type = 'VIEW';
