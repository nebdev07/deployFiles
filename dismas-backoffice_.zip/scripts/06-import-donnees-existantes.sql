-- =====================================================
-- IMPORT DES DONNÉES EXISTANTES
-- Prise en cours du processus
-- =====================================================

-- =====================================================
-- TABLES POUR L'IMPORT DES DONNÉES EXISTANTES
-- =====================================================

-- Table pour l'import du tableau de répartition existant
CREATE TABLE import_tableau_repartition (
    id INT PRIMARY KEY AUTO_INCREMENT,
    annee_scolaire INT NOT NULL,
    fichier_source VARCHAR(255) NOT NULL,
    type_fichier ENUM('EXCEL', 'CSV', 'PDF') NOT NULL,
    statut_import ENUM('EN_COURS', 'TERMINE', 'ERREUR') DEFAULT 'EN_COURS',
    nombre_lignes_importees INT DEFAULT 0,
    nombre_lignes_erreur INT DEFAULT 0,
    date_import TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    importe_par INT,
    commentaires TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by INT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    updated_by INT,
    is_deleted BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (importe_par) REFERENCES users(id),
    INDEX idx_annee_scolaire (annee_scolaire),
    INDEX idx_statut_import (statut_import),
    INDEX idx_date_import (date_import)
);

-- Table pour les données importées du tableau de répartition
CREATE TABLE import_repartition_data (
    id INT PRIMARY KEY AUTO_INCREMENT,
    import_id INT NOT NULL,
    ligne_fichier INT NOT NULL,
    structure_code VARCHAR(50),
    structure_libelle VARCHAR(200),
    niveau ENUM('CP1', 'CP2', 'CE1', 'CE2', 'CM1', 'CM2'),
    manuel_titre VARCHAR(300),
    quantite_prevue INT DEFAULT 0,
    quantite_distribuee INT DEFAULT 0,
    quantite_restante INT DEFAULT 0,
    statut_validation ENUM('EN_ATTENTE', 'VALIDE', 'ERREUR') DEFAULT 'EN_ATTENTE',
    message_erreur TEXT,
    structure_id INT,
    manuel_id INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (import_id) REFERENCES import_tableau_repartition(id),
    FOREIGN KEY (structure_id) REFERENCES structures(id),
    FOREIGN KEY (manuel_id) REFERENCES manuels(id),
    INDEX idx_import_id (import_id),
    INDEX idx_structure_code (structure_code),
    INDEX idx_niveau (niveau),
    INDEX idx_statut_validation (statut_validation)
);

-- Table pour l'import des manuels reçus
CREATE TABLE import_manuels_recus (
    id INT PRIMARY KEY AUTO_INCREMENT,
    annee_scolaire INT NOT NULL,
    structure_id INT NOT NULL,
    manuel_id INT NOT NULL,
    quantite_recue INT NOT NULL,
    date_reception DATE,
    numero_bordereau VARCHAR(50),
    fournisseur VARCHAR(200),
    etat_reception ENUM('BON', 'MOYEN', 'MAUVAIS') DEFAULT 'BON',
    commentaires TEXT,
    saisi_par INT,
    statut ENUM('SAISI', 'VALIDE', 'ANNULE') DEFAULT 'SAISI',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by INT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    updated_by INT,
    is_deleted BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (structure_id) REFERENCES structures(id),
    FOREIGN KEY (manuel_id) REFERENCES manuels(id),
    FOREIGN KEY (saisi_par) REFERENCES users(id),
    INDEX idx_annee_scolaire (annee_scolaire),
    INDEX idx_structure_id (structure_id),
    INDEX idx_manuel_id (manuel_id),
    INDEX idx_date_reception (date_reception),
    INDEX idx_statut (statut)
);

-- Table pour l'upload de fichiers
CREATE TABLE fichiers_upload (
    id INT PRIMARY KEY AUTO_INCREMENT,
    nom_fichier VARCHAR(255) NOT NULL,
    nom_original VARCHAR(255) NOT NULL,
    type_fichier ENUM('TABLEAU_REPARTITION', 'MANUELS_RECUS', 'AUTRE') NOT NULL,
    taille_fichier BIGINT NOT NULL,
    chemin_fichier VARCHAR(500) NOT NULL,
    annee_scolaire INT,
    structure_id INT,
    statut_traitement ENUM('EN_ATTENTE', 'TRAITE', 'ERREUR') DEFAULT 'EN_ATTENTE',
    date_upload TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    upload_par INT,
    commentaires TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by INT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    updated_by INT,
    is_deleted BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (structure_id) REFERENCES structures(id),
    FOREIGN KEY (upload_par) REFERENCES users(id),
    INDEX idx_type_fichier (type_fichier),
    INDEX idx_annee_scolaire (annee_scolaire),
    INDEX idx_statut_traitement (statut_traitement),
    INDEX idx_date_upload (date_upload)
);

-- =====================================================
-- VUES POUR LE SUIVI DES IMPORTS
-- =====================================================

-- Vue pour le suivi des imports de tableau de répartition
CREATE VIEW v_suivi_import_repartition AS
SELECT 
    itr.id,
    itr.annee_scolaire,
    itr.fichier_source,
    itr.type_fichier,
    itr.statut_import,
    itr.nombre_lignes_importees,
    itr.nombre_lignes_erreur,
    itr.date_import,
    CONCAT(u.nom, ' ', u.prenoms) as importe_par_nom,
    COUNT(ird.id) as total_lignes,
    SUM(CASE WHEN ird.statut_validation = 'VALIDE' THEN 1 ELSE 0 END) as lignes_validees,
    SUM(CASE WHEN ird.statut_validation = 'ERREUR' THEN 1 ELSE 0 END) as lignes_erreur
FROM import_tableau_repartition itr
LEFT JOIN users u ON itr.importe_par = u.id
LEFT JOIN import_repartition_data ird ON itr.id = ird.import_id
WHERE itr.is_deleted = FALSE
GROUP BY itr.id, itr.annee_scolaire, itr.fichier_source, itr.type_fichier, itr.statut_import, itr.nombre_lignes_importees, itr.nombre_lignes_erreur, itr.date_import, u.nom, u.prenoms;

-- Vue pour le suivi des manuels reçus
CREATE VIEW v_suivi_manuels_recus AS
SELECT 
    imr.annee_scolaire,
    s.libelle as structure_libelle,
    s.type as structure_type,
    m.titre as manuel_titre,
    m.niveau as manuel_niveau,
    imr.quantite_recue,
    imr.date_reception,
    imr.numero_bordereau,
    imr.fournisseur,
    imr.etat_reception,
    imr.statut,
    CONCAT(u.nom, ' ', u.prenoms) as saisi_par_nom
FROM import_manuels_recus imr
JOIN structures s ON imr.structure_id = s.id
JOIN manuels m ON imr.manuel_id = m.id
LEFT JOIN users u ON imr.saisi_par = u.id
WHERE imr.is_deleted = FALSE;

-- =====================================================
-- TRIGGERS POUR LA GESTION AUTOMATIQUE
-- =====================================================

DELIMITER //

-- Trigger pour mettre à jour les stocks après import des manuels reçus
CREATE TRIGGER update_stocks_after_import_manuels
AFTER INSERT ON import_manuels_recus
FOR EACH ROW
BEGIN
    -- Mise à jour ou création du stock
    INSERT INTO stocks (structure_id, manuel_id, annee_scolaire, quantite_disponible, created_by, updated_by)
    VALUES (NEW.structure_id, NEW.manuel_id, NEW.annee_scolaire, NEW.quantite_recue, NEW.saisi_par, NEW.saisi_par)
    ON DUPLICATE KEY UPDATE
    quantite_disponible = quantite_disponible + NEW.quantite_recue,
    updated_at = CURRENT_TIMESTAMP,
    updated_by = NEW.saisi_par;
    
    -- Enregistrement du mouvement de stock
    INSERT INTO mouvements_stock (stock_id, type_mouvement, quantite, quantite_avant, quantite_apres, reference_id, reference_type, effectue_par)
    SELECT 
        s.id,
        'RECEPTION',
        NEW.quantite_recue,
        s.quantite_disponible - NEW.quantite_recue,
        s.quantite_disponible,
        NEW.id,
        'IMPORT_MANUELS_RECUS',
        NEW.saisi_par
    FROM stocks s
    WHERE s.structure_id = NEW.structure_id 
    AND s.manuel_id = NEW.manuel_id 
    AND s.annee_scolaire = NEW.annee_scolaire;
END//

DELIMITER ;

-- =====================================================
-- INSERTION DE DONNÉES DE TEST
-- =====================================================

-- Insertion d'un import de tableau de répartition
INSERT INTO import_tableau_repartition (annee_scolaire, fichier_source, type_fichier, statut_import, nombre_lignes_importees, importe_par) VALUES
(2024, 'tableau_repartition_2024_2025.xlsx', 'EXCEL', 'TERMINE', 150, 1);

-- Insertion de données d'import de répartition
INSERT INTO import_repartition_data (import_id, ligne_fichier, structure_code, structure_libelle, niveau, manuel_titre, quantite_prevue, statut_validation) VALUES
(1, 1, 'EPP-COC-01', 'EPP Cocody Centre', 'CP1', 'Mon Premier Livre de Français CP1', 120, 'VALIDE'),
(1, 2, 'EPP-COC-01', 'EPP Cocody Centre', 'CP1', 'Mathématiques CP1', 120, 'VALIDE'),
(1, 3, 'EPP-YOP-02', 'EPP Yopougon Niangon', 'CP1', 'Mon Premier Livre de Français CP1', 95, 'VALIDE'),
(1, 4, 'EPP-YOP-02', 'EPP Yopougon Niangon', 'CP1', 'Mathématiques CP1', 95, 'VALIDE');

-- Insertion de manuels reçus
INSERT INTO import_manuels_recus (annee_scolaire, structure_id, manuel_id, quantite_recue, date_reception, numero_bordereau, fournisseur, saisi_par, statut) VALUES
(2024, 1, 1, 500, '2024-10-15', 'BRD-2024-001', 'Éditions Nouvelles', 1, 'VALIDE'),
(2024, 1, 2, 500, '2024-10-15', 'BRD-2024-001', 'Éditions Nouvelles', 1, 'VALIDE'),
(2024, 2, 1, 300, '2024-10-16', 'BRD-2024-002', 'Éditions Nouvelles', 1, 'VALIDE'),
(2024, 2, 2, 300, '2024-10-16', 'BRD-2024-002', 'Éditions Nouvelles', 1, 'VALIDE');

-- =====================================================
-- INDEX SUPPLEMENTAIRES
-- =====================================================

CREATE INDEX idx_import_repartition_data_import_structure ON import_repartition_data(import_id, structure_code);
CREATE INDEX idx_import_manuels_recus_structure_date ON import_manuels_recus(structure_id, date_reception);
CREATE INDEX idx_fichiers_upload_type_annee ON fichiers_upload(type_fichier, annee_scolaire);

-- =====================================================
-- FIN DU SCHÉMA D'IMPORT
-- =====================================================

-- Affichage des nouvelles tables créées
SELECT 'import_tableau_repartition' as table_name, 'Import tableau de répartition existant' as description
UNION ALL
SELECT 'import_repartition_data', 'Données importées du tableau de répartition'
UNION ALL
SELECT 'import_manuels_recus', 'Import des manuels reçus'
UNION ALL
SELECT 'fichiers_upload', 'Gestion des fichiers uploadés'; 