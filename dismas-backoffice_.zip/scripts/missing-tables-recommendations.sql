-- RECOMMANDATIONS D'AMÉLIORATION

-- 🔍 TABLES POTENTIELLEMENT MANQUANTES :

-- 1. Table pour les sessions utilisateur
CREATE TABLE IF NOT EXISTS user_session (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    token VARCHAR(500) NOT NULL,
    refresh_token VARCHAR(500),
    expires_at DATETIME NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    is_active BOOLEAN DEFAULT TRUE,
    FOREIGN KEY (user_id) REFERENCES user(id)
);

-- 2. Table pour les réponses aux enquêtes
CREATE TABLE IF NOT EXISTS reponse_enquete (
    id INT PRIMARY KEY AUTO_INCREMENT,
    enquete_id INT NOT NULL,
    user_id INT,
    structure_id INT,
    reponses JSON, -- Stockage flexible des réponses
    date_reponse DATETIME DEFAULT CURRENT_TIMESTAMP,
    is_deleted BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (enquete_id) REFERENCES enquete_satisfaction(id),
    FOREIGN KEY (user_id) REFERENCES user(id),
    FOREIGN KEY (structure_id) REFERENCES structure_administrative(id)
);

-- 3. Table pour les pièces jointes (plaintes, rapports)
CREATE TABLE IF NOT EXISTS piece_jointe (
    id INT PRIMARY KEY AUTO_INCREMENT,
    entite_type VARCHAR(50) NOT NULL, -- 'plainte', 'rapport', etc.
    entite_id INT NOT NULL,
    nom_fichier VARCHAR(255) NOT NULL,
    chemin_fichier VARCHAR(500) NOT NULL,
    taille_fichier BIGINT,
    type_mime VARCHAR(100),
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    created_by INT,
    is_deleted BOOLEAN DEFAULT FALSE
);

-- 4. Table pour les alertes système
CREATE TABLE IF NOT EXISTS alerte_systeme (
    id INT PRIMARY KEY AUTO_INCREMENT,
    type_alerte VARCHAR(50) NOT NULL, -- 'STOCK_BAS', 'RETARD_DISTRIBUTION', etc.
    titre VARCHAR(200) NOT NULL,
    message TEXT,
    structure_id INT,
    manuel_id INT,
    niveau_priorite ENUM('BASSE', 'MOYENNE', 'HAUTE', 'CRITIQUE') DEFAULT 'MOYENNE',
    statut ENUM('ACTIVE', 'TRAITEE', 'IGNOREE') DEFAULT 'ACTIVE',
    date_creation DATETIME DEFAULT CURRENT_TIMESTAMP,
    date_traitement DATETIME NULL,
    traite_par INT NULL,
    is_deleted BOOLEAN DEFAULT FALSE
);
