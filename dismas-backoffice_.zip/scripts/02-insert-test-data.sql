-- =====================================================
-- DONNÉES DE TEST RÉALISTES - CÔTE D'IVOIRE
-- =====================================================

-- Années scolaires
INSERT INTO annee_scolaire (libelle, date_debut, date_fin, est_active) VALUES
('2023-2024', '2023-09-15', '2024-06-30', FALSE),
('2024-2025', '2024-09-16', '2025-06-30', TRUE),
('2025-2026', '2025-09-15', '2026-06-30', FALSE);

-- Niveaux scolaires
INSERT INTO niveau_scolaire (code, libelle, ordre_affichage) VALUES
('CP1', 'Cours Préparatoire 1ère année', 1),
('CP2', 'Cours Préparatoire 2ème année', 2),
('CE1', 'Cours Élémentaire 1ère année', 3),
('CE2', 'Cours Élémentaire 2ème année', 4),
('CM1', 'Cours Moyen 1ère année', 5),
('CM2', 'Cours Moyen 2ème année', 6);

-- Matières
INSERT INTO matiere (code, libelle, couleur_hex) VALUES
('FR', 'Français', '#e74c3c'),
('MATH', 'Mathématiques', '#3498db'),
('HIST', 'Histoire', '#f39c12'),
('GEO', 'Géographie', '#27ae60'),
('SC', 'Sciences', '#9b59b6'),
('EPS', 'Éducation Physique et Sportive', '#e67e22'),
('ART', 'Arts Plastiques', '#1abc9c'),
('MUS', 'Musique', '#34495e');

-- Types d'ouvrages
INSERT INTO type_ouvrage (code, libelle, description) VALUES
('LIVRE', 'Livre de lecture', 'Manuel principal de la matière'),
('CAHIER', 'Cahier d\'exercices', 'Cahier d\'activités et exercices'),
('GUIDE', 'Guide du maître', 'Guide pédagogique pour l\'enseignant'),
('ATLAS', 'Atlas', 'Recueil de cartes géographiques');

-- Structures administratives - HIÉRARCHIE RÉELLE CÔTE D'IVOIRE
-- MENA (Niveau national)
INSERT INTO structure_administrative (code, libelle, type, region, adresse, telephone, email, responsable) VALUES
('MENAET', 'Ministère de l\'Éducation Nationale et de l\'Alphabétisation', 'MENA', 'Abidjan', 'Plateau, Abidjan', '+225 20 21 25 16', 'contact@men.gouv.ci', 'Ministre de l\'Éducation Nationale');

-- DRENA (Directions Régionales)
INSERT INTO structure_administrative (code, libelle, type, parent_id, region, adresse, telephone, responsable) VALUES
('DRENA-AB', 'DRENA Abidjan', 'DRENA', 1, 'Abidjan', 'Cocody, Abidjan', '+225 22 44 15 20', 'KOUAME Jean-Baptiste'),
('DRENA-BK', 'DRENA Bouaké', 'DRENA', 1, 'Gbêkê', 'Centre-ville, Bouaké', '+225 31 63 25 14', 'TRAORE Aminata'),
('DRENA-SP', 'DRENA San-Pédro', 'DRENA', 1, 'San-Pédro', 'Port, San-Pédro', '+225 34 71 20 18', 'BAMBA Seydou'),
('DRENA-KO', 'DRENA Korhogo', 'DRENA', 1, 'Poro', 'Centre, Korhogo', '+225 36 86 15 22', 'OUATTARA Mariam'),
('DRENA-YA', 'DRENA Yamoussoukro', 'DRENA', 1, 'Yamoussoukro', 'Administratif, Yamoussoukro', '+225 30 64 12 30', 'KONE Ibrahim'),
('DRENA-DA', 'DRENA Daloa', 'DRENA', 1, 'Haut-Sassandra', 'Centre, Daloa', '+225 32 78 25 16', 'DIABATE Fatou'),
('DRENA-MAN', 'DRENA Man', 'DRENA', 1, 'Tonkpi', 'Centre, Man', '+225 33 79 18 24', 'GOZE Marie'),
('DRENA-AB2', 'DRENA Abengourou', 'DRENA', 1, 'Indénié-Djuablin', 'Centre, Abengourou', '+225 35 91 14 28', 'YAO Kouassi'),
('DRENA-GG', 'DRENA Gagnoa', 'DRENA', 1, 'Gôh', 'Centre, Gagnoa', '+225 32 77 22 19', 'SILUE Adama'),
('DRENA-DI', 'DRENA Divo', 'DRENA', 1, 'Lôh-Djiboua', 'Centre, Divo', '+225 33 75 16 25', 'COULIBALY Rokia');

-- IEPP (Inspections de l'Enseignement Préscolaire et Primaire) - Abidjan
INSERT INTO structure_administrative (code, libelle, type, parent_id, region, departement, adresse, telephone, responsable) VALUES
('IEPP-COC', 'IEPP Cocody', 'IEPP', 2, 'Abidjan', 'Cocody', 'Cocody Centre', '+225 22 44 25 30', 'ASSI Marie-Claire'),
('IEPP-YOP', 'IEPP Yopougon', 'IEPP', 2, 'Abidjan', 'Yopougon', 'Yopougon Maroc', '+225 23 45 18 42', 'KOFFI Jean-Claude'),
('IEPP-ADJ', 'IEPP Adjamé', 'IEPP', 2, 'Abidjan', 'Adjamé', 'Adjamé Liberté', '+225 20 37 22 15', 'BROU Akissi'),
('IEPP-TRE', 'IEPP Treichville', 'IEPP', 2, 'Abidjan', 'Treichville', 'Treichville Zone 3', '+225 21 24 35 18', 'DAGO Patrice'),
('IEPP-ATT', 'IEPP Attécoubé', 'IEPP', 2, 'Abidjan', 'Attécoubé', 'Attécoubé Santé', '+225 23 52 14 27', 'KOUAME Adjoua');

-- IEPP Bouaké
INSERT INTO structure_administrative (code, libelle, type, parent_id, region, departement, adresse, telephone, responsable) VALUES
('IEPP-BK1', 'IEPP Bouaké 1', 'IEPP', 3, 'Gbêkê', 'Bouaké', 'Bouaké Centre', '+225 31 63 28 14', 'SORO Mamadou'),
('IEPP-BK2', 'IEPP Bouaké 2', 'IEPP', 3, 'Gbêkê', 'Bouaké', 'Bouaké Dar-Es-Salam', '+225 31 63 35 22', 'FOFANA Aïcha');

-- EPP (Écoles Primaires Publiques) - Échantillon représentatif
INSERT INTO structure_administrative (code, libelle, type, parent_id, region, departement, commune, adresse, telephone, responsable, effectif_total) VALUES
-- Cocody
('EPP-COC-01', 'EPP Cocody Centre', 'EPP', 11, 'Abidjan', 'Cocody', 'Cocody', 'Rue des Jardins, Cocody', '+225 22 44 30 15', 'KOUADIO Adjoua', 450),
('EPP-COC-02', 'EPP Cocody Riviera', 'EPP', 11, 'Abidjan', 'Cocody', 'Cocody', 'Riviera Golf, Cocody', '+225 22 44 32 18', 'ASSI Jean-Marie', 380),
('EPP-COC-03', 'EPP Cocody Angré', 'EPP', 11, 'Abidjan', 'Cocody', 'Cocody', 'Angré 8ème tranche', '+225 22 44 35 22', 'BROU Mariam', 520),

-- Yopougon
('EPP-YOP-01', 'EPP Yopougon Maroc', 'EPP', 12, 'Abidjan', 'Yopougon', 'Yopougon', 'Quartier Maroc', '+225 23 45 20 14', 'TRAORE Seydou', 680),
('EPP-YOP-02', 'EPP Yopougon Niangon', 'EPP', 12, 'Abidjan', 'Yopougon', 'Yopougon', 'Niangon Sud', '+225 23 45 22 16', 'KONE Fatima', 590),
('EPP-YOP-03', 'EPP Yopougon Selmer', 'EPP', 12, 'Abidjan', 'Yopougon', 'Yopougon', 'Selmer City', '+225 23 45 25 19', 'OUATTARA Ali', 720),

-- Adjamé
('EPP-ADJ-01', 'EPP Adjamé Liberté', 'EPP', 13, 'Abidjan', 'Adjamé', 'Adjamé', 'Liberté Carrefour', '+225 20 37 25 12', 'DIABATE Aminata', 420),
('EPP-ADJ-02', 'EPP Adjamé Bracodi', 'EPP', 13, 'Abidjan', 'Adjamé', 'Adjamé', 'Bracodi Cite', '+225 20 37 28 15', 'YAO Kouame', 350),

-- Treichville
('EPP-TRE-01', 'EPP Treichville Zone 3', 'EPP', 14, 'Abidjan', 'Treichville', 'Treichville', 'Zone 3 Industrielle', '+225 21 24 38 20', 'SILUE Adama', 480),
('EPP-TRE-02', 'EPP Treichville Biafra', 'EPP', 14, 'Abidjan', 'Treichville', 'Treichville', 'Biafra Marché', '+225 21 24 40 22', 'COULIBALY Rokia', 390),

-- Bouaké
('EPP-BK-01', 'EPP Bouaké Centre', 'EPP', 16, 'Gbêkê', 'Bouaké', 'Bouaké', 'Centre-ville', '+225 31 63 40 18', 'BAMBA Moussa', 520),
('EPP-BK-02', 'EPP Bouaké Koko', 'EPP', 16, 'Gbêkê', 'Bouaké', 'Bouaké', 'Quartier Koko', '+225 31 63 42 20', 'FOFANA Mariam', 460),
('EPP-BK-03', 'EPP Bouaké Dar-Es-Salam', 'EPP', 17, 'Gbêkê', 'Bouaké', 'Bouaké', 'Dar-Es-Salam', '+225 31 63 45 25', 'SORO Ibrahim', 580);

-- Rôles
INSERT INTO role (code, libelle, niveau_hierarchique, description, couleur_hex) VALUES
('ADMIN', 'Administrateur Système', 10, 'Accès complet au système', '#dc3545'),
('DAF', 'Directeur des Affaires Financières', 9, 'Supervision générale nationale', '#fd7e14'),
('DRENA', 'Directeur Régional', 8, 'Gestion régionale', '#ffc107'),
('IEPP', 'Inspecteur Enseignement Primaire', 7, 'Gestion circonscription', '#28a745'),
('DIRECTEUR', 'Directeur d\'École', 6, 'Gestion école', '#17a2b8'),
('MAITRE', 'Maître d\'École', 5, 'Enseignement classe', '#6f42c1'),
('PARENT', 'Parent d\'Élève', 2, 'Consultation limitée', '#6c757d');

-- Fonctionnalités
INSERT INTO fonctionalite (code, libelle, module, description) VALUES
('DASHBOARD_VIEW', 'Voir tableau de bord', 'DASHBOARD', 'Accès au tableau de bord'),
('STOCK_VIEW', 'Voir stocks', 'STOCK', 'Consultation des stocks'),
('STOCK_MANAGE', 'Gérer stocks', 'STOCK', 'Création/modification stocks'),
('DISTRIBUTION_VIEW', 'Voir distributions', 'DISTRIBUTION', 'Consultation distributions'),
('DISTRIBUTION_MANAGE', 'Gérer distributions', 'DISTRIBUTION', 'Planification/exécution distributions'),
('REGULATION_VIEW', 'Voir régulations', 'REGULATION', 'Consultation régulations'),
('REGULATION_MANAGE', 'Gérer régulations', 'REGULATION', 'Demande/approbation régulations'),
('RETOUR_VIEW', 'Voir retours', 'RETOUR', 'Consultation retours manuels'),
('RETOUR_MANAGE', 'Gérer retours', 'RETOUR', 'Collecte/évaluation retours'),
('PLAINTE_VIEW', 'Voir plaintes', 'PLAINTE', 'Consultation plaintes'),
('PLAINTE_MANAGE', 'Traiter plaintes', 'PLAINTE', 'Traitement plaintes'),
('ENQUETE_VIEW', 'Voir enquêtes', 'ENQUETE', 'Consultation enquêtes'),
('ENQUETE_MANAGE', 'Gérer enquêtes', 'ENQUETE', 'Création/gestion enquêtes'),
('RAPPORT_VIEW', 'Voir rapports', 'RAPPORT', 'Consultation rapports'),
('RAPPORT_GENERATE', 'Générer rapports', 'RAPPORT', 'Génération rapports'),
('ADMIN_USERS', 'Administrer utilisateurs', 'ADMIN', 'Gestion utilisateurs'),
('ADMIN_SYSTEM', 'Administrer système', 'ADMIN', 'Configuration système');

-- Permissions par rôle
INSERT INTO role_fonctionalite (role_id, fonctionalite_id, peut_lire, peut_creer, peut_modifier, peut_supprimer) VALUES
-- ADMIN - Tous droits
(1, 1, TRUE, TRUE, TRUE, TRUE), (1, 2, TRUE, TRUE, TRUE, TRUE), (1, 3, TRUE, TRUE, TRUE, TRUE),
(1, 4, TRUE, TRUE, TRUE, TRUE), (1, 5, TRUE, TRUE, TRUE, TRUE), (1, 6, TRUE, TRUE, TRUE, TRUE),
(1, 7, TRUE, TRUE, TRUE, TRUE), (1, 8, TRUE, TRUE, TRUE, TRUE), (1, 9, TRUE, TRUE, TRUE, TRUE),
(1, 10, TRUE, TRUE, TRUE, TRUE), (1, 11, TRUE, TRUE, TRUE, TRUE), (1, 12, TRUE, TRUE, TRUE, TRUE),
(1, 13, TRUE, TRUE, TRUE, TRUE), (1, 14, TRUE, TRUE, TRUE, TRUE), (1, 15, TRUE, TRUE, TRUE, TRUE),
(1, 16, TRUE, TRUE, TRUE, TRUE), (1, 17, TRUE, TRUE, TRUE, TRUE), (1, 18, TRUE, TRUE, TRUE, TRUE),

-- DAF - Supervision générale
(2, 1, TRUE, FALSE, FALSE, FALSE), (2, 2, TRUE, TRUE, TRUE, FALSE), (2, 3, TRUE, TRUE, TRUE, FALSE),
(2, 4, TRUE, FALSE, TRUE, FALSE), (2, 5, TRUE, TRUE, TRUE, FALSE), (2, 6, TRUE, FALSE, TRUE, FALSE),
(2, 7, TRUE, TRUE, TRUE, FALSE), (2, 8, TRUE, FALSE, TRUE, FALSE), (2, 9, TRUE, FALSE, TRUE, FALSE),
(2, 10, TRUE, FALSE, TRUE, FALSE), (2, 11, TRUE, FALSE, TRUE, FALSE), (2, 12, TRUE, FALSE, FALSE, FALSE),
(2, 13, TRUE, TRUE, TRUE, FALSE), (2, 14, TRUE, FALSE, FALSE, FALSE), (2, 15, TRUE, TRUE, TRUE, FALSE),
(2, 16, TRUE, FALSE, FALSE, FALSE),

-- DRENA - Gestion régionale
(3, 1, TRUE, FALSE, FALSE, FALSE), (3, 2, TRUE, TRUE, TRUE, FALSE), (3, 4, TRUE, FALSE, TRUE, FALSE),
(3, 5, TRUE, TRUE, TRUE, FALSE), (3, 6, TRUE, FALSE, TRUE, FALSE), (3, 7, TRUE, TRUE, TRUE, FALSE),
(3, 8, TRUE, FALSE, TRUE, FALSE), (3, 10, TRUE, FALSE, TRUE, FALSE), (3, 12, TRUE, FALSE, FALSE, FALSE),
(3, 13, TRUE, TRUE, TRUE, FALSE), (3, 15, TRUE, TRUE, TRUE, FALSE),

-- IEPP - Gestion circonscription
(4, 1, TRUE, FALSE, FALSE, FALSE), (4, 2, TRUE, FALSE, TRUE, FALSE), (4, 4, TRUE, FALSE, TRUE, FALSE),
(4, 5, TRUE, TRUE, TRUE, FALSE), (4, 6, TRUE, FALSE, FALSE, FALSE), (4, 7, TRUE, TRUE, FALSE, FALSE),
(4, 8, TRUE, FALSE, TRUE, FALSE), (4, 10, TRUE, FALSE, TRUE, FALSE), (4, 12, TRUE, FALSE, FALSE, FALSE),
(4, 15, TRUE, FALSE, TRUE, FALSE),

-- DIRECTEUR - Gestion école
(5, 1, TRUE, FALSE, FALSE, FALSE), (5, 2, TRUE, FALSE, FALSE, FALSE), (5, 4, TRUE, FALSE, FALSE, FALSE),
(5, 5, TRUE, TRUE, TRUE, FALSE), (5, 8, TRUE, FALSE, TRUE, FALSE), (5, 9, TRUE, TRUE, TRUE, FALSE),
(5, 12, TRUE, FALSE, FALSE, FALSE), (5, 15, TRUE, FALSE, FALSE, FALSE);

-- Utilisateurs de test
INSERT INTO user (nom, prenoms, email, telephone, login, password, role_id, structure_id, est_actif) VALUES
-- Administrateurs
('ADMIN', 'Système', 'admin@dismas.ci', '+225 07 00 00 01', 'admin', '$2b$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 1, 1, TRUE),

-- DAF
('KOUAME', 'Jean-Baptiste', 'daf@men.gouv.ci', '+225 07 11 22 33', 'daf.kouame', '$2b$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 2, 1, TRUE),

-- DRENA
('TRAORE', 'Aminata', 'drena.bouake@men.gouv.ci', '+225 07 22 33 44', 'drena.traore', '$2b$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 3, 3, TRUE),
('BAMBA', 'Seydou', 'drena.sanpedro@men.gouv.ci', '+225 07 33 44 55', 'drena.bamba', '$2b$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 3, 4, TRUE),

-- IEPP
('ASSI', 'Marie-Claire', 'iepp.cocody@men.gouv.ci', '+225 07 44 55 66', 'iepp.assi', '$2b$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 4, 11, TRUE),
('KOFFI', 'Jean-Claude', 'iepp.yopougon@men.gouv.ci', '+225 07 55 66 77', 'iepp.koffi', '$2b$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 4, 12, TRUE),
('SORO', 'Mamadou', 'iepp.bouake1@men.gouv.ci', '+225 07 66 77 88', 'iepp.soro', '$2b$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 4, 16, TRUE),

-- Directeurs d'école
('KOUADIO', 'Adjoua', 'dir.cocody.centre@men.gouv.ci', '+225 07 77 88 99', 'dir.kouadio', '$2b$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 5, 18, TRUE),
('TRAORE', 'Seydou', 'dir.yop.maroc@men.gouv.ci', '+225 07 88 99 00', 'dir.traore', '$2b$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 5, 21, TRUE),
('BAMBA', 'Moussa', 'dir.bouake.centre@men.gouv.ci', '+225 07 99 00 11', 'dir.bamba', '$2b$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 5, 28, TRUE);

-- Manuels scolaires selon programme officiel ivoirien
INSERT INTO manuel (code, titre, niveau_id, matiere_id, type_ouvrage_id, editeur, isbn, annee_edition, prix_unitaire) VALUES
-- CP1
('FR-CP1-01', 'Mon Premier Livre de Français CP1', 1, 1, 1, 'Éditions CEDA', '978-2-35-123456-7', 2024, 2500.00),
('MATH-CP1-01', 'Mathématiques CP1 - Mes Premiers Calculs', 1, 2, 1, 'Éditions CEDA', '978-2-35-123457-4', 2024, 2200.00),
('FR-CP1-02', 'Cahier d\'Exercices Français CP1', 1, 1, 2, 'Éditions CEDA', '978-2-35-123458-1', 2024, 1500.00),
('MATH-CP1-02', 'Cahier d\'Exercices Mathématiques CP1', 1, 2, 2, 'Éditions CEDA', '978-2-35-123459-8', 2024, 1500.00),

-- CP2
('FR-CP2-01', 'Français CP2 - Je Lis et J\'Écris', 2, 1, 1, 'Éditions CEDA', '978-2-35-123460-4', 2024, 2600.00),
('MATH-CP2-01', 'Mathématiques CP2', 2, 2, 1, 'Éditions CEDA', '978-2-35-123461-1', 2024, 2300.00),
('FR-CP2-02', 'Cahier d\'Activités Français CP2', 2, 1, 2, 'Éditions CEDA', '978-2-35-123462-8', 2024, 1600.00),
('MATH-CP2-02', 'Cahier d\'Activités Mathématiques CP2', 2, 2, 2, 'Éditions CEDA', '978-2-35-123463-5', 2024, 1600.00),

-- CE1
('FR-CE1-01', 'Français CE1 - Lecture et Expression', 3, 1, 1, 'Éditions NEI', '978-2-35-123464-2', 2024, 2800.00),
('MATH-CE1-01', 'Mathématiques CE1', 3, 2, 1, 'Éditions NEI', '978-2-35-123465-9', 2024, 2500.00),
('HIST-CE1-01', 'Histoire CE1 - Mon Pays la Côte d\'Ivoire', 3, 3, 1, 'Éditions NEI', '978-2-35-123466-6', 2024, 2000.00),
('GEO-CE1-01', 'Géographie CE1', 3, 4, 1, 'Éditions NEI', '978-2-35-123467-3', 2024, 2000.00),
('SC-CE1-01', 'Sciences CE1 - Découverte du Monde', 3, 5, 1, 'Éditions NEI', '978-2-35-123468-0', 2024, 2200.00),

-- CE2
('FR-CE2-01', 'Français CE2', 4, 1, 1, 'Éditions NEI', '978-2-35-123469-7', 2024, 2900.00),
('MATH-CE2-01', 'Mathématiques CE2', 4, 2, 1, 'Éditions NEI', '978-2-35-123470-3', 2024, 2600.00),
('HIST-CE2-01', 'Histoire CE2', 4, 3, 1, 'Éditions NEI', '978-2-35-123471-0', 2024, 2100.00),
('GEO-CE2-01', 'Géographie CE2', 4, 4, 1, 'Éditions NEI', '978-2-35-123472-7', 2024, 2100.00),
('SC-CE2-01', 'Sciences CE2', 4, 5, 1, 'Éditions NEI', '978-2-35-123473-4', 2024, 2300.00),

-- CM1
('FR-CM1-01', 'Français CM1', 5, 1, 1, 'Éditions EBURNIE', '978-2-35-123474-1', 2024, 3000.00),
('MATH-CM1-01', 'Mathématiques CM1', 5, 2, 1, 'Éditions EBURNIE', '978-2-35-123475-8', 2024, 2700.00),
('HIST-CM1-01', 'Histoire CM1', 5, 3, 1, 'Éditions EBURNIE', '978-2-35-123476-5', 2024, 2200.00),
('GEO-CM1-01', 'Géographie CM1', 5, 4, 1, 'Éditions EBURNIE', '978-2-35-123477-2', 2024, 2200.00),
('SC-CM1-01', 'Sciences CM1', 5, 5, 1, 'Éditions EBURNIE', '978-2-35-123478-9', 2024, 2400.00),

-- CM2
('FR-CM2-01', 'Français CM2', 6, 1, 1, 'Éditions EBURNIE', '978-2-35-123479-6', 2024, 3100.00),
('MATH-CM2-01', 'Mathématiques CM2', 6, 2, 1, 'Éditions EBURNIE', '978-2-35-123480-2', 2024, 2800.00),
('HIST-CM2-01', 'Histoire CM2', 6, 3, 1, 'Éditions EBURNIE', '978-2-35-123481-9', 2024, 2300.00),
('GEO-CM2-01', 'Géographie CM2', 6, 4, 1, 'Éditions EBURNIE', '978-2-35-123482-6', 2024, 2300.00),
('SC-CM2-01', 'Sciences CM2', 6, 5, 1, 'Éditions EBURNIE', '978-2-35-123483-3', 2024, 2500.00);

-- Kits pédagogiques (quels manuels par niveau)
INSERT INTO kit_pedagogique (niveau_id, manuel_id, quantite_par_eleve, est_obligatoire) VALUES
-- CP1
(1, 1, 1, TRUE), (1, 2, 1, TRUE), (1, 3, 1, TRUE), (1, 4, 1, TRUE),
-- CP2
(2, 5, 1, TRUE), (2, 6, 1, TRUE), (2, 7, 1, TRUE), (2, 8, 1, TRUE),
-- CE1
(3, 9, 1, TRUE), (3, 10, 1, TRUE), (3, 11, 1, TRUE), (3, 12, 1, TRUE), (3, 13, 1, TRUE),
-- CE2
(4, 14, 1, TRUE), (4, 15, 1, TRUE), (4, 16, 1, TRUE), (4, 17, 1, TRUE), (4, 18, 1, TRUE),
-- CM1
(5, 19, 1, TRUE), (5, 20, 1, TRUE), (5, 21, 1, TRUE), (5, 22, 1, TRUE), (5, 23, 1, TRUE),
-- CM2
(6, 24, 1, TRUE), (6, 25, 1, TRUE), (6, 26, 1, TRUE), (6, 27, 1, TRUE), (6, 28, 1, TRUE);

-- Inventaires initiaux (stocks dans les structures)
INSERT INTO inventaire_manuel (structure_id, manuel_id, annee_scolaire_id, quantite_initiale, quantite_recue, created_by) VALUES
-- EPP Cocody Centre (450 élèves)
(18, 1, 2, 80, 0, 8), (18, 2, 2, 80, 0, 8), (18, 3, 2, 80, 0, 8), (18, 4, 2, 80, 0, 8),
(18, 5, 2, 75, 0, 8), (18, 6, 2, 75, 0, 8), (18, 7, 2, 75, 0, 8), (18, 8, 2, 75, 0, 8),
(18, 9, 2, 70, 0, 8), (18, 10, 2, 70, 0, 8), (18, 11, 2, 70, 0, 8), (18, 12, 2, 70, 0, 8), (18, 13, 2, 70, 0, 8),

-- EPP Yopougon Maroc (680 élèves)
(21, 1, 2, 120, 0, 9), (21, 2, 2, 120, 0, 9), (21, 3, 2, 120, 0, 9), (21, 4, 2, 120, 0, 9),
(21, 5, 2, 115, 0, 9), (21, 6, 2, 115, 0, 9), (21, 7, 2, 115, 0, 9), (21, 8, 2, 115, 0, 9),
(21, 9, 2, 110, 0, 9), (21, 10, 2, 110, 0, 9), (21, 11, 2, 110, 0, 9), (21, 12, 2, 110, 0, 9), (21, 13, 2, 110, 0, 9),

-- EPP Bouaké Centre (520 élèves)
(28, 1, 2, 90, 0, 10), (28, 2, 2, 90, 0, 10), (28, 3, 2, 90, 0, 10), (28, 4, 2, 90, 0, 10),
(28, 5, 2, 85, 0, 10), (28, 6, 2, 85, 0, 10), (28, 7, 2, 85, 0, 10), (28, 8, 2, 85, 0, 10),
(28, 9, 2, 80, 0, 10), (28, 10, 2, 80, 0, 10), (28, 11, 2, 80, 0, 10), (28, 12, 2, 80, 0, 10), (28, 13, 2, 80, 0, 10);

-- Distributions de test
INSERT INTO distribution_classe (reference, structure_id, niveau_id, classe, annee_scolaire_id, effectif_garcons, effectif_filles, date_distribution, distribue_par, statut, created_by) VALUES
('DIST-COC-CP1-2024-001', 18, 1, 'CP1 A', 2, 22, 18, '2024-10-15', 8, 'TERMINEE', 8),
('DIST-COC-CP2-2024-001', 18, 2, 'CP2 A', 2, 20, 17, '2024-10-16', 8, 'TERMINEE', 8),
('DIST-YOP-CP1-2024-001', 21, 1, 'CP1 A', 2, 25, 23, '2024-10-17', 9, 'EN_COURS', 9),
('DIST-YOP-CP1-2024-002', 21, 1, 'CP1 B', 2, 24, 22, '2024-10-18', 9, 'PLANIFIEE', 9),
('DIST-BK-CE1-2024-001', 28, 3, 'CE1 A', 2, 18, 20, '2024-10-20', 10, 'TERMINEE', 10);

-- Détails des distributions
INSERT INTO detail_distribution_classe (distribution_id, manuel_id, quantite_prevue, quantite_distribuee) VALUES
-- Distribution CP1 A Cocody (40 élèves)
(1, 1, 40, 40), (1, 2, 40, 40), (1, 3, 40, 40), (1, 4, 40, 40),
-- Distribution CP2 A Cocody (37 élèves)
(2, 5, 37, 37), (2, 6, 37, 37), (2, 7, 37, 37), (2, 8, 37, 37),
-- Distribution CP1 A Yopougon (48 élèves)
(3, 1, 48, 45), (3, 2, 48, 45), (3, 3, 48, 45), (3, 4, 48, 45),
-- Distribution CP1 B Yopougon (46 élèves) - Planifiée
(4, 1, 46, 0), (4, 2, 46, 0), (4, 3, 46, 0), (4, 4, 46, 0),
-- Distribution CE1 A Bouaké (38 élèves)
(5, 9, 38, 38), (5, 10, 38, 38), (5, 11, 38, 38), (5, 12, 38, 38), (5, 13, 38, 38);

-- Régulations de test
INSERT INTO regulation (reference, type_regulation, structure_source_id, structure_destination_id, motif, statut, date_demande, demande_par, created_by) VALUES
('REG-2024-001', 'EXTERNE', 18, 21, 'Excédent de manuels CP1 à Cocody, déficit à Yopougon', 'APPROUVEE', '2024-10-25', 8, 8),
('REG-2024-002', 'INTERNE', 21, 22, 'Répartition entre écoles Yopougon', 'EN_COURS', '2024-10-26', 9, 9);

-- Détails des régulations
INSERT INTO detail_regulation (regulation_id, manuel_id, quantite_demandee, quantite_approuvee, quantite_transferee) VALUES
(1, 1, 20, 20, 20), (1, 2, 20, 20, 20), (1, 3, 20, 20, 20), (1, 4, 20, 20, 20),
(2, 5, 15, 15, 0), (2, 6, 15, 15, 0);

-- Retours de manuels
INSERT INTO retour_manuel (reference, structure_id, niveau_id, classe, annee_scolaire_id, date_retour, collecte_par, statut, created_by) VALUES
('RET-COC-2024-001', 18, 1, 'CP1 A', 1, '2024-06-25', 8, 'TERMINE', 8),
('RET-YOP-2024-001', 21, 2, 'CP2 B', 1, '2024-06-26', 9, 'TERMINE', 9);

-- Détails des retours
INSERT INTO detail_retour_manuel (retour_id, manuel_id, quantite_bon_etat, quantite_moyen_etat, quantite_mauvais_etat, quantite_perdue) VALUES
(1, 1, 35, 8, 2, 0), (1, 2, 33, 10, 2, 0), (1, 3, 38, 5, 2, 0), (1, 4, 36, 7, 2, 0),
(2, 5, 28, 12, 5, 2), (2, 6, 30, 10, 5, 2), (2, 7, 32, 8, 5, 2), (2, 8, 29, 11, 5, 2);

-- Plaintes de test
INSERT INTO plainte (code_suivi, nom_plaignant, telephone_plaignant, email_plaignant, structure_concernee_id, type_plainte, objet, description, statut, priorite, date_depot, assigne_a) VALUES
('PL2024001', 'KONE Mariam', '+225 07 12 34 56', 'kone.mariam@gmail.com', 18, 'MANQUE_MANUEL', 'Manque manuel de mathématiques', 'Mon enfant en CP1 n\'a pas reçu son manuel de mathématiques depuis la rentrée', 'EN_TRAITEMENT', 'HAUTE', '2024-10-20 14:30:00', 5),
('PL2024002', 'DIABATE Seydou', '+225 07 23 45 67', 'diabate.s@yahoo.fr', 21, 'RETARD_DISTRIBUTION', 'Retard dans la distribution', 'Les manuels de CE2 ne sont toujours pas arrivés dans notre école', 'DEPOSEE', 'MOYENNE', '2024-10-22 09:15:00', 6),
('PL2024003', 'OUATTARA Fatou', '+225 07 34 56 78', NULL, 28, 'QUALITE_MANUEL', 'Manuel défectueux', 'Le manuel de français de ma fille a des pages manquantes', 'RESOLUE', 'BASSE', '2024-10-18 16:45:00', 7);

-- Enquêtes de satisfaction
INSERT INTO enquete_satisfaction (titre, description, type_enquete, questions, date_debut, date_fin, est_active, created_by) VALUES
('Satisfaction Distribution 2024-2025', 'Enquête sur la qualité de la distribution des manuels scolaires', 'PARENTS', 
'[
  {"id": 1, "question": "Êtes-vous satisfait des délais de distribution des manuels ?", "type": "radio", "options": ["Très satisfait", "Satisfait", "Peu satisfait", "Insatisfait"]},
  {"id": 2, "question": "La qualité des manuels reçus est-elle satisfaisante ?", "type": "radio", "options": ["Excellente", "Bonne", "Moyenne", "Mauvaise"]},
  {"id": 3, "question": "Votre enfant a-t-il reçu tous les manuels nécessaires ?", "type": "radio", "options": ["Oui, tous", "Presque tous", "La moitié", "Très peu"]},
  {"id": 4, "question": "Commentaires et suggestions", "type": "textarea", "options": []}
]', '2024-10-01', '2024-12-31', TRUE, 2),

('Évaluation Directeurs EPP', 'Évaluation du processus de distribution par les directeurs', 'DIRECTEURS',
'[
  {"id": 1, "question": "Le processus de commande est-il clair ?", "type": "radio", "options": ["Très clair", "Clair", "Peu clair", "Confus"]},
  {"id": 2, "question": "Les délais de livraison sont-ils respectés ?", "type": "radio", "options": ["Toujours", "Souvent", "Parfois", "Jamais"]},
  {"id": 3, "question": "Notez la communication avec l\'IEPP", "type": "radio", "options": ["Excellente", "Bonne", "Moyenne", "Mauvaise"]}
]', '2024-11-01', '2024-11-30', TRUE, 2);

-- Réponses aux enquêtes
INSERT INTO reponse_enquete (enquete_id, repondant_nom, repondant_telephone, structure_id, reponses, score_satisfaction) VALUES
(1, 'BROU Akissi', '+225 07 45 67 89', 18, 
'[
  {"question_id": 1, "reponse": "Satisfait"},
  {"question_id": 2, "reponse": "Bonne"},
  {"question_id": 3, "reponse": "Oui, tous"},
  {"question_id": 4, "reponse": "Très bon service, continuez ainsi"}
]', 4.2),

(1, 'COULIBALY Ibrahim', '+225 07 56 78 90', 21, 
'[
  {"question_id": 1, "reponse": "Peu satisfait"},
  {"question_id": 2, "reponse": "Moyenne"},
  {"question_id": 3, "reponse": "Presque tous"},
  {"question_id": 4, "reponse": "Il manquait le cahier d\'exercices"}
]', 2.8);

-- Rapports générés
INSERT INTO rapport (titre, type_rapport, periode_debut, periode_fin, structure_id, contenu, statut, created_by) VALUES
('Rapport Mensuel Octobre 2024 - Cocody', 'MENSUEL', '2024-10-01', '2024-10-31', 18,
'{"distributions": 2, "eleves_servis": 77, "manuels_distribues": 308, "taux_completion": 95.2}', 'TERMINE', 8),

('Rapport Régional Abidjan - T1 2024', 'TRIMESTRIEL', '2024-09-01', '2024-12-31', 2,
'{"structures": 5, "distributions": 12, "eleves_servis": 1250, "manuels_distribues": 6800, "plaintes": 3, "satisfaction": 3.8}', 'TERMINE', 5);

-- Notifications
INSERT INTO notification (destinataire_id, titre, message, type_notification, est_lue) VALUES
(8, 'Stock faible détecté', 'Le stock de manuels CP1 Français est en dessous du seuil critique (15 unités restantes)', 'ALERTE', FALSE),
(9, 'Distribution terminée', 'La distribution pour la classe CP1 A a été marquée comme terminée', 'SUCCES', TRUE),
(5, 'Nouvelle plainte assignée', 'Une nouvelle plainte PL2024001 vous a été assignée', 'INFO', FALSE),
(2, 'Rapport mensuel disponible', 'Le rapport mensuel d\'octobre 2024 est disponible', 'INFO', TRUE);

-- Paramètres système
INSERT INTO parametre_systeme (cle, valeur, description, type_valeur) VALUES
('SEUIL_STOCK_CRITIQUE', '20', 'Seuil en dessous duquel une alerte stock est générée', 'INTEGER'),
('DELAI_TRAITEMENT_PLAINTE_JOURS', '7', 'Délai maximum pour traiter une plainte (en jours)', 'INTEGER'),
('EMAIL_NOTIFICATIONS_ACTIVES', 'true', 'Activation des notifications par email', 'BOOLEAN'),
('SMS_NOTIFICATIONS_ACTIVES', 'false', 'Activation des notifications par SMS', 'BOOLEAN'),
('ANNEE_SCOLAIRE_COURANTE', '2024-2025', 'Année scolaire actuellement active', 'STRING'),
('LOGO_SYSTEME', '/images/logo-dismas.png', 'Chemin vers le logo du système', 'STRING'),
('COULEUR_PRIMAIRE', '#FF6600', 'Couleur primaire du thème (Orange CI)', 'STRING'),
('COULEUR_SECONDAIRE', '#00A651', 'Couleur secondaire du thème (Vert CI)', 'STRING');

-- Mise à jour des quantités distribuées dans les inventaires
UPDATE inventaire_manuel SET quantite_distribuee = 40 WHERE structure_id = 18 AND manuel_id IN (1,2,3,4);
UPDATE inventaire_manuel SET quantite_distribuee = 37 WHERE structure_id = 18 AND manuel_id IN (5,6,7,8);
UPDATE inventaire_manuel SET quantite_distribuee = 45 WHERE structure_id = 21 AND manuel_id IN (1,2,3,4);
UPDATE inventaire_manuel SET quantite_distribuee = 38 WHERE structure_id = 28 AND manuel_id IN (9,10,11,12,13);

COMMIT;
