/**
 * Régulation v2 — validation locale des ajustements de quantités avant exécution.
 */
import test from "node:test"
import assert from "node:assert/strict"
import {
  plafondQuantiteAccordeeLigne,
  validateAjustementsAvantEnvoi,
} from "../lib/regulation-v2-ajustement.ts"

test("plafond : accord source prioritaire", () => {
  assert.equal(plafondQuantiteAccordeeLigne(50, 30), 30)
  assert.equal(plafondQuantiteAccordeeLigne(50, 0), 0)
})

test("plafond : fallback quantité courante si pas d’accord stocké", () => {
  assert.equal(plafondQuantiteAccordeeLigne(42, null), 42)
  assert.equal(plafondQuantiteAccordeeLigne(42, undefined), 42)
})

test("validate : accepte baisse dans le plafond et stock", () => {
  const lignes = [
    {
      id: 1,
      statut: "ACCEPTE",
      structureSourceId: 10,
      matiereId: 1,
      niveauId: 2,
      quantite: 20,
      quantiteAccordSource: 20,
    },
  ]
  const stock = new Map([["10|1|2", 100]])
  const r = validateAjustementsAvantEnvoi(lignes, [{ ligneId: 1, quantite: 15 }], stock)
  assert.equal(r.ok, true)
})

test("validate : rejette dépassement plafond", () => {
  const lignes = [
    {
      id: 1,
      statut: "ACCEPTE",
      structureSourceId: 10,
      matiereId: 1,
      niveauId: 2,
      quantite: 20,
      quantiteAccordSource: 20,
    },
  ]
  const r = validateAjustementsAvantEnvoi(lignes, [{ ligneId: 1, quantite: 21 }], new Map([["10|1|2", 100]]))
  assert.equal(r.ok, false)
})

test("validate : somme par source / matière / niveau ≤ stock", () => {
  const lignes = [
    {
      id: 1,
      statut: "ACCEPTE",
      structureSourceId: 10,
      matiereId: 1,
      niveauId: 2,
      quantite: 10,
      quantiteAccordSource: 10,
    },
    {
      id: 2,
      statut: "ACCEPTE",
      structureSourceId: 10,
      matiereId: 1,
      niveauId: 2,
      quantite: 10,
      quantiteAccordSource: 10,
    },
  ]
  const stock = new Map([["10|1|2", 15]])
  const r = validateAjustementsAvantEnvoi(
    lignes,
    [
      { ligneId: 1, quantite: 8 },
      { ligneId: 2, quantite: 8 },
    ],
    stock
  )
  assert.equal(r.ok, false)
})

test("validate : rejette ligne non ACCEPTE", () => {
  const lignes = [
    {
      id: 1,
      statut: "REFUSE",
      structureSourceId: 10,
      matiereId: 1,
      niveauId: 2,
      quantite: 5,
      quantiteAccordSource: null,
    },
  ]
  const r = validateAjustementsAvantEnvoi(lignes, [{ ligneId: 1, quantite: 0 }], new Map())
  assert.equal(r.ok, false)
})
