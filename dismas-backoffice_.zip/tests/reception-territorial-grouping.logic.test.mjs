/**
 * Regroupement territorial : un IEPP, plusieurs EPP — pas de clé IEPP = id EPP.
 */
import test from "node:test"
import assert from "node:assert/strict"
import {
  inferSoleIeppIdFromIeppRows,
  pickTerritorialIeppLabel,
  resolveTerritorialIeppGroupKey,
  sortTerritorialIeppKeys,
} from "../lib/reception-territorial-grouping.ts"

test("EPP sans parent : avant (bug) idStructure différent → faussement plusieurs IEPP ; ici groupe -1 ou parent inféré", () => {
  const sole = inferSoleIeppIdFromIeppRows([{ type: "IEPP", idStructure: 50, ieppId: 50 }])
  assert.equal(sole, 50)
  const eppA = resolveTerritorialIeppGroupKey(
    { type: "EPP", idStructure: 100, ieppId: undefined, idIEPPParent: undefined },
    sole
  )
  const eppB = resolveTerritorialIeppGroupKey(
    { type: "EPP", idStructure: 101, ieppId: undefined, idIEPPParent: undefined },
    sole
  )
  assert.equal(eppA, 50)
  assert.equal(eppB, 50)
})

test("Sans réception IEPP centrale : EPP sans parent → -1 (un seul groupe orphelin)", () => {
  const sole = inferSoleIeppIdFromIeppRows([{ type: "EPP", idStructure: 100 }])
  assert.equal(sole, undefined)
  const k = resolveTerritorialIeppGroupKey(
    { type: "EPP", idStructure: 100, idIEPPParent: undefined },
    undefined
  )
  assert.equal(k, -1)
})

test("pickTerritorialIeppLabel : priorité au libellé de la ligne IEPP centrale", () => {
  const label = pickTerritorialIeppLabel(50, [
    { type: "IEPP", structureLibelle: "IEPP COCODY" },
    { type: "EPP", ieppLibelle: "IEPP (inconnu)" },
  ])
  assert.equal(label, "IEPP COCODY")
})

test("sortTerritorialIeppKeys : -1 en dernier", () => {
  assert.deepEqual(sortTerritorialIeppKeys([ -1, 5, 2 ]), [ 2, 5, -1 ])
})
