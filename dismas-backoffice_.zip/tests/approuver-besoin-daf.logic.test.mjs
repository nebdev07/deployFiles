/**
 * Régression : l’ancienne garde frontend bloquait l’approbation / la prévisualisation
 * lorsque aucun taux ni modification n’était saisi, alors que le backend applique alors
 * l’approbation intégrale des quantités consolidées (BesoinBusiness.approve / previewApprove).
 */
import test from "node:test"
import assert from "node:assert/strict"

/** Ancienne condition (supprimée du modal) — ne pas réintroduire pour bloquer le submit. */
function legacyModalBlockedPreviewOrApprove(tauxGlobal, quantitesSize, exceptionsSize) {
  return !tauxGlobal && quantitesSize === 0 && exceptionsSize === 0
}

test("sans saisie explicite, le backend considère l’approbation complète — ne pas bloquer côté UI", () => {
  assert.equal(legacyModalBlockedPreviewOrApprove(undefined, 0, 0), true)
  // Si cette garde est réactivée, l’utilisateur voit une erreur alors que l’écran affiche déjà le mode COMPLET.
})

test("taux 0 % est une saisie valide (ne pas utiliser !tauxGlobal pour la validation)", () => {
  assert.equal(legacyModalBlockedPreviewOrApprove(0, 0, 0), true)
  // !0 est vrai en JS : l’ancienne garde bloquait aussi le taux 0 % par erreur.
})

test("taux 100 % (1) ou modifications satisfont l’ancienne garde", () => {
  assert.equal(legacyModalBlockedPreviewOrApprove(1, 0, 0), false)
  assert.equal(legacyModalBlockedPreviewOrApprove(undefined, 1, 0), false)
  assert.equal(legacyModalBlockedPreviewOrApprove(undefined, 0, 1), false)
})
