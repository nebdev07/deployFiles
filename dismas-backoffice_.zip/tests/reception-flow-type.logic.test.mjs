/**
 * Régression DRENA / fusion types : RECEPTION_EPP vs EPP canonique vs legacy.
 */
import test from "node:test"
import assert from "node:assert/strict"
import {
  hasReceptionSyntheseTerritoriale,
  normalizeReceptionFlowType,
} from "../lib/reception-flow.ts"

test("RECEPTION_IEPP et IEPP → IEPP", () => {
  assert.equal(normalizeReceptionFlowType({ typeMouvement: "RECEPTION_IEPP" }), "IEPP")
  assert.equal(normalizeReceptionFlowType({ typeMouvement: "IEPP" }), "IEPP")
})

test("RECEPTION_EPP et EPP → EPP (pas confondu avec IEPP)", () => {
  assert.equal(normalizeReceptionFlowType({ typeMouvement: "RECEPTION_EPP" }), "EPP")
  assert.equal(normalizeReceptionFlowType({ typeMouvement: "EPP" }), "EPP")
})

test("RECEPTION_IEPP ne doit pas être classé EPP (substring EPP dans IEPP)", () => {
  assert.equal(normalizeReceptionFlowType({ typeMouvement: "RECEPTION_IEPP" }), "IEPP")
})

test("chaînes vides → UNKNOWN", () => {
  assert.equal(normalizeReceptionFlowType({}), "UNKNOWN")
})

test("hasReceptionSyntheseTerritoriale : DRENA et DAF uniquement", () => {
  assert.equal(hasReceptionSyntheseTerritoriale("DRENA"), true)
  assert.equal(hasReceptionSyntheseTerritoriale("DAF"), true)
  assert.equal(hasReceptionSyntheseTerritoriale("IEPP"), false)
  assert.equal(hasReceptionSyntheseTerritoriale(undefined), false)
})
