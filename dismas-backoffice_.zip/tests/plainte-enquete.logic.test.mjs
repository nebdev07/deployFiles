/**
 * Tests légers : contraintes de longueur alignées sur le backend (varchar q1/q2/q3).
 */
import assert from "node:assert/strict";
import { test } from "node:test";

test("Q1 codes respectent longueur ≤ 10", () => {
  const q1 = ["TRES_BON", "SATISFAIT", "MOYEN", "FAIBLE", "INSAT"];
  for (const v of q1) {
    assert.ok(v.length <= 10, v);
  }
});

test("Q2 codes respectent longueur ≤ 9", () => {
  const q2 = ["BON_ETAT", "MOYEN", "MAUVAIS"];
  for (const v of q2) {
    assert.ok(v.length <= 9, v);
  }
});

test("Q3 codes respectent longueur ≤ 15", () => {
  const q3 = ["A_L_HEURE", "EN_RETARD", "NON_CONCERNE"];
  for (const v of q3) {
    assert.ok(v.length <= 15, v);
  }
});

test("Types répondants courts pour colonne étendue", () => {
  const types = ["PARENTS", "DIRECTEURS", "MAITRES", "COGES"];
  for (const t of types) {
    assert.ok(t.length <= 32, t);
  }
});
