/**
 * Flux métier : rôle personnalisé + matrice RBAC (sans serveur).
 * Vérifie la normalisation des codes et la projection matrice → clés session.
 */
import test from "node:test"
import assert from "node:assert/strict"
import {
  flattenMatrixRowsToFunctionalityPermissions,
  normalizeRoleCodeForStorage,
} from "../lib/rbac-workflow-helpers.ts"

/** Copie minimale de {@code hasFunctionalityPermission} (évite import @/ sous node --test). */
function hasFunctionalityPermission(permissions, fonctionaliteCode, permissionType) {
  if (!permissions?.length) return false
  const key = `${fonctionaliteCode}:${permissionType}`.toUpperCase()
  return permissions.some((p) => p.toUpperCase() === key)
}

/** Copie minimale de {@code canShowMenuItem} pour les cas READ + repli rôle. */
function canShowMenuItem(userRoleCode, rolesAllowed, functionalityPermissions, functionalityReadCode) {
  const rc = (userRoleCode || "").toUpperCase()
  if (!functionalityPermissions?.length) {
    return rolesAllowed.includes(rc)
  }
  if (functionalityReadCode) {
    return hasFunctionalityPermission(functionalityPermissions, functionalityReadCode, "READ")
  }
  return rolesAllowed.includes(rc)
}

test("RBAC workflow : normalisation code rôle (stable, ASCII)", () => {
  assert.equal(normalizeRoleCodeForStorage("  mon role  "), "MON_ROLE")
  assert.equal(normalizeRoleCodeForStorage("Info-EPP"), "INFO_EPP")
  assert.equal(normalizeRoleCodeForStorage("INFORMATICIEN"), "INFORMATICIEN")
})

test("RBAC workflow : matrice → liste functionalityPermissions", () => {
  const keys = flattenMatrixRowsToFunctionalityPermissions([
    { code: "besoin", grantedPermissionTypes: ["read", "CREATE"] },
    { code: "MOUVEMENT", grantedPermissionTypes: ["READ"] },
  ])
  assert.deepEqual(keys, ["BESOIN:CREATE", "BESOIN:READ", "MOUVEMENT:READ"])
})

test("RBAC workflow : rôle inconnu sans RBAC → pas dans la liste menu", () => {
  assert.equal(
    canShowMenuItem("MON_METIER", ["DAF", "ADMIN"], undefined, "BESOIN"),
    false,
  )
})

test("RBAC workflow : rôle inconnu avec BESOIN:READ → accès READ menu", () => {
  assert.equal(
    canShowMenuItem("MON_METIER", ["DAF"], ["BESOIN:READ"], "BESOIN"),
    true,
  )
})

test("RBAC workflow : permission explicite pour profil arbitraire", () => {
  assert.equal(hasFunctionalityPermission(["BESOIN:APPROVE"], "BESOIN", "APPROVE"), true)
  assert.equal(hasFunctionalityPermission(["besoin:approve"], "BESOIN", "APPROVE"), true)
})
