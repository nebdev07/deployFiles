/**
 * Aligné sur lib/utils/api-error-message.ts — vérifie que les erreurs
 * jetées par BaseApiService (code + message + details.status) restent lisibles pour les toasts.
 */
import test from "node:test"
import assert from "node:assert/strict"

/** Copie des règles utiles (garder synchro avec getApiErrorMessage côté TS). */
function getApiErrorMessage(error, fallback = "") {
  if (error == null) return fallback
  if (typeof error === "string") {
    const t = error.trim()
    return t || fallback
  }
  if (error instanceof Error) {
    const m = error.message?.trim()
    if (m) return m
  }
  if (typeof error !== "object") {
    return String(error) || fallback
  }
  const o = error
  const direct = o.message
  if (typeof direct === "string" && direct.trim()) return direct.trim()
  const rootStatus = o.status
  const fromRootStatus = rootStatus && typeof rootStatus === "object" ? rootStatus.message : undefined
  if (typeof fromRootStatus === "string" && fromRootStatus.trim()) return fromRootStatus.trim()
  const details = o.details
  const status = details && typeof details === "object" ? details.status : undefined
  const fromStatus = status && typeof status === "object" ? status.message : undefined
  if (typeof fromStatus === "string" && fromStatus.trim()) return fromStatus.trim()
  const code = o.code != null ? String(o.code) : ""
  if (code && code !== "UNKNOWN_ERROR") {
    const base = fallback || "Erreur"
    return `${base} (code ${code})`
  }
  return fallback
}

test("message exécution régulation v2 (905) sur ApiError jetée par le client HTTP", () => {
  const backendMsg =
    "Champ non renseigne: Des lignes sont encore en attente d'accord des structures sources."
  const thrown = {
    code: "905",
    message: backendMsg,
    details: {
      hasError: true,
      status: { code: "905", message: backendMsg },
    },
  }
  assert.equal(getApiErrorMessage(thrown, "Exécution impossible"), backendMsg)
})

test("message uniquement dans details.status", () => {
  const thrown = {
    code: "905",
    message: "   ",
    details: { status: { message: "Détail seulement" } },
  }
  assert.equal(getApiErrorMessage(thrown, "fb"), "Détail seulement")
})

test("message sur status racine (forme ApiResponse aplatie)", () => {
  const thrown = {
    code: "905",
    status: { code: "905", message: "Depuis status racine" },
  }
  assert.equal(getApiErrorMessage(thrown, "fb"), "Depuis status racine")
})
