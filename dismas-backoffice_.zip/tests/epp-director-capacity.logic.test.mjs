import assert from "node:assert/strict"
import { describe, it } from "node:test"
import {
  MAX_DIRECTEURS_PAR_EPP,
  collectEppDirectorCounts,
  isEppDirectorCapacityReached,
} from "../lib/utils/epp-director-capacity.ts"

describe("Plafond directeurs par EPP (liste hiérarchique)", () => {
  const row = { drenaCode: "DR01", ieppCode: "IE01", code: "EP01" }

  it("MAX_DIRECTEURS_PAR_EPP vaut 2", () => {
    assert.equal(MAX_DIRECTEURS_PAR_EPP, 2)
  })

  it("sans directeur, la ligne reste disponible", () => {
    const counts = collectEppDirectorCounts([])
    assert.equal(isEppDirectorCapacityReached(row, counts), false)
  })

  it("un directeur : pas encore plafond", () => {
    const counts = collectEppDirectorCounts([
      { roleCode: "DIRECTEUR", drenaCode: "DR01", ieppCode: "IE01", eppCode: "EP01" },
    ])
    assert.equal(isEppDirectorCapacityReached(row, counts), false)
  })

  it("deux directeurs même EPP : plafond", () => {
    const counts = collectEppDirectorCounts([
      { roleCode: "DIRECTEUR", drenaCode: "DR01", ieppCode: "IE01", eppCode: "EP01" },
      { roleCode: "directeur", drenaCode: "DR01", ieppCode: "IE01", eppCode: "EP01" },
    ])
    assert.equal(isEppDirectorCapacityReached(row, counts), true)
  })

  it("deux directeurs autre EPP : ne bloque pas cette ligne", () => {
    const counts = collectEppDirectorCounts([
      { roleCode: "DIRECTEUR", drenaCode: "DR01", ieppCode: "IE01", eppCode: "EP99" },
      { roleCode: "DIRECTEUR", drenaCode: "DR01", ieppCode: "IE01", eppCode: "EP99" },
    ])
    assert.equal(isEppDirectorCapacityReached(row, counts), false)
  })
})
