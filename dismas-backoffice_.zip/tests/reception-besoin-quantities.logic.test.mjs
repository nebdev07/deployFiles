/**
 * Agrégation demandée vs approuvée (réception IEPP depuis consolidation EPP).
 */
import test from "node:test"
import assert from "node:assert/strict"
import {
  aggregateConsolidationEppByNiveauMatiere,
  besoinDetailQuantiteDemandee,
} from "../lib/reception-besoin-quantities.ts"

test("besoinDetailQuantiteDemandee : priorité consolidée > net > brut", () => {
  assert.equal(
    besoinDetailQuantiteDemandee({ quantiteConsolidee: 200, quantiteNet: 100 }),
    200
  )
  assert.equal(besoinDetailQuantiteDemandee({ quantiteNet: 100, quantiteBrute: 50 }), 100)
  assert.equal(besoinDetailQuantiteDemandee({ quantiteBrute: 50 }), 50)
})

test("deux EPP même niveau/matière : 100+100 demandé, 80+80 approuvé → 200 / 160", () => {
  const data = [
    {
      besoinDetails: [
        {
          niveauScolaireId: 1,
          matiereId: 1,
          matiereLibelle: "Français",
          matiereCode: "FR",
          niveauScolaireLibelle: "CP1",
          niveauScolaireCode: "CP1",
          quantiteNet: 100,
          quantiteApprouvee: 80,
        },
      ],
    },
    {
      besoinDetails: [
        {
          niveauScolaireId: 1,
          matiereId: 1,
          matiereLibelle: "Français",
          matiereCode: "FR",
          niveauScolaireLibelle: "CP1",
          niveauScolaireCode: "CP1",
          quantiteNet: 100,
          quantiteApprouvee: 80,
        },
      ],
    },
  ]
  const m = aggregateConsolidationEppByNiveauMatiere(data)
  const row = m.get("1-1")
  assert.ok(row)
  assert.equal(row.quantiteDemandee, 200)
  assert.equal(row.quantiteApprouvee, 160)
})

test("clés niveau-matière distinctes ne se mélangent pas", () => {
  const data = [
    {
      besoinDetails: [
        { niveauScolaireId: 1, matiereId: 1, quantiteNet: 100, quantiteApprouvee: 80 },
        { niveauScolaireId: 4, matiereId: 1, quantiteNet: 100, quantiteApprouvee: 80 },
      ],
    },
  ]
  const m = aggregateConsolidationEppByNiveauMatiere(data)
  assert.equal(m.get("1-1")?.quantiteDemandee, 100)
  assert.equal(m.get("4-1")?.quantiteDemandee, 100)
})
