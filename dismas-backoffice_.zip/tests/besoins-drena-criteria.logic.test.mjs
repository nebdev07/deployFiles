/**
 * Critères chargement besoins : DRENA doit envoyer drenaId du profil (le backend applique en plus le scope structure).
 */
import test from "node:test"
import assert from "node:assert/strict"
import { buildBesoinGetByCriteriaPayload } from "../lib/besoins-load-criteria.ts"

test("DIRECTEUR : structureId uniquement", () => {
  const c = buildBesoinGetByCriteriaPayload({
    roleCode: "DIRECTEUR",
    structureId: 42,
    drenaIdFromProfile: 99,
  })
  assert.deepEqual(c, { structureId: 42 })
})

test("DRENA : drenaId du profil", () => {
  const c = buildBesoinGetByCriteriaPayload({
    roleCode: "DRENA",
    structureId: 1,
    drenaIdFromProfile: 7,
  })
  assert.deepEqual(c, { drenaId: 7 })
})

test("DRENA sans drena en profil : pas de drenaId (évite requête incohérente)", () => {
  const c = buildBesoinGetByCriteriaPayload({
    roleCode: "DRENA",
    drenaIdFromProfile: undefined,
  })
  assert.deepEqual(c, {})
})

test("IEPP : critères vides (filtrage UI / backend)", () => {
  const c = buildBesoinGetByCriteriaPayload({ roleCode: "IEPP" })
  assert.deepEqual(c, {})
})

test("INTENDANT + BESOIN:READ en session : structureId pour périmètre liste", () => {
  const c = buildBesoinGetByCriteriaPayload({
    roleCode: "INTENDANT",
    structureId: 12,
    functionalityPermissions: ["BESOIN:READ", "BESOIN:CREATE"],
  })
  assert.deepEqual(c, { structureId: 12 })
})

test("DAF + BESOIN:READ : pas de structureId (liste nationale / validation)", () => {
  const c = buildBesoinGetByCriteriaPayload({
    roleCode: "DAF",
    structureId: 999,
    functionalityPermissions: ["BESOIN:READ"],
  })
  assert.deepEqual(c, {})
})
