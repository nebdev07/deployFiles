/**
 * Règle alignée sur MouvementBusiness.loadFromBesoin :
 * - IEPP : statut APPROUVE
 * - EPP : CONSOLIDE ou APPROUVE
 */
import test from "node:test"
import assert from "node:assert/strict"

function statutOkPourLoadFromBesoin(statutBesoin, typeStructure) {
  return (
    statutBesoin === "APPROUVE" ||
    (statutBesoin === "CONSOLIDE" && typeStructure === "EPP")
  )
}

test("IEPP : seul APPROUVE est accepté", () => {
  assert.equal(statutOkPourLoadFromBesoin("CONSOLIDE", "IEPP"), false)
  assert.equal(statutOkPourLoadFromBesoin("APPROUVE", "IEPP"), true)
})

test("EPP : CONSOLIDE ou APPROUVE", () => {
  assert.equal(statutOkPourLoadFromBesoin("CONSOLIDE", "EPP"), true)
  assert.equal(statutOkPourLoadFromBesoin("APPROUVE", "EPP"), true)
  assert.equal(statutOkPourLoadFromBesoin("SAISI", "EPP"), false)
})
