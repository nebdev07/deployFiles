/**
 * Cas régression : API renvoie 2x les mêmes lignes (quantités 0 puis réelles).
 */
import test from "node:test"
import assert from "node:assert/strict"
import {
  dedupeManuelsLignes,
  manuelsDepuisCatalogueMouvements,
} from "../lib/reception-manuels-display.ts"

test("dedupeManuelsLignes garde la ligne avec quantité reçue max", () => {
  const rows = [
    {
      code: "FR LIVRE",
      titre: "Livre Français",
      niveau: "Catalogue CP2",
      quantite_prevue: 100,
      quantite_recue: 0,
      ecart: -100,
    },
    {
      code: "FR LIVRE",
      titre: "Livre Français",
      niveau: "Catalogue CP2",
      quantite_prevue: 100,
      quantite_recue: 100,
      ecart: 0,
    },
  ]
  const out = dedupeManuelsLignes(rows)
  assert.equal(out.length, 1)
  assert.equal(out[0].quantite_recue, 100)
  assert.equal(out[0].ecart, 0)
})

test("manuelsDepuisCatalogueMouvements fusionne catalogues doublonnés", () => {
  const catalogueMouvements = [
    {
      catalogueLibelle: "Catalogue CP2",
      matiereQuantites: [
        {
          matiereCode: "X",
          matiereLibelle: "Livre",
          quantitePrevue: 100,
          quantiteRecue: 0,
        },
      ],
    },
    {
      catalogueLibelle: "Catalogue CP2",
      matiereQuantites: [
        {
          matiereCode: "X",
          matiereLibelle: "Livre",
          quantitePrevue: 100,
          quantiteRecue: 100,
        },
      ],
    },
  ]
  const out = manuelsDepuisCatalogueMouvements(catalogueMouvements)
  assert.equal(out.length, 1)
  assert.equal(out[0].quantite_recue, 100)
})
