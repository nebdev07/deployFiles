/**
 * Régulation v2 IEPP : mobilisation vs agrégat déficit et construction des lignes API.
 */
import test from "node:test"
import assert from "node:assert/strict"
import {
  validateMobilisationAgainstAgregat,
  validateMobilisationAgainstExcedent,
  buildCreerDemandeSources,
  recordToMobilisationEntries,
  mobilisationKey,
} from "../lib/regulation-v2-mobilisation.ts"

const agregats = [
  {
    matiereId: 1,
    niveauId: 10,
    deficitTotal: 15,
    repartitionParEpp: [
      { eppId: 101, deficit: 9 },
      { eppId: 102, deficit: 6 },
    ],
  },
]

test("validate : somme mobilisée ≤ besoin agrégé", () => {
  const entries = [
    { sourceEppId: 201, matiereId: 1, niveauId: 10, quantite: 10, excedentMax: 20 },
    { sourceEppId: 202, matiereId: 1, niveauId: 10, quantite: 5, excedentMax: 20 },
  ]
  assert.equal(validateMobilisationAgainstAgregat(agregats, entries).ok, true)
})

test("validate : rejette si dépassement", () => {
  const entries = [{ sourceEppId: 201, matiereId: 1, niveauId: 10, quantite: 20, excedentMax: 30 }]
  const r = validateMobilisationAgainstAgregat(agregats, entries)
  assert.equal(r.ok, false)
})

test("validate : saisie + déjà en demande ne doit pas dépasser le besoin agrégé", () => {
  const entries = [{ sourceEppId: 201, matiereId: 1, niveauId: 10, quantite: 5, excedentMax: 30 }]
  const engagedOk = new Map([["1-10", 10]])
  assert.equal(validateMobilisationAgainstAgregat(agregats, entries, engagedOk).ok, true)
  const engagedTooMuch = new Map([["1-10", 11]])
  assert.equal(validateMobilisationAgainstAgregat(agregats, entries, engagedTooMuch).ok, false)
})

test("validate excédent : saisie + en demande ≤ excédent déclaré", () => {
  const flat = [{ eppId: 5, matiereId: 1, niveauId: 2, matiereLibelle: "M", niveauLibelle: "N", excedent: 10 }]
  const entries = [{ sourceEppId: 5, matiereId: 1, niveauId: 2, quantite: 2, excedentMax: 10 }]
  const engaged = new Map([[mobilisationKey(5, 1, 2), 8]])
  assert.equal(validateMobilisationAgainstExcedent(entries, flat, engaged).ok, true)
  assert.equal(validateMobilisationAgainstExcedent(entries, flat, new Map([[mobilisationKey(5, 1, 2), 9]])).ok, false)
})

test("buildCreerDemandeSources : répartition vers déficits sans dépasser", () => {
  const entries = [
    { sourceEppId: 201, matiereId: 1, niveauId: 10, quantite: 12, excedentMax: 20 },
  ]
  const sources = buildCreerDemandeSources(agregats, entries)
  const to101 = sources.filter((s) => s.structureDestId === 101).reduce((s, x) => s + x.quantite, 0)
  const to102 = sources.filter((s) => s.structureDestId === 102).reduce((s, x) => s + x.quantite, 0)
  assert.equal(to101, 9)
  assert.equal(to102, 3)
  assert.equal(sources.every((s) => s.structureSourceId === 201), true)
})

test("recordToMobilisationEntries : plafonne à l’excédent connu", () => {
  const flat = [{ eppId: 5, matiereId: 1, niveauId: 2, matiereLibelle: "M", niveauLibelle: "N", excedent: 3 }]
  const rec = { [mobilisationKey(5, 1, 2)]: 99 }
  const entries = recordToMobilisationEntries(rec, flat)
  assert.equal(entries.length, 1)
  assert.equal(entries[0].quantite, 3)
})
