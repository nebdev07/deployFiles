// Script Playwright CORRIGÉ - Ignore les vérifications réseau
const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');

// Configuration des utilisateurs de test
const users = [
  { role: 'ADMIN', login: 'admin', password: 'admin123' },
  { role: 'DAF', login: 'daf.kouame', password: 'daf123' },
  { role: 'DRENA', login: 'drena.kone', password: 'drena123' },
  { role: 'IEPP', login: 'iepp.assi', password: 'iepp123' },
  { role: 'DIRECTEUR', login: 'dir.kouadio', password: 'dir123' }
];

// Pages à capturer par rôle (configuration réduite pour test)
const captureConfig = {
  ADMIN: [
    { path: '/dashboard', name: 'Dashboard_Vue_Nationale' },
    { path: '/besoins', name: 'Besoins_Consolidation' },
    { path: '/commandes', name: 'Commandes_Acces_Autorise' }
  ],
  DAF: [
    { path: '/dashboard', name: 'Dashboard_Vue_Financiere' },
    { path: '/commandes', name: 'Commandes_Gestion' }
  ],
  DRENA: [
    { path: '/dashboard', name: 'Dashboard_Vue_Regionale' },
    { path: '/besoins', name: 'Besoins_Consolidation_DRENA' },
    { path: '/commandes', name: 'Commandes_Acces_Refuse' }
  ],
  IEPP: [
    { path: '/dashboard', name: 'Dashboard_Vue_Circonscription' },
    { path: '/besoins', name: 'Besoins_Consolidation_IEPP' },
    { path: '/distribution', name: 'Distribution_Validation_IEPP' }
  ],
  DIRECTEUR: [
    { path: '/dashboard', name: 'Dashboard_Vue_Ecole' },
    { path: '/besoins', name: 'Besoins_Saisie_EPP' },
    { path: '/commandes', name: 'Commandes_Acces_Refuse' }
  ]
};

async function captureScreenshots() {
  console.log('🚀 DÉMARRAGE CAPTURE DISMAS');
  console.log('⚠️  IGNORANT LES VÉRIFICATIONS RÉSEAU');
  console.log('📱 Assurez-vous que http://localhost:3000 fonctionne dans votre navigateur\n');
  
  let browser;
  
  try {
    // Créer dossier captures
    const capturesDir = './captures';
    if (!fs.existsSync(capturesDir)) {
      fs.mkdirSync(capturesDir);
      console.log('📁 Dossier captures créé\n');
    }

    console.log('🌐 Lancement du navigateur...');
    browser = await chromium.launch({ 
      headless: false,  // Mode visible pour voir ce qui se passe
      slowMo: 200,      // Ralentir pour debugging
      args: ['--no-sandbox', '--disable-setuid-sandbox'] // Pour éviter les problèmes de permissions
    });
    console.log('✅ Navigateur lancé\n');

    for (let i = 0; i < users.length; i++) {
      const user = users[i];
      console.log(`${'='.repeat(60)}`);
      console.log(`🔐 [${i + 1}/${users.length}] RÔLE: ${user.role}`);
      console.log(`${'='.repeat(60)}`);
      
      const context = await browser.newContext({
        viewport: { width: 1920, height: 1080 }
      });
      const page = await context.newPage();

      try {
        // 1. Navigation vers la page de login
        console.log('🌐 Navigation vers la page de login...');
        await page.goto('http://localhost:3000', { 
          waitUntil: 'domcontentloaded', 
          timeout: 30000 
        });
        
        // Attendre que la page soit complètement chargée
        await page.waitForTimeout(3000);
        console.log('✅ Page de login chargée');

        // 2. Capture de la page de login (pour debug)
        if (i === 0) { // Seulement pour le premier utilisateur
          await page.screenshot({ 
            path: path.join(capturesDir, 'DEBUG_Login_Page.png'),
            fullPage: true
          });
          console.log('🖼️  Capture debug de la page de login sauvegardée');
        }

        // 3. Tentative de connexion avec plusieurs stratégies
        console.log(`🔑 Connexion avec ${user.login}...`);
        
        // Stratégie 1: Sélecteurs CSS simples
        try {
          await page.fill('input[type="text"]', user.login);
          await page.fill('input[type="password"]', user.password);
          console.log('✅ Champs remplis (stratégie CSS)');
        } catch (error) {
          // Stratégie 2: Par position
          console.log('⚠️  Stratégie CSS échouée, tentative par position...');
          const inputs = await page.$$('input');
          if (inputs.length >= 2) {
            await inputs[0].fill(user.login);
            await inputs[1].fill(user.password);
            console.log('✅ Champs remplis (stratégie position)');
          } else {
            throw new Error('Pas assez de champs input trouvés');
          }
        }

        // Tentative de clic sur le bouton
        try {
          await page.click('button[type="submit"]');
          console.log('✅ Bouton submit cliqué');
        } catch (error) {
          // Tentative avec d'autres sélecteurs
          const buttons = await page.$$('button');
          if (buttons.length > 0) {
            await buttons[0].click();
            console.log('✅ Premier bouton cliqué');
          } else {
            throw new Error('Aucun bouton trouvé');
          }
        }

        // Attendre la redirection
        console.log('⏳ Attente de la redirection...');
        await page.waitForTimeout(4000);
        
        const currentUrl = page.url();
        console.log(`📍 URL actuelle: ${currentUrl}`);
        
        if (!currentUrl.includes('dashboard')) {
          console.log('⚠️  Pas de redirection vers dashboard, tentative de navigation manuelle...');
          await page.goto('http://localhost:3000/dashboard', { 
            waitUntil: 'domcontentloaded', 
            timeout: 15000 
          });
          await page.waitForTimeout(2000);
        }

        // 4. Capturer les pages spécifiques au rôle
        const pagesToCapture = captureConfig[user.role] || [];
        console.log(`📸 ${pagesToCapture.length} pages à capturer pour ${user.role}`);
        
        for (let j = 0; j < pagesToCapture.length; j++) {
          const pageConfig = pagesToCapture[j];
          console.log(`\n   [${j + 1}/${pagesToCapture.length}] ${pageConfig.name}...`);
          
          try {
            await page.goto(`http://localhost:3000${pageConfig.path}`, { 
              waitUntil: 'domcontentloaded', 
              timeout: 20000 
            });
            
            // Attendre le chargement des données
            await page.waitForTimeout(4000);

            // Faire défiler vers le haut
            await page.evaluate(() => window.scrollTo(0, 0));
            await page.waitForTimeout(1000);

            const filename = `${user.role}_${pageConfig.name}.png`;
            await page.screenshot({ 
              path: path.join(capturesDir, filename),
              fullPage: true,
              quality: 85
            });
            
            console.log(`   ✅ Sauvegardé: ${filename}`);
          } catch (error) {
            console.log(`   ❌ Erreur ${pageConfig.name}: ${error.message}`);
            
            // Capture d'écran d'erreur
            try {
              const errorFilename = `${user.role}_${pageConfig.name}_ERROR.png`;
              await page.screenshot({ 
                path: path.join(capturesDir, errorFilename),
                fullPage: true
              });
              console.log(`   📸 Capture d'erreur: ${errorFilename}`);
            } catch (screenshotError) {
              console.log(`   ❌ Impossible de capturer l'erreur`);
            }
          }
        }

        console.log(`✅ Captures terminées pour ${user.role}`);

      } catch (error) {
        console.log(`❌ Erreur générale pour ${user.role}:`);
        console.log(`   ${error.message}`);
      } finally {
        await context.close();
        console.log(`🔒 Session ${user.role} fermée\n`);
      }
    }

  } catch (globalError) {
    console.log(`💥 Erreur globale: ${globalError.message}`);
  } finally {
    if (browser) {
      await browser.close();
      console.log('🌐 Navigateur fermé');
    }
  }
  
  console.log('\n' + '='.repeat(60));
  console.log('🎉 SCRIPT TERMINÉ!');
  console.log('📁 Vérifiez le dossier ./captures pour les images');
  console.log('='.repeat(60));
}

// Démarrage immédiat sans vérifications
console.log('🚀 LANCEMENT IMMÉDIAT (sans vérifications réseau)');
console.log('📱 Assurez-vous que http://localhost:3000 fonctionne dans votre navigateur');
console.log('⏰ Démarrage dans 3 secondes...\n');

setTimeout(() => {
  captureScreenshots().catch(error => {
    console.error('💥 Erreur fatale:', error);
    console.log('\n📧 Si l\'erreur persiste, envoyez-moi le message complet!');
  });
}, 3000);