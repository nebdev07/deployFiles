# Script PowerShell pour tester la récupération du niveau scolaire via l'API
# Date: 2025-10-12

Write-Host "🧪 TEST API : Vérification de la présence de idNiveauScolaire" -ForegroundColor Cyan
Write-Host "================================================================" -ForegroundColor Cyan
Write-Host ""

# 1. Se connecter pour obtenir un token valide
Write-Host "1️⃣  Connexion..." -ForegroundColor Yellow

$loginBody = @{
    user = 0
    isSimpleLoading = $false
    data = @{
        login = "ieppAbdj3"
        password = "passer"
    }
} | ConvertTo-Json -Depth 5

try {
    $loginResponse = Invoke-WebRequest -Uri 'http://localhost:8081/user/login' `
        -Method POST `
        -Headers @{'Content-Type'='application/json'} `
        -Body $loginBody

    $loginData = $loginResponse.Content | ConvertFrom-Json
    
    if ($loginData.hasError) {
        Write-Host "❌ Erreur de connexion: $($loginData.status.message)" -ForegroundColor Red
        exit 1
    }
    
    $userId = $loginData.items[0].id
    $token = $loginData.items[0].token
    
    Write-Host "✅ Connexion réussie!" -ForegroundColor Green
    Write-Host "   User ID: $userId" -ForegroundColor Gray
    Write-Host "   Token: $($token.Substring(0, 20))..." -ForegroundColor Gray
    Write-Host ""
    
} catch {
    Write-Host "❌ Erreur lors de la connexion: $_" -ForegroundColor Red
    exit 1
}

# 2. Récupérer les catalogues actifs
Write-Host "2️⃣  Récupération des catalogues actifs..." -ForegroundColor Yellow

$catalogueBody = @{
    user = $userId
    token = $token
    isSimpleLoading = $false
    data = @{
        isdeleted = "false"
    }
} | ConvertTo-Json -Depth 5

try {
    $catalogueResponse = Invoke-WebRequest -Uri 'http://localhost:8081/catalogue/getByCriteria' `
        -Method POST `
        -Headers @{'Content-Type'='application/json'} `
        -Body $catalogueBody

    $catalogueData = $catalogueResponse.Content | ConvertFrom-Json
    
    if ($catalogueData.hasError) {
        Write-Host "❌ Erreur récupération catalogues: $($catalogueData.status.message)" -ForegroundColor Red
        exit 1
    }
    
    $catalogues = $catalogueData.items
    
    Write-Host "✅ $($catalogues.Count) catalogue(s) trouvé(s)" -ForegroundColor Green
    
    # Afficher les premiers catalogues
    foreach ($cat in $catalogues | Select-Object -First 3) {
        Write-Host "   📚 Catalogue ID: $($cat.id) - $($cat.libelle)" -ForegroundColor Gray
        Write-Host "      Niveau: $($cat.niveauScolaireLibelle) (ID: $($cat.idNiveauScolaire))" -ForegroundColor Gray
        Write-Host "      Année: $($cat.anneeScolaireLibelle)" -ForegroundColor Gray
    }
    Write-Host ""
    
    # Sélectionner le premier catalogue pour le test
    $testCatalogue = $catalogues[0]
    
} catch {
    Write-Host "❌ Erreur lors de la récupération des catalogues: $_" -ForegroundColor Red
    exit 1
}

# 3. Récupérer les matières d'un catalogue (TEST CRITIQUE)
Write-Host "3️⃣  Récupération des matières du catalogue ID: $($testCatalogue.id) ($($testCatalogue.libelle))..." -ForegroundColor Yellow

$matiereBody = @{
    user = $userId
    token = $token
    isSimpleLoading = $false
    data = @{
        catalogueId = $testCatalogue.id
    }
} | ConvertTo-Json -Depth 5

try {
    $matiereResponse = Invoke-WebRequest -Uri 'http://localhost:8081/catalogueMatiere/getByCriteria' `
        -Method POST `
        -Headers @{'Content-Type'='application/json'} `
        -Body $matiereBody

    $matiereData = $matiereResponse.Content | ConvertFrom-Json
    
    if ($matiereData.hasError) {
        Write-Host "❌ Erreur récupération matières: $($matiereData.status.message)" -ForegroundColor Red
        exit 1
    }
    
    $matieres = $matiereData.items
    
    Write-Host "✅ $($matieres.Count) matière(s) trouvée(s)" -ForegroundColor Green
    Write-Host ""
    
    # VÉRIFICATION CRITIQUE : Le niveau est-il présent ?
    Write-Host "🔍 VÉRIFICATION CRITIQUE : Présence de idNiveauScolaire" -ForegroundColor Cyan
    Write-Host "========================================================" -ForegroundColor Cyan
    Write-Host ""
    
    $allHaveNiveau = $true
    foreach ($mat in $matieres) {
        $hasNiveau = $null -ne $mat.idNiveauScolaire
        $status = if ($hasNiveau) { "✅" } else { "❌" }
        $color = if ($hasNiveau) { "Green" } else { "Red" }
        
        Write-Host "$status Matière: $($mat.matiereLibelle)" -ForegroundColor $color
        Write-Host "   ID Matière: $($mat.matiereId)" -ForegroundColor Gray
        Write-Host "   Code: $($mat.matiereCode)" -ForegroundColor Gray
        Write-Host "   idNiveauScolaire: $($mat.idNiveauScolaire)" -ForegroundColor $(if ($hasNiveau) { "Green" } else { "Red" })
        Write-Host "   niveauScolaireLibelle: $($mat.niveauScolaireLibelle)" -ForegroundColor Gray
        Write-Host "   niveauScolaireCode: $($mat.niveauScolaireCode)" -ForegroundColor Gray
        Write-Host ""
        
        if (-not $hasNiveau) {
            $allHaveNiveau = $false
        }
    }
    
    Write-Host "========================================================" -ForegroundColor Cyan
    if ($allHaveNiveau) {
        Write-Host "🎉 SUCCÈS : Toutes les matières ont un idNiveauScolaire !" -ForegroundColor Green
    } else {
        Write-Host "❌ ÉCHEC : Certaines matières n'ont pas de idNiveauScolaire" -ForegroundColor Red
    }
    Write-Host ""
    
    # Afficher un exemple complet de CatalogueMatiereDto
    if ($matieres.Count -gt 0) {
        Write-Host "📋 EXEMPLE DE RÉPONSE COMPLÈTE (première matière):" -ForegroundColor Cyan
        Write-Host "========================================================" -ForegroundColor Cyan
        $matieres[0] | ConvertTo-Json -Depth 5
        Write-Host ""
    }
    
} catch {
    Write-Host "❌ Erreur lors de la récupération des matières: $_" -ForegroundColor Red
    exit 1
}

# 4. Résumé final
Write-Host "================================================================" -ForegroundColor Cyan
Write-Host "✅ TEST TERMINÉ" -ForegroundColor Green
Write-Host ""
Write-Host "📊 Résumé:" -ForegroundColor Cyan
Write-Host "   - Catalogues trouvés: $($catalogues.Count)" -ForegroundColor Gray
Write-Host "   - Matières dans catalogue $($testCatalogue.id): $($matieres.Count)" -ForegroundColor Gray
Write-Host "   - Toutes avec niveau: $(if ($allHaveNiveau) { 'OUI ✅' } else { 'NON ❌' })" -ForegroundColor $(if ($allHaveNiveau) { "Green" } else { "Red" })
Write-Host ""
Write-Host "🎯 CONCLUSION:" -ForegroundColor Cyan
if ($allHaveNiveau) {
    Write-Host "   Le backend retourne correctement idNiveauScolaire !" -ForegroundColor Green
    Write-Host "   Le frontend peut l'utiliser sans problème." -ForegroundColor Green
} else {
    Write-Host "   PROBLÈME: Le backend ne retourne pas idNiveauScolaire" -ForegroundColor Red
    Write-Host "   Action requise: Vérifier le transformer ou la base de données" -ForegroundColor Red
}
Write-Host "================================================================" -ForegroundColor Cyan

