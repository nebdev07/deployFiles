/** @type {import('next').NextConfig} */
const nextConfig = {
    async rewrites() {
      return [
        {
          source: '/dismas-api/:path*',
          destination: 'http://localhost:8081/dismas-api/:path*',
        },
      ];
    },
  };
  
  module.exports = nextConfig;