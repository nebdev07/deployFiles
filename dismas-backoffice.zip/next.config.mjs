/** @type {import('next').NextConfig} */
// En local : pas de basePath (app à la racine). Sur le VPS : NEXT_PUBLIC_BASE_PATH=/dismas dans .env.production
const basePath = process.env.NEXT_PUBLIC_BASE_PATH || '';

const nextConfig = {
  ...(basePath && { basePath }),
  // URL canonique avec slash final quand on est sous un basePath (évite 404)
  trailingSlash: true,

  // Désactiver les logs de build en production
  webpack: (config, { isServer, dev }) => {
    // En production, minifier et optimiser
    if (!dev) {
      config.optimization = {
        ...config.optimization,
        minimize: true,
      };
    }
    return config;
  },

  // Désactiver certains warnings en production
  reactStrictMode: true,

  // Désactiver les sourcemaps en production (sécurité)
  productionBrowserSourceMaps: false,

  // Configuration des images (si nécessaire)
  images: {
    remotePatterns: [
      {
        protocol: 'http',
        hostname: '51.91.253.21',
      },
      {
        protocol: 'http',
        hostname: 'localhost',
      },
    ],
  },
  
  // Désactiver la vérification de types pendant le build (optionnel)
  // typescript: {
  //   ignoreBuildErrors: false,
  // },
};

export default nextConfig;
