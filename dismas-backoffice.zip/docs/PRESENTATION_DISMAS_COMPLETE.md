# DISMAS - PLATEFORME DE DISTRIBUTION DES MANUELS SCOLAIRES
## Présentation Client Complète

---

## INTRODUCTION

### Contexte et Justification

La Côte d'Ivoire fait face à des défis majeurs dans la distribution des manuels scolaires :
- **Manque de traçabilité** : Impossible de suivre les manuels de la commande à la distribution
- **Gestion manuelle** : Processus basé sur des documents papier, sujets aux erreurs
- **Délais de distribution** : Retards dans la livraison des manuels aux écoles
- **Pertes et détournements** : Absence de contrôle sur l'utilisation des manuels
- **Absence de retour** : Pas de système de récupération des manuels en fin d'année

### Objectifs du Projet DISMAS

1. **Digitalisation complète** du processus de distribution
2. **Traçabilité en temps réel** des manuels
3. **Optimisation des stocks** et prévention des pénuries
4. **Amélioration de la qualité** du service éducatif
5. **Réduction des coûts** de gestion et distribution

### Architecture Technique

- **Frontend** : Next.js 15.2.4 + React 19 + TypeScript
- **Backend** : Spring Boot 3.x + Java 17+
- **Base de données** : MySQL 8.0 + JPA/Hibernate
- **Sécurité** : Spring Security + JWT
- **Déploiement** : Vercel (frontend) + Cloud (backend)

---

## I. ÉTUDE DE L'EXISTANT

### A) Critique de l'Existant

#### Supports Physiques Actuels

1. **Documents Papier**
   - Bordereaux de livraison manuels
   - Fiches de répartition par école
   - Registres d'inventaire papier
   - Attestations de réception signées

2. **Processus Manuels**
   - Saisie Excel pour les commandes
   - Calculs manuels des besoins
   - Validation par signatures physiques
   - Suivi par téléphone/email

#### Problèmes Identifiés

1. **Traçabilité Limitée**
   - Impossible de localiser un manuel spécifique
   - Pas de suivi des mouvements de stock
   - Absence d'historique des distributions

2. **Erreurs Humaines**
   - Saisies manuelles sujettes aux erreurs
   - Calculs incorrects des quantités
   - Perte de documents papier

3. **Délais de Traitement**
   - Processus séquentiel lent
   - Validation par plusieurs niveaux
   - Communication asynchrone

4. **Absence de Contrôle**
   - Pas de validation automatique
   - Impossible de détecter les anomalies
   - Absence d'alertes

---

## II. ÉTUDE CONCEPTUELLE

### A) Modèle Conceptuel de Données

#### Entités Principales

1. **Structures Administratives**
   - MENA (Ministère)
   - DRENA (Directions Régionales)
   - IEPP (Inspecteurs d'Éducation)
   - EPP (Écoles Primaires Publiques)

2. **Utilisateurs et Rôles**
   - ADMIN (Administrateur système)
   - DAF (Direction Administrative et Financière)
   - DRENA (Directeur Régional)
   - IEPP (Inspecteur)
   - DIRECTEUR (Directeur d'école)
   - MAITRE (Enseignant)
   - COGES (Comité de Gestion)

3. **Manuels et Pédagogie**
   - Manuels (titre, niveau, matière)
   - Niveaux scolaires (CP1, CP2, CE1, etc.)
   - Matières (Français, Mathématiques, etc.)
   - Kits pédagogiques

4. **Distribution et Stock**
   - Inventaires par structure
   - Distributions par classe
   - Détails de distribution
   - Retours de manuels

5. **Régulation**
   - Demandes de régulation
   - Transferts entre structures
   - Approbations hiérarchiques

6. **Qualité et Suivi**
   - Plaintes et réclamations
   - Enquêtes de satisfaction
   - Rapports et statistiques

#### Relations Entre Entités

```
MENA (1) ←→ (N) DRENA
DRENA (1) ←→ (N) IEPP
IEPP (1) ←→ (N) EPP
EPP (1) ←→ (N) Distribution_Classe
Distribution_Classe (1) ←→ (N) Detail_Distribution
Manuel (1) ←→ (N) Inventaire_Manuel
Structure (1) ←→ (N) User
Role (1) ←→ (N) User
```

### B) Modèle Conceptuel de Traitement (Workflow)

#### 1. Workflow EPP (École Primaire Publique)

**Acteurs** : Directeur, Maître, COGES

**Processus** :
1. **Planification des Besoins**
   - Saisie des effectifs par classe
   - Calcul automatique des besoins
   - Validation par le directeur

2. **Réception des Manuels**
   - Confirmation de réception
   - Upload du bordereau de livraison
   - Validation des quantités reçues vs prévues

3. **Distribution aux Classes**
   - Distribution par classe
   - Signature des parents
   - Upload de la fiche de synthèse

4. **Retour de Manuels**
   - Collecte en fin d'année
   - Évaluation de l'état
   - Remise en stock

#### 2. Workflow IEPP (Inspecteur d'Éducation)

**Acteurs** : Inspecteur, Intendant

**Processus** :
1. **Supervision des EPP**
   - Validation des besoins
   - Coordination des distributions
   - Suivi des retours

2. **Régulation Interne**
   - Gestion des excédents/déficits
   - Transferts entre EPP
   - Validation des mouvements

3. **Validation des Documents**
   - Upload des bordereaux de livraison
   - Validation des fiches de répartition
   - Contrôle qualité

#### 3. Workflow DRENA (Direction Régionale)

**Acteurs** : Directeur DRENA, Contrôleur

**Processus** :
1. **Gestion Régionale**
   - Coordination des IEPP
   - Allocation des ressources
   - Validation des régulations

2. **Régulation Externe**
   - Transferts inter-DRENA
   - Gestion des pénuries
   - Optimisation des stocks

3. **Rapports et Statistiques**
   - Suivi des indicateurs
   - Génération de rapports
   - Analyse des tendances

#### 4. Workflow DAF/MENA

**Acteurs** : DAF, DPFC, DESPS, Cabinet

**Processus** :
1. **Planification Nationale**
   - Définition des besoins nationaux
   - Allocation des budgets
   - Coordination des commandes

2. **Import des Données**
   - Import des tableaux de répartition
   - Validation des données
   - Génération des commandes

3. **Suivi et Contrôle**
   - Tableaux de bord nationaux
   - Alertes et notifications
   - Rapports de performance

#### 5. Workflow Retour de Manuels

**Acteurs** : Directeur EPP, Maître, COGES

**Processus** :
1. **Planification de la Collecte**
   - Définition des dates de collecte
   - Information des parents
   - Préparation des documents

2. **Collecte et Évaluation**
   - Collecte par classe
   - Évaluation de l'état (bon, moyen, mauvais)
   - Comptage des manuels perdus

3. **Remise en Stock**
   - Saisie des quantités par état
   - Upload des bordereaux de collecte
   - Mise à jour de l'inventaire

4. **Validation IEPP**
   - Contrôle des quantités collectées
   - Validation des bordereaux
   - Autorisation de remise en stock

---

## III. ÉTUDE ORGANISATIONNELLE

### A) Modèle Organisationnel de Données

#### Tables de Référence

```sql
-- Années scolaires
annee_scolaire (id, libelle, date_debut, date_fin, est_active)

-- Niveaux scolaires
niveau_scolaire (id, code, libelle, ordre_affichage)

-- Matières
matiere (id, code, libelle, couleur_hex)

-- Types d'ouvrages
type_ouvrage (id, code, libelle, description)
```

#### Tables de Structures Administratives

```sql
-- Hiérarchie administrative
structure_administrative (
    id, code, libelle, type, parent_id,
    region, departement, commune, adresse,
    telephone, email, responsable, intendant,
    effectif_total, date_creation, actif
)
```

#### Tables de Gestion Utilisateurs

```sql
-- Rôles et permissions
role (id, code, libelle, niveau_hierarchique, description, couleur_hex)
fonctionalite (id, code, libelle, module, description)
role_fonctionalite (role_id, fonctionalite_id, permissions)

-- Utilisateurs
user (
    id, nom, prenoms, email, telephone, login, password,
    role_id, structure_id, photo_profil, derniere_connexion,
    est_actif, doit_changer_mot_de_passe
)
```

#### Tables de Gestion des Manuels

```sql
-- Manuels
manuel (
    id, code, titre, niveau_id, matiere_id, type_ouvrage_id,
    editeur, isbn, annee_edition, prix_unitaire, poids_grammes,
    description, image_couverture
)

-- Kits pédagogiques
kit_pedagogique (id, niveau_id, manuel_id, quantite_par_eleve, est_obligatoire)
```

#### Tables de Gestion des Stocks

```sql
-- Inventaires
inventaire_manuel (
    id, structure_id, manuel_id, annee_scolaire_id,
    quantite_initiale, quantite_recue, quantite_distribuee,
    quantite_retournee, quantite_perdue, quantite_actuelle
)
```

#### Tables de Distribution

```sql
-- Distributions par classe
distribution_classe (
    id, reference, structure_id, niveau_id, classe,
    annee_scolaire_id, effectif_garcons, effectif_filles,
    effectif_total, date_distribution, distribue_par,
    statut, observations
)

-- Détails de distribution
detail_distribution_classe (
    id, distribution_id, manuel_id, quantite_prevue,
    quantite_distribuee, quantite_manquante
)
```

#### Tables de Régulation

```sql
-- Régulations
regulation (
    id, reference, type_regulation, structure_source_id,
    structure_destination_id, motif, statut, date_demande,
    date_approbation, date_execution, demande_par,
    approuve_par, execute_par, observations
)

-- Détails de régulation
detail_regulation (
    id, regulation_id, manuel_id, quantite_demandee,
    quantite_approuvee, quantite_transferee
)
```

#### Tables de Retour de Manuels

```sql
-- Retours de manuels
retour_manuel (
    id, reference, structure_id, niveau_id, classe,
    annee_scolaire_id, date_retour, collecte_par,
    statut, observations
)

-- Détails de retour
detail_retour_manuel (
    id, retour_id, manuel_id, quantite_bon_etat,
    quantite_moyen_etat, quantite_mauvais_etat,
    quantite_perdue, quantite_totale
)
```

#### Tables de Qualité et Suivi

```sql
-- Plaintes
plainte (
    id, code_suivi, nom_plaignant, telephone_plaignant,
    email_plaignant, structure_concernee_id, type_plainte,
    objet, description, statut, priorite, date_depot,
    date_limite_traitement, assigne_a, resolution,
    date_resolution, satisfaction_plaignant
)

-- Enquêtes de satisfaction
enquete_satisfaction (
    id, titre, description, type_enquete, questions,
    date_debut, date_fin, est_active, structure_cible_id,
    niveau_cible_id
)

-- Réponses aux enquêtes
reponse_enquete (
    id, enquete_id, repondant_nom, repondant_telephone,
    repondant_email, structure_id, reponses,
    score_satisfaction, date_reponse
)
```

#### Tables Système

```sql
-- Journal d'activité
journal_activite (
    id, utilisateur_id, action, entite, entite_id,
    details, adresse_ip, user_agent, date_evenement
)

-- Notifications
notification (
    id, destinataire_id, titre, message, type_notification,
    est_lue, date_lecture
)

-- Paramètres système
parametre_systeme (id, cle, valeur, description, type_valeur)
```

### B) Modèle Logique de Données

#### Contraintes d'Intégrité

1. **Contraintes de Référence**
   - Toutes les clés étrangères avec CASCADE DELETE
   - Contraintes UNIQUE sur les codes et références
   - Contraintes CHECK sur les statuts et types

2. **Contraintes Métier**
   - Quantités positives uniquement
   - Dates cohérentes (début < fin)
   - Statuts valides selon le workflow

3. **Index de Performance**
   - Index sur les colonnes de recherche fréquente
   - Index composites pour les requêtes complexes
   - Index sur les clés étrangères

### C) Modèle Organisationnel de Traitement

#### Workflows Automatisés

1. **Calcul Automatique des Besoins**
   - Déclenchement : Saisie des effectifs
   - Processus : Multiplication par kit pédagogique
   - Résultat : Quantités prévues par manuel

2. **Validation Hiérarchique**
   - Déclenchement : Soumission de demande
   - Processus : Notification aux supérieurs
   - Résultat : Approbation ou rejet

3. **Mise à Jour des Stocks**
   - Déclenchement : Distribution ou retour
   - Processus : Calcul automatique des quantités
   - Résultat : Inventaire à jour

4. **Génération de Rapports**
   - Déclenchement : Période définie
   - Processus : Agrégation des données
   - Résultat : Rapport PDF/Excel

---

## IV. MAQUETTE

### A) Arborescence de l'Application

```
DISMAS Platform
├── Authentication
│   ├── Login
│   ├── Logout
│   └── Password Reset
├── Dashboard
│   ├── Overview
│   ├── Statistics
│   └── Notifications
├── Besoins
│   ├── Planification
│   ├── Calcul Automatique
│   └── Validation
├── Commandes
│   ├── Création
│   ├── Suivi
│   └── Validation
├── Distribution
│   ├── Nouvelle Distribution
│   ├── Suivi Distributions
│   ├── Confirmation Réception
│   └── Validation Distribution
├── Planification
│   ├── Répartition
│   ├── Import Excel
│   └── Export
├── Confirmation
│   ├── EPP Level
│   ├── IEPP Level
│   └── Document Upload
├── Régulation
│   ├── Demandes
│   ├── Approbations
│   ├── Transferts
│   └── Suivi
├── Retours
│   ├── Planification Collecte
│   ├── Évaluation État
│   ├── Remise en Stock
│   └── Validation
├── Plaintes
│   ├── Dépôt
│   ├── Traitement
│   ├── Escalade
│   └── Résolution
├── Enquêtes
│   ├── Création
│   ├── Diffusion
│   ├── Réponses
│   └── Analyse
├── Rapports
│   ├── Quotidiens
│   ├── Hebdomadaires
│   ├── Mensuels
│   └── Annuels
├── Stocks
│   ├── Inventaire
│   ├── Mouvements
│   ├── Alertes
│   └── Statistiques
├── Utilisateurs
│   ├── Gestion
│   ├── Rôles
│   └── Permissions
└── Administration
    ├── Paramètres
    ├── Logs
    └── Maintenance
```

### B) Flow des Modules (Captures d'Écrans)

#### 1. Authentification et Dashboard

**[PLACEHOLDER SCREENSHOT - 1920x1080px]**
**Page de Connexion DISMAS**
- Logo DISMAS en haut
- Formulaire de connexion centré
- Champs : Email/Login, Mot de passe
- Bouton "Se connecter" orange
- Lien "Mot de passe oublié"

**[PLACEHOLDER SCREENSHOT - 1920x1080px]**
**Dashboard Principal**
- Header avec logo et menu utilisateur
- Sidebar avec navigation
- Widgets de statistiques (4 colonnes)
- Graphiques de tendances
- Notifications récentes

#### 2. Gestion des Besoins

**[PLACEHOLDER SCREENSHOT - 1920x1080px]**
**Planification des Besoins**
- Formulaire de saisie des effectifs
- Sélection de la structure et classe
- Calcul automatique des besoins
- Bouton "Valider et Soumettre"

**[PLACEHOLDER SCREENSHOT - 1920x1080px]**
**Tableau des Besoins**
- Liste des besoins par structure
- Statuts (En attente, Validé, Rejeté)
- Actions : Modifier, Valider, Rejeter
- Filtres par région, niveau, statut

#### 3. Distribution des Manuels

**[PLACEHOLDER SCREENSHOT - 1920x1080px]**
**Nouvelle Distribution**
- Formulaire de création
- Sélection : Structure, Classe, Titre à distribuer
- Saisie des effectifs (garçons/filles)
- Date de distribution
- Bouton "Créer Distribution"

**[PLACEHOLDER SCREENSHOT - 1920x1080px]**
**Liste des Distributions**
- Tableau avec colonnes : Référence, Structure, Classe, Date, Statut
- Actions : Voir détails, Modifier, Annuler
- Filtres et recherche
- Bouton "Nouvelle Distribution"

#### 4. Confirmation et Validation

**[PLACEHOLDER SCREENSHOT - 1920x1080px]**
**Modal Confirmation EPP**
- Onglets : Informations, Documents
- Formulaire de confirmation
- Upload bordereau de livraison
- Upload fiche de synthèse (optionnel)
- Boutons : Confirmer, Annuler

**[PLACEHOLDER SCREENSHOT - 1920x1080px]**
**Modal Validation IEPP**
- Informations de la distribution
- Upload bordereau livreur (obligatoire)
- Upload fiche répartition (optionnel)
- Validation des quantités
- Boutons : Valider, Rejeter

#### 5. Régulation

**[PLACEHOLDER SCREENSHOT - 1920x1080px]**
**Page Régulation**
- Onglets : EPP Excédentaires, EPP Déficitaires, Régulations
- Tableaux avec actions "Initier Régulation", "Assigner Manuels"
- Filtres par DRENA, statut, type

**[PLACEHOLDER SCREENSHOT - 1920x1080px]**
**Modal Initier Régulation**
- Formulaire de demande
- Sélection structure source/destination
- Type : Interne (même DRENA) / Externe (DRENA différente)
- Saisie des manuels et quantités
- Motif de la demande

#### 6. Retour de Manuels

**[PLACEHOLDER SCREENSHOT - 1920x1080px]**
**Planification Retour**
- Formulaire de planification
- Sélection : Structure, Classe, Date de collecte
- Responsable de la collecte
- Observations

**[PLACEHOLDER SCREENSHOT - 1920x1080px]**
**Évaluation État Manuels**
- Liste des manuels à évaluer
- Quantités par état : Bon, Moyen, Mauvais, Perdu
- Upload bordereau de collecte
- Validation des quantités

#### 7. Plaintes et Enquêtes

**[PLACEHOLDER SCREENSHOT - 1920x1080px]**
**Dépôt de Plainte**
- Formulaire de plainte
- Champs : Nom, Téléphone, Email, Structure
- Type de plainte (Manque, Retard, Qualité, Autre)
- Description détaillée
- Priorité

**[PLACEHOLDER SCREENSHOT - 1920x1080px]**
**Suivi Plaintes**
- Tableau des plaintes
- Colonnes : Code, Plaignant, Type, Statut, Priorité, Date
- Actions : Voir détails, Assigner, Résoudre
- Filtres par statut, priorité, type

#### 8. Rapports et Statistiques

**[PLACEHOLDER SCREENSHOT - 1920x1080px]**
**Génération Rapports**
- Sélection du type de rapport
- Période (début/fin)
- Structure cible
- Options d'export (PDF, Excel)
- Bouton "Générer"

**[PLACEHOLDER SCREENSHOT - 1920x1080px]**
**Tableau de Bord Statistiques**
- Graphiques de tendances
- Indicateurs clés (KPI)
- Répartition par région/niveau
- Évolution des stocks
- Performance des distributions

#### 9. Gestion des Stocks

**[PLACEHOLDER SCREENSHOT - 1920x1080px]**
**Inventaire Global**
- Vue d'ensemble des stocks
- Filtres par structure, manuel, niveau
- Quantités : Initiale, Reçue, Distribuée, Retournée, Actuelle
- Alertes de stock faible

**[PLACEHOLDER SCREENSHOT - 1920x1080px]**
**Mouvements de Stock**
- Historique des mouvements
- Type : Réception, Distribution, Retour, Régulation
- Détails par mouvement
- Export des données

#### 10. Administration

**[PLACEHOLDER SCREENSHOT - 1920x1080px]**
**Gestion Utilisateurs**
- Liste des utilisateurs
- Rôles et permissions
- Statut actif/inactif
- Actions : Créer, Modifier, Désactiver

**[PLACEHOLDER SCREENSHOT - 1920x1080px]**
**Paramètres Système**
- Configuration générale
- Paramètres de notification
- Limites et seuils
- Sauvegarde et maintenance

---

## CONCLUSION

### Bénéfices Attendus

1. **Traçabilité Complète**
   - Suivi en temps réel de chaque manuel
   - Historique complet des mouvements
   - Localisation précise des stocks

2. **Optimisation des Processus**
   - Réduction des délais de 60%
   - Élimination des erreurs manuelles
   - Automatisation des calculs

3. **Amélioration de la Qualité**
   - Contrôle qualité automatisé
   - Alertes en temps réel
   - Rapports de performance

4. **Réduction des Coûts**
   - Diminution des pertes de 40%
   - Optimisation des stocks
   - Réduction des frais administratifs

### Prochaines Étapes

1. **Phase de Développement**
   - Développement frontend (Next.js)
   - Développement backend (Spring Boot)
   - Intégration base de données

2. **Phase de Test**
   - Tests unitaires et d'intégration
   - Tests de charge et performance
   - Tests utilisateurs

3. **Phase de Déploiement**
   - Déploiement en environnement de test
   - Formation des utilisateurs
   - Mise en production progressive

4. **Phase de Maintenance**
   - Support utilisateur
   - Évolutions fonctionnelles
   - Maintenance technique

---

**DISMAS - La solution complète pour la distribution intelligente des manuels scolaires en Côte d'Ivoire** 🇨🇮 