# Flux Expression des Besoins – Directeur EPP (sans régression)

## Problème corrigé

Pour un **Directeur EPP**, après saisie d’un besoin (statut SAISI), le besoin **disparaissait** de la liste « Besoins Saisis » et on ne pouvait plus **Valider** pour que l’IEPP prenne la main.

**Cause** : le besoin est rattaché à l’**EPP** (école), alors que le front utilisait partout **user.structure** (souvent l’IEPP pour un Directeur). Donc :
- chargement avec `structureId = user.structure?.id` (IEPP) → l’API ne renvoyait pas les besoins EPP ;
- filtre liste avec `b.structure.code === user.structure?.code` (IEPP) → les besoins EPP étaient exclus ;
- création avec `userStructure={user.structure}` → le besoin était créé avec `structureId = IEPP` en base, incohérent avec le chargement par EPP.

---

## Modifications appliquées (flow préservé)

### 1. Chargement des besoins (`loadBesoins`)

- **DIRECTEUR** : `criteria.structureId = (user as any).epp?.id ?? user?.structure?.id`
- On charge les besoins de l’**EPP** du directeur quand `user.epp` est présent, sinon on garde `user.structure?.id` (comportement antérieur).

### 2. Liste « Besoins Saisis » / autres listes (`getBesoinsByRole`)

- **DIRECTEUR** : on garde un besoin si :
  - `b._rawData?.structureId === (user as any).epp?.id`, ou
  - `b.structure?.code === (user as any).epp?.code`, ou
  - `b.structure?.code === user.structure?.code` (repli)
- Ainsi les besoins **EPP** (SAISI, VALIDE, etc.) restent visibles pour le Directeur ; si `user.epp` est absent, le filtre par `user.structure?.code` reste inchangé.

### 3. Création d’un besoin (`BesoinForm` – `userStructure`)

- **DIRECTEUR** avec `user.epp` : on passe la structure **EPP** au formulaire :  
  `userStructure={ { id: user.epp.id, code: user.epp.code, libelle: user.epp.libelle, type: 'EPP' } }`
- Le besoin créé a donc `structureId = EPP` en base, cohérent avec le chargement et le filtre ci‑dessus.
- Si pas de `user.epp` : `userStructure={user?.structure}` (comportement inchangé).

### 4. Suivi (`getBesoinsForSuivi`)

- Déjà basé sur `user.epp` pour le DIRECTEUR ; **aucune modification**.

### 5. Validation / édition

- **Validation (Valider)** : on garde `rawData.structureId` (celui du besoin), donc pas de changement de structure.
- **Édition** : `besoinToEdit.structureId` vient du besoin existant ; pas d’impact sur le flux.

---

## Flux métier (inchangé)

1. **Directeur** : Saisie → besoin créé avec **structureId = EPP** → statut **SAISI**.
2. **Liste « Besoins Saisis »** : le besoin reste affiché (chargement + filtre par EPP).
3. **Directeur** : clic **Valider** → statut **VALIDE**.
4. **IEPP** : voit le besoin (Consolidation / Suivi) et peut **Consolider**.
5. **DAF** : peut **Approuver** les besoins consolidés.

Aucun autre rôle ni aucun autre onglet (Consolidation, Validation DAF, Suivi) n’est modifié dans sa logique ; seuls le chargement, le filtre et la création pour le **DIRECTEUR** sont alignés sur l’EPP lorsque `user.epp` est disponible.

---

## Régression évitée

- Si **user.epp** est absent (ancienne API ou autre profil), on utilise partout **user.structure** en repli : comportement identique à l’ancien.
- **IEPP / DAF / DRENA / ADMIN** : pas de changement (getBesoinsByRole, loadBesoins, consolidation, validation).
- **Création** : en passant la structure EPP uniquement pour DIRECTEUR avec `user.epp`, les besoins restent rattachés à la bonne structure et le flux reste cohérent.
