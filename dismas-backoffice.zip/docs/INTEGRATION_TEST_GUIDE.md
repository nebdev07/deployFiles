# 🧪 Guide de Test - Intégration Frontend Validation de Stock

## 🎯 Objectif

Tester l'intégration complète du système de validation de stock dans le frontend DISMAS sans casser les fonctionnalités existantes.

## 📋 Checklist de Test

### ✅ **1. Tests Backend (Prérequis)**

Avant de tester le frontend, s'assurer que le backend fonctionne :

```bash
# Démarrer le backend
cd D:\DTSI\projet\DISMAS\dismas-backend-v1
mvn spring-boot:run

# Tester les endpoints
curl -X GET "http://localhost:8080/distributionEleve/testStockSystem/500"
curl -X GET "http://localhost:8080/distributionEleve/getStock/500/1"
```

### ✅ **2. Tests Frontend - Navigation**

#### **2.1 Page de Distribution**
- [ ] Accéder à `/distribution`
- [ ] Vérifier que la page se charge sans erreur
- [ ] Vérifier que les stats s'affichent correctement
- [ ] Vérifier que la liste des distributions existantes s'affiche

#### **2.2 Widget de Stock**
- [ ] Le widget `StockWidget` s'affiche correctement
- [ ] Sélectionner une EPP dans le dropdown
- [ ] Sélectionner une matière
- [ ] Vérifier que le stock s'affiche
- [ ] Tester le bouton "Actualiser"
- [ ] Tester le bouton "Voir tous les stocks"
- [ ] Tester le bouton "Tester le système"

### ✅ **3. Tests Frontend - Création de Distribution**

#### **3.1 Ouverture du Formulaire**
- [ ] Cliquer sur "Nouvelle Distribution"
- [ ] Vérifier que le modal s'ouvre avec le nouveau formulaire
- [ ] Vérifier que le formulaire est plus large (max-w-4xl)
- [ ] Vérifier que le formulaire est scrollable (max-h-[90vh])

#### **3.2 Remplissage du Formulaire**
- [ ] **École EPP** : Sélectionner une EPP
- [ ] **Niveau scolaire** : Sélectionner un niveau
- [ ] **Classe** : Saisir "CP1"
- [ ] **Année scolaire** : Sélectionner une année
- [ ] **Date de distribution** : Saisir une date
- [ ] **Distribué par** : Saisir un ID utilisateur (ex: 1)
- [ ] **Effectif Garçons** : Saisir 25
- [ ] **Effectif Filles** : Saisir 25

#### **3.3 Ajout de Matières**
- [ ] Cliquer sur "+ Ajouter une matière"
- [ ] Sélectionner une matière dans le dropdown
- [ ] Saisir une quantité (ex: 50)
- [ ] Vérifier que le stock disponible s'affiche
- [ ] Ajouter une deuxième matière
- [ ] Vérifier que la validation de stock fonctionne en temps réel

#### **3.4 Validation de Stock**
- [ ] **Test stock suffisant** : Saisir une quantité ≤ stock disponible
  - [ ] Vérifier que l'indicateur est vert
  - [ ] Vérifier qu'aucune erreur ne s'affiche
- [ ] **Test stock insuffisant** : Saisir une quantité > stock disponible
  - [ ] Vérifier que l'indicateur est rouge
  - [ ] Vérifier qu'une erreur s'affiche
  - [ ] Vérifier que le bouton "Créer la Distribution" est désactivé

#### **3.5 Soumission du Formulaire**
- [ ] **Avec stock suffisant** :
  - [ ] Cliquer sur "Créer la Distribution"
  - [ ] Vérifier le loading (spinner)
  - [ ] Vérifier le message de succès
  - [ ] Vérifier que le modal se ferme
  - [ ] Vérifier que le stock est mis à jour (optionnel)
- [ ] **Avec stock insuffisant** :
  - [ ] Vérifier que le bouton est désactivé
  - [ ] Vérifier qu'aucune soumission n'est possible

### ✅ **4. Tests de Régression**

#### **4.1 Fonctionnalités Existantes**
- [ ] **Modal de détails** : Cliquer sur "Voir détails" d'une distribution
- [ ] **Modal de confirmation** : Tester les boutons de confirmation EPP/IEPP
- [ ] **Navigation** : Vérifier que la navigation fonctionne toujours
- [ ] **Responsive** : Tester sur mobile/tablet

#### **4.2 Gestion d'Erreurs**
- [ ] **Backend indisponible** :
  - [ ] Arrêter le backend
  - [ ] Tester la création de distribution
  - [ ] Vérifier que l'erreur est gérée gracieusement
- [ ] **Données manquantes** :
  - [ ] Soumettre le formulaire vide
  - [ ] Vérifier les messages d'erreur appropriés

### ✅ **5. Tests de Performance**

#### **5.1 Chargement des Données**
- [ ] Vérifier que les hooks chargent les données correctement
- [ ] Vérifier que les loading states s'affichent
- [ ] Vérifier qu'aucun re-render inutile n'a lieu

#### **5.2 Validation en Temps Réel**
- [ ] Modifier une quantité dans le formulaire
- [ ] Vérifier que la validation se déclenche automatiquement
- [ ] Vérifier que l'API n'est pas appelée trop souvent (debouncing)

## 🐛 **Scénarios de Test Spécifiques**

### **Test 1 : Distribution Simple**
```
1. Sélectionner EPP ID: 500
2. Ajouter matière ID: 1, Quantité: 30
3. Remplir les autres champs obligatoires
4. Soumettre
5. Vérifier le succès
```

### **Test 2 : Stock Insuffisant**
```
1. Sélectionner EPP ID: 500
2. Ajouter matière ID: 1, Quantité: 999999
3. Vérifier l'erreur de stock
4. Vérifier que le bouton est désactivé
```

### **Test 3 : Validation Temps Réel**
```
1. Ajouter une matière avec quantité valide
2. Modifier la quantité pour dépasser le stock
3. Vérifier que l'erreur apparaît immédiatement
4. Remettre une quantité valide
5. Vérifier que l'erreur disparaît
```

## 📊 **Résultats Attendus**

### ✅ **Succès**
- [ ] Formulaire s'affiche correctement
- [ ] Validation de stock fonctionne en temps réel
- [ ] Création de distribution réussie
- [ ] Aucune régression sur les fonctionnalités existantes
- [ ] Gestion d'erreurs appropriée

### ❌ **Échecs à Surveiller**
- [ ] Erreurs de compilation TypeScript
- [ ] Erreurs de console JavaScript
- [ ] Fonctionnalités existantes cassées
- [ ] Performance dégradée
- [ ] UI/UX incohérente

## 🔧 **Commandes de Test**

### **Démarrer le Frontend**
```bash
cd D:\DTSI\projet\DISMAS\frontends\dismas-backoffice
npm run dev
# ou
pnpm dev
```

### **Vérifier les Erreurs**
```bash
# Linting
npm run lint

# Type checking
npm run type-check

# Build test
npm run build
```

### **Tests Automatisés (si disponibles)**
```bash
npm run test
npm run test:e2e
```

## 📝 **Rapport de Test**

Après chaque session de test, documenter :

1. **Tests réussis** ✅
2. **Tests échoués** ❌
3. **Bugs identifiés** 🐛
4. **Améliorations suggérées** 💡
5. **Performance observée** ⚡

## 🚀 **Déploiement**

Une fois tous les tests validés :

1. **Build de production** :
   ```bash
   npm run build
   ```

2. **Vérification du build** :
   ```bash
   npm run start
   ```

3. **Tests en production** :
   - Répéter les tests critiques
   - Vérifier les performances
   - Tester sur différents navigateurs

---

## 📞 **Support**

En cas de problème :
1. Vérifier les logs de la console
2. Vérifier les logs du backend
3. Consulter la documentation API
4. Contacter l'équipe de développement

**🎯 Objectif : Zéro régression, validation de stock fonctionnelle, UX améliorée !**
