# Déploiement dismas-backoffice sur VPS (Apache)

Guide détaillé et pas à pas pour déployer l’application Next.js du backoffice DISMAS sur un VPS avec Apache en reverse proxy.

---

## Sommaire

1. [Vue d’ensemble](#1-vue-densemble)
2. [Prérequis détaillés](#2-prérequis-détaillés)
3. [Premier déploiement (étape par étape)](#3-premier-déploiement-étape-par-étape)
4. [Configuration Apache (détaillée)](#4-configuration-apache-détaillée)
5. [HTTPS avec Let’s Encrypt](#5-https-avec-lets-encrypt)
6. [Mises à jour et procédure de redéploiement](#6-mises-à-jour-et-procédure-de-redéploiement)
7. [Vérifications et tests](#7-vérifications-et-tests)
8. [Dépannage détaillé](#8-dépannage-détaillé)
9. [Sécurité et bonnes pratiques](#9-sécurité-et-bonnes-pratiques)

---

## 1. Vue d’ensemble

### 1.1 Schéma du flux

```
Utilisateur (navigateur)
        │
        ▼
   Apache (port 80 / 443)  ← même host pour tout
        │
        ├── /dismas/  ou /dismas  → proxy → Next.js (port 3002)
        │
        └── /dismas-api/           → proxy → Backend DISMAS (ex. Tomcat 8080)
```

- **Apache** : point d’entrée unique. Il reçoit les requêtes et les aiguille : `/dismas` et `/dismas/` vers Next.js, `/dismas-api/` vers le backend (Tomcat).
- **Next.js** : écoute en local sur le port **3002** ; le front est servi sous **/dismas** ou **/dismas/**.
- **Backend** : l’appel se fait **sans host en dur** : le front utilise l’origine de la page (même host) + `/dismas-api`. Ainsi, en changeant de serveur, on ne modifie pas le code : il suffit que Apache sur le nouveau serveur expose `/dismas` et `/dismas-api` de la même façon.

### 1.2 Fichiers importants après déploiement

Sur le VPS, le backoffice DISMAS est déployé dans **`/var/www/dismas`** (même convention que arc-nwanyo-ui dans `/var/www/ui`). La configuration PM2 est définie par **`ecosystem.config.js`** à la racine du projet.

| Emplacement | Rôle |
|-------------|------|
| `/var/www/dismas/` | Racine du projet (code source + build). |
| `/var/www/dismas/.env.production` | Variables d’environnement pour le build et l’exécution (ne pas commiter). |
| `/var/www/dismas/.next/` | Dossier de build Next.js (généré par `npm run build`). |
| `/var/www/dismas/ecosystem.config.js` | Configuration PM2 (nom, port 3002, logs). |
| `/var/www/dismas/logs/` | Logs PM2 : `err.log`, `out.log`, `combined.log`. |
| `/etc/apache2/sites-available/dismas-backoffice.conf` | Configuration Apache du site (VirtualHost, proxy vers 3002). |
| Logs Apache | Souvent `/var/log/apache2/dismas-backoffice-*.log`. |

---

## 2. Prérequis détaillés

### 2.1 Système

- Un VPS avec **Debian 11/12** ou **Ubuntu 20.04/22.04** (recommandé pour suivre ce guide à l’identique).
- Accès **root** ou utilisateur avec `sudo`.
- Un **nom de domaine** (ou sous-domaine) pointant vers l’IP du VPS (pour HTTPS avec Let’s Encrypt). En test, on peut utiliser l’IP seule.

### 2.2 Node.js 18+ (LTS)

Next.js 15 nécessite Node.js 18 au minimum. Installation recommandée via **NodeSource** (versions à jour) :

```bash
# Exemple pour Node 20.x sur Debian/Ubuntu
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt-get install -y nodejs

# Vérifications (à exécuter et noter les versions)
node -v   # doit afficher v18.x ou v20.x
npm -v    # 9.x ou 10.x
```

- **Pourquoi NodeSource ?** Les paquets `nodejs` des dépôts par défaut sont parfois anciens ; NodeSource fournit une version LTS adaptée.

### 2.3 Apache et modules

```bash
# Installer Apache
sudo apt-get update
sudo apt-get install -y apache2

# Activer les modules nécessaires au reverse proxy
sudo a2enmod proxy
sudo a2enmod proxy_http
sudo a2enmod proxy_wstunnel
sudo a2enmod rewrite
sudo a2enmod headers

# Recharger Apache pour appliquer les modules
sudo systemctl reload apache2
```

**Rôle de chaque module :**

| Module | Rôle |
|--------|------|
| `proxy` | Base du reverse proxy. |
| `proxy_http` | Proxy pour HTTP (requêtes vers Next.js). |
| `proxy_wstunnel` | Proxy des WebSockets (utile si l’app ou le dev utilise des WS). |
| `rewrite` | Réécriture d’URL (ex. règles pour WebSocket ou redirections). |
| `headers` | Permet d’ajuster les en-têtes HTTP (ex. sécurité, X-Forwarded-*). |

Vérifier que les modules sont actifs :

```bash
sudo apache2ctl -M | grep -E 'proxy|rewrite|headers'
```

Vous devez voir au moins : `proxy_module`, `proxy_http_module`, `rewrite_module`, `headers_module`.

### 2.4 PM2 (gestion du processus Node)

PM2 garde l’application Next.js lancée en arrière-plan, la redémarre en cas de crash et peut la démarrer au boot.

```bash
# Installation globale
sudo npm install -g pm2

# Vérification
pm2 -v
```

**Pourquoi PM2 ?** Sans PM2, dès que vous fermez la session SSH, le processus `next start` s’arrête. PM2 détache l’application du terminal et gère les redémarrages.

### 2.5 Git (si déploiement depuis un dépôt)

```bash
sudo apt-get install -y git
git --version
```

### 2.6 Port 3002 disponible

DISMAS utilise le **port 3002** (arc-nwanyo-ui utilise 3001). Vérifier que 3002 est libre :

```bash
sudo ss -tlnp | grep 3002
```

Si la commande ne renvoie rien, le port est libre.

---

## 3. Premier déploiement (étape par étape)

### 3.1 Créer le répertoire et récupérer le code

Le répertoire de déploiement est **`/var/www/dismas`** (aligné sur l’existant : arc-nwanyo-ui dans `/var/www/ui`).

```bash
# Créer le répertoire
sudo mkdir -p /var/www/dismas
cd /var/www/dismas

# Cloner le dépôt (remplacer par l’URL réelle et la branche souhaitée)
# Le clone doit remplir /var/www/dismas (contenu du repo dans ce dossier)
sudo git clone https://github.com/votre-org/dismas-backoffice.git .
# ou : git clone ... dismas-backoffice && mv dismas-backoffice/* dismas-backoffice/.[!.]* . && rmdir dismas-backoffice

# Créer le répertoire des logs (utilisé par ecosystem.config.js)
sudo mkdir -p /var/www/dismas/logs
```

**Droits recommandés :** l’utilisateur qui lance le build et PM2 doit pouvoir lire/écrire dans le projet. Exemple avec l’utilisateur `vps` (comme pour arc-nwanyo-ui) :

```bash
sudo chown -R vps:vps /var/www/dismas
# Ensuite, travailler en tant que vps
cd /var/www/dismas
```

Si vous restez en **root**, les commandes ci-dessous s’exécutent sans `sudo` dans le répertoire du projet.

### 3.2 Fichier des variables d’environnement

Les variables `NEXT_PUBLIC_*` sont **injectées au moment du build**. Elles doivent donc être définies **avant** `npm run build`, et le fichier doit exister sur le serveur au moment du build.

Créer le fichier à la **racine du projet** :

```bash
cd /var/www/dismas
nano .env.production
```

Contenu type pour la **production** :

```env
# Obligatoire : mode production
NODE_ENV=production

# Base path : obligatoire sur le VPS (app à http://IP/dismas/). Ne pas définir en local.
NEXT_PUBLIC_BASE_PATH=/dismas

# URL de base de l’API DISMAS (sans slash final)
# C’est cette valeur qui sera « figée » dans le build.
NEXT_PUBLIC_API_URL=http://192.168.3.191/dismas-api

# Optionnel : permet au logger (lib/utils/logger.ts) de savoir qu’on est en prod
NEXT_PUBLIC_ENVIRONMENT=production
```

Pour un **staging** (autre API) :

```env
NODE_ENV=production
NEXT_PUBLIC_API_URL=https://votre-serveur-staging:8081/dismas-api
NEXT_PUBLIC_ENVIRONMENT=staging
```

Sauvegarder (Ctrl+O, Entrée, Ctrl+X avec `nano`). Vérifier que le fichier n’est **pas** versionné (présent dans `.gitignore`).

### 3.3 Installer les dépendances

```bash
cd /var/www/dismas

# npm ci utilise exactement package-lock.json (reproductible)
npm ci

# Si vous n’avez pas de lock file :
# npm install
```

Cela crée `node_modules/`. En cas d’erreur (ex. mémoire), vous pouvez augmenter la mémoire Node :

```bash
export NODE_OPTIONS="--max-old-space-size=4096"
npm ci
```

### 3.4 Lancer le build Next.js

**Important :** le fichier `.env.production` doit déjà être en place, car Next.js lit les `NEXT_PUBLIC_*` au **build time**.

```bash
cd /var/www/dismas
npm run build
```

Le build peut prendre plusieurs minutes. En cas de succès, vous voyez un résumé et le dossier `.next/` est créé/rempli.

En cas d’erreur :

- Vérifier la mémoire du VPS (swap si besoin).
- Vérifier les erreurs TypeScript/ESLint affichées et corriger le code ou la config.

### 3.5 Démarrer l’application avec PM2 (ecosystem.config.js)

La configuration PM2 est **identique** à celle d’arc-nwanyo-ui (`/var/www/ui/ecosystem.config.js`) : même structure (script `npm`, args `run start -- -p PORT`, `cwd`, logs dans un dossier `logs/`). Seuls changent le nom de l’app, le port (3002 pour DISMAS, 3001 pour arc-nwanyo-ui) et le répertoire (`/var/www/dismas`). Le fichier **`ecosystem.config.js`** est à la racine du projet. Exemple de contenu (déjà présent dans le dépôt) :

```javascript
// ecosystem.config.js (à la racine de dismas-backoffice)
module.exports = {
  apps: [{
    name: 'dismas-backoffice',
    script: 'npm',
    args: 'run start -- -p 3002',
    cwd: '/var/www/dismas',
    interpreter: 'node',
    instances: 1,
    autorestart: true,
    watch: false,
    max_memory_restart: '1G',
    env: { NODE_ENV: 'production', PORT: 3002 },
    error_file: '/var/www/dismas/logs/err.log',
    out_file: '/var/www/dismas/logs/out.log',
    log_file: '/var/www/dismas/logs/combined.log',
    time: true,
  }],
};
```

Ensuite, sur le VPS :

```bash
cd /var/www/dismas

# Démarrer Next.js en mode “npm run start” sous PM2
pm2 start ecosystem.config.js

# Enregistrer la liste des processus pour qu’elle survive à un reboot
pm2 save

# Configurer le démarrage automatique de PM2 au boot (à faire une fois)
pm2 startup
```

La commande `pm2 startup` affiche une commande `sudo ...` à exécuter ; copier-coller et l’exécuter.

Vérifications :

```bash
pm2 list
# L’application "dismas-backoffice" doit être "online" (status).

pm2 logs dismas-backoffice --lines 30
# Vous devez voir des lignes du type “Ready on http://127.0.0.1:3002” ou équivalent.
```

À ce stade, l’application répond **uniquement** en local sur le port **3002**. La suite consiste à exposer ce service via Apache.

---

## 4. Configuration Apache (détaillée)

### 4.1 Sur ce VPS : base.conf + Include (comme ui.conf)

Sur ce serveur, un seul VirtualHost (**base.conf**) écoute sur le port 80 et **inclut** les configs des apps Next.js :

- `Include sites-available/ui.conf` → ARC-UI sur **/ui/** (port 3001)
- `Include sites-available/admin.conf` → admin
- **À ajouter** : DISMAS sur **/dismas/** (port 3002)

**Étape 1 – Créer `/etc/apache2/sites-available/dismas.conf`**

Copier le contenu du fichier **`docs/apache-dismas.conf`** du projet, ou créer le fichier avec :

```bash
sudo nano /etc/apache2/sites-available/dismas.conf
```

Contenu (identique dans l’esprit à **ui.conf**, chemin `/dismas/` et port **3002**) :

```apache
# =========================
# DISMAS Backoffice - Next.js Application
# =========================
# Pas de RedirectMatch /dismas -> /dismas/ (sinon boucle avec Next.js). On proxy /dismas aussi.
ProxyPreserveHost On

# DISMAS Backoffice (port 3002)
ProxyPass /dismas/_next/static/ http://localhost:3002/dismas/_next/static/
ProxyPassReverse /dismas/_next/static/ http://localhost:3002/dismas/_next/static/
ProxyPass /dismas/ http://localhost:3002/dismas/
ProxyPassReverse /dismas/ http://localhost:3002/dismas/
ProxyPass /dismas http://localhost:3002/dismas
ProxyPassReverse /dismas http://localhost:3002/dismas

# Cache longue durée pour _next/static - DISMAS
<LocationMatch "^/dismas/_next/static">
    ExpiresActive On
    ExpiresDefault "access plus 1 year"
    Header append Cache-Control "public"
</LocationMatch>

<Directory "/var/www/dismas">
    Options -Indexes
    Require all granted
</Directory>
```

**Étape 2 – Inclure dismas.conf dans base.conf**

Dans **`/etc/apache2/sites-available/base.conf`**, à côté des autres `Include`, ajouter :

```apache
Include sites-available/dismas.conf
```

Par exemple juste après la ligne `Include sites-available/admin.conf` :

```apache
    Include sites-available/ui.conf
    Include sites-available/admin.conf
    Include sites-available/dismas.conf
```

**Étape 3 – Tester et recharger Apache**

```bash
sudo apache2ctl configtest
# Doit afficher : Syntax OK

sudo systemctl reload apache2
```

**Accès à l’application :**  
- Adresse publique : **http://154.0.30.233/dismas/** (avec le slash final).  
- En interne (si différent) : http://192.168.3.191/dismas/ ou le domaine du serveur.  

**Important :** Utiliser **/dismas/** (avec slash final). Si l’on ouvre `http://154.0.30.233/dismas` sans slash, la requête peut être envoyée à Tomcat (port 8080) et renvoyer une 404. La config inclut une redirection `RedirectMatch 301 ^/dismas$ /dismas/` pour corriger cela.

Next.js doit être buildé avec **`basePath: '/dismas'`** (via `NEXT_PUBLIC_BASE_PATH=/dismas` dans `.env.production`).

**Exposer l’API sur le même host (/dismas-api)**  
Le front appelle l’API à **même host + `/dismas-api`** (pas d’IP en dur). Il faut donc que Apache proxy **/dismas-api/** vers le backend (Tomcat). Dans le même VirtualHost (base.conf) ou dans un fichier inclus, ajouter par exemple (adapter le port 8080 si besoin) :

```apache
ProxyPass /dismas-api/ http://localhost:8080/
ProxyPassReverse /dismas-api/ http://localhost:8080/
```

Voir **`docs/apache-dismas-api.conf.example`**. Ainsi, en changeant de serveur, on configure uniquement Apache ; le code reste inchangé.

---

### 4.2 Alternative : VirtualHost dédié (site à la racine)

Si vous préférez un VirtualHost séparé où DISMAS répond à la racine `/` (sans `/dismas/`), créez un fichier dédié avec `ProxyPass / http://127.0.0.1:3002/` et utilisez `a2ensite` ; dans ce cas, **retirer** `basePath: '/dismas'` de `next.config.mjs` et rebuilder. Sur ce VPS, la configuration recommandée reste **4.1** (Include dans base.conf, chemin `/dismas/`).

---

## 5. HTTPS avec Let’s Encrypt

### 5.1 Préconditions

- Un **nom de domaine** (ex. `www.votredomaine.org`) dont le DNS pointe vers l’IP du VPS.
- Le port **80** accessible depuis Internet (Let’s Encrypt valide le domaine via HTTP).

### 5.2 Installation et obtention du certificat

```bash
# Installer Certbot et le plugin Apache
sudo apt-get update
sudo apt-get install -y certbot python3-certbot-apache

# Obtenir et installer le certificat (Certbot modifie Apache pour le HTTPS)
sudo certbot --apache -d www.votredomaine.org
```

Certbot pose quelques questions (email, conditions d’utilisation). Il configure ensuite un VirtualHost sur le port **443** et redirige souvent le HTTP vers le HTTPS.

### 5.3 Vérifier que le proxy est bien sur le VirtualHost 443

Après Certbot, il peut y avoir un nouveau fichier (ex. `dismas-backoffice-le-ssl.conf`) ou des blocs ajoutés dans un fichier existant. Ouvrir la config SSL et s’assurer que le **proxy vers 127.0.0.1:3002** est bien présent dans le bloc `<VirtualHost *:443>`, comme dans la section 4.1 (avec `ProxyPass / http://127.0.0.1:3002/` et `ProxyPassReverse`). Sinon, les ajouter dans le bloc 443.

Pour le protocole indiqué à l’app :

```apache
RequestHeader set X-Forwarded-Proto "https"
```

### 5.4 Renouvellement automatique

Let’s Encrypt renouvelle les certificats avant expiration. Tester le renouvellement avec :

```bash
sudo certbot renew --dry-run
```

Si la commande se termine sans erreur, le renouvellement automatique (via cron ou systemd) fonctionnera.

---

## 6. Mises à jour et procédure de redéploiement

### 6.1 Mise à jour “classique” (code + rebuild)

À exécuter depuis le répertoire du projet (par exemple en tant que `deploy` ou root) :

```bash
cd /var/www/dismas

# 1. Récupérer les derniers changements
git fetch origin
git checkout main
git pull origin main

# 2. Vérifier / adapter .env.production si l’URL d’API ou l’environnement a changé
nano .env.production

# 3. Réinstaller les dépendances (au cas où package.json ou lock a changé)
npm ci

# 4. Rebuild (obligatoire si le code ou les NEXT_PUBLIC_* ont changé)
npm run build

# 5. Redémarrer l’application sous PM2
pm2 restart dismas-backoffice

# 6. Vérifier le statut et les logs
pm2 list
pm2 logs dismas-backoffice --lines 50
```

### 6.2 Rollback rapide

Si après une mise à jour l’application est cassée :

```bash
cd /var/www/dismas
git log -1   # noter le commit actuel si besoin
git checkout <commit-précédent-connu>
npm ci
npm run build
pm2 restart dismas-backoffice
```

Ensuite, investiguer le problème avant de revenir à la dernière version.

### 6.3 Changer l’URL de l’API (NEXT_PUBLIC_API_URL)

Toute modification de `NEXT_PUBLIC_*` impose un **nouveau build** :

1. Modifier `.env.production` (par ex. `NEXT_PUBLIC_API_URL=...`).
2. Relancer `npm run build`.
3. `pm2 restart dismas-backoffice`.

Un simple redémarrage sans rebuild ne suffit pas, car l’URL est injectée au build.

---

## 7. Vérifications et tests

### 7.1 Next.js répond en local

```bash
curl -I http://127.0.0.1:3002
```

Attendu : réponse HTTP (ex. `200 OK` ou `304`) et des en-têtes HTML/Next.js. Si “Connection refused”, Next.js n’écoute pas ou pas sur 3002 : vérifier `pm2 list` et `pm2 logs dismas-backoffice`.

### 7.2 Apache transmet bien au backend Next.js

Depuis le serveur :

```bash
curl -I http://127.0.0.1
# ou, si vous utilisez le domaine :
curl -I -H "Host: www.votredomaine.org" http://127.0.0.1
```

Depuis votre machine (remplacer par votre domaine ou l’IP du VPS) :

```bash
curl -I http://www.votredomaine.org
# ou
curl -I http://IP_DU_VPS
```

Vous devez obtenir une réponse HTTP (souvent 200 ou 304), pas 502.

### 7.3 Page d’accueil et navigation

Ouvrir dans un navigateur :  
`http://www.votredomaine.org` (ou l’IP).  
Vérifier que la page du backoffice s’affiche et que la connexion / les appels API fonctionnent (onglet Réseau / Network : les requêtes doivent partir vers l’URL définie dans `NEXT_PUBLIC_API_URL`).

### 7.4 Vérifier l’URL d’API utilisée par le front

Les requêtes XHR/fetch du front doivent pointer vers la même base que `NEXT_PUBLIC_API_URL`. Dans les DevTools (F12) → Network, filtrer par “XHR” ou “Fetch” et contrôler l’URL des requêtes vers l’API DISMAS.

---

## 8. Dépannage détaillé

### 8.1 502 Bad Gateway

**Cause typique :** Apache ne peut pas joindre Next.js (processus arrêté ou mauvais port).

**Vérifications :**

```bash
# Le processus PM2 est-il en “online” ?
pm2 list

# Next.js écoute-t-il sur 3002 ?
sudo ss -tlnp | grep 3002

# Dernières lignes des logs Next.js
pm2 logs dismas-backoffice --lines 100
```

Si le processus est “stopped” ou “errored”, inspecter les logs pour l’erreur (ex. crash au démarrage). Relancer si besoin :  
`pm2 restart dismas-backoffice`  
ou corriger la cause (dépendances, mémoire, erreur dans le code).

Vérifier aussi que dans le VirtualHost Apache, les adresses sont bien `http://127.0.0.1:3002/` (et non une autre IP ou port).

### 8.2 Page blanche ou erreurs JavaScript

Souvent lié à une **mauvaise URL d’API** ou à une variable `NEXT_PUBLIC_*` manquante au build.

- Vérifier dans le navigateur (F12 → Console) les erreurs (réseau, CORS, 404 sur l’API).
- Vérifier que `.env.production` contenait la bonne `NEXT_PUBLIC_API_URL` **au moment du build**.
- Si l’URL a changé ou si le fichier était absent : corriger `.env.production`, refaire `npm run build`, puis `pm2 restart dismas-backoffice`.

### 8.3 Erreurs CORS (API refusée par le navigateur)

Le backend DISMAS (Spring) doit autoriser l’origine du front (ex. `https://www.votredomaine.org`).  
Configurer CORS côté backend pour inclure cette origine (et éventuellement `http://IP_DU_VPS` en staging). Ce n’est pas réglé côté Apache/Next.js seul.

### 8.4 503 Service Unavailable

Souvent après un `reload` Apache alors que Next.js est arrêté. Vérifier que PM2 a bien l’app “online” et que le port 3002 répond (voir 8.1).

### 8.5 Logs utiles

```bash
# Logs applicatif Next.js (PM2)
pm2 logs dismas-backoffice

# Logs Apache (erreurs)
sudo tail -f /var/log/apache2/dismas-backoffice-error.log

# Logs Apache (accès)
sudo tail -f /var/log/apache2/dismas-backoffice-access.log
```

### 8.6 Port 3002 déjà utilisé

Si un autre programme utilise le port 3002 :

- Soit arrêter ce programme.
- Soit modifier **`ecosystem.config.js`** : changer `args: 'run start -- -p 3002'` et `PORT: 3002` vers un autre port (ex. 3003), puis adapter le VirtualHost Apache (`ProxyPass` / `ProxyPassReverse` vers ce port), et redémarrer : `pm2 delete dismas-backoffice && pm2 start ecosystem.config.js`.

---

## 9. Sécurité et bonnes pratiques

- **Ne pas commiter** `.env.production` (vérifier qu’il est dans `.gitignore`).
- **Firewall** : ouvrir 80 et 443 ; garder 3002 fermé depuis l’extérieur (écoute sur 127.0.0.1 uniquement).
- **Mises à jour** : mettre à jour régulièrement le système (`apt update && apt upgrade`) et les dépendances npm.
- **Utilisateur dédié** : faire tourner l’app et le build avec un utilisateur non-root (ex. `deploy`) et limiter les droits sur `/var/www/dismas`.
- **PM2** : utiliser `pm2 save` après chaque changement de processus et s’assurer que `pm2 startup` a été exécuté pour la persistance au reboot.

---

Ce document décrit de façon explicite et détaillée comment le déploiement se fera sur le VPS avec Apache. Adapter les chemins, le nom de domaine et l’URL d’API selon votre environnement.
