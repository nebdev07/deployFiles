# 🌍 Configuration des Environnements - DISMAS

## 📋 Vue d'ensemble

L'application DISMAS utilise une configuration automatique qui détecte l'environnement (développement ou production) et configure l'URL du backend en conséquence.

---

## 🔧 Configuration actuelle

### **Fichier** : `lib/config/api.ts`

```typescript
const configs: Record<string, ApiConfig> = {
  development: {
    baseUrl: 'http://localhost:8081',
    timeout: 10000,
    headers: {
      'Content-Type': 'application/json',
    },
  },
  production: {
    baseUrl: 'http://51.91.253.21:8080/dismas-api',
    timeout: 15000,
    headers: {
      'Content-Type': 'application/json',
    },
  },
};

// Détection automatique de l'environnement
const environment = process.env.NODE_ENV === 'production' ? 'production' : 'development';

export const apiConfig: ApiConfig = configs[environment];
```

---

## 🚀 URLs Backend

| **Environnement** | **URL Backend** | **Timeout** |
|-------------------|-----------------|-------------|
| **Development** | `http://localhost:8081` | 10 secondes |
| **Production** | `http://51.91.253.21:8080/dismas-api` | 15 secondes |

---

## 🔄 Détection automatique

### **Comment ça fonctionne ?**

L'application détecte automatiquement l'environnement grâce à la variable `process.env.NODE_ENV` :

```typescript
const environment = process.env.NODE_ENV === 'production' ? 'production' : 'development';
```

- **Développement** : `NODE_ENV` n'est pas défini ou = `development`
- **Production** : `NODE_ENV` = `production`

---

## 💻 Utilisation en Développement

### **Lancer l'application**
```bash
npm run dev
# OU
yarn dev
```

**Résultat** :
- ✅ `NODE_ENV` = `development` (par défaut)
- ✅ Backend URL = `http://localhost:8081`
- ✅ Tous les endpoints pointent vers localhost

**Exemple de requête** :
```
POST http://localhost:8081/retourManuel/create
POST http://localhost:8081/matiere/getByCriteria
POST http://localhost:8081/user/connexion
```

---

## 🌐 Utilisation en Production

### **Build de production**
```bash
npm run build
# OU
yarn build
```

### **Lancer en production**
```bash
npm run start
# OU
yarn start
```

**Résultat** :
- ✅ `NODE_ENV` = `production` (automatique)
- ✅ Backend URL = `http://51.91.253.21:8080/dismas-api`
- ✅ Tous les endpoints pointent vers le serveur de production

**Exemple de requête** :
```
POST http://51.91.253.21:8080/dismas-api/retourManuel/create
POST http://51.91.253.21:8080/dismas-api/matiere/getByCriteria
POST http://51.91.253.21:8080/dismas-api/user/connexion
```

---

## 🔍 Vérifier la configuration active

### **Dans le code (console browser)**
```javascript
// Ouvrir F12 > Console
console.log('API Config:', apiConfig)
console.log('Base URL:', apiConfig.baseUrl)
console.log('Environment:', process.env.NODE_ENV)
```

### **Dans les requêtes réseau (F12 > Network)**
1. Ouvrir F12 > Onglet Network
2. Faire une action (ex: créer un retour)
3. Cliquer sur la requête
4. Vérifier l'URL complète

**Attendu en développement** :
```
http://localhost:8081/retourManuel/create
```

**Attendu en production** :
```
http://51.91.253.21:8080/dismas-api/retourManuel/create
```

---

## 📝 Structure des endpoints

### **Pattern général**
```
{baseUrl}/{endpoint}/{action}
```

### **Exemples**

#### **Développement**
```
http://localhost:8081/retourManuel/create
http://localhost:8081/retourManuel/getByCriteria
http://localhost:8081/retourManuel/update
http://localhost:8081/retourManuel/delete

http://localhost:8081/matiere/getByCriteria
http://localhost:8081/niveauScolaire/getByCriteria
http://localhost:8081/anneeScolaire/getByCriteria
```

#### **Production**
```
http://51.91.253.21:8080/dismas-api/retourManuel/create
http://51.91.253.21:8080/dismas-api/retourManuel/getByCriteria
http://51.91.253.21:8080/dismas-api/retourManuel/update
http://51.91.253.21:8080/dismas-api/retourManuel/delete

http://51.91.253.21:8080/dismas-api/matiere/getByCriteria
http://51.91.253.21:8080/dismas-api/niveauScolaire/getByCriteria
http://51.91.253.21:8080/dismas-api/anneeScolaire/getByCriteria
```

---

## 🛠️ Modifier la configuration

### **Changer l'URL de production**

**Fichier** : `lib/config/api.ts`

```typescript
production: {
  baseUrl: 'http://NOUVELLE_IP:PORT/dismas-api',  // ← Modifier ici
  timeout: 15000,
  headers: {
    'Content-Type': 'application/json',
  },
},
```

### **Changer le timeout**

```typescript
development: {
  baseUrl: 'http://localhost:8081',
  timeout: 20000,  // ← Augmenter à 20 secondes
  headers: {
    'Content-Type': 'application/json',
  },
},
```

### **Ajouter des headers personnalisés**

```typescript
production: {
  baseUrl: 'http://51.91.253.21:8080/dismas-api',
  timeout: 15000,
  headers: {
    'Content-Type': 'application/json',
    'X-Custom-Header': 'value',  // ← Ajouter ici
  },
},
```

---

## 🔐 Variables d'environnement (optionnel)

Pour plus de flexibilité, vous pouvez utiliser des variables d'environnement Next.js :

### **Créer `.env.local`** (développement)
```bash
# .env.local
NEXT_PUBLIC_API_URL=http://localhost:8081
NEXT_PUBLIC_API_TIMEOUT=10000
```

### **Créer `.env.production`** (production)
```bash
# .env.production
NEXT_PUBLIC_API_URL=http://51.91.253.21:8080/dismas-api
NEXT_PUBLIC_API_TIMEOUT=15000
```

### **Modifier `api.ts` pour utiliser les variables**
```typescript
const configs: Record<string, ApiConfig> = {
  development: {
    baseUrl: process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8081',
    timeout: parseInt(process.env.NEXT_PUBLIC_API_TIMEOUT || '10000'),
    headers: {
      'Content-Type': 'application/json',
    },
  },
  production: {
    baseUrl: process.env.NEXT_PUBLIC_API_URL || 'http://51.91.253.21:8080/dismas-api',
    timeout: parseInt(process.env.NEXT_PUBLIC_API_TIMEOUT || '15000'),
    headers: {
      'Content-Type': 'application/json',
    },
  },
};
```

---

## 🧪 Tests

### **Test 1 : Vérifier l'URL en développement**
```bash
npm run dev
# Ouvrir http://localhost:3000
# Ouvrir F12 > Console
# Taper : console.log(apiConfig.baseUrl)
# Attendu : http://localhost:8081
```

### **Test 2 : Vérifier l'URL en production**
```bash
npm run build
npm run start
# Ouvrir http://localhost:3000
# Ouvrir F12 > Console
# Taper : console.log(apiConfig.baseUrl)
# Attendu : http://51.91.253.21:8080/dismas-api
```

### **Test 3 : Vérifier les requêtes réseau**
```bash
# En développement
npm run dev
# Créer un retour
# F12 > Network > Vérifier l'URL de la requête
# Attendu : http://localhost:8081/retourManuel/create

# En production
npm run build
npm run start
# Créer un retour
# F12 > Network > Vérifier l'URL de la requête
# Attendu : http://51.91.253.21:8080/dismas-api/retourManuel/create
```

---

## 🚨 Dépannage

### **Problème : L'URL ne change pas en production**

**Cause** : `NODE_ENV` n'est pas défini sur `production`

**Solution** :
```bash
# Vérifier NODE_ENV
echo $NODE_ENV  # Linux/Mac
echo %NODE_ENV%  # Windows

# Forcer en production
export NODE_ENV=production  # Linux/Mac
set NODE_ENV=production     # Windows

npm run build
npm run start
```

### **Problème : Erreur CORS en production**

**Cause** : Le backend n'autorise pas l'origine du frontend

**Solution** : Configurer CORS sur le backend Spring Boot
```java
@CrossOrigin(origins = {
    "http://localhost:3000",
    "http://51.91.253.21:3000",
    "https://votre-domaine.com"
})
```

### **Problème : Timeout trop court**

**Cause** : Connexion lente ou backend surchargé

**Solution** : Augmenter le timeout dans `api.ts`
```typescript
production: {
  baseUrl: 'http://51.91.253.21:8080/dismas-api',
  timeout: 30000,  // 30 secondes
  headers: {
    'Content-Type': 'application/json',
  },
},
```

---

## 📊 Résumé

| **Action** | **Commande** | **NODE_ENV** | **URL Backend** |
|------------|--------------|--------------|-----------------|
| Développement | `npm run dev` | `development` | `http://localhost:8081` |
| Build | `npm run build` | `production` | `http://51.91.253.21:8080/dismas-api` |
| Production | `npm run start` | `production` | `http://51.91.253.21:8080/dismas-api` |

---

## ✅ Checklist

- [x] Configuration `api.ts` mise à jour avec l'URL de production
- [x] Détection automatique de l'environnement configurée
- [x] Timeout différencié par environnement (10s dev, 15s prod)
- [x] Headers configurés
- [x] Documentation complète créée
- [ ] Tests en développement à effectuer
- [ ] Tests en production à effectuer
- [ ] Vérification CORS backend à effectuer

---

**Date de configuration** : Octobre 2025
**URL Production** : `http://51.91.253.21:8080/dismas-api`
**Fichier modifié** : `lib/config/api.ts` (ligne 22)
**Statut** : ✅ Prêt pour production

