# 🔧 CORRECTION - userType DAF ENVOYÉ COMME "ADMIN"

**Date** : 2025-10-11  
**Problème** : Lors de la création d'un utilisateur DAF, le frontend envoie `userType = "ADMIN"` au lieu de `userType = "DAF"`  
**Statut** : ✅ **RÉSOLU**

---

## 🐛 SYMPTÔME

Lors de la création d'un utilisateur avec le rôle **DAF** :

**Frontend envoie** :
```json
{
  "user": 1,
  "token": "...",
  "datas": [{
    "login": "daf1",
    "email": "daf1@yopmail.com",
    "roleCode": "DAF",
    "userType": "ADMIN"  // ❌ ADMIN au lieu de DAF !
  }]
}
```

**Backend reçoit** :
```java
dto.getUserType() = "ADMIN"  // ❌ Alors qu'on a sélectionné DAF
```

**Conséquence** :
- Le backend exécute le cas `"ADMIN"` du switch
- Retourne `null` (pas de structure)
- L'utilisateur DAF est créé **SANS structure**

---

## 🔍 CAUSE RACINE

**Fichier** : `lib/types/entities.ts`  
**Ligne** : 496-497

```typescript
function getUserTypeFromRole(roleCode: string): string {
  switch (roleCode.toUpperCase()) {
    case 'ADMIN':
    case 'DAF':
      return 'ADMIN';  // ❌ DAF et ADMIN retournent tous les deux 'ADMIN'
    case 'DRENA':
      return 'DRENA';
    case 'IEPP':
      return 'IEPP';
    case 'DIRECTEUR':
      return 'EPP';
    default:
      return 'USER';
  }
}
```

**Problème** :
- Les cas `'ADMIN'` et `'DAF'` sont groupés ensemble
- Retournent tous les deux `'ADMIN'`
- Le backend ne peut pas distinguer un ADMIN d'un DAF

---

## ✅ CORRECTION APPLIQUÉE

**Fichier** : `lib/types/entities.ts`  
**Lignes** : 495-498

**Avant** :
```typescript
case 'ADMIN':
case 'DAF':
  return 'ADMIN';  // ❌ Groupé ensemble
```

**Après** :
```typescript
case 'ADMIN':
  return 'ADMIN';  // ✅ ADMIN séparé
case 'DAF':
  return 'DAF';    // ✅ DAF séparé
```

---

## 📊 MAPPING ROLE → USERTYPE

**Après correction** :

| Role Code   | userType (envoyé au backend) | Backend crée structure ? | Type structure |
|-------------|------------------------------|--------------------------|----------------|
| **ADMIN**   | "ADMIN"                      | ❌ Non                   | null           |
| **DAF**     | "DAF"                        | ✅ Oui                   | "DAF"          |
| **DRENA**   | "DRENA"                      | ✅ Oui                   | "DRENA"        |
| **IEPP**    | "IEPP"                       | ✅ Oui                   | "IEPP"         |
| **DIRECTEUR** | "EPP"                      | ✅ Oui                   | "EPP"          |

---

## 🧪 TESTS

### **Test 1 : Créer un utilisateur ADMIN**

**Payload envoyé** :
```json
{
  "roleCode": "ADMIN",
  "userType": "ADMIN"  // ✅ Correct
}
```

**Backend** :
```java
switch (dto.getUserType()) {
    case "ADMIN":
        log.info("Type ADMIN détecté : aucune structure créée");
        return null;  // ✅ Pas de structure
}
```

**Résultat BDD** :
```sql
SELECT * FROM user WHERE login = 'admin2';
-- structure_id : NULL ✅
```

---

### **Test 2 : Créer un utilisateur DAF**

**Payload envoyé** :
```json
{
  "roleCode": "DAF",
  "userType": "DAF"  // ✅ Correct maintenant !
}
```

**Backend** :
```java
switch (dto.getUserType()) {
    case "DAF":
        String dafCode = generateDafCode(dto);  // "DAF-DAF1"
        newStructure.setCode(dafCode);
        newStructure.setType("DAF");
        newStructure.setDrena(null);
        newStructure.setIepp(null);
        newStructure.setEpp(null);
        break;  // ✅ Structure DAF créée
}
```

**Résultat BDD** :
```sql
-- Table user
SELECT * FROM user WHERE login = 'daf1';
-- structure_id : 123 ✅

-- Table structure_administrative
SELECT * FROM structure_administrative WHERE id = 123;
-- code : "DAF-DAF1"
-- type : "DAF"
-- drena_id : NULL ✅
-- iepp_id : NULL ✅
-- epp_id : NULL ✅
```

---

## 📋 FICHIERS MODIFIÉS

| Fichier | Modification | Ligne |
|---------|--------------|-------|
| **entities.ts** | Séparation des cas ADMIN et DAF | 495-498 |

---

## 🎯 WORKFLOW COMPLET DE CRÉATION DAF

```
1. Frontend - Formulaire
   User sélectionne "DAF" dans le dropdown des rôles
   ↓
2. Frontend - CreateUserForm.tsx
   handleSubmit() → buildCreateUserRequest()
   ↓
3. Frontend - entities.ts
   getUserTypeFromRole("DAF") → return "DAF"  // ✅ Correct
   ↓
4. Frontend - Requête HTTP
   POST /user/create
   {
     "user": 1,
     "token": "...",
     "datas": [{
       "roleCode": "DAF",
       "userType": "DAF",  // ✅ Correct
       "login": "daf1",
       ...
     }]
   }
   ↓
5. Backend - UserBusiness.create()
   needsStructure("DAF") → true
   ↓
6. Backend - createStructureAdministrativeWithValidation()
   switch (dto.getUserType()) {
     case "DAF":  // ✅ Match !
       ...
   }
   ↓
7. Backend - Création structure DAF
   code: "DAF-DAF1"
   type: "DAF"
   drena_id: NULL
   iepp_id: NULL
   epp_id: NULL
   parent_id: 1
   ↓
8. Backend - Création user
   structure_id: 123  // ✅ Lié à la structure DAF
   ↓
9. Backend - Réponse
   {
     "items": [{ id: 10, login: "daf1", ... }],
     "hasError": false
   }
```

---

## ✅ RÉSULTAT

**Avant** :
```json
// Requête envoyée
{ "roleCode": "DAF", "userType": "ADMIN" }  // ❌

// Backend
switch ("ADMIN") → return null  // ❌ Pas de structure créée

// BDD
user.structure_id = NULL  // ❌ Incorrect pour DAF
```

**Après** :
```json
// Requête envoyée
{ "roleCode": "DAF", "userType": "DAF" }  // ✅

// Backend
switch ("DAF") → Crée structure DAF  // ✅

// BDD
user.structure_id = 123  // ✅ Correct
structure_administrative.type = "DAF"  // ✅
```

---

## 🚀 PROCHAINES ÉTAPES

1. **Redémarrer le frontend** (pour prendre en compte la modification TypeScript)
   ```bash
   # Arrêter (Ctrl+C)
   npm run dev
   ```

2. **Tester la création d'un DAF**
   - Aller sur `/users`
   - Créer un utilisateur avec rôle "DAF"
   - Ne pas remplir DRENA/IEPP/EPP
   - ✅ Vérifier que la création réussit
   - ✅ Vérifier dans la BDD que `structure_administrative.type = 'DAF'`

3. **Tester la création d'un ADMIN**
   - Créer un utilisateur avec rôle "ADMIN"
   - ✅ Vérifier que `structure_id = NULL`

---

**Document créé le** : 2025-10-11  
**Statut** : ✅ **PRÊT POUR TEST**

