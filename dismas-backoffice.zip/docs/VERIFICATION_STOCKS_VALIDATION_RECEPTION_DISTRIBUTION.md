# Vérification : Mise à jour des stocks (validation réception EPP + distribution aux élèves)

## 1. Après validation de la réception EPP → stock IEPP décrémenté

### Flux backend

1. **Validation IEPP**  
   - `MouvementBusiness.validateMouvement(MouvementId, "IEPP", userId, locale)`  
   - Le mouvement (réception EPP) passe en statut **VALIDEE**.

2. **Création des MouvementStock** (`createStockMovementsForMouvement`)  
   - Pour chaque matière de la réception :
     - **MouvementStock EPP** : `typeMouvement = "RECEPTION_EPP"`, **quantité positive** (entrée stock EPP).
     - **MouvementStock IEPP** : `typeMouvement = "DISTRIBUTION_VERS_EPP"`, **quantité négative** (`-matiereQuantite.getQuantiteRecue()`) pour l’IEPP parent (sortie stock IEPP).
   - Fichier : `MouvementBusiness.java` (l. 2187–2273).

3. **Mise à jour StockDisponible** (`stockDisponibleBusiness.updateStockFromMouvement(Mouvement)`)  
   - Pour chaque `MouvementStock` du mouvement :
     - **RECEPTION_EPP** : `quantiteReceptions += ms.getQuantite()` (positif) → stock EPP augmenté.
     - **DISTRIBUTION_VERS_EPP** : `quantiteDistributions += ms.getQuantite()` (négatif) → stock IEPP diminué.
   - Puis `stock.recalculerStockDisponible()` : `quantiteDisponible = quantiteReceptions + quantiteDistributions + retours...`  
   - Fichiers : `StockDisponibleBusiness.java` (l. 285–294, 361–399), `StockDisponible.java` (l. 137–141).

**Conclusion** : À la validation de la réception EPP par l’IEPP, le stock IEPP est bien décrémenté (MouvementStock négatif + mise à jour `StockDisponible`), et le stock EPP est incrémenté.

---

## 2. Après distribution aux élèves → stock EPP décrémenté

### Flux backend

1. **Création de la distribution**  
   - `DistributionEleveBusiness.createDistributionWithStockValidation(...)`  
   - Après création de la distribution : appel à `createStockMovementsForClassDistribution(eppId, matieres, distributionId, niveauId, userId)`.

2. **Création des MouvementStock** (`createStockMovementsForClassDistribution`)  
   - Pour chaque matière distribuée :
     - **MouvementStock** : structure = EPP, `typeMouvement = "DISTRIBUTION_CLASSES"`, **quantité négative** (`-matiere.getQuantiteRecue()`).
   - Fichier : `DistributionEleveBusiness.java` (l. 827–833).

3. **Mise à jour StockDisponible**  
   - Juste après chaque `mouvementStockRepository.save(mouvementStock)` :  
     `stockDisponibleBusiness.updateStockFromMouvementStock(mouvementStock)`.
   - Dans `updateStockFromMouvementStock` : pour **DISTRIBUTION_CLASSES**,  
     `stock.setQuantiteDistributions(stock.getQuantiteDistributions() + ms.getQuantite())` (quantité négative) → stock EPP diminué.
   - Puis `stock.recalculerStockDisponible()` et `stockDisponibleRepository.save(stock)`.
   - Fichiers : `DistributionEleveBusiness.java` (l. 864–867), `StockDisponibleBusiness.java` (l. 295–299).

**Conclusion** : Lors de la distribution aux élèves, le stock EPP est bien décrémenté (MouvementStock négatif + mise à jour immédiate de `StockDisponible`).

---

## 3. Menu Gestion des stocks → affichage cohérent

### Backend

- **Endpoint** : `GET /stock/structure/{structureId}/annee/{anneeScolaireId}`  
- **Controller** : `StockController.getStocksByStructureAndAnnee`  
- **Source des données** : `stockDisponibleBusiness.getStocksByStructureAndAnnee(structureId, anneeScolaireId)`  
  → Lecture directe de la table **StockDisponible** (même table mise à jour par validation réception et par distribution).

### Frontend

- **Page** : `app/stocks/page.tsx`  
- **Service** : `stockService.getStocksForPage(structureId, anneeScolaireId)`  
  → Appel à `/stock/structure/${structureId}/annee/${anneeScolaireId}`.  
- Les indicateurs affichés (Stock Disponible, Réceptions, Distributions) proviennent des champs `stockDisponible`, `stockReception`, `stockDistribution` mappés depuis les DTOs **StockDisponible** (quantiteDisponible, quantiteReceptions, quantiteDistributions).

**Conclusion** : Le menu « Gestion des stocks » affiche bien les données de la table `StockDisponible`, mise à jour après validation de réception EPP et après distribution aux élèves. Un rafraîchissement (bouton « Actualiser » ou rechargement de la page) montre les stocks à jour.

---

## 4. Synthèse

| Événement | Stock impacté | Mécanisme | Affichage Gestion des stocks |
|-----------|----------------|-----------|------------------------------|
| Validation réception EPP (IEPP valide) | IEPP décrémenté, EPP incrémenté | `createStockMovementsForMouvement` (MouvementStock RECEPTION_EPP + DISTRIBUTION_VERS_EPP) puis `updateStockFromMouvement` | Oui (GET /stock/structure/.../annee/...) |
| Distribution aux élèves | EPP décrémenté | `createStockMovementsForClassDistribution` (MouvementStock DISTRIBUTION_CLASSES négatif) puis `updateStockFromMouvementStock` | Oui (même endpoint) |

Les chaînes de code vérifiées sont cohérentes : validation réception EPP et distribution aux élèves mettent bien à jour `StockDisponible`, et la page Stocks lit cette même table.
