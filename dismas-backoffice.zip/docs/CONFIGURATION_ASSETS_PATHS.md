# 🖼️ Configuration des chemins d'assets - DISMAS

## 📋 Vue d'ensemble

L'application utilise des chemins différents pour les assets (images, logos, fichiers) selon l'environnement :

- **Développement** : `/imgs/logos/logo.jpg`
- **Production** : `/dismas/backoffice/imgs/logos/logo.jpg`

Cette configuration est gérée automatiquement via un utilitaire dédié et la configuration Next.js.

---

## 🔧 Configuration automatique

### **1. Utilitaire de gestion des chemins**

**Fichier** : `lib/utils/asset-paths.ts`

```typescript
import { getLogoPath, getImagePath, getAssetPath } from '@/lib/utils/asset-paths'

// Logo
const logoSrc = getLogoPath('logo.jpg')
// Dev:  /imgs/logos/logo.jpg
// Prod: /dismas/backoffice/imgs/logos/logo.jpg

// Image
const imageSrc = getImagePath('/imgs/photo.png')
// Dev:  /imgs/photo.png
// Prod: /dismas/backoffice/imgs/photo.png

// Asset générique
const assetSrc = getAssetPath('/files/document.pdf')
// Dev:  /files/document.pdf
// Prod: /dismas/backoffice/files/document.pdf
```

### **2. Configuration Next.js**

**Fichier** : `next.config.mjs`

```javascript
const nextConfig = {
  // Configuration pour le déploiement en production
  ...(process.env.NODE_ENV === 'production' && {
    basePath: '/dismas/backoffice',
    assetPrefix: '/dismas/backoffice',
  }),
}
```

**Effet** :
- `basePath` : Préfixe toutes les routes de l'application
- `assetPrefix` : Préfixe tous les assets statiques (CSS, JS, images dans `/public`)

---

## 📂 Structure des dossiers

```
dismas-backoffice/
├── public/
│   ├── imgs/
│   │   ├── logos/
│   │   │   └── logo.jpg          ← Fichier logo
│   │   ├── icons/
│   │   │   └── favicon.ico
│   │   └── photos/
│   │       └── placeholder.png
│   └── files/
│       └── documents.pdf
└── lib/
    └── utils/
        └── asset-paths.ts        ← Utilitaire de gestion
```

---

## 🎯 Utilisation dans les composants

### **Exemple 1 : Logo (composant Image)**

```tsx
import Image from 'next/image'
import { getLogoPath } from '@/lib/utils/asset-paths'

export default function Logo() {
  return (
    <Image
      src={getLogoPath('logo.jpg')}
      alt="DISMAS Logo"
      fill
      className="object-contain"
      priority
    />
  )
}
```

### **Exemple 2 : Image standard**

```tsx
import Image from 'next/image'
import { getImagePath } from '@/lib/utils/asset-paths'

export default function UserAvatar() {
  return (
    <Image
      src={getImagePath('/imgs/avatars/user.png')}
      alt="Avatar"
      width={40}
      height={40}
    />
  )
}
```

### **Exemple 3 : Balise img HTML**

```tsx
import { getImagePath } from '@/lib/utils/asset-paths'

export default function Banner() {
  return (
    <img 
      src={getImagePath('/imgs/banner.jpg')} 
      alt="Banner"
      className="w-full"
    />
  )
}
```

### **Exemple 4 : Lien de téléchargement**

```tsx
import { getAssetPath } from '@/lib/utils/asset-paths'

export default function DownloadButton() {
  return (
    <a 
      href={getAssetPath('/files/guide.pdf')}
      download
      className="btn-primary"
    >
      Télécharger le guide
    </a>
  )
}
```

### **Exemple 5 : Background CSS**

```tsx
import { getImagePath } from '@/lib/utils/asset-paths'

export default function Hero() {
  const bgImage = getImagePath('/imgs/hero-bg.jpg')
  
  return (
    <div 
      style={{ backgroundImage: `url(${bgImage})` }}
      className="h-screen bg-cover"
    >
      Hero Section
    </div>
  )
}
```

---

## 📊 Fonctions disponibles

### **getAssetPath(path: string)**

Fonction générique pour n'importe quel asset.

```typescript
getAssetPath('/imgs/photo.jpg')
getAssetPath('/files/doc.pdf')
getAssetPath('/videos/intro.mp4')
```

### **getImagePath(imagePath: string)**

Spécifique pour les images (alias de getAssetPath).

```typescript
getImagePath('/imgs/banner.png')
getImagePath('/imgs/users/avatar.jpg')
```

### **getLogoPath(logoName: string)**

Spécifique pour les logos dans `/imgs/logos/`.

```typescript
getLogoPath('logo.jpg')           // => /imgs/logos/logo.jpg (dev)
getLogoPath('logo-white.png')     // => /dismas/backoffice/imgs/logos/logo-white.png (prod)
```

### **getIconPath(iconName: string)**

Spécifique pour les icônes dans `/imgs/icons/`.

```typescript
getIconPath('favicon.ico')        // => /imgs/icons/favicon.ico (dev)
getIconPath('apple-touch-icon.png') // => /dismas/backoffice/imgs/icons/apple-touch-icon.png (prod)
```

### **isProduction()**

Détecte si on est en production.

```typescript
if (isProduction()) {
  console.log('Mode production')
} else {
  console.log('Mode développement')
}
```

### **debugAssetPath(path: string)**

Debug le chemin généré (console).

```typescript
debugAssetPath('/imgs/logo.jpg')
// Console: [Asset Path] production: { input: '/imgs/logo.jpg', output: '/dismas/backoffice/imgs/logo.jpg', isProduction: true }
```

---

## 🌍 Environnements

### **Développement**

```bash
npm run dev
```

**Résultat** :
- URL de l'app : `http://localhost:3000`
- Chemin des assets : `/imgs/logos/logo.jpg`
- `basePath` : Non défini
- `assetPrefix` : Non défini

**Exemple de requête d'asset** :
```
GET http://localhost:3000/imgs/logos/logo.jpg
```

### **Production**

```bash
npm run build
npm run start
```

**Résultat** :
- URL de l'app : `http://server/dismas/backoffice`
- Chemin des assets : `/dismas/backoffice/imgs/logos/logo.jpg`
- `basePath` : `/dismas/backoffice`
- `assetPrefix` : `/dismas/backoffice`

**Exemple de requête d'asset** :
```
GET http://server/dismas/backoffice/imgs/logos/logo.jpg
```

---

## 🔄 Migration des composants existants

### **Avant (hardcodé)**

```tsx
// ❌ Chemin hardcodé
<Image src="/imgs/logos/logo.jpg" alt="Logo" />
```

### **Après (dynamique)**

```tsx
// ✅ Chemin dynamique
import { getLogoPath } from '@/lib/utils/asset-paths'

<Image src={getLogoPath('logo.jpg')} alt="Logo" />
```

---

## 🧪 Tests

### **Test 1 : Vérifier le chemin en développement**

```bash
npm run dev
# Ouvrir http://localhost:3000
# F12 > Console
console.log(getLogoPath('logo.jpg'))
// Attendu : /imgs/logos/logo.jpg
```

### **Test 2 : Vérifier le chemin en production**

```bash
npm run build
npm run start
# Ouvrir http://localhost:3000
# F12 > Console
console.log(getLogoPath('logo.jpg'))
// Attendu : /dismas/backoffice/imgs/logos/logo.jpg
```

### **Test 3 : Vérifier l'affichage du logo**

```bash
# Développement
npm run dev
# Vérifier que le logo s'affiche

# Production
npm run build
npm run start
# Vérifier que le logo s'affiche
```

### **Test 4 : Vérifier les requêtes réseau**

```
F12 > Network > Filtrer par "img"
# En développement : /imgs/logos/logo.jpg
# En production : /dismas/backoffice/imgs/logos/logo.jpg
```

---

## 📝 Composants à migrer

### **Liste des composants utilisant des assets**

1. ✅ `components/ui/logo.tsx` (migré)
2. ⏳ `components/layout/main-layout.tsx`
3. ⏳ `app/auth/login/page.tsx`
4. ⏳ Tous les autres composants avec des images

### **Pattern de migration**

Pour chaque composant :

1. **Importer l'utilitaire**
   ```tsx
   import { getImagePath } from '@/lib/utils/asset-paths'
   ```

2. **Remplacer les chemins hardcodés**
   ```tsx
   // Avant
   src="/imgs/photo.jpg"
   
   // Après
   src={getImagePath('/imgs/photo.jpg')}
   ```

3. **Tester en développement et production**

---

## 🚨 Dépannage

### **Problème : Image ne s'affiche pas en production**

**Cause** : Chemin incorrect ou fichier manquant

**Solution** :
```bash
# Vérifier que le fichier existe
ls public/imgs/logos/logo.jpg

# Vérifier le chemin dans le navigateur
F12 > Network > Vérifier l'URL de la requête

# Debug le chemin
import { debugAssetPath } from '@/lib/utils/asset-paths'
debugAssetPath('/imgs/logos/logo.jpg')
```

### **Problème : basePath ne s'applique pas**

**Cause** : `NODE_ENV` n'est pas `production`

**Solution** :
```bash
# Vérifier NODE_ENV
echo $NODE_ENV

# Forcer en production
export NODE_ENV=production
npm run build
npm run start
```

### **Problème : 404 sur les assets**

**Cause** : Configuration serveur (Nginx/Apache) incorrecte

**Solution Nginx** :
```nginx
location /dismas/backoffice/ {
    alias /var/www/dismas-backoffice/;
    try_files $uri $uri/ /dismas/backoffice/index.html;
}

location /dismas/backoffice/_next/ {
    alias /var/www/dismas-backoffice/.next/;
}
```

---

## ✅ Checklist

- [x] Utilitaire `asset-paths.ts` créé
- [x] Configuration Next.js mise à jour (`basePath`, `assetPrefix`)
- [x] Composant `logo.tsx` migré
- [x] Documentation créée
- [ ] Migration des autres composants
- [ ] Tests en développement
- [ ] Tests en production
- [ ] Déploiement

---

## 📚 Références

- [Next.js basePath](https://nextjs.org/docs/app/api-reference/next-config-js/basePath)
- [Next.js assetPrefix](https://nextjs.org/docs/app/api-reference/next-config-js/assetPrefix)
- [Next.js Image Optimization](https://nextjs.org/docs/app/building-your-application/optimizing/images)

---

**Date** : Octobre 2025
**Fichiers créés** : `lib/utils/asset-paths.ts`, `CONFIGURATION_ASSETS_PATHS.md`
**Fichiers modifiés** : `next.config.mjs`, `components/ui/logo.tsx`
**Statut** : ✅ Configuration prête, migration en cours
















