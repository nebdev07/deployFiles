# Menu Stock / Stock Analyse – État, reste à faire, adaptations et blocages

## Contexte

Le **menu « Stocks »** (sidebar → `/stocks`) correspond à la page de gestion et d’**analyse des stocks** de manuels. La doc métier parle d’« Analyse des Stocks » (détection excédents/déficits, calcul des besoins) dans le workflow de régulation ; côté app, tout passe par la même entrée **Stocks** et la page `app/stocks/page.tsx`.

---

## 1. Ce qui est fait

### Frontend

- **Page Stocks** (`app/stocks/page.tsx`) en place avec :
  - Onglets : **Vue d’ensemble**, **Entrepôt BM**, **Stocks IEPP**, **Stocks EPP**, **Mouvements**
  - Filtrage des onglets par rôle (ADMIN, DAF, DRENA, IEPP, DIRECTEUR)
  - Boutons : Actualiser, Nouveau Mouvement, Rapport Stock
  - Vue d’ensemble : stats (Stock total, Points de stock, Alertes critiques, Mouvements jour), message « Stock en temps réel » si des données existent
  - Gestion du chargement, des erreurs et du cas « aucune donnée »
- **Service `stock.service.ts`** :
  - Types : `StockData`, `StockByStructure`, `MouvementStockData`, `StockServiceResponse<T>`
  - Méthodes : `getStockByStructure`, `getStockByMatiere`, `getAllStocksByStructure`, `getMouvementsStock`, `updateStock`, `generateStockReport`
- **Intégration partielle** : la page appelle `stockService.getStockByStructure(user.structure.id)` puis `getAllStocksByStructure` avec les matières, mais le service **n’utilise pas** les vrais endpoints `/stock/*` du backend (voir blocages).
- **Autres vues (Entrepôt, IEPP, EPP, Mouvements)** : présentes mais contenu placeholder (« Cette section sera disponible prochainement »).
- **Modals** : Détails du stock, Nouveau Mouvement, Rapport Stock : squelettes uniquement (« à implémenter »).
- **Sidebar** : entrée « Stocks » → `/stocks`, visible pour ADMIN, DAF, DRENA, IEPP, DIRECTEUR.
- **StockWidget** et **mouvement.service** : utilisent déjà les vrais endpoints `/stock/disponible` et `/stock/structure/{id}/annee/{anneeId}` (pour d’autres écrans).

### Backend

- **StockController** (`/stock`) opérationnel avec :
  - `GET /stock/disponible` (structureId, matiereId, niveauId?, anneeScolaireId?) → un `StockDisponibleDto`
  - `GET /stock/structure/{structureId}/annee/{anneeScolaireId}` → liste des stocks de la structure pour une année
  - `GET /stock/rupture/structure/{structureId}/annee/{anneeScolaireId}` → stocks en rupture
  - `GET /stock/retours-annee-precedente/{anneeScolaireId}` → stocks avec retours N-1
  - `GET /stock/resume/structure/{structureId}/annee/{anneeScolaireId}` → résumé texte
  - `POST /stock/recalculer/{anneeScolaireId}` (maintenance)
  - `POST /stock/verifier` (body: structureId, matiereId, niveauId, anneeScolaireId, quantiteDemandee)
- **DTO** : `StockDisponibleDto` avec structureId, matiereId, niveauId, anneeScolaireId, quantiteReceptions, quantiteDistributions, quantiteRetours, quantiteRetoursAnneePrecedente, quantiteDisponible, libellés (structure, matière, niveau, année), estEnRupture, aRetoursAnneePrecedente, etc.
- **Réponse** : format standard avec `item` (singulier) pour un élément, `items` (liste), `hasError`, `message`.

---

## 2. Ce qui reste à faire (pour rendre le menu « Stock analyse » fonctionnel)

### 2.1 Aligner le frontend sur l’API Stock réelle

- **Remplacer** dans `stock.service.ts` les appels à `/distributionEleve/getStock/...` par les endpoints **`/stock/*`** :
  - `getStockByStructure` → utiliser **`GET /stock/structure/{structureId}/annee/{anneeScolaireId}`** (et donc ajouter le paramètre **année scolaire** partout).
  - `getStockByMatiere` → **`GET /stock/disponible?structureId=&matiereId=&niveauId=&anneeScolaireId=`**.
  - `getAllStocksByStructure` → un seul appel **`GET /stock/structure/{structureId}/annee/{anneeScolaireId}`** (le backend renvoie déjà la liste par matière/niveau), plus de boucle sur les matières.
- **Adapter les types** frontend aux champs du `StockDisponibleDto` (ex. `quantiteDisponible`, `quantiteReceptions`, `quantiteDistributions`, `estEnRupture`, libellés structure/matière/niveau/année).
- **Gérer la réponse** : pour les endpoints qui renvoient un seul objet, le backend met l’objet dans `item` ; le service doit lire `response.item` (comme dans `mouvement.service` pour `/stock/disponible`).

### 2.2 Année scolaire

- **Sélecteur d’année scolaire** sur la page Stocks (comme ailleurs dans l’app) et passer **anneeScolaireId** à toutes les méthodes du `stock.service` qui appellent le backend.
- Utiliser le hook existant **`use-annees-scolaires`** et l’année courante (ou choix utilisateur) pour les appels.

### 2.3 Vue d’ensemble = « Stock analyse »

- **Vue d’ensemble** = contenu principal « analyse » :
  - Données réelles via **`/stock/structure/.../annee/...`** (tableau par matière/niveau, quantités, statut).
  - Indicateurs dérivés : total disponible, nombre de lignes en rupture, éventuellement « avec retours N-1 » (en utilisant **`/stock/rupture/...`** et **`/stock/retours-annee-precedente/...`** si besoin).
- Afficher **résumé** : appeler **`GET /stock/resume/structure/{id}/annee/{id}`** et afficher le texte (bloc dédié ou tooltip).

### 2.4 Onglet « Stocks en rupture » (analyse)

- Ajouter un onglet ou une section **« Ruptures »** / **« Analyse ruptures »** qui appelle **`GET /stock/rupture/structure/{structureId}/annee/{anneeScolaireId}`** et affiche la liste (matière, niveau, quantité, etc.).

### 2.5 Autres onglets (IEPP, EPP, Entrepôt, Mouvements)

- **Stocks IEPP / EPP** : selon le rôle, afficher les stocks des structures enfants (liste d’EPP sous l’IEPP, ou stock de l’EPP courant). Soit le backend expose des endpoints par type de structure / liste de structures, soit le frontend récupère la liste des structures puis appelle pour chacune **`/stock/structure/{id}/annee/{anneeId}`**.
- **Entrepôt BM** : à définir avec le métier (entrepôt global, autre périmètre) ; possiblement un endpoint dédié ou agrégation côté front.
- **Mouvements** : aujourd’hui **aucun endpoint dédié** dans le StockController ; soit exposer une API « mouvements pour une structure / période » (MouvementController ou nouveau), soit réutiliser un existant s’il y en a un.

### 2.6 Modals

- **Détails du stock** : afficher une ligne détaillée (structure, matière, niveau, année, quantités, estEnRupture, aRetoursAnneePrecedente) à partir des données déjà chargées ou d’un appel **`/stock/disponible`**.
- **Nouveau Mouvement** : dépend du workflow métier (création de mouvement = probablement **MouvementController** ou service métier existant, pas uniquement Stock).
- **Rapport Stock** : utiliser **`GET /stock/resume/...`** + éventuellement **`/stock/structure/...`** et **`/stock/rupture/...`** pour générer un rapport (affichage + export PDF/Excel si requis).

### 2.7 Recalcul (admin)

- Si besoin d’exposer le recalcul pour une année : bouton « Recalculer stock » (réservé admin) appelant **`POST /stock/recalculer/{anneeScolaireId}`**.

---

## 3. Comment adapter

- **Un seul service cohérent** : faire de **`stock.service.ts`** la seule façade frontend pour tout ce qui est « consultation / analyse stock », en s’appuyant sur les endpoints **`/stock/*`** et en reflétant le DTO backend (ou un type TS dérivé).
- **Réutiliser** la logique déjà utilisée dans **`mouvement.service`** pour `/stock/disponible` et `/stock/structure/.../annee/...` (gestion de `item` vs `items`, `hasError`) pour éviter la duplication et les incohérences.
- **Page Stocks** : 
  - Récupérer **anneeScolaireId** (année courante ou sélecteur).
  - Appeler **`stockService`** avec `user.structure.id` + `anneeScolaireId`.
  - Afficher les tableaux et indicateurs à partir des listes retournées ; ajouter une section/onglet « Ruptures » et « Résumé ».
- **Rôles / structures** : pour IEPP, afficher les stocks des EPP sous l’IEPP (si le backend le permet ou après ajout d’un endpoint). Pour DIRECTEUR EPP, afficher le stock de son EPP uniquement.

---

## 4. Ce qui bloque actuellement

### 4.1 Blocage principal : mauvais endpoint dans `stock.service.ts`

- **Problème** : `stock.service.ts` utilise **`/distributionEleve/getStock/${structureId}/1`** (et boucle sur les matières avec ce schéma) au lieu des endpoints **`/stock/*`**.
- **Conséquences** :  
  - Les données de la page Stocks ne sont pas celles du module Stock (structure, matière, niveau, année, ruptures, retours N-1).  
  - La vue d’ensemble et l’« analyse » ne reflètent pas le modèle métier stock (StockDisponible).
- **Solution** : basculer **tous** les appels de `stock.service.ts` vers **`/stock/structure/.../annee/...`**, **`/stock/disponible`**, **`/stock/rupture/...`**, **`/stock/resume/...`**, et adapter les types et le parsing (`item` / `items`).

### 4.2 Année scolaire non gérée

- Les endpoints **`/stock/*`** exigent une **anneeScolaireId** (ou utilisent l’année courante côté backend pour `/stock/disponible`).
- La page Stocks **ne transmet pas** d’année ; sans cela, les appels vers **`/stock/structure/.../annee/...`** et les autres ne peuvent pas être utilisés correctement.
- **Blocant** tant qu’un sélecteur d’année (ou année courante) n’est pas branché sur les appels du `stock.service`.

### 4.3 Inadéquation des types / réponses

- **StockData** dans `stock.service.ts` (structureLibelle, matiereCode, stockDisponible, statut OK/CRITIQUE/EPUISE) ne correspond pas au **StockDisponibleDto** (quantiteDisponible, quantiteReceptions, quantiteDistributions, estEnRupture, etc.).
- Le backend renvoie **`item`** pour un seul élément ; le service doit lire **`response.item`** pour **`/stock/disponible`** et **`response.items`** pour les listes.
- **Bloquant** si on garde l’ancien contrat : la page affichera des champs vides ou incorrects. Il faut aligner les types et le mapping sur le DTO backend.

### 4.4 Endpoints manquants ou à clarifier

- **Mouvements** : pas d’endpoint « liste des mouvements pour une structure » dans le StockController ; à ajouter côté backend ou à mapper depuis un autre module (ex. MouvementController).
- **Stocks par structure hiérarchique** (liste des EPP d’un IEPP, stock par EPP) : à confirmer si un endpoint existe (ex. liste des structures + appels multiples) ou à faire évoluer le backend.

### 4.5 Modals et rapports

- **Bloquant** uniquement pour la complétude fonctionnelle : modals et rapport restent à implémenter une fois les appels `/stock/*` et l’année en place ; pas bloquant pour afficher une première « analyse » (vue d’ensemble + ruptures + résumé).

---

## 5. Synthèse des actions prioritaires

| Priorité | Action | Impact |
|----------|--------|--------|
| 1 | Faire utiliser à `stock.service.ts` les vrais endpoints `/stock/*` (structure/annee, disponible, rupture, resume) | Données réelles et cohérentes pour l’analyse |
| 2 | Ajouter année scolaire (sélecteur ou courante) et la passer à tous les appels stock | Déblocage des appels et pertinence des données |
| 3 | Aligner les types frontend sur `StockDisponibleDto` et gérer `item` / `items` | Affichage correct et robuste |
| 4 | Implémenter la vue « Ruptures » (onglet ou section) avec `/stock/rupture/...` | Menu « Stock analyse » vraiment utile |
| 5 | Afficher le résumé avec `/stock/resume/...` | Analyse synthétique |
| 6 | Compléter modals (détail, mouvement, rapport) et onglets IEPP/EPP/Entrepôt/Mouvements | Finition du menu Stocks |

En résumé : **le menu Stock analyse est déjà en place en UI**, mais il est **bloqué** par l’usage du mauvais API (distribution au lieu de stock) et l’absence d’année scolaire. En branchant le **stock.service** sur les endpoints **`/stock/*`** et en gérant l’**année scolaire**, on débloque la fonctionnalité et on peut ensuite enrichir (ruptures, résumé, modals, autres onglets).
