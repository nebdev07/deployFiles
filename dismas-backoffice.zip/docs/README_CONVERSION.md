# 🎯 GUIDE DE CONVERSION DISMAS

## 📋 **RÉSUMÉ RAPIDE**

Pour convertir votre présentation DISMAS en PowerPoint ou PDF, utilisez l'une de ces méthodes :

### **🚀 Méthode Rapide (Windows)**
```powershell
# Exécuter le script PowerShell
.\convert_dismas.ps1

# Ou spécifier un format
.\convert_dismas.ps1 -Format pptx
.\convert_dismas.ps1 -Format pdf
.\convert_dismas.ps1 -Format all
```

### **🐧 Méthode Rapide (Linux/macOS)**
```bash
# Rendre le script exécutable (Linux/macOS)
chmod +x convert_dismas.sh

# Exécuter le script
./convert_dismas.sh

# Ou spécifier un format
./convert_dismas.sh pptx
./convert_dismas.sh pdf
./convert_dismas.sh all
```

### **🔧 Méthode Manuelle**
```bash
# Installation Pandoc
# Windows
choco install pandoc

# macOS
brew install pandoc

# Linux
sudo apt-get install pandoc

# Conversion
pandoc PRESENTATION_TEMPLATE_PROFESSIONNEL.md -o DISMAS_Presentation.pptx
pandoc PRESENTATION_TEMPLATE_PROFESSIONNEL.md -o DISMAS_Presentation.pdf
```

---

## 📁 **FICHIERS DISPONIBLES**

| **Fichier** | **Description** | **Usage** |
|-------------|----------------|-----------|
| `PRESENTATION_TEMPLATE_PROFESSIONNEL.md` | Présentation complète | Source principale |
| `convert_dismas.ps1` | Script Windows | Conversion automatique |
| `convert_dismas.sh` | Script Linux/macOS | Conversion automatique |
| `CONVERSION_GUIDE.md` | Guide détaillé | Instructions complètes |

---

## 🎯 **FORMATS SUPPORTÉS**

### **PowerPoint (.pptx)**
- ✅ **Qualité** : Excellente
- ✅ **Facilité** : Très facile
- ✅ **Usage** : Présentation client
- ✅ **Avantages** : Animations, transitions, notes

### **PDF (.pdf)**
- ✅ **Qualité** : Excellente
- ✅ **Facilité** : Facile
- ✅ **Usage** : Documentation, partage
- ✅ **Avantages** : Universel, impression

### **HTML (.html)**
- ✅ **Qualité** : Bonne
- ✅ **Facilité** : Très facile
- ✅ **Usage** : Web, email
- ✅ **Avantages** : Responsive, interactif

---

## 🚀 **INSTRUCTIONS DÉTAILLÉES**

### **1. Prérequis**

#### **Windows**
```powershell
# Installer Chocolatey (si pas déjà installé)
Set-ExecutionPolicy Bypass -Scope Process -Force; [System.Net.ServicePointManager]::SecurityProtocol = [System.Net.ServicePointManager]::SecurityProtocol -bor 3072; iex ((New-Object System.Net.WebClient).DownloadString('https://community.chocolatey.org/install.ps1'))

# Installer Pandoc
choco install pandoc -y
```

#### **macOS**
```bash
# Installer Homebrew (si pas déjà installé)
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"

# Installer Pandoc
brew install pandoc
```

#### **Linux**
```bash
# Ubuntu/Debian
sudo apt-get update && sudo apt-get install pandoc

# CentOS/RHEL
sudo yum install pandoc

# Fedora
sudo dnf install pandoc
```

### **2. Conversion Automatique**

#### **Windows PowerShell**
```powershell
# Conversion en tous formats
.\convert_dismas.ps1

# Conversion spécifique
.\convert_dismas.ps1 -Format pptx
.\convert_dismas.ps1 -Format pdf
.\convert_dismas.ps1 -Format html

# Avec paramètres personnalisés
.\convert_dismas.ps1 -Format pptx -InputFile "ma_presentation.md" -OutputPrefix "DISMAS_Client"
```

#### **Linux/macOS Bash**
```bash
# Rendre exécutable
chmod +x convert_dismas.sh

# Conversion en tous formats
./convert_dismas.sh

# Conversion spécifique
./convert_dismas.sh pptx
./convert_dismas.sh pdf
./convert_dismas.sh html

# Avec paramètres personnalisés
./convert_dismas.sh pptx "ma_presentation.md" "DISMAS_Client"
```

### **3. Conversion Manuelle**

#### **PowerPoint**
```bash
# Conversion basique
pandoc PRESENTATION_TEMPLATE_PROFESSIONNEL.md -o DISMAS_Presentation.pptx --slide-level=2

# Avec template personnalisé
pandoc PRESENTATION_TEMPLATE_PROFESSIONNEL.md -o DISMAS_Presentation.pptx --slide-level=2 --reference-doc=template.pptx
```

#### **PDF**
```bash
# Avec LaTeX (meilleure qualité)
pandoc PRESENTATION_TEMPLATE_PROFESSIONNEL.md -o DISMAS_Presentation.pdf --pdf-engine=xelatex

# Avec wkhtmltopdf
pandoc PRESENTATION_TEMPLATE_PROFESSIONNEL.md -o DISMAS_Presentation.pdf --pdf-engine=wkhtmltopdf

# Avec table des matières
pandoc PRESENTATION_TEMPLATE_PROFESSIONNEL.md -o DISMAS_Presentation.pdf --pdf-engine=xelatex --toc
```

#### **HTML**
```bash
# HTML basique
pandoc PRESENTATION_TEMPLATE_PROFESSIONNEL.md -o DISMAS_Presentation.html --standalone

# HTML avec CSS personnalisé
pandoc PRESENTATION_TEMPLATE_PROFESSIONNEL.md -o DISMAS_Presentation.html --standalone --css=style.css
```

---

## 🎨 **PERSONNALISATION**

### **Template PowerPoint Personnalisé**

1. **Créer un template PowerPoint**
   - Ouvrir PowerPoint
   - Créer un design avec les couleurs DISMAS :
     - 🟠 Orange : #FF6B35
     - 🟢 Vert : #4ECDC4
     - 🔵 Bleu : #45B7D1
     - ⚪ Blanc : #FFFFFF
   - Sauvegarder comme `dismas_template.pptx`

2. **Utiliser le template**
   ```bash
   pandoc PRESENTATION_TEMPLATE_PROFESSIONNEL.md -o DISMAS_Presentation.pptx --slide-level=2 --reference-doc=dismas_template.pptx
   ```

### **CSS Personnalisé pour HTML**

Créer un fichier `style.css` :
```css
body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background: linear-gradient(135deg, #FF6B35, #4ECDC4);
    color: #333;
}

h1, h2, h3 {
    color: #FF6B35;
}

.table {
    border-collapse: collapse;
    width: 100%;
}

.table th, .table td {
    border: 1px solid #ddd;
    padding: 8px;
    text-align: left;
}

.table th {
    background-color: #FF6B35;
    color: white;
}
```

---

## 🔧 **DÉPANNAGE**

### **Erreurs Courantes**

#### **"Pandoc n'est pas reconnu"**
```bash
# Vérifier l'installation
pandoc --version

# Réinstaller si nécessaire
# Windows
choco uninstall pandoc -y && choco install pandoc -y

# macOS
brew uninstall pandoc && brew install pandoc

# Linux
sudo apt-get remove pandoc && sudo apt-get install pandoc
```

#### **Erreur LaTeX pour PDF**
```bash
# Installer LaTeX
# Windows
choco install miktex

# macOS
brew install --cask mactex

# Linux
sudo apt-get install texlive-full
```

#### **Erreur wkhtmltopdf**
```bash
# Installer wkhtmltopdf
# Windows
choco install wkhtmltopdf

# macOS
brew install wkhtmltopdf

# Linux
sudo apt-get install wkhtmltopdf
```

#### **Images non affichées**
- Vérifier que les URLs des images sont accessibles
- Remplacer les placeholders par de vraies images
- Utiliser des chemins relatifs pour les images locales

### **Solutions Alternatives**

#### **Méthode en Ligne**
1. Aller sur [stackedit.io](https://stackedit.io)
2. Coller le contenu Markdown
3. Exporter en PDF ou HTML

#### **Applications Desktop**
- **Typora** : Export direct en plusieurs formats
- **MarkText** : Interface graphique pour Pandoc
- **Obsidian** : Export en PDF avec plugins

---

## 📊 **RÉSULTATS ATTENDUS**

Après conversion réussie, vous aurez :

### **Fichiers Créés**
- ✅ `DISMAS_Presentation.pptx` - Présentation PowerPoint
- ✅ `DISMAS_Presentation.pdf` - Document PDF
- ✅ `DISMAS_Presentation.html` - Version web

### **Caractéristiques**
- 🎨 **Design professionnel** avec couleurs DISMAS
- 📊 **Tableaux formatés** et lisibles
- 🖼️ **Images et diagrammes** intégrés
- 📋 **Structure claire** avec sections
- 📱 **Responsive** (HTML)

---

## 🎉 **VALIDATION**

### **Vérifications à Faire**
1. ✅ **PowerPoint** : Vérifier les slides et la mise en page
2. ✅ **PDF** : Contrôler la qualité d'impression
3. ✅ **HTML** : Tester sur différents navigateurs
4. ✅ **Contenu** : Vérifier que tout le contenu est présent
5. ✅ **Images** : S'assurer que les images s'affichent

### **Tests Recommandés**
- 📱 **Mobile** : Tester sur smartphone/tablette
- 🖥️ **Desktop** : Vérifier sur différents écrans
- 🖨️ **Impression** : Tester l'impression PDF
- 📧 **Email** : Envoyer par email pour test

---

## 🚀 **PROCHAINES ÉTAPES**

1. ✅ **Convertir** la présentation
2. 🔍 **Vérifier** la qualité des fichiers
3. 📤 **Partager** avec l'équipe
4. 🎯 **Présenter** au client
5. 📝 **Collecter** les retours
6. 🔄 **Itérer** si nécessaire

---

**🎯 Votre présentation DISMAS est prête pour impressionner vos clients !** 🚀 