# 📊 ANALYSE DE L'ÉTAT DES LIEUX - VALIDATION IEPP

## 🎯 Objectif de l'Analyse
Analyser l'état actuel du système DISMAS pour identifier ce qui existe déjà et ce qui doit être mis à jour pour implémenter le flow complet de **validation IEPP des réceptions EPP**.

---

## 📋 FLOW MÉTIER RAPPEL

### **Flow Complet Implémenté**
```
1️⃣ LIBRAIRIE → IEPP (Réception IEPP)
   └─ Constitue le stock IEPP
   └─ Statut: VALIDEE
   └─ Type: IEPP

2️⃣ EPP → Saisie Réception (Demande)
   └─ EPP enregistre ses besoins
   └─ Statut: EN_ATTENTE (validation IEPP)
   └─ Type: EPP

3️⃣ IEPP → Validation Réception EPP ⚠️ À IMPLÉMENTER
   └─ IEPP valide la demande EPP
   └─ Statut: EN_ATTENTE → CONFIRMEE_IEPP
   └─ Déduction stock IEPP, crédit stock EPP

4️⃣ EPP → Distribution aux Élèves
   └─ Condition: Statut CONFIRMEE_IEPP
   └─ Distribution par classe
```

---

## ✅ CE QUI EXISTE DÉJÀ (Backend)

### **1. Table `mouvement`** ✅
```sql
CREATE TABLE mouvement (
  id INT AUTO_INCREMENT PRIMARY KEY,
  type_mouvement VARCHAR(50) NOT NULL,  -- 'IEPP' ou 'EPP'
  observation TEXT,
  numero_bordereau VARCHAR(100),
  date_mouvement DATE NOT NULL,
  id_structure INT NOT NULL,            -- Structure (IEPP ou EPP)
  statut VARCHAR(50) NOT NULL,          -- 'EN_ATTENTE', 'CONFIRMEE_IEPP', 'CONFIRMEE_EPP', 'ANNULEE'
  validated_by INT,                     -- ✅ Qui a validé
  validated_at TIMESTAMP,               -- ✅ Quand validé
  validation_level VARCHAR(20),         -- ✅ 'IEPP' ou 'EPP'
  created_at TIMESTAMP NOT NULL,
  created_by INT NOT NULL,
  is_deleted BOOLEAN DEFAULT FALSE,
  updated_at TIMESTAMP,
  updated_by INT,
  annee_scolaire_id INT,
  annee_stock_id INT,
  note_annee_stock VARCHAR(500)
);
```

**Statuts disponibles** :
- ✅ `EN_ATTENTE` : Réception EPP en attente de validation IEPP
- ✅ `CONFIRMEE_IEPP` : Validée par IEPP
- ✅ `CONFIRMEE_EPP` : Confirmée par EPP (réception physique)
- ✅ `ANNULEE` : Annulée
- ✅ `VALIDEE` : Réception IEPP directe (librairie)

### **2. Méthode `validateMouvement()`** ✅
**Fichier** : `MouvementBusiness.java` (lignes 788-850)

```java
public Response<MouvementDto> validateMouvement(
  Integer MouvementId, 
  String validationLevel,  // 'IEPP' ou 'EPP'
  Integer userId, 
  Locale locale
) {
  // 1. Récupère le mouvement
  // 2. Vérifie statut = EN_ATTENTE
  // 3. Change statut vers CONFIRMEE_IEPP ou CONFIRMEE_EPP
  // 4. Enregistre validated_by, validated_at, validation_level
  // 5. Sauvegarde dans l'historique
}
```

**Ce qui fonctionne** :
- ✅ Changement de statut (`EN_ATTENTE` → `CONFIRMEE_IEPP`)
- ✅ Enregistrement de l'utilisateur validateur
- ✅ Date de validation
- ✅ Historique de validation

**Ce qui manque** ⚠️ :
- ❌ Déduction du stock IEPP
- ❌ Crédit du stock EPP
- ❌ Création des MouvementStock

### **3. Endpoint `/mouvement/validate`** ✅
**Fichier** : `MouvementController.java` (lignes 151-163)

```java
@RequestMapping(value="/validate", method=RequestMethod.POST)
public Response<MouvementDto> validate(@RequestBody Request<MouvementDto> request) {
  MouvementDto dto = request.getData();
  Integer MouvementId = dto.getId();
  String validationLevel = dto.getValidationLevel();  // 'IEPP'
  Integer userId = request.getUser();
  
  return MouvementBusiness.validateMouvement(MouvementId, validationLevel, userId, locale);
}
```

**Utilisation** :
```json
POST /mouvement/validate
{
  "user": 4,
  "token": "...",
  "data": {
    "id": 123,
    "validationLevel": "IEPP"
  }
}
```

### **4. Table `mouvement_stock`** ✅
```sql
CREATE TABLE mouvement_stock (
  id INT AUTO_INCREMENT PRIMARY KEY,
  id_mouvement INT NOT NULL,
  id_matiere INT NOT NULL,
  id_niveau_scolaire INT NOT NULL,
  quantite INT NOT NULL,
  type_mouvement VARCHAR(50) NOT NULL,  -- 'ENTREE' ou 'SORTIE'
  id_structure INT NOT NULL,
  annee_scolaire_id INT NOT NULL,
  date_mouvement DATE NOT NULL,
  created_at TIMESTAMP,
  created_by INT,
  is_deleted BOOLEAN DEFAULT FALSE
);
```

### **5. Méthode `validateStockBeforeEPPMouvement()`** ✅
**Fichier** : `MouvementBusiness.java` (lignes 691-777)

- ✅ Vérifie le stock IEPP avant validation
- ✅ Récupère le stock disponible IEPP parent
- ✅ Compare avec les quantités demandées EPP
- ✅ Retourne erreur si stock insuffisant

---

## ❌ CE QUI MANQUE (À IMPLÉMENTER)

### **1. Gestion des Stocks lors de la Validation IEPP** ❌

**Dans `validateMouvement()`**, il manque :

```java
// APRÈS validation (ligne 826)
Mouvement = MouvementRepository.save(Mouvement);

// ❌ MANQUANT : Gestion des stocks
if ("IEPP".equals(validationLevel)) {
  // 1. Récupérer toutes les MatiereQuantite du mouvement
  List<MatiereQuantite> quantites = getMatiereQuantitesByMouvement(MouvementId);
  
  // 2. Pour chaque quantité validée
  for (MatiereQuantite quantite : quantites) {
    
    // 3. Créer MouvementStock SORTIE pour IEPP (déduction)
    createMouvementStock(
      MouvementId,
      quantite.getMatiere().getId(),
      quantite.getNiveauScolaire().getId(),
      quantite.getQuantiteRecue(),  // Quantité validée
      "SORTIE",                     // Sortie du stock IEPP
      idIEPP,                       // Structure IEPP
      anneeScolaireId,
      Mouvement.getDateMouvement()
    );
    
    // 4. Créer MouvementStock ENTREE pour EPP (crédit)
    createMouvementStock(
      MouvementId,
      quantite.getMatiere().getId(),
      quantite.getNiveauScolaire().getId(),
      quantite.getQuantiteRecue(),  // Quantité validée
      "ENTREE",                     // Entrée dans le stock EPP
      idEPP,                        // Structure EPP
      anneeScolaireId,
      Mouvement.getDateMouvement()
    );
  }
  
  // 5. Mettre à jour le statut des MatiereQuantite
  updateMatiereQuantiteStatut(quantites, "DISTRIBUE");
}
```

### **2. Endpoint pour Récupérer les Réceptions EPP en Attente** ❌

**Endpoint manquant** :
```java
@RequestMapping(value="/getReceptionsEnAttente", method=RequestMethod.POST)
public Response<MouvementDto> getReceptionsEnAttente(@RequestBody Request<MouvementDto> request) {
  // Récupérer les mouvements EPP en attente de validation IEPP
  // Filtrer par structure IEPP (parent des EPP)
}
```

**Critères de recherche** :
- `type_mouvement` = 'EPP'
- `statut` = 'EN_ATTENTE'
- `structure.parent_id` = idIEPP (IEPP parent des EPP)

### **3. Méthode pour Récupérer les MatiereQuantite d'un Mouvement** ❌

```java
private List<MatiereQuantite> getMatiereQuantitesByMouvement(Integer mouvementId) {
  // Récupérer CatalogueMouvement du mouvement
  List<CatalogueMouvement> catalogues = CatalogueMouvementRepository
    .findByIdMouvement(mouvementId);
  
  // Récupérer les MatiereQuantite de chaque catalogue
  List<MatiereQuantite> allQuantites = new ArrayList<>();
  for (CatalogueMouvement catalogue : catalogues) {
    List<MatiereQuantite> quantites = matiereQuantiteRepository
      .findByIdCatalogueMouvement(catalogue.getId());
    allQuantites.addAll(quantites);
  }
  
  return allQuantites;
}
```

### **4. Méthode pour Créer les MouvementStock** ❌

```java
private void createMouvementStock(
  Integer mouvementId,
  Integer matiereId,
  Integer niveauId,
  Integer quantite,
  String typeMouvement,  // 'ENTREE' ou 'SORTIE'
  Integer structureId,
  Integer anneeScolaireId,
  Date dateMouvement
) {
  MouvementStock mvtStock = new MouvementStock();
  mvtStock.setIdMouvement(mouvementId);
  mvtStock.setIdMatiere(matiereId);
  mvtStock.setIdNiveauScolaire(niveauId);
  mvtStock.setQuantite(quantite);
  mvtStock.setTypeMouvement(typeMouvement);
  mvtStock.setIdStructure(structureId);
  mvtStock.setAnneeScolaireId(anneeScolaireId);
  mvtStock.setDateMouvement(dateMouvement);
  mvtStock.setCreatedAt(new Date());
  mvtStock.setCreatedBy(userId);
  
  mouvementStockRepository.save(mvtStock);
}
```

---

## ❌ CE QUI MANQUE (Frontend)

### **1. Menu "Validation Distributions" pour IEPP** ❌

**Page manquante** : `/app/validation-distributions/page.tsx`

**Fonctionnalités nécessaires** :
- Liste des réceptions EPP en attente (`statut = EN_ATTENTE`)
- Détails de chaque réception (quantités, manuels, EPP)
- Bouton "Valider" pour chaque réception
- Vérification du stock IEPP avant validation
- Gestion des observations de validation

### **2. Interface de Validation** ❌

```tsx
interface ValidationIEPPProps {
  mouvement: MouvementData;
  onValidate: (mouvementId: number, observations?: string) => void;
  onReject: (mouvementId: number, motif: string) => void;
}

const ValidationIEPPModal = ({ mouvement, onValidate, onReject }: ValidationIEPPProps) => {
  // Afficher :
  // - Informations EPP (école, directeur)
  // - Détails des manuels demandés
  // - Stock IEPP disponible vs demandé
  // - Alertes si stock insuffisant
  // - Zone observations
  // - Boutons Valider / Rejeter
}
```

### **3. Service Frontend pour Validation** ❌

```typescript
// lib/services/validation.service.ts
class ValidationService {
  async validateReceptionEPP(mouvementId: number, observations?: string) {
    return await fetch('/mouvement/validate', {
      method: 'POST',
      body: JSON.stringify({
        user: userId,
        token: token,
        data: {
          id: mouvementId,
          validationLevel: 'IEPP',
          observation: observations
        }
      })
    });
  }
  
  async getReceptionsEnAttenteIEPP(ieppId: number) {
    return await fetch('/mouvement/getByCriteria', {
      method: 'POST',
      body: JSON.stringify({
        user: userId,
        token: token,
        data: {
          typeMouvement: 'EPP',
          statut: 'EN_ATTENTE',
          idStructureParent: ieppId  // EPP dont le parent est cet IEPP
        }
      })
    });
  }
}
```

### **4. Menu dans la Navigation** ❌

Dans `components/layout/sidebar.tsx` ou équivalent :

```tsx
{user.role.code === 'IEPP' && (
  <NavItem 
    href="/validation-distributions" 
    icon={CheckCircleIcon}
    label="Validation Distributions"
    badge={receptionsEnAttente.length}  // Badge avec nombre en attente
  />
)}
```

---

## 📊 ÉTAT ACTUEL DES MODULES

### **Module Réceptions** (`/app/receptions/page.tsx`)
**État** : ✅ Fonctionnel
**Rôles** : ADMIN, DAF, DRENA, IEPP, EPP
**Fonctionnalités** :
- ✅ Création réception IEPP (du librairie)
- ✅ Création réception EPP (demande)
- ✅ Liste des réceptions
- ✅ Upload documents (bordereau)
- ✅ Gestion des quantités par matière

**Ce qui manque** :
- ❌ Filtre par statut (`EN_ATTENTE`, `CONFIRMEE_IEPP`)
- ❌ Indicateur visuel "En attente validation"
- ❌ Bouton "Valider" pour IEPP

### **Module Distribution** (`/app/distribution/page.tsx`)
**État** : ✅ Fonctionnel (mais focus distribution élèves)
**Rôles** : DIRECTEUR, MAITRE, COGES
**Fonctionnalités** :
- ✅ Distribution aux élèves par classe
- ✅ Confirmation de distribution

**Utilisation actuelle** :
- Focus sur la distribution **aux élèves** (étape 4)
- Pas de gestion de la validation IEPP (étape 3)

**Proposition** :
- Option 1 : Créer un nouveau module `/validation-distributions` pour IEPP
- Option 2 : Étendre `/distribution` avec onglets selon le rôle

### **Module Stocks** (`/app/stocks/page.tsx`)
**État** : ❓ À vérifier
**Besoin** :
- Afficher le stock disponible IEPP
- Afficher le stock disponible EPP
- Historique des mouvements

---

## 🔧 ANALYSE TECHNIQUE DÉTAILLÉE

### **Backend - État Actuel**

#### **✅ Ce qui fonctionne**
1. **Création réception IEPP** (librairie → IEPP)
   - ✅ Endpoint `/mouvement/create`
   - ✅ Statut `VALIDEE` directement
   - ✅ Type `IEPP`

2. **Création réception EPP** (demande EPP)
   - ✅ Endpoint `/mouvement/create`
   - ✅ Statut `EN_ATTENTE`
   - ✅ Type `EPP`

3. **Validation du mouvement**
   - ✅ Endpoint `/mouvement/validate`
   - ✅ Changement de statut
   - ✅ Enregistrement validateur

4. **Vérification stock avant réception EPP**
   - ✅ Endpoint `/mouvement/validateStockBeforeEPP`
   - ✅ Vérifie stock IEPP disponible

#### **❌ Ce qui manque**
1. **Gestion des stocks lors de validation IEPP**
   ```java
   // Dans validateMouvement() après validation
   if ("IEPP".equals(validationLevel)) {
     // ❌ Créer MouvementStock SORTIE pour IEPP
     // ❌ Créer MouvementStock ENTREE pour EPP
     // ❌ Mettre à jour statut MatiereQuantite
   }
   ```

2. **Endpoint pour récupérer réceptions EPP en attente par IEPP**
   ```java
   // ❌ Manquant
   @RequestMapping(value="/getReceptionsEPPEnAttente", method=RequestMethod.POST)
   public Response<MouvementDto> getReceptionsEPPEnAttente(@RequestBody Request<MouvementDto> request)
   ```

3. **Méthode pour récupérer MatiereQuantite d'un mouvement**
   ```java
   // ❌ Manquant
   private List<MatiereQuantite> getMatiereQuantitesByMouvement(Integer mouvementId)
   ```

4. **Méthode pour créer MouvementStock**
   ```java
   // ❌ Manquant (ou existe mais pas appelée lors de validation)
   private void createMouvementStockFromValidation(...)
   ```

---

### **Frontend - État Actuel**

#### **✅ Ce qui existe**
1. **Module Réceptions** (`/app/receptions/page.tsx`)
   - ✅ Création réception IEPP
   - ✅ Création réception EPP
   - ✅ Liste des réceptions
   - ✅ Détails réceptions

2. **Module Distribution** (`/app/distribution/page.tsx`)
   - ✅ Distribution aux élèves
   - ✅ Confirmation EPP

3. **Service Reception** (`lib/services/reception.service.ts`)
   - ✅ `createReception()`
   - ✅ `getReceptions()`
   - ✅ `createMatiereQuantite()` ✅ CORRIGÉ (sans idNiveauScolaire)

#### **❌ Ce qui manque**
1. **Module "Validation Distributions"** pour IEPP
   - ❌ Page `/app/validation-distributions/page.tsx`
   - ❌ Composant `ValidationIEPPModal`
   - ❌ Service `validation.service.ts`

2. **Dans le module Réceptions**
   - ❌ Onglet "En Attente Validation" (pour IEPP)
   - ❌ Bouton "Valider Distribution" (pour IEPP)
   - ❌ Indicateur visuel statut `EN_ATTENTE`

3. **Dans le module Distribution**
   - ❌ Condition d'affichage si `statut !== CONFIRMEE_IEPP`
   - ❌ Message "En attente validation IEPP"

---

## 🎯 RECOMMANDATIONS D'IMPLÉMENTATION

### **Approche 1 : Extension du Module Réceptions** (Recommandé)
**Avantages** :
- ✅ Tout centralisé dans Réceptions
- ✅ Moins de code à écrire
- ✅ Interface cohérente

**Modifications** :
1. Ajouter onglets dans `/app/receptions/page.tsx` :
   - `Toutes` | `En Attente Validation` | `Validées` | `Annulées`
2. Filtrer par statut selon l'onglet
3. Afficher bouton "Valider" si :
   - `user.role.code === 'IEPP'`
   - `mouvement.statut === 'EN_ATTENTE'`
   - `mouvement.typeMouvement === 'EPP'`

### **Approche 2 : Nouveau Module Validation**
**Avantages** :
- ✅ Séparation des responsabilités
- ✅ Interface dédiée IEPP
- ✅ Plus clair pour l'utilisateur

**Modifications** :
1. Créer `/app/validation-distributions/page.tsx`
2. Créer service `validation.service.ts`
3. Ajouter dans la navigation IEPP

---

## 📋 CHECKLIST D'IMPLÉMENTATION

### **Backend** ✅❌

- [x] Table `mouvement` avec champs validation
- [x] Endpoint `/mouvement/validate`
- [x] Méthode `validateMouvement()`
- [x] Endpoint `/mouvement/validateStockBeforeEPP`
- [ ] **Gestion stocks dans `validateMouvement()`** ⚠️ PRIORITÉ 1
- [ ] **Méthode `getMatiereQuantitesByMouvement()`** ⚠️ PRIORITÉ 2
- [ ] **Méthode `createMouvementStockFromValidation()`** ⚠️ PRIORITÉ 2
- [ ] **Endpoint `/mouvement/getReceptionsEPPEnAttente`** ⚠️ PRIORITÉ 3

### **Frontend** ✅❌

- [x] Module Réceptions fonctionnel
- [x] Service Reception avec méthodes CRUD
- [x] Correction `createMatiereQuantite()` sans idNiveauScolaire
- [ ] **Onglets filtres par statut dans Réceptions** ⚠️ PRIORITÉ 1
- [ ] **Bouton "Valider Distribution" pour IEPP** ⚠️ PRIORITÉ 1
- [ ] **Modal de validation avec détails** ⚠️ PRIORITÉ 2
- [ ] **Service `validateReception()`** ⚠️ PRIORITÉ 2
- [ ] **Condition blocage distribution si pas CONFIRMEE_IEPP** ⚠️ PRIORITÉ 3
- [ ] **Indicateurs visuels statuts** ⚠️ PRIORITÉ 3

---

## 🔍 POINTS D'ATTENTION

### **1. Stock IEPP Parent**
- Le backend a déjà la logique pour trouver l'IEPP parent d'une EPP
- Méthode : `getIEPPParentId(Integer structureEPPId)`
- ✅ Utilisée dans `validateStockBeforeEPPMouvement()`

### **2. Année Scolaire**
- Les stocks sont gérés par année scolaire
- ✅ Champ `annee_scolaire_id` dans `mouvement`
- ✅ Champ `annee_stock_id` pour gérer les retours année N+1

### **3. Type Mouvement vs Type Reception**
- `type_mouvement` : 'IEPP' (réception librairie) ou 'EPP' (réception/demande EPP)
- Ne pas confondre avec `type_operation` dans `mouvement_stock` ('ENTREE', 'SORTIE')

### **4. Statuts**
- `EN_ATTENTE` : Réception EPP en attente validation IEPP
- `CONFIRMEE_IEPP` : Validée par IEPP → Distribution autorisée
- `CONFIRMEE_EPP` : Confirmée par EPP (réception physique)
- `VALIDEE` : Réception IEPP directe (librairie)
- `ANNULEE` : Annulée

---

## 🚀 PLAN D'ACTION RECOMMANDÉ

### **Phase 1 : Backend (Priorité Haute)** ⚠️
1. ✅ **Compléter `validateMouvement()`** avec gestion stocks
   - Ajouter création MouvementStock SORTIE (IEPP)
   - Ajouter création MouvementStock ENTREE (EPP)
   - Mettre à jour statut MatiereQuantite

2. ✅ **Créer méthodes utilitaires**
   - `getMatiereQuantitesByMouvement()`
   - `createMouvementStockFromValidation()`

3. ⚠️ **Endpoint optionnel** (peut utiliser `/getByCriteria` avec filtres)
   - `/mouvement/getReceptionsEPPEnAttente`

### **Phase 2 : Frontend (Priorité Moyenne)** ⚠️
1. ✅ **Étendre module Réceptions**
   - Ajouter onglets filtres par statut
   - Ajouter bouton "Valider" pour IEPP
   - Modal de validation avec détails

2. ✅ **Service de validation**
   - Méthode `validateReception()`
   - Méthode `getReceptionsEnAttente()`

3. ⚠️ **Blocage distribution élèves**
   - Vérifier `statut === 'CONFIRMEE_IEPP'`
   - Message si pas validé

### **Phase 3 : Tests et Validation (Priorité Basse)**
1. Tests unitaires backend
2. Tests d'intégration
3. Tests utilisateurs IEPP

---

## 📌 CONCLUSION

### **État Actuel : 60% Implémenté** ✅
- ✅ Structure de données complète
- ✅ Endpoints de base existants
- ✅ Création réceptions IEPP et EPP
- ✅ Vérification stock avant réception EPP

### **Manquant : 40%** ❌
- ❌ **Backend** : Gestion stocks lors validation (15%)
- ❌ **Frontend** : Interface validation IEPP (20%)
- ❌ **Frontend** : Blocage distribution si pas validé (5%)

### **Effort Estimé** :
- **Backend** : 4-6 heures (gestion stocks + méthodes utilitaires)
- **Frontend** : 6-8 heures (interface + service + tests)
- **Total** : 10-14 heures de développement

### **Priorisation** :
1. 🔴 **URGENT** : Backend - Gestion stocks dans `validateMouvement()`
2. 🟡 **IMPORTANT** : Frontend - Interface validation pour IEPP
3. 🟢 **SOUHAITABLE** : Blocage distribution élèves si pas validé

---

**Document d'analyse créé le : 13/10/2025**  
**Statut : Prêt pour implémentation**  
**Prochaine étape : Validation de l'analyse avec l'équipe technique**

