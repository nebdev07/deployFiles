# 🔄 GUIDE DE MIGRATION DES ENDPOINTS

## 📋 **CHANGEMENTS BACKEND → FRONTEND**

L'architecture backend a été refactorée pour unifier la gestion des mouvements (Réceptions, Distributions, Retours) dans une seule table et API.

---

## ✅ **NOUVEAUX ENDPOINTS**

### Ancien vs Nouveau

| Ancien Endpoint | Nouveau Endpoint | Type Mouvement |
|-----------------|------------------|----------------|
| `/reception/create` | `/mouvement/create` | `RECEPTION_IEPP` ou `RECEPTION_EPP` |
| `/reception/createWithStock` | `/mouvement/createWithStock` | `RECEPTION_IEPP` ou `RECEPTION_EPP` |
| `/reception/validate` | `/mouvement/validate` | Tous types |
| `/reception/getByCriteria` | `/mouvement/getByCriteria` | Tous types |
| `/reception/getWithDetails/{id}` | `/mouvement/getWithDetails/{id}` | Tous types |
| `/distributionEleve/create` | `/mouvement/create` | `DISTRIBUTION_CLASSES` |
| *(nouveau)* | `/mouvement/create` | `RETOUR_CLASSES` |
| *(nouveau)* | `/mouvement/annuler` | Annulation |

---

## 📦 **NOUVEAU SERVICE FRONTEND**

### `mouvement.service.ts`

Remplace `reception.service.ts` avec une architecture unifiée.

#### Import
```typescript
import { mouvementService } from '@/lib/services/mouvement.service';
```

#### Méthodes Principales

```typescript
// 1. Créer une réception IEPP
const result = await mouvementService.createMouvement({
  typeMouvement: 'RECEPTION_IEPP',
  numeroBordereau: 'BL-2024-001',
  dateMouvement: '09/10/2024',
  idStructure: 10,
  anneeScolaireId: 1,
  observation: 'Réception du premier lot',
  catalogues: [
    {
      idCatalogue: 5,
      matieres: [
        { idMatiere: 100, quantitePrevue: 100, quantiteRecue: 95 }
      ]
    }
  ]
});

// 2. Créer avec gestion automatique des stocks
const result = await mouvementService.createMouvementWithStock({ /* ... */ });

// 3. Valider une réception
const result = await mouvementService.validateMouvement(1, 'IEPP');

// 4. Récupérer avec détails
const result = await mouvementService.getMouvementWithDetails(1);

// 5. Rechercher par critères
const result = await mouvementService.getMouvementsByCriteria({
  typeMouvement: 'RECEPTION_EPP',
  statut: 'EN_ATTENTE',
  anneeScolaireId: 1
});

// 6. Annuler un mouvement
const result = await mouvementService.annulerMouvement(1, 'Erreur de saisie');

// 7. Vérifier stock disponible
const result = await mouvementService.getStockDisponible(10, 100, 1, 1);

// 8. Vérifier avant distribution
const result = await mouvementService.verifierStock(10, 100, 1, 1, 50);
```

---

## 🔧 **MODIFICATIONS À APPORTER**

### 1. Remplacer les imports

**Avant:**
```typescript
import { receptionService } from '@/lib/services/reception.service';
```

**Après:**
```typescript
import { mouvementService } from '@/lib/services/mouvement.service';
```

---

### 2. Mettre à jour les appels

#### Création d'une réception

**Avant:**
```typescript
const result = await receptionService.createReception({
  typeReception: 'IEPP',
  numeroBordereau: 'BL-001',
  dateReception: '09/10/2024',
  idStructure: 10,
  catalogues: [...]
});
```

**Après:**
```typescript
const result = await mouvementService.createMouvement({
  typeMouvement: 'RECEPTION_IEPP',  // ✅ Changé
  numeroBordereau: 'BL-001',
  dateMouvement: '09/10/2024',      // ✅ Changé
  idStructure: 10,
  anneeScolaireId: 1,               // ✅ Ajouté
  catalogues: [...]
});
```

#### Validation

**Avant:**
```typescript
await receptionService.validateReception(receptionId, 'IEPP');
```

**Après:**
```typescript
await mouvementService.validateMouvement(receptionId, 'IEPP');
```

---

### 3. Mettre à jour les types

**Avant:**
```typescript
typeReception: 'IEPP' | 'EPP'
dateReception: string
```

**Après:**
```typescript
typeMouvement: 'RECEPTION_IEPP' | 'RECEPTION_EPP' | 'DISTRIBUTION_CLASSES' | 'RETOUR_CLASSES'
dateMouvement: string
anneeScolaireId: number  // Nouveau champ obligatoire
```

---

### 4. Gérer les nouveaux champs de réponse

**Nouveaux champs dans `MouvementResponse`:**
```typescript
{
  // Existants
  id: number;
  typeMouvement: string;
  numeroBordereau: string;
  dateMouvement: string;
  statut: string;
  
  // Nouveaux ✅
  anneeScolaireId: number;
  anneeScolaireLibelle?: string;
  anneeStockId?: number;           // Année de comptabilisation
  anneeStockLibelle?: string;
  noteAnneeStock?: string;         // Si retour N→N+1
}
```

---

## 📝 **FICHIERS À MODIFIER**

### Pages principales

1. **`app/receptions/page.tsx`** (PRIORITÉ 1)
   - Ligne 1595: `createReception` → `createMouvement`
   - Import: `reception.service.ts` → `mouvement.service.ts`
   - Types: `typeReception` → `typeMouvement`
   - Champs: `dateReception` → `dateMouvement`
   - Ajouter: `anneeScolaireId`

2. **`app/distributions/page.tsx`** (si existe)
   - Utiliser `mouvementService.createMouvement()` avec `typeMouvement: 'DISTRIBUTION_CLASSES'`

3. **`app/retours/page.tsx`** (si existe)
   - Utiliser `mouvementService.createMouvement()` avec `typeMouvement: 'RETOUR_CLASSES'`

---

## ⚡ **MIGRATION RAPIDE - EXEMPLE COMPLET**

### Fichier: `app/receptions/page.tsx`

#### Étape 1: Import
```typescript
// ❌ Ancien
import { receptionService, ReceptionData } from '@/lib/services/reception.service';

// ✅ Nouveau
import { mouvementService, MouvementData } from '@/lib/services/mouvement.service';
```

#### Étape 2: Types d'état
```typescript
// ❌ Ancien
const [formData, setFormData] = useState<Partial<ReceptionData>>({
  typeReception: 'EPP',
  dateReception: formatDate(new Date()),
  numeroBordereau: '',
  idStructure: userStructureId,
  catalogues: []
});

// ✅ Nouveau
const [formData, setFormData] = useState<Partial<MouvementData>>({
  typeMouvement: 'RECEPTION_EPP',           // ✅
  dateMouvement: formatDate(new Date()),    // ✅
  numeroBordereau: '',
  idStructure: userStructureId,
  anneeScolaireId: currentAnneeScolaireId,  // ✅ Ajouter
  catalogues: []
});
```

#### Étape 3: Fonction de création
```typescript
// ❌ Ancien
const handleCreateReception = async () => {
  const result = await receptionService.createReception(formData);
  // ...
};

// ✅ Nouveau
const handleCreateReception = async () => {
  const result = await mouvementService.createMouvement(formData);
  // ...
};
```

#### Étape 4: Validation
```typescript
// ❌ Ancien
await receptionService.validateReception(reception.id, 'EPP');

// ✅ Nouveau
await mouvementService.validateMouvement(reception.id, 'EPP');
```

---

## 🎯 **NOUVEAUX TYPES MOUVEMENT**

```typescript
enum TypeMouvement {
  RECEPTION_IEPP = 'RECEPTION_IEPP',           // Réception par IEPP
  RECEPTION_EPP = 'RECEPTION_EPP',             // Réception par EPP
  DISTRIBUTION_CLASSES = 'DISTRIBUTION_CLASSES', // Distribution aux classes
  RETOUR_CLASSES = 'RETOUR_CLASSES'            // Retours des classes
}
```

---

## 📊 **GESTION DES STOCKS**

### Endpoints stocks (inchangés mais centralisés)

```typescript
// Stock disponible
GET /stock/disponible?structureId=10&matiereId=100&niveauId=1&anneeScolaireId=1

// Tous les stocks d'une structure
GET /stock/structure/{structureId}/annee/{anneeScolaireId}

// Stocks en rupture
GET /stock/rupture/structure/{structureId}/annee/{anneeScolaireId}

// Retours année précédente
GET /stock/retours-annee-precedente/{anneeScolaireId}

// Résumé stock
GET /stock/resume/structure/{structureId}/annee/{anneeScolaireId}

// Recalculer stock
POST /stock/recalculer/{anneeScolaireId}

// Vérifier disponibilité
POST /stock/verifier
```

---

## ✅ **CHECKLIST MIGRATION**

- [ ] Créer `mouvement.service.ts`
- [ ] Modifier `app/receptions/page.tsx`
  - [ ] Remplacer imports
  - [ ] Changer `typeReception` → `typeMouvement`
  - [ ] Changer `dateReception` → `dateMouvement`
  - [ ] Ajouter `anneeScolaireId`
  - [ ] Remplacer `createReception()` → `createMouvement()`
  - [ ] Remplacer `validateReception()` → `validateMouvement()`
- [ ] Modifier `app/distributions/page.tsx` (si existe)
- [ ] Modifier `app/retours/page.tsx` (si existe)
- [ ] Tester création réception IEPP
- [ ] Tester création réception EPP
- [ ] Tester validation
- [ ] Tester consultation stocks
- [ ] **(Optionnel)** Supprimer `reception.service.ts` après migration complète

---

## 🚨 **POINTS D'ATTENTION**

### 1. Année scolaire obligatoire
Tous les mouvements nécessitent maintenant `anneeScolaireId`. Assurez-vous de:
- Récupérer l'année courante au chargement
- L'inclure dans tous les formulaires
- La passer dans toutes les requêtes

### 2. Type mouvement spécifique
Ne pas utiliser `'IEPP'` ou `'EPP'` seuls, mais:
- `'RECEPTION_IEPP'`
- `'RECEPTION_EPP'`
- `'DISTRIBUTION_CLASSES'`
- `'RETOUR_CLASSES'`

### 3. Champs renommés
- `dateReception` → `dateMouvement`
- `typeReception` → `typeMouvement`
- `idReception` → `id` (standard)

### 4. Gestion automatique année stock
Pour les retours, le backend calcule automatiquement:
- `anneeStock = annee N+1` si type = `RETOUR_CLASSES`
- Champ `noteAnneeStock` rempli automatiquement

---

## 📞 **SUPPORT**

En cas de problème:
1. Vérifier les logs backend pour les erreurs API
2. Vérifier la console navigateur pour les erreurs réseau
3. Confirmer que `anneeScolaireId` est bien passé
4. Vérifier le format des dates (DD/MM/YYYY)

---

**Date:** 2025-10-09  
**Version:** 1.0  
**Statut:** ✅ Prêt pour migration

