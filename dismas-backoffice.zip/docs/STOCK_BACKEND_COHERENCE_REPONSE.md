# Le backend peut-il répondre aux données demandées par la page Stock ?

## Réponse courte : **Oui**, pour l’essentiel.

Le backend **StockController** + **StockDisponibleDto** fournissent déjà les données nécessaires pour alimenter la page Stocks de façon cohérente. Il faut :

1. Appeler les **bons endpoints** (`/stock/*` au lieu de `/distributionEleve/getStock/...`).
2. Passer l’**année scolaire** (`anneeScolaireId`) à chaque appel.
3. Faire un **mapping léger** côté front (noms de champs + dérivation du statut).

---

## Ce que la page Stock demande aujourd’hui

D’après `app/stocks/page.tsx` et `lib/services/stock.service.ts` :

| Besoin page | Type frontend | Champs utilisés |
|-------------|----------------|------------------|
| En-tête structure | `StockByStructure` | `structureId`, `structureLibelle`, `structureCode`, `stockTotal`, `derniereMiseAJour`, `statutGlobal` |
| Liste par matière | `StockData[]` (allStocks) | `structureId`, `structureLibelle`, `structureCode`, `matiereId`, `matiereCode`, `matiereLibelle`, `stockDisponible`, `stockReception`, `stockDistribution`, `statut` (OK/CRITIQUE/EPUISE) |
| Stats vue d’ensemble | dérivées | Total stock, nombre matières critiques, nombre matières épuisées |

---

## Ce que le backend renvoie (StockDisponibleDto)

Après **StockDisponibleTransformer** (toDto + enrichDto), chaque élément contient :

| Champ backend | Présent | Remarque |
|---------------|--------|-----------|
| `structureId`, `structureCode`, `structureLibelle`, `structureType` | Oui | Remplis par le transformer depuis l’entité |
| `matiereId`, `matiereCode`, `matiereLibelle` | Oui | Idem |
| `niveauId`, `niveauCode`, `niveauLibelle` | Oui | Idem (peut être null selon le cas) |
| `anneeScolaireId`, `anneeScolaireCode`, `anneeScolaireLibelle` | Oui | Idem |
| `quantiteDisponible` | Oui | |
| `quantiteReceptions`, `quantiteDistributions`, `quantiteRetours`, `quantiteRetoursAnneePrecedente` | Oui | |
| `estEnRupture` | Oui | Enrichi (true si quantiteDisponible <= 0) |
| `aRetoursAnneePrecedente` | Oui | Enrichi |
| `detailStock` | Oui | Message formaté (entité) |
| `updatedAt` | Oui | Dernière MAJ |

Donc les **données cohérentes nécessaires** (structure, matière, niveau, année, quantités, indicateurs) sont bien disponibles côté backend.

---

## Correspondance Backend → Page Stock

### 1) Une seule requête pour tout remplir

- **Appel** : `GET /stock/structure/{structureId}/annee/{anneeScolaireId}`
- **Réponse** : `response.items` = liste de `StockDisponibleDto` (une ligne par combinaison structure / matière / niveau / année).

La page n’a pas besoin de deux appels (getStockByStructure + getAllStocksByStructure). Un seul appel suffit.

### 2) Construire `StockByStructure` à partir de `items`

- `structureId`, `structureLibelle`, `structureCode` : prendre par ex. le premier élément (tous partagent la même structure), ou utiliser `user.structure`.
- `stockTotal` : `sum(item.quantiteDisponible)` sur les `items`.
- `derniereMiseAJour` : `max(item.updatedAt)` sur les `items`, ou laisser vide / “–” si non requis.
- `statutGlobal` : dérivé (ex. BON si aucune rupture, CRITIQUE/EPUISE si au moins une ligne en rupture).
- `matieres` : peut rester `[]` si la page utilise directement `allStocks` pour le détail.

### 3) Construire `StockData[]` (allStocks) à partir de `items`

Pour chaque `item` (ou après agrégation par matière si vous voulez une ligne par matière) :

| Frontend (StockData) | Backend (StockDisponibleDto) |
|---------------------|-----------------------------|
| `structureId` | `structureId` |
| `structureLibelle` | `structureLibelle` |
| `structureCode` | `structureCode` |
| `matiereId` | `matiereId` |
| `matiereCode` | `matiereCode` |
| `matiereLibelle` | `matiereLibelle` |
| `stockDisponible` | `quantiteDisponible` |
| `stockReception` | `quantiteReceptions` |
| `stockDistribution` | `quantiteDistributions` |
| `statut` | dérivé : `estEnRupture === true` → `'EPUISE'`, sinon ex. `quantiteDisponible < seuilCritique` → `'CRITIQUE'`, sinon `'OK'` |

Si vous affichez une ligne par (matière + niveau), un `item` = une ligne. Si vous voulez une ligne par matière (tous niveaux confondus), il faut grouper par `matiereId` et sommer `quantiteDisponible` (et éventuellement les autres quantités).

---

## Endpoints utiles pour la page

| Besoin | Endpoint | Réponse |
|--------|----------|--------|
| Liste complète stocks (structure + année) | `GET /stock/structure/{structureId}/annee/{anneeScolaireId}` | `items` = liste cohérente avec libellés et quantités |
| Stocks en rupture | `GET /stock/rupture/structure/{structureId}/annee/{anneeScolaireId}` | `items` = mêmes DTO, filtrés rupture |
| Résumé texte | `GET /stock/resume/structure/{structureId}/annee/{anneeScolaireId}` | `item` = string (résumé) |
| Détail une ligne (optionnel) | `GET /stock/disponible?structureId=&matiereId=&niveauId=&anneeScolaireId=` | `item` = un DTO |

Donc **oui**, le backend peut répondre avec **toutes les données cohérentes nécessaires** pour la vue d’ensemble et le détail par matière/niveau.

---

## Contrainte obligatoire : année scolaire

- Tous ces endpoints exigent une **année scolaire** (ex. `anneeScolaireId` dans l’URL ou en paramètre).
- La page actuelle ne l’envoie pas. Il faut donc :
  - soit récupérer l’**année courante** (backend ou endpoint année courante),
  - soit ajouter un **sélecteur d’année** et passer l’`anneeScolaireId` choisi à chaque appel.

Sans ça, le backend ne peut pas renvoyer les bons stocks.

---

## Ce que le backend ne fournit pas (ou pas dans StockController)

| Besoin | Réponse |
|--------|--------|
| **Liste des mouvements** (onglet Mouvements) | Pas d’endpoint “liste mouvements par structure” dans **StockController**. À prévoir dans **MouvementController** ou autre module si vous voulez afficher l’historique des mouvements sur la page Stock. |
| **Stock total “structure”** (agrégat) | Pas d’endpoint dédié ; à calculer côté front à partir de `items` (sum `quantiteDisponible`). |
| **Seuil critique** pour statut CRITIQUE | Non présent dans le DTO ; vous pouvez fixer un seuil côté front (ex. 10) ou ajouter un champ/paramètre côté backend si besoin métier. |

Ces points ne bloquent pas l’affichage principal : vue d’ensemble, tableau par matière/niveau, ruptures et résumé sont couverts.

---

## Synthèse

- Le backend **peut** répondre aux données demandées par la page Stock avec des **données cohérentes** (structure, matière, niveau, année, quantités, libellés, estEnRupture, etc.).
- Il suffit d’utiliser **`/stock/structure/.../annee/...`** (et éventuellement rupture + resume), avec un **mapping** des champs et une **dérivation du statut** (OK/CRITIQUE/EPUISE) côté front, et de **passer l’année scolaire** à chaque requête.
- Le seul point non couvert par le StockController actuel est la **liste des mouvements** pour l’onglet Mouvements ; à traiter côté backend (nouvel endpoint ou existant dans MouvementController) si vous voulez cette fonctionnalité.
