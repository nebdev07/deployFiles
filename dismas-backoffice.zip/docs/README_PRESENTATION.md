# 📋 DOCUMENTS DE PRÉSENTATION DISMAS

## 🎯 **Documents Disponibles**

### **1. PRESENTATION_DISMAS_COMPLETE.md** ⭐ **PRINCIPAL**
- **Contenu** : Présentation complète avec toutes les tables de base de données
- **Structure** : Introduction, I) Étude de l'Existant, II) Étude Conceptuelle, III) Étude Organisationnelle, IV) Maquette
- **Fonctionnalités** : Tous les workflows (EPP, IEPP, DRENA, DAF/MENA, Retour de Manuels)
- **Tables** : Toutes les tables du schéma DISMAS-NextJs
- **Placeholders** : Espaces pour captures d'écran (1920x1080px)

### **2. PRESENTATION_TEMPLATE_PROFESSIONNEL.md**
- **Contenu** : Template de base pour présentation académique
- **Structure** : Même structure que le document complet
- **Fonctionnalités** : Workflows de base
- **Tables** : Tables principales uniquement

## 🚀 **Conversion Rapide**

### **PowerShell (Windows)**
```powershell
# Conversion automatique en tous formats
.\convert_dismas.ps1

# Conversion spécifique
.\convert_dismas.ps1 -Format pptx
.\convert_dismas.ps1 -Format pdf
```

### **Bash (Linux/macOS)**
```bash
# Rendre le script exécutable
chmod +x convert_dismas.sh

# Conversion automatique
./convert_dismas.sh

# Conversion spécifique
./convert_dismas.sh pptx
./convert_dismas.sh pdf
```

### **Manuel avec Pandoc**
```bash
# PowerPoint
pandoc PRESENTATION_DISMAS_COMPLETE.md -o DISMAS_Presentation.pptx --slide-level=2

# PDF
pandoc PRESENTATION_DISMAS_COMPLETE.md -o DISMAS_Presentation.pdf --pdf-engine=xelatex

# Word
pandoc PRESENTATION_DISMAS_COMPLETE.md -o DISMAS_Presentation.docx
```

## 📊 **Contenu du Document Principal**

### **I. INTRODUCTION**
- Contexte et justification
- Objectifs du projet DISMAS
- Architecture technique

### **II. ÉTUDE DE L'EXISTANT**
- Critique des supports physiques actuels
- Problèmes identifiés (traçabilité, erreurs, délais)

### **III. ÉTUDE CONCEPTUELLE**
- **Modèle Conceptuel de Données** : 6 entités principales
- **Modèle Conceptuel de Traitement** : 5 workflows détaillés
  - EPP (École Primaire Publique)
  - IEPP (Inspecteur d'Éducation)
  - DRENA (Direction Régionale)
  - DAF/MENA (Direction Administrative)
  - Retour de Manuels

### **IV. ÉTUDE ORGANISATIONNELLE**
- **Modèle Organisationnel de Données** : Toutes les tables DISMAS
- **Modèle Logique de Données** : Contraintes et index
- **Modèle Organisationnel de Traitement** : Workflows automatisés

### **V. MAQUETTE**
- **Arborescence** : Structure complète de l'application
- **Flow des Modules** : 10 sections avec placeholders pour captures d'écran

## 🎨 **Tables de Base de Données Incluses**

### **Tables de Référence**
- `annee_scolaire`, `niveau_scolaire`, `matiere`, `type_ouvrage`

### **Structures Administratives**
- `structure_administrative` (hiérarchie MENA → DRENA → IEPP → EPP)

### **Gestion Utilisateurs**
- `role`, `fonctionalite`, `role_fonctionalite`, `user`

### **Gestion des Manuels**
- `manuel`, `kit_pedagogique`

### **Stocks et Distribution**
- `inventaire_manuel`, `distribution_classe`, `detail_distribution_classe`

### **Régulation**
- `regulation`, `detail_regulation`

### **Retour de Manuels**
- `retour_manuel`, `detail_retour_manuel`

### **Qualité et Suivi**
- `plainte`, `enquete_satisfaction`, `reponse_enquete`

### **Système**
- `journal_activite`, `notification`, `parametre_systeme`

## 📋 **Workflows Détaillés**

### **1. Workflow EPP**
- Planification des besoins
- Réception des manuels
- Distribution aux classes
- Retour de manuels

### **2. Workflow IEPP**
- Supervision des EPP
- Régulation interne
- Validation des documents

### **3. Workflow DRENA**
- Gestion régionale
- Régulation externe
- Rapports et statistiques

### **4. Workflow DAF/MENA**
- Planification nationale
- Import des données
- Suivi et contrôle

### **5. Workflow Retour de Manuels**
- Planification de la collecte
- Collecte et évaluation
- Remise en stock
- Validation IEPP

## 🎯 **Prêt pour Présentation Client**

Le document `PRESENTATION_DISMAS_COMPLETE.md` contient :
- ✅ Toutes les tables nécessaires
- ✅ Tous les workflows utilisateurs
- ✅ Toutes les fonctionnalités
- ✅ Placeholders pour captures d'écran
- ✅ Structure académique complète

**Conversion recommandée** : PowerPoint pour présentation client, PDF pour documentation, Word pour rapport détaillé.

---

**DISMAS - Plateforme de Distribution des Manuels Scolaires** 🇨🇮 