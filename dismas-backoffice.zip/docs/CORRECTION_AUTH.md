# 🔐 CORRECTION AUTHENTIFICATION

## ❌ **PROBLÈME**

```
Error: Utilisateur non connecté
lib\services\mouvement.service.ts (438:13)
```

**Cause:** Le service `mouvementService` cherchait les informations d'authentification dans les mauvais emplacements du localStorage.

---

## 🔍 **ANALYSE**

### localStorage utilisé dans le projet

D'après `BaseApiService` (ligne 230-254), le projet utilise :
- **Token:** `localStorage.getItem('auth_token')`
- **User:** `localStorage.getItem('dismas_user')` ou `localStorage.getItem('user_session')`

### Ce qui était dans MouvementService (INCORRECT)

```typescript
// ❌ Avant
private getCurrentUserId(): number | null {
  const userJson = localStorage.getItem('user');  // ❌ Mauvaise clé
  // ...
}

private getAuthToken(): string | null {
  return localStorage.getItem('token');  // ❌ Mauvaise clé
}
```

---

## ✅ **CORRECTION APPLIQUÉE**

### Fichier: `lib/services/mouvement.service.ts`

#### 1. Méthode getCurrentUserId() (ligne 463-476)

```typescript
// ✅ Après
private getCurrentUserId(): number | null {
  if (typeof window === 'undefined') return null;
  
  try {
    // Essayer plusieurs emplacements (compatibilité)
    const userSession = localStorage.getItem('dismas_user') || 
                       localStorage.getItem('user_session') || 
                       localStorage.getItem('user');
    
    if (!userSession) return null;
    
    const user = JSON.parse(userSession);
    return user?.id || null;
  } catch (error) {
    console.error('Erreur lors de la récupération de l\'utilisateur:', error);
    return null;
  }
}
```

**Changements:**
- ✅ Essaie `dismas_user` en priorité
- ✅ Fallback sur `user_session`
- ✅ Fallback final sur `user` (compatibilité)

#### 2. Méthode getAuthToken() (ligne 478-485)

```typescript
// ✅ Après
private getAuthToken(): string | null {
  if (typeof window === 'undefined') return null;
  
  // Essayer plusieurs emplacements (compatibilité)
  return localStorage.getItem('auth_token') || 
         localStorage.getItem('token') || 
         null;
}
```

**Changements:**
- ✅ Essaie `auth_token` en priorité
- ✅ Fallback sur `token` (compatibilité)

---

## 🎯 **RÉSULTAT**

### Avant
```
❌ Error: Utilisateur non connecté
   - getCurrentUserId() retournait null
   - getAuthToken() retournait null
   - buildRequest() throw Error
```

### Après
```
✅ getCurrentUserId() retourne l'ID depuis 'dismas_user'
✅ getAuthToken() retourne le token depuis 'auth_token'
✅ buildRequest() construit correctement la requête
✅ Les appels API fonctionnent
```

---

## 📊 **MAPPING LOCALSTORAGE**

| Donnée | Clé principale | Clé fallback 1 | Clé fallback 2 |
|--------|---------------|----------------|----------------|
| **User** | `dismas_user` | `user_session` | `user` |
| **Token** | `auth_token` | `token` | - |

### Exemples de données

#### User (dismas_user)
```json
{
  "id": 29,
  "nom": "KOUASSI",
  "prenoms": "Jean",
  "login": "jkouassi",
  "role": {
    "id": 1,
    "code": "IEPP",
    "libelle": "Inspecteur IEPP"
  },
  "structure": {
    "id": 128,
    "code": "IEPP-COC",
    "libelle": "IEPP Cocody",
    "type": "IEPP"
  }
}
```

#### Token (auth_token)
```
eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
```

---

## 🧪 **VÉRIFICATION**

### Commandes pour tester dans Console Navigateur

```javascript
// Vérifier le token
console.log('Token:', localStorage.getItem('auth_token'));

// Vérifier l'utilisateur
console.log('User:', JSON.parse(localStorage.getItem('dismas_user')));

// Vérifier l'ID utilisateur
const user = JSON.parse(localStorage.getItem('dismas_user'));
console.log('User ID:', user.id);
```

### Résultats attendus
```
Token: eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
User: { id: 29, nom: "KOUASSI", ... }
User ID: 29
```

---

## 📝 **AUTRES SERVICES À VÉRIFIER**

Si d'autres services rencontrent le même problème, appliquer la même correction :

### Template de correction

```typescript
// Dans n'importe quel service qui hérite de BaseApiService
// OU qui implémente ses propres méthodes d'auth

private getCurrentUserId(): number | null {
  if (typeof window === 'undefined') return null;
  
  try {
    const userSession = localStorage.getItem('dismas_user') || 
                       localStorage.getItem('user_session') || 
                       localStorage.getItem('user');
    if (!userSession) return null;
    
    const user = JSON.parse(userSession);
    return user?.id || null;
  } catch (error) {
    console.error('Erreur:', error);
    return null;
  }
}

private getAuthToken(): string | null {
  if (typeof window === 'undefined') return null;
  return localStorage.getItem('auth_token') || localStorage.getItem('token') || null;
}
```

---

## ⚡ **BONNE PRATIQUE**

### Utiliser BaseApiService directement

Au lieu de réimplémenter `getCurrentUserId()` et `getAuthToken()`, le service pourrait hériter des méthodes de `BaseApiService` :

```typescript
export class MouvementService extends BaseApiService {
  // ✅ Utiliser les méthodes protected de BaseApiService
  // getCurrentUserId() et getAuthToken() sont déjà implémentées !
  
  private buildRequest(data: any, isCreateUpdate = false) {
    const userId = this.getCurrentUserId();    // ✅ Héritée
    const token = this.getAuthToken();         // ✅ Héritée
    
    // ...
  }
}
```

**Avantage:** Une seule implémentation, maintenance simplifiée.

---

## ✅ **CHECKLIST CORRECTION AUTH**

- [x] Corriger `getCurrentUserId()` avec fallbacks
- [x] Corriger `getAuthToken()` avec fallbacks
- [x] Tester dans console navigateur
- [ ] Vérifier autres services custom
- [ ] Considérer héritage des méthodes BaseApiService

---

**Date:** 2025-10-09  
**Statut:** ✅ **CORRIGÉ**  
**Impact:** L'authentification fonctionne maintenant correctement

