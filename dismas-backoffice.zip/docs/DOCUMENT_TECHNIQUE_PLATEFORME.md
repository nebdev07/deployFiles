# DOCUMENT TECHNIQUE - PLATEFORME DISMAS
## Système de Gestion des Manuels Scolaires

---

## TABLE DES MATIÈRES

1. [Vue d'ensemble](#vue-densemble)
2. [Architecture Technique](#architecture-technique)
3. [Flux Fonctionnel](#flux-fonctionnel)
4. [Modules et Fonctionnalités](#modules-et-fonctionnalités)
5. [Gestion des Utilisateurs](#gestion-des-utilisateurs)
6. [Base de Données](#base-de-données)
7. [API Backend](#api-backend)
8. [Interface Utilisateur](#interface-utilisateur)
9. [Sécurité](#sécurité)
10. [Déploiement](#déploiement)
11. [Maintenance et Support](#maintenance-et-support)

---

## VUE D'ENSEMBLE

### Description du Projet
DISMAS (Distribution Intelligente des Manuels Scolaires) est une plateforme web moderne conçue pour gérer l'ensemble du processus de distribution des manuels scolaires au niveau national. Le système suit un flux bottom-up pour l'expression des besoins et top-down pour la distribution.

### Objectifs
- **Automatisation** : Remplacer les processus manuels par une solution numérique
- **Traçabilité** : Assurer le suivi complet des manuels de la commande à la distribution
- **Transparence** : Fournir une visibilité totale sur les stocks et les distributions
- **Efficacité** : Optimiser les processus de gestion et réduire les pertes

### Public Cible
- **Administrateurs** : Gestion globale du système
- **DAF** : Gestion financière et commandes
- **DRENA** : Consolidation régionale
- **IEPP** : Consolidation départementale
- **Directeurs d'EPP** : Expression des besoins
- **Bibliothécaires** : Gestion des stocks locaux

---

## ARCHITECTURE TECHNIQUE

### Stack Technologique

#### Frontend
- **Framework** : Next.js 15.2.4 avec React 19
- **Langage** : TypeScript
- **Styling** : Tailwind CSS
- **UI Components** : Radix UI + Shadcn/ui
- **State Management** : React Hooks (useState, useContext)
- **Déploiement** : Vercel

#### Backend (Prévu)
- **Framework** : Spring Boot 3.x
- **Langage** : Java 17+
- **Base de données** : MySQL 8.0
- **ORM** : JPA/Hibernate
- **Sécurité** : Spring Security + JWT
- **API** : RESTful APIs
- **Documentation** : Swagger/OpenAPI

#### Infrastructure
- **Base de données** : MySQL
- **Cache** : Redis (optionnel)
- **Stockage fichiers** : AWS S3 ou équivalent
- **Monitoring** : Spring Boot Actuator

### Architecture Globale

```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   Frontend      │    │   Backend       │    │   Base de       │
│   (Next.js)     │◄──►│   (Spring Boot) │◄──►│   Données       │
│                 │    │                 │    │   (MySQL)       │
└─────────────────┘    └─────────────────┘    └─────────────────┘
         │                       │                       │
         │                       │                       │
         ▼                       ▼                       ▼
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   Vercel        │    │   Docker        │    │   Backup        │
│   (Déploiement) │    │   (Container)   │    │   (Automated)   │
└─────────────────┘    └─────────────────┘    └─────────────────┘
```

---

## FLUX FONCTIONNEL

### Processus Principal

#### 1. Expression des Besoins (Bottom-Up)
```
EPP → IEPP → DRENA → MENA/DAF
```

**Étape 1 : Expression au niveau EPP**
- Les directeurs d'EPP saisissent leurs besoins
- Calcul automatique des effectifs par niveau
- Sélection des manuels requis par niveau

**Étape 2 : Consolidation IEPP**
- Regroupement des besoins des EPP
- Validation et ajustement des quantités
- Statut : SAISI → VALIDE → CONSOLIDE

**Étape 3 : Consolidation DRENA**
- Regroupement des consolidations IEPP
- Validation régionale
- Statut : EN_COURS → VALIDE → CONSOLIDE

#### 2. Gestion des Commandes (DAF)
- **Synthèse des besoins** : Vue consolidée de tous les besoins
- **Saisie des commandes** : Quantités commandées par manuel
- **Génération du tableau de répartition** : Calcul automatique des allocations

#### 3. Distribution (Top-Down)
```
MENA → DRENA → IEPP → EPP
```

**Étape 1 : Tableau de Répartition**
- Calcul automatique des allocations
- Répartition équitable basée sur les effectifs
- Génération des documents de distribution

**Étape 2 : Distribution Physique**
- Suivi des livraisons
- Validation des réceptions
- Gestion des retours et réclamations

### Statuts du Processus

| Statut | Description | Niveau |
|--------|-------------|---------|
| SAISI | Saisie initiale | EPP |
| BROUILLON | Brouillon en cours | Tous |
| VALIDE | Validé par le niveau supérieur | IEPP, DRENA |
| EN_COURS | En cours de traitement | DRENA |
| CONSOLIDE | Consolidé et finalisé | DRENA |
| ANNULE | Annulé | Tous |

---

## MODULES ET FONCTIONNALITÉS

### 1. Dashboard
**Accès** : Tous les utilisateurs
**Fonctionnalités** :
- Statistiques globales
- Indicateurs par rôle
- Alertes et notifications
- Vue d'ensemble des stocks

### 2. Expression des Besoins
**Accès** : DIRECTEUR, IEPP, DRENA, DAF, ADMIN
**Fonctionnalités** :
- Saisie des besoins EPP
- Consolidation IEPP
- Consolidation DRENA
- Validation et approbation
- Historique des modifications

### 3. Commandes
**Accès** : DAF, ADMIN
**Fonctionnalités** :
- Synthèse des besoins consolidés
- Saisie des quantités commandées
- Génération du tableau de répartition
- Export des documents

### 4. Tableau de Répartition
**Accès** : DAF, DRENA, IEPP, DIRECTEUR, ADMIN
**Fonctionnalités** :
- Vue d'ensemble des répartitions
- Détails par DRENA/IEPP/EPP
- Sélection d'année scolaire
- Export PDF/Excel
- Impression des documents

### 5. Stocks
**Accès** : Tous les utilisateurs
**Fonctionnalités** :
- Gestion des stocks par structure
- Suivi des mouvements
- Alertes de stock faible
- Inventaire physique

### 6. Distribution
**Accès** : DIRECTEUR, MAITRE, COGES
**Fonctionnalités** :
- Suivi des livraisons
- Validation des réceptions
- Gestion des distributions aux élèves
- Historique des distributions

### 7. Régulation
**Accès** : DRENA, IEPP, DIRECTEUR
**Fonctionnalités** :
- Transferts entre structures
- Ajustements de stocks
- Gestion des surplus/déficits

### 8. Retours
**Accès** : DIRECTEUR, MAITRE
**Fonctionnalités** :
- Saisie des retours d'élèves
- Validation des retours
- Réintégration en stock

### 9. Réclamations
**Accès** : Tous les utilisateurs
**Fonctionnalités** :
- Saisie des réclamations
- Suivi du traitement
- Résolution des problèmes

### 10. Enquêtes
**Accès** : ADMIN, DRENA
**Fonctionnalités** :
- Création d'enquêtes
- Collecte des réponses
- Analyse des résultats

### 11. Rapports
**Accès** : Tous les utilisateurs (selon rôle)
**Fonctionnalités** :
- Rapports de distribution
- Statistiques d'utilisation
- Rapports financiers
- Export des données

### 12. Utilisateurs
**Accès** : ADMIN
**Fonctionnalités** :
- Gestion des utilisateurs
- Attribution des rôles
- Gestion des permissions

### 13. Paramétrages
**Accès** : ADMIN
**Fonctionnalités** :
- Configuration du système
- Gestion des manuels
- Paramètres régionaux

---

## GESTION DES UTILISATEURS

### Hiérarchie des Rôles

```
ADMIN (Niveau 1)
├── DAF (Niveau 2)
├── DRENA (Niveau 3)
│   └── IEPP (Niveau 4)
│       └── EPP (Niveau 5)
│           ├── DIRECTEUR (Niveau 6)
│           ├── MAITRE (Niveau 7)
│           └── COGES (Niveau 8)
```

### Structure des Tables

#### Table `user`
```sql
CREATE TABLE user (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    nom VARCHAR(100) NOT NULL,
    prenoms VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE,
    telephone VARCHAR(20),
    role_id BIGINT NOT NULL,
    structure_id BIGINT,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by BIGINT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    updated_by BIGINT,
    is_deleted BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (role_id) REFERENCES role(id),
    FOREIGN KEY (structure_id) REFERENCES structure(id),
    FOREIGN KEY (created_by) REFERENCES user(id),
    FOREIGN KEY (updated_by) REFERENCES user(id)
);
```

#### Table `role`
```sql
CREATE TABLE role (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    code VARCHAR(20) UNIQUE NOT NULL,
    nom VARCHAR(100) NOT NULL,
    description TEXT,
    niveau INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by BIGINT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    updated_by BIGINT,
    is_deleted BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (created_by) REFERENCES user(id),
    FOREIGN KEY (updated_by) REFERENCES user(id)
);
```

#### Table `fonctionalite`
```sql
CREATE TABLE fonctionalite (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    code VARCHAR(50) UNIQUE NOT NULL,
    nom VARCHAR(100) NOT NULL,
    description TEXT,
    module VARCHAR(50) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by BIGINT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    updated_by BIGINT,
    is_deleted BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (created_by) REFERENCES user(id),
    FOREIGN KEY (updated_by) REFERENCES user(id)
);
```

#### Table `role_fonctionalite`
```sql
CREATE TABLE role_fonctionalite (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    role_id BIGINT NOT NULL,
    fonctionalite_id BIGINT NOT NULL,
    can_read BOOLEAN DEFAULT FALSE,
    can_write BOOLEAN DEFAULT FALSE,
    can_delete BOOLEAN DEFAULT FALSE,
    can_approve BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by BIGINT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    updated_by BIGINT,
    is_deleted BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (role_id) REFERENCES role(id),
    FOREIGN KEY (fonctionalite_id) REFERENCES fonctionalite(id),
    FOREIGN KEY (created_by) REFERENCES user(id),
    FOREIGN KEY (updated_by) REFERENCES user(id),
    UNIQUE KEY unique_role_fonctionalite (role_id, fonctionalite_id)
);
```

### Permissions par Rôle

| Rôle | Niveau | Permissions Principales |
|------|--------|------------------------|
| ADMIN | 1 | Toutes les permissions |
| DAF | 2 | Gestion financière, commandes, tableau de répartition |
| DRENA | 3 | Consolidation régionale, régulation |
| IEPP | 4 | Consolidation départementale |
| DIRECTEUR | 6 | Gestion EPP, expression des besoins |
| MAITRE | 7 | Distribution aux élèves |
| COGES | 8 | Suivi et contrôle |

---

## BASE DE DONNÉES

### Tables Principales

#### Gestion des Manuels
- `manuel` : Catalogue des manuels
- `niveau` : Niveaux scolaires
- `manuel_niveau` : Association manuels-niveaux

#### Gestion des Structures
- `structure` : Structures (MENA, DRENA, IEPP, EPP)
- `type_structure` : Types de structures

#### Expression des Besoins
- `besoin` : Besoins exprimés par EPP
- `besoin_detail` : Détails des besoins
- `consolidation_iepp` : Consolidations IEPP
- `consolidation_drena` : Consolidations DRENA

#### Commandes et Distribution
- `commande` : Commandes DAF
- `commande_detail` : Détails des commandes
- `tableau_repartition` : Tableau de répartition
- `repartition_detail` : Détails de répartition

#### Stocks et Mouvements
- `stock` : Stocks par structure
- `mouvement_stock` : Mouvements de stock
- `distribution` : Distributions aux élèves
- `retour` : Retours d'élèves

#### Gestion des Utilisateurs
- `user` : Utilisateurs
- `role` : Rôles
- `fonctionalite` : Fonctionnalités
- `role_fonctionalite` : Permissions

### Relations Clés

```
Structure (1) ←→ (N) User
Structure (1) ←→ (N) Stock
User (1) ←→ (N) Besoin
Besoin (1) ←→ (N) BesoinDetail
Structure (1) ←→ (N) ConsolidationIEPP
Structure (1) ←→ (N) ConsolidationDRENA
Commande (1) ←→ (N) CommandeDetail
TableauRepartition (1) ←→ (N) RepartitionDetail
```

---

## API BACKEND

### Architecture REST

#### Authentification
```
POST /api/auth/login
POST /api/auth/logout
POST /api/auth/refresh
GET  /api/auth/profile
```

#### Gestion des Utilisateurs
```
GET    /api/users
POST   /api/users
GET    /api/users/{id}
PUT    /api/users/{id}
DELETE /api/users/{id}
GET    /api/users/roles
GET    /api/users/fonctionalites
```

#### Expression des Besoins
```
GET    /api/besoins
POST   /api/besoins
GET    /api/besoins/{id}
PUT    /api/besoins/{id}
DELETE /api/besoins/{id}
GET    /api/besoins/consolidation/iepp
GET    /api/besoins/consolidation/drena
POST   /api/besoins/consolider/iepp/{id}
POST   /api/besoins/consolider/drena/{id}
```

#### Commandes
```
GET    /api/commandes
POST   /api/commandes
GET    /api/commandes/{id}
PUT    /api/commandes/{id}
DELETE /api/commandes/{id}
POST   /api/commandes/generer-tableau/{id}
```

#### Tableau de Répartition
```
GET    /api/repartition
GET    /api/repartition/{id}
GET    /api/repartition/annee/{annee}
GET    /api/repartition/drena/{drenaId}
GET    /api/repartition/iepp/{ieppId}
POST   /api/repartition/export/{format}
```

#### Stocks
```
GET    /api/stocks
GET    /api/stocks/{structureId}
POST   /api/stocks/mouvement
GET    /api/stocks/mouvements
```

#### Distribution
```
GET    /api/distributions
POST   /api/distributions
GET    /api/distributions/{id}
PUT    /api/distributions/{id}
```

### Format des Réponses

#### Succès
```json
{
  "success": true,
  "data": {...},
  "message": "Opération réussie"
}
```

#### Erreur
```json
{
  "success": false,
  "error": {
    "code": "ERROR_CODE",
    "message": "Message d'erreur",
    "details": {...}
  }
}
```

### Pagination
```json
{
  "success": true,
  "data": {
    "content": [...],
    "pageable": {
      "page": 0,
      "size": 20,
      "totalElements": 100,
      "totalPages": 5
    }
  }
}
```

---

## INTERFACE UTILISATEUR

### Design System

#### Couleurs
- **Primaire** : Blue-600 (#2563EB)
- **Secondaire** : Gray-600 (#4B5563)
- **Succès** : Green-600 (#16A34A)
- **Avertissement** : Yellow-600 (#CA8A04)
- **Erreur** : Red-600 (#DC2626)
- **Info** : Blue-500 (#3B82F6)

#### Typographie
- **Titre principal** : text-2xl font-bold
- **Sous-titre** : text-xl font-semibold
- **Titre de section** : text-lg font-medium
- **Corps de texte** : text-base
- **Petit texte** : text-sm

#### Composants
- **Boutons** : Variantes primary, secondary, outline, ghost
- **Cartes** : Bordures arrondies, ombres subtiles
- **Tableaux** : Lignes alternées, hover effects
- **Modales** : Overlay avec backdrop blur
- **Formulaires** : Validation en temps réel

### Responsive Design
- **Mobile First** : Design adaptatif
- **Breakpoints** : sm (640px), md (768px), lg (1024px), xl (1280px)
- **Navigation** : Sidebar collapsible sur mobile

### Accessibilité
- **Contraste** : Ratio WCAG AA minimum
- **Navigation clavier** : Support complet
- **Screen readers** : ARIA labels appropriés
- **Focus visible** : Indicateurs de focus clairs

---

## SÉCURITÉ

### Authentification
- **JWT Tokens** : Access token + Refresh token
- **Expiration** : Access token (15min), Refresh token (7 jours)
- **Rotation** : Refresh token automatique

### Autorisation
- **RBAC** : Role-Based Access Control
- **Permissions granulaires** : CRUD par fonctionnalité
- **Hiérarchie** : Respect de la hiérarchie des rôles

### Protection des Données
- **Chiffrement** : Mots de passe hashés (BCrypt)
- **HTTPS** : Communication sécurisée
- **Validation** : Input validation côté serveur
- **Sanitisation** : Protection contre les injections

### Audit Trail
- **Logs** : Toutes les actions importantes
- **Traçabilité** : created_by, updated_by sur toutes les tables
- **Soft Delete** : is_deleted pour la récupération

---

## DÉPLOIEMENT

### Environnements

#### Développement
- **Frontend** : Local (localhost:3000)
- **Backend** : Local (localhost:8080)
- **Base de données** : Local MySQL

#### Staging
- **Frontend** : Vercel Preview
- **Backend** : Docker sur serveur de test
- **Base de données** : MySQL sur serveur de test

#### Production
- **Frontend** : Vercel Production
- **Backend** : Docker sur serveur de production
- **Base de données** : MySQL cluster
- **Monitoring** : Application Insights

### CI/CD Pipeline

#### Frontend (Vercel)
```
Git Push → Build → Test → Deploy
```

#### Backend (GitHub Actions)
```
Git Push → Build → Test → Docker Build → Deploy
```

### Monitoring
- **Performance** : Response times, throughput
- **Erreurs** : Error tracking, alerting
- **Utilisation** : User analytics, feature usage
- **Infrastructure** : CPU, mémoire, disque

---

## MAINTENANCE ET SUPPORT

### Maintenance Préventive
- **Backups** : Automatiques quotidiens
- **Updates** : Mises à jour de sécurité
- **Monitoring** : Surveillance 24/7
- **Tests** : Tests automatisés

### Support Utilisateur
- **Documentation** : Guides utilisateur
- **Formation** : Sessions de formation
- **Support** : Ticket system
- **FAQ** : Questions fréquentes

### Évolutions Futures
- **API Mobile** : Application mobile
- **Intégrations** : Systèmes externes
- **IA/ML** : Prédiction des besoins
- **Analytics** : Tableaux de bord avancés

---

## CONCLUSION

La plateforme DISMAS représente une solution complète et moderne pour la gestion des manuels scolaires. Son architecture robuste, son interface intuitive et son flux fonctionnel optimisé en font un outil indispensable pour l'administration scolaire.

### Points Forts
- **Architecture moderne** : Next.js + Spring Boot
- **Flux optimisé** : Bottom-up puis top-down
- **Sécurité renforcée** : RBAC + audit trail
- **Interface intuitive** : Design system cohérent
- **Scalabilité** : Architecture microservices ready

### Avantages Métier
- **Réduction des pertes** : Traçabilité complète
- **Optimisation des coûts** : Gestion centralisée
- **Transparence** : Visibilité totale du processus
- **Efficacité** : Automatisation des tâches répétitives

La plateforme est prête pour le déploiement en production et peut évoluer selon les besoins futurs de l'organisation. 