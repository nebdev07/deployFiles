# DOCUMENT TECHNIQUE - FLOWS DE DISTRIBUTION DES MANUELS

## Vue d'ensemble

La plateforme DISMAS supporte **deux approches complémentaires** pour la distribution des manuels scolaires, permettant une flexibilité maximale selon le contexte et les besoins.

---

## 1. FLOW BOTTOM-UP (Expression des Besoins)

### Description
Approche traditionnelle basée sur l'expression préalable des besoins par les structures éducatives.

### Étapes du Processus

```
1. EXPRESSION DES BESOINS
   ├── EPP : Saisie des besoins par niveau/classe
   ├── IEPP : Consolidation départementale
   ├── DRENA : Consolidation régionale
   └── DAF : Validation et approbation

2. COMMANDE
   ├── Génération du tableau de répartition
   ├── Commande des manuels
   └── Réception des stocks

3. DISTRIBUTION
   ├── Distribution basée sur le tableau de répartition
   ├── Suivi des distributions
   └── Validation des réceptions

4. RÉGULATION
   ├── Identification des excédents/déficits
   ├── Régulation entre EPP
   └── Optimisation des stocks
```

### Avantages
- ✅ **Planification précise** : Besoins identifiés à l'avance
- ✅ **Contrôle budgétaire** : Commandes basées sur les besoins réels
- ✅ **Traçabilité complète** : Chaque étape documentée
- ✅ **Optimisation des coûts** : Évite les surcommandes

### Inconvénients
- ❌ **Processus long** : Plusieurs étapes de validation
- ❌ **Rigidité** : Difficile d'ajuster après validation
- ❌ **Dépendance** : Nécessite la participation de tous les niveaux

---

## 2. FLOW TOP-DOWN (Distribution Directe)

### Description
Approche agile basée sur la distribution directe suivie de l'identification des besoins réels.

### Étapes du Processus

```
1. DISTRIBUTION INITIALE
   ├── Distribution directe aux EPP
   ├── Basée sur les effectifs estimés
   └── Gestion des stocks disponibles

2. DISTRIBUTION AUX ÉLÈVES
   ├── Distribution dans chaque classe
   ├── Identification des besoins réels
   └── Saisie des effectifs réels

3. IDENTIFICATION DES BESOINS RÉELS
   ├── Calcul des excédents/déficits
   ├── Analyse par manuel et niveau
   └── Génération des rapports

4. RÉGULATION
   ├── Transfert des excédents
   ├── Complémentation des déficits
   └── Optimisation finale
```

### Avantages
- ✅ **Rapidité** : Distribution immédiate possible
- ✅ **Flexibilité** : Ajustements en cours de processus
- ✅ **Réactivité** : Réponse aux besoins réels
- ✅ **Simplicité** : Moins d'étapes de validation

### Inconvénients
- ❌ **Risque de gaspillage** : Distribution sans planification précise
- ❌ **Coûts potentiels** : Surcommandes possibles
- ❌ **Complexité régulation** : Nécessite plus de régulation

---

## 3. APPROCHE HYBRIDE

### Principe
Combinaison intelligente des deux flows selon le contexte, la région, ou le type de manuel.

### Stratégies d'Implémentation

#### Stratégie 1 : Par Type de Manuel
```
📚 MANUELS PRINCIPAUX (Français, Mathématiques)
   → Flow Bottom-Up (planification précise)

📖 MANUELS COMPLÉMENTAIRES (Sciences, Histoire)
   → Flow Top-Down (distribution agile)
```

#### Stratégie 2 : Par Région
```
🏙️ RÉGIONS URBANES (effectifs stables)
   → Flow Bottom-Up

🏘️ RÉGIONS RURALES (effectifs variables)
   → Flow Top-Down
```

#### Stratégie 3 : Par Période
```
📅 DÉBUT D'ANNÉE (planification)
   → Flow Bottom-Up

📅 MILIEU D'ANNÉE (ajustements)
   → Flow Top-Down
```

---

## 4. IMPLÉMENTATION TECHNIQUE

### Tables Principales

#### Flow Bottom-Up
```sql
-- Expression des besoins
besoins (id, annee_scolaire, structure_id, niveau, effectif_total, statut)
besoin_details (id, besoin_id, manuel_id, quantite_demandee, quantite_consolidee)

-- Commandes
commandes (id, numero_commande, annee_scolaire, fournisseur, statut)
commande_details (id, commande_id, manuel_id, quantite_commandee)

-- Distribution
distributions (id, annee_scolaire, structure_source_id, structure_destination_id, manuel_id, quantite_distribuee)
```

#### Flow Top-Down
```sql
-- Distribution directe
distributions_directes (id, annee_scolaire, structure_source_id, structure_destination_id, manuel_id, quantite_distribuee, type_distribution)

-- Distribution aux élèves
distributions_eleves (id, annee_scolaire, structure_id, manuel_id, niveau, classe, quantite_distribuee)

-- Besoins réels identifiés
besoins_reels (id, annee_scolaire, structure_id, niveau, manuel_id, quantite_manquante, quantite_excedantaire, effectif_reel)
```

### Gestion des Flows
```sql
-- Stratégies de distribution
strategies_distribution (id, code, libelle, type_flow, parametres)

-- Phases de distribution
phases_distribution (id, annee_scolaire, phase, statut, date_debut, date_fin)
```

---

## 5. INTERFACE UTILISATEUR

### Dashboard Principal
```
┌─────────────────────────────────────────────────────────────┐
│                    DASHBOARD DISMAS                        │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  📊 STATISTIQUES GLOBALES                                 │
│  ├── Flow Bottom-Up : 45 EPP, 12,500 manuels             │
│  ├── Flow Top-Down : 23 EPP, 8,200 manuels               │
│  └── Régulation : 15 transferts en cours                  │
│                                                             │
│  🎯 PHASES ACTIVES                                        │
│  ├── Expression des besoins : TERMINÉE                    │
│  ├── Distribution initiale : EN COURS                     │
│  ├── Distribution élèves : EN COURS                       │
│  └── Régulation : EN ATTENTE                              │
│                                                             │
│  ⚠️  ALERTES                                              │
│  ├── 3 EPP en déficit (CP1 Français)                     │
│  ├── 5 EPP en excédent (CE2 Mathématiques)               │
│  └── 2 commandes en retard                                │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### Modules Spécialisés

#### Module "Expression des Besoins" (Bottom-Up)
- Saisie des besoins par EPP
- Consolidation par niveau hiérarchique
- Validation et approbation
- Génération du tableau de répartition

#### Module "Distribution Directe" (Top-Down)
- Distribution immédiate aux EPP
- Suivi des distributions aux élèves
- Identification automatique des besoins réels
- Alertes sur les excédents/déficits

#### Module "Régulation Hybride"
- Gestion des transferts entre EPP
- Optimisation des stocks
- Rapports de régulation
- Historique des mouvements

---

## 6. LOGIQUE MÉTIER

### Détermination du Flow
```javascript
function determinerFlow(contexte) {
  const { type_manuel, region, periode, effectif_stable } = contexte;
  
  if (type_manuel === 'PRINCIPAL' && effectif_stable) {
    return 'BOTTOM_UP';
  } else if (type_manuel === 'COMPLEMENTAIRE' || !effectif_stable) {
    return 'TOP_DOWN';
  } else {
    return 'HYBRIDE';
  }
}
```

### Calcul des Besoins Réels
```javascript
function calculerBesoinsReels(distribution_eleves, stock_disponible) {
  const effectif_total = distribution_eleves.reduce((sum, d) => sum + d.quantite, 0);
  
  if (stock_disponible < effectif_total) {
    return {
      type: 'DEFICIT',
      quantite: effectif_total - stock_disponible
    };
  } else if (stock_disponible > effectif_total) {
    return {
      type: 'EXCEDENT',
      quantite: stock_disponible - effectif_total
    };
  }
  
  return { type: 'EQUILIBRE', quantite: 0 };
}
```

---

## 7. RAPPORTS ET ANALYSES

### Rapport Comparatif des Flows
```
┌─────────────────────────────────────────────────────────────┐
│              COMPARAISON DES FLOWS 2024-2025              │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  FLOW BOTTOM-UP                                           │
│  ├── EPP concernés : 45                                   │
│  ├── Manuels planifiés : 12,500                          │
│  ├── Précision : 94%                                      │
│  └── Coût moyen : 2,300 FCFA/manuel                      │
│                                                             │
│  FLOW TOP-DOWN                                            │
│  ├── EPP concernés : 23                                   │
│  ├── Manuels distribués : 8,200                           │
│  ├── Régulation nécessaire : 15%                          │
│  └── Coût moyen : 2,450 FCFA/manuel                      │
│                                                             │
│  RÉGULATION HYBRIDE                                       │
│  ├── Transferts effectués : 28                            │
│  ├── Manuels optimisés : 1,200                            │
│  ├── Économies réalisées : 15%                            │
│  └── Satisfaction globale : 92%                            │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## 8. RECOMMANDATIONS D'UTILISATION

### Pour les Manuels Principaux
- **Flow Bottom-Up** recommandé
- Planification détaillée nécessaire
- Validation par tous les niveaux
- Suivi strict des effectifs

### Pour les Manuels Complémentaires
- **Flow Top-Down** recommandé
- Distribution agile
- Régulation post-distribution
- Flexibilité maximale

### Pour les Situations d'Urgence
- **Flow Top-Down** obligatoire
- Distribution immédiate
- Régulation intensive
- Rapports détaillés

### Pour les Régions Pilotes
- **Flow Hybride** recommandé
- Test des deux approches
- Comparaison des résultats
- Optimisation continue

---

## 9. ÉVOLUTION FUTURE

### Améliorations Prévues
1. **IA Prédictive** : Anticipation des besoins basée sur l'historique
2. **Optimisation Automatique** : Algorithmes de régulation intelligente
3. **Interface Mobile** : Application pour les directeurs d'EPP
4. **Intégration Météo** : Ajustement selon les conditions climatiques

### Métriques de Succès
- **Précision des prévisions** : > 90%
- **Temps de distribution** : < 30 jours
- **Coût par manuel** : < 2,500 FCFA
- **Satisfaction utilisateur** : > 85%

---

## CONCLUSION

L'approche hybride offre la **flexibilité maximale** pour répondre aux différents contextes éducatifs. En combinant les avantages des deux flows, la plateforme DISMAS peut s'adapter aux besoins spécifiques de chaque région, type de manuel, ou situation particulière.

La clé du succès réside dans la **bonne utilisation de chaque approche** selon le contexte, avec un système de régulation robuste pour optimiser les résultats finaux. 