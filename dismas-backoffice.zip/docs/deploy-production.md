# 🚀 Guide de Déploiement en Production - DISMAS

## 📋 Prérequis

- ✅ Node.js 18+ installé
- ✅ Backend accessible sur `http://51.91.253.21:8080/dismas-api`
- ✅ Accès au serveur de production
- ✅ Configuration CORS activée sur le backend

---

## 🔧 Étapes de déploiement

### **1. Vérifier la configuration**

**Fichier** : `lib/config/api.ts`

Vérifier que l'URL de production est correcte :
```typescript
production: {
  baseUrl: 'http://51.91.253.21:8080/dismas-api',  // ✅ OK
  timeout: 15000,
  headers: {
    'Content-Type': 'application/json',
  },
},
```

---

### **2. Tester en local avec la config production**

```bash
# Forcer NODE_ENV en production
export NODE_ENV=production  # Linux/Mac
set NODE_ENV=production     # Windows

# Build
npm run build

# Lancer en mode production
npm run start

# Tester l'application
# Ouvrir http://localhost:3000
# F12 > Network > Vérifier que les requêtes pointent vers 51.91.253.21
```

---

### **3. Build pour la production**

```bash
# Nettoyer les builds précédents
rm -rf .next  # Linux/Mac
rmdir /s /q .next  # Windows

# Build optimisé
npm run build

# Résultat attendu
# ✅ Compiled successfully
# ✅ .next/ créé avec les fichiers optimisés
```

---

### **4. Déploiement sur le serveur**

#### **Option A : Déploiement manuel**

```bash
# 1. Transférer les fichiers vers le serveur
scp -r .next user@51.91.253.21:/path/to/app/
scp -r public user@51.91.253.21:/path/to/app/
scp -r node_modules user@51.91.253.21:/path/to/app/
scp package.json user@51.91.253.21:/path/to/app/
scp next.config.mjs user@51.91.253.21:/path/to/app/

# 2. Se connecter au serveur
ssh user@51.91.253.21

# 3. Aller dans le dossier de l'app
cd /path/to/app

# 4. Installer les dépendances (si nécessaire)
npm install --production

# 5. Lancer l'application
NODE_ENV=production npm run start
```

#### **Option B : Déploiement avec PM2 (recommandé)**

```bash
# Sur le serveur
cd /path/to/app

# Installer PM2 (si non installé)
npm install -g pm2

# Créer ecosystem.config.js
cat > ecosystem.config.js << EOF
module.exports = {
  apps: [{
    name: 'dismas-frontend',
    script: 'npm',
    args: 'start',
    env: {
      NODE_ENV: 'production',
      PORT: 3000
    },
    instances: 1,
    autorestart: true,
    watch: false,
    max_memory_restart: '1G',
  }]
}
EOF

# Lancer avec PM2
pm2 start ecosystem.config.js

# Sauvegarder la configuration
pm2 save

# Auto-démarrage au boot
pm2 startup
```

#### **Option C : Déploiement avec Docker**

```bash
# Créer Dockerfile
cat > Dockerfile << EOF
FROM node:18-alpine

WORKDIR /app

COPY package*.json ./
RUN npm install --production

COPY . .
RUN npm run build

EXPOSE 3000

ENV NODE_ENV=production

CMD ["npm", "start"]
EOF

# Build l'image Docker
docker build -t dismas-frontend .

# Lancer le conteneur
docker run -d \
  --name dismas-frontend \
  -p 3000:3000 \
  -e NODE_ENV=production \
  --restart unless-stopped \
  dismas-frontend
```

---

### **5. Configuration Nginx (reverse proxy)**

```nginx
# /etc/nginx/sites-available/dismas-frontend
server {
    listen 80;
    server_name votre-domaine.com;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}

# Activer la configuration
sudo ln -s /etc/nginx/sites-available/dismas-frontend /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl reload nginx
```

---

## 🔍 Vérifications post-déploiement

### **1. Vérifier que l'application est accessible**
```bash
curl http://51.91.253.21:3000
# OU
curl http://votre-domaine.com
```

### **2. Vérifier les logs**

**Avec PM2** :
```bash
pm2 logs dismas-frontend
```

**Avec Docker** :
```bash
docker logs dismas-frontend
```

### **3. Vérifier les requêtes API**

Ouvrir l'application dans le navigateur :
```
http://votre-domaine.com
# OU
http://51.91.253.21:3000
```

F12 > Network > Vérifier que les requêtes pointent vers :
```
http://51.91.253.21:8080/dismas-api/...
```

### **4. Tester les fonctionnalités**

- ✅ Connexion
- ✅ Navigation
- ✅ Création d'un retour
- ✅ Modification d'un retour
- ✅ Suppression d'un retour
- ✅ Pagination
- ✅ Chargement des données de référence

---

## 🛡️ Configuration CORS Backend

Le backend doit autoriser les requêtes depuis le frontend.

**Fichier backend** : `WebConfig.java` ou `SecurityConfig.java`

```java
@Configuration
public class WebConfig implements WebMvcConfigurer {
    
    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/**")
                .allowedOrigins(
                    "http://localhost:3000",
                    "http://51.91.253.21:3000",
                    "http://votre-domaine.com"
                )
                .allowedMethods("GET", "POST", "PUT", "DELETE", "OPTIONS")
                .allowedHeaders("*")
                .allowCredentials(true);
    }
}
```

---

## 📊 Monitoring

### **Avec PM2**
```bash
# Status
pm2 status

# Logs en temps réel
pm2 logs dismas-frontend --lines 100

# Monitoring
pm2 monit

# Redémarrer
pm2 restart dismas-frontend

# Arrêter
pm2 stop dismas-frontend

# Supprimer
pm2 delete dismas-frontend
```

### **Avec Docker**
```bash
# Status
docker ps | grep dismas-frontend

# Logs
docker logs -f dismas-frontend

# Stats
docker stats dismas-frontend

# Redémarrer
docker restart dismas-frontend

# Arrêter
docker stop dismas-frontend

# Supprimer
docker rm -f dismas-frontend
```

---

## 🔄 Mise à jour

### **Processus de mise à jour**

```bash
# 1. Sur votre machine locale
git pull
npm run build

# 2. Transférer vers le serveur
scp -r .next user@51.91.253.21:/path/to/app/

# 3. Sur le serveur
ssh user@51.91.253.21
cd /path/to/app

# 4. Redémarrer l'application
pm2 restart dismas-frontend
# OU
docker restart dismas-frontend
```

---

## 🚨 Dépannage

### **Problème : Application ne démarre pas**

**Vérifications** :
```bash
# Vérifier les logs
pm2 logs dismas-frontend --err

# Vérifier le port
netstat -tulpn | grep :3000

# Vérifier NODE_ENV
pm2 env dismas-frontend | grep NODE_ENV
```

### **Problème : Erreur 502 Bad Gateway**

**Cause** : Le frontend n'est pas accessible

**Solution** :
```bash
# Vérifier que l'app tourne
pm2 status
curl http://localhost:3000

# Redémarrer Nginx
sudo systemctl restart nginx
```

### **Problème : Requêtes API échouent**

**Cause** : CORS ou backend inaccessible

**Solution** :
```bash
# Tester l'accès au backend
curl http://51.91.253.21:8080/dismas-api/user/connexion

# Vérifier les logs backend
# Activer CORS si nécessaire
```

### **Problème : Erreur "Module not found"**

**Cause** : Dépendances manquantes

**Solution** :
```bash
# Réinstaller les dépendances
npm install --production

# Reconstruire
npm run build

# Redémarrer
pm2 restart dismas-frontend
```

---

## 📝 Checklist de déploiement

- [ ] Configuration `api.ts` vérifiée
- [ ] Build local réussi
- [ ] Tests locaux en mode production OK
- [ ] Fichiers transférés vers le serveur
- [ ] Dépendances installées sur le serveur
- [ ] Application lancée (PM2/Docker)
- [ ] Nginx configuré (si applicable)
- [ ] CORS configuré sur le backend
- [ ] Application accessible
- [ ] Requêtes API fonctionnent
- [ ] Fonctionnalités testées
- [ ] Logs vérifiés
- [ ] Monitoring configuré
- [ ] Documentation mise à jour

---

## 🎯 Résumé

| **Étape** | **Commande** | **Statut** |
|-----------|--------------|------------|
| Build | `npm run build` | ✅ |
| Déploiement | `scp` / `docker` / `pm2` | ⏳ À faire |
| Nginx | Configuration reverse proxy | ⏳ Optionnel |
| CORS | Configuration backend | ⚠️ Requis |
| Tests | Vérification fonctionnalités | ⏳ À faire |
| Monitoring | PM2 / Docker logs | ⏳ À configurer |

---

**Date** : Octobre 2025
**URL Production** : `http://51.91.253.21:8080/dismas-api`
**Port Frontend** : `3000`
**Statut** : ✅ Configuration prête, déploiement à effectuer

