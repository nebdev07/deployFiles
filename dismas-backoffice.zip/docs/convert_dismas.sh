#!/bin/bash
# 🎯 Script de Conversion DISMAS
# Conversion automatique de la présentation en PowerPoint et PDF

# Configuration
FORMAT=${1:-"all"}
INPUT_FILE=${2:-"PRESENTATION_DISMAS_COMPLETE.md"}
OUTPUT_PREFIX=${3:-"DISMAS_Presentation"}

# Couleurs pour l'affichage
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

echo -e "${GREEN}🎯 Conversion DISMAS en cours...${NC}"
echo -e "${CYAN}📁 Fichier source: $INPUT_FILE${NC}"
echo -e "${CYAN}🎨 Format demandé: $FORMAT${NC}"

# Vérifier si le fichier source existe
if [ ! -f "$INPUT_FILE" ]; then
    echo -e "${RED}❌ Erreur: Le fichier $INPUT_FILE n'existe pas!${NC}"
    exit 1
fi

# Vérifier si Pandoc est installé
if ! command -v pandoc &> /dev/null; then
    echo -e "${YELLOW}❌ Pandoc n'est pas installé. Installation en cours...${NC}"
    
    # Détecter le système d'exploitation
    if [[ "$OSTYPE" == "linux-gnu"* ]]; then
        # Linux
        if command -v apt-get &> /dev/null; then
            sudo apt-get update && sudo apt-get install -y pandoc
        elif command -v yum &> /dev/null; then
            sudo yum install -y pandoc
        elif command -v dnf &> /dev/null; then
            sudo dnf install -y pandoc
        else
            echo -e "${RED}❌ Impossible d'installer Pandoc automatiquement${NC}"
            echo -e "${CYAN}💡 Installez Pandoc manuellement: https://pandoc.org/installing.html${NC}"
            exit 1
        fi
    elif [[ "$OSTYPE" == "darwin"* ]]; then
        # macOS
        if command -v brew &> /dev/null; then
            brew install pandoc
        else
            echo -e "${RED}❌ Homebrew n'est pas installé${NC}"
            echo -e "${CYAN}💡 Installez Homebrew: https://brew.sh${NC}"
            exit 1
        fi
    else
        echo -e "${RED}❌ Système d'exploitation non supporté${NC}"
        exit 1
    fi
    
    echo -e "${GREEN}✅ Pandoc installé avec succès!${NC}"
fi

# Fonction de conversion
convert_presentation() {
    local format=$1
    
    case $format in
        "pptx")
            echo -e "${YELLOW}🔄 Conversion en PowerPoint...${NC}"
            if pandoc "$INPUT_FILE" -o "$OUTPUT_PREFIX.pptx" --slide-level=2; then
                echo -e "${GREEN}✅ Présentation PowerPoint créée: $OUTPUT_PREFIX.pptx${NC}"
            else
                echo -e "${RED}❌ Erreur lors de la conversion PowerPoint${NC}"
            fi
            ;;
        "pdf")
            echo -e "${YELLOW}🔄 Conversion en PDF...${NC}"
            # Essayer d'abord avec xelatex
            if pandoc "$INPUT_FILE" -o "$OUTPUT_PREFIX.pdf" --pdf-engine=xelatex; then
                echo -e "${GREEN}✅ PDF créé avec LaTeX: $OUTPUT_PREFIX.pdf${NC}"
            else
                echo -e "${YELLOW}⚠️ LaTeX non disponible, tentative avec wkhtmltopdf...${NC}"
                if pandoc "$INPUT_FILE" -o "$OUTPUT_PREFIX.pdf" --pdf-engine=wkhtmltopdf; then
                    echo -e "${GREEN}✅ PDF créé avec wkhtmltopdf: $OUTPUT_PREFIX.pdf${NC}"
                else
                    echo -e "${RED}❌ Erreur lors de la conversion PDF${NC}"
                    echo -e "${CYAN}💡 Installez LaTeX ou wkhtmltopdf pour la conversion PDF${NC}"
                fi
            fi
            ;;
        "html")
            echo -e "${YELLOW}🔄 Conversion en HTML...${NC}"
            if pandoc "$INPUT_FILE" -o "$OUTPUT_PREFIX.html" --standalone; then
                echo -e "${GREEN}✅ HTML créé: $OUTPUT_PREFIX.html${NC}"
            else
                echo -e "${RED}❌ Erreur lors de la conversion HTML${NC}"
            fi
            ;;
        "all")
            echo -e "${YELLOW}🔄 Conversion en tous formats...${NC}"
            convert_presentation "pptx"
            convert_presentation "pdf"
            convert_presentation "html"
            ;;
        *)
            echo -e "${RED}❌ Format non supporté: $format${NC}"
            echo -e "${CYAN}💡 Formats supportés: pptx, pdf, html, all${NC}"
            ;;
    esac
}

# Exécuter la conversion
convert_presentation "$FORMAT"

# Afficher les fichiers créés
echo -e "\n${GREEN}📊 Fichiers créés:${NC}"
for file in "$OUTPUT_PREFIX".*; do
    if [ -f "$file" ]; then
        size=$(du -h "$file" | cut -f1)
        echo -e "${CYAN}📄 $file ($size)${NC}"
    fi
done

echo -e "\n${GREEN}🎉 Conversion terminée!${NC}"
echo -e "${GREEN}🚀 Prêt pour votre présentation client!${NC}" 