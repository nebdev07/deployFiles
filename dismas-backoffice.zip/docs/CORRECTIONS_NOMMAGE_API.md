# 🔧 CORRECTIONS NOMMAGE API - Frontend ↔️ Backend

**Date** : 2025-10-12  
**Problème** : Incohérence entre les noms de champs frontend et backend  
**Statut** : ✅ **CORRIGÉ**

---

## 🎯 PROBLÈME IDENTIFIÉ

Le **frontend** utilisait des noms d'entités "métier" (`Reception`, `CatalogueReception`) alors que le **backend** utilise les noms techniques (`Mouvement`, `CatalogueMouvement`).

---

## 📋 CORRECTIONS APPLIQUÉES

### **1. Endpoints**

| Avant (❌) | Après (✅) | Raison |
|-----------|-----------|--------|
| `/reception` | `/mouvement` | Entité backend = `Mouvement` |
| `/MouvementFiles` | `/mouvementFiles` | Cohérence camelCase |
| `/CatalogueMouvement` | `/catalogueMouvement` | Cohérence camelCase |
| `/MatiereQuantite` | `/matiereQuantite` | Cohérence camelCase |

---

### **2. Champs des payloads**

#### **CatalogueMouvement (catalogue-réception)**

**Avant** (❌) :
```json
{
  "idReception": 5,
  "idCatalogue": 1,
  "statut": "ACTIF"
}
```

**Après** (✅) :
```json
{
  "idMouvement": 5,      // CORRECTION: Backend attend idMouvement
  "idCatalogue": 1,
  "statut": "ACTIF"
}
```

**Fichier modifié** : `reception.service.ts` ligne 455

---

#### **MatiereQuantite**

**Avant** (❌) :
```json
{
  "idCatalogueReception": 123,
  "idMatiere": 10,
  "quantiteRecue": 100
}
```

**Après** (✅) :
```json
{
  "idCatalogueMouvement": 123,   // CORRECTION: Backend attend idCatalogueMouvement
  "idMatiere": 10,
  "quantiteRecue": 100
}
```

**Fichier modifié** : `reception.service.ts` ligne 507

---

#### **MouvementFiles (fichiers)**

**Avant** (❌) :
```json
{
  "idReception": 5,
  "fileName": "bordereau.pdf"
}
```

**Après** (✅) :
```json
{
  "idMouvement": 5,      // CORRECTION: Backend attend idMouvement
  "fileName": "bordereau.pdf"
}
```

**Fichier modifié** : `reception.service.ts` ligne 381

---

## 📝 RÉSUMÉ DES MODIFICATIONS

### **reception.service.ts**

| Ligne | Modification | Description |
|-------|--------------|-------------|
| 63 | `private filesEndpoint = '/mouvementFiles'` | Endpoint fichiers en camelCase |
| 64 | `private catalogueReceptionEndpoint = '/catalogueMouvement'` | Endpoint catalogue en camelCase |
| 381 | `idMouvement: receptionId` | Upload fichier |
| 455 | `idMouvement: receptionId` | Création catalogue-mouvement |
| 507 | `idCatalogueMouvement: catalogueReceptionId` | Création matière-quantité |

---

## ✅ RÉSULTAT

**Avant** :
```
❌ POST /CatalogueMouvement/create
   { idReception: 5 }
   → Erreur: "Champ non renseigne: idMouvement"
```

**Après** :
```
✅ POST /catalogueMouvement/create
   { idMouvement: 5 }
   → Succès !
```

---

## 🎯 CONVENTION APPLIQUÉE

| Type | Convention Backend | Exemple |
|------|-------------------|---------|
| **Entité** | PascalCase | `Mouvement`, `CatalogueMouvement` |
| **Endpoint** | camelCase | `/mouvement`, `/catalogueMouvement` |
| **Champ DTO** | camelCase avec `id` préfixe | `idMouvement`, `idCatalogueMouvement` |

---

## 🧪 TEST

**Payload de test** :

```json
{
  "user": 3,
  "token": "...",
  "datas": [{
    "idMouvement": 5,
    "idCatalogue": 1,
    "statut": "ACTIF"
  }]
}
```

**Résultat attendu** :

```json
{
  "status": {
    "code": "200",
    "message": "Operation effectuee avec succes"
  },
  "items": [{
    "id": 123,
    "idMouvement": 5,
    "idCatalogue": 1,
    "statut": "ACTIF"
  }],
  "hasError": false
}
```

---

**Les corrections sont appliquées ! Le frontend et le backend sont maintenant cohérents.** ✅

