# Plan d'implémentation – Page Stock (analyse) – Zéro régression

## Principe

- **Périmètre modifié** : uniquement `lib/services/stock.service.ts` et `app/stocks/page.tsx`.
- **Aucun autre fichier** : pas de modification de `mouvement.service`, `distribution.service`, `reception.service`, ni des composants qui les utilisent (DistributionForm, ValidationIEPPModal, RedistribuerStockModalV2, StockWidget).
- **Contract** : la page Stocks continue d’utiliser les types `StockByStructure` et `StockData[]` ; seul le service change la **source** des données (endpoints `/stock/*` + mapping).

---

## 1. Cartographie des usages (régression)

| Fichier | API utilisée | Action |
|---------|--------------|--------|
| **app/stocks/page.tsx** | `stockService.getStockByStructure`, `stockService.getAllStocksByStructure` | **Modifier** (appeler nouveau flux) |
| **lib/services/stock.service.ts** | `/distributionEleve/getStock/...` | **Modifier** (basculer sur `/stock/*` + mapping) |
| **lib/services/mouvement.service.ts** | `/stock/disponible`, `/stock/structure/.../annee/...` | **Ne pas toucher** |
| **components/modals/ValidationIEPPModal.tsx** | `mouvementService.getStockDisponible` | **Ne pas toucher** |
| **components/modals/RedistribuerStockModalV2.tsx** | `mouvementService.getStocksByStructureAndAnnee` + fetch distributionEleve | **Ne pas toucher** |
| **lib/services/distribution.service.ts** | `distributionEleve/getStock` | **Ne pas toucher** |
| **components/forms/DistributionForm.tsx** | `distributionService.getStockDisponible` | **Ne pas toucher** |
| **lib/services/reception.service.ts** | `reception/...getStock` | **Ne pas toucher** |
| **components/StockWidget.tsx** | `receptionService.getStock` | **Ne pas toucher** |

Conclusion : **seuls `stock.service.ts` et `app/stocks/page.tsx` sont modifiés.** Aucun autre module n’utilise `stockService` → **0 régression** sur Distribution, Réception, Régulation, Validation IEPP, etc.

---

## 2. Phases d’implémentation

### Phase 0 – Prérequis (vérification)

- [ ] Backend : `GET /stock/structure/{structureId}/annee/{anneeScolaireId}` disponible et retourne `items` (liste de `StockDisponibleDto`).
- [ ] Frontend : `apiConfig.baseUrl` utilisé par `BaseApiService` (déjà le cas) → les appels `this.get('/stock/...')` ciblent le bon host.

---

### Phase 1 – Service Stock (sans casser la page)

**Fichier** : `lib/services/stock.service.ts`

1. **Ajouter** une méthode dédiée à la page, sans modifier encore les signatures existantes :
   - `getStocksForPage(structureId: number, anneeScolaireId: number): Promise<StockServiceResponse<{ structure: StockByStructure; allStocks: StockData[] }>>`
   - Implémentation :
     - Appel `this.get(\`/stock/structure/${structureId}/annee/${anneeScolaireId}\`)`.
     - Lire `(response as any).items` (liste DTO backend).
     - Si `response.hasError` ou pas d’items → retourner `{ success: false, data: null, message }`.
     - Mapper chaque item DTO vers `StockData` :
       - `quantiteDisponible` → `stockDisponible`
       - `quantiteReceptions` → `stockReception`
       - `quantiteDistributions` → `stockDistribution`
       - `structureLibelle`, `structureCode`, `matiereCode`, `matiereLibelle` → idem
       - `statut` : si `estEnRupture === true` → `'EPUISE'`, sinon si `quantiteDisponible < (seuilCritique ?? 10)` → `'CRITIQUE'`, sinon `'OK'`.
     - Construire `StockByStructure` :
       - `structureId`, `structureLibelle`, `structureCode` depuis le premier item (ou défaut).
       - `stockTotal` = somme des `quantiteDisponible`.
       - `derniereMiseAJour` = max des `updatedAt` ou chaîne vide.
       - `statutGlobal` = dérivé (ex. EPUISE si au moins une rupture, sinon CRITIQUE si au moins un critique, sinon BON).
       - `matieres` = `[]` (la page utilise `allStocks`).
     - Retourner `{ success: true, data: { structure, allStocks }, message }`.

2. **Ne pas modifier** pour l’instant :
   - `getStockByStructure`, `getStockByMatiere`, `getAllStocksByStructure` (la page ne les appellera plus après Phase 2, mais on peut les laisser pour d’éventuels autres appels ou les déprécier plus tard).

3. **Tests de non-régression** :
   - Aucun autre fichier n’appelle `getStocksForPage` tant que la page n’est pas mise à jour → pas d’impact.
   - Vérifier que le build TypeScript passe.

---

### Phase 2 – Page Stocks (année + un seul appel)

**Fichier** : `app/stocks/page.tsx`

1. **Année scolaire**
   - Importer `useAnneesScolaires` (ou `anneeScolaireService.getAnneesScolaires` avec filtre `estCourante` si vous préférez).
   - État : `const [anneeScolaireId, setAnneeScolaireId] = useState<number | null>(null)`.
   - Au montage (ou après chargement user) : charger les années actives, définir `anneeScolaireId` sur l’année courante (celle avec `estCourante === true`) ou la première de la liste.
   - Afficher un **sélecteur d’année** (dropdown) dans le header de la page ; à chaque changement, `setAnneeScolaireId(id)` et relancer `loadStockData()`.

2. **Chargement des données**
   - Dans `loadStockData()` :
     - Ne plus appeler `getStockByStructure` ni `getAllStocksByStructure`.
     - Si `!anneeScolaireId` → ne pas appeler l’API (ou attendre que l’année soit sélectionnée).
     - Appeler `stockService.getStocksForPage(user.structure.id, anneeScolaireId)`.
     - En cas de succès : `setStockData(data.structure)`, `setAllStocks(data.allStocks)`.
     - En cas d’erreur : `setError(...)`, `toast.error(...)` comme aujourd’hui.

3. **Conserver**
   - Toute la logique d’affichage existante : `getStocksByRole`, `roleStockData`, `getStatutBadge`, stats (Stock total, Alertes, etc.), onglets, modals (squelettes).
   - Les types importés : `StockByStructure`, `StockData` (inchangés).

4. **Tests de non-régression**
   - Ouvrir la page Stocks : sélecteur d’année visible, données chargées (ou message « Aucune donnée » si backend vide).
   - Vérifier que Dashboard, Distribution, Réceptions, Régulation, Validation IEPP, Redistribuer stock, StockWidget fonctionnent comme avant (aucun fichier modifié côté distribution/reception/mouvement).

---

### Phase 3 – Optionnel (améliorations sans régression)

- **Onglet Ruptures** : ajouter un onglet « Ruptures » qui appelle `GET /stock/rupture/structure/{id}/annee/{anneeId}` (nouvelle méthode dans `stock.service` retournant `StockData[]` mappé) et affiche la liste. La page reste la seule à utiliser le service Stock.
- **Résumé** : appeler `GET /stock/resume/structure/{id}/annee/{id}` (nouvelle méthode dans `stock.service`) et afficher le texte dans la vue d’ensemble.
- **Nettoyage** : après validation, supprimer ou déprécier `getStockByStructure` / `getStockByMatiere` / `getAllStocksByStructure` dans `stock.service` si plus utilisés nulle part.

---

## 3. Mapping DTO backend → StockData (référence)

Pour chaque élément de `response.items` (StockDisponibleDto) :

| StockData (frontend) | Source backend (StockDisponibleDto) |
|---------------------|------------------------------------|
| structureId | structureId |
| structureLibelle | structureLibelle |
| structureCode | structureCode |
| matiereId | matiereId |
| matiereCode | matiereCode |
| matiereLibelle | matiereLibelle |
| stockDisponible | quantiteDisponible |
| stockReception | quantiteReceptions |
| stockDistribution | quantiteDistributions |
| statut | estEnRupture ? 'EPUISE' : (quantiteDisponible < seuil ? 'CRITIQUE' : 'OK') |

`seuil` = 10 par défaut (ou champ backend si disponible plus tard).

---

## 4. Gestion des réponses backend

- Le backend renvoie `Response<T>` avec `items` (liste), `hasError`, `status.message`.
- Dans `stock.service`, utiliser la même logique que dans `mouvement.service` :
  - Vérifier `!response.hasError` et présence de `response.items`.
  - Ne pas s’appuyer sur `response.success` si le contrat frontend utilise `hasError` (vérifier dans `base-api.service` comment `get()` mappe la réponse).

---

## 5. Checklist finale (zéro régression)

- [ ] Seuls `stock.service.ts` et `app/stocks/page.tsx` sont modifiés.
- [ ] Aucune modification dans `mouvement.service.ts`, `distribution.service.ts`, `reception.service.ts`.
- [ ] Aucune modification dans `DistributionForm`, `ValidationIEPPModal`, `RedistribuerStockModalV2`, `StockWidget`.
- [ ] Page Stocks : année scolaire requise, un seul appel `getStocksForPage(structureId, anneeScolaireId)`.
- [ ] Types `StockByStructure` et `StockData` inchangés (compatibilité affichage).
- [ ] Build TS OK.
- [ ] Tests manuels : Stocks avec année ; Distribution ; Réceptions ; Régulation ; Validation IEPP ; Redistribuer stock.

---

## 6. Ordre d’exécution recommandé

1. Implémenter **Phase 1** (`getStocksForPage` dans `stock.service.ts` + mapping).
2. Vérifier le build et que la page actuelle ne casse pas (elle continue d’appeler les anciennes méthodes tant qu’on n’a pas fait la Phase 2).
3. Implémenter **Phase 2** (page : année + appel `getStocksForPage`, suppression des appels à `getStockByStructure` / `getAllStocksByStructure`).
4. Tester la page Stocks puis les autres écrans listés ci-dessus.
5. Optionnel : Phase 3 (ruptures, résumé, nettoyage des anciennes méthodes).

Ce plan garantit une implémentation **sans régression** sur les flux existants (distribution, réception, régulation, validation IEPP).
