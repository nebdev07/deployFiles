# 🔄 REDÉMARRER LE FRONTEND APRÈS MODIFICATIONS

**Date** : 2025-10-11  
**Raison** : Modifications dans `mouvement.service.ts` et `base-api.service.ts`

---

## 🛑 ÉTAPE 1 : ARRÊTER LE SERVEUR

**Dans le terminal où le frontend tourne** :

```bash
# Arrêter avec Ctrl+C
Ctrl + C
```

---

## 🧹 ÉTAPE 2 : VIDER LE CACHE DU NAVIGATEUR

**Option 1 - Chrome/Edge** :
1. Ouvrir **DevTools** (F12)
2. Clic droit sur le bouton **Actualiser** ↻
3. Sélectionner **"Vider le cache et actualiser de force"**

**Option 2 - Raccourci clavier** :
```
Ctrl + Shift + Delete
→ Cocher "Images et fichiers en cache"
→ Cocher "Cookies et données de site"
→ Effacer
```

**Option 3 - Console navigateur** :
```javascript
// Vider le localStorage
localStorage.clear()

// Puis recharger
location.reload()
```

---

## ▶️ ÉTAPE 3 : REDÉMARRER LE FRONTEND

**Dans le terminal** :

```bash
# Si vous utilisez npm
npm run dev

# Si vous utilisez pnpm
pnpm dev

# Si vous utilisez yarn
yarn dev
```

---

## 🔐 ÉTAPE 4 : SE RECONNECTER

1. Ouvrir l'application dans le navigateur
2. **Se connecter à nouveau** avec vos identifiants
3. **Vérifier dans la console** (F12) :

```javascript
// Vérifier que le token est bien sauvegardé
console.log('Token:', localStorage.getItem('auth_token'))
console.log('User:', JSON.parse(localStorage.getItem('dismas_user')))
```

---

## ✅ ÉTAPE 5 : TESTER

1. Naviguer vers **`/receptions`**
2. Vérifier dans **Network** (F12) :
   - Requête `POST /mouvement/getByCriteria`
   - **Payload** doit contenir :
     ```json
     {
       "user": 3,
       "token": "kgsDSw...",
       "data": { ... }  // ✅ Objet, pas array
     }
     ```
   - **Headers** doit contenir :
     ```
     Session-Key: kgsDSw...
     ```

3. ✅ **Vérifier** : Pas de message "Session expirée"

---

## 🔍 SI LE PROBLÈME PERSISTE

**Exécutez ce script dans la console** :

```javascript
// Diagnostic complet
const diagnostic = {
  // localStorage
  token: localStorage.getItem('auth_token')?.substring(0, 20) + '...',
  tokenLength: localStorage.getItem('auth_token')?.length,
  user: JSON.parse(localStorage.getItem('dismas_user') || 'null'),
  expiry: localStorage.getItem('token_expiry'),
  
  // Vérification expiration
  isExpired: new Date(localStorage.getItem('token_expiry')) <= new Date(),
  minutesRemaining: Math.floor((new Date(localStorage.getItem('token_expiry')) - new Date()) / 1000 / 60)
};

console.log('=== DIAGNOSTIC COMPLET ===');
console.table(diagnostic);

// Si le token est expiré
if (diagnostic.isExpired) {
  console.error('❌ LE TOKEN EST EXPIRÉ ! Reconnectez-vous.');
} else {
  console.log('✅ Token valide pour encore', diagnostic.minutesRemaining, 'minutes');
}
```

---

## 📋 COMMANDES UTILES

### **Redémarrer complètement**

```bash
# 1. Arrêter le frontend
Ctrl + C

# 2. Vider le cache npm/node_modules (si nécessaire)
rm -rf .next

# 3. Redémarrer
npm run dev
```

### **Vérifier le processus frontend**

```powershell
# Windows PowerShell
Get-Process | Where-Object {$_.ProcessName -like "*node*"}

# Tuer tous les processus node si nécessaire
Get-Process | Where-Object {$_.ProcessName -like "*node*"} | Stop-Process -Force
```

---

## 🎯 RÉSUMÉ

1. ✅ **Arrêter** le frontend (Ctrl+C)
2. ✅ **Vider** le cache navigateur
3. ✅ **Redémarrer** le frontend (`npm run dev`)
4. ✅ **Se reconnecter**
5. ✅ **Tester** `/receptions`

---

**Si après ces étapes le problème persiste, exécutez le script de diagnostic et partagez-moi les résultats.**

