# Analyse des Impacts : Besoin Multi-Niveaux

## 🎯 OBJECTIF

**Un seul besoin visible par structure et par année scolaire** – éviter à l'utilisateur de voir plusieurs besoins (CP, CE1, CE2, etc.) pour la même structure et la même année.

## 📊 ÉTAT ACTUEL

| Composant | Comportement actuel |
|-----------|---------------------|
| **Besoin** | 1 Besoin = 1 Niveau (unicité `structureId + anneeScolaireId + niveauScolaireId`) |
| **BesoinDetail** | Pas de `niveauScolaireId` – hérite du niveau du Besoin parent |
| **Consolidation** | Utilise `besoinEpp.getNiveauScolaire().getId()` (ligne 1004 BesoinBusiness) |
| **Approbation** | `findByBesoinId` – pas de distinction par niveau dans les détails |
| **Frontend** | BesoinForm crée déjà 1 besoin par niveau quand plusieurs catalogues sélectionnés |

## ✅ SOLUTION CHOISIE : Option 1

**Ajouter `niveauScolaireId` dans BesoinDetail** et **changer l'unicité Besoin** à `structureId + anneeScolaireId`.

### Modifications requises

#### Phase 1 : Backend

1. **Migration SQL** : `ALTER TABLE besoin_detail ADD niveau_scolaire_id INT NULL`
2. **BesoinDetail entity** : Ajouter `@ManyToOne NiveauScolaire niveauScolaire` + colonne
3. **BesoinDetailDto** : Ajouter `niveauScolaireId`, `niveauScolaireCode`, `niveauScolaireLibelle`
4. **BesoinDetailTransformer** : Mapper `niveauScolaire`
5. **BesoinRepository** : Nouvelle méthode `findByStructureIdAndAnneeScolaireId` (existe déjà)
6. **BesoinBusiness create** :
   - Vérifier unicité par structure+annee (pas par niveau)
   - Pour Besoin multi-niveau : `niveauScolaireId` = premier niveau des détails (compatibilité)
   - Pour chaque BesoinDetail : set `niveauScolaireId` depuis le catalogue/données
7. **BesoinBusiness consolidate** : Utiliser `detail.getNiveauScolaire() != null ? detail.getNiveauScolaire().getId() : besoinEpp.getNiveauScolaire().getId()`
8. **BesoinDetailBusiness** : Gérer `niveauScolaireId` à la création
9. **BesoinDetailRepository** : Critère `niveauScolaireId` dans generateCriteria si besoin

#### Phase 2 : Frontend

1. **BesoinDetailData** : Ajouter `niveauScolaireId?: number`
2. **BesoinForm** : Créer UN seul besoin avec tous les détails (chacun avec `niveauScolaireId`)
3. **Page besoins** : Afficher 1 ligne par structure/année (regrouper si nécessaire)
4. **Affichage** : Détails groupés par niveau dans la vue

## ⚠️ POINTS DE VIGILANCE

- **Migration données existantes** : `UPDATE besoin_detail bd JOIN besoin b ON bd.besoin_id = b.id SET bd.niveau_scolaire_id = b.niveau_scolaire_id WHERE bd.niveau_scolaire_id IS NULL`
- **Contrainte Besoin** : Supprimer la vérification d'unicité par niveau ; autoriser 1 besoin par structure+annee
- **Réception/Distribution** : Vérifier que `getForReception` et flux associés gèrent les détails multi-niveaux

## 📁 FICHIERS IMPACTÉS

### Backend
- `BesoinDetail.java`, `BesoinDetailDto.java`, `BesoinDetailTransformer.java`
- `BesoinBusiness.java` (create, consolidate)
- `BesoinDetailBusiness.java`
- `BesoinRepository.java` (logique unicité dans Business)
- `BesoinDetailRepository.java` / `_BesoinDetailRepository.java`

### Frontend
- `BesoinForm.tsx`, `besoins.service.ts`
- `app/besoins/page.tsx`
- `lib/types/entities.ts` (si utilisé)
