# 📊 Analyse : Gestion du Cas "IEPP sans Stock" lors de la Création d'une Réception EPP

## 🎯 Contexte

Lorsqu'un EPP essaie de créer une nouvelle réception alors que son IEPP parent n'a **aucun stock disponible**, comment est-ce géré dans les deux versions ?

---

## 🔄 VERSION "GOOD" (Ancienne)

### 1. Ouverture du Modal ✅

**Fonction :** `handleNouvelleReception()` (lignes 652-682)

```typescript
const handleNouvelleReception = async () => {
  // Déterminer le type de réception selon le rôle
  if (user.role.code === "IEPP") {
    setReceptionType("IEPP")
  } else if (user.role.code === "DIRECTEUR") {
    setReceptionType("EPP")
  }

  // Récupérer tous les catalogues actifs disponibles
  await fetchAvailableCatalogues()

  // Initialiser les données du formulaire
  setReceptionFormData({...})

  // Réinitialiser les états
  setSelectedCatalogueId('')
  setCurrentCatalogueData(null)
  setCatalogueMatieres([])
  setSelectedCatalogues([])

  setShowNouvelleReceptionModal(true) // ✅ Modal s'ouvre TOUJOURS
}
```

**Comportement :**
- ✅ Le modal s'ouvre **TOUJOURS**, même si l'IEPP n'a pas de stock
- ❌ **Aucune vérification préventive** du stock avant l'ouverture
- ⚠️ L'utilisateur peut remplir le formulaire et essayer de créer la réception

---

### 2. Validation du Stock lors de la Création ⚠️

**Fonction :** Dans le handler du bouton "Créer la Réception" (lignes 1685-1738)

```typescript
if (receptionFormData.type === "EPP") {
  // ✅ Validation du stock AVANT la création de la réception
  console.log('🔍 Validation du stock IEPP avant création réception EPP...')
  
  // Préparer les données de validation
  const stockValidationData = {
    idStructure: user.structure?.parentId || user.structure?.id || 0,
    matiereQuantites: selectedCatalogues.flatMap((catalogue: any) =>
      catalogue.quantitesSaisies.map((q: any) => ({
        idMatiere: q.matiereId,
        matiereLibelle: q.libelle,
        quantiteRecue: q.quantite_recue,
        idNiveauScolaire: q.idNiveauScolaire || catalogue.niveauScolaireId,
        niveauScolaireLibelle: q.niveauScolaireLibelle || catalogue.niveauScolaire,
        niveauScolaireCode: q.niveauScolaireCode || catalogue.niveauCode
      }))
    )
  }
  
  // Appel au backend pour validation
  const stockValidation = await receptionService.validateStockBeforeEPP(stockValidationData)
  
  if (!stockValidation.success) {
    // ❌ Stock insuffisant - Afficher message d'erreur
    const errorMessage = stockValidation.message || 'Stock insuffisant'
    toast.error(
      <div className="max-w-md">
        <div className="font-semibold text-red-800 mb-2">❌ Stock insuffisant</div>
        <div className="text-sm text-red-700 whitespace-pre-line">
          {errorMessage}
        </div>
        <div className="text-xs text-red-600 mt-2">
          Veuillez réduire les quantités demandées ou contacter l'administrateur.
        </div>
      </div>,
      {
        duration: 8000,
        position: 'top-center',
        style: {
          background: '#fef2f2',
          border: '1px solid #fecaca',
          color: '#991b1b'
        }
      }
    )
    return // ❌ Arrête la création, mais le modal reste ouvert
  }
  
  console.log('✅ Stock validé avec succès')
}
```

**Comportement :**
- ⚠️ Validation **frontend** (peut être contournée)
- ⚠️ Validation **après** que l'utilisateur ait rempli le formulaire
- ❌ Le modal **reste ouvert** même si le stock est insuffisant
- ⚠️ L'utilisateur doit **réessayer** ou **modifier les quantités**

**Endpoint Backend :** `validateStockBeforeEPPMouvement`
- Recalcule le stock depuis `MatiereQuantite` (lent)
- Vérifie le stock IEPP parent

---

## 🔄 VERSION ACTUELLE (Nouvelle)

### 1. Vérification Préventive du Stock ✅

**Fonction :** `handleNouvelleReception()` (lignes 749-849)

```typescript
const handleNouvelleReception = async () => {
  // Déterminer le type de réception selon le rôle
  if (user.role.code === "IEPP") {
    setReceptionType("IEPP")
  } else if (user.role.code === "DIRECTEUR") {
    setReceptionType("EPP")
  }

  // ✅ NOUVEAU : Pour les réceptions EPP, vérifier que l'IEPP parent a du stock disponible
  if (user.role.code === "DIRECTEUR") {
    try {
      console.log('🔍 Vérification du stock IEPP parent avant ouverture du modal...')
      
      // Récupérer les catalogues pour vérifier le stock
      await fetchAvailableCatalogues()
      
      if (availableCatalogues.length === 0) {
        toast.error(
          <div className="max-w-md">
            <div className="font-semibold text-red-800 mb-2">❌ Aucun catalogue disponible</div>
            <div className="text-sm text-red-700">
              Aucun catalogue actif n'est disponible pour créer une réception.
            </div>
          </div>
        )
        return // ❌ Ne pas ouvrir le modal
      }

      // Vérifier le stock de l'IEPP parent pour au moins une matière du premier catalogue
      let hasStock = false
      let stockCheckCount = 0
      const maxStockChecks = 3 // Vérifier 3 matières au maximum pour performance

      for (const catalogue of availableCatalogues.slice(0, 2)) {
        if (stockCheckCount >= maxStockChecks) break
        
        // Charger les matières du catalogue
        const matieresResult = await catalogueService.getCatalogueMatieres(catalogue.id)
        if (matieresResult.success && matieresResult.data && matieresResult.data.length > 0) {
          // Vérifier le stock pour les premières matières
          for (const matiere of matieresResult.data.slice(0, 2)) {
            if (stockCheckCount >= maxStockChecks) break
            
            const stockResponse = await receptionService.getStock(
              user.structure?.parentId || user.structure?.id || 0,
              matiere.id
            )
            
            if (stockResponse.success && stockResponse.data) {
              const stockDisponible = stockResponse.data.stockDisponible || 0
              if (stockDisponible > 0) {
                hasStock = true
                break
              }
            }
            stockCheckCount++
          }
        }
        
        if (hasStock) break
      }

      // ✅ Si aucun stock n'a été trouvé, afficher un message et empêcher l'ouverture du modal
      if (!hasStock) {
        toast.error(
          <div className="max-w-md">
            <div className="font-semibold text-red-800 mb-2">❌ Stock IEPP insuffisant</div>
            <div className="text-sm text-red-700 mb-2">
              Votre IEPP parent n'a actuellement aucun stock disponible pour créer une réception.
            </div>
            <div className="text-xs text-red-600">
              Veuillez contacter votre IEPP pour plus d'informations ou réessayer plus tard.
            </div>
          </div>,
          {
            duration: 8000,
            position: 'top-center',
            style: {
              background: '#fef2f2',
              border: '1px solid #fecaca',
              color: '#991b1b',
              maxWidth: '500px'
            }
          }
        )
        console.warn('⚠️ Modal non ouvert : Stock IEPP insuffisant')
        return // ❌ Ne pas ouvrir le modal
      }
    } catch (error) {
      console.error('❌ Erreur lors de la vérification du stock IEPP:', error)
      toast.error('Erreur lors de la vérification du stock IEPP.')
      return // ❌ Ne pas ouvrir le modal en cas d'erreur
    }
  }

  // ✅ Si tout est OK, initialiser et ouvrir le modal
  setReceptionFormData({...})
  setSelectedCatalogueId('')
  setCurrentCatalogueData(null)
  setCatalogueMatieres([])
  setSelectedCatalogues([])
  setShowNouvelleReceptionModal(true)
}
```

**Comportement :**
- ✅ **Vérification préventive** du stock **AVANT** l'ouverture du modal
- ✅ Le modal **ne s'ouvre pas** si aucun stock n'est disponible
- ✅ Message d'erreur **immédiat** et **clair**
- ⚠️ Vérifie seulement **3 matières maximum** (optimisation performance)

---

### 2. Validation du Stock lors de la Création ✅

**Fonction :** Dans le handler du bouton "Créer la Réception" (lignes 1970-2029)

```typescript
if (isReceptionEPPDirecte) {
  // ✅ Flow Réception EPP Directe avec validation stock automatique
  console.log('🔄 Flow Réception EPP Directe : utilisation de createReceptionEPP (validation stock automatique)')
  
  // Préparer les données avec CatalogueMouvements
  receptionData.catalogueMouvements = selectedCatalogues.map((catalogue: any) => ({
    idCatalogue: catalogue.id,
    matiereQuantites: catalogue.quantitesSaisies
      .filter((q: any) => q.quantite_recue > 0)
      .map((q: any) => ({
        idMatiere: q.matiereId,
        quantiteRecue: q.quantite_recue,
        quantitePrevue: q.quantite_prevue || q.quantite_recue,
        idNiveauScolaire: q.idNiveauScolaire ?? catalogue.niveauId ?? catalogue.idNiveauScolaire,
        niveauScolaireCode: q.niveauScolaireCode ?? catalogue.niveauCode,
        niveauScolaireLibelle: q.niveauScolaireLibelle ?? catalogue.niveauScolaire
      }))
  }))
  
  // ✅ Appel au backend avec validation stock automatique
  const receptionResponse = await mouvementService.createReceptionEPP(receptionData)
  
  if (!receptionResponse.success) {
    const errorMessage = receptionResponse.message || 'Erreur lors de la création de la réception EPP'
    
    // Détecter si c'est une erreur de stock insuffisant
    const isStockError = errorMessage.includes('Stock insuffisant') || 
                       errorMessage.includes('Disponible:') || 
                       errorMessage.includes('Demandé:')
    
    toast.error(
      <div className="max-w-lg">
        <div className="font-semibold text-red-800 mb-2">
          {isStockError ? '❌ Stock IEPP insuffisant' : '❌ Erreur de création'}
        </div>
        <div className="text-sm text-red-700 whitespace-pre-line">
          {errorMessage}
        </div>
        <div className="text-xs text-red-600 mt-2">
          {isStockError 
            ? 'Veuillez réduire les quantités demandées ou contacter l\'administrateur.'
            : 'Veuillez vérifier vos données et réessayer.'
          }
        </div>
      </div>,
      {
        duration: isStockError ? 10000 : 6000,
        position: 'top-center',
        style: {
          background: '#fef2f2',
          border: '1px solid #fecaca',
          color: '#991b1b',
          maxWidth: '500px'
        }
      }
    )
    throw new Error(errorMessage) // ❌ Arrête la création
  }
  
  console.log('✅ Réception EPP créée avec succès (stock IEPP validé), ID:', receptionId)
}
```

**Endpoint Backend :** `createReceptionEPP` → `validateIEPPStockForReceptionEPP`
- ✅ Utilise directement la table `StockDisponible` (rapide, fiable)
- ✅ Validation **backend** (non contournable)
- ✅ Vérifie le stock IEPP parent pour **toutes** les matières demandées

**Comportement :**
- ✅ Validation **backend** (sécurisée)
- ✅ Validation **avant** la création de la réception
- ❌ Si validation échoue, la réception **n'est pas créée**
- ⚠️ Le modal **reste ouvert** (l'utilisateur peut modifier les quantités)

---

## 📊 COMPARAISON DÉTAILLÉE

| Aspect | Version "Good" | Version Actuelle | Impact |
|--------|---------------|------------------|--------|
| **Vérification préventive** | ❌ Non | ✅ Oui (avant ouverture modal) | 🟢 **Amélioration UX** |
| **Ouverture modal si stock = 0** | ✅ Oui (toujours) | ❌ Non (bloqué) | 🟢 **Amélioration UX** |
| **Validation stock** | ⚠️ Frontend | ✅ Backend | 🔴 **Amélioration sécurité** |
| **Source validation stock** | ⚠️ MatiereQuantite (recalcul) | ✅ StockDisponible (table) | 🟢 **Amélioration performance** |
| **Moment validation** | ⚠️ Après remplissage formulaire | ✅ Avant ouverture + lors création | 🟢 **Amélioration UX** |
| **Message d'erreur** | ⚠️ Après tentative création | ✅ Avant ouverture modal | 🟢 **Amélioration UX** |
| **Modal reste ouvert si erreur** | ✅ Oui | ✅ Oui | ⚠️ Identique |
| **Performance** | ⚠️ Recalcul lent | ✅ Table matérialisée rapide | 🟢 **Amélioration performance** |

---

## 🎯 SCÉNARIOS D'UTILISATION

### Scénario 1 : IEPP n'a AUCUN stock (stock = 0 pour toutes les matières)

#### Version "Good" ❌
1. ✅ Utilisateur clique sur "Nouvelle Réception"
2. ✅ Modal s'ouvre (pas de vérification)
3. ⚠️ Utilisateur remplit le formulaire (perte de temps)
4. ⚠️ Utilisateur clique sur "Créer la Réception"
5. ❌ Validation échoue → Message d'erreur
6. ⚠️ Modal reste ouvert (utilisateur frustré)

**Résultat :** ⚠️ **Mauvaise UX** - L'utilisateur perd du temps à remplir un formulaire qui ne peut pas aboutir

#### Version Actuelle ✅
1. ✅ Utilisateur clique sur "Nouvelle Réception"
2. ✅ Vérification préventive du stock
3. ❌ **Aucun stock trouvé** → Message d'erreur immédiat
4. ❌ **Modal ne s'ouvre pas**
5. ✅ Utilisateur informé immédiatement

**Résultat :** ✅ **Meilleure UX** - L'utilisateur est informé immédiatement, pas de perte de temps

---

### Scénario 2 : IEPP a du stock INSUFFISANT (stock < quantité demandée)

#### Version "Good" ⚠️
1. ✅ Utilisateur clique sur "Nouvelle Réception"
2. ✅ Modal s'ouvre
3. ⚠️ Utilisateur remplit le formulaire avec quantités > stock disponible
4. ⚠️ Utilisateur clique sur "Créer la Réception"
5. ❌ Validation échoue → Message d'erreur détaillé
6. ⚠️ Modal reste ouvert (utilisateur peut modifier les quantités)

**Résultat :** ⚠️ **UX acceptable** - L'utilisateur peut corriger les quantités

#### Version Actuelle ✅
1. ✅ Utilisateur clique sur "Nouvelle Réception"
2. ✅ Vérification préventive du stock (détecte qu'il y a du stock)
3. ✅ Modal s'ouvre
4. ⚠️ Utilisateur remplit le formulaire avec quantités > stock disponible
5. ⚠️ Utilisateur clique sur "Créer la Réception"
6. ❌ Validation backend échoue → Message d'erreur détaillé
7. ⚠️ Modal reste ouvert (utilisateur peut modifier les quantités)

**Résultat :** ✅ **Meilleure UX** - Double validation (préventive + backend) + message d'erreur détaillé

---

### Scénario 3 : IEPP a du stock SUFFISANT (stock >= quantité demandée)

#### Version "Good" ✅
1. ✅ Utilisateur clique sur "Nouvelle Réception"
2. ✅ Modal s'ouvre
3. ✅ Utilisateur remplit le formulaire
4. ✅ Utilisateur clique sur "Créer la Réception"
5. ✅ Validation réussie → Réception créée

**Résultat :** ✅ **Fonctionnel**

#### Version Actuelle ✅
1. ✅ Utilisateur clique sur "Nouvelle Réception"
2. ✅ Vérification préventive du stock (détecte qu'il y a du stock)
3. ✅ Modal s'ouvre
4. ✅ Utilisateur remplit le formulaire
5. ✅ Utilisateur clique sur "Créer la Réception"
6. ✅ Validation backend réussie → Réception créée

**Résultat :** ✅ **Fonctionnel** + Double validation (sécurité renforcée)

---

## ✅ AVANTAGES DE LA VERSION ACTUELLE

### 1. 🟢 Meilleure Expérience Utilisateur (UX)
- ✅ **Message d'erreur immédiat** si aucun stock disponible
- ✅ **Pas de perte de temps** à remplir un formulaire qui ne peut pas aboutir
- ✅ **Feedback clair** sur la situation

### 2. 🔴 Sécurité Renforcée
- ✅ **Validation backend** (non contournable)
- ✅ **Double validation** (préventive + backend)
- ✅ **Source fiable** (table StockDisponible)

### 3. 🟢 Performance Améliorée
- ✅ **Vérification préventive optimisée** (3 matières max)
- ✅ **Table matérialisée** (rapide vs recalcul)
- ✅ **Moins d'appels API** inutiles

### 4. 🟢 Cohérence
- ✅ **Même logique** de validation préventive et backend
- ✅ **Messages d'erreur cohérents**
- ✅ **Workflow unifié**

---

## ⚠️ POINTS D'ATTENTION

### 1. Vérification Préventive Limitée
- ⚠️ La vérification préventive ne vérifie que **3 matières maximum**
- ⚠️ Si l'IEPP a du stock pour certaines matières mais pas toutes, le modal s'ouvre quand même
- ✅ La validation backend complète garantit que toutes les matières ont du stock suffisant

### 2. Performance
- ⚠️ La vérification préventive fait plusieurs appels API (`getStock` pour chaque matière)
- ✅ Optimisée avec limite de 3 matières
- ✅ La validation backend est plus rapide (table matérialisée)

### 3. Messages d'Erreur
- ✅ Messages clairs et détaillés
- ✅ Indiquent la cause exacte (stock insuffisant, matière concernée, etc.)

---

## 🎯 CONCLUSION

### Version "Good" ❌
- ❌ Pas de vérification préventive
- ⚠️ Validation frontend (contournable)
- ⚠️ Recalcul lent du stock
- ⚠️ Mauvaise UX (utilisateur perd du temps)

### Version Actuelle ✅
- ✅ Vérification préventive (bloque l'ouverture du modal si aucun stock)
- ✅ Validation backend (sécurisée)
- ✅ Table matérialisée (rapide)
- ✅ Meilleure UX (message immédiat, pas de perte de temps)

**La Version Actuelle est nettement meilleure** pour gérer le cas où l'IEPP n'a pas de stock, offrant :
1. ✅ **Meilleure UX** : Message immédiat, pas de perte de temps
2. ✅ **Sécurité renforcée** : Validation backend non contournable
3. ✅ **Performance améliorée** : Table matérialisée vs recalcul
4. ✅ **Double validation** : Préventive + backend pour robustesse

