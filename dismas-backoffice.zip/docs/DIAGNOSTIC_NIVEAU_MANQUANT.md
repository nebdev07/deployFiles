# 🔍 DIAGNOSTIC : Niveau Scolaire Manquant dans la Validation

**Date**: 2025-10-12  
**Problème observé**: `idNiveauScolaire = undefined` dans `stockValidationData.matiereQuantites`

---

## 📊 **LOGS ACTUELS**

```javascript
🔍 Vérification des stocks pour réception EPP...
🔍 Données de validation du stock: {idStructure: 5, matiereQuantites: Array(2)}
🎓 Vérification des niveaux dans la validation:
  [0] Matière: Français, Niveau ID: undefined  ❌
  [1] Matière: Mathématiques, Niveau ID: undefined  ❌
```

**Conclusion** : Le fallback ne fonctionne pas car **les deux sources sont vides** :
- `quantite.idNiveauScolaire` = `undefined`
- `catalogue.niveauId` = `undefined`

---

## 🎯 **LOGS DE DEBUG AJOUTÉS**

### **1. Au chargement des catalogues (ligne 186-189)**

```javascript
🔍 DEBUG niveauId dans les catalogues:
  [0] Manuels CP1: niveauId = 1 ✅  // ou undefined ❌
  [1] Manuels CE1: niveauId = 3 ✅  // ou undefined ❌
```

**Ce log va nous dire** : Est-ce que `availableCatalogues` contient `niveauId` ?

---

### **2. Avant la validation EPP (lignes 1522-1530)**

```javascript
🔍 DEBUG selectedCatalogues AVANT validation:
  📚 [0] Catalogue: Manuels CE1
       → id: 4
       → niveauId: 3 ✅  // ou undefined ❌
       → niveauScolaire: CE1
       → quantitesSaisies: [...]
         [0] Matière: Français, idNiveauScolaire: 3 ✅  // ou undefined ❌
```

**Ce log va nous dire** : Est-ce que `selectedCatalogues` conserve le `niveauId` ?

---

## 🔬 **DIAGNOSTIC ÉTAPE PAR ÉTAPE**

### **Étape 1 : Vérifier la réponse API du backend**

**Dans le navigateur** (Onglet Network) :
1. Créer une nouvelle réception
2. Chercher la requête : `POST /catalogue/getByCriteria`
3. Regarder la **réponse** (Response tab)

**Vérifier** :
```json
{
  "items": [
    {
      "id": 4,
      "libelle": "Manuels CE1",
      "niveauScolaire": {
        "id": 3,          // ✅ Doit être présent
        "libelle": "CE1",
        "code": "CE1"
      },
      "idNiveauScolaire": 3  // ✅ Peut-être présent aussi
    }
  ]
}
```

**Si `niveauScolaire.id` est absent** → Problème backend (transformer)
**Si `niveauScolaire.id` est présent** → Problème dans le mapping frontend

---

### **Étape 2 : Vérifier le mapping des catalogues (ligne 177)**

**Code actuel** :
```typescript
niveauId: catalogue.niveauScolaire?.id || catalogue.idNiveauScolaire
```

**Avec les logs, on verra** :
- Si `catalogue.niveauScolaire?.id` est présent
- Si `catalogue.idNiveauScolaire` est présent
- Lequel est utilisé

---

### **Étape 3 : Vérifier la propagation dans selectedCatalogues (ligne 300)**

**Code actuel** :
```typescript
const catalogueWithQuantities = {
  ...currentCatalogueData,  // ← Est-ce que currentCatalogueData a niveauId ?
  quantitesSaisies: receptionFormData.manuels.filter(...)
}
```

**Avec les logs** :
```javascript
🔍 DEBUG selectedCatalogues AVANT validation:
  📚 [0] Catalogue: Manuels CE1
       → niveauId: undefined ❌  // Si undefined ici, le problème est dans currentCatalogueData
```

---

### **Étape 4 : Vérifier la saisie des quantités (ligne 1237)**

**Code actuel** :
```typescript
idNiveauScolaire: catalogue?.niveauId
```

**Avec les logs** :
```javascript
🎓 Niveau scolaire: ID=3 (depuis quantité)  // ou ID=undefined ❌
```

---

## 🎯 **PROCHAINES ACTIONS (SELON LES LOGS)**

### **Scénario A : `niveauId` absent dans `availableCatalogues`**

**Si vous voyez** :
```javascript
🔍 DEBUG niveauId dans les catalogues:
  [0] Manuels CP1: niveauId = undefined ❌
```

**Solution** : Le problème est dans le mapping (ligne 177). Le backend ne retourne peut-être pas `niveauScolaire.id`.

**Action** :
- Vérifier la réponse API dans Network
- Vérifier le transformer backend `CatalogueTransformer.java`

---

### **Scénario B : `niveauId` présent dans `availableCatalogues` mais absent dans `selectedCatalogues`**

**Si vous voyez** :
```javascript
// Au chargement
🔍 DEBUG niveauId dans les catalogues:
  [0] Manuels CP1: niveauId = 1 ✅

// Mais avant validation
🔍 DEBUG selectedCatalogues AVANT validation:
  📚 [0] Catalogue: Manuels CP1
       → niveauId: undefined ❌
```

**Solution** : Le `niveauId` est perdu lors de l'ajout au tableau (ligne 300).

**Action** :
- Vérifier que `currentCatalogueData` contient `niveauId`
- Peut-être ajouter explicitement : `niveauId: currentCatalogueData.niveauId`

---

### **Scénario C : `niveauId` présent partout mais pas dans `quantite.idNiveauScolaire`**

**Si vous voyez** :
```javascript
🔍 DEBUG selectedCatalogues AVANT validation:
  📚 [0] Catalogue: Manuels CE1
       → niveauId: 3 ✅
       → Quantités saisies:
         [0] Matière: Français, idNiveauScolaire: undefined ❌
```

**Solution** : Le niveau n'est pas ajouté lors de la saisie (ligne 1237).

**Action** :
- Vérifier que la ligne 1237 utilise bien `catalogue?.niveauId`
- Vérifier que `catalogue` est trouvé dans `availableCatalogues`

---

## 📋 **CHECKLIST DE VÉRIFICATION**

### **Dans le navigateur (console) :**

- [ ] Au chargement : `🔍 DEBUG niveauId dans les catalogues` → Vérifier si `niveauId` est présent
- [ ] À la sélection : Vérifier `currentCatalogueData` contient `niveauId`
- [ ] À l'ajout au tableau : Vérifier `selectedCatalogues[0].niveauId`
- [ ] À la saisie : Vérifier le log `🎓 Niveau scolaire: ID=?`
- [ ] Avant validation : `🔍 DEBUG selectedCatalogues AVANT validation` → Vérifier `niveauId`
- [ ] Dans validation : `🎓 Vérification des niveaux` → Doit afficher un ID (pas `undefined`)

---

## 🎯 **PROCHAINE ÉTAPE**

**Testez maintenant dans le navigateur** et partagez-moi les logs suivants :

1. **Au chargement des catalogues** :
   ```
   🔍 DEBUG niveauId dans les catalogues:
     [0] Manuels CP1: niveauId = ???
   ```

2. **Avant la validation** :
   ```
   🔍 DEBUG selectedCatalogues AVANT validation:
     📚 [0] Catalogue: ???
          → niveauId: ???
   ```

**Avec ces logs, je saurai exactement où le niveau est perdu et je pourrai corriger ! 🎯**

