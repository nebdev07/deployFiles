# 📄 GUIDE DE CONVERSION - DISMAS Présentation

## 🎯 **MÉTHODES DE CONVERSION**

### **1. 🚀 Méthode Rapide - Pandoc (Recommandée)**

#### **Installation Pandoc**
```bash
# Windows (avec Chocolatey)
choco install pandoc

# macOS (avec Homebrew)
brew install pandoc

# Linux
sudo apt-get install pandoc
```

#### **Conversion en PowerPoint**
```bash
# Conversion directe en PPTX
pandoc PRESENTATION_DISMAS_COMPLETE.md -o DISMAS_Presentation.pptx --slide-level=2

# Avec template personnalisé
pandoc PRESENTATION_DISMAS_COMPLETE.md -o DISMAS_Presentation.pptx --slide-level=2 --reference-doc=template.pptx
```

#### **Conversion en PDF**
```bash
# Via LaTeX (meilleure qualité)
pandoc PRESENTATION_DISMAS_COMPLETE.md -o DISMAS_Presentation.pdf --pdf-engine=xelatex

# Via HTML
pandoc PRESENTATION_DISMAS_COMPLETE.md -o DISMAS_Presentation.pdf --pdf-engine=wkhtmltopdf
```

### **2. 🎨 Méthode Visuelle - Marp**

#### **Installation Marp**
```bash
npm install -g @marp-team/marp-cli
```

#### **Conversion**
```bash
# En PDF
marp PRESENTATION_DISMAS_COMPLETE.md --pdf

# En HTML
marp PRESENTATION_DISMAS_COMPLETE.md --html

# En PowerPoint
marp PRESENTATION_DISMAS_COMPLETE.md --pptx
```

### **3. 🌐 Méthode Web - Reveal.js**

#### **Installation**
```bash
npm install -g reveal-md
```

#### **Conversion**
```bash
# Générer une présentation web
reveal-md PRESENTATION_DISMAS_COMPLETE.md --static _site

# Exporter en PDF
reveal-md PRESENTATION_DISMAS_COMPLETE.md --print presentation.pdf
```

---

## 📋 **SCRIPT AUTOMATISÉ**

### **Script Windows (PowerShell)**
```powershell
# conversion_dismas.ps1
param(
    [string]$Format = "pptx"
)

Write-Host "🎯 Conversion DISMAS en cours..." -ForegroundColor Green

# Vérifier si Pandoc est installé
if (!(Get-Command pandoc -ErrorAction SilentlyContinue)) {
    Write-Host "❌ Pandoc n'est pas installé. Installation..." -ForegroundColor Red
    choco install pandoc -y
}

# Conversion selon le format
switch ($Format.ToLower()) {
    "pptx" {
        pandoc PRESENTATION_DISMAS_COMPLETE.md -o DISMAS_Presentation.pptx --slide-level=2
        Write-Host "✅ Présentation PowerPoint créée : DISMAS_Presentation.pptx" -ForegroundColor Green
    }
    "pdf" {
        pandoc PRESENTATION_DISMAS_COMPLETE.md -o DISMAS_Presentation.pdf --pdf-engine=xelatex
        Write-Host "✅ PDF créé : DISMAS_Presentation.pdf" -ForegroundColor Green
    }
    "html" {
        pandoc PRESENTATION_TEMPLATE_PROFESSIONNEL.md -o DISMAS_Presentation.html --standalone
        Write-Host "✅ HTML créé : DISMAS_Presentation.html" -ForegroundColor Green
    }
    default {
        Write-Host "❌ Format non supporté. Utilisez: pptx, pdf, ou html" -ForegroundColor Red
    }
}
```

### **Script Linux/macOS (Bash)**
```bash
#!/bin/bash
# conversion_dismas.sh

echo "🎯 Conversion DISMAS en cours..."

# Vérifier Pandoc
if ! command -v pandoc &> /dev/null; then
    echo "❌ Pandoc n'est pas installé"
    exit 1
fi

# Fonction de conversion
convert_to() {
    local format=$1
    case $format in
        "pptx")
            pandoc PRESENTATION_TEMPLATE_PROFESSIONNEL.md -o DISMAS_Presentation.pptx --slide-level=2
            echo "✅ Présentation PowerPoint créée : DISMAS_Presentation.pptx"
            ;;
        "pdf")
            pandoc PRESENTATION_TEMPLATE_PROFESSIONNEL.md -o DISMAS_Presentation.pdf --pdf-engine=xelatex
            echo "✅ PDF créé : DISMAS_Presentation.pdf"
            ;;
        "html")
            pandoc PRESENTATION_TEMPLATE_PROFESSIONNEL.md -o DISMAS_Presentation.html --standalone
            echo "✅ HTML créé : DISMAS_Presentation.html"
            ;;
        *)
            echo "❌ Format non supporté. Utilisez: pptx, pdf, ou html"
            ;;
    esac
}

# Utilisation
if [ $# -eq 0 ]; then
    convert_to "pptx"
else
    convert_to $1
fi
```

---

## 🎨 **TEMPLATE POWERPOINT PERSONNALISÉ**

### **Créer un template PowerPoint**
1. Ouvrir PowerPoint
2. Créer un design avec les couleurs DISMAS :
   - 🟠 Orange : #FF6B35
   - 🟢 Vert : #4ECDC4
   - 🔵 Bleu : #45B7D1
   - ⚪ Blanc : #FFFFFF
3. Sauvegarder comme `dismas_template.pptx`

### **Utiliser le template**
```bash
pandoc PRESENTATION_TEMPLATE_PROFESSIONNEL.md -o DISMAS_Presentation.pptx --slide-level=2 --reference-doc=dismas_template.pptx
```

---

## 🌐 **MÉTHODE EN LIGNE**

### **1. StackEdit**
1. Aller sur [stackedit.io](https://stackedit.io)
2. Coller le contenu Markdown
3. Exporter en PDF ou HTML

### **2. Dillinger**
1. Aller sur [dillinger.io](https://dillinger.io)
2. Coller le contenu
3. Exporter en PDF

### **3. Markdown to Slides**
1. Aller sur [slides.com](https://slides.com)
2. Importer le fichier Markdown
3. Exporter en PDF

---

## 📱 **MÉTHODE MOBILE**

### **Applications recommandées**
- **Markor** (Android) : Éditeur Markdown avec export PDF
- **iA Writer** (iOS/macOS) : Export direct en PDF
- **Typora** (Desktop) : Export en plusieurs formats

---

## 🎯 **RECOMMANDATIONS PAR USAGE**

### **Pour Présentation Client**
```bash
# PowerPoint avec template personnalisé
pandoc PRESENTATION_TEMPLATE_PROFESSIONNEL.md -o DISMAS_Client.pptx --slide-level=2 --reference-doc=dismas_template.pptx
```

### **Pour Documentation**
```bash
# PDF haute qualité
pandoc PRESENTATION_TEMPLATE_PROFESSIONNEL.md -o DISMAS_Documentation.pdf --pdf-engine=xelatex --toc
```

### **Pour Web**
```bash
# HTML responsive
pandoc PRESENTATION_TEMPLATE_PROFESSIONNEL.md -o DISMAS_Web.html --standalone --css=style.css
```

---

## 🔧 **DÉPANNAGE**

### **Problèmes courants**

#### **Erreur LaTeX**
```bash
# Installer LaTeX
# Windows
choco install miktex

# macOS
brew install --cask mactex

# Linux
sudo apt-get install texlive-full
```

#### **Erreur wkhtmltopdf**
```bash
# Installer wkhtmltopdf
# Windows
choco install wkhtmltopdf

# macOS
brew install wkhtmltopdf

# Linux
sudo apt-get install wkhtmltopdf
```

#### **Images non affichées**
- Vérifier que les URLs des images sont accessibles
- Remplacer les placeholders par de vraies images
- Utiliser des chemins relatifs pour les images locales

---

## 📊 **FORMATS SUPPORTÉS**

| **Format** | **Qualité** | **Facilité** | **Recommandé pour** |
|------------|-------------|--------------|---------------------|
| **PowerPoint (.pptx)** | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ | Présentation client |
| **PDF** | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐ | Documentation |
| **HTML** | ⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ | Web/Email |
| **LaTeX** | ⭐⭐⭐⭐⭐ | ⭐⭐ | Publications |

---

## 🚀 **COMMANDES RAPIDES**

```bash
# Conversion rapide en PowerPoint
pandoc PRESENTATION_TEMPLATE_PROFESSIONNEL.md -o DISMAS.pptx

# Conversion rapide en PDF
pandoc PRESENTATION_TEMPLATE_PROFESSIONNEL.md -o DISMAS.pdf

# Conversion avec table des matières
pandoc PRESENTATION_TEMPLATE_PROFESSIONNEL.md -o DISMAS.pdf --toc

# Conversion avec numérotation
pandoc PRESENTATION_TEMPLATE_PROFESSIONNEL.md -o DISMAS.pdf --number-sections
```

---

## 🎉 **RÉSULTAT FINAL**

Après conversion, vous aurez :
- ✅ **DISMAS_Presentation.pptx** : Présentation PowerPoint professionnelle
- ✅ **DISMAS_Presentation.pdf** : Document PDF haute qualité
- ✅ **DISMAS_Presentation.html** : Version web responsive

**Prêt pour votre présentation client !** 🎯 