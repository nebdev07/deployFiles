# IV) MAQUETTE - DISMAS

## A) Arborescence de l'Application

```
📱 DISMAS - Système de Distribution des Manuels Scolaires
├── 🏠 Dashboard
│   ├── 📊 Statistiques Globales
│   ├── 📈 Graphiques de Performance
│   └── 🔔 Notifications Récentes
│
├── 📋 Planification
│   ├── 📊 Tableau de Répartition
│   │   ├── 📥 Import Excel
│   │   ├── 📊 Visualisation des Données
│   │   └── 📤 Export des Données
│   └── 🎯 Objectifs de Distribution
│
├── 📦 Distribution
│   ├── 📝 Nouvelle Distribution
│   │   ├── 🏫 Sélection EPP
│   │   ├── 📚 Sélection Manuels
│   │   ├── 👥 Effectifs (Garçons/Filles)
│   │   └── 📅 Date de Distribution
│   ├── ✅ Confirmation Réception (EPP)
│   │   ├── 📊 Quantités Reçues
│   │   ├── 📄 Bordereau de Livraison
│   │   └── 👥 Fiche de Synthèse avec Émargements
│   └── 🛡️ Validation IEPP
│       ├── 📊 Consolidation des Confirmations
│       ├── 🚚 Bordereau Livreur
│       └── 📋 Fiche de Répartition (optionnel)
│
├── 📊 Stocks
│   ├── 📦 Inventaire des Manuels
│   ├── 📈 Mouvements de Stock
│   └── 📊 Rapports de Stock
│
├── 🔄 Régulation
│   ├── 📋 Liste des Régulations
│   ├── ➕ Nouvelle Régulation
│   ├── 📈 EPP Excédentaires
│   │   └── 🚀 Initier Régulation
│   ├── 📉 EPP Déficitaires
│   │   └── 📦 Assigner Manuels
│   └── 📊 Détails des Régulations
│       ├── 🏢 DRENA Source
│       ├── 🏢 DRENA Destination
│       └── 📚 Manuels Concernés
│
├── 📋 Gestion
│   ├── 🏫 Structures (EPP, IEPP, DRENA)
│   ├── 👥 Utilisateurs et Rôles
│   ├── 📚 Manuels et Matériels
│   └── ⚙️ Paramètres Système
│
└── 📊 Rapports
    ├── 📈 Rapports de Distribution
    ├── 📊 Rapports de Stock
    ├── 🔄 Rapports de Régulation
    └── 📋 Rapports d'Audit
```

## B) Flow des Modules (Captures d'Écrans)

### 🏠 **1. Dashboard Principal**
```
┌─────────────────────────────────────────────────────────────┐
│                    DISMAS - Dashboard                      │
├─────────────────────────────────────────────────────────────┤
│ 📊 Statistiques Globales                                  │
│ ┌─────────────┐ ┌─────────────┐ ┌─────────────┐          │
│ │ Manuels     │ │ EPP         │ │ Régulations │          │
│ │ Distribués  │ │ Actives     │ │ En Cours    │          │
│ │ 125,430     │ │ 847         │ │ 23          │          │
│ └─────────────┘ └─────────────┘ └─────────────┘          │
│                                                           │
│ 📈 Graphiques de Performance                             │
│ ┌─────────────────────────────────────────────────────┐   │
│ │ Distribution par Région (Graphique)                │   │
│ └─────────────────────────────────────────────────────┘   │
│                                                           │
│ 🔔 Notifications Récentes                               │
│ • Nouvelle régulation demandée - EPP Cocody Centre      │
│ • Distribution terminée - EPP Yopougon Maroc            │
│ • Stock faible - Mathématiques CP1                      │
└─────────────────────────────────────────────────────────────┘
```

### 📋 **2. Planification - Tableau de Répartition**
```
┌─────────────────────────────────────────────────────────────┐
│              Planification - Tableau de Répartition        │
├─────────────────────────────────────────────────────────────┤
│ 📥 Import Excel │ 📊 Visualiser │ 📤 Exporter │ 🔍 Filtrer │
├─────────────────────────────────────────────────────────────┤
│ EPP              │ Niveau │ Manuel           │ Qté Prévue │
├─────────────────────────────────────────────────────────────┤
│ EPP Cocody Centre│ CP1    │ Français CP1     │ 120        │
│ EPP Cocody Centre│ CP1    │ Mathématiques CP1│ 120        │
│ EPP Yopougon     │ CP2    │ Français CP2     │ 110        │
│ EPP Bouaké Centre│ CE1    │ Français CE1     │ 95         │
└─────────────────────────────────────────────────────────────┘
```

### 📦 **3. Distribution - Nouvelle Distribution**
```
┌─────────────────────────────────────────────────────────────┐
│                    Nouvelle Distribution                   │
├─────────────────────────────────────────────────────────────┤
│ 🏫 EPP : EPP Cocody Centre                               │
│ 📚 Classe : CP1                                          │
│ 📖 Titre à distribuer : Mon Premier Livre de Français CP1│
│ 👥 Effectif Garçons : 25                                 │
│ 👥 Effectif Filles : 23                                  │
│ 📅 Date : 15/11/2024                                     │
│                                                           │
│ [✅ Créer Distribution] [❌ Annuler]                      │
└─────────────────────────────────────────────────────────────┘
```

### ✅ **4. Confirmation Réception EPP**
```
┌─────────────────────────────────────────────────────────────┐
│                Confirmation Réception EPP                  │
├─────────────────────────────────────────────────────────────┤
│ 📊 Quantités Reçues │ 📄 Documents                        │
├─────────────────────────────────────────────────────────────┤
│ Niveau │ Manuel           │ Qté Prévue │ Qté Reçue │ Écart │
├─────────────────────────────────────────────────────────────┤
│ CP1    │ Français CP1     │ 120        │ [115]     │ -5    │
│ CP1    │ Mathématiques CP1│ 120        │ [120]     │ 0     │
│                                                           │
│ 📄 Bordereau de Livraison : [Choisir fichier]            │
│ 👥 Fiche de Synthèse : [Choisir fichier]                 │
│                                                           │
│ [✅ Confirmer Réception] [❌ Annuler]                     │
└─────────────────────────────────────────────────────────────┘
```

### 🛡️ **5. Validation IEPP**
```
┌─────────────────────────────────────────────────────────────┐
│                    Validation IEPP                        │
├─────────────────────────────────────────────────────────────┤
│ 📊 Quantités Reçues │ 📄 Documents                        │
├─────────────────────────────────────────────────────────────┤
│ 🚚 Bordereau de Livraison du Livreur : [Choisir fichier] │
│ 📋 Fiche de Répartition (optionnel) : [Choisir fichier]  │
│                                                           │
│ 📊 Consolidation des Confirmations EPP                    │
│ • EPP Cocody Centre : ✅ Confirmé                         │
│ • EPP Yopougon Maroc : ✅ Confirmé                        │
│ • EPP Bouaké Centre : ⏳ En attente                       │
│                                                           │
│ [✅ Valider Distribution] [❌ Annuler]                     │
└─────────────────────────────────────────────────────────────┘
```

### 🔄 **6. Régulation - EPP Excédentaires**
```
┌─────────────────────────────────────────────────────────────┐
│                    EPP Excédentaires                      │
├─────────────────────────────────────────────────────────────┤
│ Structure        │ Niveau │ Manuels Excédentaires │ Total │
├─────────────────────────────────────────────────────────────┤
│ EPP Cocody Centre│ CP1    │ Français CP1: 25      │ 45    │
│                  │        │ Mathématiques CP1: 20 │       │
│                  │        │                        │       │
│ EPP Yopougon     │ CP2    │ Français CP2: 15      │ 15    │
│                  │        │                        │       │
│                  │        │ [🚀 Initier Régulation] │       │
└─────────────────────────────────────────────────────────────┘
```

### 📉 **7. Régulation - EPP Déficitaires**
```
┌─────────────────────────────────────────────────────────────┐
│                    EPP Déficitaires                       │
├─────────────────────────────────────────────────────────────┤
│ Structure        │ Niveau │ Manuels Manquants     │ Total │
├─────────────────────────────────────────────────────────────┤
│ EPP Yopougon     │ CP1    │ Français CP1: 30      │ 55    │
│ Niangon          │        │ Mathématiques CP1: 25 │       │
│                  │        │                        │       │
│ EPP Bouaké Centre│ CE1    │ Français CE1: 40      │ 40    │
│                  │        │                        │       │
│                  │        │ [📦 Assigner Manuels]  │       │
└─────────────────────────────────────────────────────────────┘
```

### 📊 **8. Détails Régulation**
```
┌─────────────────────────────────────────────────────────────┐
│                    Détails de la Régulation               │
├─────────────────────────────────────────────────────────────┤
│ Référence : REG-2024-004                                  │
│ Type : EXTERNE (DRENA Abidjan → DRENA Bouaké)            │
│ Structure Source : EPP Abidjan Plateau                    │
│ Structure Destination : EPP Bouaké Sakassou               │
│ DRENA Source : DRENA Abidjan                              │
│ DRENA Destination : DRENA Bouaké                          │
│                                                           │
│ 📚 Manuels Concernés                                      │
│ Manuel              │ Demandé │ Approuvé │ Transféré      │
│ Français CP1        │ 50      │ 0        │ 0              │
│ Mathématiques CP1   │ 50      │ 0        │ 0              │
│                                                           │
│ [✅ Approuver] [❌ Rejeter] [📋 Fermer]                   │
└─────────────────────────────────────────────────────────────┘
```

### 📦 **9. Stocks - Inventaire**
```
┌─────────────────────────────────────────────────────────────┐
│                    Inventaire des Stocks                   │
├─────────────────────────────────────────────────────────────┤
│ 📚 Manuel              │ Stock │ En Transit │ Disponible  │
├─────────────────────────────────────────────────────────────┤
│ Français CP1          │ 1,250 │ 200        │ 1,050       │
│ Mathématiques CP1     │ 1,180 │ 150        │ 1,030       │
│ Français CP2          │ 980   │ 100        │ 880          │
│ Mathématiques CP2     │ 920   │ 80         │ 840          │
│                                                           │
│ 📈 Graphique d'évolution des stocks                       │
└─────────────────────────────────────────────────────────────┘
```

### 📊 **10. Rapports - Distribution**
```
┌─────────────────────────────────────────────────────────────┐
│                    Rapports de Distribution                │
├─────────────────────────────────────────────────────────────┤
│ 📅 Période : 01/09/2024 - 31/10/2024                     │
│ 📊 Statistiques Globales                                  │
│ • Total manuels distribués : 125,430                      │
│ • EPP couvertes : 847/1,200                              │
│ • Taux de couverture : 70.6%                             │
│                                                           │
│ 📈 Répartition par Région                                 │
│ • Abidjan : 45,230 manuels                               │
│ • Bouaké : 28,450 manuels                                │
│ • San-Pédro : 15,670 manuels                             │
│                                                           │
│ [📤 Exporter PDF] [📊 Exporter Excel]                     │
└─────────────────────────────────────────────────────────────┘
```

## 🎯 **Parcours Utilisateur Typique**

### **👨‍💼 Directeur EPP**
1. **Connexion** → Dashboard
2. **Distribution** → Nouvelle Distribution
3. **Confirmation** → Confirmation Réception EPP
4. **Documents** → Upload bordereau + fiche synthèse

### **👨‍💼 Directeur IEPP**
1. **Connexion** → Dashboard
2. **Validation** → Validation Distribution IEPP
3. **Documents** → Upload bordereau livreur
4. **Régulation** → Gestion des EPP excédentaires/déficitaires

### **👨‍💼 Administrateur DRENA**
1. **Connexion** → Dashboard
2. **Planification** → Tableau de Répartition
3. **Régulation** → Gestion des régulations inter-DRENA
4. **Rapports** → Génération des rapports

### **👨‍💼 Administrateur MENA/DAF**
1. **Connexion** → Dashboard
2. **Planification** → Import/Export des données
3. **Régulation** → Validation des régulations externes
4. **Rapports** → Rapports nationaux

## 🎨 **Design System**

### **Couleurs DISMAS**
- 🟠 **Orange** : Actions principales, boutons
- 🟢 **Vert** : Succès, confirmations
- 🔵 **Bleu** : Informations, liens
- 🔴 **Rouge** : Erreurs, alertes
- ⚪ **Blanc** : Arrière-plans
- ⚫ **Gris** : Textes secondaires

### **Composants UI**
- 📱 **Responsive Design** : Mobile-first
- 🎯 **Accessibilité** : WCAG 2.1
- ⚡ **Performance** : Chargement rapide
- 🔒 **Sécurité** : Authentification robuste

---

*Cette maquette présente l'interface utilisateur complète du système DISMAS avec tous les modules et fonctionnalités principales.* 