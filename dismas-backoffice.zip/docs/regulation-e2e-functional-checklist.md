# Régulation — checklist tests fonctionnels (hub DRENA / DAF)

À exécuter sur un environnement de recette avec données réalistes (année scolaire, stocks, hiérarchie SA).

## Prérequis

- Comptes : **IEPP**, **DRENA**, **DAF**, **ADMIN** (optionnel).
- Au moins une **DRENA** avec **2 IEPP** (un avec stock IEPP > 0 sur au moins une ligne matière/niveau après récupération EPP→IEPP si besoin).
- Pour le **DAF** : DRENA(s) enfant(s) du **DAF** avec stock disponible sur la SA **DRENA** (lignes `stock_disponible` / mouvements cohérents).

## Flux IEPP (régression)

1. Programmer une récupération IEPP, valider : stock **EPP** diminué selon taux, stock **IEPP** augmenté.
2. **Redistribuer du Stock (Avancé)** IEPP→EPP : mouvement OK, déficit EPP mis à jour si applicable.

## Flux DRENA (hub)

1. S’assurer que les IEPP ont du **stock disponible** (post-récupération locale ou données de test).
2. Programmer **programmer-drena**, puis **valider** avec un utilisateur **DRENA** (ou profil autorisé).
3. Vérifier :
   - stock **IEPP** diminué (taux appliqué) sur les lignes concernées ;
   - stock **DRENA** (SA hub) augmenté en face ;
   - détails régulation avec préfixe `[Hub DRENA]`.
4. Ouvrir **Hub DRENA → IEPP** : stock hub > 0, effectuer une redistribution vers un IEPP déficitaire ; stocks cohérents.

## Flux DAF (hub national)

1. Programmer **programmer-daf** (national).
2. Valider avec un utilisateur **DAF** (ou ADMIN avec initiateur DAF pour résolution du hub — voir backend).
3. Vérifier :
   - stock **DRENA** diminué selon taux ;
   - stock **DAF** augmenté ;
   - détails avec `[Hub DAF]`.
4. **Hub DAF → DRENA** : redistribution depuis le hub DAF vers une DRENA déficitaire.

## Cas négatifs (rappel)

- **DAF** ne valide pas une programmation **périmètre DRENA** ; **DRENA** ne valide pas une programmation **nationale** (règles métier existantes).

## Points API (rappel)

- Programmation DRENA : `POST /regulation/programmer-drena`
- Programmation DAF : `POST /regulation/programmer-daf`
- Validation : `POST /regulation/valider`
- Hub : `POST /regulation/redistribuer-drena-iepp`, `POST /regulation/redistribuer-daf-drena`
