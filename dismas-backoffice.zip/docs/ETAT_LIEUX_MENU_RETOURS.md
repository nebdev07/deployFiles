# 📊 ÉTAT DES LIEUX - MENU RETOURS

**Date d'analyse** : 2025-12-04  
**Objectif** : Faire l'inventaire complet du module Retours pour continuer l'intégration

---

## 🎯 VUE D'ENSEMBLE

Le module **Retours de Manuels** permet aux EPP de déclarer les manuels retournés en fin d'année scolaire. Ces retours doivent être comptabilisés dans l'année scolaire suivante (N+1) pour alimenter le stock disponible.

---

## ✅ CE QUI EXISTE DÉJÀ

### **1. BACKEND - Entités et Repository**

#### **Entité `RetourManuel`** ✅
- **Fichier** : `dismas-backend/.../RetourManuel.java`
- **Table** : `retour_manuel`
- **Champs** :
  - `id` (PK)
  - `dateRetour` (Date)
  - `quantiteRetournee` (Integer)
  - `effectifClasse` (Integer, optionnel)
  - `commentaire` (String, TEXT)
  - `enregistrePar` (Integer)
  - Relations : `structureAdministrative`, `anneeScolaire`, `niveauScolaire`, `matiere`
  - Audit : `createdat`, `createdby`, `updatedat`, `updatedby`, `isdeleted`

#### **Entité `DetailRetourManuel`** ✅
- **Fichier** : `dismas-backend/.../DetailRetourManuel.java`
- **Table** : `detail_retour_manuel`
- **Champs** :
  - `id` (PK)
  - `retourId` (FK vers `retour_manuel`)
  - `manuelId` (Integer)
  - `quantiteDistribuee` (Integer)
  - `quantiteBonEtat` (Integer)
  - `quantiteMauvaisEtat` (Integer)
  - `quantitePerdue` (Integer)
- **Statut** : Entité créée mais **PAS UTILISÉE** dans le frontend actuel

#### **Repository** ✅
- `RetourManuelRepository` : CRUD standard
- `DetailRetourManuelRepository` : CRUD standard

---

### **2. BACKEND - Business Logic**

#### **`RetourManuelBusiness`** ✅
- **Fichier** : `dismas-backend/.../RetourManuelBusiness.java`
- **Méthodes CRUD** :
  - ✅ `create()` : Création avec validation des relations
  - ✅ `update()` : Mise à jour
  - ✅ `delete()` : Suppression logique
  - ✅ `getByCriteria()` : Recherche avec critères
  - ✅ `getFullInfos()` : Enrichissement des DTOs

#### **⚠️ PROBLÈME IDENTIFIÉ** : 
**AUCUNE INTÉGRATION AVEC LE SYSTÈME DE STOCK**

- ❌ Pas de création de `MouvementStock` lors de la création d'un `RetourManuel`
- ❌ Pas d'appel à `stockDisponibleBusiness.updateStockFromMouvement()`
- ❌ Pas de gestion du type `RETOUR_CLASSES` dans `MouvementStock`
- ❌ Pas de logique pour comptabiliser en année N+1

**Impact** : Les retours sont enregistrés mais **n'impactent pas le stock disponible**.

---

### **3. BACKEND - Controller**

#### **`RetourManuelController`** ✅
- **Fichier** : `dismas-backend/.../RetourManuelController.java`
- **Endpoints** :
  - ✅ `POST /retourManuel/create`
  - ✅ `POST /retourManuel/update`
  - ✅ `POST /retourManuel/delete`
  - ✅ `POST /retourManuel/getByCriteria`

**Statut** : Endpoints fonctionnels mais **incomplets** (pas d'intégration stock)

---

### **4. FRONTEND - Service**

#### **`retour.service.ts`** ✅
- **Fichier** : `dismas-backoffice/lib/services/retour.service.ts`
- **Méthodes** :
  - ✅ `create()` : Création avec formatage date
  - ✅ `update()` : Mise à jour
  - ✅ `delete()` : Suppression
  - ✅ `getByCriteria()` : Recherche avec pagination
  - ✅ `getById()` : Récupération par ID
  - ✅ `getByStructure()` : Récupération par structure

**Statut** : Service complet et fonctionnel

---

### **5. FRONTEND - Page**

#### **`app/retours/page.tsx`** ✅
- **Fichier** : `dismas-backoffice/app/retours/page.tsx` (724 lignes)
- **Fonctionnalités** :
  - ✅ Liste paginée des retours
  - ✅ Formulaire de création (7 champs)
  - ✅ Formulaire de modification
  - ✅ Suppression avec confirmation
  - ✅ Modal de détails
  - ✅ Statistiques (total retours, manuels retournés)
  - ✅ Validation des champs obligatoires
  - ✅ Toasts de feedback
  - ✅ Loading states
  - ✅ Gestion des données de référence (matières, niveaux, années)

**Champs du formulaire** :
- Année Scolaire (obligatoire)
- Niveau (obligatoire)
- Matière (obligatoire)
- Date de Retour (obligatoire)
- Quantité Retournée (obligatoire)
- Effectif Classe (optionnel)
- Observations (optionnel)

**Statut** : Interface complète et fonctionnelle

---

### **6. INTÉGRATION MENU**

#### **Sidebar** ✅
- **Fichier** : `dismas-backoffice/components/layout/sidebar.tsx`
- **Menu** : "Retours" → `/retours`
- **Statut** : Menu présent et fonctionnel

---

## ✅ DÉCISION ARCHITECTURALE

### **INTÉGRATION STOCK - VOLONTAIREMENT DIFFÉRÉE** 🟢

#### **Décision** :
Les retours sont **intentionnellement créés SANS impact sur les stocks** pour le moment.

#### **Raison** :
1. **Comptabilisation N+1** : Les retours sont comptabilisés pour l'année scolaire suivante (N+1)
2. **Utilisation future** : Les retours seront utilisés pour les **demandes d'expression de besoin** (module pas encore implémenté)
3. **Séparation des responsabilités** : Les retours sont des données de référence, l'intégration stock sera faite lors de l'implémentation du module "Besoins"

#### **État actuel** :
- ✅ Les retours sont enregistrés dans `retour_manuel`
- ✅ Pas de création de `MouvementStock` (volontaire)
- ✅ Pas de mise à jour de `StockDisponible` (volontaire)
- ✅ Les retours sont disponibles pour les besoins futurs

#### **Intégration future** :
Lors de l'implémentation du module "Demandes d'Expression de Besoin", on pourra :
1. Récupérer les retours de l'année N
2. Les utiliser pour calculer les besoins de l'année N+1
3. Créer les `MouvementStock` et mettre à jour `StockDisponible` à ce moment-là

---

### **2. ENDPOINT DÉDIÉ POUR CRÉATION AVEC STOCK** 🟡

#### **Option 1** : Modifier `RetourManuelBusiness.create()`
- ✅ Avantage : Simple, tout en un
- ❌ Inconvénient : Modifie le flux existant

#### **Option 2** : Créer endpoint dédié `/retourManuel/createWithStock`
- ✅ Avantage : Ne casse pas l'existant
- ✅ Avantage : Cohérent avec `/mouvement/createStockMovements`
- ✅ Recommandé

---

### **3. GESTION `DetailRetourManuel`** 🟡

#### **État actuel** :
- Entité existe mais **non utilisée** dans le frontend
- Permet de détailler l'état des manuels retournés (bon état, mauvais état, perdus)

#### **À décider** :
- Utiliser `DetailRetourManuel` pour un suivi détaillé ?
- Ou garder seulement `RetourManuel` avec `quantiteRetournee` ?

---

### **4. VALIDATION STOCK DISPONIBLE** 🟡

#### **À implémenter** :
Avant de créer un retour, vérifier que la quantité retournée ne dépasse pas la quantité distribuée :
- Récupérer les distributions pour (structure, niveau, matière, année)
- Somme des quantités distribuées
- Vérifier : `quantiteRetournee <= quantiteDistribuee`

---

### **5. AFFICHAGE STOCK IMPACTÉ** 🟢

#### **À ajouter dans le frontend** :
- Afficher le stock disponible **avant** le retour
- Afficher le stock disponible **après** le retour (prévisualisation)
- Indiquer si le retour sera comptabilisé en année N+1

---

## 📋 PLAN D'ÉVOLUTION FUTURE

### **PHASE FUTURE : Intégration avec Module "Besoins"** 🔵

Lors de l'implémentation du module "Demandes d'Expression de Besoin", on pourra :

1. **Récupérer les retours de l'année N**
   - Filtrer par `anneeScolaireId = N`
   - Grouper par structure, niveau, matière

2. **Calculer les besoins N+1**
   - Utiliser les retours comme base de calcul
   - Prendre en compte les effectifs prévus

3. **Créer MouvementStock et mettre à jour StockDisponible**
   - À ce moment-là, créer les `MouvementStock` (type `RETOUR_CLASSES`)
   - Mettre à jour `StockDisponible` pour l'année N+1
   - Gérer `quantiteRetoursAnneePrecedente`

---

### **AMÉLIORATIONS POSSIBLES (Optionnelles)** 🟢

1. **Validation quantité retournée**
   - Vérifier que `quantiteRetournee <= quantiteDistribuee` (pour information)

2. **Affichage statistiques**
   - Total retours par année
   - Retours par niveau/matière

3. **Utilisation `DetailRetourManuel`** (optionnel)
   - Si besoin de détailler l'état des manuels (bon état, mauvais état, perdus)

---

## 🔗 LIENS AVEC AUTRES MODULES

### **Module Stock**
- ✅ `StockDisponible` : Impacté par les retours
- ✅ `MouvementStock` : Créé pour chaque retour
- ✅ Type `RETOUR_CLASSES` : Déjà géré dans `StockDisponibleBusiness`

### **Module Distribution**
- Les retours concernent les manuels **distribués** aux classes
- Relation : `DistributionEleve` → `MouvementStock` (type `DISTRIBUTION_CLASSES`)
- Validation : `quantiteRetournee <= quantiteDistribuee`

### **Module Réception**
- Les retours peuvent être réutilisés pour les réceptions de l'année suivante
- Stock N+1 alimenté par les retours de l'année N

---

## 📊 FLUX ACTUEL vs FLUX ATTENDU

### **FLUX ACTUEL** ❌
```
Frontend → POST /retourManuel/create
  ↓
Backend → RetourManuelBusiness.create()
  ↓
Sauvegarde → retour_manuel (table)
  ↓
❌ AUCUN IMPACT SUR LE STOCK
```

### **FLUX ATTENDU** ✅
```
Frontend → POST /retourManuel/create
  ↓
Backend → RetourManuelBusiness.create()
  ↓
Sauvegarde → retour_manuel (table)
  ↓
Création → MouvementStock (type: RETOUR_CLASSES)
  ├─ anneeMouvement = N (année du retour)
  └─ anneeStock = N+1 (année suivante)
  ↓
Mise à jour → StockDisponible
  ├─ Si anneeMouvement != anneeStock
  │  └─ quantiteRetoursAnneePrecedente += quantite
  └─ Sinon
     └─ quantiteRetours += quantite
  ↓
✅ STOCK N+1 ALIMENTÉ
```

---

## 🎯 ÉTAT ACTUEL - VALIDÉ ✅

L'implémentation actuelle est **CORRECTE** pour les besoins actuels :

1. ✅ **Les retours sont créés sans impact stock** (comme souhaité)
2. ✅ **Les retours sont enregistrés pour utilisation future** (besoins N+1)
3. ✅ **L'intégration stock sera faite lors de l'implémentation du module "Besoins"**

## 🔮 PROCHAINES ÉTAPES (Futures)

1. **🔵 FUTUR** : Implémenter le module "Demandes d'Expression de Besoin"
2. **🔵 FUTUR** : Intégrer les retours dans le calcul des besoins
3. **🔵 FUTUR** : Créer MouvementStock et mettre à jour StockDisponible à ce moment-là

---

## 📝 NOTES TECHNIQUES

### **Références existantes** :
- `MouvementBusiness.createStockMovementsForMouvement()` : Pattern à suivre
- `StockDisponibleBusiness.updateStockFromMouvementStock()` : Méthode réutilisable
- `DistributionEleveBusiness` : Exemple d'intégration stock pour distributions

### **Patterns à respecter** :
- Utiliser `RETOUR_CLASSES` comme type de mouvement (standardisé)
- Gérer `anneeMouvement` vs `anneeStock` pour comptabilisation N+1
- Ne pas créer de doublons (vérifier existence avant création)

---

**Document créé le** : 2025-12-04  
**Dernière mise à jour** : 2025-12-04

