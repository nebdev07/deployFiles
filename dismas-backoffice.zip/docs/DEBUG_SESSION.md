# 🔍 GUIDE DE DÉBOGAGE - SESSION EXPIRÉE

**Date** : 2025-10-11  
**Problème** : Session expirée immédiatement après connexion

---

## 🧪 ÉTAPE 1 : VÉRIFIER LE LOCALSTORAGE

Ouvrez la console du navigateur (F12) et exécutez :

```javascript
// 1. Vérifier le token
console.log('auth_token:', localStorage.getItem('auth_token'))

// 2. Vérifier l'utilisateur
console.log('dismas_user:', localStorage.getItem('dismas_user'))

// 3. Vérifier l'expiration
console.log('token_expiry:', localStorage.getItem('token_expiry'))

// 4. Vérifier toutes les clés
console.log('Toutes les clés:', Object.keys(localStorage))
```

**Résultat attendu** :
```javascript
auth_token: "kgsDSw3Y4eWMwXZwF4axrTJIGMHZirI6iCL1XWNOPwcWT7CG..." // ✅ Token long
dismas_user: "{\"id\":3,\"nom\":\"Dupont\",\"prenoms\":\"Jean\",...}" // ✅ JSON utilisateur
token_expiry: "2025-10-11T18:30:00" // ✅ Date future
```

---

## 🧪 ÉTAPE 2 : VÉRIFIER LA REQUÊTE RÉSEAU

1. Ouvrez **DevTools** (F12)
2. Allez dans l'onglet **Network** (Réseau)
3. Actualisez la page `/receptions`
4. Cherchez la requête `mouvement/getByCriteria`
5. Cliquez dessus et allez dans **Payload**

**Vérifiez** :

### **Headers** :
```json
{
  "Content-Type": "application/json",
  "Authorization": "Bearer kgsDSw3Y4eWMwXZwF4axrTJIGMHZirI6iCL1XWNOPwcWT7CG...",
  "Session-Key": "kgsDSw3Y4eWMwXZwF4axrTJIGMHZirI6iCL1XWNOPwcWT7CG..."
}
```

### **Request Payload** :
```json
{
  "user": 3,
  "token": "kgsDSw3Y4eWMwXZwF4axrTJIGMHZirI6iCL1XWNOPwcWT7CG...",
  "isSimpleLoading": false,
  "data": {
    "idStructure": 4,
    "typeMouvement": "RECEPTION_IEPP"
  }
}
```

**⚠️ Vérifier** :
- ✅ `token` est présent dans le body
- ✅ `user` est présent (ID numérique)
- ✅ `data` (objet) et non `datas` (array)

---

## 🧪 ÉTAPE 3 : VÉRIFIER LA RÉPONSE BACKEND

Dans l'onglet **Response** de la requête `mouvement/getByCriteria` :

**Si erreur** :
```json
{
  "status": {
    "code": "900",
    "message": "Token invalide" // ou "Session expirée"
  },
  "hasError": true
}
```

**Si succès** :
```json
{
  "items": [...],
  "hasError": false,
  "count": 5
}
```

---

## 🔧 ÉTAPE 4 : SOLUTIONS SELON L'ERREUR

### **Erreur : "Token invalide"**

**Cause** : Le token n'existe pas dans la base de données `user`

**Solution** :
```sql
-- Vérifier si le token existe dans la table user
SELECT id, login, token, token_expire_at 
FROM user 
WHERE token = 'VOTRE_TOKEN_ICI';

-- Si aucun résultat, le problème est que le token n'a pas été sauvegardé lors de la connexion
```

**Action** :
1. Se **déconnecter complètement**
2. **Vider le cache** du navigateur (Ctrl+Shift+Del)
3. Se **reconnecter**

---

### **Erreur : "Session expirée"**

**Cause** : Le champ `token_expire_at` dans la BDD est dépassé

**Solution** :
```sql
-- Vérifier l'expiration du token
SELECT 
  id, 
  login, 
  token_expire_at,
  NOW() AS current_time,
  TIMESTAMPDIFF(MINUTE, NOW(), token_expire_at) AS minutes_remaining
FROM user 
WHERE id = 3; -- Votre ID utilisateur

-- Si minutes_remaining est négatif, le token a expiré
```

**Action** : Se reconnecter pour obtenir un nouveau token

---

### **Erreur : "La requete attendue n'est pas celle fournie"**

**Cause** : Format de requête incorrect (`datas` au lieu de `data`)

**Solution** : ✅ Déjà corrigée dans `mouvement.service.ts` ligne 233

**Action** : Redémarrer le frontend pour prendre en compte les modifications

---

## 🔧 ÉTAPE 5 : VÉRIFIER REDIS

Le backend utilise **Redis** pour stocker les sessions. Vérifiez que Redis est démarré :

```bash
# Windows (si Redis installé localement)
redis-cli ping

# Résultat attendu : PONG
```

Si Redis n'est **PAS démarré**, le token ne sera jamais trouvé dans Redis et le backend cherchera dans la BDD.

**Action** : Démarrer Redis si nécessaire

---

## 🎯 CHECKLIST DE RÉSOLUTION

- [ ] **1. Vider le cache du navigateur** (Ctrl+Shift+Del)
- [ ] **2. Se déconnecter complètement**
- [ ] **3. Fermer tous les onglets de l'application**
- [ ] **4. Vérifier que le backend est démarré**
- [ ] **5. Vérifier que Redis est démarré** (si applicable)
- [ ] **6. Se reconnecter** avec vos identifiants
- [ ] **7. Vérifier le localStorage** (console navigateur)
- [ ] **8. Tester la navigation vers `/receptions`**

---

## 📝 SCRIPT DE VÉRIFICATION RAPIDE

**Console navigateur (F12)** :

```javascript
// Script de diagnostic complet
const diagnostic = {
  token: localStorage.getItem('auth_token'),
  user: JSON.parse(localStorage.getItem('dismas_user') || 'null'),
  expiry: localStorage.getItem('token_expiry'),
  allKeys: Object.keys(localStorage)
};

console.table(diagnostic);

// Vérifier si le token est expiré
const expiry = new Date(diagnostic.expiry);
const now = new Date();
console.log('Token expiré ?', expiry <= now);
console.log('Minutes restantes:', Math.floor((expiry - now) / 1000 / 60));
```

---

## 🚨 SI LE PROBLÈME PERSISTE

**Vérifier les logs backend** :

```bash
# Dans le dossier backend
cd D:\DOC DTSI\projects\DAAF\DISMAS\backend\dismas-backend\src
tail -f logs/spring.log  # Ou le fichier de log approprié
```

Cherchez des lignes comme :
- `Token invalide`
- `Session expirée`
- `UserDto userDto = redisUser.get(request.getToken())`

---

## 📄 INFORMATIONS À FOURNIR POUR DEBUG

Si le problème persiste, fournissez-moi :

1. **Console navigateur** : Résultat du script de diagnostic ci-dessus
2. **Network tab** : Request payload de `/mouvement/getByCriteria`
3. **Network tab** : Response de `/mouvement/getByCriteria`
4. **Logs backend** : Les 20 dernières lignes quand l'erreur se produit

---

**Document créé le** : 2025-10-11  
**Objectif** : Diagnostiquer et résoudre le problème de session expirée

