# 🎯 Script de Conversion DISMAS
# Conversion automatique de la présentation en PowerPoint et PDF

param(
    [string]$Format = "all",
    [string]$InputFile = "PRESENTATION_DISMAS_COMPLETE.md",
    [string]$OutputPrefix = "DISMAS_Presentation"
)

Write-Host "🎯 Conversion DISMAS en cours..." -ForegroundColor Green
Write-Host "📁 Fichier source: $InputFile" -ForegroundColor Cyan
Write-Host "🎨 Format demandé: $Format" -ForegroundColor Cyan

# Vérifier si le fichier source existe
if (!(Test-Path $InputFile)) {
    Write-Host "❌ Erreur: Le fichier $InputFile n'existe pas!" -ForegroundColor Red
    exit 1
}

# Vérifier si Pandoc est installé
if (!(Get-Command pandoc -ErrorAction SilentlyContinue)) {
    Write-Host "❌ Pandoc n'est pas installé. Installation en cours..." -ForegroundColor Yellow
    try {
        choco install pandoc -y
        Write-Host "✅ Pandoc installé avec succès!" -ForegroundColor Green
    }
    catch {
        Write-Host "❌ Erreur lors de l'installation de Pandoc. Veuillez l'installer manuellement." -ForegroundColor Red
        Write-Host "💡 Lien: https://pandoc.org/installing.html" -ForegroundColor Cyan
        exit 1
    }
}

# Fonction de conversion
function Convert-DismasPresentation {
    param(
        [string]$Format
    )
    
    switch ($Format.ToLower()) {
        "pptx" {
            Write-Host "🔄 Conversion en PowerPoint..." -ForegroundColor Yellow
            try {
                pandoc $InputFile -o "$OutputPrefix.pptx" --slide-level=2
                Write-Host "✅ Présentation PowerPoint créée: $OutputPrefix.pptx" -ForegroundColor Green
            }
            catch {
                Write-Host "❌ Erreur lors de la conversion PowerPoint" -ForegroundColor Red
            }
        }
        "pdf" {
            Write-Host "🔄 Conversion en PDF..." -ForegroundColor Yellow
            try {
                # Essayer d'abord avec xelatex
                pandoc $InputFile -o "$OutputPrefix.pdf" --pdf-engine=xelatex
                Write-Host "✅ PDF créé avec LaTeX: $OutputPrefix.pdf" -ForegroundColor Green
            }
            catch {
                Write-Host "⚠️ LaTeX non disponible, tentative avec wkhtmltopdf..." -ForegroundColor Yellow
                try {
                    pandoc $InputFile -o "$OutputPrefix.pdf" --pdf-engine=wkhtmltopdf
                    Write-Host "✅ PDF créé avec wkhtmltopdf: $OutputPrefix.pdf" -ForegroundColor Green
                }
                catch {
                    Write-Host "❌ Erreur lors de la conversion PDF" -ForegroundColor Red
                    Write-Host "💡 Installez LaTeX ou wkhtmltopdf pour la conversion PDF" -ForegroundColor Cyan
                }
            }
        }
        "html" {
            Write-Host "🔄 Conversion en HTML..." -ForegroundColor Yellow
            try {
                pandoc $InputFile -o "$OutputPrefix.html" --standalone
                Write-Host "✅ HTML créé: $OutputPrefix.html" -ForegroundColor Green
            }
            catch {
                Write-Host "❌ Erreur lors de la conversion HTML" -ForegroundColor Red
            }
        }
        "all" {
            Write-Host "🔄 Conversion en tous formats..." -ForegroundColor Yellow
            Convert-DismasPresentation "pptx"
            Convert-DismasPresentation "pdf"
            Convert-DismasPresentation "html"
        }
        default {
            Write-Host "❌ Format non supporté: $Format" -ForegroundColor Red
            Write-Host "💡 Formats supportés: pptx, pdf, html, all" -ForegroundColor Cyan
        }
    }
}

# Exécuter la conversion
Convert-DismasPresentation $Format

# Afficher les fichiers créés
Write-Host "`n📊 Fichiers créés:" -ForegroundColor Green
Get-ChildItem -Name "$OutputPrefix.*" | ForEach-Object {
    $size = (Get-Item $_).Length
    $sizeKB = [math]::Round($size / 1KB, 2)
    Write-Host "📄 $_ ($sizeKB KB)" -ForegroundColor Cyan
}

Write-Host "`n🎉 Conversion terminée!" -ForegroundColor Green
Write-Host "🚀 Prêt pour votre présentation client!" -ForegroundColor Green 