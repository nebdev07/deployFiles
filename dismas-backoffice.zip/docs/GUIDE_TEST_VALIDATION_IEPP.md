# 🧪 GUIDE DE TEST - VALIDATION IEPP

## 📋 Objectif
Tester le flow complet de validation IEPP des réceptions EPP avant distribution aux élèves.

---

## ✅ PRÉ-REQUIS

### **Environnement**
- ✅ Backend démarré sur `localhost:8081`
- ✅ Frontend démarré sur `localhost:3000`
- ✅ Base de données MySQL accessible

### **Utilisateurs de Test**
```
IEPP :
- Username: iepp_cocody
- Password: test123
- Structure: IEPP Cocody

EPP :
- Username: epp_cocody_centre
- Password: test123
- Structure: EPP Cocody Centre (parent: IEPP Cocody)
```

---

## 🔄 SCÉNARIO DE TEST COMPLET

### **ÉTAPE 1 : Créer Stock IEPP (Réception Librairie)** ✅

**Connexion** : IEPP (`iepp_cocody`)

**Action** :
1. Aller dans **Réceptions**
2. Cliquer **"Nouvelle Réception IEPP"**
3. Sélectionner catalogue : **CP1 - Catalogue 2024-2025**
4. Saisir quantités :
   - Français CP1 : **1000**
   - Mathématiques CP1 : **1000**
5. Upload bordereau PDF
6. Cliquer **"Enregistrer la Réception"**

**Résultat Attendu** :
- ✅ Toast : "Réception créée avec succès"
- ✅ Réception visible dans la liste
- ✅ Statut : `VALIDEE`
- ✅ Stock IEPP Cocody : **+1000** Français CP1, **+1000** Maths CP1

**Vérification Base de Données** :
```sql
-- Vérifier le mouvement
SELECT * FROM mouvement WHERE type_mouvement = 'IEPP' ORDER BY id DESC LIMIT 1;
-- Statut devrait être 'VALIDEE'

-- Vérifier les stocks créés
SELECT * FROM mouvement_stock WHERE id_mouvement = [ID_MOUVEMENT];
-- Devrait avoir 2 lignes (Français + Maths) avec quantité positive
```

---

### **ÉTAPE 2 : EPP Saisit sa Réception (Demande)** ✅

**Déconnexion + Connexion** : EPP (`epp_cocody_centre`)

**Action** :
1. Aller dans **Réceptions**
2. Cliquer **"Nouvelle Réception EPP"**
3. Sélectionner même catalogue : **CP1 - Catalogue 2024-2025**
4. Saisir quantités demandées :
   - Français CP1 : **150**
   - Mathématiques CP1 : **150**
5. Upload bordereau PDF
6. Cliquer **"Enregistrer la Réception"**

**Résultat Attendu** :
- ✅ Toast : "Réception créée avec succès"
- ✅ Réception visible dans la liste
- ✅ Statut : `EN_ATTENTE` ⚠️
- ✅ Message : "En attente de validation IEPP"
- ✅ Stock IEPP : **PAS ENCORE déduit** (toujours 1000)
- ✅ Stock EPP : **PAS ENCORE crédité** (toujours 0)

**Vérification Base de Données** :
```sql
-- Vérifier le mouvement EPP
SELECT * FROM mouvement WHERE type_mouvement = 'EPP' ORDER BY id DESC LIMIT 1;
-- Statut devrait être 'EN_ATTENTE'

-- Vérifier qu'AUCUN mouvement_stock n'est créé
SELECT * FROM mouvement_stock WHERE id_mouvement = [ID_MOUVEMENT];
-- Devrait être VIDE (pas encore de mouvement de stock)
```

---

### **ÉTAPE 3 : IEPP Valide la Réception EPP** ⭐ **NOUVEAU**

**Déconnexion + Connexion** : IEPP (`iepp_cocody`)

**Action** :
1. Aller dans **Distribution**
2. Vérifier les **onglets** affichés :
   - 📚 Distributions aux Élèves
   - ✅ Validation Réceptions EPP **[1]** ← Badge rouge
3. Cliquer sur onglet **"Validation Réceptions EPP"**
4. Vérifier la liste :
   - EPP Cocody Centre
   - Bordereau : BL-EPP-2024-001
   - Date : 13/10/2025
   - Statut : ⏳ En Attente
5. Cliquer sur **"Valider"**

**Modal de Validation** :
- ✅ Informations réception affichées
- ✅ Tableau des matières :
  ```
  Matière      | Niveau | Demandé | Stock IEPP | Écart | Statut
  Français CP1 | CP1    | 150     | 1000       | 0     | ✓ OK
  Maths CP1    | CP1    | 150     | 1000       | 0     | ✓ OK
  ```
- ✅ Effet de la validation :
  - Stock IEPP sera déduit de **300** manuels
  - Stock EPP sera crédité de **300** manuels
  - EPP pourra distribuer aux élèves

6. (Optionnel) Ajouter observations : "Validation normale, stocks suffisants"
7. Cliquer **"Valider la Distribution"**

**Résultat Attendu** :
- ✅ Toast : "✅ Réception validée avec succès ! Les stocks ont été mis à jour."
- ✅ Réception disparue de la liste (plus en attente)
- ✅ Badge onglet : **[0]** (plus de réception en attente)

**Vérification Base de Données** :
```sql
-- 1. Vérifier le mouvement validé
SELECT * FROM mouvement WHERE id = [ID_MOUVEMENT_EPP];
-- Champs modifiés :
-- statut = 'CONFIRMEE_IEPP'
-- validated_by = [ID_USER_IEPP]
-- validated_at = [TIMESTAMP]
-- validation_level = 'IEPP'

-- 2. Vérifier les MouvementStock créés
SELECT 
  ms.id, 
  ms.type_mouvement, 
  ms.quantite, 
  sa.libelle as structure
FROM mouvement_stock ms
JOIN structure_administrative sa ON ms.id_structure = sa.id
WHERE ms.id_mouvement = [ID_MOUVEMENT_EPP]
ORDER BY ms.id;

-- Résultat attendu (2 lignes) :
-- Ligne 1: DISTRIBUTION EPP, +150 (Français), Structure: EPP Cocody Centre
-- Ligne 2: DISTRIBUTION VERS EPP, -150 (Français), Structure: IEPP Cocody
-- Ligne 3: DISTRIBUTION EPP, +150 (Maths), Structure: EPP Cocody Centre
-- Ligne 4: DISTRIBUTION VERS EPP, -150 (Maths), Structure: IEPP Cocody

-- 3. Vérifier les stocks actuels
-- Stock IEPP (devrait être réduit)
SELECT SUM(quantite) as stock_total 
FROM mouvement_stock 
WHERE id_structure = [ID_IEPP] AND id_matiere = [ID_FRANCAIS_CP1];
-- Résultat attendu : 1000 - 150 = 850

-- Stock EPP (devrait être crédité)
SELECT SUM(quantite) as stock_total 
FROM mouvement_stock 
WHERE id_structure = [ID_EPP] AND id_matiere = [ID_FRANCAIS_CP1];
-- Résultat attendu : 0 + 150 = 150
```

---

### **ÉTAPE 4A : EPP Tente Distribution AVANT Validation** ⚠️ **BLOCAGE**

**Connexion** : EPP (`epp_cocody_centre`)

**Action** :
1. Aller dans **Distribution**
2. Cliquer **"Nouvelle Distribution"**
3. Observer l'interface

**Résultat Attendu** :
- ❌ **ALERTE ROUGE** affichée :
  ```
  🚫 Distribution Bloquée
  La réception EPP doit être validée par l'IEPP avant de pouvoir 
  distribuer les manuels aux élèves.
  
  Statut actuel : EN_ATTENTE
  Contactez votre IEPP pour valider la réception.
  ```
- ❌ **Bouton "Créer la Distribution"** remplacé par **"Distribution Bloquée"**
- ❌ Bouton **désactivé** (grisé)
- ✅ Impossible de soumettre le formulaire

---

### **ÉTAPE 4B : EPP Distribue APRÈS Validation IEPP** ✅ **AUTORISÉ**

**Pré-requis** : IEPP a validé la réception (Étape 3)

**Connexion** : EPP (`epp_cocody_centre`)

**Action** :
1. Aller dans **Distribution**
2. Cliquer **"Nouvelle Distribution"**
3. Observer l'interface

**Résultat Attendu** :
- ✅ **Aucune alerte rouge** (réception validée)
- ✅ **Formulaire actif** (champs accessibles)
- ✅ **Bouton "Créer la Distribution"** actif
- ✅ Peut sélectionner catalogues et quantités

4. Sélectionner catalogue : **CP1**
5. Saisir quantités à distribuer :
   - Classe CP1-A (30 élèves) :
     - Français CP1 : **30**
     - Maths CP1 : **30**
6. Cliquer **"Créer la Distribution"**

**Résultat Attendu** :
- ✅ Toast : "Distribution créée avec succès"
- ✅ Distribution visible dans la liste
- ✅ Stock EPP déduit : 150 - 30 = **120** manuels

**Vérification Base de Données** :
```sql
-- Vérifier la distribution créée
SELECT * FROM distribution_classe ORDER BY id DESC LIMIT 1;

-- Vérifier le mouvement de stock EPP (distribution classe)
SELECT * FROM mouvement_stock 
WHERE type_mouvement = 'DISTRIBUTION CLASSE' 
ORDER BY id DESC LIMIT 2;
-- Quantité devrait être négative : -30 pour chaque matière
```

---

## 🧪 TESTS DE VALIDATION SPÉCIFIQUES

### **TEST 1 : Stock IEPP Insuffisant** ⚠️

**Scénario** :
1. EPP demande **500** Français CP1
2. Stock IEPP disponible : **400**
3. IEPP tente de valider

**Résultat Attendu** :
- ⚠️ Modal affiche : "Stock IEPP: 400" en **ROUGE**
- ⚠️ Statut : "⚠ Insuffisant"
- ❌ Bouton "Valider" **désactivé**
- ⚠️ Message : "Stock IEPP insuffisant pour certaines matières"

---

### **TEST 2 : Écart Positif (Surplus)** ✅

**Scénario** :
1. EPP prévoyait **100** Français CP1
2. EPP reçoit **102** Français CP1
3. Écart : **+2**

**Résultat Attendu** :
- ✅ Écart affiché en **VERT** : "+2"
- ✅ Validation possible
- ✅ Stock EPP crédité de **102** (quantité réelle reçue)

---

### **TEST 3 : Écart Négatif (Manque)** ⚠️

**Scénario** :
1. EPP prévoyait **100** Français CP1
2. EPP reçoit **98** Français CP1
3. Écart : **-2**

**Résultat Attendu** :
- ⚠️ Écart affiché en **ROUGE** : "-2"
- ✅ Validation possible (stock IEPP suffisant)
- ✅ Stock EPP crédité de **98** (quantité réelle reçue)
- 📝 Observations IEPP recommandées

---

### **TEST 4 : Plusieurs Catalogues** ✅

**Scénario** :
1. EPP demande :
   - Catalogue CP1 : 150 manuels
   - Catalogue CP2 : 120 manuels
   - Catalogue CE1 : 100 manuels
2. IEPP valide

**Résultat Attendu** :
- ✅ Modal affiche **3 catalogues**
- ✅ Vérification stock pour **chaque catalogue**
- ✅ Si tous OK → Validation possible
- ✅ Si un KO → Validation bloquée
- ✅ Création de **6 MouvementStock** (2 par catalogue)

---

## 🎯 CHECKLIST DE VALIDATION

### **Backend** ✅
- [ ] Mouvement IEPP créé avec statut VALIDEE
- [ ] Mouvement EPP créé avec statut EN_ATTENTE
- [ ] Endpoint `/mouvement/validate` répond correctement
- [ ] Statut change EN_ATTENTE → CONFIRMEE_IEPP
- [ ] MouvementStock SORTIE créé pour IEPP (quantité négative)
- [ ] MouvementStock ENTREE créé pour EPP (quantité positive)
- [ ] Stock IEPP calculé correctement
- [ ] Stock EPP calculé correctement

### **Frontend** ✅
- [ ] Onglets visibles pour IEPP
- [ ] Badge avec nombre réceptions en attente
- [ ] Liste réceptions EPP chargée
- [ ] Modal validation s'ouvre
- [ ] Stock IEPP affiché correctement
- [ ] Blocage si stock insuffisant
- [ ] Validation réussie → Toast succès
- [ ] Alerte rouge affichée si EPP pas validé
- [ ] Bouton distribution bloqué si pas validé
- [ ] Distribution autorisée après validation

---

## 📊 REQUÊTES SQL UTILES

### **1. Vérifier Stock IEPP**
```sql
SELECT 
  m.libelle as matiere,
  ns.libelle as niveau,
  SUM(ms.quantite) as stock_disponible
FROM mouvement_stock ms
JOIN matiere m ON ms.id_matiere = m.id
JOIN niveau_scolaire ns ON ms.id_niveau_scolaire = ns.id
WHERE ms.id_structure = [ID_IEPP]
  AND ms.is_deleted = false
GROUP BY m.id, ns.id;
```

### **2. Vérifier Stock EPP**
```sql
SELECT 
  m.libelle as matiere,
  ns.libelle as niveau,
  SUM(ms.quantite) as stock_disponible
FROM mouvement_stock ms
JOIN matiere m ON ms.id_matiere = m.id
JOIN niveau_scolaire ns ON ms.id_niveau_scolaire = ns.id
WHERE ms.id_structure = [ID_EPP]
  AND ms.is_deleted = false
GROUP BY m.id, ns.id;
```

### **3. Historique Mouvement**
```sql
SELECT 
  mv.id,
  mv.type_mouvement,
  mv.statut,
  mv.validated_by,
  mv.validated_at,
  mv.validation_level,
  sa.libelle as structure
FROM mouvement mv
JOIN structure_administrative sa ON mv.id_structure = sa.id
WHERE mv.id = [ID_MOUVEMENT];
```

### **4. Détails MatiereQuantite**
```sql
SELECT 
  mq.id,
  m.libelle as matiere,
  ns.libelle as niveau,
  mq.quantite_recue,
  mq.quantite_prevue,
  mq.ecart,
  mq.type_operation,
  mq.statut_stock
FROM matiere_quantite mq
JOIN matiere m ON mq.id_matiere = m.id
LEFT JOIN niveau_scolaire ns ON mq.id_niveau_scolaire = ns.id
WHERE mq.id_catalogue_mouvement IN (
  SELECT id FROM catalogue_mouvement WHERE id_mouvement = [ID_MOUVEMENT]
);
```

---

## 🐛 PROBLÈMES POTENTIELS ET SOLUTIONS

### **Problème 1 : "Niveau scolaire manquant"**
**Cause** : `CatalogueMatiere` n'a pas de `niveau_scolaire_id`  
**Solution** :
```sql
UPDATE catalogue_matiere 
SET niveau_scolaire_id = 1  -- ID du niveau (CP1, CP2, etc.)
WHERE catalogue_id = [ID_CATALOGUE] 
  AND matiere_id = [ID_MATIERE];
```

### **Problème 2 : "IEPP parent non trouvé"**
**Cause** : Structure EPP n'a pas de parent IEPP défini  
**Solution** :
```sql
UPDATE structure_administrative 
SET parent_id = [ID_IEPP]  -- ID de l'IEPP parent
WHERE id = [ID_EPP] AND type = 'EPP';
```

### **Problème 3 : "Stock IEPP insuffisant"**
**Cause** : IEPP n'a pas reçu assez de manuels du librairie  
**Solution** :
1. Créer une nouvelle réception IEPP avec quantités suffisantes
2. Ou ajuster la demande EPP

### **Problème 4 : "Réception déjà validée"**
**Cause** : Tentative de re-validation d'une réception déjà validée  
**Solution** : Normal, ignorer (protection backend)

---

## 📈 MÉTRIQUES DE SUCCÈS

### **Indicateurs Fonctionnels**
- ✅ IEPP peut voir les réceptions EPP en attente
- ✅ IEPP peut valider une réception EPP
- ✅ Stocks IEPP et EPP mis à jour correctement
- ✅ EPP ne peut PAS distribuer si pas validé IEPP
- ✅ EPP PEUT distribuer après validation IEPP

### **Indicateurs Techniques**
- ✅ 0 erreur backend lors validation
- ✅ 0 erreur frontend lors affichage
- ✅ Temps de réponse < 2 secondes
- ✅ Transactions atomiques (rollback en cas d'erreur)

### **Indicateurs UX**
- ✅ Interface intuitive et claire
- ✅ Feedback immédiat (toast, loading)
- ✅ Messages d'erreur explicites
- ✅ Guidage utilisateur (alertes, badges)

---

## ✅ VALIDATION FINALE

**Ce test est réussi si** :

1. ✅ IEPP peut créer réception (librairie → IEPP)
2. ✅ EPP peut créer réception (demande → IEPP)
3. ✅ IEPP voit réception EPP en attente
4. ✅ IEPP peut valider réception EPP
5. ✅ Stocks mis à jour automatiquement (IEPP -, EPP +)
6. ✅ EPP **bloquée** avant validation IEPP
7. ✅ EPP **autorisée** après validation IEPP

**Si tous les points sont verts → SYSTÈME PRÊT POUR PRODUCTION** ✅

---

## 📞 SUPPORT

En cas de problème lors des tests :

1. **Vérifier les logs backend** : Console Spring Boot
2. **Vérifier les logs frontend** : Console navigateur (F12)
3. **Vérifier la base de données** : Requêtes SQL ci-dessus
4. **Consulter la documentation** :
   - `IMPLEMENTATION_VALIDATION_IEPP_COMPLETE.md`
   - `ANALYSE_ETAT_LIEUX_VALIDATION_IEPP.md`

---

**Guide de Test DISMAS - Validation IEPP**  
**Version** : 1.0  
**Date** : 13/10/2025  
**Statut** : ✅ Prêt pour tests

