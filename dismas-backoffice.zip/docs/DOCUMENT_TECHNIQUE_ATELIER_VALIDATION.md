# DOCUMENT TECHNIQUE - ATELIER DE VALIDATION
## Plateforme DISMAS - Système de Distribution des Manuels Scolaires

---

## 📋 **TABLE DES MATIÈRES**

1. [Vue d'ensemble du projet](#vue-densemble-du-projet)
2. [Analyse technique détaillée](#analyse-technique-détaillée)
3. [Architecture et spécifications](#architecture-et-spécifications)
4. [Plan de développement](#plan-de-développement)
5. [Estimation des ressources](#estimation-des-ressources)
6. [Planning et phases](#planning-et-phases)
7. [Risques et mitigation](#risques-et-mitigation)
8. [Conclusion et recommandations](#conclusion-et-recommandations)

---

## 🎯 **VUE D'ENSEMBLE DU PROJET**

### **Contexte et Justification**

La Côte d'Ivoire fait face à des défis majeurs dans la distribution des manuels scolaires :

- **Traçabilité limitée** : Impossible de suivre les manuels de la commande à la distribution
- **Processus manuel** : Documents papier, saisies Excel, calculs manuels
- **Erreurs fréquentes** : Saisies incorrectes, calculs erronés, perte de documents
- **Délais importants** : Processus séquentiel lent, validation par plusieurs niveaux
- **Absence de contrôle** : Pas de validation automatique, impossibilité de détecter les anomalies

### **Objectifs du Projet DISMAS**

1. **Digitalisation complète** du processus de distribution
2. **Traçabilité en temps réel** des manuels
3. **Optimisation des stocks** et prévention des pénuries
4. **Amélioration de la qualité** du service éducatif
5. **Réduction des coûts** de gestion et distribution

### **Valeur Ajoutée**

- **Efficacité** : Réduction de 70% du temps de traitement
- **Précision** : Élimination des erreurs de saisie et calcul
- **Transparence** : Visibilité totale sur le processus
- **Contrôle** : Validation automatique et alertes en temps réel

---

## 🔧 **ANALYSE TECHNIQUE DÉTAILLÉE**

### **A) Analyse de l'Existant**

#### **Processus Actuel**
```
Expression des besoins (Papier) → Consolidation manuelle → Commande Excel → Distribution physique → Suivi téléphonique
```

#### **Problèmes Techniques Identifiés**

1. **Données non structurées**
   - Documents papier non standardisés
   - Fichiers Excel non centralisés
   - Absence de base de données

2. **Processus non automatisés**
   - Calculs manuels des besoins
   - Validation par signatures physiques
   - Communication asynchrone

3. **Absence de traçabilité**
   - Impossible de localiser un manuel
   - Pas d'historique des mouvements
   - Absence de statistiques

### **B) Solution Technique Proposée**

#### **Architecture Globale**
```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   Frontend      │    │   Backend       │    │   Base de       │
│   (Next.js)     │◄──►│   (Spring Boot) │◄──►│   Données       │
│                 │    │                 │    │   (MySQL)       │
└─────────────────┘    └─────────────────┘    └─────────────────┘
         │                       │                       │
         │                       │                       │
         ▼                       ▼                       ▼
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   Vercel        │    │   Docker        │    │   Backup        │
│   (Déploiement) │    │   (Container)   │    │   (Automated)   │
└─────────────────┘    └─────────────────┘    └─────────────────┘
```

#### **Stack Technologique**

**Frontend**
- **Framework** : Next.js 15.2.4 avec React 19
- **Langage** : TypeScript pour la robustesse
- **Styling** : Tailwind CSS pour un design moderne
- **UI Components** : Radix UI + Shadcn/ui
- **State Management** : React Hooks (useState, useContext)
- **Déploiement** : Vercel pour la performance

**Backend**
- **Framework** : Spring Boot 3.x
- **Langage** : Java 17+ pour la stabilité
- **Base de données** : MySQL 8.0
- **ORM** : JPA/Hibernate
- **Sécurité** : Spring Security + JWT
- **API** : RESTful APIs
- **Documentation** : Swagger/OpenAPI

**Infrastructure**
- **Base de données** : MySQL avec réplication
- **Cache** : Redis pour les performances
- **Stockage fichiers** : AWS S3 ou équivalent
- **Monitoring** : Spring Boot Actuator

---

## 🏗️ **ARCHITECTURE ET SPÉCIFICATIONS**

### **A) Flux Fonctionnel Principal**

#### **1. Expression des Besoins (Bottom-Up)**
```
EPP → IEPP → DRENA → MENA/DAF
```

**Étape 1 : Expression au niveau EPP**
- Saisie des effectifs par niveau
- Calcul automatique des besoins
- Sélection des manuels requis

**Étape 2 : Consolidation IEPP**
- Regroupement des besoins EPP
- Validation et ajustement
- Statut : SAISI → VALIDE → CONSOLIDE

**Étape 3 : Consolidation DRENA**
- Regroupement des consolidations IEPP
- Validation régionale
- Statut : EN_COURS → VALIDE → CONSOLIDE

#### **2. Gestion des Commandes (DAF)**
- Synthèse des besoins consolidés
- Saisie des quantités commandées
- Génération du tableau de répartition

#### **3. Distribution (Top-Down)**
```
MENA → DRENA → IEPP → EPP
```

**Étape 1 : Tableau de Répartition**
- Calcul automatique des allocations
- Répartition équitable basée sur les effectifs
- Génération des documents de distribution

**Étape 2 : Distribution Physique**
- Suivi des livraisons
- Validation des réceptions
- Gestion des retours et réclamations

### **B) Modules Fonctionnels**

#### **1. Dashboard**
- Statistiques globales
- Indicateurs par rôle
- Alertes et notifications
- Vue d'ensemble des stocks

#### **2. Expression des Besoins**
- Saisie des besoins EPP
- Consolidation IEPP
- Consolidation DRENA
- Validation et approbation

#### **3. Commandes**
- Synthèse des besoins consolidés
- Saisie des quantités commandées
- Génération du tableau de répartition
- Export des documents

#### **4. Tableau de Répartition**
- Vue d'ensemble des répartitions
- Détails par DRENA/IEPP/EPP
- Sélection d'année scolaire
- Export PDF/Excel

#### **5. Stocks**
- Gestion des stocks par structure
- Suivi des mouvements
- Alertes de stock faible
- Inventaire physique

#### **6. Distribution**
- Suivi des livraisons
- Validation des réceptions
- Gestion des distributions aux élèves
- Historique des distributions

#### **7. Régulation**
- Transferts entre structures
- Ajustements de stocks
- Gestion des surplus/déficits

#### **8. Retours**
- Saisie des retours d'élèves
- Validation des retours
- Réintégration en stock

#### **9. Réclamations**
- Saisie des réclamations
- Suivi du traitement
- Résolution des problèmes

#### **10. Rapports**
- Rapports de distribution
- Statistiques d'utilisation
- Rapports financiers
- Export des données

### **C) Gestion des Utilisateurs**

#### **Hiérarchie des Rôles**
```
ADMIN (Niveau 1)
├── DAF (Niveau 2)
├── DRENA (Niveau 3)
│   └── IEPP (Niveau 4)
│       └── EPP (Niveau 5)
│           ├── DIRECTEUR (Niveau 6)
│           ├── MAITRE (Niveau 7)
│           └── COGES (Niveau 8)
```

#### **Permissions par Rôle**

| Rôle | Niveau | Permissions Principales |
|------|--------|------------------------|
| ADMIN | 1 | Toutes les permissions |
| DAF | 2 | Gestion financière, commandes, tableau de répartition |
| DRENA | 3 | Consolidation régionale, régulation |
| IEPP | 4 | Consolidation départementale |
| DIRECTEUR | 6 | Gestion EPP, expression des besoins |
| MAITRE | 7 | Distribution aux élèves |
| COGES | 8 | Suivi et contrôle |

### **D) Base de Données**

#### **Tables Principales**

**Gestion des Manuels**
- `manuel` : Catalogue des manuels
- `niveau` : Niveaux scolaires
- `manuel_niveau` : Association manuels-niveaux

**Gestion des Structures**
- `structure` : Structures (MENA, DRENA, IEPP, EPP)
- `type_structure` : Types de structures

**Expression des Besoins**
- `besoin` : Besoins exprimés par EPP
- `besoin_detail` : Détails des besoins
- `consolidation_iepp` : Consolidations IEPP
- `consolidation_drena` : Consolidations DRENA

**Commandes et Distribution**
- `commande` : Commandes DAF
- `commande_detail` : Détails des commandes
- `tableau_repartition` : Tableau de répartition
- `repartition_detail` : Détails de répartition

**Stocks et Mouvements**
- `stock` : Stocks par structure
- `mouvement_stock` : Mouvements de stock
- `distribution` : Distributions aux élèves
- `retour` : Retours d'élèves

**Gestion des Utilisateurs**
- `user` : Utilisateurs
- `role` : Rôles
- `fonctionalite` : Fonctionnalités
- `role_fonctionalite` : Permissions

---

## 🚀 **PLAN DE DÉVELOPPEMENT**

### **A) Approche de Développement**

#### **Méthodologie Agile**
- **Sprints** de 2 semaines
- **Daily Standups** pour le suivi
- **Sprint Reviews** pour la validation
- **Retrospectives** pour l'amélioration

#### **Architecture Modulaire**
- **Modules indépendants** pour faciliter le développement
- **APIs RESTful** pour l'intégration
- **Tests automatisés** pour la qualité
- **Documentation continue** pour la maintenance

### **B) Phases de Développement**

#### **Phase 1 : Fondations (4 semaines)**
- **Semaine 1-2** : Setup de l'environnement
  - Configuration Next.js
  - Setup Spring Boot
  - Configuration MySQL
  - Mise en place CI/CD

- **Semaine 3-4** : Architecture de base
  - Authentification JWT
  - Gestion des utilisateurs
  - Structure de base de données
  - APIs de base

#### **Phase 2 : Modules Core (6 semaines)**
- **Semaine 5-6** : Expression des besoins
  - Interface de saisie EPP
  - Logique de consolidation
  - Validation des données

- **Semaine 7-8** : Commandes et répartition
  - Interface de commandes
  - Calcul de répartition
  - Génération de documents

- **Semaine 9-10** : Stocks et distribution
  - Gestion des stocks
  - Suivi des distributions
  - Mouvements de stock

#### **Phase 3 : Modules Avancés (4 semaines)**
- **Semaine 11-12** : Régulation et retours
  - Transferts entre structures
  - Gestion des retours
  - Ajustements de stocks

- **Semaine 13-14** : Rapports et analytics
  - Tableaux de bord
  - Rapports exportables
  - Statistiques avancées

#### **Phase 4 : Finalisation (2 semaines)**
- **Semaine 15** : Tests et optimisation
  - Tests d'intégration
  - Tests de performance
  - Optimisations

- **Semaine 16** : Déploiement
  - Déploiement production
  - Formation utilisateurs
  - Documentation finale

---

## 💰 **ESTIMATION DES RESSOURCES**

### **A) Équipe de Développement**

#### **Équipe Frontend (2 personnes)**
- **1 Lead Frontend Developer** (Senior)
  - Next.js, React, TypeScript
  - 8 semaines à 100%
  - Coût : 16,000€

- **1 Frontend Developer** (Mid-level)
  - UI/UX, Tailwind CSS
  - 8 semaines à 100%
  - Coût : 12,000€

#### **Équipe Backend (2 personnes)**
- **1 Lead Backend Developer** (Senior)
  - Spring Boot, Java, MySQL
  - 8 semaines à 100%
  - Coût : 16,000€

- **1 Backend Developer** (Mid-level)
  - APIs, sécurité, tests
  - 8 semaines à 100%
  - Coût : 12,000€

#### **Équipe DevOps (1 personne)**
- **1 DevOps Engineer** (Senior)
  - CI/CD, déploiement, monitoring
  - 4 semaines à 100%
  - Coût : 8,000€

### **B) Infrastructure**

#### **Développement**
- **Serveurs de développement** : 1,000€
- **Licences logiciels** : 2,000€
- **Outils de collaboration** : 500€

#### **Production**
- **Serveurs de production** : 5,000€
- **Base de données** : 3,000€
- **Monitoring et sécurité** : 2,000€

### **C) Formation et Support**

#### **Formation Utilisateurs**
- **Sessions de formation** : 3,000€
- **Documentation utilisateur** : 2,000€
- **Support post-déploiement** : 5,000€

### **D) Total Estimé**

| Catégorie | Coût |
|-----------|------|
| **Développement** | 64,000€ |
| **Infrastructure** | 13,500€ |
| **Formation/Support** | 10,000€ |
| **Contingence (15%)** | 13,125€ |
| **TOTAL** | **100,625€** |

---

## 📅 **PLANNING ET PHASES**

### **A) Planning Détaillé**

#### **Mois 1 : Fondations**
```
Semaine 1-2 : Setup et Architecture
├── Configuration environnement
├── Architecture de base
├── Authentification
└── Base de données

Semaine 3-4 : Modules Core
├── Gestion utilisateurs
├── Expression des besoins
└── APIs de base
```

#### **Mois 2 : Développement Core**
```
Semaine 5-6 : Expression des Besoins
├── Interface EPP
├── Consolidation IEPP
└── Validation

Semaine 7-8 : Commandes
├── Interface commandes
├── Calcul répartition
└── Génération documents
```

#### **Mois 3 : Modules Avancés**
```
Semaine 9-10 : Stocks et Distribution
├── Gestion stocks
├── Suivi distributions
└── Mouvements

Semaine 11-12 : Régulation
├── Transferts
├── Retours
└── Ajustements
```

#### **Mois 4 : Finalisation**
```
Semaine 13-14 : Rapports
├── Tableaux de bord
├── Export données
└── Statistiques

Semaine 15-16 : Déploiement
├── Tests finaux
├── Déploiement production
└── Formation utilisateurs
```

### **B) Jalons Clés**

| Jalon | Date | Livrable |
|-------|------|----------|
| **J1** | Semaine 2 | Architecture validée |
| **J2** | Semaine 6 | Expression des besoins fonctionnelle |
| **J3** | Semaine 10 | Commandes et répartition opérationnelles |
| **J4** | Semaine 14 | Tous modules fonctionnels |
| **J5** | Semaine 16 | Plateforme en production |

### **C) Critères de Validation**

#### **Critères Techniques**
- ✅ Tests unitaires > 80% de couverture
- ✅ Tests d'intégration passés
- ✅ Performance < 2s de temps de réponse
- ✅ Sécurité validée par audit

#### **Critères Fonctionnels**
- ✅ Tous les workflows implémentés
- ✅ Interface utilisateur intuitive
- ✅ Export des données fonctionnel
- ✅ Gestion des erreurs robuste

#### **Critères Métier**
- ✅ Respect du flux bottom-up/top-down
- ✅ Traçabilité complète des manuels
- ✅ Validation par niveaux hiérarchiques
- ✅ Rapports et statistiques disponibles

---

## ⚠️ **RISQUES ET MITIGATION**

### **A) Risques Techniques**

#### **Risque 1 : Complexité de l'intégration**
- **Impact** : Retard dans le développement
- **Probabilité** : Moyenne
- **Mitigation** : 
  - Architecture modulaire
  - APIs bien documentées
  - Tests d'intégration précoces

#### **Risque 2 : Performance de la base de données**
- **Impact** : Lenteur de l'application
- **Probabilité** : Faible
- **Mitigation** :
  - Optimisation des requêtes
  - Index appropriés
  - Cache Redis

#### **Risque 3 : Sécurité des données**
- **Impact** : Compromission des données
- **Probabilité** : Faible
- **Mitigation** :
  - Audit de sécurité
  - Chiffrement des données sensibles
  - Tests de pénétration

### **B) Risques Métier**

#### **Risque 1 : Résistance au changement**
- **Impact** : Adoption lente par les utilisateurs
- **Probabilité** : Moyenne
- **Mitigation** :
  - Formation intensive
  - Interface intuitive
  - Support utilisateur

#### **Risque 2 : Évolution des besoins**
- **Impact** : Modifications en cours de projet
- **Probabilité** : Moyenne
- **Mitigation** :
  - Architecture flexible
  - Sprints courts
  - Validation continue

#### **Risque 3 : Volume de données**
- **Impact** : Performance dégradée
- **Probabilité** : Faible
- **Mitigation** :
  - Pagination
  - Filtres avancés
  - Optimisation des requêtes

### **C) Plan de Contingence**

#### **Scénario 1 : Retard de développement**
- **Action** : Ajout d'un développeur
- **Coût** : +25% du budget
- **Délai** : +2 semaines

#### **Scénario 2 : Problème de performance**
- **Action** : Optimisation et cache
- **Coût** : +10% du budget
- **Délai** : +1 semaine

#### **Scénario 3 : Évolution des besoins**
- **Action** : Phase supplémentaire
- **Coût** : +30% du budget
- **Délai** : +4 semaines

---

## 🎯 **CONCLUSION ET RECOMMANDATIONS**

### **A) Synthèse du Projet**

La plateforme DISMAS représente une solution complète et moderne pour la gestion des manuels scolaires en Côte d'Ivoire. Son architecture robuste, son interface intuitive et son flux fonctionnel optimisé en font un outil indispensable pour l'administration scolaire.

#### **Points Forts**
- **Architecture moderne** : Next.js + Spring Boot
- **Flux optimisé** : Bottom-up puis top-down
- **Sécurité renforcée** : RBAC + audit trail
- **Interface intuitive** : Design system cohérent
- **Scalabilité** : Architecture microservices ready

#### **Avantages Métier**
- **Réduction des pertes** : Traçabilité complète
- **Optimisation des coûts** : Gestion centralisée
- **Transparence** : Visibilité totale du processus
- **Efficacité** : Automatisation des tâches répétitives

### **B) Recommandations**

#### **Recommandation 1 : Déploiement Progressif**
- **Phase 1** : Déploiement pilote dans 2 régions
- **Phase 2** : Extension à 5 régions
- **Phase 3** : Déploiement national

#### **Recommandation 2 : Formation Intensive**
- **Sessions de formation** : 2 jours par niveau
- **Documentation** : Guides utilisateur détaillés
- **Support** : Hotline dédiée

#### **Recommandation 3 : Monitoring Continu**
- **KPIs** : Temps de traitement, taux d'erreur
- **Alertes** : Problèmes techniques, anomalies
- **Rapports** : Utilisation, performance

### **C) Prochaines Étapes**

#### **Étape 1 : Validation du Document**
- **Révision** par l'équipe technique
- **Validation** par les parties prenantes
- **Approbation** du budget et planning

#### **Étape 2 : Lancement du Projet**
- **Recrutement** de l'équipe
- **Setup** de l'environnement
- **Début** du développement

#### **Étape 3 : Suivi et Contrôle**
- **Réunions** hebdomadaires de suivi
- **Rapports** mensuels d'avancement
- **Ajustements** si nécessaire

### **D) ROI Attendu**

#### **Gains Quantifiables**
- **Réduction des pertes** : 30% (économie estimée : 500,000€/an)
- **Optimisation des stocks** : 20% (économie estimée : 200,000€/an)
- **Réduction des délais** : 70% (gain de productivité : 300,000€/an)

#### **Gains Qualifiables**
- **Amélioration de la qualité** éducative
- **Transparence** du processus
- **Satisfaction** des utilisateurs
- **Modernisation** de l'administration

### **E) Conclusion**

La plateforme DISMAS est prête pour le déploiement en production. Son architecture robuste, son interface intuitive et son flux fonctionnel optimisé en font un outil indispensable pour l'administration scolaire ivoirienne.

**Investissement** : 100,625€
**ROI annuel** : 1,000,000€
**Période de retour** : 1.2 mois

Le projet DISMAS représente une opportunité unique de moderniser la gestion des manuels scolaires en Côte d'Ivoire, avec un impact positif immédiat sur l'efficacité administrative et la qualité du service éducatif.

---

**Document préparé pour l'Atelier de Validation du Document d'Analyse et de Développement de la Plateforme DISMAS**

*Date : [Date de l'atelier]*  
*Version : 1.0*  
*Préparé par : Équipe Technique DISMAS* 