# Script PowerShell pour redémarrer le frontend Next.js

Write-Host "=====================================" -ForegroundColor Cyan
Write-Host "REDÉMARRAGE DU FRONTEND DISMAS" -ForegroundColor Cyan
Write-Host "=====================================" -ForegroundColor Cyan

# 1. Arrêter tous les processus Node.js (Next.js)
Write-Host ""
Write-Host "Étape 1: Arrêt des processus Node.js..." -ForegroundColor Yellow
$nodeProcesses = Get-Process -Name "node" -ErrorAction SilentlyContinue
if ($nodeProcesses) {
    $nodeProcesses | Stop-Process -Force
    Write-Host "✅ Processus Node.js arrêtés" -ForegroundColor Green
} else {
    Write-Host "ℹ️  Aucun processus Node.js en cours" -ForegroundColor Gray
}

# 2. Supprimer le cache Next.js
Write-Host ""
Write-Host "Étape 2: Nettoyage du cache Next.js..." -ForegroundColor Yellow
if (Test-Path ".next") {
    Remove-Item -Path ".next" -Recurse -Force
    Write-Host "✅ Cache .next supprimé" -ForegroundColor Green
} else {
    Write-Host "ℹ️  Pas de cache .next trouvé" -ForegroundColor Gray
}

# 3. Démarrer le serveur de développement
Write-Host ""
Write-Host "Étape 3: Démarrage du serveur Next.js..." -ForegroundColor Yellow
Write-Host ""
Write-Host "=====================================" -ForegroundColor Cyan
Write-Host "SERVEUR EN COURS DE DÉMARRAGE..." -ForegroundColor Cyan
Write-Host "=====================================" -ForegroundColor Cyan
Write-Host ""

# Vérifier si npm, pnpm ou yarn est utilisé
if (Test-Path "pnpm-lock.yaml") {
    Write-Host "📦 Utilisation de pnpm détectée" -ForegroundColor Cyan
    pnpm dev
} elseif (Test-Path "yarn.lock") {
    Write-Host "📦 Utilisation de yarn détectée" -ForegroundColor Cyan
    yarn dev
} else {
    Write-Host "📦 Utilisation de npm par défaut" -ForegroundColor Cyan
    npm run dev
}

