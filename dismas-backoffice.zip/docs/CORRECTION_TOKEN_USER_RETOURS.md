# 🔐 Correction - Token et User ID dans retour.service.ts

## 📋 Problème identifié

Le service `retour.service.ts` utilisait des valeurs hardcodées pour le token et l'user ID :

```typescript
const userId = 1; // TODO: Récupérer l'ID de l'utilisateur connecté
const token = 'dummy-token'; // TODO: Récupérer le token d'authentification
```

## ✅ Solution appliquée

### **Utilisation des méthodes de BaseApiService**

Le service `BaseApiService` expose deux méthodes protégées pour récupérer les informations d'authentification :

1. **`this.getCurrentUserId()`** : Récupère l'ID de l'utilisateur depuis le localStorage
2. **`this.getAuthToken()`** : Récupère le token d'authentification depuis le localStorage

### **Code corrigé**

```typescript
private buildRequest(data: any, isCreateUpdate: boolean = true): any {
  const userId = this.getCurrentUserId();
  const token = this.getAuthToken();
  
  // Vérifier si l'utilisateur est connecté
  if (!userId || !token) {
    console.warn('Utilisateur non connecté - impossible de gérer les retours');
    throw new Error('Utilisateur non connecté');
  }
  
  const baseRequest = {
    user: userId,
    token: token,
    isSimpleLoading: false
  };
  
  if (isCreateUpdate) {
    return {
      ...baseRequest,
      datas: Array.isArray(data) ? data : [data]
    };
  } else {
    return {
      ...baseRequest,
      data: data
    };
  }
}
```

## 🔍 Détails des méthodes utilisées

### **1. getCurrentUserId()**

**Source** : `BaseApiService` (lignes 243-257)

```typescript
protected getCurrentUserId(): number | null {
  if (typeof window !== 'undefined') {
    const userSession = localStorage.getItem('dismas_user') || localStorage.getItem('user_session');
    if (userSession) {
      try {
        const user = JSON.parse(userSession);
        return user.id || null;
      } catch (error) {
        console.error('Erreur lors du parsing de la session utilisateur:', error);
        return null;
      }
    }
  }
  return null;
}
```

**Clés localStorage recherchées** :
- `dismas_user` (prioritaire)
- `user_session` (fallback)

### **2. getAuthToken()**

**Source** : `BaseApiService` (lignes 233-238)

```typescript
protected getAuthToken(): string | null {
  if (typeof window !== 'undefined') {
    return localStorage.getItem('auth_token');
  }
  return null;
}
```

**Clé localStorage** : `auth_token`

## 🛡️ Gestion des erreurs

### **Utilisateur non connecté**

Si l'utilisateur n'est pas connecté (pas de token ou pas d'ID) :

```typescript
if (!userId || !token) {
  console.warn('Utilisateur non connecté - impossible de gérer les retours');
  throw new Error('Utilisateur non connecté');
}
```

**Comportement** :
- Log d'avertissement dans la console
- Exception levée
- Le composant affichera un toast d'erreur

### **Token expiré**

Le `BaseApiService` gère automatiquement les tokens expirés :

1. Détection des erreurs HTTP 401/403
2. Détection des erreurs métier avec code "900"
3. Nettoyage du localStorage
4. Notification utilisateur
5. Redirection vers la page de connexion (après 2s)

## 📊 Pattern utilisé

### **Pattern identique aux autres services**

Le pattern utilisé est exactement le même que :
- ✅ `reception.service.ts` (lignes 88-96)
- ✅ `distribution.service.ts` (sera corrigé également)
- ✅ Tous les services étendant `BaseApiService`

### **Structure de la requête backend**

```typescript
{
  user: 123,                    // ID de l'utilisateur connecté
  token: "abc123...",           // Token d'authentification
  isSimpleLoading: false,       // Flag de chargement
  datas: [{ ... }]              // Données (CREATE/UPDATE/DELETE)
  // OU
  data: { ... }                 // Données (GET/SEARCH)
}
```

## 🔄 Comparaison Avant/Après

### **Avant (Hardcodé)**
```typescript
const userId = 1;
const token = 'dummy-token';
```

**Problèmes** :
- ❌ Toujours le même utilisateur (ID = 1)
- ❌ Token invalide ("dummy-token")
- ❌ Authentification échoue côté backend
- ❌ Impossible de tracer qui a créé/modifié les données

### **Après (Dynamique)**
```typescript
const userId = this.getCurrentUserId();
const token = this.getAuthToken();
```

**Avantages** :
- ✅ Utilisateur réel récupéré depuis la session
- ✅ Token valide récupéré depuis le localStorage
- ✅ Authentification réussit côté backend
- ✅ Traçabilité correcte (createdBy, updatedBy)

## 🧪 Tests à effectuer

### **Test 1 : Vérifier le localStorage**
```javascript
// Dans la console du navigateur
console.log('User:', localStorage.getItem('dismas_user'))
console.log('Token:', localStorage.getItem('auth_token'))
```

**Attendu** :
```json
User: {"id":5,"login":"epp_user","nom":"User","prenom":"EPP",...}
Token: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
```

### **Test 2 : Créer un retour**
```
1. Se connecter avec un utilisateur EPP
2. Aller sur /retours
3. Cliquer "Nouveau Retour"
4. Remplir le formulaire
5. Soumettre
```

**Attendu** :
- ✅ Requête POST avec userId et token corrects
- ✅ Backend valide le token
- ✅ Retour créé avec le bon createdBy

### **Test 3 : Vérifier les logs réseau**
```
1. Ouvrir F12 > Onglet Network
2. Créer un retour
3. Cliquer sur la requête POST /retourManuel/create
4. Onglet "Payload" > Voir le corps de la requête
```

**Attendu** :
```json
{
  "user": 5,
  "token": "eyJhbGci...",
  "isSimpleLoading": false,
  "datas": [{
    "structureId": 5,
    "anneeScolaireId": 2,
    ...
  }]
}
```

## 🔧 Dépannage

### **Erreur : "Utilisateur non connecté"**

**Cause** : Pas de session dans le localStorage

**Solution** :
1. Déconnexion/Reconnexion
2. Vérifier que le login enregistre bien la session
3. Vérifier les clés localStorage (`dismas_user`, `auth_token`)

### **Erreur : "Token invalide" ou "Session expirée"**

**Cause** : Token expiré ou corrompu

**Solution** :
1. Le système redirige automatiquement vers /auth/login
2. Se reconnecter pour obtenir un nouveau token

### **Erreur : "Backend refuse la requête"**

**Cause** : Token non reconnu par le backend

**Solution** :
1. Vérifier que le backend est démarré
2. Vérifier la configuration JWT dans le backend
3. Vérifier que le token est bien envoyé dans le header `Authorization`

## 📝 Fichiers modifiés

1. ✅ `lib/services/retour.service.ts`
   - Méthode `buildRequest()` corrigée
   - Utilisation de `this.getCurrentUserId()`
   - Utilisation de `this.getAuthToken()`
   - Vérification de connexion ajoutée

## 🎯 Bénéfices

1. ✅ **Authentification correcte** : Token et user ID réels
2. ✅ **Traçabilité** : `createdBy` et `updatedBy` corrects
3. ✅ **Sécurité** : Vérification de connexion avant chaque requête
4. ✅ **Cohérence** : Pattern identique aux autres services
5. ✅ **Maintenabilité** : Utilisation des méthodes de base

---

**Date de correction** : $(date)
**Fichier modifié** : `lib/services/retour.service.ts`
**Lignes modifiées** : 81-110 (méthode `buildRequest`)
**Pattern** : Identique à `reception.service.ts`

