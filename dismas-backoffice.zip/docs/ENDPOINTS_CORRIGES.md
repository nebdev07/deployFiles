# ✅ ENDPOINTS CORRECTS - BACKEND API

## 🔗 **BASE URL**
```
http://localhost:8081
```

---

## 📋 **ENDPOINTS MOUVEMENTS** (`/mouvement`)

### Création et gestion

| Méthode | Endpoint | Description |
|---------|----------|-------------|
| POST | `/mouvement/create` | Créer un mouvement (réception/distribution/retour) |
| POST | `/mouvement/createWithStock` | Créer avec gestion automatique des stocks |
| POST | `/mouvement/update` | Modifier un mouvement |
| POST | `/mouvement/delete` | Supprimer un mouvement (soft delete) |
| POST | `/mouvement/getByCriteria` | Rechercher par critères |
| GET | `/mouvement/getWithDetails/{id}` | Détails complets d'un mouvement |

### Validation et annulation

| Méthode | Endpoint | Description |
|---------|----------|-------------|
| POST | `/mouvement/validate` | Valider un mouvement (IEPP/EPP) |
| POST | `/mouvement/annuler` | Annuler un mouvement |

### Consultation stocks

| Méthode | Endpoint | Description |
|---------|----------|-------------|
| POST | `/mouvement/getStock` | Consulter le stock |
| POST | `/mouvement/getStockHistory` | Historique des stocks |
| POST | `/mouvement/getStockByStructure` | Stocks par structure |
| POST | `/mouvement/getStockByYear` | Stocks par année |
| POST | `/mouvement/validateStockBeforeEPP` | Valider stock avant distribution EPP |

### Utilitaires

| Méthode | Endpoint | Description |
|---------|----------|-------------|
| POST | `/mouvement/sendNotification` | Envoyer notification |
| POST | `/mouvement/correctStockData` | Corriger données stock |
| GET | `/mouvement/testIEPPParent/{structureId}` | Test IEPP parent |

---

## 📊 **ENDPOINTS STOCKS** (`/stock`)

| Méthode | Endpoint | Description |
|---------|----------|-------------|
| GET | `/stock/disponible` | Stock disponible (params: structureId, matiereId, niveauId, anneeScolaireId) |
| GET | `/stock/structure/{structureId}/annee/{anneeScolaireId}` | Tous les stocks d'une structure |
| GET | `/stock/rupture/structure/{structureId}/annee/{anneeScolaireId}` | Stocks en rupture |
| GET | `/stock/retours-annee-precedente/{anneeScolaireId}` | Retours N-1 comptés en N |
| GET | `/stock/resume/structure/{structureId}/annee/{anneeScolaireId}` | Résumé des stocks |
| POST | `/stock/recalculer/{anneeScolaireId}` | Recalculer stocks d'une année |
| POST | `/stock/verifier` | Vérifier disponibilité stock |

---

## 📚 **ENDPOINTS CATALOGUES**

| Méthode | Endpoint | Description |
|---------|----------|-------------|
| POST | `/catalogue/create` | Créer catalogue |
| POST | `/catalogue/update` | Modifier catalogue |
| POST | `/catalogue/delete` | Supprimer catalogue |
| POST | `/catalogue/getByCriteria` | Rechercher catalogues |
| POST | `/catalogue/findActiveCatalogues` | Catalogues actifs |
| POST | `/catalogueMatiere/getMatieresByCatalogueId` | Matières d'un catalogue |

---

## 📦 **ENDPOINTS CATALOGUE MOUVEMENT**

| Méthode | Endpoint | Description |
|---------|----------|-------------|
| POST | `/catalogueMouvement/create` | Lier catalogue à mouvement |
| POST | `/catalogueMouvement/update` | Modifier lien |
| POST | `/catalogueMouvement/delete` | Supprimer lien |
| POST | `/catalogueMouvement/getByCriteria` | Rechercher liens |

---

## 🔢 **ENDPOINTS MATIERE QUANTITE**

| Méthode | Endpoint | Description |
|---------|----------|-------------|
| POST | `/matiereQuantite/create` | Créer quantité matière |
| POST | `/matiereQuantite/update` | Modifier quantité |
| POST | `/matiereQuantite/delete` | Supprimer quantité |
| POST | `/matiereQuantite/getByCriteria` | Rechercher quantités |

---

## 📄 **ENDPOINTS FICHIERS**

| Méthode | Endpoint | Description |
|---------|----------|-------------|
| POST | `/mouvementFiles/create` | Uploader fichier |
| POST | `/mouvementFiles/update` | Modifier fichier |
| POST | `/mouvementFiles/delete` | Supprimer fichier |
| POST | `/mouvementFiles/getByCriteria` | Rechercher fichiers |
| GET | `/mouvementFiles/download/{id}` | Télécharger fichier |

---

## 📜 **ENDPOINTS HISTORIQUE**

| Méthode | Endpoint | Description |
|---------|----------|-------------|
| POST | `/mouvementHistory/create` | Créer entrée historique |
| POST | `/mouvementHistory/getByCriteria` | Consulter historique |

---

## ❌ **ENDPOINTS ANNULATION**

| Méthode | Endpoint | Description |
|---------|----------|-------------|
| POST | `/annulationMouvement/create` | Créer annulation |
| POST | `/annulationMouvement/update` | Modifier annulation |
| POST | `/annulationMouvement/delete` | Supprimer annulation |
| POST | `/annulationMouvement/getByCriteria` | Rechercher annulations |

---

## 🎓 **ENDPOINTS DISTRIBUTION ÉLÈVES**

| Méthode | Endpoint | Description |
|---------|----------|-------------|
| POST | `/distributionEleve/create` | Créer distribution |
| POST | `/distributionEleve/createWithStockValidation` | Créer avec validation stock |
| POST | `/distributionEleve/getStock` | Consulter stock pour distribution |
| GET | `/distributionEleve/debugStock/{eppId}/{matiereId}/{niveauId}` | Debug stock |

---

## 📅 **ENDPOINTS ANNÉE SCOLAIRE**

| Méthode | Endpoint | Description |
|---------|----------|-------------|
| POST | `/anneescolaire/create` | Créer année |
| POST | `/anneescolaire/update` | Modifier année |
| POST | `/anneescolaire/delete` | Supprimer année |
| POST | `/anneescolaire/getByCriteria` | Rechercher années |

---

## 🎯 **ENDPOINTS RÉFÉRENCE**

### Niveaux scolaires
```
POST /niveauscolaire/getByCriteria
```

### Matières
```
POST /matiere/getByCriteria
```

### Structures
```
POST /structure/getByCriteria
```

---

## 📝 **FORMAT REQUÊTE STANDARD**

### Création/Modification/Suppression
```json
{
  "user": 1,
  "token": "jwt_token_here",
  "isSimpleLoading": false,
  "datas": [
    {
      "typeMouvement": "RECEPTION_IEPP",
      "numeroBordereau": "BL-2024-001",
      "dateMouvement": "09/10/2024",
      "idStructure": 10,
      "anneeScolaireId": 1,
      "observation": "Première réception"
    }
  ]
}
```

### Recherche
```json
{
  "user": 1,
  "token": "jwt_token_here",
  "isSimpleLoading": false,
  "data": {
    "typeMouvement": "RECEPTION_IEPP",
    "statut": "EN_ATTENTE",
    "anneeScolaireId": 1
  }
}
```

---

## ✅ **CORRECTION APPLIQUÉE**

### Avant (INCORRECT)
```typescript
private baseEndpoint = 'Mouvement'; // ❌ Majuscule
```

### Après (CORRECT)
```typescript
private baseEndpoint = 'mouvement'; // ✅ Minuscule
```

---

## 🧪 **TEST DES ENDPOINTS**

### Créer une réception
```bash
curl -X POST http://localhost:8081/mouvement/create \
  -H "Content-Type: application/json" \
  -d '{
    "user": 1,
    "token": "your_token",
    "isSimpleLoading": false,
    "datas": [{
      "typeMouvement": "RECEPTION_IEPP",
      "numeroBordereau": "BL-TEST-001",
      "dateMouvement": "09/10/2024",
      "idStructure": 10,
      "anneeScolaireId": 1
    }]
  }'
```

### Consulter stock disponible
```bash
curl "http://localhost:8081/stock/disponible?structureId=10&matiereId=100&niveauId=1&anneeScolaireId=1"
```

---

**Date:** 2025-10-09  
**Statut:** ✅ Endpoints corrects - Minuscule confirmé  
**Note:** Tous les endpoints backend utilisent la **minuscule**

