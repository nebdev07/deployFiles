"use client"

import { useState, useEffect, useMemo } from "react"
import { XMarkIcon, EyeIcon, CheckCircleIcon } from "@heroicons/react/24/outline"
import toast from "react-hot-toast"
import { besoinsService, BesoinResponse } from "../../lib/services/besoins.service"

interface ApprouverBesoinModalProps {
  isOpen: boolean
  onClose: () => void
  besoinIds: number[]
  onApprove: (tauxGlobal?: number, quantitesApprouvees?: Map<number, number>, exceptionsEpp?: Map<number, Map<number, number>>) => Promise<void>
  besoins?: BesoinResponse[]
}

export default function ApprouverBesoinModal({
  isOpen,
  onClose,
  besoinIds,
  onApprove,
  besoins = []
}: ApprouverBesoinModalProps) {
  const [tauxGlobal, setTauxGlobal] = useState<number | undefined>(undefined)
  const [quantitesApprouvees, setQuantitesApprouvees] = useState<Map<number, number>>(new Map())
  const [exceptionsEpp, setExceptionsEpp] = useState<Map<number, Map<number, number>>>(new Map()) // Map<eppId, Map<matiereId, quantiteApprouvee>>
  const [loadingDetails, setLoadingDetails] = useState(false)
  const [loadingPreview, setLoadingPreview] = useState(false)
  const [loadingApprove, setLoadingApprove] = useState(false)
  const [besoinsDetails, setBesoinsDetails] = useState<BesoinResponse[]>([])
  const [previewData, setPreviewData] = useState<any>(null)
  const [showPreview, setShowPreview] = useState(false)
  const [showExceptionsEpp, setShowExceptionsEpp] = useState(false)
  const [eppBesoinsMap, setEppBesoinsMap] = useState<Map<number, BesoinResponse[]>>(new Map()) // Map<ieppBesoinId, EPP besoins[]>

  // Charger les détails des besoins au montage
  useEffect(() => {
    if (isOpen && besoinIds.length > 0) {
      loadBesoinsDetails()
    }
  }, [isOpen, besoinIds])

  const loadBesoinsDetails = async () => {
    setLoadingDetails(true)
    try {
      const detailsPromises = besoinIds.map(id => besoinsService.getDetails(id))
      const results = await Promise.all(detailsPromises)
      
      const loadedBesoins = results
        .filter(r => r.success && r.data)
        .map(r => r.data!)
      
      // ✅ NOUVEAU : Filtrer pour ne garder que les besoins IEPP consolidés
      const besoinsIepp = loadedBesoins.filter(b => 
        b.structureType === 'IEPP' && b.statut === 'CONSOLIDE'
      )
      
      if (besoinsIepp.length === 0) {
        toast.error('Aucun besoin IEPP consolidé trouvé. Seuls les besoins IEPP consolidés peuvent être approuvés par la DAF.')
        onClose()
        return
      }
      
      if (loadedBesoins.length > besoinsIepp.length) {
        toast(`${loadedBesoins.length - besoinsIepp.length} besoin(s) EPP ignoré(s). Seuls les besoins IEPP consolidés sont affichés.`, {
          icon: '⚠️',
          duration: 4000,
        })
      }
      
      setBesoinsDetails(besoinsIepp)
      
      // ✅ NOUVEAU : Charger les besoins EPP consolidés pour chaque besoin IEPP (pour les exceptions)
      const eppBesoinsMapTemp = new Map<number, BesoinResponse[]>()
      for (const besoinIepp of besoinsIepp) {
        if (besoinIepp.structureAdministrativeId) {
          try {
            // Utiliser getConsolidationDetails pour récupérer les besoins EPP consolidés dans ce besoin IEPP
            const eppBesoinsResult = await besoinsService.getConsolidationDetails(
              besoinIepp.structureAdministrativeId
            )
            if (eppBesoinsResult.success && eppBesoinsResult.data) {
              // Filtrer pour ne garder que les besoins EPP du même niveau et année scolaire
              const eppBesoinsFiltered = eppBesoinsResult.data.filter(b => 
                b.niveauScolaireId === besoinIepp.niveauScolaireId &&
                b.anneeScolaireId === besoinIepp.anneeScolaireId
              )
              if (eppBesoinsFiltered.length > 0) {
                eppBesoinsMapTemp.set(besoinIepp.id, eppBesoinsFiltered)
              }
            }
          } catch (error) {
            console.warn(`Erreur lors du chargement des besoins EPP consolidés pour IEPP ${besoinIepp.id}:`, error)
          }
        }
      }
      setEppBesoinsMap(eppBesoinsMapTemp)
      
    } catch (error: any) {
      console.error('Erreur lors du chargement des détails:', error)
      toast.error('Erreur lors du chargement des détails des besoins')
    } finally {
      setLoadingDetails(false)
    }
  }

  const handlePreview = async () => {
    if (!tauxGlobal && quantitesApprouvees.size === 0 && exceptionsEpp.size === 0) {
      toast.error('Veuillez saisir un taux global, modifier manuellement au moins une quantité, ou définir des exceptions EPP')
      return
    }

    setLoadingPreview(true)
    try {
      const result = await besoinsService.previewApprove(
        besoinIds,
        tauxGlobal,
        quantitesApprouvees.size > 0 ? quantitesApprouvees : undefined,
        exceptionsEpp.size > 0 ? exceptionsEpp : undefined
      )

      if (result.success && result.data) {
        setPreviewData(result.data)
        setShowPreview(true)
        toast.success('Prévisualisation générée avec succès')
      } else {
        toast.error(result.message || 'Erreur lors de la prévisualisation')
      }
    } catch (error: any) {
      console.error('Erreur lors de la prévisualisation:', error)
      toast.error('Erreur lors de la prévisualisation')
    } finally {
      setLoadingPreview(false)
    }
  }

  const handleApprove = async () => {
    if (!tauxGlobal && quantitesApprouvees.size === 0 && exceptionsEpp.size === 0) {
      toast.error('Veuillez saisir un taux global, modifier manuellement au moins une quantité, ou définir des exceptions EPP')
      return
    }

    setLoadingApprove(true)
    try {
      await onApprove(
        tauxGlobal,
        quantitesApprouvees.size > 0 ? quantitesApprouvees : undefined,
        exceptionsEpp.size > 0 ? exceptionsEpp : undefined
      )
      onClose()
    } catch (error: any) {
      console.error('Erreur lors de l\'approbation:', error)
      toast.error('Erreur lors de l\'approbation')
    } finally {
      setLoadingApprove(false)
    }
  }

  const updateQuantiteApprouvee = (besoinDetailId: number, quantite: number) => {
    const newMap = new Map(quantitesApprouvees)
    if (quantite > 0) {
      newMap.set(besoinDetailId, quantite)
    } else {
      newMap.delete(besoinDetailId)
    }
    setQuantitesApprouvees(newMap)
  }
  
  // ✅ NOUVEAU : Mettre à jour une exception EPP
  const updateExceptionEpp = (eppId: number, matiereId: number, quantite: number) => {
    const newMap = new Map(exceptionsEpp)
    if (!newMap.has(eppId)) {
      newMap.set(eppId, new Map())
    }
    const eppExceptions = newMap.get(eppId)!
    if (quantite > 0) {
      eppExceptions.set(matiereId, quantite)
    } else {
      eppExceptions.delete(matiereId)
      if (eppExceptions.size === 0) {
        newMap.delete(eppId)
      }
    }
    setExceptionsEpp(newMap)
  }
  
  // ✅ NOUVEAU : Obtenir une exception EPP
  const getExceptionEpp = (eppId: number, matiereId: number): number | undefined => {
    return exceptionsEpp.get(eppId)?.get(matiereId)
  }

  const getQuantiteApprouvee = (besoinDetailId: number, quantiteConsolidee: number): number => {
    // Si modification manuelle, utiliser cette valeur
    if (quantitesApprouvees.has(besoinDetailId)) {
      return quantitesApprouvees.get(besoinDetailId)!
    }
    // Sinon, si taux global, l'appliquer
    if (tauxGlobal !== undefined && tauxGlobal !== null) {
      return Math.round(quantiteConsolidee * tauxGlobal)
    }
    // Sinon, retourner la quantité consolidée
    return quantiteConsolidee
  }

  const { totalQuantiteDemandee, totalQuantiteApprouvee } = useMemo(() => {
    let demandee = 0
    let approuvee = 0
    for (const besoin of besoinsDetails) {
      for (const detail of besoin.besoinDetails || []) {
        const qc = detail.quantiteConsolidee ?? 0
        demandee += qc
        let qa = qc
        if (quantitesApprouvees.has(detail.id)) {
          qa = quantitesApprouvees.get(detail.id)!
        } else if (tauxGlobal !== undefined && tauxGlobal !== null) {
          qa = Math.round(qc * tauxGlobal)
        }
        approuvee += qa
      }
    }
    return { totalQuantiteDemandee: demandee, totalQuantiteApprouvee: approuvee }
  }, [besoinsDetails, tauxGlobal, quantitesApprouvees])

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto">
      <div className="flex items-center justify-center min-h-screen px-4 pt-4 pb-20 text-center sm:block sm:p-0">
        <div className="fixed inset-0 transition-opacity bg-gray-500 bg-opacity-75" onClick={onClose}></div>

        <div className="inline-block align-bottom bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-6xl sm:w-full">
          <div className="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-medium text-gray-900">
                Approuver les Besoins (DAF)
              </h3>
              <button
                onClick={onClose}
                className="text-gray-400 hover:text-gray-600"
              >
                <XMarkIcon className="h-6 w-6" />
              </button>
            </div>

            {loadingDetails ? (
              <div className="text-center py-8">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900 mx-auto"></div>
                <p className="mt-2 text-gray-600">Chargement des détails...</p>
              </div>
            ) : (
              <div className="space-y-6">
                {/* ✅ Taux Global - Section mise en évidence */}
                <div className="bg-blue-50 border-2 border-blue-200 p-5 rounded-lg">
                  <div className="flex items-center gap-2 mb-3">
                    <span className="text-2xl">📊</span>
                    <label className="block text-base font-semibold text-gray-900">
                      Taux Global d'Approbation
                    </label>
                  </div>
                  <div className="flex items-center gap-4 mb-3">
                    <div className="flex items-center gap-2">
                      <input
                        type="number"
                        min="0"
                        max="100"
                        step="1"
                        value={tauxGlobal !== undefined ? tauxGlobal * 100 : ''}
                        onChange={(e) => {
                          const value = e.target.value ? parseFloat(e.target.value) / 100 : undefined
                          setTauxGlobal(value)
                        }}
                        className="w-32 px-4 py-3 text-lg font-semibold border-2 border-blue-400 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white"
                        placeholder="Ex: 80"
                      />
                      <span className="text-lg font-medium text-gray-700">%</span>
                    </div>
                    <div className="flex-1">
                      {tauxGlobal !== undefined ? (
                        <div className="bg-white p-3 rounded border border-blue-300">
                          <p className="text-sm font-medium text-blue-900">
                            ✅ {Math.round(tauxGlobal * 100)}% sera appliqué automatiquement aux quantités <span className="font-semibold">sans modification manuelle</span>
                          </p>
                        </div>
                      ) : (
                        <p className="text-sm text-gray-600 italic">
                          💡 Saisissez un pourcentage (0-100). Ce taux s'appliquera à toutes les quantités consolidées sauf celles que vous modifierez manuellement ci-dessous.
                        </p>
                      )}
                    </div>
                  </div>
                  <div className="bg-yellow-50 border border-yellow-200 rounded p-2">
                    <p className="text-xs text-yellow-800">
                      <span className="font-semibold">Note :</span> Le taux global s'applique uniquement aux quantités sans modification manuelle. Vous pouvez modifier individuellement chaque quantité dans le tableau ci-dessous.
                    </p>
                  </div>
                  {besoinsDetails.length > 0 && (
                    <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div className="bg-white border border-blue-200 rounded-lg p-4">
                        <p className="text-xs font-medium text-gray-500 uppercase tracking-wide">
                          Quantité totale demandée
                        </p>
                        <p className="mt-1 text-2xl font-bold text-gray-900 tabular-nums">
                          {totalQuantiteDemandee.toLocaleString()} <span className="text-base font-semibold text-gray-600">manuels</span>
                        </p>
                        <p className="mt-1 text-xs text-gray-500">
                          Somme des quantités consolidées (lignes IEPP affichées)
                        </p>
                      </div>
                      <div className="bg-white border-2 border-blue-400 rounded-lg p-4">
                        <p className="text-xs font-medium text-blue-800 uppercase tracking-wide">
                          Quantité totale qui sera approuvée
                        </p>
                        <p className="mt-1 text-2xl font-bold text-blue-900 tabular-nums">
                          {totalQuantiteApprouvee.toLocaleString()} <span className="text-base font-semibold text-blue-800">manuels</span>
                        </p>
                        <p className="mt-1 text-xs text-blue-700">
                          {totalQuantiteDemandee > 0
                            ? `Soit environ ${Math.round((totalQuantiteApprouvee / totalQuantiteDemandee) * 100)} % de la demande consolidée (arrondis par ligne).`
                            : 'Aucune ligne consolidée à agréger.'}
                        </p>
                      </div>
                    </div>
                  )}
                </div>

                {/* ✅ NOUVEAU : Section Exceptions EPP */}
                {besoinsDetails.length > 0 && (
                  <div className="bg-purple-50 border-2 border-purple-200 p-5 rounded-lg">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-2">
                        <span className="text-2xl">⭐</span>
                        <label className="block text-base font-semibold text-gray-900">
                          Exceptions EPP (Optionnel)
                        </label>
                      </div>
                      <button
                        type="button"
                        onClick={() => setShowExceptionsEpp(!showExceptionsEpp)}
                        className="text-sm text-purple-700 hover:text-purple-900 font-medium"
                      >
                        {showExceptionsEpp ? 'Masquer' : 'Afficher'} les exceptions
                      </button>
                    </div>
                    {showExceptionsEpp && (
                      <div className="space-y-4 mt-4">
                        <div className="bg-white p-3 rounded border border-purple-200">
                          <p className="text-sm text-purple-800">
                            <span className="font-semibold">💡 Exceptions EPP :</span> Permet d'accorder des quantités spécifiques à certains EPP (ex: 100% pour EPP prioritaires). 
                            Les exceptions ont priorité sur le taux global et les modifications manuelles par matière.
                          </p>
                        </div>
                        {besoinsDetails.map((besoinIepp) => {
                          const eppBesoins = eppBesoinsMap.get(besoinIepp.id) || []
                          if (eppBesoins.length === 0) {
                            return null
                          }
                          
                          return (
                            <div key={besoinIepp.id} className="bg-white border border-purple-200 rounded-lg p-4">
                              <div className="mb-3">
                                <p className="font-medium text-gray-900">{besoinIepp.reference}</p>
                                <p className="text-sm text-gray-600">
                                  {besoinIepp.structureAdministrativeLibelle} - {besoinIepp.niveauScolaireLibelle}
                                </p>
                                <p className="text-xs text-purple-600 mt-1">
                                  {eppBesoins.length} EPP lié(s) à ce besoin consolidé
                                </p>
                              </div>
                              
                              <div className="space-y-3">
                                {eppBesoins.map((besoinEpp) => {
                                  const eppId = besoinEpp.structureAdministrativeId
                                  if (!besoinEpp.besoinDetails || besoinEpp.besoinDetails.length === 0 || !eppId) {
                                    return null
                                  }
                                  
                                  return (
                                    <div key={besoinEpp.id} className="border border-gray-200 rounded p-3 bg-gray-50">
                                      <p className="font-medium text-sm text-gray-900 mb-2">
                                        📍 {besoinEpp.structureAdministrativeLibelle}
                                      </p>
                                      <div className="grid grid-cols-1 gap-2">
                                        {besoinEpp.besoinDetails.map((detail) => {
                                          if (!detail.matiereId) return null
                                          const quantiteNetEpp = detail.quantiteNet || 0
                                          const exception = getExceptionEpp(eppId, detail.matiereId)
                                          
                                          return (
                                            <div key={detail.id} className="flex items-center justify-between p-2 bg-white rounded border border-gray-200">
                                              <div className="flex-1">
                                                <p className="text-xs font-medium text-gray-700">
                                                  {detail.matiereLibelle || detail.matiereCode}
                                                </p>
                                                <p className="text-xs text-gray-500">
                                                  Demandé: {quantiteNetEpp.toLocaleString()}
                                                </p>
                                              </div>
                                              <div className="flex items-center gap-2">
                                                <input
                                                  type="number"
                                                  min="0"
                                                  max={quantiteNetEpp}
                                                  value={exception !== undefined ? exception : ''}
                                                  onChange={(e) => {
                                                    const newValue = parseInt(e.target.value) || 0
                                                    updateExceptionEpp(eppId, detail.matiereId, newValue)
                                                  }}
                                                  placeholder={`Taux global: ${tauxGlobal ? Math.round(quantiteNetEpp * tauxGlobal) : quantiteNetEpp}`}
                                                  className="w-28 px-2 py-1 text-sm text-right border-2 border-purple-300 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-500 bg-purple-50"
                                                />
                                                {exception !== undefined && (
                                                  <span className="text-xs text-purple-600">✏️</span>
                                                )}
                                              </div>
                                            </div>
                                          )
                                        })}
                                      </div>
                                    </div>
                                  )
                                })}
                              </div>
                            </div>
                          )
                        })}
                      </div>
                    )}
                  </div>
                )}

                {/* Liste des besoins avec détails */}
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h4 className="text-lg font-semibold text-gray-900">📋 Détails des Besoins - Modifications Manuelles</h4>
                    <span className="text-sm text-gray-500">
                      {besoinsDetails.reduce((sum, b) => sum + (b.besoinDetails?.length || 0), 0)} matière(s) au total
                    </span>
                  </div>
                  <div className="bg-green-50 border border-green-200 rounded p-3 mb-4">
                    <p className="text-sm text-green-800">
                      <span className="font-semibold">✏️ Modification manuelle :</span> Cliquez sur les champs "Quantité Approuvée" dans le tableau ci-dessous pour modifier individuellement chaque quantité. Les valeurs modifiées manuellement ont priorité sur le taux global.
                    </p>
                  </div>
                  {besoinsDetails.map((besoin) => (
                    <div key={besoin.id} className="border border-gray-200 rounded-lg p-4">
                      <div className="flex items-center justify-between mb-3">
                        <div>
                          <div className="flex items-center gap-2">
                            <p className="font-medium text-gray-900">{besoin.reference}</p>
                            <span className="inline-flex px-2 py-1 text-xs font-semibold rounded-full bg-blue-100 text-blue-800">
                              IEPP CONSOLIDÉ
                            </span>
                          </div>
                          <p className="text-sm text-gray-600">
                            {besoin.structureAdministrativeLibelle} - {besoin.niveauScolaireLibelle}
                          </p>
                        </div>
                      </div>

                      {besoin.besoinDetails && besoin.besoinDetails.length > 0 ? (
                        <div className="overflow-x-auto">
                          <table className="min-w-full divide-y divide-gray-200">
                            <thead className="bg-gray-50">
                              <tr>
                                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                                  Matière
                                </th>
                                <th className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase">
                                  Quantité Consolidée
                                </th>
                                <th className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase">
                                  Quantité Approuvée
                                </th>
                                <th className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase">
                                  Écart
                                </th>
                                <th className="px-4 py-3 text-center text-xs font-medium text-gray-500 uppercase">
                                  Mode
                                </th>
                              </tr>
                            </thead>
                            <tbody className="bg-white divide-y divide-gray-200">
                              {besoin.besoinDetails.map((detail) => {
                                const quantiteConsolidee = detail.quantiteConsolidee || 0
                                const quantiteApprouvee = getQuantiteApprouvee(detail.id, quantiteConsolidee)
                                const ecart = quantiteApprouvee - quantiteConsolidee
                                const isManual = quantitesApprouvees.has(detail.id)
                                const mode = isManual ? 'MANUEL' : tauxGlobal !== undefined ? 'TAUX_GLOBAL' : 'COMPLET'

                                return (
                                  <tr key={detail.id}>
                                    <td className="px-4 py-3 text-sm text-gray-900">
                                      {detail.matiereLibelle || detail.matiereCode || `Matière ${detail.matiereId}`}
                                    </td>
                                    <td className="px-4 py-3 text-sm text-right text-gray-700 font-medium">
                                      {quantiteConsolidee.toLocaleString()}
                                    </td>
                                    <td className="px-4 py-3 text-sm">
                                      <div className="flex items-center justify-end gap-2">
                                        <input
                                          type="number"
                                          min="0"
                                          max={quantiteConsolidee}
                                          value={quantiteApprouvee}
                                          onChange={(e) => {
                                            const newValue = parseInt(e.target.value) || 0
                                            updateQuantiteApprouvee(detail.id, newValue)
                                          }}
                                          className={`w-36 px-3 py-2 text-right text-base font-semibold border-2 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                                            isManual 
                                              ? 'border-purple-400 bg-purple-50' 
                                              : 'border-gray-300 bg-white'
                                          }`}
                                          placeholder={quantiteConsolidee.toString()}
                                        />
                                        {isManual && (
                                          <span className="text-purple-600 text-xs" title="Modification manuelle">
                                            ✏️
                                          </span>
                                        )}
                                      </div>
                                      {isManual && (
                                        <p className="text-xs text-purple-600 mt-1 text-right">
                                          Modifié manuellement
                                        </p>
                                      )}
                                    </td>
                                    <td className={`px-4 py-3 text-sm text-right font-medium ${
                                      ecart < 0 ? 'text-red-600' : ecart > 0 ? 'text-green-600' : 'text-gray-600'
                                    }`}>
                                      {ecart > 0 ? '+' : ''}{ecart.toLocaleString()}
                                    </td>
                                    <td className="px-4 py-3 text-sm text-center">
                                      <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${
                                        mode === 'MANUEL' ? 'bg-purple-100 text-purple-800' :
                                        mode === 'TAUX_GLOBAL' ? 'bg-blue-100 text-blue-800' :
                                        'bg-green-100 text-green-800'
                                      }`}>
                                        {mode}
                                      </span>
                                    </td>
                                  </tr>
                                )
                              })}
                            </tbody>
                          </table>
                        </div>
                      ) : (
                        <p className="text-sm text-gray-500">Aucun détail disponible</p>
                      )}
                    </div>
                  ))}
                </div>

                {/* Récapitulatif de prévisualisation */}
                {showPreview && previewData && (
                  <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                    <h4 className="font-medium text-blue-900 mb-3">Récapitulatif de Prévisualisation</h4>
                    <div className="grid grid-cols-3 gap-4 text-sm">
                      <div>
                        <p className="text-gray-600">Total Consolidé</p>
                        <p className="text-lg font-semibold text-gray-900">
                          {previewData.totalQuantiteConsolidee?.toLocaleString() || 0}
                        </p>
                      </div>
                      <div>
                        <p className="text-gray-600">Total Approuvé</p>
                        <p className="text-lg font-semibold text-blue-900">
                          {previewData.totalQuantiteApprouvee?.toLocaleString() || 0}
                        </p>
                      </div>
                      <div>
                        <p className="text-gray-600">Taux d'Approbation</p>
                        <p className="text-lg font-semibold text-green-900">
                          {previewData.tauxApprobationGlobal 
                            ? `${Math.round(previewData.tauxApprobationGlobal * 100)}%`
                            : '0%'}
                        </p>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>

          <div className="bg-gray-50 px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse">
            <div className="flex gap-3">
              <button
                type="button"
                onClick={handlePreview}
                disabled={loadingPreview || loadingDetails}
                className="inline-flex items-center px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50"
              >
                <EyeIcon className="h-4 w-4 mr-2" />
                Prévisualiser
              </button>
              <button
                type="button"
                onClick={handleApprove}
                disabled={loadingApprove || loadingDetails}
                className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50"
              >
                <CheckCircleIcon className="h-4 w-4 mr-2" />
                {loadingApprove ? 'Approbation...' : 'Approuver'}
              </button>
              <button
                type="button"
                onClick={onClose}
                className="inline-flex items-center px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-500"
              >
                Annuler
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

