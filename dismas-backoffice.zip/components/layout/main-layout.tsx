"use client"

import { logger } from '@/lib/utils/logger'

import type React from "react"
import { useEffect } from "react"
import { usePathname, useRouter } from "next/navigation"

import { useAuth } from "../../app/providers"
import { isConsultationOnlyRole } from "@/lib/utils/role-access"
import { isCabinetAllowedPath } from "@/lib/constants/cabinet-allowed-routes"
import Sidebar from "./sidebar"
import Header from "./header"

interface MainLayoutProps {
  children: React.ReactNode
}

export default function MainLayout({ children }: MainLayoutProps) {
  const { user } = useAuth()
  const pathname = usePathname()
  const router = useRouter()
  const consultationCabinet = user ? isConsultationOnlyRole(user.role?.code) : false

  useEffect(() => {
    if (!user || !consultationCabinet || !pathname) return
    if (!isCabinetAllowedPath(pathname)) {
      router.replace("/dashboard")
    }
  }, [user, consultationCabinet, pathname, router])

  logger.log('🔍 MainLayout - User:', user) // Debug

  if (!user) {
    logger.log('🔍 MainLayout - No user, returning null') // Debug
    return null
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Sidebar />

      <div className="lg:ml-64 min-h-screen">
        <Header />

        <main className="p-6">
          {consultationCabinet && (
            <div
              className="mb-4 rounded-lg border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-950"
              role="status"
            >
              <span className="font-medium">Mode consultation</span>
              {' — '}
              Les actions de saisie, validation et modification métier sont désactivées. Export et lecture des données
              restent disponibles selon les écrans.
            </div>
          )}
          {children}
        </main>
      </div>
    </div>
  )
}
