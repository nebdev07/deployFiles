"use client"

import { useState } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { useAuth } from "../../app/providers"
import {
  HomeIcon,
  CubeIcon,
  TruckIcon,
  ArrowsRightLeftIcon,
  ArrowUturnLeftIcon,
  ExclamationTriangleIcon,
  ClipboardDocumentListIcon,
  ChartBarIcon,
  UserGroupIcon,
  CogIcon,
  Bars3Icon,
  XMarkIcon,
  ShoppingCartIcon,
  DocumentTextIcon,
  UserCircleIcon,
} from "@heroicons/react/24/outline"
import Logo from "../ui/logo"

const menuItems = [
  {
    name: "Tableau de bord",
    href: "/dashboard",
    icon: HomeIcon,
    roles: ["ADMIN", "DAF", "DRENA", "IEPP", "DIRECTEUR", "MAITRE", "CABINET"],
  },
  {
    name: "Tableau de répartition",
    href: "/planification/repartition",
    icon: DocumentTextIcon,
    roles: ["ADMIN", "DAF", "DRENA", "IEPP", "DIRECTEUR", "CABINET"],
  },
  {
    name: "Commande",
    href: "/commandes",
    icon: ShoppingCartIcon,
    roles: ["ADMIN", "DAF"],
  },
  {
    name: "Récupération",
    href: "/retours",
    icon: ArrowUturnLeftIcon,
    roles: ["ADMIN", "DAF", "DRENA", "IEPP", "DIRECTEUR", "MAITRE"],
  },
  {
    name: "Expression des besoins",
    href: "/besoins",
    icon: ClipboardDocumentListIcon,
    roles: ["ADMIN", "DAF", "DRENA", "IEPP", "DIRECTEUR", "CABINET"],
  },
  {
    name: "Réception",
    href: "/receptions",
    icon: TruckIcon,
    roles: ["ADMIN", "DAF", "DRENA", "IEPP", "DIRECTEUR", "CABINET"],
  },
  {
    name: "Stock",
    href: "/stocks",
    icon: CubeIcon,
    roles: ["ADMIN", "DAF", "DRENA", "IEPP", "DIRECTEUR", "CABINET"],
  },
  {
    name: "Distribution",
    href: "/distribution",
    icon: TruckIcon,
    roles: ["ADMIN", "DAF", "DRENA", "IEPP", "DIRECTEUR", "MAITRE"],
  },
  {
    name: "Régulation",
    href: "/regulation",
    icon: ArrowsRightLeftIcon,
    roles: ["ADMIN", "DAF", "DRENA", "IEPP"],
  },
  {
    name: "Rapport",
    href: "/rapports",
    icon: ChartBarIcon,
    roles: ["ADMIN", "DAF", "DRENA", "IEPP", "DIRECTEUR", "CABINET"],
  },
  {
    name: "Plainte",
    href: "/plaintes",
    icon: ExclamationTriangleIcon,
    roles: ["ADMIN", "DAF", "DRENA", "IEPP", "DIRECTEUR", "COGES"],
  },
  {
    name: "Enquête",
    href: "/enquetes",
    icon: ClipboardDocumentListIcon,
    roles: ["ADMIN", "DAF", "DRENA", "IEPP", "DIRECTEUR", "COGES"],
  },
  {
    name: "Utilisateur",
    href: "/users",
    icon: UserGroupIcon,
    roles: ["ADMIN", "DAF", "DRENA", "IEPP"],
  },
  {
    name: "Paramètre",
    href: "/admin/parametrages",
    icon: CogIcon,
    roles: ["ADMIN", "DAF", "DPFC"],
  },
  {
    name: "Profil",
    href: "/profil",
    icon: UserCircleIcon,
    roles: ["ADMIN", "DAF", "DRENA", "IEPP", "DIRECTEUR", "MAITRE", "COGES", "DPFC", "CABINET"],
  },
  {
    name: "Monitoring",
    href: "/admin",
    icon: CogIcon,
    roles: ["ADMIN"],
  },
]

export default function Sidebar() {
  const { user } = useAuth()
  const pathname = usePathname()
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)

  // ✅ CORRECTION: Vérification après tous les hooks
  if (!user) {
    return (
      <div className="w-64 bg-white border-r border-gray-200">
        <div className="p-4">
          <p className="text-gray-600">Chargement...</p>
        </div>
      </div>
    )
  }

  const filteredMenuItems = menuItems.filter((item) => {
    const userRoleCode = (user.role?.code || '').toUpperCase()
    return item.roles.includes(userRoleCode)
  })

  const SidebarContent = ({ hideLogo = false }: { hideLogo?: boolean }) => (
    <div className="flex h-full min-h-0 flex-col">
      {/* Logo (masqué sur mobile : déjà affiché dans la barre du drawer) */}
      {!hideLogo && (
        <div className="flex shrink-0 items-center border-b border-gray-200 px-6 py-4">
          <Logo size="sm" showText={true} />
        </div>
      )}

      {/* User Info */}
      <div className="shrink-0 px-6 py-4 border-b border-gray-200 bg-gray-50">
        <div className="flex items-center">
          <div className="w-10 h-10 bg-gradient-to-r from-orange-400 to-green-400 rounded-full flex items-center justify-center">
            <span className="text-white font-semibold text-sm">
              {user.prenoms.charAt(0)}
              {user.nom.charAt(0)}
            </span>
          </div>
          <div className="ml-3">
            <p className="text-sm font-medium text-gray-900">
              {user.prenoms} {user.nom}
            </p>
            <p className="text-xs text-gray-500">{user.role.libelle}</p>
            {user.structure && <p className="text-xs text-gray-400">{user.structure.libelle}</p>}
          </div>
        </div>
      </div>

      {/* Navigation — zone scrollable (important sur petit écran / fenêtre basse) */}
      <nav className="min-h-0 flex-1 space-y-1 overflow-y-auto overflow-x-hidden px-4 py-4 overscroll-contain touch-pan-y">
        {filteredMenuItems.map((item) => {
          const normalizedPath = pathname?.replace(/\/+$/, "") || "/"
          const normalizedHref = item.href.replace(/\/+$/, "")
          const isActive =
            normalizedPath === normalizedHref ||
            (normalizedHref !== "/dashboard" &&
              normalizedHref !== "/besoins" &&
              normalizedPath.startsWith(`${normalizedHref}/`))
          return (
            <Link
              key={item.name}
              href={item.href}
              className={`flex items-center px-3 py-2 text-sm font-medium rounded-lg transition-colors ${
                isActive
                  ? "bg-orange-600 text-white shadow-sm"
                  : "text-gray-600 hover:bg-gray-100 hover:text-gray-900"
              }`}
              onClick={() => setIsMobileMenuOpen(false)}
            >
              <item.icon className={`h-5 w-5 mr-3 ${isActive ? "text-white" : ""}`} />
              {item.name}
            </Link>
          )
        })}
      </nav>

      {/* Footer */}
      <div className="shrink-0 px-6 py-4 border-t border-gray-200">
        <p className="text-xs text-gray-500 text-center">
          MENA - République de Côte d'Ivoire
          <br />
          Version 1.0.0
        </p>
      </div>
    </div>
  )

  return (
    <>
      {/* Mobile menu button */}
      <button
        onClick={() => setIsMobileMenuOpen(true)}
        className="lg:hidden fixed top-4 left-4 z-50 p-2 bg-white rounded-lg shadow-lg border"
      >
        <Bars3Icon className="h-6 w-6 text-gray-600" />
      </button>

      {/* Desktop Sidebar */}
      <div className="z-40 hidden bg-white border-r border-gray-200 lg:fixed lg:inset-y-0 lg:flex lg:w-64 lg:flex-col lg:min-h-0">
        <SidebarContent />
      </div>

      {/* Mobile Sidebar — colonne flex + min-h-0 pour que le nav interne puisse défiler */}
      {isMobileMenuOpen && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div className="fixed inset-0 bg-black bg-opacity-50" onClick={() => setIsMobileMenuOpen(false)} />
          <div className="fixed inset-y-0 left-0 flex h-full max-h-[100dvh] w-[min(100%,16rem)] flex-col bg-white shadow-xl">
            <div className="flex shrink-0 items-center justify-between border-b border-gray-200 px-4 py-3">
              <Logo size="sm" showText={true} />
              <button
                type="button"
                onClick={() => setIsMobileMenuOpen(false)}
                className="rounded-lg p-2 hover:bg-gray-100"
                aria-label="Fermer le menu"
              >
                <XMarkIcon className="h-6 w-6 text-gray-600" />
              </button>
            </div>
            <div className="min-h-0 flex-1 overflow-hidden">
              <SidebarContent hideLogo />
            </div>
          </div>
        </div>
      )}
    </>
  )
}
