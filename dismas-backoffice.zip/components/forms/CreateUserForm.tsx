/**
 * Composant de formulaire de création/modification d'utilisateur
 * Intègre les structures administratives (DRENA, IEPP, EPP)
 */

import { logger } from '@/lib/utils/logger'

import React, { useState, useEffect, useLayoutEffect, useMemo } from 'react';
import { useStructures } from '@/hooks/use-structures';
import { useRoles } from '@/hooks/use-roles';
import { buildCreateUserRequest, CreateUserRequest } from '@/lib/types/entities';
import { UserListItem } from '@/lib/utils/user-mapping';
import toast from 'react-hot-toast';
import { SearchableStructureSelect } from '@/components/ui/SearchableStructureSelect';
import { UserCircleIcon, BuildingOffice2Icon, AcademicCapIcon } from '@heroicons/react/24/outline';

/** Préremplissage hiérarchique (création par DRENA / IEPP depuis la page Utilisateurs) */
export interface UserCreationPreset {
  roleCode: string;
  drenaId: string;
  ieppId?: string;
  eppId?: string;
  lockRole?: boolean;
  lockDrena?: boolean;
  lockIepp?: boolean;
  lockEpp?: boolean;
  /**
   * `fromRow` : ligne du tableau — DRENA+IEPP(+EPP) préremplis selon la ligne.
   * `fromHeader` : bouton général — parents verrouillés, feuille (IEPP ou EPP) laissée au choix.
   */
  source?: 'fromRow' | 'fromHeader';
}

interface CreateUserFormProps {
  onSubmit: (userData: any) => void; // Type simplifié pour éviter les conflits
  onCancel: () => void;
  loading?: boolean;
  editUser?: UserListItem; // Si fourni, le formulaire est en mode modification
  /** Rôle du compte connecté : filtre les rôles créables (DRENA → IEPP, IEPP → DIRECTEUR) */
  creatorRoleCode?: string;
  /** Valeurs imposées pour la création d’un compte enfant */
  creationPreset?: UserCreationPreset | null;
  /** Verrouillage champs hiérarchie en édition (DRENA / IEPP sur leurs enfants) */
  editHierarchyLocks?: { lockDrena: boolean; lockIepp: boolean };
}

interface FormData {
  firstName: string;
  lastName: string;
  email: string;
  login: string;
  telephone: string;
  bornOn: string;
  roleCode: string;
  drenaId: string;
  ieppId: string;
  eppId: string;
  isActive: boolean;
}

export default function CreateUserForm({
  onSubmit,
  onCancel,
  loading = false,
  editUser,
  creatorRoleCode,
  creationPreset = null,
  editHierarchyLocks,
}: CreateUserFormProps) {
  const {
    drenas,
    iepps,
    epps,
    loadDrenas,
    loadIepps,
    loadEpps,
    clearEpps,
    clearIeppsAndEpps,
    loading: structuresLoading,
  } = useStructures();
  const { roles, loading: rolesLoading, error: rolesError, loadRoles } = useRoles();

  const rolesForSelect = useMemo(() => {
    const code = (creatorRoleCode || '').toUpperCase();
    if (code === 'DRENA') {
      return roles.filter((r) => r.code === 'IEPP');
    }
    if (code === 'IEPP') {
      return roles.filter((r) => r.code === 'DIRECTEUR');
    }
    return roles;
  }, [roles, creatorRoleCode]);
  
  // Vérifier si l'utilisateur est connecté
  const [isUserConnected, setIsUserConnected] = useState(false);
  
  useEffect(() => {
    if (typeof window !== 'undefined') {
      const userSession = localStorage.getItem('dismas_user') || localStorage.getItem('user_session');
      const authToken = localStorage.getItem('auth_token');
      const isConnected = !!(userSession && authToken);
      
      logger.log('CreateUserForm - Vérification de connexion:', {
        userSession: !!userSession,
        authToken: !!authToken,
        isConnected,
        userSessionContent: userSession ? JSON.parse(userSession) : null
      });
      
      setIsUserConnected(isConnected);
    }
  }, []);
  
  // Déterminer les valeurs initiales selon le mode (création/modification)
  const getInitialFormData = (): FormData => {
    if (editUser) {
      // Mode modification : IDs structures issus du backend (liste utilisateurs)
      return {
        firstName: editUser.firstName || '',
        lastName: editUser.lastName || '',
        email: editUser.email || '',
        login: editUser.login || '',
        telephone: editUser.telephone || '',
        bornOn: '',
        roleCode: editUser.role.code || '',
        drenaId:
          editUser.drenaId != null && editUser.drenaId > 0 ? String(editUser.drenaId) : '',
        ieppId:
          editUser.ieppId != null && editUser.ieppId > 0 ? String(editUser.ieppId) : '',
        eppId: editUser.eppId != null && editUser.eppId > 0 ? String(editUser.eppId) : '',
        isActive: editUser.isActive ?? true,
      };
    } else {
      // Mode création : valeurs par défaut
      return {
        firstName: '',
        lastName: '',
        email: '',
        login: '',
        telephone: '',
        bornOn: '',
        roleCode: '',
        drenaId: '',
        ieppId: '',
        eppId: '',
        isActive: true,
      };
    }
  };

  const [formData, setFormData] = useState<FormData>(getInitialFormData());

  const [errors, setErrors] = useState<string[]>([]);

  /**
   * Préréglage : useLayoutEffect pour que drenaId / ieppId / eppId soient posés
   * avant les autres effets — sinon l’effet « DRENA » voyait encore l’état vide
   * et vidait ieppId/eppId (bug liste IEPP vide au montage).
   */
  // En édition : charger DRENA / IEPP / EPP pour préremplir les listes déroulantes
  useEffect(() => {
    if (!editUser?.id) return;
    void loadDrenas();
    const did = editUser.drenaId;
    if (typeof did === 'number' && did > 0) {
      void loadIepps(did);
      const iid = editUser.ieppId;
      if (typeof iid === 'number' && iid > 0) {
        void loadEpps(did, iid);
      }
    }
  }, [editUser?.id, editUser?.drenaId, editUser?.ieppId, loadDrenas, loadIepps, loadEpps]);

  useLayoutEffect(() => {
    if (editUser || !creationPreset) return;
    const p = creationPreset;
    const fromHeader = p.source === 'fromHeader';
    setFormData((prev) => ({
      ...prev,
      roleCode: p.roleCode,
      drenaId: p.drenaId,
      // Depuis l’en-tête : ne pas préremplir la feuille (IEPP pour DRENA, EPP pour IEPP)
      ieppId:
        fromHeader && p.roleCode === 'IEPP'
          ? ''
          : p.ieppId || '',
      eppId:
        fromHeader && p.roleCode === 'DIRECTEUR'
          ? ''
          : p.eppId || '',
    }));
    loadDrenas();
    const did = parseInt(p.drenaId, 10);
    if (!Number.isNaN(did)) {
      void loadIepps(did);
    }
    const iid = p.ieppId ? parseInt(p.ieppId, 10) : NaN;
    if (!Number.isNaN(did) && !Number.isNaN(iid)) {
      void loadEpps(did, iid);
    }
  }, [editUser, creationPreset, loadDrenas, loadIepps, loadEpps]);

  // Charger les IEPP quand une DRENA et un rôle sont connus (pas de reset agressif au montage)
  useEffect(() => {
    if (formData.drenaId && formData.roleCode) {
      loadIepps(parseInt(formData.drenaId, 10));
    }
  }, [formData.drenaId, formData.roleCode, loadIepps]);

  // Charger les EPP quand DRENA + IEPP + rôle sont connus
  useEffect(() => {
    if (formData.drenaId && formData.ieppId && formData.roleCode) {
      loadEpps(parseInt(formData.drenaId, 10), parseInt(formData.ieppId, 10));
    }
  }, [formData.drenaId, formData.ieppId, formData.roleCode, loadEpps]);

  // Pas de DRENA : loadIepps ne part pas — éviter d’afficher des IEPP/EPP d’une sélection antérieure
  useEffect(() => {
    if (!formData.drenaId && ['IEPP', 'DIRECTEUR'].includes(formData.roleCode)) {
      clearIeppsAndEpps();
    }
  }, [formData.drenaId, formData.roleCode, clearIeppsAndEpps]);

  // DIRECTEUR sans IEPP : loadEpps ne part pas — vider les EPP affichées (ex. désélection IEPP)
  useEffect(() => {
    if (formData.roleCode === 'DIRECTEUR' && !formData.ieppId) {
      clearEpps();
    }
  }, [formData.ieppId, formData.roleCode, clearEpps]);

  // Fonction pour réinitialiser les structures dépendantes
  const resetDependentStructures = (level: 'iepp' | 'epp') => {
    if (level === 'iepp') {
      setFormData(prev => ({ ...prev, ieppId: '', eppId: '' }));
    } else if (level === 'epp') {
      setFormData(prev => ({ ...prev, eppId: '' }));
    }
  };

  const handleInputChange = (field: keyof FormData, value: string | boolean) => {
    setFormData(prev => {
      const newData = { ...prev, [field]: value };
      
      // Gérer les changements hiérarchiques
      if (field === 'drenaId') {
        // Si la DRENA change, réinitialiser IEPP et EPP
        newData.ieppId = '';
        newData.eppId = '';
      } else if (field === 'ieppId') {
        // Si l'IEPP change, réinitialiser EPP
        newData.eppId = '';
      }
      
      return newData;
    });
    
    // Réinitialiser les erreurs quand l'utilisateur modifie le formulaire
    if (errors.length > 0) {
      setErrors([]);
    }
  };

  const MATRICULE_MIN_LENGTH = 6;
  const TELEPHONE_CI = /^(01|05|07)\d{8}$/;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrors([]);

    try {
      const loginTrim = formData.login.trim();
      if (loginTrim.length < MATRICULE_MIN_LENGTH) {
        const msg = `Le matricule doit comporter au moins ${MATRICULE_MIN_LENGTH} caractères`;
        setErrors([msg]);
        toast.error(msg);
        return;
      }

      const telDigits = formData.telephone.replace(/\D/g, "");
      if (!editUser) {
        if (!telDigits) {
          const msg = "Le numéro de téléphone est obligatoire.";
          setErrors([msg]);
          toast.error(msg);
          return;
        }
        if (!TELEPHONE_CI.test(telDigits)) {
          const msg =
            "Le téléphone doit comporter 10 chiffres et commencer par 01, 05 ou 07.";
          setErrors([msg]);
          toast.error(msg);
          return;
        }
      } else if (telDigits && !TELEPHONE_CI.test(telDigits)) {
        const msg =
          "Le téléphone doit comporter 10 chiffres et commencer par 01, 05 ou 07.";
        setErrors([msg]);
        toast.error(msg);
        return;
      }

      const rc = formData.roleCode;
      const structureMissing: string[] = [];
      if (['DRENA', 'IEPP', 'DIRECTEUR'].includes(rc) && !formData.drenaId) {
        structureMissing.push('une DRENA');
      }
      if (['IEPP', 'DIRECTEUR'].includes(rc) && !formData.ieppId) {
        structureMissing.push('une IEPP');
      }
      if (rc === 'DIRECTEUR' && !formData.eppId) {
        structureMissing.push('une EPP');
      }
      if (structureMissing.length > 0) {
        const msg = `Veuillez sélectionner ${structureMissing.join(', ')}.`;
        setErrors([msg]);
        toast.error(msg);
        return;
      }

      if (editUser) {
        // Mode modification : construire les données de mise à jour
        const updateData: Partial<CreateUserRequest> & { id: number } = {
          id: editUser.id,
          firstName: formData.firstName,
          lastName: formData.lastName,
          email: formData.email,
          login: loginTrim,
          telephone: telDigits,
          isActive: formData.isActive,
          // Ajouter les champs de rôle et structures si modifiés
          roleId: formData.roleCode ? getRoleIdByCode(formData.roleCode) : editUser.role.id,
          roleCode: formData.roleCode || editUser.role.code, // Ajouter le code du rôle
        };

        // Ajouter les structures si modifiées
        if (formData.drenaId) {
          updateData.drenaId = parseInt(formData.drenaId);
          updateData.drenaCode = drenas.find(d => d.id === parseInt(formData.drenaId))?.code || '';
        }
        
        if (formData.ieppId) {
          updateData.ieppId = parseInt(formData.ieppId);
          updateData.ieppCode = iepps.find(i => i.id === parseInt(formData.ieppId))?.code || '';
        }
        
        if (formData.eppId) {
          updateData.eppId = parseInt(formData.eppId);
          updateData.eppCode = epps.find(e => e.id === parseInt(formData.eppId))?.code || '';
        }

        onSubmit(updateData);
      } else {
        // Mode création : construire le contexte selon le rôle sélectionné
        const context: any = { roleCode: formData.roleCode };
        
        if (formData.drenaId) {
          context.drenaId = parseInt(formData.drenaId);
          context.drenaCode = drenas.find(d => d.id === parseInt(formData.drenaId))?.code || '';
        }
        
        if (formData.ieppId) {
          context.ieppId = parseInt(formData.ieppId);
          context.ieppCode = iepps.find(i => i.id === parseInt(formData.ieppId))?.code || '';
        }
        
        if (formData.eppId) {
          context.eppId = parseInt(formData.eppId);
          context.eppCode = epps.find(e => e.id === parseInt(formData.eppId))?.code || '';
        }

        // Construire la requête de création d'utilisateur (sans mot de passe)
        const userRequest = buildCreateUserRequest(
          { ...formData, login: loginTrim, telephone: telDigits } as any,
          context
        );
        
        onSubmit(userRequest);
      }
      
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Erreur de validation';
      setErrors([errorMessage]);
      toast.error(errorMessage);
    }
  };

  // Fonction utilitaire pour obtenir l'ID du rôle par son code
  const getRoleIdByCode = (roleCode: string): number => {
    switch (roleCode.toUpperCase()) {
      case 'ADMIN': return 1;
      case 'DAF': return 2;
      case 'DRENA': return 3;
      case 'IEPP': return 4;
      case 'DIRECTEUR': return 5;
      default: return 1;
    }
  };

  // Déterminer quels champs sont requis selon le rôle
  const getRequiredFields = () => {
    const base = ['firstName', 'lastName', 'login'];
    
    switch (formData.roleCode) {
      case 'DRENA':
        return [...base, 'drenaId'];
      case 'IEPP':
        return [...base, 'drenaId', 'ieppId'];
      case 'DIRECTEUR':
        return [...base, 'drenaId', 'ieppId', 'eppId'];
      default:
        return base;
    }
  };

  const requiredFields = getRequiredFields();
  const isFieldRequired = (field: string) => requiredFields.includes(field);

  // Déterminer si les structures sont visibles selon le rôle
  const showDrenaField = ['DRENA', 'IEPP', 'DIRECTEUR'].includes(formData.roleCode);
  const showIeppField = ['IEPP', 'DIRECTEUR'].includes(formData.roleCode);
  const showEppField = formData.roleCode === 'DIRECTEUR';

  const drenaEmptyLabel = !isUserConnected
    ? 'Utilisateur non connecté'
    : structuresLoading
      ? 'Chargement des DRENA…'
      : drenas.length === 0
        ? 'Aucune DRENA disponible'
        : 'Sélectionner une DRENA';

  const ieppEmptyLabel = !formData.drenaId
    ? "Sélectionnez d'abord une DRENA"
    : structuresLoading
      ? 'Chargement des IEPP…'
      : 'Sélectionner une IEPP';

  const eppEmptyLabel = !formData.ieppId
    ? "Sélectionnez d'abord une IEPP"
    : structuresLoading
      ? 'Chargement des EPP…'
      : 'Sélectionner une EPP';

  return (
    <div className="space-y-6">
      {!isUserConnected && (
        <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-md">
          <div className="flex items-center">
            <div className="text-yellow-600 mr-3">⚠️</div>
            <div>
              <h3 className="text-yellow-800 font-medium">Utilisateur non connecté</h3>
              <p className="text-yellow-700 text-sm mt-1">
                Veuillez vous connecter pour accéder aux données des rôles et structures.
              </p>
            </div>
          </div>
        </div>
      )}

      {errors.length > 0 && (
        <div className="p-4 bg-red-50 border border-red-200 rounded-md">
          <h3 className="text-red-800 font-medium">Erreurs de validation :</h3>
          <ul className="mt-2 text-red-700">
            {errors.map((error, index) => (
              <li key={index}>• {error}</li>
            ))}
          </ul>
        </div>
      )}

      {editUser && (
        <div className="rounded-xl overflow-hidden border border-orange-200/80 shadow-md ring-1 ring-orange-100/80">
          <div className="bg-gradient-to-r from-orange-500 via-orange-600 to-amber-600 px-4 py-4 sm:px-5 text-white flex items-center gap-4">
            <div className="h-14 w-14 shrink-0 rounded-2xl bg-white/20 flex items-center justify-center text-lg font-bold ring-2 ring-white/25">
              {(editUser.firstName?.charAt(0) || '?').toUpperCase()}
              {(editUser.lastName?.charAt(0) || '?').toUpperCase()}
            </div>
            <div className="min-w-0">
              <p className="font-bold text-lg truncate">
                {editUser.firstName} {editUser.lastName}
              </p>
              <p className="text-sm text-orange-100">{editUser.role.libelle}</p>
              <p className="text-xs font-mono text-white/90 mt-0.5 truncate">@{editUser.login}</p>
            </div>
          </div>
          <div className="bg-orange-50/80 px-4 py-2.5 text-xs text-orange-900/90 border-t border-orange-100">
            <span className="font-semibold">ID {editUser.id}</span>
            <span className="mx-2 text-orange-300">·</span>
            Structure affichée : {editUser.structure.libelle}
          </div>
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Coordonnées */}
        <div className="rounded-xl border border-gray-200 bg-gradient-to-b from-slate-50/90 to-white p-4 sm:p-5 shadow-sm">
          <h3 className="text-sm font-semibold text-gray-800 flex items-center gap-2 border-b border-gray-100 pb-3 mb-4">
            <UserCircleIcon className="h-5 w-5 text-orange-500 shrink-0" aria-hidden />
            Coordonnées
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="form-group">
            <label className="form-label">
              Prénom {isFieldRequired('firstName') && <span className="text-red-500">*</span>}
            </label>
            <input
              type="text"
              value={formData.firstName}
              onChange={(e) => handleInputChange('firstName', e.target.value)}
              className="input-field"
              required={isFieldRequired('firstName')}
            />
          </div>

          <div className="form-group">
            <label className="form-label">
              Nom {isFieldRequired('lastName') && <span className="text-red-500">*</span>}
            </label>
            <input
              type="text"
              value={formData.lastName}
              onChange={(e) => handleInputChange('lastName', e.target.value)}
              className="input-field"
              required={isFieldRequired('lastName')}
            />
          </div>

          <div className="form-group">
            <label className="form-label">
              Email
            </label>
            <input
              type="email"
              value={formData.email}
              onChange={(e) => handleInputChange('email', e.target.value)}
              className="input-field"
              required={false}
            />
          </div>

          <div className="form-group">
            <label className="form-label">
              Matricule {isFieldRequired('login') && <span className="text-red-500">*</span>}
            </label>
            <input
              type="text"
              value={formData.login}
              onChange={(e) => handleInputChange('login', e.target.value)}
              className="input-field"
              minLength={MATRICULE_MIN_LENGTH}
              required={isFieldRequired('login')}
              autoComplete="off"
            />
            {/* <p className="text-xs text-gray-500 mt-1">
              Au moins {MATRICULE_MIN_LENGTH} caractères (sans compter les espaces en début/fin, supprimés à l&apos;enregistrement).
            </p> */}
          </div>


          <div className="form-group">
            <label className="form-label">
              Téléphone {!editUser && <span className="text-red-500">*</span>}
            </label>
            <input
              type="tel"
              inputMode="numeric"
              autoComplete="tel"
              placeholder="ex. 07 12 34 56 78"
              value={formData.telephone}
              onChange={(e) => handleInputChange('telephone', e.target.value)}
              className="input-field"
            />
            <p className="text-xs text-gray-500 mt-1">
              10 chiffres, commençant par 01, 05 ou 07 (Côte d&apos;Ivoire).
            </p>
          </div>

          <div className="form-group">
            <label className="form-label">Date de naissance</label>
            <input
              type="date"
              value={formData.bornOn}
              onChange={(e) => handleInputChange('bornOn', e.target.value)}
              className="input-field"
            />
          </div>
          </div>
        </div>

        {/* Profil & rattachement */}
        <div className="rounded-xl border border-emerald-200/90 bg-gradient-to-b from-emerald-50/60 to-white p-4 sm:p-5 shadow-sm">
          <h3 className="text-sm font-semibold text-emerald-950 flex items-center gap-2 border-b border-emerald-100 pb-3 mb-1">
            <AcademicCapIcon className="h-5 w-5 text-emerald-600 shrink-0" aria-hidden />
            Profil et rattachement
          </h3>
          <p className="text-xs text-emerald-800/85 mb-4">
            Rôle hiérarchique et structures DRENA → IEPP → EPP selon les règles du ministère.
          </p>

        {/* Rôle */}
        <div className="form-group">
          <div className="flex items-center justify-between">
            <label className="form-label">
              Rôle <span className="text-red-500">*</span>
            </label>
            {isUserConnected && (
              <button
                type="button"
                onClick={() => {
                  logger.log('Rechargement des rôles...');
                  loadRoles({ isActive: true });
                }}
                className="text-xs text-blue-600 hover:text-blue-800 underline"
                disabled={rolesLoading}
              >
                {rolesLoading ? "Chargement..." : "Recharger"}
              </button>
            )}
          </div>
          <select
            value={formData.roleCode}
            onChange={(e) => handleInputChange('roleCode', e.target.value)}
            className="input-field"
            required
            disabled={rolesLoading || !isUserConnected || !!creationPreset?.lockRole}
          >
            <option value="">
              {!isUserConnected 
                ? "Utilisateur non connecté" 
                : rolesLoading 
                  ? "Chargement des rôles..." 
                  : roles.length === 0 
                    ? "Aucun rôle disponible" 
                    : "Sélectionner un rôle"
              }
            </option>
            {(creatorRoleCode ? rolesForSelect : roles).map((role) => (
              <option key={role.id} value={role.code}>
                {role.libelle} ({role.code})
              </option>
            ))}
          </select>
          {rolesError && (
            <p className="text-red-600 text-sm mt-1">{rolesError}</p>
          )}
          {rolesLoading && (
            <p className="text-sm text-gray-500 mt-1">
              🔄 Chargement des rôles depuis le serveur...
            </p>
          )}
          {(creatorRoleCode ? rolesForSelect : roles).length === 0 && !rolesLoading && (
            <p className="text-sm text-yellow-600 mt-1">
              ⚠️ Aucun rôle disponible pour votre profil
            </p>
          )}
          {rolesError && (
            <p className="text-sm text-red-600 mt-1">
              ❌ {rolesError}
            </p>
          )}
        </div>

        {(showDrenaField || showIeppField || showEppField) && (
          <div className="flex items-start gap-2 rounded-lg bg-white/80 border border-emerald-100 px-3 py-2 mb-3">
            <BuildingOffice2Icon className="h-5 w-5 text-emerald-600 shrink-0 mt-0.5" aria-hidden />
            <div className="text-xs text-emerald-900/90">
              <p className="font-semibold text-emerald-950">Hiérarchie territoriale</p>
              <p className="mt-0.5">Sélectionnez d&apos;abord la <strong>DRENA</strong>, puis l&apos;<strong>IEPP</strong> et l&apos;<strong>EPP</strong> lorsque le rôle l&apos;exige.</p>
            </div>
          </div>
        )}

        {showDrenaField && (
          <div className="form-group">
            <div className="flex items-center justify-between">
              <label className="form-label">
                DRENA {isFieldRequired('drenaId') && <span className="text-red-500">*</span>}
              </label>
              {isUserConnected && (
                <button
                  type="button"
                  onClick={() => {
                    logger.log('Rechargement des DRENA...');
                    loadDrenas();
                  }}
                  className="text-xs text-blue-600 hover:text-blue-800 underline"
                  disabled={structuresLoading}
                >
                  {structuresLoading ? "Chargement..." : "Recharger"}
                </button>
              )}
            </div>
            <SearchableStructureSelect
              id="user-form-drena"
              value={formData.drenaId}
              onChange={(v) => handleInputChange('drenaId', v)}
              options={drenas.map((d) => ({
                id: d.id,
                code: d.code,
                libelle: d.libelle,
              }))}
              emptyLabel={drenaEmptyLabel}
              disabled={
                structuresLoading ||
                !isUserConnected ||
                !!creationPreset?.lockDrena ||
                !!editHierarchyLocks?.lockDrena
              }
            />
          </div>
        )}

        {showIeppField && (
          <div className="form-group">
            <label className="form-label">
              IEPP {isFieldRequired('ieppId') && <span className="text-red-500">*</span>}
            </label>
            <SearchableStructureSelect
              id="user-form-iepp"
              value={formData.ieppId}
              onChange={(v) => handleInputChange('ieppId', v)}
              options={iepps.map((i) => ({
                id: i.id,
                code: i.code,
                libelle: i.libelle,
              }))}
              emptyLabel={ieppEmptyLabel}
              disabled={
                !formData.drenaId ||
                structuresLoading ||
                !!creationPreset?.lockIepp ||
                !!editHierarchyLocks?.lockIepp
              }
            />
            {!formData.drenaId && (
              <p className="text-sm text-gray-500 mt-1">
                Les IEPP sont filtrées par la DRENA sélectionnée
              </p>
            )}
          </div>
        )}

        {showEppField && (
          <div className="form-group">
            <label className="form-label">
              EPP {isFieldRequired('eppId') && <span className="text-red-500">*</span>}
            </label>
            <SearchableStructureSelect
              id="user-form-epp"
              value={formData.eppId}
              onChange={(v) => handleInputChange('eppId', v)}
              options={epps.map((e) => ({
                id: e.id,
                code: e.code,
                libelle: e.libelle,
              }))}
              emptyLabel={eppEmptyLabel}
              disabled={!formData.ieppId || structuresLoading || !!creationPreset?.lockEpp}
            />
            {!formData.ieppId && (
              <p className="text-sm text-gray-500 mt-1">
                Les EPP sont filtrées par l'IEPP sélectionnée
              </p>
            )}
          </div>
        )}

        </div>

        {/* Options */}
        <div className="rounded-lg border border-gray-100 bg-gray-50/80 px-4 py-3 flex flex-wrap items-center gap-4">
          <label className="flex items-center">
            <input
              type="checkbox"
              checked={formData.isActive}
              onChange={(e) => handleInputChange('isActive', e.target.checked)}
              className="mr-2"
            />
            <span className="text-sm text-gray-800">Compte actif</span>
          </label>
        </div>

        {/* Boutons d'action */}
        <div className="flex justify-end space-x-3 pt-4">
          <button
            type="button"
            onClick={onCancel}
            className="btn-outline"
            disabled={loading}
          >
            Annuler
          </button>
          <button
            type="submit"
            className="btn-primary"
            disabled={loading || structuresLoading}
          >
            {loading ? (editUser ? 'Modification...' : 'Création...') : (editUser ? 'Modifier Utilisateur' : 'Créer Utilisateur')}
          </button>
        </div>
      </form>
    </div>
  );
}