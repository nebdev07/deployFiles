/**
 * Composant de formulaire pour l'Expression des Besoins
 * Adapté pour utiliser les catalogues (comme réception/distribution)
 * Permet la saisie des quantités pour chaque matière avant d'ajouter au tableau
 */

import React, { useState, useEffect, useMemo, useRef } from 'react';
import { useAnneesScolaires } from '@/hooks/use-annees-scolaires';
import { besoinsService, BesoinData, BesoinDetailData } from '@/lib/services/besoins.service';
import { catalogueService } from '@/lib/services/catalogue.service';
import { PlusIcon, XCircleIcon, ClipboardDocumentListIcon, CalculatorIcon, TrashIcon } from '@heroicons/react/24/outline';
import toast from 'react-hot-toast';

interface BesoinFormProps {
  onSubmit: (besoinData: BesoinData | BesoinData[]) => void; // ✅ NOUVEAU : Peut accepter un tableau pour multi-création
  onCancel: () => void;
  loading?: boolean;
  userStructure?: any;
  besoinExistant?: BesoinData | any; // Pour l'édition (peut être BesoinResponse complet)
  mode?: 'create' | 'edit' | 'view'; // Mode du formulaire
}

interface MatiereBesoin {
  matiereId: number;
  matiereCode: string;
  matiereLibelle: string;
  quantiteBrute: number;
  quantiteRetourAnneePrecedente: number;
  quantiteNet: number;
  loadingRetours?: boolean;
  catalogueId?: number;
  /** Niveau scolaire (pour besoin multi-niveaux) */
  niveauScolaireId?: number;
}

interface Catalogue {
  id: number;
  libelle: string;
  niveauScolaire: string;
  niveauScolaireId: number;
  niveauCode: string;
  code: string;
  anneeScolaire: string;
  anneeScolaireId: number;
  icone: string;
  matieres: any[];
  quantitesSaisies: MatiereBesoin[];
  // Effectif spécifique à ce niveau
  effectifTotal?: number;
}

interface FormData {
  anneeScolaireId: number;
  // ✅ SUPPRIMÉ : effectifGarcons, effectifFilles, effectifTotal (maintenant dans chaque Catalogue)
  commentaire: string;
  manuels: MatiereBesoin[]; // Toutes les matières avec quantités (comme DistributionForm)
  selectedCatalogues: Catalogue[];
}

export default function BesoinForm({ onSubmit, onCancel, loading = false, userStructure, besoinExistant, mode = 'create' }: BesoinFormProps) {
  const { anneesScolaires: annees, loading: anneesLoading } = useAnneesScolaires();
  const anneeCouranteId = useMemo(
    () => (annees || []).find((a: any) => a?.estCourante === true)?.id ?? null,
    [annees]
  );

  // État du formulaire principal (identique à DistributionForm)
  const [formData, setFormData] = useState<FormData>({
    anneeScolaireId: besoinExistant?.anneeScolaireId || (annees && annees.length > 0 ? annees[0].id : 0),
    // ✅ SUPPRIMÉ : effectifGarcons, effectifFilles, effectifTotal (maintenant dans chaque Catalogue)
    commentaire: besoinExistant?.commentaire || '',
    manuels: besoinExistant?.besoinDetails?.map((d: any) => ({
      matiereId: d.matiereId,
      matiereCode: d.matiereCode || '',
      matiereLibelle: d.matiereLibelle || '',
      quantiteBrute: d.quantiteBrute || 0,
      quantiteRetourAnneePrecedente: d.quantiteRetourAnneePrecedente || 0,
      quantiteNet: d.quantiteNet || 0,
    })) || [],
    selectedCatalogues: []
  });

  // États pour la gestion des catalogues
  const [availableCatalogues, setAvailableCatalogues] = useState<Catalogue[]>([]);
  const [selectedCatalogueId, setSelectedCatalogueId] = useState<string>('');
  const [currentCatalogueData, setCurrentCatalogueData] = useState<Catalogue | null>(null);
  const [catalogueMatieres, setCatalogueMatieres] = useState<any[]>([]);
  const [loadingCatalogues, setLoadingCatalogues] = useState(false);
  const [loadingRetours, setLoadingRetours] = useState<Record<number, boolean>>({});
  const [error, setError] = useState<string>('');

  // ✅ SUPPRIMÉ : Calcul automatique de effectifTotal global (plus nécessaire, effectifs saisis par niveau)

  // Met à jour l'effectif total d'un catalogue déjà ajouté
  const handleUpdateCatalogueEffectifs = (catalogueId: number, value: number) => {
    setFormData(prev => ({
      ...prev,
      selectedCatalogues: prev.selectedCatalogues.map(c => {
        if (c.id === catalogueId) {
          return {
            ...c,
            effectifTotal: value
          };
        }
        return c;
      })
    }));
  };

  // Fonction utilitaire pour obtenir l'icône du catalogue
  const getCatalogueIcon = (niveauCode: string) => {
    const iconMap: { [key: string]: string } = {
      'CP1': '📚',
      'CP2': '📖',
      'CE1': '📘',
      'CE2': '📗',
      'CM1': '📙',
      'CM2': '📕'
    };
    return iconMap[niveauCode] || '📄';
  };

  // Charger les catalogues actifs pour l'année sélectionnée
  useEffect(() => {
    if (formData.anneeScolaireId) {
      loadCatalogues();
    }
  }, [formData.anneeScolaireId]);

  // ✅ NOUVEAU : Référence pour éviter les initialisations multiples
  const initializedRef = useRef(false);

  // Initialiser selectedCatalogues en mode édition ou vue - GROUPER PAR NIVEAU + effectifs depuis BesoinDetail
  useEffect(() => {
    if ((mode !== 'edit' && mode !== 'view') || !besoinExistant?.besoinDetails || besoinExistant.besoinDetails.length === 0) {
      initializedRef.current = false;
      return;
    }
    if (availableCatalogues.length === 0) return;
    if (initializedRef.current) return;

    const details = besoinExistant.besoinDetails;
    const byNiveau = new Map<number, typeof details>();
    for (const d of details) {
      const nivId = d.niveauScolaireId ?? besoinExistant.niveauScolaireId;
      if (!nivId) continue;
      if (!byNiveau.has(nivId)) byNiveau.set(nivId, []);
      byNiveau.get(nivId)!.push(d);
    }

    const cataloguesToAdd: Catalogue[] = [];
    const manuelsToAdd: MatiereBesoin[] = [];
    const effGlobalTotal = besoinExistant.effectifTotal || ((besoinExistant.effectifGarcons || 0) + (besoinExistant.effectifFilles || 0));
    const nbNiveaux = byNiveau.size;

    for (const [niveauId, nivDetails] of byNiveau) {
      const catalogue = availableCatalogues.find(c => c.niveauScolaireId === niveauId);
      if (!catalogue) continue;

      // Effectifs depuis le premier BesoinDetail de ce niveau (stockés en BDD)
      const premier = nivDetails[0] as any;
      const effTotalDetail =
        premier?.effectifTotalNiveau ??
        premier?.effectifTotal ??
        (premier?.effectifGarcons || 0) + (premier?.effectifFilles || 0);
      const effTotalFallback = (nbNiveaux === 1 ? effGlobalTotal : Math.floor(effGlobalTotal / nbNiveaux));
      const effTotal =
        effTotalDetail || effTotalFallback;

      const quantitesSaisies = nivDetails.map((d: any) => ({
        matiereId: d.matiereId,
        matiereCode: d.matiereCode || '',
        matiereLibelle: d.matiereLibelle || '',
        quantiteBrute: d.quantiteBrute || 0,
        quantiteRetourAnneePrecedente: d.quantiteRetourAnneePrecedente || 0,
        quantiteNet: d.quantiteNet || 0,
      }));

      cataloguesToAdd.push({
        ...catalogue,
        quantitesSaisies,
        effectifTotal: effTotal,
      });

      for (const d of nivDetails) {
        manuelsToAdd.push({
          matiereId: d.matiereId,
          matiereCode: d.matiereCode || '',
          matiereLibelle: d.matiereLibelle || '',
          quantiteBrute: d.quantiteBrute || 0,
          quantiteRetourAnneePrecedente: d.quantiteRetourAnneePrecedente || 0,
          quantiteNet: d.quantiteNet || 0,
          catalogueId: catalogue.id,
          niveauScolaireId: niveauId,
        });
      }
    }

    setFormData(prev => ({
      ...prev,
      selectedCatalogues: cataloguesToAdd,
      manuels: manuelsToAdd,
    }));
    initializedRef.current = true;
  }, [mode, besoinExistant?.besoinDetails?.length, besoinExistant?.niveauScolaireId, availableCatalogues.length]);

  /**
   * Charge les catalogues actifs pour l'année sélectionnée
   */
  const loadCatalogues = async () => {
    if (!formData.anneeScolaireId) return;

    setLoadingCatalogues(true);
    setError('');

    try {
      console.log('📚 Chargement des catalogues actifs pour année:', formData.anneeScolaireId);

      const result = await catalogueService.getCataloguesActifs(formData.anneeScolaireId);

      if (result.hasError) {
        throw new Error(result.status?.message || 'Erreur lors de la récupération des catalogues');
      }

      if (!result.items || !Array.isArray(result.items)) {
        throw new Error('Aucune donnée reçue du serveur');
      }

      // Mapper les données backend vers le format frontend (déjà filtrées par année côté backend)
      const mappedCatalogues: Catalogue[] = result.items.map((catalogue: any) => {
        const niveauId = catalogue.niveauScolaire?.id || catalogue.niveauScolaireId || catalogue.idNiveauScolaire || 0;
        const niveauCode = catalogue.niveauScolaire?.code || catalogue.niveauScolaireCode || 'N/A';
        const niveauLibelle = catalogue.niveauScolaire?.libelle || catalogue.niveauScolaireLibelle || 'N/A';
        const anneeId = catalogue.anneeScolaire?.id || catalogue.anneeScolaireId || 0;

        return {
          id: catalogue.id,
          libelle: catalogue.libelle,
          code: catalogue.code,
          anneeScolaire: catalogue.anneeScolaire?.libelle || catalogue.anneeScolaireLibelle || 'N/A',
          anneeScolaireId: anneeId,
          niveauScolaire: niveauLibelle,
          niveauScolaireId: niveauId,
          niveauCode: niveauCode,
          icone: getCatalogueIcon(niveauCode),
          matieres: catalogue.matieres || [],
          quantitesSaisies: []
        };
      });

      console.log('📚 Catalogues filtrés pour année', formData.anneeScolaireId, ':', mappedCatalogues);
      setAvailableCatalogues(mappedCatalogues);

      if (mappedCatalogues.length === 0) {
        toast(`Aucun catalogue actif trouvé pour l'année sélectionnée`, {
          icon: '⚠️'
        });
      }

    } catch (error) {
      console.error('Erreur lors du chargement des catalogues:', error);
      const errorMessage = error instanceof Error ? error.message : 'Erreur inconnue';
      setError(errorMessage);
      toast.error(`Erreur lors du chargement des catalogues: ${errorMessage}`);
      setAvailableCatalogues([]);
    } finally {
      setLoadingCatalogues(false);
    }
  };

  /**
   * Gère la sélection d'un catalogue
   */
  const handleCatalogueSelect = async (catalogueId: string) => {
    if (!catalogueId) {
      setSelectedCatalogueId('');
      setCurrentCatalogueData(null);
      setCatalogueMatieres([]);
      return;
    }

    const catalogue = availableCatalogues.find(c => c.id.toString() === catalogueId);
    if (!catalogue) {
      console.error(`❌ Catalogue ${catalogueId} non trouvé`);
      return;
    }

    setSelectedCatalogueId(catalogueId);
    setCurrentCatalogueData(catalogue);
    setError('');

    // Récupérer les matières associées à ce catalogue
    await fetchCatalogueMatieres(parseInt(catalogueId));
  };

  /**
   * Récupère les matières d'un catalogue
   */
  const fetchCatalogueMatieres = async (catalogueId: number) => {
    try {
      console.log('📚 Récupération des matières pour catalogue:', catalogueId);

      const result = await catalogueService.getMatieresByCatalogue(catalogueId);

      if (result.hasError) {
        throw new Error(result.status?.message || 'Erreur lors de la récupération des matières');
      }

      // Mapper les matières reçues
      const matieres = result.items?.map((cm: any) => ({
        id: cm.matiereId,
        code: cm.matiereCode,
        libelle: cm.matiereLibelle,
      })) || [];

      console.log('📚 Matières mappées:', matieres);
      setCatalogueMatieres(matieres);

      // Charger les retours N-1 pour toutes les matières du catalogue
      if (currentCatalogueData && formData.anneeScolaireId) {
        await loadRetoursForMatieres(matieres, currentCatalogueData.niveauScolaireId);
      }

    } catch (error) {
      console.error('Erreur lors de la récupération des matières du catalogue:', error);
      toast.error("Erreur lors du chargement des matières du catalogue");
      setCatalogueMatieres([]);
    }
  };

  /**
   * Charge les retours N-1 pour toutes les matières
   */
  const loadRetoursForMatieres = async (matieres: any[], niveauId: number) => {
    if (!userStructure?.id || !formData.anneeScolaireId) return;

    for (const matiere of matieres) {
      // Vérifier si on a déjà les retours pour cette matière
      const existingMatiere = formData.manuels.find(m => m.matiereId === matiere.id);
      if (existingMatiere && existingMatiere.quantiteRetourAnneePrecedente > 0) {
        continue; // Déjà chargé
      }

      await fetchRetoursN1(matiere.id, niveauId, formData.anneeScolaireId);
    }
  };

  /**
   * Récupère les retours N-1 pour une matière
   */
  const fetchRetoursN1 = async (matiereId: number, niveauId: number, anneeScolaireId: number) => {
    if (!userStructure?.id || !matiereId || !niveauId || !anneeScolaireId) {
      return 0;
    }

    setLoadingRetours(prev => ({ ...prev, [matiereId]: true }));

    try {
      const result = await besoinsService.getQuantiteRetourAnneeN1(
        userStructure.id,
        niveauId,
        matiereId,
        anneeScolaireId
      );

      if (result.success && result.data !== undefined) {
        // Mettre à jour la matière dans formData.manuels si elle existe
        // Note: Cette fonction est appelée depuis handleUpdateQuantiteBrute qui gère déjà le catalogueId
        const existingIndex = formData.manuels.findIndex(m => m.matiereId === matiereId);
        if (existingIndex >= 0) {
          const retoursN1 = result.data;
          const quantiteBrute = formData.manuels[existingIndex].quantiteBrute;
          const quantiteNet = Math.max(0, quantiteBrute - retoursN1);
          
          setFormData(prev => ({
            ...prev,
            manuels: prev.manuels.map((m, idx) =>
              idx === existingIndex
                ? { ...m, quantiteRetourAnneePrecedente: retoursN1, quantiteNet }
                : m
            )
          }));
        }
        return result.data;
      }
      return 0;
    } catch (error) {
      console.error(`Erreur lors du chargement des quantités récupérées (N-1) pour la matière ${matiereId}:`, error);
      return 0;
    } finally {
      setLoadingRetours(prev => ({ ...prev, [matiereId]: false }));
    }
  };

  /**
   * Met à jour la quantité brute d'une matière (comme DistributionForm)
   */
  const handleUpdateQuantiteBrute = async (matiereId: number, quantiteBrute: number) => {
    if (!currentCatalogueData || !formData.anneeScolaireId) {
      toast.error('Données incomplètes pour mettre à jour la quantité');
      return;
    }

    // ✅ CORRECTION : Rechercher la matière en tenant compte du catalogueId
    // Une même matière peut exister dans plusieurs catalogues (ex: Français dans CP2 et CE1)
    const existingMatiere = formData.manuels.find(m => 
      m.matiereId === matiereId && m.catalogueId === currentCatalogueData.id
    );
    let retoursN1 = existingMatiere?.quantiteRetourAnneePrecedente || 0;

    // Si pas encore chargé, récupérer les retours N-1
    if (retoursN1 === 0 && existingMatiere) {
      retoursN1 = await fetchRetoursN1(matiereId, currentCatalogueData.niveauScolaireId, formData.anneeScolaireId);
    } else if (!existingMatiere) {
      // Nouvelle matière pour ce catalogue, charger les retours N-1
      retoursN1 = await fetchRetoursN1(matiereId, currentCatalogueData.niveauScolaireId, formData.anneeScolaireId);
    }

    const quantiteNet = Math.max(0, quantiteBrute - retoursN1);

    // Trouver la matière dans catalogueMatieres pour récupérer code/libelle
    const matiereInfo = catalogueMatieres.find(m => m.id === matiereId);

    const newManuels = [...formData.manuels];
    // ✅ CORRECTION : Rechercher en tenant compte du catalogueId
    const existingIndex = newManuels.findIndex(m => 
      m.matiereId === matiereId && m.catalogueId === currentCatalogueData.id
    );

    if (existingIndex >= 0) {
      // Mettre à jour la matière existante pour ce catalogue
      newManuels[existingIndex] = {
        ...newManuels[existingIndex],
        quantiteBrute,
        quantiteRetourAnneePrecedente: retoursN1,
        quantiteNet,
        catalogueId: currentCatalogueData.id // S'assurer que catalogueId est défini
      };
    } else {
      // Ajouter une nouvelle matière pour ce catalogue
      newManuels.push({
        matiereId: matiereId,
        matiereCode: matiereInfo?.code || '',
        matiereLibelle: matiereInfo?.libelle || '',
        quantiteBrute,
        quantiteRetourAnneePrecedente: retoursN1,
        quantiteNet,
        catalogueId: currentCatalogueData.id,
        niveauScolaireId: currentCatalogueData.niveauScolaireId,
      });
    }

    setFormData(prev => ({ ...prev, manuels: newManuels }));
  };

  // ✅ NOUVEAU : État pour les effectifs du catalogue en cours de sélection
  const [currentCatalogueEffectifs, setCurrentCatalogueEffectifs] = useState({
    effectifTotal: 0
  });

  // Met à jour l'effectif total du catalogue en cours de sélection
  const handleUpdateCurrentCatalogueEffectifs = (value: number) => {
    setCurrentCatalogueEffectifs({
      effectifTotal: value
    });
  };

  // ✅ NOUVEAU : Réinitialiser les effectifs quand on change de catalogue
  useEffect(() => {
    if (currentCatalogueData) {
      // En mode édition, pré-remplir depuis besoinExistant si disponible
      if (mode === 'edit' && besoinExistant && besoinExistant.niveauScolaireId === currentCatalogueData.niveauScolaireId) {
        setCurrentCatalogueEffectifs({
          effectifTotal: besoinExistant.effectifTotal || ((besoinExistant.effectifGarcons || 0) + (besoinExistant.effectifFilles || 0))
        });
      } else {
        // Sinon, réinitialiser à 0
        setCurrentCatalogueEffectifs({
          effectifTotal: 0
        });
      }
    }
  }, [currentCatalogueData?.id, mode, besoinExistant?.niveauScolaireId]);

  /**
   * Ajoute le catalogue sélectionné au tableau (comme DistributionForm)
   */
  const addCatalogueToTable = () => {
    if (!selectedCatalogueId || !currentCatalogueData) {
      setError('Veuillez sélectionner un catalogue');
      return;
    }

    // Vérifier si le catalogue est déjà sélectionné
    const isAlreadySelected = formData.selectedCatalogues.some(c => c.id === currentCatalogueData.id);
    if (isAlreadySelected) {
      setError('Ce catalogue est déjà sélectionné');
      return;
    }

    // Vérifier que l'effectif total est saisi
    if (currentCatalogueEffectifs.effectifTotal <= 0) {
      toast.error('L\'effectif total doit être supérieur à 0');
      return;
    }

    // Vérifier qu'au moins une quantité a été saisie
    const matieresAvecQuantites = formData.manuels.filter(m => 
      m.catalogueId === currentCatalogueData.id && m.quantiteBrute > 0
    );

    if (matieresAvecQuantites.length === 0) {
      toast.error('Veuillez saisir au moins une quantité pour ce catalogue');
      return;
    }

    // ✅ NOUVEAU : Ajouter le catalogue avec les quantités saisies et les effectifs saisis
    const catalogueWithQuantites = {
      ...currentCatalogueData,
      quantitesSaisies: matieresAvecQuantites,
      effectifTotal: currentCatalogueEffectifs.effectifTotal
    };

    setFormData(prev => ({
      ...prev,
      selectedCatalogues: [...prev.selectedCatalogues, catalogueWithQuantites]
    }));

    setSelectedCatalogueId('');
    setCurrentCatalogueData(null);
    setCatalogueMatieres([]);
    setCurrentCatalogueEffectifs({ effectifTotal: 0 }); // Réinitialiser
    setError('');
    toast.success('Catalogue ajouté avec succès');
  };

  /**
   * Retire un catalogue du tableau
   */
  const removeCatalogueFromTable = (catalogueId: number) => {
    setFormData(prev => ({
      ...prev,
      selectedCatalogues: prev.selectedCatalogues.filter(c => c.id !== catalogueId),
      manuels: prev.manuels.filter(m => m.catalogueId !== catalogueId)
    }));
    toast.success('Catalogue retiré');
  };

  /**
   * Met à jour la quantité brute dans le tableau des catalogues sélectionnés
   */
  const handleUpdateQuantiteInTable = async (catalogueId: number, matiereId: number, quantiteBrute: number) => {
    const catalogue = formData.selectedCatalogues.find(c => c.id === catalogueId);
    if (!catalogue || !formData.anneeScolaireId) {
      return;
    }

    // Récupérer les retours N-1
    let retoursN1 = 0;
    const existingMatiere = formData.manuels.find(m => m.matiereId === matiereId);
    if (existingMatiere) {
      retoursN1 = existingMatiere.quantiteRetourAnneePrecedente;
    } else {
      retoursN1 = await fetchRetoursN1(matiereId, catalogue.niveauScolaireId, formData.anneeScolaireId);
    }

    const quantiteNet = Math.max(0, quantiteBrute - retoursN1);

    // Mettre à jour dans manuels
    const newManuels = [...formData.manuels];
    const existingIndex = newManuels.findIndex(m => m.matiereId === matiereId && m.catalogueId === catalogueId);

    if (existingIndex >= 0) {
      newManuels[existingIndex] = {
        ...newManuels[existingIndex],
        quantiteBrute,
        quantiteRetourAnneePrecedente: retoursN1,
        quantiteNet
      };
    }

    // Mettre à jour dans selectedCatalogues
    setFormData(prev => ({
      ...prev,
      manuels: newManuels,
      selectedCatalogues: prev.selectedCatalogues.map(c =>
        c.id === catalogueId
          ? {
              ...c,
              quantitesSaisies: c.quantitesSaisies.map(q =>
                q.matiereId === matiereId
                  ? { ...q, quantiteBrute, quantiteRetourAnneePrecedente: retoursN1, quantiteNet }
                  : q
              )
            }
          : c
      )
    }));
  };

  /**
   * Recalcule les retours N-1 pour toutes les matières
   */
  const handleRecalculateRetours = async () => {
    if (!formData.anneeScolaireId) {
      toast.error('Veuillez sélectionner une année scolaire');
      return;
    }

    for (const catalogue of formData.selectedCatalogues) {
      for (const matiere of catalogue.quantitesSaisies) {
        const retoursN1 = await fetchRetoursN1(
          matiere.matiereId,
          catalogue.niveauScolaireId,
          formData.anneeScolaireId
        );
        const quantiteNet = Math.max(0, matiere.quantiteBrute - retoursN1);

        setFormData(prev => ({
          ...prev,
          manuels: prev.manuels.map(m =>
            m.matiereId === matiere.matiereId && m.catalogueId === catalogue.id
              ? { ...m, quantiteRetourAnneePrecedente: retoursN1, quantiteNet }
              : m
          ),
          selectedCatalogues: prev.selectedCatalogues.map(c =>
            c.id === catalogue.id
              ? {
                  ...c,
                  quantitesSaisies: c.quantitesSaisies.map(q =>
                    q.matiereId === matiere.matiereId
                      ? { ...q, quantiteRetourAnneePrecedente: retoursN1, quantiteNet }
                      : q
                  )
                }
              : c
          )
        }));
      }
    }

    toast.success(`Récupérations ${retourAnneeReferenceCode} recalculées avec succès`);
  };

  /**
   * Génère une référence automatique
   */
  const generateReference = (): string => {
    const structureCode = userStructure?.code || 'EPP';
    const anneeCode = annees?.find(a => a.id === formData.anneeScolaireId)?.code || 'ANNEE';
    const timestamp = new Date().getTime().toString().slice(-4);
    return `BES-${structureCode}-${anneeCode}-${timestamp}`;
  };

  const retourAnneeReferenceCode = useMemo(() => {
    const selectedCode = annees?.find((a: any) => a?.id === formData.anneeScolaireId)?.code
    if (typeof selectedCode === "string") {
      const m = selectedCode.match(/^(\d{4})-(\d{4})$/)
      if (m) {
        const start = Number(m[1]) - 1
        const end = Number(m[1])
        return `${start}-${end}`
      }
      return selectedCode
    }
    return "N-1"
  }, [annees, formData.anneeScolaireId])

  /**
   * Valide le formulaire
   */
  const validateForm = (): boolean => {
    if (!formData.anneeScolaireId) {
      toast.error('Veuillez sélectionner une année scolaire');
      return false;
    }
    if (mode === 'create' && anneeCouranteId && formData.anneeScolaireId !== anneeCouranteId) {
      toast.error("Création refusée: seule l'année scolaire courante est autorisée.");
      return false;
    }

    // Vérifier que chaque catalogue a un effectif total valide
    for (const catalogue of formData.selectedCatalogues) {
      const effectifTotal = catalogue.effectifTotal || 0;

      if (effectifTotal <= 0) {
        toast.error(`L'effectif total pour ${catalogue.niveauScolaire} doit être supérieur à 0`);
        return false;
      }
    }

    if (formData.selectedCatalogues.length === 0) {
      toast.error('Veuillez sélectionner au moins un catalogue');
      return false;
    }

    // Vérifier qu'au moins une quantité a été saisie
    const hasQuantities = formData.selectedCatalogues.some(catalogue =>
      catalogue.quantitesSaisies && catalogue.quantitesSaisies.some(q => q.quantiteBrute > 0)
    );

    if (!hasQuantities) {
      toast.error('Veuillez saisir au moins une quantité pour un catalogue');
      return false;
    }

    return true;
  };

  /**
   * Soumet le formulaire
   */
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!validateForm()) return;

    // Vérifier qu'on a au moins un niveau (depuis les catalogues)
    const niveauxUniques = new Set(formData.selectedCatalogues.map(c => c.niveauScolaireId));
    if (niveauxUniques.size === 0) {
      toast.error('Aucun niveau scolaire trouvé dans les catalogues');
      return;
    }

    // ✅ BESOIN MULTI-NIVEAUX : Un seul besoin par structure/année avec tous les détails (chaque détail a son niveau)
    // Le backend accepte maintenant 1 besoin avec plusieurs BesoinDetail, chacun avec niveauScolaireId
    const matieresAvecQuantites = formData.manuels.filter(m => m.quantiteBrute > 0);
    if (matieresAvecQuantites.length === 0) {
      toast.error('Aucune quantité saisie');
      return;
    }

    // Premier niveau = niveau "principal" du Besoin (compatibilité backend)
    const premierNiveauId = Array.from(niveauxUniques)[0];
    const premierCatalogue = formData.selectedCatalogues[0];

    // Transformer les données : chaque BesoinDetail a niveauScolaireId + effectifs par niveau
    const besoinDetails: BesoinDetailData[] = matieresAvecQuantites.map(m => {
      const catalogue = formData.selectedCatalogues.find(c => c.id === m.catalogueId);
      const niveauId = catalogue?.niveauScolaireId ?? m.niveauScolaireId ?? premierNiveauId;
      const effNiveau = Math.max(0, catalogue?.effectifTotal ?? 0);
      return {
        matiereId: m.matiereId,
        niveauScolaireId: niveauId,
        effectifTotalNiveau: effNiveau,
        quantiteBrute: m.quantiteBrute,
        quantiteRetourAnneePrecedente: m.quantiteRetourAnneePrecedente || 0,
        quantiteNet: m.quantiteNet || 0,
      };
    });

    // Calculer les effectifs totaux (somme des effectifs de tous les catalogues)
    const effectifTotal = formData.selectedCatalogues.reduce((s, c) => s + (c.effectifTotal || 0), 0);

    const besoinData: BesoinData = {
      id: besoinExistant?.id,
      reference: besoinExistant?.reference || generateReference(),
      structureId: userStructure?.id || 0,
      niveauScolaireId: premierNiveauId,
      anneeScolaireId: formData.anneeScolaireId,
      effectifTotal,
      statut: besoinExistant?.statut || 'SAISI',
      commentaire: formData.commentaire,
      besoinDetails,
    };

    console.log('📤 Données de besoin (multi-niveaux):', besoinData);
    onSubmit(besoinData);
  };

  // Catalogues disponibles (non déjà sélectionnés)
  const availableCataloguesForSelect = useMemo(() => {
    return availableCatalogues.filter(c => 
      !formData.selectedCatalogues.some(sc => sc.id === c.id)
    );
  }, [availableCatalogues, formData.selectedCatalogues]);

  return (
    <div className="max-w-6xl mx-auto max-h-[calc(100vh-8rem)] overflow-y-auto pr-2">
      {/* Header - Sticky */}
      <div className="sticky top-0 bg-white z-10 pb-4 pt-2 mb-6 border-b border-gray-200">
        <div className="flex items-center justify-between">
          <h3 className="text-xl font-bold text-gray-900 flex items-center gap-3">
            <ClipboardDocumentListIcon className="h-6 w-6 text-gray-700" />
            {besoinExistant ? 'Modifier le Besoin' : 'Nouvelle Expression de Besoin'}
          </h3>
          <button 
            onClick={onCancel} 
            className="text-gray-400 hover:text-gray-600 transition-colors"
            disabled={loading}
          >
            <XCircleIcon className="h-6 w-6" />
          </button>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Informations générales */}
        <div className="bg-white border border-gray-200 p-6 rounded-xl shadow-sm">
          <h4 className="text-lg font-semibold text-gray-900 mb-6 flex items-center gap-2">
            <span className="text-orange-600">📋</span>
            Informations Générales
          </h4>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Année Scolaire * (détermine les catalogues disponibles)
              </label>
              <select
                value={formData.anneeScolaireId}
                onChange={(e) => {
                  const anneeId = parseInt(e.target.value);
                  setFormData(prev => ({ 
                    ...prev, 
                    anneeScolaireId: anneeId,
                    selectedCatalogues: [], // Réinitialiser les catalogues sélectionnés
                    manuels: [] // Réinitialiser les matières
                  }));
                }}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-gray-500"
                required
                disabled={anneesLoading || mode === 'view'}
              >
                <option value="0">-- Sélectionner une année --</option>
                {annees?.map(annee => (
                  <option key={annee.id} value={annee.id} disabled={mode === 'create' && !!anneeCouranteId && annee.id !== anneeCouranteId}>
                    {annee.libelle}
                  </option>
                ))}
              </select>
              {mode === 'create' && (
                <p className="mt-2 text-xs text-amber-700">
                  Seule l&apos;année scolaire courante est autorisée pour la création d&apos;une expression de besoin.
                </p>
              )}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Référence
              </label>
              <input
                type="text"
                value={besoinExistant?.reference || generateReference()}
                readOnly
                className="w-full px-3 py-2 border border-gray-300 rounded-md bg-gray-100 text-gray-600"
              />
            </div>

            {/* Statut (affiché seulement en mode view/edit) */}
            {besoinExistant && (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Statut
                </label>
                <div className="flex items-center gap-2">
                  <span className={`px-3 py-2 rounded-md text-sm font-medium ${
                    besoinExistant.statut === 'SAISI' ? 'bg-yellow-100 text-yellow-800' :
                    besoinExistant.statut === 'VALIDE' ? 'bg-blue-100 text-blue-800' :
                    besoinExistant.statut === 'CONSOLIDE' ? 'bg-purple-100 text-purple-800' :
                    besoinExistant.statut === 'APPROUVE' ? 'bg-green-100 text-green-800' :
                    'bg-gray-100 text-gray-800'
                  }`}>
                    {besoinExistant.statut || 'SAISI'}
                  </span>
                </div>
              </div>
            )}

            {/* Structure (affiché seulement en mode view/edit) */}
            {besoinExistant?.structureAdministrativeLibelle && (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Structure
                </label>
                <input
                  type="text"
                  value={besoinExistant.structureAdministrativeLibelle}
                  readOnly
                  className="w-full px-3 py-2 border border-gray-300 rounded-md bg-gray-100 text-gray-600"
                />
              </div>
            )}

            {/* Niveau Scolaire (affiché seulement en mode view/edit) */}
            {besoinExistant?.niveauScolaireLibelle && (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Niveau Scolaire
                </label>
                <input
                  type="text"
                  value={besoinExistant.niveauScolaireLibelle}
                  readOnly
                  className="w-full px-3 py-2 border border-gray-300 rounded-md bg-gray-100 text-gray-600"
                />
              </div>
            )}
          </div>

          {/* Dates et utilisateurs (affiché seulement en mode view/edit) */}
          {besoinExistant && (
            <div className="mt-4 pt-4 border-t border-gray-200">
              <h5 className="text-sm font-semibold text-gray-700 mb-3">Historique</h5>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                {besoinExistant.dateSaisie && (
                  <div>
                    <span className="font-medium text-gray-700">Saisi le:</span>
                    <span className="ml-2 text-gray-900">
                      {new Date(besoinExistant.dateSaisie).toLocaleDateString('fr-FR')}
                      {besoinExistant.saisiParFirstName && ` par ${besoinExistant.saisiParFirstName} ${besoinExistant.saisiParLastName}`}
                    </span>
                  </div>
                )}
                {besoinExistant.dateValidation && (
                  <div>
                    <span className="font-medium text-gray-700">Validé le:</span>
                    <span className="ml-2 text-gray-900">
                      {new Date(besoinExistant.dateValidation).toLocaleDateString('fr-FR')}
                      {besoinExistant.valideParFirstName && ` par ${besoinExistant.valideParFirstName} ${besoinExistant.valideParLastName}`}
                    </span>
                  </div>
                )}
                {besoinExistant.dateConsolidation && (
                  <div>
                    <span className="font-medium text-gray-700">Consolidé le:</span>
                    <span className="ml-2 text-gray-900">
                      {new Date(besoinExistant.dateConsolidation).toLocaleDateString('fr-FR')}
                      {besoinExistant.consolideParFirstName && ` par ${besoinExistant.consolideParFirstName} ${besoinExistant.consolideParLastName}`}
                    </span>
                  </div>
                )}
                {besoinExistant.dateApprobation && (
                  <div>
                    <span className="font-medium text-gray-700">Approuvé le:</span>
                    <span className="ml-2 text-gray-900">
                      {new Date(besoinExistant.dateApprobation).toLocaleDateString('fr-FR')}
                      {besoinExistant.approuveParFirstName && ` par ${besoinExistant.approuveParFirstName} ${besoinExistant.approuveParLastName}`}
                    </span>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>

        {/* ✅ SUPPRIMÉ : Section "Effectifs Globaux" - Les effectifs sont maintenant saisis par niveau dans "Catalogue Sélectionné" */}

        {/* Sélection de catalogues (comme DistributionForm) */}
        <div className="bg-white border border-gray-200 p-6 rounded-xl shadow-sm">
          <h4 className="text-lg font-semibold text-gray-900 mb-6 flex items-center gap-2">
            <CalculatorIcon className="h-5 w-5 text-orange-600" />
            Catalogues et Matières
          </h4>
          
          {!formData.anneeScolaireId && (
            <div className="mb-4 p-3 bg-yellow-50 border border-yellow-200 rounded-md">
              <p className="text-sm text-yellow-800">
                ⚠️ Veuillez d'abord sélectionner une année scolaire pour charger les catalogues disponibles
              </p>
            </div>
          )}

          {/* Sticky section pour la sélection de catalogue (masquée en mode view) */}
          {mode !== 'view' && (
          <div className="sticky top-16 bg-white z-10 pb-4 mb-4 border-b border-gray-200">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Choisir un Catalogue
                </label>
                <select
                  value={selectedCatalogueId}
                  onChange={(e) => handleCatalogueSelect(e.target.value)}
                  className={`w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-gray-500 ${
                    error ? 'border-red-300' : 'border-gray-300'
                  }`}
                  disabled={loadingCatalogues || !formData.anneeScolaireId}
                >
                  <option value="">-- Sélectionner un catalogue --</option>
                  {availableCataloguesForSelect.map((catalogue) => (
                    <option key={catalogue.id} value={catalogue.id}>
                      {catalogue.icone} {catalogue.niveauScolaire} - {catalogue.code}
                    </option>
                  ))}
                </select>
                
                {error && (
                  <div className="mt-2 text-sm text-red-600 flex items-center">
                    <svg className="w-4 h-4 mr-1" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
                    </svg>
                    {error}
                  </div>
                )}
              </div>
              <div className="flex items-end">
                <button
                  type="button"
                  onClick={addCatalogueToTable}
                  disabled={!selectedCatalogueId || !currentCatalogueData}
                  className="w-full px-6 py-3 bg-orange-600 text-white rounded-lg hover:bg-orange-700 disabled:bg-gray-400 disabled:cursor-not-allowed font-medium shadow-sm hover:shadow-md transition-all duration-200"
                >
                  ➕ Ajouter au Tableau
                </button>
              </div>
            </div>
          </div>
          )}

          {/* Affichage du catalogue sélectionné avec saisie des quantités (comme DistributionForm) */}
          {mode !== 'view' && currentCatalogueData && (
            <div className="bg-gradient-to-br from-orange-50 to-white p-6 rounded-xl border-2 border-orange-200 mb-6 shadow-md">
              <h5 className="font-semibold text-gray-900 mb-4 text-lg flex items-center gap-2">
                <span className="text-orange-600">📚</span>
                Catalogue Sélectionné: {currentCatalogueData.niveauScolaire}
              </h5>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm mb-4">
                <div>
                  <span className="font-medium text-gray-700">Code:</span>
                  <span className="ml-2 text-gray-900">{currentCatalogueData.code}</span>
                </div>
                <div>
                  <span className="font-medium text-gray-700">Année:</span>
                  <span className="ml-2 text-gray-900">{currentCatalogueData.anneeScolaire}</span>
                </div>
                <div>
                  <span className="font-medium text-gray-700">Matières:</span>
                  <span className="ml-2 text-gray-900">{catalogueMatieres.length}</span>
                </div>
              </div>

              {/* ✅ NOUVEAU : Section Effectifs pour ce niveau (avant les matières) */}
              <div className="mb-6 p-4 bg-gradient-to-r from-orange-50 to-orange-100 border-2 border-orange-300 rounded-xl shadow-sm">
                <h6 className="text-sm font-semibold text-gray-900 mb-4 flex items-center gap-2">
                  <span className="text-orange-700">👥</span>
                  Effectifs pour {currentCatalogueData.niveauScolaire} *
                </h6>
                <div className="grid grid-cols-1 md:grid-cols-1 gap-3">
                  <div className="md:max-w-sm">
                    <label className="block text-xs font-medium text-gray-700 mb-1">
                      Effectif Total *
                    </label>
                    <input
                      type="number"
                      min="0"
                      value={currentCatalogueEffectifs.effectifTotal}
                      onChange={(e) => handleUpdateCurrentCatalogueEffectifs(parseInt(e.target.value) || 0)}
                      className="w-full px-3 py-2 text-sm border-2 border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-orange-500 transition-all"
                      required
                      disabled={(mode as 'create' | 'edit' | 'view') === 'view'}
                    />
                  </div>
                </div>
              </div>

              {/* Matières avec champs de saisie de quantité (comme DistributionForm) */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <h6 className="font-medium text-gray-900">Saisir les quantités (Besoin Brut):</h6>
                </div>
                
                {catalogueMatieres.length === 0 ? (
                  <div className="text-center py-4 text-gray-500">
                    Aucune matière trouvée pour ce catalogue
                  </div>
                ) : (
                  catalogueMatieres.map((matiere: any) => {
                    const matiereData = formData.manuels.find((m: any) => m.matiereId === matiere.id && m.catalogueId === currentCatalogueData.id);
                    const quantiteBrute = matiereData?.quantiteBrute || 0;
                    const retoursN1 = matiereData?.quantiteRetourAnneePrecedente || 0;
                    const quantiteNet = matiereData?.quantiteNet || 0;
                    const isLoading = loadingRetours[matiere.id];
                    
                    return (
                      <div key={matiere.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div className="flex-1">
                          <div className="font-medium text-gray-900">{matiere.libelle}</div>
                          <div className="text-sm text-gray-600">
                            Code: {matiere.code}
                            {quantiteBrute > 0 && (
                              <>
                                <span className="ml-2 text-blue-600">{`| Récup. ${retourAnneeReferenceCode}: ${retoursN1}`}</span>
                                <span className="ml-2 text-green-600">| Besoin Net: {quantiteNet}</span>
                              </>
                            )}
                            {isLoading && (
                              <span className="ml-2 text-gray-500">⏳ Chargement des récupérations...</span>
                            )}
                          </div>
                        </div>
                        <div className="ml-4">
                          <input
                            type="number"
                            value={quantiteBrute}
                            onChange={(e) => {
                              const newQuantite = parseInt(e.target.value) || 0;
                              handleUpdateQuantiteBrute(matiere.id, newQuantite);
                            }}
                            className="w-28 px-4 py-2.5 text-center border-2 border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-orange-500 transition-all font-medium"
                            min="0"
                            placeholder="0"
                          />
                        </div>
                      </div>
                    );
                  })
                )}
              </div>
            </div>
          )}

          {/* Tableau des catalogues sélectionnés (comme DistributionForm) */}
          {formData.selectedCatalogues.length > 0 && (
            <div className="mt-6">
              <div className="flex items-center justify-between mb-3">
                <h5 className="font-semibold text-gray-900">
                  Catalogues Sélectionnés ({formData.selectedCatalogues.length})
                </h5>
                <button
                  type="button"
                  onClick={handleRecalculateRetours}
                  disabled={!formData.anneeScolaireId}
                  className="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 disabled:bg-gray-400 disabled:cursor-not-allowed text-sm"
                  title={`Recalculer les récupérations ${retourAnneeReferenceCode}`}
                >
                  🔄 Recalculer les récupérations
                </button>
              </div>
              <div className="space-y-6">
                {formData.selectedCatalogues.map((catalogue, idx) => (
                  <div key={catalogue.id} className="bg-white border-2 border-orange-200 rounded-xl p-6 shadow-md hover:shadow-lg transition-shadow duration-200 relative overflow-hidden">
                    <div className="absolute top-0 left-0 w-1 h-full bg-orange-500 opacity-60" aria-hidden />
                    <div className="flex items-center justify-between mb-5 pb-4 border-b-2 border-orange-200">
                      <h6 className="text-lg font-semibold text-gray-900 flex items-center gap-3">
                        <span className="text-2xl">{catalogue.icone}</span>
                        <span>
                          <span className="block text-orange-700 font-bold">{catalogue.niveauScolaire}</span>
                          <span className="text-sm font-normal text-gray-600">{catalogue.libelle} - {catalogue.niveauCode}</span>
                        </span>
                        <span className="px-2 py-0.5 bg-orange-100 text-orange-800 text-xs font-medium rounded">Niveau {idx + 1}</span>
                      </h6>
                      {mode !== 'view' && (
                      <button
                        type="button"
                        onClick={() => removeCatalogueFromTable(catalogue.id)}
                        className="text-red-600 hover:text-red-800 p-2 hover:bg-red-50 rounded-lg transition-colors"
                        title="Retirer ce catalogue"
                      >
                        <TrashIcon className="h-5 w-5" />
                      </button>
                      )}
                    </div>

                    {/* Section Effectifs spécifiques à CE niveau */}
                    <div className="mb-6 p-4 bg-gradient-to-r from-orange-50 to-orange-100 border-2 border-orange-300 rounded-xl shadow-sm">
                      <h6 className="text-sm font-semibold text-gray-900 mb-4 flex items-center gap-2">
                        <span className="text-orange-700">👥</span>
                        Effectifs pour <strong className="text-orange-800">{catalogue.niveauScolaire}</strong> uniquement
                      </h6>
                      <div className="grid grid-cols-1 md:grid-cols-1 gap-3">
                        <div className="md:max-w-sm">
                          <label className="block text-xs font-medium text-gray-700 mb-1">
                            Effectif Total *
                          </label>
                          <input
                            type="number"
                            min="0"
                            value={catalogue.effectifTotal || 0}
                            onChange={(e) => handleUpdateCatalogueEffectifs(catalogue.id, parseInt(e.target.value) || 0)}
                            className="w-full px-3 py-2 text-sm border-2 border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-orange-500 transition-all"
                            required
                            disabled={(mode as 'create' | 'edit' | 'view') === 'view'}
                          />
                        </div>
                      </div>
                    </div>

                    {/* Tableau des matières de ce niveau */}
                    {catalogue.quantitesSaisies.length > 0 && (
                      <div className="overflow-x-auto">
                        <table className="min-w-full bg-white border border-gray-200">
                          <thead className="bg-orange-50">
                            <tr>
                              <th className="px-4 py-2 text-left text-xs font-medium text-orange-800 uppercase">Matière ({catalogue.niveauScolaire})</th>
                              <th className="px-4 py-2 text-left text-xs font-medium text-orange-800 uppercase">Besoin Brut</th>
                              <th className="px-4 py-2 text-left text-xs font-medium text-orange-800 uppercase">{`Récup. ${retourAnneeReferenceCode}`}</th>
                              <th className="px-4 py-2 text-left text-xs font-medium text-orange-800 uppercase">Besoin Net</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-gray-200">
                            {catalogue.quantitesSaisies.map((matiere) => (
                              <tr key={matiere.matiereId}>
                                <td className="px-4 py-2">
                                  <div>
                                    <div className="font-medium text-gray-900">{matiere.matiereLibelle}</div>
                                    <div className="text-sm text-gray-500">{matiere.matiereCode}</div>
                                  </div>
                                </td>
                                <td className="px-4 py-2">
                                    <input
                                      type="number"
                                      min="0"
                                      value={matiere.quantiteBrute}
                                      onChange={(e) => {
                                        const quantite = parseInt(e.target.value) || 0;
                                        handleUpdateQuantiteInTable(catalogue.id, matiere.matiereId, quantite);
                                      }}
                                      className="w-28 px-4 py-2 border-2 border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-orange-500 transition-all font-medium"
                                    />
                                </td>
                                <td className="px-4 py-2">
                                  <div className="flex items-center gap-2">
                                    <span className="text-gray-700">{matiere.quantiteRetourAnneePrecedente}</span>
                                    {loadingRetours[matiere.matiereId] && (
                                      <span className="text-xs text-gray-500">⏳</span>
                                    )}
                                  </div>
                                </td>
                                <td className="px-4 py-2">
                                  <span className="font-semibold text-blue-600">{matiere.quantiteNet}</span>
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Commentaire */}
        <div className="bg-white border border-gray-200 p-6 rounded-xl shadow-sm">
          <label className="block text-sm font-medium text-gray-700 mb-3 flex items-center gap-2">
            <span className="text-orange-600">💬</span>
            Commentaire
          </label>
          <textarea
            value={formData.commentaire}
            onChange={(e) => setFormData(prev => ({ ...prev, commentaire: e.target.value }))}
            rows={4}
            className="w-full px-4 py-3 border-2 border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-orange-500 transition-all resize-none"
            placeholder="Observations ou commentaires sur ce besoin..."
            disabled={(mode as 'create' | 'edit' | 'view') === 'view'}
          />
        </div>

        {/* Actions */}
        <div className="flex justify-end gap-4 pt-6 pb-8 mb-4 border-t border-gray-200 bg-white sticky bottom-0">
          <button
            type="button"
            onClick={onCancel}
            className="px-6 py-3 border-2 border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 hover:border-gray-400 font-medium transition-all duration-200 shadow-sm hover:shadow-md"
            disabled={loading}
          >
            Annuler
          </button>
          {mode !== 'view' && (
            <button
              type="submit"
              className="px-8 py-3 bg-orange-600 text-white rounded-lg hover:bg-orange-700 disabled:bg-gray-400 disabled:cursor-not-allowed font-medium shadow-md hover:shadow-lg transition-all duration-200 flex items-center gap-2"
              disabled={loading}
            >
              {loading ? (
                <>
                  <svg className="animate-spin h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                  Enregistrement...
                </>
              ) : besoinExistant ? (
                '✏️ Modifier'
              ) : (
                '✅ Créer le Besoin'
              )}
            </button>
          )}
        </div>
      </form>
    </div>
  );
}
