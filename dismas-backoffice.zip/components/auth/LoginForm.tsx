/**
 * Composant de formulaire de connexion simplifié
 * Compatible avec l'API backend et le fallback mock
 */

"use client"

import React, { useState } from "react"
import { useAuth } from "../../app/providers"
import { useRouter } from "next/navigation"
import toast from "react-hot-toast"

interface LoginFormProps {
  className?: string;
}

export default function LoginForm({ className = "" }: LoginFormProps) {
  const [credentials, setCredentials] = useState({ login: "", password: "" })
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [errorMessage, setErrorMessage] = useState<string>("")
  
  const { login } = useAuth()
  const router = useRouter()

  // Méthode de connexion
  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setErrorMessage("") // Reset error message

    if (!credentials.login || !credentials.password) {
      toast.error("Veuillez remplir tous les champs")
      return
    }

    setIsSubmitting(true)

    try {
      const result = await login(credentials)
      if (result.success) {
        if (result.mustChangePassword) {
          const msg = "Première connexion détectée : veuillez changer votre mot de passe par défaut."
          setErrorMessage("")
          toast.success(msg)
          if (typeof window !== "undefined") {
            localStorage.setItem("first_login_transition_pending", "true")
          }
          router.push("/auth/first-login-transition")
        } else {
          toast.success("Connexion réussie !")
          router.push("/dashboard")
        }
      } else {
        // Afficher l'erreur retournée par le contexte d'authentification
        const errorMsg = result.error || "Identifiants incorrects"
        setErrorMessage(errorMsg)
        toast.error(errorMsg)
      }
    } catch (error: any) {
      console.error('Login error:', error)
      
      // Gérer les différents types d'erreurs
      let errorMessage = "Erreur de connexion"
      
      if (error?.code === 'SERVER_UNAVAILABLE') {
        errorMessage = "Serveur indisponible. Veuillez vérifier votre connexion et réessayer."
      } else if (error?.code === 'NETWORK_ERROR') {
        errorMessage = "Erreur de réseau. Vérifiez votre connexion internet."
      } else if (error?.message) {
        errorMessage = error.message
      }
      
      setErrorMessage(errorMessage)
      toast.error(errorMessage)
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <div className={`space-y-6 ${className}`}>
      {errorMessage && (
        <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-md">
          <div className="flex">
            <div className="flex-shrink-0">
              {errorMessage.includes('Serveur indisponible') ? (
                // Icône serveur pour les erreurs de serveur
                <svg className="h-5 w-5 text-red-400" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M2 5a2 2 0 012-2h12a2 2 0 012 2v2a2 2 0 01-2 2H4a2 2 0 01-2-2V5zm14 1a1 1 0 11-2 0 1 1 0 012 0zM2 13a2 2 0 012-2h12a2 2 0 012 2v2a2 2 0 01-2 2H4a2 2 0 01-2-2v-2zm14 1a1 1 0 11-2 0 1 1 0 012 0z" clipRule="evenodd" />
                </svg>
              ) : (
                // Icône d'erreur générale
                <svg className="h-5 w-5 text-red-400" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
                </svg>
              )}
            </div>
            <div className="ml-3">
              <p className="text-sm font-medium">{errorMessage}</p>
              {errorMessage.includes('Serveur indisponible') && (
                <p className="text-xs text-red-600 mt-1">
                  Vérifiez que le serveur backend est démarré et accessible.
                </p>
              )}
            </div>
          </div>
        </div>
      )}
      
      <form onSubmit={handleLogin} className="space-y-6">
        <div>
          <label htmlFor="login" className="form-label">
            Nom d'utilisateur
          </label>
          <input
            id="login"
            name="login"
            type="text"
            required
            className="input-field"
            placeholder="Entrez votre nom d'utilisateur"
            value={credentials.login}
            onChange={(e) => setCredentials({ ...credentials, login: e.target.value })}
          />
        </div>

        <div>
          <label htmlFor="password" className="form-label">
            Mot de passe
          </label>
          <input
            id="password"
            name="password"
            type="password"
            required
            className="input-field"
            placeholder="Entrez votre mot de passe"
            value={credentials.password}
            onChange={(e) => setCredentials({ ...credentials, password: e.target.value })}
          />
        </div>

        <div>
          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full btn-primary flex items-center justify-center"
          >
            {isSubmitting ? (
              <>
                <div className="spinner mr-2"></div>
                Connexion...
              </>
            ) : (
              "Se connecter"
            )}
          </button>
        </div>
        <div className="text-center">
          <button
            type="button"
            onClick={() => router.push("/auth/forgot-password")}
            className="text-sm text-orange-600 hover:text-orange-700 hover:underline"
          >
            Mot de passe oublié ?
          </button>
        </div>
      </form>
    </div>
  )
}