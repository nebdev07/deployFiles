/**
 * Régression profils : accès Réceptions / Distribution (menu) et règles de chargement / filtre.
 */
import test from "node:test"
import assert from "node:assert/strict"
import { hasReceptionSyntheseTerritoriale } from "../lib/reception-flow.ts"
import {
  canAccessReceptionsModule,
  filterReceptionsListForRole,
  shouldFetchReceptionsOnUserReady,
} from "../lib/reception-profile-access.ts"
import { canAccessDistributionFromMenu } from "../lib/distribution-profile-access.ts"
import { groupDistributionsByIeppThenEpp } from "../lib/distribution-synthese-grouping.ts"

const PROFILES_RECEPTIONS_OK = ["ADMIN", "DAF", "DRENA", "IEPP", "DIRECTEUR", "CABINET"]
const PROFILES_RECEPTIONS_DENY = ["MAITRE", "COGES", "DPFC", ""]

test("Réceptions : profils autorisés (menu + garde page)", () => {
  for (const code of PROFILES_RECEPTIONS_OK) {
    assert.equal(canAccessReceptionsModule(code), true, `expected OK for ${code}`)
  }
})

test("Réceptions : profils refusés", () => {
  for (const code of PROFILES_RECEPTIONS_DENY) {
    assert.equal(canAccessReceptionsModule(code || undefined), false, `expected deny for ${code || "undefined"}`)
  }
  assert.equal(canAccessReceptionsModule(undefined), false)
})

test("Distribution (menu) : MAITRE autorisé ; COGES non listé", () => {
  assert.equal(canAccessDistributionFromMenu("MAITRE"), true)
  assert.equal(canAccessDistributionFromMenu("DRENA"), true)
  assert.equal(canAccessDistributionFromMenu("COGES"), false)
})

test("shouldFetchReceptionsOnUserReady : DRENA/DAF/CABINET sans structure", () => {
  assert.equal(shouldFetchReceptionsOnUserReady("DRENA", undefined), true)
  assert.equal(shouldFetchReceptionsOnUserReady("DAF", undefined), true)
  assert.equal(shouldFetchReceptionsOnUserReady("CABINET", undefined), true)
})

test("alignement : shouldFetch (sans structure) coïncide avec hasReceptionSyntheseTerritoriale", () => {
  const codes = ["DRENA", "DAF", "CABINET", "IEPP", "ADMIN", "DIRECTEUR"]
  for (const code of codes) {
    const syn = hasReceptionSyntheseTerritoriale(code)
    const fetchNoStruct = shouldFetchReceptionsOnUserReady(code, undefined)
    assert.equal(
      fetchNoStruct,
      syn,
      `role ${code}: fetch sans structure doit suivre synthèse territoriale`
    )
  }
})

test("shouldFetchReceptionsOnUserReady : IEPP / ADMIN avec structure", () => {
  assert.equal(shouldFetchReceptionsOnUserReady("IEPP", 12), true)
  assert.equal(shouldFetchReceptionsOnUserReady("ADMIN", 1), true)
})

test("shouldFetchReceptionsOnUserReady : IEPP sans structure → false", () => {
  assert.equal(shouldFetchReceptionsOnUserReady("IEPP", undefined), false)
  assert.equal(shouldFetchReceptionsOnUserReady("IEPP", 0), false)
})

test("filterReceptionsListForRole : DIRECTEUR → type EPP seulement", () => {
  const rows = [
    { id: 1, type: "EPP" },
    { id: 2, type: "IEPP" },
  ]
  const out = filterReceptionsListForRole("DIRECTEUR", rows)
  assert.equal(out.length, 1)
  assert.equal(out[0].id, 1)
})

test("filterReceptionsListForRole : DRENA / IEPP → pas de filtre type", () => {
  const rows = [
    { id: 1, type: "EPP" },
    { id: 2, type: "IEPP" },
  ]
  assert.equal(filterReceptionsListForRole("DRENA", rows).length, 2)
  assert.equal(filterReceptionsListForRole("IEPP", rows).length, 2)
})

test("groupDistributionsByIeppThenEpp : regroupe par IEPP puis EPP", () => {
  const dist = [
    {
      id: 10,
      structureId: 100,
      structureParentId: 50,
      structureLibelle: "EPP A",
      classe: "CM1",
    },
    {
      id: 11,
      structureId: 101,
      structureParentId: 50,
      structureLibelle: "EPP B",
      classe: "CM2",
    },
  ]
  const groups = groupDistributionsByIeppThenEpp(dist, { 50: "IEPP Test" })
  assert.equal(groups.length, 1)
  assert.equal(groups[0].ieppId, 50)
  assert.equal(groups[0].ieppLabel, "IEPP Test")
  assert.equal(groups[0].epps.size, 2)
})
