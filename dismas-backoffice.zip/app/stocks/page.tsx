"use client"

import { logger } from '@/lib/utils/logger'

import { useState, useEffect, useCallback, useMemo } from "react"
import MainLayout from "../../components/layout/main-layout"
import { useAuth } from "../providers"
import { stockService, StockByStructure, StockData, MouvementStockData } from "../../lib/services/stock.service"
import { rapportService, downloadRapportFile } from "@/lib/services/rapport.service"
import { structuresService, type Iepp, type Epp } from "@/lib/services/structures.service"
import { regulationService, type StructureDeficitItem, type StructureExcedentItem, isRegulationMultiLevelEnabled } from "@/lib/services/regulation.service"
import { dashboardService } from "@/lib/services/dashboard.service"
import { useMatieres } from "@/hooks/use-matieres"
import { useStructures } from "@/hooks/use-structures"
import { useAnneesScolaires } from "@/hooks/use-annees-scolaires"
import { useConsultationOnly } from "@/hooks/use-consultation-only"
import toast from "react-hot-toast"
import {
  CubeIcon,
  PlusIcon,
  ArrowUpTrayIcon,
  ExclamationTriangleIcon,
  DocumentTextIcon,
  TruckIcon,
  BuildingOfficeIcon,
  CalendarDaysIcon,
} from "@heroicons/react/24/outline"

/**
 * PK `structure_administrative` pour les endpoints stock (hors agrégat DRENA).
 * `structure.id` peut être un id métier (ex. DRENA) — voir `convertUserToLegacyUser` / `buildLegacyMainStructure`.
 */
function getStructureAdministrativePk(user: {
  structureAdministrativeId?: number
  structure?: { id?: number }
} | null): number | undefined {
  if (!user) return undefined
  if (typeof user.structureAdministrativeId === "number" && user.structureAdministrativeId > 0) {
    return user.structureAdministrativeId
  }
  const sid = user.structure?.id
  if (typeof sid === "number" && sid > 0) return sid
  return undefined
}

export default function StocksPage() {
  const { user } = useAuth()
  const { consultationOnly } = useConsultationOnly()
  const { matieres, loading: matieresLoading } = useMatieres()
  const { epps, iepps, loadEpps, loadIepps, loading: structuresLoading } = useStructures()
  const { anneesScolaires, getAnneesScolaires, loading: anneesLoading } = useAnneesScolaires()

  /**
   * Id pour GET `/stock/structure/...` et mouvements.
   * - DRENA : id circonscription (agrégat `/stock/drena/...`).
   * - DAF / ADMIN rattachés au MENA (structure ≠ type DAF) : 1er entrepôt DAF national,
   *   comme le crédit stock des commandes (`structureDaf` / `firstStructureDafNationale` côté API).
   * - Sinon : PK session (`structureAdministrativeId`).
   */
  const [stockApiStructureId, setStockApiStructureId] = useState<number | null>(null)

  useEffect(() => {
    let cancelled = false
    async function resolveStockStructureId() {
      if (!user) {
        setStockApiStructureId(null)
        return
      }
      const rc = (user.role?.code ?? "").toUpperCase()
      if (rc === "DRENA") {
        const id = user.structure?.id
        setStockApiStructureId(typeof id === "number" && id > 0 ? id : null)
        return
      }
      const typ = (user.structure?.type ?? "").toUpperCase()
      if ((rc === "DAF" || rc === "ADMIN" || rc === "CABINET") && typ !== "DAF") {
        try {
          const r = await structuresService.getAdministrativeStructuresByType("DAF")
          if (cancelled) return
          const items = r.items as Array<{ id: number }> | undefined
          const firstId = Array.isArray(items) && items.length > 0 ? items[0]?.id : undefined
          if (typeof firstId === "number" && firstId > 0) {
            setStockApiStructureId(firstId)
            return
          }
        } catch (e) {
          logger.warn("Résolution entrepôt DAF (getByType DAF) — repli PK session", e)
          if (cancelled) return
        }
      }
      if (cancelled) return
      setStockApiStructureId(getStructureAdministrativePk(user) ?? null)
    }
    void resolveStockStructureId()
    return () => {
      cancelled = true
    }
  }, [user])

  const [selectedView, setSelectedView] = useState("overview")
  const [showModal, setShowModal] = useState(false)
  const [selectedStock, setSelectedStock] = useState<any>(null)
  const [showMouvementModal, setShowMouvementModal] = useState(false)
  const [showRapportModal, setShowRapportModal] = useState(false)
  const [rapportGenerating, setRapportGenerating] = useState(false)

  /** Année scolaire sélectionnée (obligatoire pour l'appel /stock/structure/.../annee/...) */
  const [anneeScolaireId, setAnneeScolaireId] = useState<number | null>(null)

  // États pour les données réelles
  const [stockData, setStockData] = useState<StockByStructure | null>(null)
  const [allStocks, setAllStocks] = useState<StockData[]>([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  /** Mouvements de stock (onglet Mouvements) */
  const [mouvements, setMouvements] = useState<MouvementStockData[]>([])
  const [loadingMouvements, setLoadingMouvements] = useState(false)

  /** Déficit / excédent (structure connectée) */
  const [structureDeficits, setStructureDeficits] = useState<StructureDeficitItem[]>([])
  const [structureExcedents, setStructureExcedents] = useState<StructureExcedentItem[]>([])
  const [loadingStructureGaps, setLoadingStructureGaps] = useState(false)

  /** Stocks IEPP : liste des IEPP (sans stock), cache stock par structure, chargement par page */
  const [ieppList, setIeppList] = useState<Iepp[]>([])
  const [ieppStocksCache, setIeppStocksCache] = useState<Record<number, { structure: StockByStructure; allStocks: StockData[] }>>({})
  const [loadingIeppList, setLoadingIeppList] = useState(false)
  const [loadingIeppPage, setLoadingIeppPage] = useState(false)

  /** Stocks EPP : liste des EPP (sans stock), cache stock par structure, chargement par page */
  const [eppList, setEppList] = useState<Array<{ epp: Epp; ieppLibelle?: string }>>([])
  const [eppStocksCache, setEppStocksCache] = useState<Record<number, { structure: StockByStructure; allStocks: StockData[] }>>({})
  const [loadingEppList, setLoadingEppList] = useState(false)
  const [loadingEppPage, setLoadingEppPage] = useState(false)
  const [drenaIeppAggregatedLoaded, setDrenaIeppAggregatedLoaded] = useState(false)
  const [drenaEppAggregatedLoaded, setDrenaEppAggregatedLoaded] = useState(false)

  /** Lecture seule : DAF/ADMIN = arbre DRENA → IEPP → EPP ; DRENA = IEPP → EPP sous sa circonscription */
  const [terrDrenaId, setTerrDrenaId] = useState<number | null>(null)
  const [terrIeppId, setTerrIeppId] = useState<number | null>(null)
  const [terrRoEppId, setTerrRoEppId] = useState<number | null>(null)
  const [terrDrenaStocks, setTerrDrenaStocks] = useState<StockData[] | null>(null)
  const [terrIeppStocks, setTerrIeppStocks] = useState<StockData[] | null>(null)
  const [terrRoEppStocks, setTerrRoEppStocks] = useState<StockData[] | null>(null)
  const [terrDrenaList, setTerrDrenaList] = useState<Array<{ id: number; code: string; libelle: string }>>([])
  const [terrIeppList, setTerrIeppList] = useState<Array<{ ieppId: number; ieppCode: string; ieppLibelle: string }>>([])
  const [terrRoEppList, setTerrRoEppList] = useState<Array<{ eppId: number; code?: string; libelle?: string }>>([])
  const [loadingTerr, setLoadingTerr] = useState(false)

  /** Filtres et pagination par onglet */
  const [filterIepp, setFilterIepp] = useState("")
  const [filterEpp, setFilterEpp] = useState("")
  const [filterMouvements, setFilterMouvements] = useState("")
  const [pageIepp, setPageIepp] = useState(1)
  const [pageEpp, setPageEpp] = useState(1)
  const [pageMouvements, setPageMouvements] = useState(1)
  const PAGE_SIZE_STRUCTURES = 5
  const PAGE_SIZE_MOUVEMENTS = 10

  // Charger les années scolaires au montage
  useEffect(() => {
    if (user) {
      getAnneesScolaires()
    }
  }, [user, getAnneesScolaires])

  // Définir l'année courante par défaut une fois les années chargées
  useEffect(() => {
    if (anneesScolaires.length > 0 && anneeScolaireId === null) {
      const courante = anneesScolaires.find((a) => a.estCourante)
      setAnneeScolaireId(courante?.id ?? anneesScolaires[0]?.id ?? null)
    }
  }, [anneesScolaires, anneeScolaireId])

  // Charger EPP/IEPP au montage
  useEffect(() => {
    if (user) {
      loadEpps()
      loadIepps()
    }
  }, [user])

  /**
   * Charge les données de stock depuis le backend (GET /stock/structure/.../annee/...)
   */
  const loadStockData = useCallback(async () => {
    if (stockApiStructureId == null || anneeScolaireId == null) return

    setLoading(true)
    setError(null)

    try {
      const roleCode = user?.role?.code ?? ""
      logger.log(`📊 Chargement stock (${roleCode}) structure ${stockApiStructureId} année ${anneeScolaireId}`)
      const response = roleCode === "DRENA"
        ? await stockService.getStocksForDrenaPage(stockApiStructureId, anneeScolaireId)
        : await stockService.getStocksForPage(stockApiStructureId, anneeScolaireId)

      if (response.success && response.data) {
        setStockData(response.data.structure)
        setAllStocks(response.data.allStocks)
        logger.log('✅ Stock chargé avec succès')
      } else {
        setError(response.message)
        toast.error(response.message)
      }
    } catch (err: any) {
      logger.error('❌ Erreur lors du chargement du stock:', err)
      setError(err?.message ?? 'Erreur lors du chargement du stock')
      toast.error('Erreur lors du chargement du stock')
    } finally {
      setLoading(false)
    }
  }, [stockApiStructureId, anneeScolaireId, user?.role?.code])

  // Charger le stock quand structure + année sont prêts
  useEffect(() => {
    if (stockApiStructureId != null && anneeScolaireId != null) {
      loadStockData()
    }
  }, [stockApiStructureId, anneeScolaireId, loadStockData])

  const loadStructureGaps = useCallback(async () => {
    const sid = getStructureAdministrativePk(user) ?? user?.structure?.id
    if (!sid || anneeScolaireId == null) return
    const role = user?.role?.code ?? ""
    // Les gaps (déficit/excédent) concernent principalement les EPP (DIRECTEUR)
    if (role !== "DIRECTEUR") {
      setStructureDeficits([])
      setStructureExcedents([])
      return
    }
    setLoadingStructureGaps(true)
    try {
      const [defRes, excRes] = await Promise.all([
        regulationService.getStructureDeficits(sid, anneeScolaireId),
        regulationService.getStructureExcedents(sid, anneeScolaireId),
      ])
      setStructureDeficits(Array.isArray(defRes.items) ? (defRes.items as StructureDeficitItem[]) : [])
      setStructureExcedents(Array.isArray(excRes.items) ? (excRes.items as StructureExcedentItem[]) : [])
    } catch (e) {
      setStructureDeficits([])
      setStructureExcedents([])
    } finally {
      setLoadingStructureGaps(false)
    }
  }, [user, anneeScolaireId])

  useEffect(() => {
    const sid = getStructureAdministrativePk(user) ?? user?.structure?.id
    if (sid && anneeScolaireId != null) {
      loadStructureGaps()
    }
  }, [user, anneeScolaireId, loadStructureGaps])

  useEffect(() => {
    if (!user || !isRegulationMultiLevelEnabled()) return
    const rc = user.role?.code ?? ""
    if (rc === "DRENA" && user.structure?.id) {
      setTerrDrenaId(user.structure.id)
      return
    }
    if (rc !== "DAF" && rc !== "ADMIN") return
    let cancelled = false
    dashboardService
      .listNationalDrenas()
      .then((r) => {
        if (cancelled) return
        const raw = r.items as unknown
        const list = Array.isArray(raw) ? raw : raw != null ? [raw] : []
        setTerrDrenaList(list as Array<{ id: number; code: string; libelle: string }>)
      })
      .catch(() => {
        if (!cancelled) setTerrDrenaList([])
      })
    return () => {
      cancelled = true
    }
  }, [user])

  useEffect(() => {
    if (terrIeppId == null) {
      setTerrRoEppList([])
      setTerrRoEppId(null)
      setTerrRoEppStocks(null)
      return
    }
    let cancelled = false
    structuresService
      .getEppsByIepp(terrIeppId)
      .then((r) => {
        if (cancelled) return
        const raw = (r.items ?? []) as unknown
        const flat: Epp[] =
          Array.isArray(raw) && raw.length > 0 && Array.isArray((raw as Epp[][])[0])
            ? (raw as Epp[][]).flat()
            : (raw as Epp[])
        setTerrRoEppList(
          flat.map((e) => ({
            eppId: e.id,
            code: e.code,
            libelle: e.libelle,
          })),
        )
      })
      .catch(() => {
        if (!cancelled) setTerrRoEppList([])
      })
    return () => {
      cancelled = true
    }
  }, [terrIeppId])

  useEffect(() => {
    if (terrDrenaId == null || anneeScolaireId == null) {
      setTerrIeppList([])
      return
    }
    let cancelled = false
    dashboardService
      .getDrenaActivites(terrDrenaId, anneeScolaireId)
      .then((r) => {
        if (cancelled) return
        const first = Array.isArray(r.items) ? r.items[0] : r.items
        const iepps = (first as { iepps?: Array<{ ieppId: number; ieppCode: string; ieppLibelle: string }> })?.iepps ?? []
        setTerrIeppList(
          iepps.map((x) => ({
            ieppId: x.ieppId,
            ieppCode: x.ieppCode,
            ieppLibelle: x.ieppLibelle,
          })),
        )
      })
      .catch(() => {
        if (!cancelled) setTerrIeppList([])
      })
    return () => {
      cancelled = true
    }
  }, [terrDrenaId, anneeScolaireId])

  /** Charge les mouvements de stock quand on ouvre l'onglet Mouvements */
  const loadMouvements = useCallback(async () => {
    if (stockApiStructureId == null) return
    setLoadingMouvements(true)
    try {
      const roleCode = user?.role?.code ?? ""
      const res = roleCode === "DRENA"
        ? await stockService.getMouvementsStockForDrena(stockApiStructureId)
        : await stockService.getMouvementsStock(stockApiStructureId)
      if (res.success && res.data) setMouvements(res.data)
      else setMouvements([])
    } catch {
      setMouvements([])
    } finally {
      setLoadingMouvements(false)
    }
  }, [stockApiStructureId, user?.role?.code])

  useEffect(() => {
    if (selectedView === "mouvements" && stockApiStructureId != null) {
      loadMouvements()
    }
  }, [selectedView, stockApiStructureId, loadMouvements])

  /** Charge la liste des stocks par IEPP (DRENA/DAF/ADMIN) pour l’onglet Stocks IEPP */
  /** Charge uniquement la liste des IEPP (DRENA = ses IEPP, DAF/ADMIN = tous). Pas de stock. */
  const loadIeppList = useCallback(async () => {
    const role = user?.role?.code ?? ""
    if (role !== "DRENA" && role !== "DAF" && role !== "ADMIN") return
    setLoadingIeppList(true)
    setIeppList([])
    setIeppStocksCache({})
    try {
      if (role === "DRENA" && user?.structure?.id) {
        const r = await structuresService.getIeppsByDrena(user.structure.id)
        const raw = (r.items ?? []) as unknown
        setIeppList(Array.isArray(raw) && raw.length > 0 && Array.isArray(raw[0]) ? (raw as Iepp[][]).flat() : (raw as Iepp[]))
      } else {
        const r = await structuresService.getIepps({ isActive: true })
        const raw = (r.items ?? []) as unknown
        setIeppList(Array.isArray(raw) && raw.length > 0 && Array.isArray(raw[0]) ? (raw as Iepp[][]).flat() : (raw as Iepp[]))
      }
    } catch (e) {
      logger.error("loadIeppList", e)
      setIeppList([])
    } finally {
      setLoadingIeppList(false)
    }
  }, [user?.structure?.id, user?.role?.code])

  /** Charge la liste des stocks par EPP (IEPP/DRENA/DAF/ADMIN) pour l’onglet Stocks EPP */
  /** Charge uniquement la liste des EPP (IEPP = ses EPP, DRENA = ses EPP via ses IEPP). Pas de stock. */
  const loadEppList = useCallback(async () => {
    const role = user?.role?.code ?? ""
    if (role !== "IEPP" && role !== "DRENA" && role !== "DAF" && role !== "ADMIN") return
    setLoadingEppList(true)
    setEppList([])
    setEppStocksCache({})
    try {
      const toEppList = (raw: unknown): Epp[] =>
        Array.isArray(raw) && raw.length > 0 && Array.isArray(raw[0]) ? (raw as Epp[][]).flat() : (raw as Epp[])

      if (role === "IEPP" && user?.structure?.id) {
        const r = await structuresService.getEppsByIepp(user.structure.id)
        const epps = toEppList(r.items ?? [])
        setEppList(epps.map((epp) => ({ epp })))
      } else if (role === "DRENA" && user?.structure?.id) {
        const rIepp = await structuresService.getIeppsByDrena(user.structure.id)
        const ieppsRaw = (rIepp.items ?? []) as unknown
        const iepps = Array.isArray(ieppsRaw) && ieppsRaw.length > 0 && Array.isArray(ieppsRaw[0]) ? (ieppsRaw as Iepp[][]).flat() : (ieppsRaw as Iepp[])
        const eppLists = await Promise.all(iepps.map((iepp) => structuresService.getEppsByIepp(iepp.id)))
        const flat: Array<{ epp: Epp; ieppLibelle?: string }> = []
        eppLists.forEach((rEpp, i) => {
          const epps = toEppList(rEpp.items ?? [])
          epps.forEach((epp) => flat.push({ epp, ieppLibelle: iepps[i]?.libelle }))
        })
        setEppList(flat)
      } else {
        const rIepp = await structuresService.getIepps({ isActive: true })
        const ieppsRaw = (rIepp.items ?? []) as unknown
        const iepps = Array.isArray(ieppsRaw) && ieppsRaw.length > 0 && Array.isArray(ieppsRaw[0]) ? (ieppsRaw as Iepp[][]).flat() : (ieppsRaw as Iepp[])
        const eppLists = await Promise.all(iepps.map((iepp) => structuresService.getEppsByIepp(iepp.id)))
        const flat: Array<{ epp: Epp; ieppLibelle?: string }> = []
        eppLists.forEach((rEpp, i) => {
          const epps = toEppList(rEpp.items ?? [])
          epps.forEach((epp) => flat.push({ epp, ieppLibelle: iepps[i]?.libelle }))
        })
        setEppList(flat)
      }
    } catch (e) {
      logger.error("loadEppList", e)
      setEppList([])
    } finally {
      setLoadingEppList(false)
    }
  }, [user?.structure?.id, user?.role?.code])

  /** Au clic sur l’onglet, charge uniquement la liste (pas les stocks). */
  useEffect(() => {
    if (selectedView === "iepp" && ["DRENA", "DAF", "ADMIN"].includes(user?.role?.code ?? "")) {
      loadIeppList()
    }
  }, [selectedView, user?.role?.code, loadIeppList])

  useEffect(() => {
    if (selectedView === "epp" && ["IEPP", "DRENA", "DAF", "ADMIN"].includes(user?.role?.code ?? "")) {
      loadEppList()
    }
  }, [selectedView, user?.role?.code, loadEppList])

  /** À chaque changement d’année scolaire, vider le cache des stocks (IEPP/EPP) pour forcer un rechargement. */
  useEffect(() => {
    setIeppStocksCache({})
    setEppStocksCache({})
    setDrenaIeppAggregatedLoaded(false)
    setDrenaEppAggregatedLoaded(false)
  }, [anneeScolaireId])

  /** Charge les stocks uniquement pour les IEPP de la page courante (en parallèle). */
  useEffect(() => {
    if (selectedView !== "iepp" || anneeScolaireId == null) return
    if (user?.role?.code === "DRENA" && user?.structure?.id && !drenaIeppAggregatedLoaded) {
      let cancelled = false
      setLoadingIeppPage(true)
      stockService
        .getStocksForDrenaIeppTab(user.structure.id, anneeScolaireId)
        .then((res) => {
          if (cancelled) return
          if (res.success && res.data) {
            const grouped: Record<number, { structure: StockByStructure; allStocks: StockData[] }> = {}
            const byStructure = new Map<number, StockData[]>()
            res.data.forEach((s) => {
              const arr = byStructure.get(s.structureId) ?? []
              arr.push(s)
              byStructure.set(s.structureId, arr)
            })
            byStructure.forEach((stocks, sid) => {
              grouped[sid] = {
                structure: {
                  structureId: sid,
                  structureLibelle: stocks[0]?.structureLibelle ?? `Structure ${sid}`,
                  structureCode: stocks[0]?.structureCode ?? `STR-${sid}`,
                  stockTotal: stocks.reduce((sum, x) => sum + x.stockDisponible, 0),
                  derniereMiseAJour: "",
                  statutGlobal: stocks.some((x) => x.statut === "EPUISE")
                    ? "EPUISE"
                    : stocks.some((x) => x.statut === "CRITIQUE")
                    ? "CRITIQUE"
                    : "BON",
                  matieres: [],
                },
                allStocks: stocks,
              }
            })
            setIeppStocksCache(grouped)
            setDrenaIeppAggregatedLoaded(true)
          }
        })
        .finally(() => {
          if (!cancelled) setLoadingIeppPage(false)
        })
      return () => {
        cancelled = true
      }
    }
    const q = filterIepp.trim().toLowerCase()
    const filtered = !q ? ieppList : ieppList.filter((iepp) => (iepp.libelle ?? "").toLowerCase().includes(q) || (iepp.code ?? "").toLowerCase().includes(q))
    const start = (pageIepp - 1) * PAGE_SIZE_STRUCTURES
    const pageList = filtered.slice(start, start + PAGE_SIZE_STRUCTURES)
    if (pageList.length === 0) return
    const missing = pageList.filter((iepp) => !ieppStocksCache[iepp.id])
    if (missing.length === 0) return
    let cancelled = false
    setLoadingIeppPage(true)
    Promise.all(missing.map((iepp) => stockService.getStocksForPage(iepp.id, anneeScolaireId)))
      .then((results) => {
        if (cancelled) return
        setIeppStocksCache((prev) => {
          const next = { ...prev }
          missing.forEach((iepp, i) => {
            const res = results[i]
            if (res?.success && res?.data) next[iepp.id] = { structure: res.data!.structure, allStocks: res.data!.allStocks }
          })
          return next
        })
      })
      .catch((e) => logger.error("loadIeppPageStocks", e))
      .finally(() => {
        if (!cancelled) setLoadingIeppPage(false)
      })
    return () => { cancelled = true }
  }, [selectedView, anneeScolaireId, pageIepp, filterIepp, ieppList, user?.role?.code, user?.structure?.id, drenaIeppAggregatedLoaded])

  /** Charge les stocks uniquement pour les EPP de la page courante (en parallèle). */
  useEffect(() => {
    if (selectedView !== "epp" || anneeScolaireId == null) return
    if (user?.role?.code === "DRENA" && user?.structure?.id && !drenaEppAggregatedLoaded) {
      let cancelled = false
      setLoadingEppPage(true)
      stockService
        .getStocksForDrenaEppTab(user.structure.id, anneeScolaireId)
        .then((res) => {
          if (cancelled) return
          if (res.success && res.data) {
            const grouped: Record<number, { structure: StockByStructure; allStocks: StockData[] }> = {}
            const byStructure = new Map<number, StockData[]>()
            res.data.forEach((s) => {
              const arr = byStructure.get(s.structureId) ?? []
              arr.push(s)
              byStructure.set(s.structureId, arr)
            })
            byStructure.forEach((stocks, sid) => {
              grouped[sid] = {
                structure: {
                  structureId: sid,
                  structureLibelle: stocks[0]?.structureLibelle ?? `Structure ${sid}`,
                  structureCode: stocks[0]?.structureCode ?? `STR-${sid}`,
                  stockTotal: stocks.reduce((sum, x) => sum + x.stockDisponible, 0),
                  derniereMiseAJour: "",
                  statutGlobal: stocks.some((x) => x.statut === "EPUISE")
                    ? "EPUISE"
                    : stocks.some((x) => x.statut === "CRITIQUE")
                    ? "CRITIQUE"
                    : "BON",
                  matieres: [],
                },
                allStocks: stocks,
              }
            })
            setEppStocksCache(grouped)
            setDrenaEppAggregatedLoaded(true)
          }
        })
        .finally(() => {
          if (!cancelled) setLoadingEppPage(false)
        })
      return () => {
        cancelled = true
      }
    }
    const q = filterEpp.trim().toLowerCase()
    const filtered = !q ? eppList : eppList.filter(({ epp, ieppLibelle }) => (epp.libelle ?? "").toLowerCase().includes(q) || (epp.code ?? "").toLowerCase().includes(q) || (ieppLibelle ?? "").toLowerCase().includes(q))
    const start = (pageEpp - 1) * PAGE_SIZE_STRUCTURES
    const pageList = filtered.slice(start, start + PAGE_SIZE_STRUCTURES)
    if (pageList.length === 0) return
    const missing = pageList.filter(({ epp }) => !eppStocksCache[epp.id])
    if (missing.length === 0) return
    let cancelled = false
    setLoadingEppPage(true)
    Promise.all(missing.map(({ epp }) => stockService.getStocksForPage(epp.id, anneeScolaireId)))
      .then((results) => {
        if (cancelled) return
        setEppStocksCache((prev) => {
          const next = { ...prev }
          missing.forEach(({ epp }, i) => {
            const res = results[i]
            if (res?.success && res?.data) next[epp.id] = { structure: res.data!.structure, allStocks: res.data!.allStocks }
          })
          return next
        })
      })
      .catch((e) => logger.error("loadEppPageStocks", e))
      .finally(() => {
        if (!cancelled) setLoadingEppPage(false)
      })
    return () => { cancelled = true }
  }, [selectedView, anneeScolaireId, pageEpp, filterEpp, eppList, user?.role?.code, user?.structure?.id, drenaEppAggregatedLoaded])

  /**
   * Actualise les données de stock
   */
  const refreshStockData = () => {
    loadStockData();
  };

  /** Filtrage et pagination — Stocks IEPP (liste des IEPP, sans stock) */
  const filteredIeppList = useMemo(() => {
    const q = filterIepp.trim().toLowerCase()
    if (!q) return ieppList
    return ieppList.filter(
      (iepp) =>
        (iepp.libelle ?? "").toLowerCase().includes(q) || (iepp.code ?? "").toLowerCase().includes(q)
    )
  }, [ieppList, filterIepp])
  const paginatedIeppList = useMemo(() => {
    const start = (pageIepp - 1) * PAGE_SIZE_STRUCTURES
    return filteredIeppList.slice(start, start + PAGE_SIZE_STRUCTURES)
  }, [filteredIeppList, pageIepp])
  const totalPagesIepp = Math.max(1, Math.ceil(filteredIeppList.length / PAGE_SIZE_STRUCTURES))

  /** Filtrage et pagination — Stocks EPP (liste des EPP, sans stock) */
  const filteredEppList = useMemo(() => {
    const q = filterEpp.trim().toLowerCase()
    if (!q) return eppList
    return eppList.filter(
      ({ epp, ieppLibelle }) =>
        (epp.libelle ?? "").toLowerCase().includes(q) ||
        (epp.code ?? "").toLowerCase().includes(q) ||
        (ieppLibelle ?? "").toLowerCase().includes(q)
    )
  }, [eppList, filterEpp])
  const paginatedEppList = useMemo(() => {
    const start = (pageEpp - 1) * PAGE_SIZE_STRUCTURES
    return filteredEppList.slice(start, start + PAGE_SIZE_STRUCTURES)
  }, [filteredEppList, pageEpp])
  const totalPagesEpp = Math.max(1, Math.ceil(filteredEppList.length / PAGE_SIZE_STRUCTURES))

  /** Filtrage et pagination — Mouvements */
  const filteredMouvements = useMemo(() => {
    const q = filterMouvements.trim().toLowerCase()
    if (!q) return mouvements
    return mouvements.filter(
      (m) =>
        (m.typeMouvement ?? "").toLowerCase().includes(q) ||
        (m.matiereLibelle ?? "").toLowerCase().includes(q) ||
        (m.matiereCode ?? "").toLowerCase().includes(q) ||
        (m.dateMouvement ?? "").toLowerCase().includes(q) ||
        (m.structureSource ?? "").toLowerCase().includes(q)
    )
  }, [mouvements, filterMouvements])
  const paginatedMouvements = useMemo(() => {
    const start = (pageMouvements - 1) * PAGE_SIZE_MOUVEMENTS
    return filteredMouvements.slice(start, start + PAGE_SIZE_MOUVEMENTS)
  }, [filteredMouvements, pageMouvements])
  const totalPagesMouvements = Math.max(1, Math.ceil(filteredMouvements.length / PAGE_SIZE_MOUVEMENTS))

  /** Réinitialiser la page quand le filtre ou l’onglet change */
  useEffect(() => {
    setPageIepp(1)
  }, [filterIepp])
  useEffect(() => {
    setPageEpp(1)
  }, [filterEpp])
  useEffect(() => {
    setPageMouvements(1)
  }, [filterMouvements])

  // ✅ CORRECTION: Vérification après tous les hooks
  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <p className="text-gray-600">Chargement...</p>
        </div>
      </div>
    )
  }

  /**
   * Détermine les données de stock selon le rôle de l'utilisateur
   */
  const getStocksByRole = () => {
    // Si on a des données réelles, les utiliser
    if (stockData && allStocks.length > 0) {
      return {
        structure: stockData,
        matieres: allStocks,
        hasRealData: true
      };
    }

    // Sinon, retourner des données vides
    return { hasRealData: false };
  }

  const roleStockData = getStocksByRole()
  const anneeRetourNMoins1Code = (() => {
    const selected = anneesScolaires.find((a: any) => a?.id === anneeScolaireId)
    const code = selected?.code
    if (typeof code === "string") {
      const m = code.match(/^(\d{4})-(\d{4})$/)
      if (m) {
        const start = Number(m[1]) - 1
        const end = Number(m[1])
        return `${start}-${end}`
      }
      return code
    }
    return "N-1"
  })()

  const getStatutBadge = (statut: string) => {
    switch (statut) {
      case "OK":
      case "BON":
        return "badge-success"
      case "CRITIQUE":
        return "badge-error"
      case "MOYEN":
        return "badge-warning"
      default:
        return "badge-info"
    }
  }

  const getTotalStocks = () => {
    if (roleStockData.hasRealData) {
      return allStocks.reduce((sum, stock) => sum + stock.stockDisponible, 0);
    }
    return 0;
  }

  return (
    <MainLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Gestion des Stocks</h1>
            <p className="text-gray-600">Suivi hiérarchique des stocks de manuels scolaires</p>
          </div>
          <div className="flex flex-wrap items-center gap-3 mt-4 sm:mt-0">
            {/* Sélecteur d'année scolaire */}
            <div className="flex items-center gap-2">
              <CalendarDaysIcon className="h-5 w-5 text-gray-500" />
              <select
                value={anneeScolaireId ?? ''}
                onChange={(e) => setAnneeScolaireId(e.target.value ? Number(e.target.value) : null)}
                className="rounded-lg border border-gray-300 px-3 py-2 text-sm focus:border-orange-500 focus:ring-1 focus:ring-orange-500"
                disabled={anneesLoading || anneesScolaires.length === 0}
              >
                <option value="">Sélectionner une année</option>
                {anneesScolaires.map((a) => (
                  <option key={a.id} value={a.id}>
                    {a.libelle ?? a.code ?? `Année ${a.id}`}
                    {a.estCourante ? ' (courante)' : ''}
                  </option>
                ))}
              </select>
            </div>
            <button
              onClick={refreshStockData}
              className="btn-outline"
              disabled={loading || anneeScolaireId == null}
            >
              {loading ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-gray-600 mr-2"></div>
                  Chargement...
                </>
              ) : (
                <>
                  <ArrowUpTrayIcon className="h-5 w-5 mr-2" />
                  Actualiser
                </>
              )}
            </button>
            {!consultationOnly && (
              <button onClick={() => setShowMouvementModal(true)} className="btn-primary">
                <PlusIcon className="h-5 w-5 mr-2" />
                Nouveau Mouvement
              </button>
            )}
            {!consultationOnly && (
              <button onClick={() => setShowRapportModal(true)} className="btn-secondary">
                <DocumentTextIcon className="h-5 w-5 mr-2" />
                Rapport Stock
              </button>
            )}
          </div>
        </div>

        {/* Navigation par onglets */}
        <div className="border-b border-gray-200">
          <nav className="-mb-px flex space-x-8">
            {[
              { id: "overview", name: "Vue d'ensemble", show: true },
              { id: "entrepot", name: "Entrepôt BM", show: user.role.code === "ADMIN" || user.role.code === "DAF" },
              { id: "iepp", name: "Stocks IEPP", show: ["IEPP", "DRENA", "DAF", "ADMIN", "CABINET"].includes(user.role.code) },
              { id: "epp", name: "Stocks EPP", show: ["DIRECTEUR", "IEPP", "DRENA", "DAF", "ADMIN", "CABINET"].includes(user.role.code) },
              { id: "mouvements", name: "Mouvements manuels", show: true },
            ]
              .filter((tab) => tab.show)
              .map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setSelectedView(tab.id)}
                  className={`py-2 px-1 border-b-2 font-medium text-sm ${
                    selectedView === tab.id
                      ? "border-orange-500 text-orange-600"
                      : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
                  }`}
                >
                  {tab.name}
                </button>
              ))}
          </nav>
        </div>

        {/* Vue d'ensemble */}
        {selectedView === "overview" && (
          <div className="space-y-6">
            {/* Données réelles du backend */}
            {roleStockData.hasRealData && (
              <div className="bg-green-50 border border-green-200 rounded-lg p-4 mb-6">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-lg font-semibold text-green-800">Stock en Temps Réel</h3>
                    <p className="text-green-700">
                      Données synchronisées avec le backend • Structure: {stockData?.structureLibelle}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm text-green-600">
                      {allStocks.length} ligne(s) de stock
                    </p>
                    <p className="text-sm text-green-600">
                      Dernière MAJ: {stockData?.derniereMiseAJour || '—'}
                    </p>
                  </div>
                </div>
                
                {allStocks.length > 0 && (
                  <>
                    <div className="mt-4 grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
                      <div
                        className="bg-white p-3 rounded border"
                        title={
                          user.role.code === "DRENA"
                            ? "Somme du stock disponible au niveau IEPP du ressort. Le stock des EPP figure dans l’onglet Stocks EPP."
                            : undefined
                        }
                      >
                        <p className="text-sm text-gray-600">
                          {user.role.code === "DRENA" ? "Stock disponible (IEPP)" : "Stock Disponible"}
                        </p>
                        <p className="text-2xl font-bold text-green-600">
                          {allStocks.reduce((sum, stock) => sum + stock.stockDisponible, 0)}
                        </p>
                      </div>
                      <div className="bg-white p-3 rounded border">
                        <p className="text-sm text-gray-600">Total Réceptions</p>
                        <p className="text-2xl font-bold text-blue-600">
                          {allStocks.reduce((sum, stock) => sum + stock.stockReception, 0)}
                        </p>
                      </div>
                      <div className="bg-white p-3 rounded border">
                        <p className="text-sm text-gray-600">Total Distribué</p>
                        <p className="text-2xl font-bold text-orange-600">
                          {allStocks.reduce((sum, stock) => sum + stock.stockDistribution, 0)}
                        </p>
                      </div>
                      <div className="bg-white p-3 rounded border" title="Mouvements de régulation (IEPP → EPP) : sorties à l’IEPP ou entrées à l’EPP selon votre structure.">
                        <p className="text-sm text-gray-600">Régulation (redistrib.)</p>
                        <p className="text-2xl font-bold text-violet-600">
                          {allStocks.reduce((sum, stock) => sum + stock.stockRedistribution, 0)}
                        </p>
                      </div>
                      <div className="bg-white p-3 rounded border">
                        <p className="text-sm text-gray-600">Matières Critiques</p>
                        <p className="text-2xl font-bold text-yellow-600">
                          {allStocks.filter(s => s.statut === 'CRITIQUE').length}
                        </p>
                      </div>
                      <div className="bg-white p-3 rounded border">
                        <p className="text-sm text-gray-600">Matières Épuisées</p>
                        <p className="text-2xl font-bold text-red-600">
                          {allStocks.filter(s => s.statut === 'EPUISE').length}
                        </p>
                      </div>
                    </div>
                    <div className="mt-4">
                      <h4 className="text-sm font-semibold text-gray-700 mb-2">Détail par matière et niveau</h4>
                      <div className="overflow-x-auto rounded-lg border border-green-200 bg-white max-h-64 overflow-y-auto">
                        <table className="min-w-full text-sm">
                          <thead className="bg-green-50 sticky top-0">
                            <tr>
                              <th className="px-3 py-2 text-left font-medium text-gray-700">Matière</th>
                              <th className="px-3 py-2 text-left font-medium text-gray-700">Niveau</th>
                              <th className="px-3 py-2 text-right font-medium text-gray-700">Dispo.</th>
                              <th className="px-3 py-2 text-right font-medium text-gray-700">Réceptions</th>
                              <th className="px-3 py-2 text-right font-medium text-gray-700">Distribué</th>
                              <th
                                className="px-3 py-2 text-right font-medium text-gray-700"
                                title="Régulation IEPP → EPP (quantités redistribuées pour la ligne matière/niveau)"
                              >
                                Régul.
                              </th>
                              <th className="px-3 py-2 text-center font-medium text-gray-700">Statut</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-gray-100">
                            {allStocks.map((s, i) => (
                              <tr key={`ov-${s.matiereId}-${s.niveauId ?? i}`}>
                                <td className="px-3 py-2 text-gray-900">{s.matiereLibelle || s.matiereCode || "—"}</td>
                                <td className="px-3 py-2 text-gray-600">{s.niveauLibelle ?? s.niveauCode ?? "—"}</td>
                                <td className="px-3 py-2 text-right">{s.stockDisponible}</td>
                                <td className="px-3 py-2 text-right">{s.stockReception}</td>
                                <td className="px-3 py-2 text-right">{s.stockDistribution}</td>
                                <td className="px-3 py-2 text-right text-violet-800">{s.stockRedistribution}</td>
                                <td className="px-3 py-2 text-center">
                                  <span className={`badge ${getStatutBadge(s.statut)}`}>{s.statut}</span>
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </>
                )}
              </div>
            )}

            {/* Message d'erreur */}
            {error && (
              <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                <div className="flex items-center">
                  <ExclamationTriangleIcon className="h-5 w-5 text-red-600 mr-2" />
                  <p className="text-red-800 font-medium">Erreur de chargement</p>
                </div>
                <p className="text-red-700 mt-1">{error}</p>
                <button 
                  onClick={refreshStockData}
                  className="mt-2 text-sm text-red-600 hover:text-red-800 underline"
                >
                  Réessayer
                </button>
              </div>
            )}

            {isRegulationMultiLevelEnabled() &&
              anneeScolaireId != null &&
              (user.role.code === "DAF" || user.role.code === "ADMIN" || user.role.code === "DRENA") && (
                <div className="rounded-lg border border-slate-200 bg-slate-50 p-4 mb-6">
                  <h3 className="text-sm font-semibold text-slate-900 mb-1">Territoire (lecture seule)</h3>
                  <p className="text-xs text-slate-600 mb-3">
                    {user.role.code === "DRENA"
                      ? "Consultez le stock de votre DRENA, puis des IEPP et EPP du ressort (aucune modification)."
                      : "Consultez le stock d'une DRENA, puis d'une IEPP et d'un EPP du ressort (aucune modification)."}
                  </p>
                  <div className="flex flex-wrap gap-3 items-end">
                    {user.role.code === "DRENA" ? (
                      <div className="text-sm text-slate-800">
                        <span className="text-xs text-slate-600 block mb-0.5">DRENA (votre structure)</span>
                        <span className="font-medium">
                          {user.structure?.libelle || user.structure?.code || `#${user.structure?.id ?? "—"}`}
                        </span>
                      </div>
                    ) : (
                      <div>
                        <label className="block text-xs text-slate-600 mb-1">DRENA</label>
                        <select
                          value={terrDrenaId ?? ""}
                          onChange={(e) => {
                            const v = e.target.value ? Number(e.target.value) : null
                            setTerrDrenaId(v)
                            setTerrIeppId(null)
                            setTerrRoEppId(null)
                            setTerrDrenaStocks(null)
                            setTerrIeppStocks(null)
                            setTerrRoEppStocks(null)
                          }}
                          className="rounded border border-slate-300 px-2 py-1.5 text-sm min-w-[200px]"
                        >
                          <option value="">—</option>
                          {terrDrenaList.map((d) => (
                            <option key={d.id} value={d.id}>
                              {d.libelle || d.code || d.id}
                            </option>
                          ))}
                        </select>
                      </div>
                    )}
                    <button
                      type="button"
                      disabled={terrDrenaId == null || loadingTerr}
                      onClick={async () => {
                        if (terrDrenaId == null || anneeScolaireId == null) return
                        setLoadingTerr(true)
                        try {
                          const res = await stockService.getStocksForPage(terrDrenaId, anneeScolaireId)
                          setTerrDrenaStocks(res.success && res.data ? res.data.allStocks : [])
                        } catch {
                          setTerrDrenaStocks([])
                        } finally {
                          setLoadingTerr(false)
                        }
                      }}
                      className="rounded bg-slate-600 text-white px-3 py-1.5 text-sm disabled:opacity-50"
                    >
                      Charger stock DRENA
                    </button>
                    <div>
                      <label className="block text-xs text-slate-600 mb-1">IEPP</label>
                      <select
                        value={terrIeppId ?? ""}
                        onChange={(e) => {
                          const v = e.target.value ? Number(e.target.value) : null
                          setTerrIeppId(v)
                          setTerrRoEppId(null)
                          setTerrIeppStocks(null)
                          setTerrRoEppStocks(null)
                        }}
                        className="rounded border border-slate-300 px-2 py-1.5 text-sm min-w-[200px]"
                      >
                        <option value="">—</option>
                        {terrIeppList.map((i) => (
                          <option key={i.ieppId} value={i.ieppId}>
                            {i.ieppLibelle || i.ieppCode || i.ieppId}
                          </option>
                        ))}
                      </select>
                    </div>
                    <button
                      type="button"
                      disabled={terrIeppId == null || loadingTerr}
                      onClick={async () => {
                        if (terrIeppId == null || anneeScolaireId == null) return
                        setLoadingTerr(true)
                        try {
                          const res = await stockService.getStocksForPage(terrIeppId, anneeScolaireId)
                          setTerrIeppStocks(res.success && res.data ? res.data.allStocks : [])
                        } catch {
                          setTerrIeppStocks([])
                        } finally {
                          setLoadingTerr(false)
                        }
                      }}
                      className="rounded bg-slate-600 text-white px-3 py-1.5 text-sm disabled:opacity-50"
                    >
                      Charger stock IEPP
                    </button>
                    <div>
                      <label className="block text-xs text-slate-600 mb-1">EPP (après IEPP)</label>
                      <select
                        value={terrRoEppId ?? ""}
                        onChange={(e) => {
                          const v = e.target.value ? Number(e.target.value) : null
                          setTerrRoEppId(v)
                          setTerrRoEppStocks(null)
                        }}
                        className="rounded border border-slate-300 px-2 py-1.5 text-sm min-w-[200px]"
                      >
                        <option value="">—</option>
                        {terrRoEppList.map((e) => (
                          <option key={e.eppId} value={e.eppId}>
                            {e.libelle || e.code || e.eppId}
                          </option>
                        ))}
                      </select>
                    </div>
                    <button
                      type="button"
                      disabled={terrRoEppId == null || loadingTerr}
                      onClick={async () => {
                        if (terrRoEppId == null || anneeScolaireId == null) return
                        setLoadingTerr(true)
                        try {
                          const res = await stockService.getStocksForPage(terrRoEppId, anneeScolaireId)
                          setTerrRoEppStocks(res.success && res.data ? res.data.allStocks : [])
                        } catch {
                          setTerrRoEppStocks([])
                        } finally {
                          setLoadingTerr(false)
                        }
                      }}
                      className="rounded bg-slate-600 text-white px-3 py-1.5 text-sm disabled:opacity-50"
                    >
                      Charger stock EPP
                    </button>
                  </div>
                  {(terrDrenaStocks != null || terrIeppStocks != null || terrRoEppStocks != null) && (
                    <div className="mt-4 grid md:grid-cols-2 lg:grid-cols-3 gap-4 max-h-64 overflow-y-auto">
                      {terrDrenaStocks != null && (
                        <div>
                          <p className="text-xs font-medium text-slate-700 mb-1">Stock DRENA (aperçu)</p>
                          <table className="min-w-full text-xs border border-slate-200">
                            <thead className="bg-slate-100">
                              <tr>
                                <th className="px-2 py-1 text-left">Matière</th>
                                <th className="px-2 py-1 text-right">Dispo.</th>
                              </tr>
                            </thead>
                            <tbody>
                              {terrDrenaStocks.slice(0, 50).map((s, i) => (
                                <tr key={`td-${i}`} className="border-t border-slate-100">
                                  <td className="px-2 py-1">{s.matiereLibelle ?? s.matiereCode}</td>
                                  <td className="px-2 py-1 text-right">{s.stockDisponible}</td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      )}
                      {terrIeppStocks != null && (
                        <div>
                          <p className="text-xs font-medium text-slate-700 mb-1">Stock IEPP (aperçu)</p>
                          <table className="min-w-full text-xs border border-slate-200">
                            <thead className="bg-slate-100">
                              <tr>
                                <th className="px-2 py-1 text-left">Matière</th>
                                <th className="px-2 py-1 text-right">Dispo.</th>
                              </tr>
                            </thead>
                            <tbody>
                              {terrIeppStocks.slice(0, 50).map((s, i) => (
                                <tr key={`ti-${i}`} className="border-t border-slate-100">
                                  <td className="px-2 py-1">{s.matiereLibelle ?? s.matiereCode}</td>
                                  <td className="px-2 py-1 text-right">{s.stockDisponible}</td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      )}
                      {terrRoEppStocks != null && (
                        <div>
                          <p className="text-xs font-medium text-slate-700 mb-1">Stock EPP (aperçu)</p>
                          <table className="min-w-full text-xs border border-slate-200">
                            <thead className="bg-slate-100">
                              <tr>
                                <th className="px-2 py-1 text-left">Matière</th>
                                <th className="px-2 py-1 text-right">Dispo.</th>
                              </tr>
                            </thead>
                            <tbody>
                              {terrRoEppStocks.slice(0, 50).map((s, i) => (
                                <tr key={`te-${i}`} className="border-t border-slate-100">
                                  <td className="px-2 py-1">{s.matiereLibelle ?? s.matiereCode}</td>
                                  <td className="px-2 py-1 text-right">{s.stockDisponible}</td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              )}

            {/* Stats globales */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <div className="stat-card">
                <div className="flex items-center">
                  <div className="p-3 rounded-lg bg-blue-50 text-blue-600">
                    <CubeIcon className="h-6 w-6" />
                  </div>
                  <div className="ml-4">
                    <p className="stat-label">Stock Total</p>
                    <p className="stat-value">
                      {roleStockData.hasRealData 
                        ? allStocks.reduce((sum, stock) => sum + stock.stockDisponible, 0).toLocaleString()
                        : getTotalStocks().toLocaleString()
                      }
                    </p>
                  </div>
                </div>
              </div>

              <div className="stat-card">
                <div className="flex items-center">
                  <div className="p-3 rounded-lg bg-green-50 text-green-600">
                    <BuildingOfficeIcon className="h-6 w-6" />
                  </div>
                  <div className="ml-4">
                    <p className="stat-label">Points de Stock</p>
                    <p className="stat-value">
                      {roleStockData.hasRealData 
                        ? 1 // Structure actuelle
                        : 0
                      }
                    </p>
                  </div>
                </div>
              </div>

              <div className="stat-card">
                <div className="flex items-center">
                  <div className="p-3 rounded-lg bg-yellow-50 text-yellow-600">
                    <ExclamationTriangleIcon className="h-6 w-6" />
                  </div>
                  <div className="ml-4">
                    <p className="stat-label">Alertes Critiques</p>
                    <p className="stat-value">
                      {roleStockData.hasRealData 
                        ? allStocks.filter(s => s.statut === 'CRITIQUE' || s.statut === 'EPUISE').length
                        : 0
                      }
                    </p>
                  </div>
                </div>
              </div>

              <div className="stat-card">
                <div className="flex items-center">
                  <div className="p-3 rounded-lg bg-purple-50 text-purple-600">
                    <TruckIcon className="h-6 w-6" />
                  </div>
                  <div className="ml-4">
                    <p className="stat-label">Mouvements Jour</p>
                    <p className="stat-value">0</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Déficit / Excédent (modèle aligné sur la régulation) */}
            {user?.role?.code === "DIRECTEUR" && (
              <div className="card">
                <div className="flex items-center justify-between gap-4 flex-wrap">
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900">Déficit / Excédent</h3>
                    <p className="text-sm text-gray-600">
                      Modèle régulation: comparaison de l&apos;effectif classe avec la quantité reçue, par matière et niveau.
                    </p>
                  </div>
                  <div className="text-sm text-gray-500">
                    {loadingStructureGaps ? "Chargement..." : `${structureDeficits.length} déficit(s) · ${structureExcedents.length} excédent(s)`}
                  </div>
                </div>

                {(structureDeficits.length > 0 || structureExcedents.length > 0) && (
                  <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="rounded-lg border border-red-200 bg-red-50 p-4">
                      <div className="flex items-center justify-between mb-3">
                        <p className="font-semibold text-red-800">Combinaisons Déficitaires</p>
                        <p className="text-sm text-red-700">
                          Total: {structureDeficits.reduce((s, d) => s + (d.deficit ?? 0), 0)}
                        </p>
                      </div>
                      {structureDeficits.length === 0 ? (
                        <p className="text-sm text-red-700">Aucun déficit détecté.</p>
                      ) : (
                        <div className="overflow-x-auto rounded border border-red-200 bg-white max-h-64 overflow-y-auto">
                          <table className="min-w-full text-sm">
                            <thead className="bg-red-50 sticky top-0">
                              <tr>
                                <th className="px-3 py-2 text-left font-medium text-gray-700">Matière</th>
                                <th className="px-3 py-2 text-left font-medium text-gray-700">Niveau</th>
                                <th className="px-3 py-2 text-right font-medium text-gray-700">Effectif classe</th>
                                <th className="px-3 py-2 text-right font-medium text-gray-700">Quantité reçue</th>
                                <th className="px-3 py-2 text-right font-medium text-gray-700">Déficit</th>
                              </tr>
                            </thead>
                            <tbody className="divide-y divide-gray-100">
                              {structureDeficits.map((d, i) => (
                                <tr key={`def-${d.matiereId}-${d.niveauId}-${i}`}>
                                  <td className="px-3 py-2 text-gray-900">{d.matiereLibelle || d.matiereCode}</td>
                                  <td className="px-3 py-2 text-gray-600">{d.niveauLibelle || d.niveauCode}</td>
                                  <td className="px-3 py-2 text-right">{d.effectifClasse}</td>
                                  <td className="px-3 py-2 text-right">{d.quantiteRecueTotale}</td>
                                  <td className="px-3 py-2 text-right font-semibold text-red-700">{d.deficit}</td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      )}
                    </div>

                    <div className="rounded-lg border border-amber-200 bg-amber-50 p-4">
                      <div className="flex items-center justify-between mb-3">
                        <p className="font-semibold text-amber-800">Combinaisons Excédentaires</p>
                        <p className="text-sm text-amber-700">
                          Total: {structureExcedents.reduce((s, e) => s + (e.excedent ?? 0), 0)}
                        </p>
                      </div>
                      {structureExcedents.length === 0 ? (
                        <p className="text-sm text-amber-700">Aucun excédent détecté.</p>
                      ) : (
                        <div className="overflow-x-auto rounded border border-amber-200 bg-white max-h-64 overflow-y-auto">
                          <table className="min-w-full text-sm">
                            <thead className="bg-amber-50 sticky top-0">
                              <tr>
                                <th className="px-3 py-2 text-left font-medium text-gray-700">Matière</th>
                                <th className="px-3 py-2 text-left font-medium text-gray-700">Niveau</th>
                                <th className="px-3 py-2 text-right font-medium text-gray-700">Effectif classe</th>
                                <th className="px-3 py-2 text-right font-medium text-gray-700">Quantité reçue</th>
                                <th className="px-3 py-2 text-right font-medium text-gray-700">Excédent</th>
                              </tr>
                            </thead>
                            <tbody className="divide-y divide-gray-100">
                              {structureExcedents.map((e, i) => (
                                <tr key={`exc-${e.matiereId}-${e.niveauId}-${i}`}>
                                  <td className="px-3 py-2 text-gray-900">{e.matiereLibelle || e.matiereCode}</td>
                                  <td className="px-3 py-2 text-gray-600">{e.niveauLibelle || e.niveauCode}</td>
                                  <td className="px-3 py-2 text-right">{e.effectifClasse}</td>
                                  <td className="px-3 py-2 text-right">{e.quantiteRecueTotale}</td>
                                  <td className="px-3 py-2 text-right font-semibold text-amber-700">{e.excedent}</td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {!loadingStructureGaps && structureDeficits.length === 0 && structureExcedents.length === 0 && (
                  <div className="mt-4 text-sm text-gray-600">
                    Aucun déficit/excédent détecté pour l&apos;année sélectionnée, ou effectif non renseigné.
                  </div>
                )}
              </div>
            )}

            {/* Message si pas de données */}
            {!roleStockData.hasRealData && !loading && !error && (
              <div className="text-center py-12">
                <CubeIcon className="h-16 w-16 mx-auto text-gray-300 mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">Aucune donnée de stock disponible</h3>
                {/* <p className="text-gray-500 mb-4">
                  Les données de stock seront affichées ici une fois synchronisées avec le backend.
                </p> */}
                <button 
                  onClick={refreshStockData}
                  className="btn-primary"
                >
                  Actualiser les données
                </button>
              </div>
            )}
          </div>
        )}

        {/* Autres vues - pour l'instant vides */}
        {selectedView === "entrepot" && (
          <div className="text-center py-12">
            <BuildingOfficeIcon className="h-16 w-16 mx-auto text-gray-300 mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">Entrepôt Banque Mondiale</h3>
            <p className="text-gray-500">Cette section sera disponible prochainement.</p>
          </div>
        )}

        {/* Stocks IEPP — selon rôle : IEPP = mon stock, DRENA/DAF/ADMIN = liste des IEPP avec détail */}
        {selectedView === "iepp" && (
          <div className="space-y-6">
            <h3 className="text-lg font-semibold text-gray-900">Stocks IEPP</h3>
            {(["IEPP"].includes(user?.role?.code ?? "")) && (
              <>
                <p className="text-sm text-gray-600">
                  Stock de votre inspection — {stockData?.structureLibelle ?? user?.structure?.libelle ?? "Ma structure"}
                </p>
                {!roleStockData.hasRealData && !loading && (
                  <p className="text-gray-500">Sélectionnez une année et actualisez pour charger les données.</p>
                )}
                {roleStockData.hasRealData && (
                  <div className="overflow-x-auto rounded-lg border border-gray-200">
                    <table className="min-w-full divide-y divide-gray-200">
                      <thead className="bg-gray-50">
                        <tr>
                          <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Matière</th>
                          <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Niveau</th>
                          <th className="px-4 py-2 text-right text-xs font-medium text-gray-500 uppercase">Stock dispo.</th>
                          <th className="px-4 py-2 text-right text-xs font-medium text-gray-500 uppercase">Réceptions</th>
                          <th className="px-4 py-2 text-right text-xs font-medium text-gray-500 uppercase">Distributions</th>
                          <th
                            className="px-4 py-2 text-right text-xs font-medium text-gray-500 uppercase"
                            title="Quantités envoyées par régulation (IEPP → EPP)"
                          >
                            Régul.
                          </th>
                          <th className="px-4 py-2 text-center text-xs font-medium text-gray-500 uppercase">Statut</th>
                        </tr>
                      </thead>
                      <tbody className="bg-white divide-y divide-gray-200">
                        {allStocks.map((s, i) => (
                          <tr key={`iepp-${s.matiereId}-${s.niveauId ?? i}`}>
                            <td className="px-4 py-2 text-sm text-gray-900">{s.matiereLibelle || s.matiereCode || "—"}</td>
                            <td className="px-4 py-2 text-sm text-gray-600">{s.niveauLibelle ?? s.niveauCode ?? "—"}</td>
                            <td className="px-4 py-2 text-sm text-right">{s.stockDisponible}</td>
                            <td className="px-4 py-2 text-sm text-right">{s.stockReception}</td>
                            <td className="px-4 py-2 text-sm text-right">{s.stockDistribution}</td>
                            <td className="px-4 py-2 text-sm text-right text-violet-800">{s.stockRedistribution}</td>
                            <td className="px-4 py-2 text-center">
                              <span className={`badge ${getStatutBadge(s.statut)}`}>{s.statut}</span>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </>
            )}
            {(["DRENA", "DAF", "ADMIN"].includes(user?.role?.code ?? "")) && (
              <>
                <p className="text-sm text-gray-600">
                  {user?.role?.code === "DRENA" ? "Stocks des IEPP de votre DRENA." : "Stocks par IEPP."}
                </p>
                {anneeScolaireId == null && <p className="text-gray-500">Sélectionnez une année.</p>}
                {anneeScolaireId != null && (
                  <div className="flex flex-wrap items-center gap-3">
                    <label className="text-sm text-gray-600">Filtrer par nom ou code IEPP :</label>
                    <input
                      type="text"
                      value={filterIepp}
                      onChange={(e) => setFilterIepp(e.target.value)}
                      placeholder="Rechercher..."
                      className="rounded-lg border border-gray-300 px-3 py-2 text-sm w-48 focus:ring-orange-500 focus:border-orange-500"
                    />
                  </div>
                )}
                {loadingIeppList && (
                  <div className="flex items-center gap-2 text-gray-500">
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-gray-600" />
                    Chargement de la liste des IEPP...
                  </div>
                )}
                {!loadingIeppList && anneeScolaireId == null && ieppList.length > 0 && (
                  <p className="text-gray-500">Sélectionnez une année pour afficher les stocks.</p>
                )}
                {!loadingIeppList && anneeScolaireId != null && ieppList.length === 0 && (
                  <p className="text-gray-500">Aucune IEPP trouvée.</p>
                )}
                {!loadingIeppList && paginatedIeppList.map((iepp) => {
                  const cached = ieppStocksCache[iepp.id]
                  const structure = cached?.structure
                  const rows = cached?.allStocks ?? []
                  return (
                    <div key={iepp.id} className="border border-gray-200 rounded-lg overflow-hidden">
                      <div className="bg-gray-50 px-4 py-2 font-medium text-gray-900">
                        {iepp.libelle || iepp.code || `Structure ${iepp.id}`}
                        {cached == null ? (
                          <span className="ml-2 text-sm font-normal text-gray-500">— Chargement…</span>
                        ) : (
                          <span className="ml-2 text-sm font-normal text-gray-500">— Total: {Number(structure?.stockTotal) ?? 0} · {rows.length} ligne(s)</span>
                        )}
                      </div>
                      {cached == null && loadingIeppPage && (
                        <div className="flex items-center gap-2 px-4 py-6 text-gray-500">
                          <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-gray-600" />
                          Chargement du stock…
                        </div>
                      )}
                      {cached != null && (
                        <div className="overflow-x-auto">
                          <table className="min-w-full divide-y divide-gray-200">
                            <thead className="bg-gray-100">
                              <tr>
                                <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Matière</th>
                                <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Niveau</th>
                                <th className="px-4 py-2 text-right text-xs font-medium text-gray-500 uppercase">Stock dispo.</th>
                                <th className="px-4 py-2 text-right text-xs font-medium text-gray-500 uppercase">Réceptions</th>
                                <th className="px-4 py-2 text-right text-xs font-medium text-gray-500 uppercase">Distributions</th>
                                <th
                                  className="px-4 py-2 text-right text-xs font-medium text-gray-500 uppercase"
                                  title="Quantités envoyées par régulation (IEPP → EPP)"
                                >
                                  Régul.
                                </th>
                                <th className="px-4 py-2 text-center text-xs font-medium text-gray-500 uppercase">Statut</th>
                              </tr>
                            </thead>
                            <tbody className="bg-white divide-y divide-gray-200">
                              {rows.map((s, i) => (
                                <tr key={`${iepp.id}-${s.matiereId}-${s.niveauId ?? i}`}>
                                  <td className="px-4 py-2 text-sm text-gray-900">{s.matiereLibelle || s.matiereCode || "—"}</td>
                                  <td className="px-4 py-2 text-sm text-gray-600">{s.niveauLibelle ?? s.niveauCode ?? "—"}</td>
                                  <td className="px-4 py-2 text-sm text-right">{s.stockDisponible}</td>
                                  <td className="px-4 py-2 text-sm text-right">{s.stockReception}</td>
                                  <td className="px-4 py-2 text-sm text-right">{s.stockDistribution}</td>
                                  <td className="px-4 py-2 text-sm text-right text-violet-800">{s.stockRedistribution}</td>
                                  <td className="px-4 py-2 text-center">
                                    <span className={`badge ${getStatutBadge(s.statut)}`}>{s.statut}</span>
                                  </td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      )}
                    </div>
                  )
                })}
                {!loadingIeppList && filteredIeppList.length > 0 && (
                  <div className="flex items-center justify-between border-t border-gray-200 pt-3">
                    <p className="text-sm text-gray-500">
                      {filteredIeppList.length} IEPP(s) {filterIepp.trim() ? "(filtré)" : ""}
                    </p>
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => setPageIepp(1)}
                        disabled={pageIepp <= 1}
                        className="rounded border border-gray-300 px-3 py-1 text-sm disabled:opacity-50"
                      >
                        Première
                      </button>
                      <button
                        type="button"
                        onClick={() => setPageIepp((p) => Math.max(1, p - 1))}
                        disabled={pageIepp <= 1}
                        className="rounded border border-gray-300 px-3 py-1 text-sm disabled:opacity-50"
                      >
                        Précédent
                      </button>
                      <span className="text-sm text-gray-600">
                        Page {pageIepp} / {totalPagesIepp}
                      </span>
                      <button
                        type="button"
                        onClick={() => setPageIepp((p) => Math.min(totalPagesIepp, p + 1))}
                        disabled={pageIepp >= totalPagesIepp}
                        className="rounded border border-gray-300 px-3 py-1 text-sm disabled:opacity-50"
                      >
                        Suivant
                      </button>
                      <button
                        type="button"
                        onClick={() => setPageIepp(totalPagesIepp)}
                        disabled={pageIepp >= totalPagesIepp}
                        className="rounded border border-gray-300 px-3 py-1 text-sm disabled:opacity-50"
                      >
                        Dernière
                      </button>
                    </div>
                  </div>
                )}
              </>
            )}
          </div>
        )}

        {/* Stocks EPP — DIRECTEUR = mon EPP ; IEPP/DRENA/DAF/ADMIN = détail groupé par EPP */}
        {selectedView === "epp" && (
          <div className="space-y-6">
            <h3 className="text-lg font-semibold text-gray-900">Stocks EPP</h3>
            {(["DIRECTEUR"].includes(user?.role?.code ?? "")) && (
              <>
                <p className="text-sm text-gray-600">
                  Stock de votre école — {stockData?.structureLibelle ?? user?.structure?.libelle ?? "Ma structure"}
                </p>
                <p className="text-xs text-gray-500">
                  Provenance: Réceptions, récupérations reportées ({anneeRetourNMoins1Code}), puis sorties en distributions.
                </p>
                {!roleStockData.hasRealData && !loading && (
                  <p className="text-gray-500">Sélectionnez une année et actualisez pour charger les données.</p>
                )}
                {roleStockData.hasRealData && (
                  <div className="overflow-x-auto rounded-lg border border-gray-200">
                    <table className="min-w-full divide-y divide-gray-200">
                      <thead className="bg-gray-50">
                        <tr>
                          <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Matière</th>
                          <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Niveau</th>
                          <th className="px-4 py-2 text-right text-xs font-medium text-gray-500 uppercase">Stock dispo.</th>
                          <th className="px-4 py-2 text-right text-xs font-medium text-gray-500 uppercase">Réceptions</th>
                          <th className="px-4 py-2 text-right text-xs font-medium text-gray-500 uppercase">{`Récup. ${anneeRetourNMoins1Code}`}</th>
                          <th className="px-4 py-2 text-right text-xs font-medium text-gray-500 uppercase">Distributions</th>
                          <th
                            className="px-4 py-2 text-right text-xs font-medium text-gray-500 uppercase"
                            title="Quantités reçues par régulation depuis l’IEPP"
                          >
                            Régul.
                          </th>
                          <th className="px-4 py-2 text-center text-xs font-medium text-gray-500 uppercase">Statut</th>
                        </tr>
                      </thead>
                      <tbody className="bg-white divide-y divide-gray-200">
                        {allStocks.map((s, i) => (
                          <tr key={`epp-${s.matiereId}-${s.niveauId ?? i}`}>
                            <td className="px-4 py-2 text-sm text-gray-900">{s.matiereLibelle || s.matiereCode || "—"}</td>
                            <td className="px-4 py-2 text-sm text-gray-600">{s.niveauLibelle ?? s.niveauCode ?? "—"}</td>
                            <td className="px-4 py-2 text-sm text-right">{s.stockDisponible}</td>
                            <td className="px-4 py-2 text-sm text-right">{s.stockReception}</td>
                            <td className="px-4 py-2 text-sm text-right">{s.stockRetoursAnneePrecedente}</td>
                            <td className="px-4 py-2 text-sm text-right">{s.stockDistribution}</td>
                            <td className="px-4 py-2 text-sm text-right text-violet-800">{s.stockRedistribution}</td>
                            <td className="px-4 py-2 text-center">
                              <span className={`badge ${getStatutBadge(s.statut)}`}>{s.statut}</span>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </>
            )}
            {(["IEPP", "DRENA", "DAF", "ADMIN"].includes(user?.role?.code ?? "")) && (
              <>
                <p className="text-sm text-gray-600">
                  Détail du stock par école (EPP). {user?.role?.code === "IEPP" && "Écoles de votre inspection."}
                </p>
                <p className="text-xs text-gray-500">
                  Provenance affichée par ligne: Réceptions + récupérations reportées ({anneeRetourNMoins1Code}), moins Distributions.
                </p>
                {anneeScolaireId == null && <p className="text-gray-500">Sélectionnez une année.</p>}
                {anneeScolaireId != null && (
                  <div className="flex flex-wrap items-center gap-3">
                    <label className="text-sm text-gray-600">Filtrer par nom ou code EPP :</label>
                    <input
                      type="text"
                      value={filterEpp}
                      onChange={(e) => setFilterEpp(e.target.value)}
                      placeholder="Rechercher une école..."
                      className="rounded-lg border border-gray-300 px-3 py-2 text-sm w-56 focus:ring-orange-500 focus:border-orange-500"
                    />
                  </div>
                )}
                {loadingEppList && (
                  <div className="flex items-center gap-2 text-gray-500">
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-gray-600" />
                    Chargement de la liste des EPP...
                  </div>
                )}
                {!loadingEppList && anneeScolaireId == null && eppList.length > 0 && (
                  <p className="text-gray-500">Sélectionnez une année pour afficher les stocks.</p>
                )}
                {!loadingEppList && anneeScolaireId != null && eppList.length === 0 && (
                  <p className="text-gray-500">Aucun EPP trouvé.</p>
                )}
                {!loadingEppList && paginatedEppList.map(({ epp, ieppLibelle }) => {
                  const cached = eppStocksCache[epp.id]
                  const structure = cached?.structure
                  const rows = cached?.allStocks ?? []
                  return (
                    <div key={epp.id} className="border border-gray-200 rounded-lg overflow-hidden">
                      <div className="bg-gray-50 px-4 py-2 font-medium text-gray-900">
                        {epp.libelle || epp.code || `Structure ${epp.id}`}
                        {ieppLibelle && <span className="ml-2 text-sm font-normal text-gray-600">(IEPP: {ieppLibelle})</span>}
                        {cached == null ? (
                          <span className="ml-2 text-sm font-normal text-gray-500">— Chargement…</span>
                        ) : (
                          <span className="ml-2 text-sm font-normal text-gray-500">— Total: {Number(structure?.stockTotal) ?? 0} · {rows.length} ligne(s)</span>
                        )}
                      </div>
                      {cached == null && loadingEppPage && (
                        <div className="flex items-center gap-2 px-4 py-6 text-gray-500">
                          <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-gray-600" />
                          Chargement du stock…
                        </div>
                      )}
                      {cached != null && (
                        <div className="overflow-x-auto">
                          <table className="min-w-full divide-y divide-gray-200">
                            <thead className="bg-gray-100">
                              <tr>
                                <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Matière</th>
                                <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Niveau</th>
                                <th className="px-4 py-2 text-right text-xs font-medium text-gray-500 uppercase">Stock dispo.</th>
                                <th className="px-4 py-2 text-right text-xs font-medium text-gray-500 uppercase">Réceptions</th>
                                <th className="px-4 py-2 text-right text-xs font-medium text-gray-500 uppercase">{`Récup. ${anneeRetourNMoins1Code}`}</th>
                                <th className="px-4 py-2 text-right text-xs font-medium text-gray-500 uppercase">Distributions</th>
                                <th
                                  className="px-4 py-2 text-right text-xs font-medium text-gray-500 uppercase"
                                  title="Quantités reçues par régulation depuis l’IEPP"
                                >
                                  Régul.
                                </th>
                                <th className="px-4 py-2 text-center text-xs font-medium text-gray-500 uppercase">Statut</th>
                              </tr>
                            </thead>
                            <tbody className="bg-white divide-y divide-gray-200">
                              {rows.map((s, i) => (
                                <tr key={`${epp.id}-${s.matiereId}-${s.niveauId ?? i}`}>
                                  <td className="px-4 py-2 text-sm text-gray-900">{s.matiereLibelle || s.matiereCode || "—"}</td>
                                  <td className="px-4 py-2 text-sm text-gray-600">{s.niveauLibelle ?? s.niveauCode ?? "—"}</td>
                                  <td className="px-4 py-2 text-sm text-right">{s.stockDisponible}</td>
                                  <td className="px-4 py-2 text-sm text-right">{s.stockReception}</td>
                                  <td className="px-4 py-2 text-sm text-right">{s.stockRetoursAnneePrecedente}</td>
                                  <td className="px-4 py-2 text-sm text-right">{s.stockDistribution}</td>
                                  <td className="px-4 py-2 text-sm text-right text-violet-800">{s.stockRedistribution}</td>
                                  <td className="px-4 py-2 text-center">
                                    <span className={`badge ${getStatutBadge(s.statut)}`}>{s.statut}</span>
                                  </td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      )}
                    </div>
                  )
                })}
                {!loadingEppList && filteredEppList.length > 0 && (
                  <div className="flex items-center justify-between border-t border-gray-200 pt-3">
                    <p className="text-sm text-gray-500">
                      {filteredEppList.length} EPP(s) {filterEpp.trim() ? "(filtré)" : ""}
                    </p>
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => setPageEpp(1)}
                        disabled={pageEpp <= 1}
                        className="rounded border border-gray-300 px-3 py-1 text-sm disabled:opacity-50"
                      >
                        Première
                      </button>
                      <button
                        type="button"
                        onClick={() => setPageEpp((p) => Math.max(1, p - 1))}
                        disabled={pageEpp <= 1}
                        className="rounded border border-gray-300 px-3 py-1 text-sm disabled:opacity-50"
                      >
                        Précédent
                      </button>
                      <span className="text-sm text-gray-600">
                        Page {pageEpp} / {totalPagesEpp}
                      </span>
                      <button
                        type="button"
                        onClick={() => setPageEpp((p) => Math.min(totalPagesEpp, p + 1))}
                        disabled={pageEpp >= totalPagesEpp}
                        className="rounded border border-gray-300 px-3 py-1 text-sm disabled:opacity-50"
                      >
                        Suivant
                      </button>
                      <button
                        type="button"
                        onClick={() => setPageEpp(totalPagesEpp)}
                        disabled={pageEpp >= totalPagesEpp}
                        className="rounded border border-gray-300 px-3 py-1 text-sm disabled:opacity-50"
                      >
                        Dernière
                      </button>
                    </div>
                  </div>
                )}
              </>
            )}
          </div>
        )}

        {/* Mouvements de stock */}
        {selectedView === "mouvements" && (
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-gray-900">Mouvements de stock</h3>
            <p className="text-sm text-gray-500">Historique des mouvements pour votre structure.</p>
            {mouvements.length > 0 && (
              <div className="flex flex-wrap items-center gap-3">
                <label className="text-sm text-gray-600">Filtrer (type, matière, date, structure) :</label>
                <input
                  type="text"
                  value={filterMouvements}
                  onChange={(e) => setFilterMouvements(e.target.value)}
                  placeholder="Rechercher..."
                  className="rounded-lg border border-gray-300 px-3 py-2 text-sm w-56 focus:ring-orange-500 focus:border-orange-500"
                />
              </div>
            )}
            {loadingMouvements ? (
              <div className="flex items-center gap-2 text-gray-500">
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-gray-600" />
                Chargement des mouvements...
              </div>
            ) : mouvements.length === 0 ? (
              <p className="text-gray-500 py-6">Aucun mouvement enregistré pour cette structure.</p>
            ) : (
              <>
                <div className="overflow-x-auto rounded-lg border border-gray-200">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Date</th>
                        <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Type</th>
                        <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Matière</th>
                        <th className="px-4 py-2 text-right text-xs font-medium text-gray-500 uppercase">Quantité</th>
                        <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Structure</th>
                        <th className="px-4 py-2 text-center text-xs font-medium text-gray-500 uppercase">Statut</th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {paginatedMouvements.map((m) => (
                        <tr key={m.id}>
                          <td className="px-4 py-2 text-sm text-gray-900">{m.dateMouvement || "—"}</td>
                          <td className="px-4 py-2 text-sm text-gray-700">{m.typeMouvement || "—"}</td>
                          <td className="px-4 py-2 text-sm">{m.matiereLibelle || m.matiereCode || "—"}</td>
                          <td className="px-4 py-2 text-sm text-right">{m.quantite}</td>
                          <td className="px-4 py-2 text-sm text-gray-600">{m.structureSource ?? "—"}</td>
                          <td className="px-4 py-2 text-center">
                            <span className={`badge ${getStatutBadge(m.statut)}`}>{m.statut || "—"}</span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                {filteredMouvements.length > 0 && (
                  <div className="flex items-center justify-between border-t border-gray-200 pt-3">
                    <p className="text-sm text-gray-500">
                      {filteredMouvements.length} mouvement(s) {filterMouvements.trim() ? "(filtré)" : ""}
                    </p>
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => setPageMouvements(1)}
                        disabled={pageMouvements <= 1}
                        className="rounded border border-gray-300 px-3 py-1 text-sm disabled:opacity-50"
                      >
                        Première
                      </button>
                      <button
                        type="button"
                        onClick={() => setPageMouvements((p) => Math.max(1, p - 1))}
                        disabled={pageMouvements <= 1}
                        className="rounded border border-gray-300 px-3 py-1 text-sm disabled:opacity-50"
                      >
                        Précédent
                      </button>
                      <span className="text-sm text-gray-600">
                        Page {pageMouvements} / {totalPagesMouvements}
                      </span>
                      <button
                        type="button"
                        onClick={() => setPageMouvements((p) => Math.min(totalPagesMouvements, p + 1))}
                        disabled={pageMouvements >= totalPagesMouvements}
                        className="rounded border border-gray-300 px-3 py-1 text-sm disabled:opacity-50"
                      >
                        Suivant
                      </button>
                      <button
                        type="button"
                        onClick={() => setPageMouvements(totalPagesMouvements)}
                        disabled={pageMouvements >= totalPagesMouvements}
                        className="rounded border border-gray-300 px-3 py-1 text-sm disabled:opacity-50"
                      >
                        Dernière
                      </button>
                    </div>
                  </div>
                )}
              </>
            )}
          </div>
        )}

        {/* Modals - pour l'instant vides */}
        {showModal && (
          <div className="modal-overlay" onClick={() => setShowModal(false)}>
            <div className="modal-content max-w-lg" onClick={(e) => e.stopPropagation()}>
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold">Détails du Stock</h3>
                <button onClick={() => setShowModal(false)} className="text-gray-400 hover:text-gray-600">
                  <ExclamationTriangleIcon className="h-6 w-6" />
                </button>
              </div>
              <p className="text-gray-500">Détails du stock à implémenter.</p>
            </div>
          </div>
        )}

        {showMouvementModal && (
          <div className="modal-overlay" onClick={() => setShowMouvementModal(false)}>
            <div className="modal-content max-w-lg" onClick={(e) => e.stopPropagation()}>
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold">Nouveau Mouvement</h3>
                <button onClick={() => setShowMouvementModal(false)} className="text-gray-400 hover:text-gray-600">
                  <ExclamationTriangleIcon className="h-6 w-6" />
                </button>
              </div>
              <p className="text-gray-500">Formulaire de mouvement à implémenter.</p>
            </div>
          </div>
        )}

        {showRapportModal && (
          <div className="modal-overlay" onClick={() => !rapportGenerating && setShowRapportModal(false)}>
            <div className="modal-content max-w-lg" onClick={(e) => e.stopPropagation()}>
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold">Rapport de stock</h3>
                <button
                  type="button"
                  disabled={rapportGenerating}
                  onClick={() => setShowRapportModal(false)}
                  className="text-gray-400 hover:text-gray-600"
                >
                  <ExclamationTriangleIcon className="h-6 w-6" />
                </button>
              </div>
              <p className="text-sm text-gray-600 mb-4">
                Export Excel des mouvements de stock pour l’année scolaire sélectionnée sur cet écran, pour la
                structure utilisée par l’API stock (ci-dessous).
              </p>
              {anneeScolaireId == null ? (
                <p className="text-amber-700 text-sm">Sélectionnez d’abord une année scolaire dans la page.</p>
              ) : (
                <p className="text-xs text-gray-500">
                  Année scolaire ID : <span className="font-mono">{anneeScolaireId}</span>
                  {stockApiStructureId != null && (
                    <> — Structure API : <span className="font-mono">{stockApiStructureId}</span></>
                  )}
                </p>
              )}
              <div className="flex justify-end gap-2 mt-6">
                <button type="button" className="btn-outline" disabled={rapportGenerating} onClick={() => setShowRapportModal(false)}>
                  Fermer
                </button>
                <button
                  type="button"
                  className="btn-primary"
                  disabled={rapportGenerating || anneeScolaireId == null}
                  onClick={async () => {
                    if (anneeScolaireId == null) return
                    setRapportGenerating(true)
                    try {
                      const res = await rapportService.generate({
                        codeType: "STOCK",
                        anneeScolaireId,
                        structureId: stockApiStructureId ?? undefined,
                        format: "XLSX",
                      })
                      if (res.hasError) {
                        toast.error(res.status?.message || "Échec de la génération")
                        return
                      }
                      const row = Array.isArray(res.items) ? res.items[0] : undefined
                      if (row?.fichierBase64 && row.nomFichier) {
                        downloadRapportFile(row)
                        toast.success("Rapport téléchargé.")
                        setShowRapportModal(false)
                      }
                    } catch (e: unknown) {
                      toast.error(e instanceof Error ? e.message : "Erreur")
                    } finally {
                      setRapportGenerating(false)
                    }
                  }}
                >
                  {rapportGenerating ? "Génération…" : "Générer Excel"}
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </MainLayout>
  )
}