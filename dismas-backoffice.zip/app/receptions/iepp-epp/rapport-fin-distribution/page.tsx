"use client"

import { useState } from "react"
import MainLayout from "../../../../components/layout/main-layout"
import { useAuth } from "../../../providers"
import { toast } from "sonner"
import {
  DocumentTextIcon,
  CheckCircleIcon,
  ClockIcon,
  XCircleIcon,
  ArrowUpTrayIcon,
  CalculatorIcon,
  PrinterIcon,
} from "@heroicons/react/24/outline"

// Données mockées des distributions en cours
const mockDistributionsEnCours = [
  {
    id: 1,
    reference: "REC-IEPP-EPP-COC-2024-001",
    bordereau: "BL-IEPP-COC-2024-001",
    epp_destinataire: "EPP Cocody Centre",
    date_distribution: "2024-10-20",
    statut: "DISTRIBUTION_EN_COURS",
    manuels: [
      { 
        code: "FR-CP1-001", 
        titre: "Français CP1", 
        quantite_prevue: 150, 
        quantite_distribuee: 148,
        ecart: -2
      },
      { 
        code: "MA-CP1-001", 
        titre: "Mathématiques CP1", 
        quantite_prevue: 150, 
        quantite_distribuee: 150,
        ecart: 0
      },
    ],
    documents: {
      bordereau_livraison: "BL-IEPP-COC-2024-001.pdf",
      fiche_reception: null
    }
  },
  {
    id: 2,
    reference: "REC-IEPP-EPP-COC-2024-002",
    bordereau: "BL-IEPP-COC-2024-002",
    epp_destinataire: "EPP Cocody Riviera",
    date_distribution: "2024-10-21",
    statut: "DISTRIBUTION_EN_COURS",
    manuels: [
      { 
        code: "FR-CP2-001", 
        titre: "Français CP2", 
        quantite_prevue: 120, 
        quantite_distribuee: 0,
        ecart: 0
      },
      { 
        code: "MA-CP2-001", 
        titre: "Mathématiques CP2", 
        quantite_prevue: 120, 
        quantite_distribuee: 0,
        ecart: 0
      },
    ],
    documents: {
      bordereau_livraison: "BL-IEPP-COC-2024-002.pdf",
      fiche_reception: null
    }
  },
]

export default function RapportFinDistributionPage() {
  const { user } = useAuth()
  const [selectedDistribution, setSelectedDistribution] = useState<any>(null)
  const [showRapportModal, setShowRapportModal] = useState(false)
  const [rapportFormData, setRapportFormData] = useState<any>({
    ficheEmargement: null,
    ficheEmargementName: "",
    observations: "",
    quantitesEffectives: []
  })

  // ✅ CORRECTION: Vérification après tous les hooks
  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <p className="text-gray-600">Chargement...</p>
        </div>
      </div>
    )
  }

  // Vérifier les droits d'accès
  if (!["ADMIN", "DAF", "DRENA", "IEPP"].includes(user.role.code)) {
    return (
      <MainLayout>
        <div className="min-h-screen flex items-center justify-center">
          <div className="text-center">
            <XCircleIcon className="h-16 w-16 text-red-500 mx-auto mb-4" />
            <h2 className="text-xl font-semibold text-gray-900 mb-2">Accès Restreint</h2>
            <p className="text-gray-600">Vous n'avez pas les droits pour accéder à ce module.</p>
          </div>
        </div>
      </MainLayout>
    )
  }

  const getDistributionsByRole = () => {
    switch (user.role.code) {
      case "ADMIN":
      case "DAF":
        return mockDistributionsEnCours
      case "DRENA":
        // DRENA voit les distributions de ses IEPP
        return mockDistributionsEnCours.filter(d => 
          d.reference.includes(user.structure?.libelle?.split(" ")[1] || "")
        )
      case "IEPP":
        // IEPP voit ses propres distributions
        return mockDistributionsEnCours.filter(d => 
          d.reference.includes(user.structure?.libelle?.split(" ")[1] || "")
        )
      default:
        return []
    }
  }

  const getStatusBadge = (statut: string) => {
    switch (statut) {
      case "DISTRIBUTION_EN_COURS":
        return <span className="badge-warning">🔄 Distribution en Cours</span>
      case "TERMINEE":
        return <span className="badge-success">✅ Terminée</span>
      default:
        return <span className="badge-secondary">{statut}</span>
    }
  }

  const handleGenererRapport = (distribution: any) => {
    // Initialiser le formulaire avec les données de la distribution
    setRapportFormData({
      ficheEmargement: null,
      ficheEmargementName: "",
      observations: "",
      quantitesEffectives: distribution.manuels.map((m: any) => ({
        ...m,
        quantite_effective: m.quantite_distribuee || 0
      }))
    })
    
    setSelectedDistribution(distribution)
    setShowRapportModal(true)
  }

  const distributions = getDistributionsByRole()

  return (
    <MainLayout>
      <div className="p-6">
        {/* Header */}
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
            <DocumentTextIcon className="h-8 w-8 text-blue-600" />
            Rapport de Fin de Distribution
          </h1>
          <p className="text-gray-600 mt-1">
            Finaliser la distribution et charger les fiches d'émargement
          </p>
        </div>

        {/* Statistiques */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <div className="card">
            <div className="flex items-center">
              <ClockIcon className="h-8 w-8 text-orange-600" />
              <div className="ml-3">
                <p className="text-sm font-medium text-gray-600">Distributions en Cours</p>
                <p className="text-2xl font-bold text-gray-900">
                  {distributions.filter(d => d.statut === "DISTRIBUTION_EN_COURS").length}
                </p>
              </div>
            </div>
          </div>
          
          <div className="card">
            <div className="flex items-center">
              <CheckCircleIcon className="h-8 w-8 text-green-600" />
              <div className="ml-3">
                <p className="text-sm font-medium text-gray-600">Terminées</p>
                <p className="text-2xl font-bold text-gray-900">
                  {distributions.filter(d => d.statut === "TERMINEE").length}
                </p>
              </div>
            </div>
          </div>
          
          <div className="card">
            <div className="flex items-center">
              <CalculatorIcon className="h-8 w-8 text-purple-600" />
              <div className="ml-3">
                <p className="text-sm font-medium text-gray-600">À Rapporter</p>
                <p className="text-2xl font-bold text-gray-900">
                  {distributions.filter(d => d.statut === "DISTRIBUTION_EN_COURS").length}
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Liste des distributions */}
        <div className="card">
          <div className="card-header">
            <h2 className="card-title">Distributions en Cours - À Finaliser</h2>
          </div>
          
          <div className="overflow-x-auto">
            <table className="table">
              <thead>
                <tr>
                  <th>Référence</th>
                  <th>EPP Destinataire</th>
                  <th>Date Distribution</th>
                  <th>Manuels</th>
                  <th>Statut</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {distributions.filter(d => d.statut === "DISTRIBUTION_EN_COURS").map((distribution) => (
                  <tr key={distribution.id} className="hover:bg-gray-50">
                    <td className="font-medium">{distribution.reference}</td>
                    <td>{distribution.epp_destinataire}</td>
                    <td>{new Date(distribution.date_distribution).toLocaleDateString("fr-FR")}</td>
                    <td>
                      <div className="text-sm">
                        {distribution.manuels.length} manuel(s)
                        <div className="text-xs text-gray-500">
                          {distribution.manuels.map(m => m.titre).join(", ")}
                        </div>
                      </div>
                    </td>
                    <td>{getStatusBadge(distribution.statut)}</td>
                    <td>
                      <div className="flex space-x-2">
                        <button
                          onClick={() => setSelectedDistribution(distribution)}
                          className="btn-outline btn-sm"
                        >
                          <DocumentTextIcon className="h-4 w-4" />
                          Détails
                        </button>
                        
                        <button
                          onClick={() => handleGenererRapport(distribution)}
                          className="btn-primary btn-sm"
                        >
                          <DocumentTextIcon className="h-4 w-4" />
                          Générer Rapport
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Modal détails distribution */}
        {selectedDistribution && !showRapportModal && (
          <div className="modal-overlay" onClick={() => setSelectedDistribution(null)}>
            <div className="modal-content max-w-4xl" onClick={(e) => e.stopPropagation()}>
              <div className="px-6 py-4 border-b border-orange-200 flex justify-between items-center bg-orange-50/30">
                <h3 className="text-xl font-bold text-orange-800">Détails Distribution IEPP → EPP</h3>
                <button onClick={() => setSelectedDistribution(null)} className="text-gray-400 hover:text-gray-600">
                  <XCircleIcon className="h-6 w-6" />
                </button>
              </div>

              <div className="p-6 space-y-6">
                <div className="border-2 border-orange-200 rounded-lg p-4 bg-orange-50/50">
                  <h4 className="text-lg font-semibold text-orange-800 mb-4">Informations Générales</h4>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Référence</label>
                      <p className="text-gray-900">{selectedDistribution.reference}</p>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">EPP Destinataire</label>
                      <p className="text-gray-900">{selectedDistribution.epp_destinataire}</p>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Date Distribution</label>
                      <p className="text-gray-900">
                        {new Date(selectedDistribution.date_distribution).toLocaleDateString("fr-FR")}
                      </p>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Statut</label>
                      <div>{getStatusBadge(selectedDistribution.statut)}</div>
                    </div>
                  </div>
                </div>

                <div className="border-2 border-orange-200 rounded-lg p-4 bg-orange-50/50">
                  <h4 className="text-lg font-semibold text-orange-800 mb-4">Manuels Distribués</h4>
                  <div className="overflow-x-auto">
                    <table className="min-w-full bg-white border border-orange-200 rounded-lg">
                      <thead className="bg-orange-50">
                        <tr>
                          <th className="px-4 py-3 text-left text-xs font-medium text-orange-800 uppercase tracking-wider">Code</th>
                          <th className="px-4 py-3 text-left text-xs font-medium text-orange-800 uppercase tracking-wider">Manuel</th>
                          <th className="px-4 py-3 text-left text-xs font-medium text-orange-800 uppercase tracking-wider">Total démandé</th>
                          <th className="px-4 py-3 text-left text-xs font-medium text-orange-800 uppercase tracking-wider">Quantité Distribuée</th>
                          <th className="px-4 py-3 text-left text-xs font-medium text-orange-800 uppercase tracking-wider">Écart</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-orange-100">
                        {selectedDistribution.manuels?.map((manuel: any, index: number) => (
                          <tr key={index} className="hover:bg-orange-50/50">
                            <td className="px-4 py-3 text-sm font-medium text-gray-900">{manuel.code}</td>
                            <td className="px-4 py-3 text-sm text-gray-700">{manuel.titre}</td>
                            <td className="px-4 py-3 text-sm text-gray-700">{manuel.quantite_prevue}</td>
                            <td className="px-4 py-3 text-sm text-gray-700">{manuel.quantite_distribuee}</td>
                            <td className="px-4 py-3 text-sm">
                              <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${manuel.ecart < 0 ? 'bg-red-100 text-red-800' : manuel.ecart > 0 ? 'bg-green-100 text-green-800' : 'bg-orange-100 text-orange-800'}`}>
                                {manuel.ecart > 0 ? '+' : ''}{manuel.ecart}
                              </span>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

                <div className="border-2 border-orange-200 rounded-lg p-4 bg-orange-50/50">
                  <h4 className="text-lg font-semibold text-orange-800 mb-4">Documents</h4>
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <DocumentTextIcon className="h-4 w-4 text-orange-600" />
                      <span className="text-sm text-gray-700">Bordereau de distribution: {selectedDistribution.documents?.bordereau_livraison || "Non uploadé"}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <DocumentTextIcon className="h-4 w-4 text-orange-600" />
                      <span className="text-sm text-gray-700">Fiche de réception: {selectedDistribution.documents?.fiche_reception || "Non uploadé"}</span>
                    </div>
                  </div>
                </div>

                <div className="flex justify-end pt-4 border-t border-orange-200">
                  <button
                    onClick={() => setSelectedDistribution(null)}
                    className="px-6 py-2 bg-gray-800 text-white rounded-md hover:bg-gray-900 transition-colors"
                  >
                    Fermer
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ✅ MODAL : Génération du rapport de fin de distribution */}
        {showRapportModal && selectedDistribution && rapportFormData && (
          <div className="modal-overlay" onClick={() => setShowRapportModal(false)}>
            <div className="modal-content max-w-6xl max-h-[90vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-bold text-gray-900 flex items-center gap-3">
                  <DocumentTextIcon className="h-6 w-6 text-blue-600" />
                  Rapport de Fin de Distribution
                </h3>
                <button 
                  onClick={() => setShowRapportModal(false)} 
                  className="text-gray-400 hover:text-gray-600 transition-colors"
                >
                  <XCircleIcon className="h-6 w-6" />
                </button>
              </div>

              <div className="space-y-8">
                {/* Section 1: Informations de la distribution */}
                <div className="bg-gray-50 rounded-lg p-6">
                  <h4 className="text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2">
                    📋 Distribution à Finaliser
                  </h4>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Référence
                      </label>
                      <p className="text-gray-900 font-medium">{selectedDistribution.reference}</p>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        EPP Destinataire
                      </label>
                      <p className="text-gray-900">{selectedDistribution.epp_destinataire}</p>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Date Distribution
                      </label>
                      <p className="text-gray-900">
                        {new Date(selectedDistribution.date_distribution).toLocaleDateString("fr-FR")}
                      </p>
                    </div>
                  </div>
                </div>

                {/* Section 2: Quantités effectives distribuées */}
                <div className="bg-white rounded-lg border border-gray-200">
                  <div className="px-6 py-4 border-b border-gray-200 bg-gray-50">
                    <h4 className="text-lg font-semibold text-gray-900 flex items-center gap-2">
                      📊 Quantités Effectives Distribuées
                    </h4>
                  </div>
                  <div className="overflow-x-auto">
                    <table className="min-w-full">
                      <thead className="bg-gray-50">
                        <tr>
                          <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider border-b border-gray-200">
                            Code
                          </th>
                          <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider border-b border-gray-200">
                            Manuel
                          </th>
                          <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider border-b border-gray-200">
                            Niveau
                          </th>
                          <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider border-b border-gray-200">
                            Total démandé
                          </th>
                          <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider border-b border-gray-200">
                            Quantité Effective
                          </th>
                          <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider border-b border-gray-200">
                            Écart Final
                          </th>
                        </tr>
                      </thead>
                      <tbody className="bg-white divide-y divide-gray-200">
                        {rapportFormData.quantitesEffectives.map((manuel: any, index: number) => (
                          <tr key={index} className="hover:bg-blue-50 transition-colors">
                            <td className="px-4 py-3 text-sm font-medium text-gray-900">
                              {manuel.code}
                            </td>
                            <td className="px-4 py-3 text-sm text-gray-700">
                              {manuel.titre}
                            </td>
                            <td className="px-4 py-3 text-sm text-gray-700">
                              <span className="inline-flex px-2 py-1 text-xs font-semibold rounded-full bg-blue-100 text-blue-800">
                                {manuel.niveau}
                              </span>
                            </td>
                            <td className="px-4 py-3 text-sm text-gray-700 bg-blue-50 font-medium">
                              {manuel.quantite_prevue}
                            </td>
                            <td className="px-4 py-3">
                              <input
                                type="number"
                                value={manuel.quantite_effective}
                                onChange={(e) => {
                                  const newQuantites = [...rapportFormData.quantitesEffectives]
                                  newQuantites[index].quantite_effective = parseInt(e.target.value) || 0
                                  newQuantites[index].ecart = newQuantites[index].quantite_effective - newQuantites[index].quantite_prevue
                                  setRapportFormData({...rapportFormData, quantitesEffectives: newQuantites})
                                }}
                                className="w-20 px-2 py-1 text-center border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                                min="0"
                                max={manuel.quantite_prevue}
                              />
                            </td>
                            <td className="px-4 py-3">
                              <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${
                                manuel.ecart < 0 
                                  ? 'bg-red-100 text-red-800' 
                                  : manuel.ecart > 0 
                                    ? 'bg-green-100 text-green-800' 
                                    : 'bg-gray-100 text-gray-800'
                              }`}>
                                {manuel.ecart > 0 ? '+' : ''}{manuel.ecart}
                              </span>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* Section 3: Fiches d'émargement */}
                <div className="bg-white rounded-lg border border-gray-200">
                  <div className="px-6 py-4 border-b border-gray-200 bg-gray-50">
                    <h4 className="text-lg font-semibold text-gray-900 flex items-center gap-2">
                      📝 Fiches d'Émargement (Obligatoire)
                    </h4>
                  </div>
                  <div className="p-6 space-y-6">
                    {/* Fiche d'émargement */}
                    <div className="space-y-3">
                      <label className="block text-sm font-medium text-gray-700 flex items-center gap-2">
                        <span className="text-red-500">*</span>
                        Fiche d'Émargement avec Signatures
                      </label>
                      <div className="flex items-center gap-3">
                        <input
                          type="file"
                          accept=".pdf,.doc,.docx,.jpg,.jpeg,.png"
                          onChange={(e) => {
                            const file = e.target.files?.[0]
                            if (file) {
                              setRapportFormData({
                                ...rapportFormData, 
                                ficheEmargement: file,
                                ficheEmargementName: file.name
                              })
                            }
                          }}
                          className="flex-1 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        />
                        {rapportFormData.ficheEmargementName && (
                          <span className="inline-flex px-3 py-1 text-sm font-medium text-green-800 bg-green-100 rounded-full">
                            ✓ {rapportFormData.ficheEmargementName}
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-gray-500">
                        Fiche d'émargement signée par les responsables EPP avec les quantités effectives reçues
                      </p>
                    </div>

                    {/* Observations */}
                    <div className="space-y-3">
                      <label className="block text-sm font-medium text-gray-700">
                        Observations sur la Distribution
                      </label>
                      <textarea
                        value={rapportFormData.observations}
                        onChange={(e) => setRapportFormData({...rapportFormData, observations: e.target.value})}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        rows={3}
                        placeholder="Observations sur la distribution, conditions de réception, etc."
                      />
                    </div>
                  </div>
                </div>

                {/* Section 4: Actions */}
                <div className="flex justify-between items-center pt-6 border-t border-gray-200">
                  <div className="text-sm text-gray-600">
                    <span className="text-red-500">*</span> Champs obligatoires
                  </div>
                  
                  <div className="flex gap-3">
                    <button
                      onClick={() => setShowRapportModal(false)}
                      className="px-6 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:border-transparent transition-colors"
                    >
                      Annuler
                    </button>
                    <button
                      onClick={() => {
                        // Validation des champs obligatoires
                        if (!rapportFormData.ficheEmargement) {
                          toast.error("Veuillez charger la fiche d'émargement")
                          return
                        }

                        // Mettre à jour la distribution
                        const distributionIndex = mockDistributionsEnCours.findIndex(d => d.id === selectedDistribution.id)
                        if (distributionIndex !== -1) {
                          mockDistributionsEnCours[distributionIndex] = {
                            ...mockDistributionsEnCours[distributionIndex],
                            statut: "TERMINEE",
                            manuels: rapportFormData.quantitesEffectives.map((q: any) => ({
                              ...q,
                              quantite_distribuee: q.quantite_effective
                            })),
                            documents: {
                              ...mockDistributionsEnCours[distributionIndex].documents,
                              fiche_reception: rapportFormData.ficheEmargementName
                            }
                          }
                        }
                        
                        // Fermer la modal
                        setShowRapportModal(false)
                        setSelectedDistribution(null)
                        
                        // Message de succès
                        toast.success("Rapport de fin de distribution généré avec succès !")
                      }}
                      className="px-6 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                      disabled={!rapportFormData.ficheEmargement}
                    >
                      Finaliser la Distribution
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </MainLayout>
  )
}
