"use client"

import { useState, useEffect, useMemo, useRef } from "react"
import type { ReactNode } from "react"
import MainLayout from "../../components/layout/main-layout"
import { useAuth } from "../providers"
import { catalogueService } from "@/lib/services/catalogue.service"
import { mouvementService } from "@/lib/services/mouvement.service"
import { receptionService } from "@/lib/services/reception.service"
import { distributionService } from "@/lib/services/distribution.service"
import { besoinsService } from "@/lib/services/besoins.service"
import { structuresService } from "@/lib/services/structures.service"
import { manuelsDepuisCatalogueMouvements } from "@/lib/reception-manuels-display"
import {
  hasReceptionSyntheseTerritoriale,
  normalizeReceptionFlowType,
} from "@/lib/reception-flow"
import {
  canAccessReceptionsModule,
  filterReceptionsListForRole,
  shouldFetchReceptionsOnUserReady,
} from "@/lib/reception-profile-access"
import { groupDistributionsByIeppThenEpp } from "@/lib/distribution-synthese-grouping"
import {
  inferSoleIeppIdFromIeppRows,
  pickTerritorialIeppLabel,
  resolveTerritorialIeppGroupKey,
  sortTerritorialIeppKeys,
} from "@/lib/reception-territorial-grouping"
import { aggregateConsolidationEppByNiveauMatiere } from "@/lib/reception-besoin-quantities"
import { isConsultationOnlyRole } from "@/lib/utils/role-access"
import { toast } from "sonner"
import ValidationIEPPModal from "@/components/modals/ValidationIEPPModal"
import { useAnneesScolaires } from "@/hooks/use-annees-scolaires"
import {
  PlusIcon,
  TruckIcon,
  CheckCircleIcon,
  ClockIcon,
  XCircleIcon,
  XMarkIcon,
  DocumentTextIcon,
  CubeIcon,
  BuildingOfficeIcon,
  ClipboardDocumentListIcon,
  WrenchScrewdriverIcon,
  ExclamationTriangleIcon,
  ChevronDownIcon,
  ChevronRightIcon,
} from "@heroicons/react/24/outline"

// Données mockées supprimées - utilisation des vraies données du backend

// ✅ UTILITAIRE : Parser une date au format français "DD/MM/YYYY HH:mm" ou "DD/MM/YYYY"
const parseFrenchDate = (dateStr: string | null | undefined): Date | null => {
  if (!dateStr) return null
  
  try {
    const str = dateStr.toString().trim()
    
    // Format français "DD/MM/YYYY HH:mm" ou "DD/MM/YYYY"
    if (str.includes('/')) {
      const parts = str.split(' ')
      const datePart = parts[0] // "DD/MM/YYYY"
      const timePart = parts[1] || '00:00' // "HH:mm" ou "00:00"
      
      const [day, month, year] = datePart.split('/')
      const [hours, minutes] = timePart.split(':')
      
      // Créer une date au format ISO (YYYY-MM-DDTHH:mm:ss)
      const isoDate = `${year}-${month.padStart(2, '0')}-${day.padStart(2, '0')}T${(hours || '00').padStart(2, '0')}:${(minutes || '00').padStart(2, '0')}:00`
      const parsedDate = new Date(isoDate)
      
      if (!isNaN(parsedDate.getTime())) {
        return parsedDate
      }
    }
    
    // Essayer de parser comme date ISO ou autre format standard
    const parsedDate = new Date(str)
    if (!isNaN(parsedDate.getTime())) {
      return parsedDate
    }
    
    return null
  } catch (error) {
    console.warn('⚠️ Erreur lors du parsing de la date:', error, 'Date originale:', dateStr)
    return null
  }
}

// ✅ UTILITAIRE : Formater une date pour l'affichage (format français)
const formatFrenchDate = (dateStr: string | null | undefined): string => {
  const date = parseFrenchDate(dateStr)
  if (!date) return '-'
  
  try {
    return date.toLocaleDateString('fr-FR', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit'
    })
  } catch (error) {
    console.warn('⚠️ Erreur lors du formatage de la date:', error)
    return '-'
  }
}

// ✅ UTILITAIRE : Convertir une date française en format ISO (YYYY-MM-DD) pour les inputs
const frenchDateToISO = (dateStr: string | null | undefined): string => {
  const date = parseFrenchDate(dateStr)
  if (!date) return new Date().toISOString().split('T')[0]
  
  try {
    return date.toISOString().split('T')[0]
  } catch (error) {
    console.warn('⚠️ Erreur lors de la conversion en ISO:', error)
    return new Date().toISOString().split('T')[0]
  }
}

export default function ReceptionsPage() {
  const { user } = useAuth()
  const consultationOnly = useMemo(() => isConsultationOnlyRole(user?.role?.code), [user?.role?.code])
  const { anneesScolaires, loading: anneesLoading } = useAnneesScolaires()
  const [showNouvelleReceptionModal, setShowNouvelleReceptionModal] = useState(false)
  const [showDetailsModal, setShowDetailsModal] = useState(false)
  const [selectedReception, setSelectedReception] = useState<any>(null)
  const [receptionType, setReceptionType] = useState<'IEPP' | 'EPP'>('IEPP')
  const [receptions, setReceptions] = useState<any[]>([])
  const [receptionFormData, setReceptionFormData] = useState<any>({
    type: 'IEPP',
    ecole: '',
    date_reception: new Date().toISOString().split('T')[0],
    bordereau: '',
    bordereauFile: null,
    bordereauFileName: '',
    observations: '',
    manuels: []
  })
  
  // États pour le nouveau flux
  const [availableCatalogues, setAvailableCatalogues] = useState<any[]>([])
  const [selectedCatalogueId, setSelectedCatalogueId] = useState<string>('')
  const [catalogueMatieres, setCatalogueMatieres] = useState<any[]>([])
  const [stockDisponible, setStockDisponible] = useState<any>({})
  const [loadingCatalogues, setLoadingCatalogues] = useState(false)
  const [loadingStocks, setLoadingStocks] = useState(false)
  const [selectedCatalogues, setSelectedCatalogues] = useState<any[]>([])
  const [currentCatalogueData, setCurrentCatalogueData] = useState<any>(null)
  const [error, setError] = useState<string | null>(null)
  // ✅ NOUVEAU : États pour charger depuis Besoin approuvé
  const [showLoadFromBesoinModal, setShowLoadFromBesoinModal] = useState(false)
  const [besoinsApprouves, setBesoinsApprouves] = useState<any[]>([])
  const [loadingBesoinsApprouves, setLoadingBesoinsApprouves] = useState(false)
  const [selectedBesoinId, setSelectedBesoinId] = useState<number | null>(null)
  // ✅ NOUVEAU : États pour la validation IEPP des réceptions EPP
  const [showValidationModal, setShowValidationModal] = useState(false)
  const [selectedReceptionForValidation, setSelectedReceptionForValidation] = useState<any>(null)
  const [validatingReceptionIds, setValidatingReceptionIds] = useState<Set<number>>(new Set())
  /** DRENA / DAF : bloc distributions (DRENA = périmètre API ; DAF = vue large côté liste) */
  const [drenaDistributions, setDrenaDistributions] = useState<any[]>([])
  const [loadingDrenaDistributions, setLoadingDrenaDistributions] = useState(false)
  const [drenaIeppLabelsForDist, setDrenaIeppLabelsForDist] = useState<Record<number, string>>({})
  /** DRENA / DAF : groupes IEPP repliés dans le tableau (Set = ids repliés) */
  const [collapsedTerritorialIepp, setCollapsedTerritorialIepp] = useState<Set<number>>(new Set())
  /** Clés `ieppId-schoolId` : lignes réceptions masquées sous l’en-tête établissement */
  const [collapsedTerritorialSchool, setCollapsedTerritorialSchool] = useState<Set<string>>(new Set())
  // ID du catalogue en cours d'édition dans le tableau (null = mode ajout)
  const [editingCatalogueId, setEditingCatalogueId] = useState<number | string | null>(null)
  // Message d'erreur pour la modal d'alerte personnalisée (remplace window.alert)
  const [errorAlertMessage, setErrorAlertMessage] = useState<string | null>(null)
  // Ref pour stocker les quantités depuis besoin (chargées à la sélection du catalogue, pas en amont)
  const quantitesDepuisBesoinRef = useRef<Map<string, any[]> | null>(null)

  const toggleTerritorialIepp = (ieppId: number) => {
    setCollapsedTerritorialIepp((prev) => {
      const next = new Set(prev)
      if (next.has(ieppId)) next.delete(ieppId)
      else next.add(ieppId)
      return next
    })
  }

  const toggleTerritorialSchool = (key: string) => {
    setCollapsedTerritorialSchool((prev) => {
      const next = new Set(prev)
      if (next.has(key)) next.delete(key)
      else next.add(key)
      return next
    })
  }

  const closeReceptionModal = () => {
    setEditingCatalogueId(null)
    setShowNouvelleReceptionModal(false)
  }

  // Catalogues qui ne sont pas encore dans le tableau → affichés dans le dropdown (re-sélectionnables après "Retirer")
  const cataloguesDisponiblesPourSelect = useMemo(() => {
    return availableCatalogues.filter(
      (c: any) => !selectedCatalogues.some((sc: any) => Number(sc.id) === Number(c.id))
    )
  }, [availableCatalogues, selectedCatalogues])

  // Charger les réceptions au montage:
  // - DRENA / DAF: dès que l'utilisateur est disponible (synthèse)
  // - autres rôles: quand structure.id est disponible
  useEffect(() => {
    if (!user) return
    if (shouldFetchReceptionsOnUserReady(user?.role?.code, user?.structure?.id)) {
      fetchReceptions()
    }
  }, [user?.id, user?.role?.code, user?.structure?.id])

  useEffect(() => {
    if (!hasReceptionSyntheseTerritoriale(user?.role?.code)) {
      setDrenaDistributions([])
      setLoadingDrenaDistributions(false)
      return
    }
    let cancelled = false
    setLoadingDrenaDistributions(true)
    distributionService
      .getDistributionsPaginated(1, 500, {})
      .then((res) => {
        if (!cancelled && res.success && Array.isArray(res.data)) {
          setDrenaDistributions(res.data)
        }
      })
      .finally(() => {
        if (!cancelled) setLoadingDrenaDistributions(false)
      })
    return () => {
      cancelled = true
    }
  }, [user?.role?.code, user?.id])

  useEffect(() => {
    if (!hasReceptionSyntheseTerritoriale(user?.role?.code) || !drenaDistributions.length) return
    const parentIds = Array.from(
      new Set(
        drenaDistributions
          .map((d: any) => Number(d.structureParentId))
          .filter((id: number) => id > 0 && !Number.isNaN(id))
      )
    )
    if (!parentIds.length) return
    let cancelled = false
    ;(async () => {
      const next: Record<number, string> = {}
      await Promise.all(
        parentIds.map(async (ieppId) => {
          try {
            const res = await structuresService.getIeppById(ieppId)
            const row = (res as any)?.items?.[0]
            if (row?.id != null) {
              next[Number(row.id)] = String(row.libelle || row.code || `IEPP #${row.id}`)
            }
          } catch {
            /* ignore */
          }
        })
      )
      if (!cancelled) setDrenaIeppLabelsForDist(next)
    })()
    return () => {
      cancelled = true
    }
  }, [user?.role?.code, drenaDistributions])

  // ✅ Grouper les besoins approuvés par IEPP (structure + année) → une seule ligne par IEPP
  // Doit être appelé AVANT tout return conditionnel (Rules of Hooks)
  const besoinsGroupesParIepp = useMemo(() => {
    if (!besoinsApprouves?.length) return []
    const byKey = new Map<string, { structureId: number; structure: string; annee: string; besoins: any[]; dateApprobation: string }>()
    for (const b of besoinsApprouves) {
      const sid = b.structureId ?? b._rawData?.structureId ?? 0
      const annee = b.anneeScolaireLibelle || b.anneeScolaireCode || b._rawData?.anneeScolaireLibelle || '-'
      const key = `${sid}-${annee}`
      if (!byKey.has(key)) {
        byKey.set(key, {
          structureId: sid,
          structure: b.structureAdministrativeLibelle || b._rawData?.structureAdministrativeLibelle || '-',
          annee,
          besoins: [],
          dateApprobation: b.dateApprobation || ''
        })
      }
      const row = byKey.get(key)!
      row.besoins.push(b)
      if (b.dateApprobation && (!row.dateApprobation || b.dateApprobation > row.dateApprobation)) {
        row.dateApprobation = b.dateApprobation
      }
    }
    return Array.from(byKey.values())
  }, [besoinsApprouves])

  // Vérification après tous les hooks
  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <p className="text-gray-600">Chargement...</p>
        </div>
      </div>
    )
  }

  // Vérifier les droits d'accès (aligné menu sidebar Réceptions)
  if (!canAccessReceptionsModule(user.role.code)) {
    return (
      <MainLayout>
        <div className="min-h-screen flex items-center justify-center">
          <div className="text-center">
            <XCircleIcon className="h-16 w-16 text-red-500 mx-auto mb-4" />
            <h2 className="text-xl font-semibold text-gray-900 mb-2">Accès Restreint</h2>
            <p className="text-gray-600">Vous n'avez pas les droits pour accéder à ce module.</p>
          </div>
        </div>
      </MainLayout>
    )
  }

  const getStatusBadge = (statut: string) => {
    switch (statut) {
      case "BROUILLON":
        return <span className="badge-secondary">📝 Brouillon</span>
      case "SAISIE":
        return <span className="badge-warning">📝 Saisie</span>
      case "EN_ATTENTE":
        return <span className="badge-warning">⏳ En attente</span>
      case "BESOIN_CONSOLIDE":
        return <span className="badge-secondary">📋 Besoin consolidé (mouvement)</span>
      case "BESOIN_APPROUVE":
        return <span className="badge-warning">✔️ Besoin approuvé (mouvement)</span>
      case "BESOIN_SAISI":
        return <span className="badge-secondary">📝 Besoin saisi</span>
      case "VALIDEE":
        return <span className="badge-success">✅ Validée</span>
      case "CONFIRMEE_IEPP":
        return <span className="badge-success">✅ Confirmée IEPP</span>
      case "CONFIRMEE_EPP":
        return <span className="badge-success">✅ Confirmée EPP</span>
      case "CONFIRMEE":
        return <span className="badge-success">✅ Confirmée</span>
      case "ANNULEE":
        return <span className="badge-error">❌ Annulée</span>
      default:
        return <span className="badge-secondary">{statut}</span>
    }
  }

  const getReceptionTypeLabel = (type: string) => {
    switch (type) {
      case "IEPP":
        return "Livreur → IEPP"
      case "EPP":
        return "IEPP → EPP"
      default:
        return type
    }
  }

  // Type de réception selon l'utilisateur : Directeur EPP → toujours EPP (IEPP→EPP) ; sinon selon structure (IEPP → Livreur→IEPP)
  const getReceptionTypeForCurrentUser = (): 'IEPP' | 'EPP' =>
    user?.role?.code === 'DIRECTEUR' ? 'EPP' : (user?.structure?.type === 'IEPP' ? 'IEPP' : 'EPP')

  /** Année à utiliser pour /catalogue/getByCriteria (alignée sur le besoin, le mouvement ou l'année courante). */
  const resolveAnneeIdForCatalogues = (explicit?: number | null): number | undefined => {
    if (explicit != null && explicit > 0) return explicit
    const courante = anneesScolaires.find((a: any) => a.estCourante)?.id
    if (courante != null && courante > 0) return courante
    const first = anneesScolaires[0]?.id
    return first != null && first > 0 ? first : undefined
  }

  // Fonction pour récupérer les catalogues actifs (filtrés par année côté API quand l'id est connu)
  // Retourne les catalogues pour permettre leur utilisation immédiate (éviter race condition avec setState async)
  const fetchAvailableCatalogues = async (anneeScolaireId?: number | null): Promise<any[]> => {
    setLoadingCatalogues(true)
    setError(null)
    
    try {
      const result = await catalogueService.getCataloguesActifs(resolveAnneeIdForCatalogues(anneeScolaireId))
      
      if (result.hasError) {
        throw new Error(result.status?.message || 'Erreur lors de la récupération des catalogues')
      }

      if (!result.items || !Array.isArray(result.items)) {
        if (result.status?.message) throw new Error(result.status.message)
        throw new Error('Aucune donnée reçue du serveur')
      }

      const mappedCatalogues = result.items.map((catalogue: any) => ({
        id: catalogue.id,
        libelle: catalogue.libelle,
        code: catalogue.code,
        anneeScolaire: catalogue.anneeScolaire?.libelle || catalogue.anneeScolaireLibelle || 'N/A',
        niveauScolaire: catalogue.niveauScolaire?.libelle || catalogue.niveauScolaireLibelle || 'N/A',
        niveauCode: catalogue.niveauScolaire?.code || catalogue.niveauScolaireCode || 'N/A',
        niveauScolaireCode: catalogue.niveauScolaire?.code || catalogue.niveauScolaireCode || 'N/A',
        niveauId: catalogue.niveauScolaire?.id ?? catalogue.idNiveauScolaire ?? catalogue.matieres?.[0]?.idNiveauScolaire,
        statut: catalogue.statut || 'ACTIF',
        couleur: getCatalogueColor(catalogue.niveauScolaire?.code || catalogue.niveauScolaireCode),
        icone: getCatalogueIcon(catalogue.niveauScolaire?.code || catalogue.niveauScolaireCode),
        matieres: catalogue.matieres || []
      }))

      setAvailableCatalogues(mappedCatalogues)
      if (mappedCatalogues.length === 0) toast.warning("Aucun catalogue actif trouvé")
      return mappedCatalogues
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Erreur inconnue'
      setError(errorMessage)
      toast.error(`Erreur lors du chargement des catalogues: ${errorMessage}`)
      setAvailableCatalogues([])
      return []
    } finally {
      setLoadingCatalogues(false)
    }
  }

  // Fonction utilitaire pour obtenir la couleur du catalogue
  const getCatalogueColor = (niveauCode: string) => {
    const colorMap: { [key: string]: string } = {
      'CP1': 'bg-blue-500',
      'CP2': 'bg-green-500',
      'CE1': 'bg-purple-500',
      'CE2': 'bg-orange-500',
      'CM1': 'bg-red-500',
      'CM2': 'bg-indigo-500'
    }
    return colorMap[niveauCode] || 'bg-gray-500'
  }

  // Fonction utilitaire pour obtenir l'icône du catalogue
  const getCatalogueIcon = (niveauCode: string) => {
    const iconMap: { [key: string]: string } = {
      'CP1': '📚',
      'CP2': '📖',
      'CE1': '📘',
      'CE2': '📗',
      'CM1': '📙',
      'CM2': '📕'
    }
    return iconMap[niveauCode] || '📄'
  }

  // Fonction pour sélectionner un catalogue depuis le select
  const handleCatalogueSelect = async (catalogueId: string) => {
    if (!catalogueId) return
    
    const catalogue = availableCatalogues.find(c => c.id.toString() === catalogueId)
    if (!catalogue) return
    
    // 🔍 DEBUG: Vérifier le catalogue avant de le stocker
    console.log('🔍 DEBUG handleCatalogueSelect - Catalogue trouvé:', catalogue)
    console.log(`   → niveauId: ${catalogue.niveauId} (type: ${typeof catalogue.niveauId})`)
    console.log(`   → niveauScolaire: ${catalogue.niveauScolaire}`)
    console.log(`   → niveauCode: ${catalogue.niveauCode}`)
    
    setSelectedCatalogueId(catalogueId)
    setCurrentCatalogueData(catalogue)
    setEditingCatalogueId(null) // sortir du mode édition si on choisit un autre catalogue
    
    const niveauCode = catalogue?.niveauCode ?? catalogue?.niveauScolaireCode
    await fetchCatalogueMatieres(parseInt(catalogueId), niveauCode || undefined)
  }

  // Fonction pour récupérer les matières d'un catalogue
  // Si niveauCode fourni et quantitesDepuisBesoinRef contient des données, injecte les quantités dans manuels
  const fetchCatalogueMatieres = async (catalogueId: number, niveauCode?: string) => {
    try {
      const result = await catalogueService.getMatieresByCatalogue(catalogueId)
      
      if (result.hasError) {
        throw new Error(result.status?.message || 'Erreur lors de la récupération des matières')
      }

      const matieres = result.items?.map((cm: any) => ({
        id: cm.matiereId,
        code: cm.matiereCode,
        libelle: cm.matiereLibelle,
        quantite_prevue: 0,
        idNiveauScolaire: cm.idNiveauScolaire,
        niveauScolaireLibelle: cm.niveauScolaireLibelle,
        niveauScolaireCode: cm.niveauScolaireCode
      })) || []

      setCatalogueMatieres(matieres)

      // Injecter les quantités depuis besoin si disponibles pour ce niveau
      const refMap = quantitesDepuisBesoinRef.current
      const itemsBesoin = niveauCode && refMap?.get(niveauCode)
      const refKeys = refMap ? Array.from(refMap.keys()) : []
      console.log(`🔍 [QUANTITÉS] fetchCatalogueMatieres - catalogueId=${catalogueId} niveauCode=${niveauCode ?? 'non fourni'} ref=${refMap ? 'présent' : 'vide'} clésRef=[${refKeys.join(', ')}] itemsBesoin=${itemsBesoin?.length ?? 0}`)
      if (itemsBesoin && itemsBesoin.length > 0) {
        const manuels = matieres.map((m: any) => {
          const fromBesoin = itemsBesoin.find((i: any) => i.matiereId === m.id)
          if (fromBesoin) {
            const qApp = Number(fromBesoin.quantite_approuvee)
            const qAppSafe = Number.isFinite(qApp) && qApp >= 0 ? qApp : 0
            const qPrev = fromBesoin.quantite_prevue ?? 0
            return {
              matiereId: m.id,
              code: m.code,
              libelle: m.libelle,
              titre: m.libelle,
              quantite_prevue: qPrev,
              quantite_approuvee: qAppSafe,
              quantite_recue: fromBesoin.quantite_recue ?? (qAppSafe > 0 ? qAppSafe : 0),
              idNiveauScolaire: m.idNiveauScolaire ?? fromBesoin.idNiveauScolaire,
              niveauScolaireLibelle: m.niveauScolaireLibelle ?? fromBesoin.niveauScolaireLibelle,
              niveauScolaireCode: m.niveauScolaireCode ?? fromBesoin.niveauScolaireCode,
              isFromBesoin: true
            }
          }
          return {
            matiereId: m.id,
            code: m.code,
            libelle: m.libelle,
            titre: m.libelle,
            quantite_prevue: 0,
            quantite_recue: 0,
            idNiveauScolaire: m.idNiveauScolaire,
            niveauScolaireLibelle: m.niveauScolaireLibelle,
            niveauScolaireCode: m.niveauScolaireCode
          }
        })
        setReceptionFormData((prev: any) => ({ ...prev, manuels }))
      } else {
        setReceptionFormData((prev: any) => ({ ...prev, manuels: [] }))
      }
      
      await fetchStockDisponible(matieres)
      
    } catch (error) {
      console.error('Erreur lors de la récupération des matières du catalogue:', error)
      toast.error("Erreur lors du chargement des matières du catalogue")
      setCatalogueMatieres([])
    }
  }

  // Fonction pour ajouter le catalogue sélectionné au tableau
  const addCatalogueToTable = () => {
    if (!currentCatalogueData || !selectedCatalogueId) {
      toast.error("Veuillez sélectionner un catalogue")
      return
    }

    const isUpdateMode = editingCatalogueId != null

    // En mode ajout : vérifier que le catalogue n'est pas déjà dans le tableau
    if (!isUpdateMode) {
      const exists = selectedCatalogues.some(c => Number(c.id) === Number(currentCatalogueData.id))
      if (exists) {
        toast.error("Ce catalogue est déjà sélectionné")
        return
      }
    }

    // ✅ Ajouter le catalogue au tableau avec les quantités saisies (confirmation IEPP)
    // Inclure toutes les matières avec quantite_recue > 0, avec quantite_prevue également
    const quantitesSaisies = receptionFormData.manuels
      .filter((m: any) => m.quantite_recue > 0)
      .map((m: any) => ({
        matiereId: m.matiereId,
        code: m.code,
        libelle: m.libelle || m.titre,
        quantite_prevue: m.quantite_prevue || 0,
        quantite_approuvee: m.quantite_approuvee ?? m.quantite_recue ?? 0,
        quantite_recue: m.quantite_recue || 0,
        idNiveauScolaire: m.idNiveauScolaire,
        niveauScolaireLibelle: m.niveauScolaireLibelle,
        niveauScolaireCode: m.niveauScolaireCode,
        isFromBesoin: m.isFromBesoin || false // ✅ Préserver le flag isFromBesoin
      }))
    
    // ✅ NOUVEAU : Validation quantite_prevue obligatoire pour réception directe
    const isReceptionDirecte = !receptionFormData.id || receptionFormData.id === 0
    if (isReceptionDirecte && quantitesSaisies.length > 0) {
      const manuelsSansQuantitePrevue = quantitesSaisies.filter((q: any) => !q.quantite_prevue || q.quantite_prevue <= 0)
      if (manuelsSansQuantitePrevue.length > 0) {
        toast.error(`Veuillez saisir la quantité demandée pour : ${manuelsSansQuantitePrevue.map((q: any) => q.libelle || q.code).join(', ')}`)
        return
      }
      
      // Validation : quantite_recue ne peut pas dépasser quantite_prevue
      const manuelsAvecQuantiteRecueSuperieure = quantitesSaisies.filter((q: any) => q.quantite_recue > q.quantite_prevue)
      if (manuelsAvecQuantiteRecueSuperieure.length > 0) {
        toast.error(`La quantité reçue ne peut pas dépasser la quantité demandée pour : ${manuelsAvecQuantiteRecueSuperieure.map((q: any) => q.libelle || q.code).join(', ')}`)
        return
      }
    }
    
    const catalogueWithQuantities = {
      ...currentCatalogueData,
      quantitesSaisies
    }

    if (isUpdateMode) {
      const idEdit = Number(editingCatalogueId)
      setSelectedCatalogues(prev => prev.filter(c => Number(c.id) !== idEdit).concat([catalogueWithQuantities]))
      setEditingCatalogueId(null)
      toast.success("Ligne mise à jour")
    } else {
      setSelectedCatalogues(prev => [...prev, catalogueWithQuantities])
      toast.success("Catalogue ajouté au tableau")
    }
    
    // Réinitialiser la sélection
    setSelectedCatalogueId('')
    setCurrentCatalogueData(null)
    setCatalogueMatieres([])
    setReceptionFormData((prev: any) => ({ ...prev, manuels: [] }))
  }

  // Fonction pour supprimer un catalogue du tableau (comparaison id normalisée number/string)
  // Réinitialise la sélection du formulaire si on retire le catalogue actuellement sélectionné,
  // pour que le catalogue retiré réapparaisse dans le select et soit re-sélectionnable.
  const removeCatalogueFromTable = (catalogueId: number | string) => {
    const idNum = Number(catalogueId)
    const wasCurrentSelection = Number(selectedCatalogueId) === idNum
    setSelectedCatalogues(prev => prev.filter(c => Number(c.id) !== idNum))
    if (wasCurrentSelection) {
      setSelectedCatalogueId('')
      setCurrentCatalogueData(null)
      setCatalogueMatieres([])
      setReceptionFormData((prev: any) => ({ ...prev, manuels: [] }))
      setEditingCatalogueId(null)
    }
    toast.success("Catalogue retiré du tableau")
  }

  // Recharger une ligne du tableau dans le formulaire pour édition (bouton Editer)
  const handleEditCatalogueRow = (catalogue: any) => {
    setEditingCatalogueId(catalogue.id)
    setCurrentCatalogueData({
      id: catalogue.id,
      niveauScolaire: catalogue.niveauScolaire,
      niveauCode: catalogue.niveauCode ?? catalogue.niveauScolaire,
      code: catalogue.code ?? catalogue.niveauCode ?? String(catalogue.id),
      niveauId: catalogue.idNiveauScolaire,
      icone: catalogue.icone ?? '📚'
    })
    setSelectedCatalogueId(String(catalogue.id))
    const manuels = (catalogue.quantitesSaisies || []).map((q: any) => ({
      matiereId: q.matiereId,
      code: q.code ?? q.matiereCode ?? '',
      libelle: q.libelle ?? '',
      titre: q.libelle ?? '',
      quantite_prevue: q.quantite_prevue ?? 0,
      quantite_approuvee: q.quantite_approuvee ?? q.quantite_recue ?? 0,
      quantite_recue: q.quantite_recue ?? 0,
      idNiveauScolaire: q.idNiveauScolaire,
      niveauScolaireLibelle: q.niveauScolaireLibelle,
      niveauScolaireCode: q.niveauScolaireCode,
      isFromBesoin: q.isFromBesoin ?? false
    }))
    setReceptionFormData((prev: any) => ({ ...prev, manuels }))
    setCatalogueMatieres(manuels.map((m: any) => ({
      id: m.matiereId,
      code: m.code,
      libelle: m.libelle,
      quantite_prevue: m.quantite_prevue,
      idNiveauScolaire: m.idNiveauScolaire,
      niveauScolaireLibelle: m.niveauScolaireLibelle,
      niveauScolaireCode: m.niveauScolaireCode
    })))
    toast.success("Modifiez les quantités puis cliquez sur « Mettre à jour »")
  }

  // Fonction pour récupérer les stocks disponibles depuis le backend
  const fetchStockDisponible = async (matieres: any[]) => {
    setLoadingStocks(true)
    
    try {
      if (!user?.structure?.id) {
        console.warn('Structure ID non disponible pour récupérer les stocks')
        // Initialiser avec des stocks à 0
        const defaultStock: { [key: number]: number } = {}
        matieres.forEach(matiere => {
          defaultStock[matiere.id] = 0
        })
        setStockDisponible(defaultStock)
        return
      }

      // ✅ CORRECTION : Récupérer les vrais stocks depuis le backend
      const stockMap: { [key: number]: number } = {}
      
      // Pour les réceptions IEPP, le stock est toujours 0 (on ajoute au stock)
      if (receptionFormData.type === "IEPP" || receptionFormData.type === "LIVREUR_IEPP") {
        matieres.forEach(matiere => {
          stockMap[matiere.id] = 0
        })
        setStockDisponible(stockMap)
        console.log('✅ Mode réception IEPP : Stock initialisé à 0 (les quantités seront ajoutées au stock)')
        return
      }
      
      // Pour les réceptions EPP, ne plus récupérer le stock EPP (non pertinent)
      // La validation du stock IEPP est gérée automatiquement par createReceptionEPP
      // Pour une réception, on augmente le stock, donc afficher le stock actuel n'a pas de sens
      if (receptionFormData.type === "EPP") {
        console.log('ℹ️ Réception EPP : Stock non affiché (validation stock IEPP gérée par createReceptionEPP)')
        // Initialiser à 0 pour l'affichage (sera mis à jour après réception)
        matieres.forEach(matiere => {
          stockMap[matiere.id] = 0
        })
        
        setStockDisponible(stockMap)
        console.log('✅ Stocks récupérés avec succès:', stockMap)
      } else {
        // Pour les autres types, initialiser à 0
        matieres.forEach(matiere => {
          stockMap[matiere.id] = 0
        })
        setStockDisponible(stockMap)
      }
      
    } catch (error) {
      console.error('❌ Erreur lors de la récupération du stock:', error)
      // En cas d'erreur, initialiser avec des stocks à 0
      const defaultStock: { [key: number]: number } = {}
      matieres.forEach(matiere => {
        defaultStock[matiere.id] = 0
      })
      setStockDisponible(defaultStock)
      
      // Afficher un avertissement si ce n'est pas critique
      if (receptionFormData.type === "EPP") {
        toast.warning("Impossible de récupérer les stocks depuis le backend. Les valeurs affichées sont à 0.")
      }
    } finally {
      setLoadingStocks(false)
    }
  }

  // Fonction pour charger les réceptions depuis le backend
  const fetchReceptions = async () => {
    try {
      console.log('🔍 Récupération des réceptions pour la structure:', user.structure?.id)
      console.log('🔍 Détails utilisateur complet:', {
        userId: user.id,
        userRole: user.role?.code,
        structureId: user.structure?.id,
        structureLibelle: user.structure?.libelle,
        structureType: user.structure?.type
      })

      const roleCode = user.role?.code
      let baseMouvements: any[] = []

      // ✅ DRENA / DAF: fusion des types (DRENA = périmètre API ; DAF = pas de filtre structure sur ces appels)
      if (hasReceptionSyntheseTerritoriale(roleCode)) {
        const [respIepp, respEpp, respEppLegacy] = await Promise.all([
          mouvementService.getMouvementsByCriteria({ typeMouvement: 'RECEPTION_IEPP' }),
          mouvementService.getMouvementsByCriteria({ typeMouvement: 'RECEPTION_EPP' }),
          mouvementService.getMouvementsByCriteria({ typeMouvement: 'EPP' }),
        ])

        const list = [
          ...(respIepp.success && respIepp.data ? respIepp.data : []),
          ...(respEpp.success && respEpp.data ? respEpp.data : []),
          ...(respEppLegacy.success && respEppLegacy.data ? respEppLegacy.data : []),
        ]

        const byId = new Map<number, any>()
        for (const m of list) {
          if (m?.id != null) byId.set(Number(m.id), m)
        }
        baseMouvements = Array.from(byId.values())
      } else {
        // Directeur → RECEPTION_EPP (IEPP→EPP) ; rôle IEPP / structure IEPP → RECEPTION_IEPP
        const typeMouvement = getReceptionTypeForCurrentUser() === 'IEPP' ? 'RECEPTION_IEPP' : 'RECEPTION_EPP'
        const response = await mouvementService.getMouvementsByCriteria({
          idStructure: user.structure?.id,
          typeMouvement
        })
        baseMouvements = response.success && response.data ? response.data : []
      }

      console.log('📊 Données brutes des réceptions:', baseMouvements)
      
      if (baseMouvements && baseMouvements.length) {
        console.log('🔍 Nombre de réceptions trouvées:', baseMouvements.length)
        
        // Récupérer les détails complets pour chaque réception (avec catalogues et quantités)
        const detailedReceptions = await Promise.all(
          baseMouvements.map(async (reception: any) => {
            try {
              const detailsResponse = await mouvementService.getMouvementWithDetails(reception.id);
              if (detailsResponse.success && detailsResponse.data) {
                console.log(`✅ Détails récupérés pour mouvement ${reception.id}:`, detailsResponse.data);
                return detailsResponse.data;
              } else {
                console.warn(`⚠️ Impossible de récupérer les détails pour mouvement ${reception.id}`);
                return reception; // Fallback sur les données initiales
              }
            } catch (error) {
              console.error(`❌ Erreur détails mouvement ${reception.id}:`, error);
              return reception; // Fallback sur les données initiales
            }
          })
        );

        const filesByReceptionId = new Map<number, any[]>()
        if (hasReceptionSyntheseTerritoriale(roleCode)) {
          const fileResults = await Promise.all(
            detailedReceptions
              .filter((r: any) => r?.id != null)
              .map(async (r: any) => {
                try {
                  const fr = await receptionService.getReceptionFiles(Number(r.id))
                  return {
                    id: Number(r.id),
                    files: fr.success && fr.data ? fr.data : [],
                  }
                } catch {
                  return { id: Number(r.id), files: [] as any[] }
                }
              })
          )
          for (const fr of fileResults) {
            filesByReceptionId.set(fr.id, fr.files)
          }
        }

        // ✅ DRENA / DAF: précharger les libellés IEPP (pour regroupement)
        const ieppLibellesById = new Map<number, string>()
        if (hasReceptionSyntheseTerritoriale(roleCode)) {
          const ieppIds = Array.from(new Set(
            detailedReceptions
              .map((r: any) => {
                const flow = normalizeReceptionFlowType(r)
                if (flow === 'IEPP') return Number(r?.idStructure)
                if (flow === 'EPP') return Number(r?.idIEPPParent)
                return null
              })
              .filter((x: any) => x != null && !Number.isNaN(Number(x)))
              .map((x: any) => Number(x))
          ))

          await Promise.all(
            ieppIds.map(async (ieppId: number) => {
              try {
                const res = await structuresService.getIeppById(ieppId)
                const row = (res as any)?.items?.[0]
                if (row?.id != null) {
                  ieppLibellesById.set(Number(row.id), String(row.libelle || row.code || `IEPP #${row.id}`))
                }
              } catch {
                // fallback silencieux
              }
            })
          )
        }
        
        // Transformer les données backend vers le format frontend
        const transformedReceptions = detailedReceptions.map((reception: any, index: number) => {
          const flow = normalizeReceptionFlowType(reception)
          let typeReception =
            flow !== "UNKNOWN"
              ? flow
              : (reception.typeMouvement?.replace("RECEPTION_", "") ||
                  reception.typeReception ||
                  (reception.idIEPPParent ? "EPP" : "IEPP"))
          if (typeReception !== "IEPP" && typeReception !== "EPP") {
            typeReception = reception.idIEPPParent ? "EPP" : "IEPP"
          }
          const attachedFiles = hasReceptionSyntheseTerritoriale(roleCode)
            ? (filesByReceptionId.get(Number(reception.id)) ?? [])
            : undefined

          console.log(`📋 Réception ${index + 1}:`, {
            id: reception.id,
            typeMouvement: reception.typeMouvement,
            typeReception: typeReception,
            idStructure: reception.idStructure,
            userStructureId: user.structure?.id,
            userRole: user.role?.code
          })
          if (typeReception === "IEPP") {
            console.log(`✅ Transformation IEPP pour réception ${reception.id}`)
            
            // Transformer catalogueMouvements + matiereQuantites en manuels
            const receptionAny = reception as any; // Type assertion pour accéder à catalogueMouvements
            console.log(`🔍 DEBUG - Réception ${reception.id} catalogueMouvements:`, receptionAny.catalogueMouvements);
            const manuels = manuelsDepuisCatalogueMouvements(receptionAny.catalogueMouvements)
            console.log(`✅ Manuels transformés (dédup):`, manuels);
            
            return {
              id: reception.id,
              reference: reception.numeroBordereau || `REC-IEPP-${reception.codeStructure || reception.idStructure || 'X'}-${String(reception.id).slice(-3)}`,
              type: typeReception,
              livreur: "Livreur Standard",
              date_reception: reception.dateMouvement || reception.dateReception,
              statut: reception.statut,
              confirme_par: `${user.nom} ${user.prenoms} (${user.structure?.libelle})`,
              idStructure: reception.idStructure,
              structureLibelle: reception.structureLibelle,
              ieppId: reception.idStructure,
              ieppLibelle: hasReceptionSyntheseTerritoriale(roleCode)
                ? (ieppLibellesById.get(Number(reception.idStructure)) || reception.structureLibelle || `IEPP #${reception.idStructure}`)
                : undefined,
              documents: {
                bordereau_livraison: "bordereau.pdf" // TODO: Récupérer depuis les fichiers
              },
              observations: reception.observation,
              manuels: manuels,
              attachedFiles,
            }
          } else if (typeReception === "EPP") {
            console.log(`✅ Transformation EPP pour réception ${reception.id}`)
            
            // Transformer catalogueMouvements + matiereQuantites en manuels
            const receptionAny = reception as any; // Type assertion pour accéder à catalogueMouvements
            const manuels = manuelsDepuisCatalogueMouvements(receptionAny.catalogueMouvements)
            
            return {
              id: reception.id,
              reference: reception.numeroBordereau || `REC-EPP-${reception.codeStructure || reception.idStructure || 'X'}-${String(reception.id).slice(-3)}`,
              type: typeReception,
              ecole: (reception as any).structureLibelle || user.structure?.libelle || '',
              date_reception: reception.dateMouvement || reception.dateReception,
              statut: reception.statut,
              confirme_par: `${user.nom} ${user.prenoms} (${user.structure?.libelle})`,
              idStructure: reception.idStructure,
              structureLibelle: (reception as any).structureLibelle,
              idIEPPParent: reception.idIEPPParent,
              ieppId: reception.idIEPPParent,
              ieppLibelle: hasReceptionSyntheseTerritoriale(roleCode)
                ? (ieppLibellesById.get(Number(reception.idIEPPParent)) || (reception.idIEPPParent ? `IEPP #${reception.idIEPPParent}` : 'IEPP (inconnu)'))
                : undefined,
              documents: {
                bordereau_livraison: "bordereau.pdf" // TODO: Récupérer depuis les fichiers
              },
              observations: reception.observation,
              manuels: manuels,
              attachedFiles,
            }
          } else {
            console.log(`⚠️ Type de réception inconnu: ${typeReception} pour réception ${reception.id}`)
            return {
              id: reception.id,
              reference: `REC-UNKNOWN-${user.structure?.libelle?.split(" ")[1] || "COC"}-${new Date().getFullYear()}-${String(reception.id).slice(-3)}`,
              type: typeReception,
              ecole: user.structure?.libelle || '',
              date_reception: reception.dateMouvement || reception.dateReception,
              statut: reception.statut,
              confirme_par: `${user.nom} ${user.prenoms} (${user.structure?.libelle})`,
              documents: {
                bordereau_livraison: "bordereau.pdf"
              },
              observations: reception.observation,
              manuels: [],
              attachedFiles,
            }
          }
        })
        
        console.log('📋 Réceptions transformées:', transformedReceptions)
        console.log('🎯 Nombre de réceptions à afficher:', transformedReceptions.length)
        console.log('📊 Détails de la première réception:', transformedReceptions[0])
        
        setReceptions(transformedReceptions)
        
        // Vérifier l'état après setState
        setTimeout(() => {
          console.log('🔄 État des réceptions après setState:', receptions)
        }, 100)
      } else {
        console.log('⚠️ Aucune réception trouvée (liste vide ou erreur API)')
        setReceptions([])
      }
    } catch (error) {
      console.error('❌ Erreur lors du chargement des réceptions:', error)
      // En cas d'erreur, garder les données mockées existantes
    }
  }

  // Fonction helper pour transformer les dates au format backend
  const formatDateForBackend = (dateString: string) => {
    if (!dateString) return ''
    
    // Vérifier si la date est valide
    const date = new Date(dateString)
    if (isNaN(date.getTime())) {
      console.error('Date invalide:', dateString)
      return ''
    }
    
    // Convertir de "2025-09-25" vers "25/09/2025 00:00:00" (format attendu par le backend)
    const day = String(date.getDate()).padStart(2, '0')
    const month = String(date.getMonth() + 1).padStart(2, '0')
    const year = date.getFullYear()
    
    const formattedDate = `${day}/${month}/${year} 00:00:00`
    console.log(`Date formatée: ${dateString} → ${formattedDate}`)
    
    return formattedDate
  }

  // Fonction helper pour transformer les données frontend vers le format backend
  const transformReceptionData = () => {
    console.log('🔍 receptionFormData.date_reception:', receptionFormData.date_reception)
    // ✅ NOUVEAU : Inclure l'ID du Mouvement si présent (pour mise à jour depuis Besoin)
    console.log('🔍 receptionFormData.id (Mouvement):', receptionFormData.id)
    console.log('🔍 formatDateForBackend result:', formatDateForBackend(receptionFormData.date_reception))
    console.log('🔍 Détails structure utilisateur:')
    console.log('  - ID Structure:', user.structure?.id)
    console.log('  - Libellé structure:', user.structure?.libelle)
    console.log('  - Type structure:', user.structure?.type)
    console.log('  - Code structure:', user.structure?.code)
    
    // Convertir IEPP/EPP en RECEPTION_IEPP/RECEPTION_EPP
    const typeMouvement = receptionFormData.type === 'IEPP' ? 'RECEPTION_IEPP' : 'RECEPTION_EPP';
    
    // Déterminer l'année scolaire à utiliser :
    // 1. Si le formulaire a déjà une anneeScolaireId explicite, essayer de la retrouver dans la liste
    // 2. Sinon, utiliser l'année marquée comme courante (estCourante)
    // 3. En dernier recours, prendre la première année disponible
    const currentAnnee =
      (receptionFormData.anneeScolaireId &&
        anneesScolaires.find((a: any) => a.id === receptionFormData.anneeScolaireId)) ||
      anneesScolaires.find((a: any) => a.estCourante) ||
      (anneesScolaires.length > 0 ? anneesScolaires[0] : null)

    const baseData: any = {
      typeMouvement: typeMouvement,
      observation: receptionFormData.observations || '',
      numeroBordereau: receptionFormData.bordereau,
      dateMouvement: formatDateForBackend(receptionFormData.date_reception),
      idStructure: receptionFormData.idStructure || user.structure?.id || 0,
      anneeScolaireId: currentAnnee?.id || receptionFormData.anneeScolaireId || 1
    }

    // ✅ NOUVEAU : Inclure l'ID du Mouvement si présent (pour mise à jour depuis Besoin)
    if (receptionFormData.id) {
      baseData.id = receptionFormData.id
      console.log('✅ ID Mouvement inclus pour mise à jour:', receptionFormData.id)
    }

    return baseData
  }

  // Fonction helper pour transformer les détails de réception en format manuels
  const transformReceptionDetailsToManuels = (receptionDetails: any) => {
    if (receptionDetails?.catalogueMouvements?.length) {
      return manuelsDepuisCatalogueMouvements(receptionDetails.catalogueMouvements)
    }
    const manuels: any[] = []
    if (receptionDetails.catalogueReceptions && receptionDetails.catalogueReceptions.length > 0) {
      receptionDetails.catalogueReceptions.forEach((catalogueReception: any) => {
        if (catalogueReception.matiereQuantites && catalogueReception.matiereQuantites.length > 0) {
          catalogueReception.matiereQuantites.forEach((matiereQuantite: any) => {
            manuels.push({
              code: matiereQuantite.matiereCode || `MAT-${matiereQuantite.idMatiere}`,
              titre: matiereQuantite.matiereLibelle || `Matière ${matiereQuantite.idMatiere}`,
              niveau: catalogueReception.catalogueLibelle || 'Niveau inconnu',
              quantite_prevue: matiereQuantite.quantitePrevue || 0,
              quantite_recue: matiereQuantite.quantiteRecue || 0,
              ecart: matiereQuantite.ecart || 0
            })
          })
        }
      })
    }
    console.log('📚 Manuels transformés:', manuels)
    return manuels
  }

  const handleNouvelleReception = async () => {
    if (consultationOnly) {
      toast.error("Création ou modification de réception indisponible en mode consultation.")
      return
    }
    // Déterminer le type de réception selon le rôle
    if (user.role.code === "IEPP") {
      setReceptionType("IEPP")
    } else if (user.role.code === "DIRECTEUR") {
      setReceptionType("EPP")
    }

    // ✅ La validation du stock IEPP est maintenant gérée par le backend (createReceptionEPP)
    // Le modal s'ouvre toujours, et le backend retournera un message d'erreur si le stock est insuffisant

    // Récupérer tous les catalogues actifs disponibles (si pas déjà fait)
    if (availableCatalogues.length === 0) {
      await fetchAvailableCatalogues()
    }

    // Initialiser les données du formulaire (Directeur → EPP, sinon selon structure)
    // Pour Directeur EPP : ecole = EPP du directeur (user.epp), pas l'IEPP (user.structure)
    const ecoleInitiale = user?.role?.code === 'DIRECTEUR'
      ? ((user as any).epp?.libelle || '')
      : (user.structure?.type === 'EPP' ? (user.structure?.libelle || '') : '')
    setReceptionFormData({
      type: getReceptionTypeForCurrentUser(),
      ecole: ecoleInitiale,
      date_reception: new Date().toISOString().split('T')[0],
      bordereau: '',
      bordereauFile: null,
      bordereauFileName: '',
      observations: '',
      manuels: []
    })

    // Réinitialiser les états
    setSelectedCatalogueId('')
    setCurrentCatalogueData(null)
    setCatalogueMatieres([])
    setSelectedCatalogues([])
    // ✅ Nettoyer la ref quantités (pas de chargement depuis besoin)
    quantitesDepuisBesoinRef.current = null

    setShowNouvelleReceptionModal(true)
  }

  // ✅ NOUVEAU : Charger les Besoins approuvés
  const fetchBesoinsApprouves = async () => {
    setLoadingBesoinsApprouves(true)
    try {
      // ✅ IMPORTANT : Utiliser roleCode comme structureType
      // Le backend attend "IEPP" ou "EPP", donc on mappe DIRECTEUR → EPP
      const roleCode = user?.role?.code
      
      if (!roleCode) {
        toast.error('Rôle utilisateur non défini. Impossible de récupérer les besoins approuvés.')
        setLoadingBesoinsApprouves(false)
        return
      }
      
      // Mapper le roleCode vers structureType attendu par le backend
      let structureType: string | undefined
      if (roleCode === "IEPP") {
        structureType = "IEPP"
      } else if (roleCode === "DIRECTEUR") {
        structureType = "EPP" // DIRECTEUR correspond à une structure EPP
      } else {
        toast.error('Seuls les utilisateurs IEPP ou DIRECTEUR peuvent charger des besoins approuvés.')
        setLoadingBesoinsApprouves(false)
        return
      }
      
      console.log('🔵 [FETCH-BESOINS] structureId:', user?.structure?.id)
      console.log('🔵 [FETCH-BESOINS] roleCode:', roleCode)
      console.log('🔵 [FETCH-BESOINS] structureType (mappé):', structureType)
      
      const result = await besoinsService.getBesoinsApprouves(
        user?.structure?.id,
        resolveAnneeIdForCatalogues(receptionFormData.anneeScolaireId),
        structureType // structureType mappé depuis roleCode (IEPP ou DIRECTEUR → EPP)
      )
      
      if (result.success && result.data) {
        setBesoinsApprouves(result.data)
        // Modal déjà ouverte ; les données sont chargées au clic sur Charger
      } else {
        toast.error(result.message || 'Aucun Besoin approuvé trouvé')
      }
    } catch (error: any) {
      console.error('❌ Erreur lors de la récupération des Besoins approuvés:', error)
      toast.error('Erreur lors de la récupération des Besoins approuvés')
    } finally {
      setLoadingBesoinsApprouves(false)
    }
  }

  // ✅ Charger depuis un groupe IEPP : pré-remplit TOUS les niveaux et matières via getConsolidationDetails
  const handleLoadFromBesoinGroup = async (groupe: any) => {
    if (consultationOnly) {
      toast.error("Chargement depuis besoin indisponible en mode consultation.")
      return
    }
    const firstBesoin = groupe.besoins?.[0]
    if (!firstBesoin?.id) return
    try {
      toast.loading('Chargement des détails depuis le besoin approuvé...')
      const mouvementResult = await mouvementService.loadFromBesoin(firstBesoin.id)
      if (!mouvementResult.success || !mouvementResult.data) {
        toast.error(mouvementResult.message || 'Erreur lors du chargement')
        return
      }
      const mouvement = mouvementResult.data as any
      let cataloguesDisponibles = availableCatalogues
      if (cataloguesDisponibles.length === 0) {
        cataloguesDisponibles = await fetchAvailableCatalogues(
          mouvement.anneeScolaireId ?? firstBesoin.anneeScolaireId
        )
      }
      const dateReception = frenchDateToISO(mouvement.dateMouvement)
      const baseFormData = {
        id: mouvement.id,
        type: getReceptionTypeForCurrentUser(),
        ecole: mouvement.structureLibelle || '',
        date_reception: dateReception,
        bordereau: mouvement.numeroBordereau || '',
        bordereauFile: null,
        bordereauFileName: '',
        observations: mouvement.observation || '',
        manuels: [],
        anneeScolaireId: mouvement.anneeScolaireId,
        idStructure: mouvement.idStructure
      }
      setReceptionFormData(baseFormData)
      setSelectedCatalogues([])
      if (user?.role?.code === "IEPP" && groupe.structureId) {
        const consolidationResult = await besoinsService.getConsolidationDetails(groupe.structureId)
        if (consolidationResult.success && consolidationResult.data?.length) {
          // 🔍 LOG: Données consolidation (EPP → besoinDetails par niveau/matière)
          console.log('🔍 [QUANTITÉS] === getConsolidationDetails ===', consolidationResult.data.length, 'besoins EPP')
          consolidationResult.data.forEach((b: any, bi: number) => {
            (b.besoinDetails || []).forEach((d: any, di: number) => {
              console.log(
                `🔍 [QUANTITÉS] EPP[${bi}] BesoinDetail[${di}]: niveau=${d.niveauScolaireId} matiere=${d.matiereId} demandée=${d.quantiteConsolidee ?? d.quantiteNet ?? d.quantiteBrute} approuvée=${d.quantiteApprouvee}`
              )
            })
          })
          const aggregated = aggregateConsolidationEppByNiveauMatiere(consolidationResult.data)
          const byNiveau = new Map<number, { niveauLibelle: string; niveauCode: string; items: any[] }>()
          for (const m of aggregated.values()) {
            if (!byNiveau.has(m.niveauId)) {
              byNiveau.set(m.niveauId, { niveauLibelle: m.niveauLibelle, niveauCode: m.niveauCode, items: [] })
            }
            byNiveau.get(m.niveauId)!.items.push({
              matiereId: m.matiereId,
              code: m.matiereCode,
              libelle: m.matiereLibelle,
              quantite_prevue: m.quantiteDemandee,
              quantite_approuvee: m.quantiteApprouvee,
              quantite_recue: m.quantiteApprouvee,
              idNiveauScolaire: m.niveauId,
              niveauScolaireLibelle: m.niveauLibelle,
              niveauScolaireCode: m.niveauCode,
              isFromBesoin: true
            })
          }
          // 🔍 LOG: Agrégation finale (clé niveau-matière → quantité)
          console.log(
            '🔍 [QUANTITÉS] aggregated:',
            Array.from(aggregated.entries()).map(
              ([k, v]) =>
                `${k} (${v.niveauCode}-${v.matiereCode}) → demandée=${v.quantiteDemandee} approuvée=${v.quantiteApprouvee}`
            )
          )
          console.log('🔍 [QUANTITÉS] byNiveau:', Array.from(byNiveau.entries()).map(([nivId, v]) => `niveau=${nivId} items=${v.items.length} ${v.items.map((i: any) => `${i.libelle}:${i.quantite_prevue}`).join('; ')}`))
          // ✅ Flux séquentiel : ne pas pré-ajouter les catalogues ; stocker les quantités pour injection à la sélection
          const quantitesByNiveauCode = new Map<string, any[]>()
          for (const [, { niveauCode, items }] of byNiveau) {
            if (niveauCode && items.length > 0) {
              quantitesByNiveauCode.set(niveauCode, items)
            }
          }
          quantitesDepuisBesoinRef.current = quantitesByNiveauCode
          setSelectedCatalogues([])
          setSelectedCatalogueId('')
          setCurrentCatalogueData(null)
          setCatalogueMatieres([])
          setReceptionFormData((prev: any) => ({ ...prev, manuels: [] }))
          setShowLoadFromBesoinModal(false)
          setShowNouvelleReceptionModal(true)
          toast.success('Sélectionnez un catalogue pour charger ses quantités, puis ajoutez-le au tableau')
        } else {
          await handleLoadFromBesoin(firstBesoin.id)
        }
      } else {
        await handleLoadFromBesoin(firstBesoin.id)
      }
    } catch (e: any) {
      console.error(e)
      toast.error(e?.message || 'Erreur lors du chargement')
    } finally {
      toast.dismiss()
    }
  }

  // ✅ NOUVEAU : Charger un Mouvement depuis un Besoin approuvé
  const handleLoadFromBesoin = async (besoinId: number) => {
    if (consultationOnly) {
      toast.error("Chargement depuis besoin indisponible en mode consultation.")
      return
    }
    try {
      toast.loading('Chargement du Mouvement depuis le Besoin approuvé...')
      
      const mouvementResult = await mouvementService.loadFromBesoin(besoinId)
      
      if (!mouvementResult.success || !mouvementResult.data) {
        toast.error(mouvementResult.message || 'Erreur lors du chargement du Mouvement')
        return
      }

      const mouvement = mouvementResult.data

      let cataloguesDisponibles = availableCatalogues
      if (cataloguesDisponibles.length === 0) {
        console.log('📚 Chargement des catalogues disponibles (année mouvement)...')
        cataloguesDisponibles = await fetchAvailableCatalogues(mouvement.anneeScolaireId)
      }
      console.log('📦 Mouvement chargé:', mouvement)
      
      // ✅ NOUVEAU : Charger les détails du besoin pour récupérer quantiteConsolidee et quantiteApprouvee
      const besoinDetailsResult = await besoinsService.getDetails(besoinId)
      // ✅ Correction: indexer par (niveau, matière) pour avoir des quantités distinctes par niveau
      let besoinDetailsMap: Map<string, { quantiteConsolidee: number; quantiteApprouvee: number }> = new Map()
      
      if (besoinDetailsResult.success && besoinDetailsResult.data?.besoinDetails) {
        // 🔍 LOG: Détails bruts reçus du backend (vérifier niveauScolaireId par détail)
        console.log('🔍 [QUANTITÉS] === BesoinDetails bruts (getDetails) ===')
        besoinDetailsResult.data.besoinDetails.forEach((bd: any, i: number) => {
          console.log(`🔍 [QUANTITÉS] BesoinDetail[${i}]: niveauScolaireId=${bd.niveauScolaireId}, matiereId=${bd.matiereId}, matiere=${bd.matiereLibelle || bd.matiereCode}, quantiteApprouvee=${bd.quantiteApprouvee}, quantiteConsolidee=${bd.quantiteConsolidee}`)
        })
        besoinDetailsResult.data.besoinDetails.forEach((bd: any) => {
          const niveauId = bd.niveauScolaireId ?? 0
          const matiereId = bd.matiereId
          if (!matiereId) return
          const key = `${niveauId}-${matiereId}`
          besoinDetailsMap.set(key, {
            quantiteConsolidee: bd.quantiteConsolidee || 0,
            quantiteApprouvee: bd.quantiteApprouvee || 0
          })
        })
        // 🔍 LOG: Map construite (clé = niveauId-matiereId)
        console.log('🔍 [QUANTITÉS] besoinDetailsMap clés:', Array.from(besoinDetailsMap.entries()).map(([k, v]) => `${k} → prevue=${v.quantiteConsolidee} recue=${v.quantiteApprouvee}`))
      }
      
      // ✅ Réinitialiser selectedCatalogues - le catalogue sera ajouté uniquement après "Ajouter au Tableau"
      setSelectedCatalogues([])
      
      // 3. Pré-remplir le formulaire avec les données du Mouvement
      // ✅ IMPORTANT : Inclure l'ID du Mouvement pour que le backend puisse le mettre à jour
      // ✅ CORRECTION : Parser correctement la date au format français "DD/MM/YYYY HH:mm"
      const dateReception = frenchDateToISO(mouvement.dateMouvement)
      
      // 4. Construire quantitesByNiveauCode à partir de TOUS les catalogueMouvements (CP2, CE1, etc.)
      const quantitesByNiveauCode = new Map<string, any[]>()
      const mouvementAny = mouvement as any; // Type assertion pour accéder à catalogueMouvements
      if (mouvementAny.catalogueMouvements && Array.isArray(mouvementAny.catalogueMouvements) && mouvementAny.catalogueMouvements.length > 0) {
        // 🔍 LOG: Structure du mouvement
        console.log('🔍 [QUANTITÉS] Mouvement.catalogueMouvements:', mouvementAny.catalogueMouvements?.map((cm: any, i: number) => `[${i}] catalogueId=${cm.idCatalogue} niveauId=${cm.idNiveauScolaire} niveauCode=${cm.matiereQuantites?.[0]?.niveauScolaireCode ?? cm.niveauScolaireCode} matiereQuantites=${cm.matiereQuantites?.length}`))
        for (const catalogueMouvement of mouvementAny.catalogueMouvements) {
          if (!catalogueMouvement.matiereQuantites?.length) continue
          const niveauCode = catalogueMouvement.matiereQuantites[0]?.niveauScolaireCode ?? catalogueMouvement.niveauScolaireCode
          if (!niveauCode) continue
          const manuelsPourNiveau = catalogueMouvement.matiereQuantites.map((mq: any) => {
            const niveauId = mq.idNiveauScolaire ?? 0
            const key = `${niveauId}-${mq.idMatiere}`
            const besoinDetail = besoinDetailsMap.get(key)
            const quantiteConsolidee = besoinDetail?.quantiteConsolidee || mq.quantitePrevue || 0
            const quantiteApprouvee = besoinDetail?.quantiteApprouvee || mq.quantiteRecue || mq.quantitePrevue || 0
            return {
              matiereId: mq.idMatiere,
              code: mq.matiereCode || '',
              titre: mq.matiereLibelle || '',
              quantite_prevue: quantiteConsolidee,
              quantite_approuvee: quantiteApprouvee,
              quantite_recue: quantiteApprouvee,
              idNiveauScolaire: mq.idNiveauScolaire,
              niveauScolaireLibelle: mq.niveauScolaireLibelle,
              niveauScolaireCode: mq.niveauScolaireCode,
              isFromBesoin: true
            }
          })
          quantitesByNiveauCode.set(niveauCode, manuelsPourNiveau)
          console.log(`🔍 [QUANTITÉS] Niveau ${niveauCode}: ${manuelsPourNiveau.length} matières`, manuelsPourNiveau)
        }
        quantitesDepuisBesoinRef.current = quantitesByNiveauCode
        setSelectedCatalogueId('')
        setCurrentCatalogueData(null)
        setCatalogueMatieres([])
      } else {
        toast.warning('Aucun catalogue trouvé dans le Mouvement')
        setReceptionFormData({
          id: mouvement.id,
          type: getReceptionTypeForCurrentUser(),
          ecole: mouvement.structureLibelle || '',
          date_reception: dateReception,
          bordereau: mouvement.numeroBordereau || '',
          bordereauFile: null,
          bordereauFileName: '',
          observations: mouvement.observation || '',
          manuels: [],
          anneeScolaireId: mouvement.anneeScolaireId,
          idStructure: mouvement.idStructure
        })
        toast.dismiss()
        return
      }
      
      // 6. Mettre à jour le formulaire (manuels vides : injectés à la sélection du catalogue)
      setReceptionFormData({
        id: mouvement.id, // ✅ ID du Mouvement pour mise à jour
        type: getReceptionTypeForCurrentUser(),
        ecole: mouvement.structureLibelle || '',
        date_reception: dateReception,
        bordereau: mouvement.numeroBordereau || '',
        bordereauFile: null,
        bordereauFileName: '',
        observations: mouvement.observation || '',
        manuels: [], // ✅ Injectés à la sélection du catalogue depuis quantitesDepuisBesoinRef
        anneeScolaireId: mouvement.anneeScolaireId, // ✅ Pour le backend
        idStructure: mouvement.idStructure // ✅ Pour le backend
      })
      
      toast.success('Mouvement chargé depuis le Besoin approuvé avec succès')
      setShowLoadFromBesoinModal(false)
      setShowNouvelleReceptionModal(true)
    } catch (error: any) {
      console.error('❌ Erreur lors du chargement depuis Besoin:', error)
      toast.error('Erreur lors du chargement du Mouvement depuis le Besoin')
    } finally {
      toast.dismiss()
    }
  }

  // Fonction pour vérifier si une réception peut être annulée (uniquement en statut SAISIE)
  const canAnnulerReception = (reception: any) => {
    if (consultationOnly) return false
    const isCancelable = reception.statut === "SAISIE" || reception.statut === "BROUILLON"
    if (!isCancelable) return false
    switch (user.role.code) {
      case "ADMIN":
      case "DAF":
        return true
      case "IEPP":
        return reception.type === "IEPP"
      case "DIRECTEUR":
        return reception.type === "EPP"
      default:
        return false
    }
  }

  // ✅ SUPPRIMÉ : validateStocksBeforeReception n'est plus nécessaire
  // La validation du stock est maintenant gérée automatiquement par le backend
  // - Pour réception EPP : createReceptionEPP valide le stock IEPP via StockDisponible
  // - Pour réception IEPP : pas de validation nécessaire (on augmente le stock)

  // Fonction pour gérer l'annulation d'une réception
  const handleAnnulationReception = async (reception: { id: number; statut?: string }) => {
    if (consultationOnly) {
      toast.error("Annulation indisponible en mode consultation.")
      return
    }
    const receptionId = reception.id
    const isSaisie = reception.statut === "SAISIE"
    try {
      console.log('🔄 Début de l\'annulation de la réception:', receptionId)
      const messageConfirmation = isSaisie
        ? 'Êtes-vous sûr de vouloir annuler cette saisie ? Aucun stock n\'a été impacté.'
        : 'Êtes-vous sûr de vouloir annuler cette réception ? Cette action restaurera les stocks et ne pourra pas être annulée.'
      const confirmation = window.confirm(messageConfirmation)
      if (!confirmation) {
        console.log('❌ Annulation annulée par l\'utilisateur')
        return
      }
      const raison = window.prompt('Veuillez indiquer la raison de l\'annulation :')
      if (!raison || raison.trim() === '') {
        toast.error('La raison de l\'annulation est obligatoire')
        return
      }
      console.log('📝 Raison de l\'annulation:', raison)
      const response = await receptionService.annulerReception(receptionId, raison.trim())
      
      if (response.success) {
        console.log('✅ Réception annulée avec succès')
        toast.success('Réception annulée avec succès')
        
        // Envoyer notification email d'annulation
        try {
          const notificationResponse = await receptionService.sendNotificationEmail(
            'RECEPTION_ANNULEE',
            receptionId,
            user.email || '',
            { raison: raison.trim() }
          )
          
          if (notificationResponse.success) {
            console.log('📧 Notification d\'annulation envoyée')
          } else {
            console.warn('⚠️ Erreur envoi notification:', notificationResponse.message)
          }
        } catch (error) {
          console.warn('⚠️ Erreur envoi notification email:', error)
        }
        
        // Recharger la liste des réceptions
        await fetchReceptions()
      } else {
        console.error('❌ Erreur lors de l\'annulation:', response.message)
        toast.error(`Erreur lors de l'annulation: ${response.message}`)
      }
      
    } catch (error) {
      console.error('❌ Erreur lors de l\'annulation de la réception:', error)
      toast.error('Erreur lors de l\'annulation de la réception')
    }
  }

  // Charger une réception pour édition :
  // - IEPP : SAISIE uniquement
  // - EPP  : BROUILLON uniquement
  const handleLoadReceptionForEdit = async (reception: { id: number }) => {
    if (consultationOnly) {
      toast.error("Modification de réception indisponible en mode consultation.")
      return
    }
    try {
      toast.loading('Chargement de la réception...')
      const detailsResponse = await mouvementService.getMouvementWithDetails(reception.id)
      toast.dismiss()
      if (!detailsResponse.success || !detailsResponse.data) {
        toast.error(detailsResponse.message || 'Erreur lors du chargement')
        return
      }
      const data = detailsResponse.data as any
      const typeMouvement = String(data.typeMouvement ?? '')
      const isIeppDraft = data.statut === 'SAISIE' && (typeMouvement === 'IEPP' || typeMouvement === 'RECEPTION_IEPP')
      const isEppEditable =
        data.statut === 'BROUILLON' &&
        (typeMouvement === 'EPP' || typeMouvement === 'RECEPTION_EPP')
      if (!isIeppDraft && !isEppEditable) {
        toast.error("Cette réception n'est pas modifiable dans son statut actuel.")
        return
      }
      const dateStr = data.dateMouvement
        ? (parseFrenchDate(data.dateMouvement)
            ? (() => {
                const d = parseFrenchDate(data.dateMouvement)!
                return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`
              })()
            : '')
        : new Date().toISOString().split('T')[0]
      const catalogues: any[] = []
      if (data.catalogueMouvements && Array.isArray(data.catalogueMouvements)) {
        for (const cm of data.catalogueMouvements) {
          const idCatalogue = cm.idCatalogue ?? cm.catalogue?.id ?? cm.id
          const quantitesSaisies = (cm.matiereQuantites || []).map((mq: any) => ({
            matiereId: mq.idMatiere,
            quantite_recue: mq.quantiteRecue ?? 0,
            quantite_prevue: mq.quantitePrevue ?? mq.quantiteRecue ?? 0,
            libelle: mq.matiereLibelle ?? '',
            code: mq.matiereCode ?? '',
            idNiveauScolaire: mq.idNiveauScolaire,
            niveauScolaireCode: mq.niveauScolaireCode,
            niveauScolaireLibelle: mq.niveauScolaireLibelle,
            matiereCode: mq.matiereCode
          }))
          catalogues.push({
            id: idCatalogue,
            niveauScolaire: cm.catalogueLibelle ?? cm.niveauScolaireLibelle ?? 'N/A',
            niveauCode: cm.matiereQuantites?.[0]?.niveauScolaireCode,
            idNiveauScolaire: cm.matiereQuantites?.[0]?.idNiveauScolaire,
            quantitesSaisies
          })
        }
      }
      setReceptionFormData({
        id: data.id,
        type: (typeMouvement === 'EPP' || typeMouvement === 'RECEPTION_EPP') ? 'EPP' : 'IEPP',
        idStructure: data.idStructure ?? data.structure?.id ?? user.structure?.id,
        bordereau: data.numeroBordereau ?? '',
        date_reception: dateStr,
        observations: data.observation ?? '',
        anneeScolaireId: data.anneeScolaireId,
        bordereauFile: null,
        bordereauFileName: '',
        ecole: '',
        manuels: []
      })
      setSelectedCatalogues(catalogues)
      quantitesDepuisBesoinRef.current = null
      setEditingCatalogueId(null)
      setShowNouvelleReceptionModal(true)
      toast.success('Réception chargée. Modifiez puis enregistrez.')
    } catch (error) {
      toast.dismiss()
      console.error('Erreur chargement réception pour édition:', error)
      toast.error('Erreur lors du chargement de la réception')
    }
  }

  // Valider une réception IEPP en SAISIE → VALIDEE (création des MouvementStock côté backend)
  // ✅ RÈGLE : à la validation finale, le numéro de bordereau + le fichier bordereau doivent exister
  const handleValidateReceptionIEPPSaisie = async (reception: { id: number }) => {
    if (consultationOnly) {
      toast.error("Validation indisponible en mode consultation.")
      return
    }
    if (validatingReceptionIds.has(reception.id)) return
    setValidatingReceptionIds((prev) => {
      const next = new Set(prev)
      next.add(reception.id)
      return next
    })
    try {
      // Vérifier la présence du numéro de bordereau
      const detailsResponse = await mouvementService.getMouvementWithDetails(reception.id)
      const mouvement = detailsResponse.success ? (detailsResponse.data as any) : null
      const numeroBordereau = (mouvement?.numeroBordereau ?? '').toString().trim()

      // Vérifier la présence du fichier bordereau
      const filesResponse = await receptionService.getReceptionFiles(reception.id)
      const files = filesResponse.success ? (filesResponse.data as any[]) : []
      const hasBordereauFile = Array.isArray(files) && files.some((f: any) => String(f?.fileType ?? '').toUpperCase() === 'BORDEREAU')

      if (!numeroBordereau || !hasBordereauFile) {
        toast.error("Avant validation, veuillez renseigner le numéro de bordereau et joindre le fichier bordereau.")
        await handleLoadReceptionForEdit({ id: reception.id })
        return
      }

      const ok = window.confirm('Valider cette saisie ? Les stocks seront mis à jour et la réception ne pourra plus être modifiée.')
      if (!ok) return

      const response = await receptionService.validateReception(reception.id, 'IEPP')
      if (response.success) {
        toast.success('Réception validée. Les stocks ont été mis à jour.')
        await fetchReceptions()
      } else {
        toast.error(response.message || 'Erreur lors de la validation')
      }
    } catch (error) {
      console.error('Erreur validation réception IEPP (SAISIE):', error)
      toast.error('Erreur lors de la validation de la réception')
    } finally {
      setValidatingReceptionIds((prev) => {
        const next = new Set(prev)
        next.delete(reception.id)
        return next
      })
    }
  }

  // ✅ NOUVEAU : Fonction pour gérer la validation IEPP d'une réception EPP
  const handleValidateReception = async (reception: any) => {
    if (consultationOnly) {
      toast.error("Validation indisponible en mode consultation.")
      return
    }
    if (validatingReceptionIds.has(reception.id)) return
    setValidatingReceptionIds((prev) => {
      const next = new Set(prev)
      next.add(reception.id)
      return next
    })
    try {
      console.log('🔍 Préparation validation IEPP pour réception:', reception.id)
      
      // Récupérer les détails complets de la réception pour le modal
      const detailsResponse = await mouvementService.getMouvementWithDetails(reception.id)
      
      if (detailsResponse.success && detailsResponse.data) {
        console.log('📊 Détails récupérés pour validation:', detailsResponse.data)
        
        // Transformer les données pour le modal ValidationIEPPModal
        // Utiliser 'as any' car MouvementResponse n'a pas toutes les propriétés typées mais elles existent à l'exécution
        const data = detailsResponse.data as any
        const receptionForValidation = {
          id: data.id,
          reference: data.reference || `REC-${data.id}`,
          typeMouvement: data.typeMouvement,
          numeroBordereau: data.numeroBordereau || '',
          dateMouvement: data.dateMouvement || '',
          observation: data.observation || '',
          statut: data.statut,
          structure: data.structure ? {
            id: data.structure.id,
            libelle: data.structure.libelle || data.structureLibelle,
            code: data.structure.code || ''
          } : null,
          structureLibelle: data.structureLibelle,
          structureType: data.structureType,
          matiereQuantites: data.matiereQuantites || [],
          catalogueMouvements: data.catalogueMouvements || [],
          anneeScolaireId: data.anneeScolaireId
        }
        
        setSelectedReceptionForValidation(receptionForValidation)
        setShowValidationModal(true)
      } else {
        console.error('❌ Erreur récupération détails pour validation:', detailsResponse.message)
        toast.error(`Erreur lors de la récupération des détails: ${detailsResponse.message}`)
      }
    } catch (error) {
      console.error('❌ Erreur lors de la préparation de la validation:', error)
      toast.error('Erreur lors de la préparation de la validation')
    } finally {
      setValidatingReceptionIds((prev) => {
        const next = new Set(prev)
        next.delete(reception.id)
        return next
      })
    }
  }

  // ✅ NOUVEAU : Fonction callback après validation réussie
  const handleValidationSuccess = async () => {
    console.log('✅ Validation réussie - Rechargement des réceptions')
    await fetchReceptions()
    setShowValidationModal(false)
    setSelectedReceptionForValidation(null)
  }

  const handleCorrectStockData = async () => {
    if (!confirm('Êtes-vous sûr de vouloir corriger les données de stock ? Cette opération peut prendre quelques instants.')) {
      return
    }

    try {
      const response = await receptionService.correctStockData()
      if (response.success) {
        toast.success(
          <div className="max-w-md">
            <div className="font-semibold text-green-800 mb-2">✅ Correction terminée</div>
            <div className="text-sm text-green-700">
              {response.message}
            </div>
            <div className="text-xs text-green-600 mt-2">
              Les données de stock ont été corrigées.
            </div>
          </div>,
          {
            duration: 5000,
            position: 'top-center',
            style: {
              background: '#f0fdf4',
              border: '1px solid #bbf7d0',
              color: '#166534'
            }
          }
        )
        // Recharger les réceptions après correction
        await fetchReceptions()
      } else {
        toast.error(
          <div className="max-w-md">
            <div className="font-semibold text-red-800 mb-2">❌ Erreur de correction</div>
            <div className="text-sm text-red-700">
              {response.message}
            </div>
          </div>,
          {
            duration: 6000,
            position: 'top-center'
          }
        )
      }
    } catch (error) {
      console.error('❌ Erreur lors de la correction des données:', error)
      toast.error('Erreur lors de la correction des données')
    }
  }

  const handleDownloadFile = async (receptionId: number) => {
    try {
      console.log('📥 Téléchargement du fichier pour la réception:', receptionId)
      
      // Récupérer d'abord les fichiers de la réception
      const filesResponse = await receptionService.getReceptionFiles(receptionId)
      
      if (!filesResponse.success || !filesResponse.data || filesResponse.data.length === 0) {
        toast.error('Aucun fichier trouvé pour cette réception')
        return
      }
      
      // Utiliser le premier fichier trouvé
      const firstFile = filesResponse.data[0] as any
      console.log('📁 Fichier trouvé:', firstFile)
      
      const response = await receptionService.downloadReceptionFile(firstFile.id)
      
      if (response.success && response.data) {
        // Créer un lien de téléchargement
        const url = window.URL.createObjectURL(response.data)
        const link = document.createElement('a')
        link.href = url
        link.download = firstFile.fileName || `bordereau_reception_${receptionId}.pdf`
        document.body.appendChild(link)
        link.click()
        document.body.removeChild(link)
        window.URL.revokeObjectURL(url)
        
        toast.success('Fichier téléchargé avec succès')
      } else {
        console.error('❌ Erreur lors du téléchargement:', response.message)
        toast.error(`Erreur lors du téléchargement: ${response.message}`)
      }
    } catch (error) {
      console.error('❌ Erreur lors du téléchargement du fichier:', error)
      toast.error('Erreur lors du téléchargement du fichier')
    }
  }

  const downloadReceptionAttachmentById = async (fileId: number, fileName?: string) => {
    try {
      const response = await receptionService.downloadReceptionFile(fileId)
      if (response.success && response.data) {
        const url = window.URL.createObjectURL(response.data)
        const link = document.createElement('a')
        link.href = url
        link.download = fileName || `piece_${fileId}`
        document.body.appendChild(link)
        link.click()
        document.body.removeChild(link)
        window.URL.revokeObjectURL(url)
        toast.success('Téléchargement lancé')
      } else {
        toast.error(response.message || 'Téléchargement impossible')
      }
    } catch (error) {
      console.error('❌ Téléchargement pièce jointe:', error)
      toast.error('Erreur lors du téléchargement')
    }
  }

  // Calculer les statistiques basées sur les données filtrées par rôle
  const receptionsFiltrees = filterReceptionsListForRole(user.role.code, receptions)
  const totalReceptions = receptionsFiltrees.length
  // Confirmées = réceptions validées (backend utilise le statut VALIDEE)
  const receptionsConfirmees = receptionsFiltrees.filter(
    (r) => r.statut === "VALIDEE" || r.statut === "CONFIRMEE" || r.statut === "CONFIRMEE_IEPP" || r.statut === "CONFIRMEE_EPP"
  ).length

  // Total des manuels reçus : uniquement sur les réceptions validées/confirmées (hors SAISIE, ANNULEE)
  const totalManuelsRecus = receptionsFiltrees
    .filter((r) => r.statut === "VALIDEE" || r.statut === "CONFIRMEE" || r.statut === "CONFIRMEE_IEPP" || r.statut === "CONFIRMEE_EPP")
    .reduce((total, reception) => {
      const manuels = reception.manuels || []
      return total + manuels.reduce((sum: number, manuel: any) => sum + (manuel.quantite_recue || 0), 0)
    }, 0)

  return (
    <MainLayout>
      <div className="p-6">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
              <TruckIcon className="h-8 w-8 text-gray-700" />
              Réceptions des Manuels
            </h1>
            <p className="text-gray-600 mt-1">
              Gestion des réceptions de manuels scolaires
            </p>
          </div>
          <div className="flex gap-3">
            <div className="flex gap-3">
              {/* <button
                onClick={handleNouvelleReception}
                className="btn-primary flex items-center gap-2"
                disabled={true}
              >
                <PlusIcon className="h-5 w-5" />
                Nouvelle Réception
              </button> */}
              {!consultationOnly && (
              <button
                onClick={() => setShowLoadFromBesoinModal(true)}
                className="btn-secondary flex items-center gap-2"
                title="Charger une réception depuis un Besoin approuvé"
              >
                <ClipboardDocumentListIcon className="h-5 w-5" />
                Charger depuis Besoin approuvé
              </button>
              )}
            </div>
            {/* <button
              onClick={handleCorrectStockData}
              className="btn-secondary flex items-center gap-2"
              title="Corriger les données de stock existantes"
            >
              <WrenchScrewdriverIcon className="h-5 w-5" />
              Corriger Stock
            </button> */}
          </div>
        </div>

        {/* Statistiques */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <div className="card">
            <div className="flex items-center">
              <CubeIcon className="h-8 w-8 text-gray-700" />
              <div className="ml-3">
                <p className="text-sm font-medium text-gray-600">Total Réceptions</p>
                <p className="text-2xl font-bold text-gray-900">{totalReceptions}</p>
                <p className="text-xs text-gray-500">Toutes réceptions</p>
              </div>
            </div>
          </div>
          
          <div className="card">
            <div className="flex items-center">
              <CheckCircleIcon className="h-8 w-8 text-gray-700" />
              <div className="ml-3">
                <p className="text-sm font-medium text-gray-600">Confirmées</p>
                <p className="text-2xl font-bold text-gray-900">{receptionsConfirmees}</p>
                <p className="text-xs text-gray-500">{totalReceptions > 0 ? Math.round((receptionsConfirmees / totalReceptions) * 100) : 0}% du total</p>
              </div>
            </div>
          </div>
          
          <div className="card">
            <div className="flex items-center">
              <DocumentTextIcon className="h-8 w-8 text-gray-700" />
              <div className="ml-3">
                <p className="text-sm font-medium text-gray-600">Manuels Reçus</p>
                <p className="text-2xl font-bold text-gray-900">{totalManuelsRecus.toLocaleString()}</p>
                <p className="text-xs text-gray-500">Total quantités</p>
              </div>
            </div>
          </div>
        </div>

        {hasReceptionSyntheseTerritoriale(user.role?.code) && (
          <div className="card mb-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-2 flex items-center gap-2">
              <BuildingOfficeIcon className="h-6 w-6 text-amber-700" />
              Distributions (vue synthèse IEPP / EPP)
            </h3>
            <p className="text-sm text-gray-600 mb-4">
              {user.role?.code === "DRENA"
                ? "Périmètre DREN : répartition par IEPP puis par établissement (EPP)."
                : "Vue DAF : synthèse des distributions par IEPP et par établissement."}{" "}
              Les totaux de manuels viennent du détail des mouvements de stock.
            </p>
            {loadingDrenaDistributions ? (
              <p className="text-gray-500 text-sm">Chargement des distributions…</p>
            ) : !drenaDistributions.length ? (
              <p className="text-gray-500 text-sm">Aucune distribution dans le périmètre.</p>
            ) : (
              <div className="space-y-4">
                {groupDistributionsByIeppThenEpp(
                  drenaDistributions,
                  drenaIeppLabelsForDist
                ).map((g) => (
                    <div
                      key={`dist-iepp-${g.ieppId}`}
                      className="border border-amber-100 rounded-lg overflow-hidden bg-amber-50/30"
                    >
                      <div className="px-4 py-2 bg-amber-100/80 font-semibold text-amber-950">
                        {g.ieppLabel}
                      </div>
                      <div className="p-3 space-y-3">
                        {Array.from(g.epps.entries())
                          .sort((a, b) =>
                            a[1].eppLabel.localeCompare(b[1].eppLabel, "fr", {
                              sensitivity: "base",
                            })
                          )
                          .map(([eppKey, block]) => (
                            <div
                              key={`${g.ieppId}-${eppKey}`}
                              className="border border-gray-200 rounded-md bg-white"
                            >
                              <div className="px-3 py-1.5 text-sm font-medium text-gray-800 border-b border-gray-100 bg-gray-50">
                                {block.eppLabel}
                              </div>
                              <div className="overflow-x-auto">
                                <table className="table text-sm w-full">
                                  <thead>
                                    <tr>
                                      <th>Date</th>
                                      <th>Classe</th>
                                      <th>Statut</th>
                                      <th>Manuels</th>
                                    </tr>
                                  </thead>
                                  <tbody>
                                    {block.rows
                                      .slice()
                                      .sort(
                                        (a: any, b: any) =>
                                          Number(b.id) - Number(a.id)
                                      )
                                      .map((row: any) => (
                                        <tr key={row.id}>
                                          <td>
                                            {row.dateDistribution
                                              ? formatFrenchDate(
                                                  String(row.dateDistribution)
                                                )
                                              : "—"}
                                          </td>
                                          <td>{row.classe || "—"}</td>
                                          <td>{getStatusBadge(row.statut)}</td>
                                          <td>
                                            {row.totalManuelsDistribues != null
                                              ? row.totalManuelsDistribues
                                              : "—"}
                                          </td>
                                        </tr>
                                      ))}
                                  </tbody>
                                </table>
                              </div>
                            </div>
                          ))}
                      </div>
                    </div>
                  ))}
              </div>
            )}
          </div>
        )}

        {/* Table des Réceptions */}
        <div className="card">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Liste des Réceptions</h3>
          <div className="overflow-x-auto">
            <table className="table">
              <thead>
                <tr>
                  <th>Référence</th>
                  <th>Type</th>
                  <th>Livreur/École</th>
                  <th>Date</th>
                  <th>Statut</th>
                  <th>Confirmé par</th>
                  {hasReceptionSyntheseTerritoriale(user.role?.code) && (
                    <th className="min-w-[10rem]">Fichiers</th>
                  )}
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {(() => {
                  console.log('🎨 RENDU: Nombre de réceptions à afficher:', receptionsFiltrees.length)
                  console.log('🎨 RENDU: Réceptions filtrées:', receptionsFiltrees)
                  const syntheseTerritoriale = hasReceptionSyntheseTerritoriale(user.role?.code)
                  const colSpan = syntheseTerritoriale ? 8 : 7

                  const renderReceptionRow = (reception: any) => {
                    console.log('🎨 RENDU: Affichage réception ID:', reception.id, 'Type:', reception.type)
                    return (
                  <tr key={reception.id}>
                    <td className="font-medium">{reception.reference}</td>
                    <td>
                      <span className="inline-flex px-2 py-1 text-xs font-semibold rounded-full bg-gray-100 text-gray-800">
                        {getReceptionTypeLabel(reception.type)}
                      </span>
                    </td>
                    <td>
                      {reception.type === "IEPP"
                        ? (reception.structureLibelle || reception.ieppLibelle || "—")
                        : reception.type === "LIVREUR_IEPP"
                          ? "Livreur Standard"
                          : (reception.ecole || reception.structureLibelle || "—")}
                    </td>
                    <td>{new Date(reception.date_reception).toLocaleDateString('fr-FR')}</td>
                    <td>{getStatusBadge(reception.statut)}</td>
                    <td>{reception.confirme_par || "-"}</td>
                    {syntheseTerritoriale && (
                      <td className="text-sm max-w-[14rem] align-top">
                        {(reception.attachedFiles || []).length === 0 ? (
                          <span className="text-gray-400">—</span>
                        ) : (
                          <div className="flex flex-col gap-1">
                            {(reception.attachedFiles || []).map((f: any) => (
                              <button
                                key={f.id}
                                type="button"
                                className="text-left text-blue-600 hover:underline truncate"
                                title={f.fileName || `Fichier #${f.id}`}
                                onClick={() =>
                                  downloadReceptionAttachmentById(f.id, f.fileName)
                                }
                              >
                                {f.fileName || `Fichier #${f.id}`}
                              </button>
                            ))}
                          </div>
                        )}
                      </td>
                    )}
                    <td>
                      <div className="flex space-x-2">
                        <button
                          onClick={async () => {
                            try {
                              console.log('🔍 Récupération des détails pour la réception:', reception.id)
                              
                              // Récupérer les détails complets de la réception
                              const detailsResponse = await mouvementService.getMouvementWithDetails(reception.id)
                              
                              if (detailsResponse.success && detailsResponse.data) {
                                console.log('📊 Détails récupérés:', detailsResponse.data)
                                
                                const detailsDataAny = detailsResponse.data as any
                                const manuels = manuelsDepuisCatalogueMouvements(detailsDataAny.catalogueMouvements)
                                
                                const receptionWithDetails = {
                                  ...reception,
                                  statut: detailsDataAny.statut ?? reception.statut,
                                  reference: detailsDataAny.numeroBordereau || reception.reference,
                                  date_reception: detailsDataAny.dateMouvement || reception.date_reception,
                                  ecole: detailsDataAny.structureLibelle || reception.ecole,
                                  manuels,
                                }
                                
                                console.log('📋 Réception avec détails transformés:', receptionWithDetails)
                                setSelectedReception(receptionWithDetails)
                            setShowDetailsModal(true)
                              } else {
                                console.error('❌ Erreur récupération détails:', detailsResponse.message)
                                toast.error(`Erreur lors de la récupération des détails: ${detailsResponse.message}`)
                              }
                            } catch (error) {
                              console.error('❌ Erreur lors de la récupération des détails:', error)
                              toast.error('Erreur lors de la récupération des détails')
                            }
                          }}
                          className="btn-secondary btn-sm"
                        >
                          Détails
                        </button>
                        
                        {/* Bouton Valider : EPP en attente (validation IEPP) ou IEPP en saisie (passage SAISIE → VALIDEE) */}
                        {reception.statut === "EN_ATTENTE" && user.role.code === "IEPP" && !consultationOnly && (
                          <button
                            onClick={() => handleValidateReception(reception)}
                            disabled={validatingReceptionIds.has(reception.id)}
                            className="btn-primary btn-sm flex items-center gap-1"
                            title="Valider cette réception EPP"
                          >
                            <CheckCircleIcon className="h-4 w-4" />
                            Valider
                          </button>
                        )}
                        {reception.statut === "SAISIE" && reception.type === "IEPP" && user.role.code === "IEPP" && !consultationOnly && (
                          <button
                            onClick={() => handleValidateReceptionIEPPSaisie(reception)}
                            disabled={validatingReceptionIds.has(reception.id)}
                            className="btn-primary btn-sm flex items-center gap-1"
                            title="Valider cette saisie (mise à jour des stocks)"
                          >
                            <CheckCircleIcon className="h-4 w-4" />
                            Valider
                          </button>
                        )}
                        {/* Modifier : uniquement pour réceptions IEPP en SAISIE */}
                        {reception.statut === "SAISIE" && reception.type === "IEPP" && (user.role.code === "IEPP" || user.role.code === "ADMIN" || user.role.code === "DAF") && !consultationOnly && (
                          <button
                            onClick={() => handleLoadReceptionForEdit(reception)}
                            className="btn-outline btn-sm"
                            title="Modifier cette saisie"
                          >
                            <WrenchScrewdriverIcon className="h-4 w-4" />
                            Modifier
                          </button>
                        )}
                        {(reception.statut === "BROUILLON" && reception.type === "EPP" && user.role.code === "DIRECTEUR") && !consultationOnly && (
                          <button
                            onClick={() => handleLoadReceptionForEdit(reception)}
                            className="btn-outline btn-sm"
                            title="Modifier cette réception EPP"
                          >
                            <WrenchScrewdriverIcon className="h-4 w-4" />
                            Modifier
                          </button>
                        )}
                        {/* Bouton d'annulation conditionnel */}
                        {canAnnulerReception(reception) && (
                          <button
                            onClick={() => handleAnnulationReception(reception)}
                            className="btn-danger btn-sm"
                            title={reception.statut === "SAISIE" ? "Annuler cette saisie" : "Annuler cette réception"}
                          >
                            Annuler
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                    )
                  }

                  if (!syntheseTerritoriale) {
                    return receptionsFiltrees.map(renderReceptionRow)
                  }

                  // ✅ DRENA / DAF : un bloc par IEPP (jamais l’id d’une EPP comme clé IEPP)
                  const soleIeppId = inferSoleIeppIdFromIeppRows(receptionsFiltrees)
                  const groups = new Map<number, { ieppId: number; ieppLibelle: string; receptions: any[] }>()
                  for (const r of receptionsFiltrees) {
                    const ieppKey = resolveTerritorialIeppGroupKey(r, soleIeppId)
                    if (!groups.has(ieppKey)) {
                      groups.set(ieppKey, {
                        ieppId: ieppKey,
                        ieppLibelle: pickTerritorialIeppLabel(ieppKey, [r]),
                        receptions: [],
                      })
                    }
                    groups.get(ieppKey)!.receptions.push(r)
                  }
                  for (const g of groups.values()) {
                    g.ieppLibelle = pickTerritorialIeppLabel(g.ieppId, g.receptions)
                  }

                  const sortedGroups = sortTerritorialIeppKeys([...groups.keys()]).map((k) => groups.get(k)!)

                  return sortedGroups.flatMap((g) => {
                    const ieppCollapsed = collapsedTerritorialIepp.has(g.ieppId)
                    const ieppOnly = g.receptions.filter((r: any) => r.type === 'IEPP')
                    const eppOnly = g.receptions.filter((r: any) => r.type === 'EPP')
                    const eppBySchool = new Map<number, any[]>()
                    for (const r of eppOnly) {
                      const k = Number(r.idStructure ?? 0)
                      if (!eppBySchool.has(k)) eppBySchool.set(k, [])
                      eppBySchool.get(k)!.push(r)
                    }
                    const sortRec = (a: any, b: any) =>
                      String(b.date_reception || '').localeCompare(String(a.date_reception || ''))

                    const headerRow = (
                      <tr key={`iepp-h-${g.ieppId}`} className="bg-gray-100">
                        <td colSpan={colSpan} className="font-semibold text-gray-900 py-2">
                          <button
                            type="button"
                            onClick={() => toggleTerritorialIepp(g.ieppId)}
                            aria-expanded={!ieppCollapsed}
                            className="flex items-center gap-2 w-full text-left rounded px-1 py-0.5 -mx-1 hover:bg-gray-200/90 focus:outline-none focus:ring-2 focus:ring-amber-500/50"
                          >
                            {ieppCollapsed ? (
                              <ChevronRightIcon className="h-5 w-5 shrink-0 text-gray-600" aria-hidden />
                            ) : (
                              <ChevronDownIcon className="h-5 w-5 shrink-0 text-gray-600" aria-hidden />
                            )}
                            <span>{g.ieppLibelle}</span>
                            <span className="text-xs font-normal text-gray-500">
                              ({g.receptions.length} réception{g.receptions.length > 1 ? "s" : ""})
                            </span>
                          </button>
                        </td>
                      </tr>
                    )

                    if (ieppCollapsed) {
                      return [headerRow] as React.ReactElement[]
                    }

                    const block: React.ReactElement[] = [
                      headerRow,
                      <tr key={`sub-iepp-${g.ieppId}`} className="bg-amber-50/90">
                        <td colSpan={colSpan} className="text-xs font-semibold uppercase tracking-wide text-amber-950 py-1.5">
                          1 — Réception centrale (fournisseur → cet IEPP)
                        </td>
                      </tr>,
                    ]
                    if (ieppOnly.length === 0) {
                      block.push(
                        <tr key={`empty-iepp-${g.ieppId}`}>
                          <td colSpan={colSpan} className="text-gray-500 text-sm py-2">
                            Aucune réception centrale pour cet IEPP.
                          </td>
                        </tr>
                      )
                    } else {
                      block.push(...ieppOnly.slice().sort(sortRec).map(renderReceptionRow))
                    }
                    block.push(
                      <tr key={`sub-epp-${g.ieppId}`} className="bg-sky-50/90">
                        <td colSpan={colSpan} className="text-xs font-semibold uppercase tracking-wide text-sky-950 py-1.5">
                          2 — Réceptions vers les établissements (IEPP → chaque EPP)
                        </td>
                      </tr>
                    )
                    const schools = Array.from(eppBySchool.entries()).sort((a, b) => {
                      const la = a[1][0]?.structureLibelle || a[1][0]?.ecole || ''
                      const lb = b[1][0]?.structureLibelle || b[1][0]?.ecole || ''
                      return String(la).localeCompare(String(lb), 'fr', { sensitivity: 'base' })
                    })
                    if (eppOnly.length === 0) {
                      block.push(
                        <tr key={`empty-epp-${g.ieppId}`}>
                          <td colSpan={colSpan} className="text-gray-500 text-sm py-2 pl-2">
                            Aucune réception IEPP → EPP pour cet IEPP.
                          </td>
                        </tr>
                      )
                    } else {
                      for (const [schoolId, recs] of schools) {
                        const schoolKey = `${g.ieppId}-${schoolId}`
                        const schoolCollapsed = collapsedTerritorialSchool.has(schoolKey)
                        const schoolLabel =
                          recs[0]?.structureLibelle || recs[0]?.ecole || `Établissement #${schoolId}`
                        block.push(
                          <tr key={`school-${schoolKey}`} className="bg-white border-l-4 border-sky-300">
                            <td colSpan={colSpan} className="pl-2 text-sm font-medium text-sky-900 py-1.5">
                              <button
                                type="button"
                                onClick={(e) => {
                                  e.stopPropagation()
                                  toggleTerritorialSchool(schoolKey)
                                }}
                                aria-expanded={!schoolCollapsed}
                                className="flex items-center gap-2 w-full text-left rounded px-2 py-0.5 hover:bg-sky-50 focus:outline-none focus:ring-2 focus:ring-sky-400/50"
                              >
                                {schoolCollapsed ? (
                                  <ChevronRightIcon className="h-4 w-4 shrink-0 text-sky-700" aria-hidden />
                                ) : (
                                  <ChevronDownIcon className="h-4 w-4 shrink-0 text-sky-700" aria-hidden />
                                )}
                                <span>{schoolLabel}</span>
                                <span className="text-xs font-normal text-sky-700/80">
                                  ({recs.length} ligne{recs.length > 1 ? "s" : ""})
                                </span>
                              </button>
                            </td>
                          </tr>
                        )
                        if (!schoolCollapsed) {
                          block.push(...recs.slice().sort(sortRec).map(renderReceptionRow))
                        }
                      }
                    }
                    return block
                  })
                })()}
              </tbody>
            </table>
          </div>
        </div>


        {/* Modal Nouvelle Réception - même design que Expression des Besoins */}
        {showNouvelleReceptionModal && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 overflow-y-auto" onClick={() => closeReceptionModal()}>
            <div className="bg-white rounded-lg shadow-xl w-[95vw] max-w-6xl mx-4 my-8 max-h-[95vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
              <div className="sticky top-0 bg-white z-10 pb-4 pt-6 px-6 border-b border-gray-200">
                <div className="flex items-center justify-between">
                  <h3 className="text-xl font-bold text-gray-900 flex items-center gap-3">
                    <PlusIcon className="h-6 w-6 text-orange-600" />
                    Nouvelle Réception - {getReceptionTypeLabel(receptionFormData.type || getReceptionTypeForCurrentUser())}
                  </h3>
                  <button
                    onClick={() => closeReceptionModal()}
                    className="text-gray-400 hover:text-gray-600 transition-colors"
                  >
                    <XCircleIcon className="h-6 w-6" />
                  </button>
                </div>
              </div>

              <div className="p-6 space-y-6">
                {/* Sélection de Catalogue */}
                <div className="bg-white border border-gray-200 p-6 rounded-xl shadow-sm">
                  <h4 className="text-lg font-semibold text-gray-900 mb-6 flex items-center gap-2">
                    <ClipboardDocumentListIcon className="h-5 w-5 text-orange-600" />
                    Sélection des Catalogues
                  </h4>
                  
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                    <div className="md:col-span-2">
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Choisir un Catalogue
                      </label>
                      <select
                        key={`catalogue-select-${selectedCatalogues.length}-${cataloguesDisponiblesPourSelect.map((c: any) => c.id).join('-')}`}
                        value={selectedCatalogueId}
                        onChange={(e) => handleCatalogueSelect(e.target.value)}
                        className={`w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-gray-500 focus:border-transparent ${
                          error ? 'border-red-300' : 'border-gray-300'
                        }`}
                        disabled={loadingCatalogues}
                      >
                        <option value="">
                          {cataloguesDisponiblesPourSelect.length === 0
                            ? "— Tous les catalogues ont été ajoutés —"
                            : "— Sélectionner un catalogue —"}
                        </option>
                        {cataloguesDisponiblesPourSelect.map((catalogue: any) => (
                          <option key={catalogue.id} value={catalogue.id}>
                            {catalogue.icone} {catalogue.niveauScolaire} - {catalogue.code}
                          </option>
                        ))}
                      </select>
                      
                      {error && (
                        <div className="mt-2 text-sm text-red-600 flex items-center">
                          <svg className="w-4 h-4 mr-1" fill="currentColor" viewBox="0 0 20 20">
                            <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
                          </svg>
                          {error}
                        </div>
                      )}
                    </div>
                    <div className="flex items-end">
                      <button
                        onClick={addCatalogueToTable}
                        disabled={!selectedCatalogueId || !currentCatalogueData}
                        className="w-full px-6 py-3 bg-orange-600 text-white rounded-lg hover:bg-orange-700 disabled:bg-gray-400 disabled:cursor-not-allowed font-medium shadow-sm hover:shadow-md transition-all duration-200"
                      >
                        {editingCatalogueId != null ? 'Mettre à jour la ligne' : 'Ajouter au Tableau'}
                      </button>
                    </div>
                  </div>

                  {/* Affichage du catalogue sélectionné */}
                  {currentCatalogueData && (
                    <div className="bg-gradient-to-br from-orange-50 to-white p-6 rounded-xl border-2 border-orange-200 mb-4 shadow-md">
                      <h5 className="font-semibold text-gray-900 mb-4 text-lg flex items-center gap-2">
                        <span className="text-orange-600">📚</span>
                        Catalogue Sélectionné: {currentCatalogueData.niveauScolaire}
                      </h5>
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm mb-4">
                        <div>
                          <span className="font-medium text-gray-700">Code:</span>
                          <span className="ml-2 text-gray-900">{currentCatalogueData.code}</span>
                        </div>
                        <div>
                          <span className="font-medium text-gray-700">Année:</span>
                          <span className="ml-2 text-gray-900">{currentCatalogueData.anneeScolaire}</span>
                        </div>
                        <div>
                          <span className="font-medium text-gray-700">Matières:</span>
                          {/* ✅ Afficher le nombre de matières depuis catalogueMatieres au lieu de currentCatalogueData.matieres */}
                          <span className="ml-2 text-gray-900">{catalogueMatieres.length}</span>
                        </div>
                      </div>

                      {/* Matières avec champs de quantités */}
                      <div className="space-y-3">
                        <div className="flex items-center justify-between">
                          <h6 className="font-medium text-gray-900">Saisir les quantités:</h6>
                          {loadingStocks && (
                            <div className="flex items-center text-sm text-gray-500">
                              <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-gray-500 mr-2"></div>
                              Chargement des stocks...
                            </div>
                          )}
                        </div>
                        
                        {catalogueMatieres.length === 0 ? (
                          <div className="text-center py-4 text-gray-500">
                            Aucune matière trouvée pour ce catalogue
                          </div>
                        ) : (
                          catalogueMatieres.map((matiere: any) => {
                            const manuelExistant = receptionFormData.manuels.find((m: any) => m.matiereId === matiere.id)
                            const quantiteRecue = manuelExistant?.quantite_recue || 0
                            // ✅ Pour réception directe : quantite_prevue est saisissable (pas depuis matiere.quantite_prevue qui est 0)
                            // Pour réception depuis Besoin : quantite_prevue vient du Besoin (quantiteConsolidee) - lecture seule
                            const quantitePrevue = manuelExistant?.quantite_prevue || 0
                            const quantiteApprouvee =
                              typeof manuelExistant?.quantite_approuvee === "number" &&
                              !Number.isNaN(manuelExistant.quantite_approuvee)
                                ? manuelExistant.quantite_approuvee
                                : 0
                            const stockActuel = stockDisponible[matiere.id] || 0
                            
                            // ✅ Détecter si c'est une réception depuis un Besoin (quantités prévues depuis besoin consolidé, lecture seule)
                            // Uniquement via le flag isFromBesoin (posé au chargement depuis besoin). En édition réception directe SAISIE, pas de flag → saisie libre.
                            const isReceptionFromBesoin = manuelExistant?.isFromBesoin === true
                            /** Plafond saisie « Reçue » : depuis besoin → quota DAF (sinon risque de dépasser l’approuvé) */
                            const plafondRecevable = isReceptionFromBesoin
                              ? quantiteApprouvee > 0
                                ? quantiteApprouvee
                                : quantitePrevue
                              : quantitePrevue
                            const isQuantiteRecueInvalid =
                              plafondRecevable > 0 && quantiteRecue > plafondRecevable
                            
                            return (
                              <div key={matiere.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                                <div className="flex-1">
                                  <div className="font-medium text-gray-900">{matiere.libelle}</div>
                                  <div className="text-sm text-gray-600">
                                    Code: {matiere.code}
                                    {isReceptionFromBesoin && (
                                      <span className="ml-2 text-xs font-medium">
                                        <span className="text-blue-600">Demandée (consolidée): {quantitePrevue.toLocaleString()}</span>
                                        <span className="mx-1 text-gray-400">•</span>
                                        <span className="text-green-600">Approuvée (DAF): {quantiteApprouvee.toLocaleString()}</span>
                                      </span>
                                    )}
                                    {isQuantiteRecueInvalid && (
                                      <span className="ml-2 text-red-600 font-semibold">
                                        ⚠️ Quantité reçue ({quantiteRecue}) dépasse le plafond autorisé (
                                        {isReceptionFromBesoin ? "approuvée" : "demandée"} : {plafondRecevable})
                                      </span>
                                    )}
                                  </div>
                                </div>
                                <div className="ml-4 flex gap-3">
                                  {/* ✅ NOUVEAU : Champ de saisie pour quantite_prevue (obligatoire pour réception directe, lecture seule pour réception depuis Besoin) */}
                                  <div className="flex flex-col">
                                    <label className="text-xs text-gray-600 mb-1">
                                      Quantité demandée
                                      {isReceptionFromBesoin && (
                                        <span className="ml-1 text-gray-500 text-xs font-medium">(Besoin consolidé)</span>
                                      )}
                                    </label>
                                    {isReceptionFromBesoin ? (
                                      // ✅ Lecture seule pour réception depuis Besoin (quantiteConsolidee)
                                      <div className="w-24 px-3 py-2 text-center border-2 border-gray-200 bg-gray-100 text-gray-700 rounded-md font-semibold">
                                        {quantitePrevue.toLocaleString()}
                                      </div>
                                    ) : (
                                      // ✅ Saisissable pour réception directe
                                      <input
                                        type="number"
                                        value={quantitePrevue}
                                        onChange={(e) => {
                                          const newQuantitePrevue = parseInt(e.target.value) || 0
                                          
                                          const newManuels = [...receptionFormData.manuels]
                                          const existingIndex = newManuels.findIndex((m: any) => m.matiereId === matiere.id)
                                          
                                          if (existingIndex >= 0) {
                                            newManuels[existingIndex].quantite_prevue = newQuantitePrevue
                                            // ✅ Si quantite_recue dépasse la nouvelle quantite_prevue, la limiter
                                            if (newManuels[existingIndex].quantite_recue > newQuantitePrevue && newQuantitePrevue > 0) {
                                              newManuels[existingIndex].quantite_recue = newQuantitePrevue
                                            }
                                          } else {
                                            const catalogue = availableCatalogues.find(c => c.id.toString() === selectedCatalogueId)
                                            
                                            newManuels.push({
                                              matiereId: matiere.id,
                                              code: matiere.code,
                                              libelle: matiere.libelle,
                                              quantite_prevue: newQuantitePrevue,
                                              quantite_recue: 0,
                                              idNiveauScolaire: catalogue?.niveauId,
                                              niveauScolaireLibelle: catalogue?.niveauScolaire,
                                              niveauScolaireCode: catalogue?.niveauCode
                                            })
                                          }
                                          
                                          setReceptionFormData({...receptionFormData, manuels: newManuels})
                                        }}
                                        className={`w-24 px-3 py-2 text-center border rounded-md focus:outline-none focus:ring-2 focus:ring-gray-500 focus:border-transparent ${
                                          quantitePrevue === 0 
                                            ? 'border-red-300 bg-red-50' 
                                            : 'border-gray-300'
                                        }`}
                                        min="0"
                                        placeholder="0"
                                        disabled={loadingStocks}
                                        required
                                      />
                                    )}
                                  </div>
                                  
                                  {/* Champ de saisie pour quantite_recue */}
                                  <div className="flex flex-col">
                                    <label className="text-xs text-gray-600 mb-1">
                                      Reçue
                                      {isReceptionFromBesoin && (
                                        <span className="ml-1 text-gray-500">(max. approuvée)</span>
                                      )}
                                    </label>
                                  <input
                                    type="number"
                                    value={quantiteRecue}
                                    onChange={(e) => {
                                      const newQuantite = parseInt(e.target.value) || 0
                                      
                                        if (plafondRecevable > 0 && newQuantite > plafondRecevable) {
                                          toast.error(
                                            isReceptionFromBesoin
                                              ? `La quantité reçue (${newQuantite}) ne peut pas dépasser la quantité approuvée (${plafondRecevable})`
                                              : `La quantité reçue (${newQuantite}) ne peut pas dépasser la quantité demandée (${plafondRecevable})`
                                          )
                                          return
                                        }
                                      
                                      const newManuels = [...receptionFormData.manuels]
                                      const existingIndex = newManuels.findIndex((m: any) => m.matiereId === matiere.id)
                                      
                                      if (existingIndex >= 0) {
                                        newManuels[existingIndex].quantite_recue = newQuantite
                                      } else {
                                        const catalogue = availableCatalogues.find(c => c.id.toString() === selectedCatalogueId)
                                        
                                        newManuels.push({
                                          matiereId: matiere.id,
                                          code: matiere.code,
                                          libelle: matiere.libelle,
                                            quantite_prevue: quantitePrevue || 0,
                                          quantite_recue: newQuantite,
                                          idNiveauScolaire: catalogue?.niveauId,
                                          niveauScolaireLibelle: catalogue?.niveauScolaire,
                                          niveauScolaireCode: catalogue?.niveauCode
                                        })
                                      }
                                      
                                      setReceptionFormData({...receptionFormData, manuels: newManuels})
                                    }}
                                      className={`w-24 px-3 py-2 text-center border rounded-md focus:outline-none focus:ring-2 focus:ring-gray-500 focus:border-transparent ${
                                        isQuantiteRecueInvalid ? 'border-red-500 bg-red-50' : 'border-gray-300'
                                      }`}
                                    min="0"
                                      max={plafondRecevable > 0 ? plafondRecevable : undefined}
                                    placeholder="0"
                                    disabled={loadingStocks}
                                      required
                                  />
                                  </div>
                                </div>
                              </div>
                            )
                          })
                        )}
                      </div>
                    </div>
                  )}

                  {/* Tableau des catalogues sélectionnés */}
                  {selectedCatalogues.length > 0 && (
                    <div className="mt-6">
                      <h5 className="font-semibold text-gray-900 mb-4 flex items-center gap-2">
                        <span className="text-orange-600">📋</span>
                        Catalogues Sélectionnés ({selectedCatalogues.length})
                      </h5>
                      <div className="overflow-x-auto">
                        <table className="min-w-full bg-white border border-orange-200 rounded-lg overflow-hidden">
                          <thead className="bg-gradient-to-r from-orange-50 to-orange-100">
                            <tr>
                              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Catalogue
                              </th>
                              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Niveau
                              </th>
                              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Matières
                              </th>
                              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Quantités Saisies
                              </th>
                              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Actions
                              </th>
                            </tr>
                          </thead>
                          <tbody className="bg-white divide-y divide-gray-200">
                            {selectedCatalogues.map((catalogue) => (
                              <tr key={catalogue.id} className="hover:bg-gray-50">
                                <td className="px-4 py-3 text-sm">
                                  <div className="flex items-center">
                                    <span className="text-lg mr-2">{catalogue.icone}</span>
                                    <div>
                                      <div className="font-medium text-gray-900">{catalogue.niveauScolaire}</div>
                                      <div className="text-gray-500 text-xs">{catalogue.code}</div>
                                    </div>
                                  </div>
                                </td>
                                <td className="px-4 py-3 text-sm">
                                  <span className="inline-flex px-2 py-1 text-xs font-semibold rounded-full bg-blue-100 text-blue-800">
                                    {catalogue.niveauCode}
                                  </span>
                                </td>
                                <td className="px-4 py-3 text-sm text-gray-900">
                                  {/* ✅ Afficher le nombre de matières depuis quantitesSaisies du catalogue */}
                                  {catalogue.quantitesSaisies?.length || 0} matière(s)
                                </td>
                                <td className="px-4 py-3 text-sm">
                                  <div className="space-y-1">
                                    {catalogue.quantitesSaisies.map((q: any, index: number) => (
                                      <div key={index} className="text-xs">
                                        {/* ✅ Afficher quantite_prevue et quantite_recue */}
                                        {q.libelle}: 
                                        <span className="ml-1 font-medium text-blue-600">Demandée: {q.quantite_prevue || 0}</span>
                                        {q.isFromBesoin && (
                                          <span className="ml-2 font-medium text-green-600">Approuvée: {q.quantite_approuvee ?? (q.quantite_recue || 0)}</span>
                                        )}
                                        <span className="ml-2 font-medium text-gray-700">Reçue: {q.quantite_recue || 0}</span>
                                        {q.quantite_recue > 0 &&
                                          (q.isFromBesoin
                                            ? (q.quantite_approuvee ?? 0) > 0 && q.quantite_recue > (q.quantite_approuvee ?? 0)
                                            : q.quantite_prevue > 0 && q.quantite_recue > q.quantite_prevue) && (
                                          <span className="ml-2 text-red-600 font-semibold">⚠️</span>
                                        )}
                                      </div>
                                    ))}
                                    {catalogue.quantitesSaisies.length === 0 && (
                                      <span className="text-gray-400 text-xs">Aucune quantité saisie</span>
                                    )}
                                  </div>
                                </td>
                                <td className="px-4 py-3 text-sm">
                                  <div className="flex items-center gap-2">
                                    {!consultationOnly && (
                                      <>
                                    <button
                                      onClick={() => handleEditCatalogueRow(catalogue)}
                                      className="text-orange-600 hover:text-orange-800 text-xs font-medium"
                                      title="Modifier cette ligne"
                                    >
                                      Editer
                                    </button>
                                    <span className="text-gray-300">|</span>
                                    <button
                                      onClick={() => removeCatalogueFromTable(catalogue.id)}
                                      className="text-red-600 hover:text-red-800 text-xs font-medium"
                                      title="Retirer du tableau"
                                    >
                                      Retirer
                                    </button>
                                      </>
                                    )}
                                  </div>
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  )}
                </div>

                {/* Informations de Base */}
                <div className="bg-white border border-gray-200 p-6 rounded-xl shadow-sm">
                  <h4 className="text-lg font-semibold text-gray-900 mb-6 flex items-center gap-2">
                    <DocumentTextIcon className="h-5 w-5 text-orange-600" />
                    Informations de Base
                  </h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Date de Réception
                      </label>
                      <input
                        type="date"
                        value={receptionFormData.date_reception}
                        onChange={(e) => {
                          console.log('📅 Date sélectionnée:', e.target.value)
                          setReceptionFormData({
                            ...receptionFormData,
                            date_reception: e.target.value
                          })
                        }}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-gray-500 focus:border-transparent"
                      />
                    </div>
                    
                    {receptionFormData.type === "EPP" ? (
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          École Destinataire
                        </label>
                        <div className="w-full px-3 py-2 bg-gray-50 border border-gray-300 rounded-md text-gray-700">
                          {receptionFormData.ecole || (user as any).epp?.libelle || user.structure?.libelle || "École non définie"}
                        </div>
                        <p className="text-xs text-gray-500 mt-1">
                          École du directeur connecté (EPP destinataire)
                        </p>
                      </div>
                    ) : null}
                    
                  <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Numéro de Bordereau
                      </label>
                      <input
                        type="text"
                        value={receptionFormData.bordereau}
                        onChange={(e) => setReceptionFormData({
                          ...receptionFormData,
                          bordereau: e.target.value
                        })}
                        placeholder="Ex: BL-2024-001"
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-gray-500 focus:border-transparent"
                      />
                    </div>
                  </div>
                </div>


                {/* Bordereau de Livraison Physique */}
                <div className="bg-gray-50 p-4 rounded-lg">
                  <h4 className="text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2">
                    <DocumentTextIcon className="h-5 w-5 text-gray-700" />
                    Bordereau de Livraison Physique
                  </h4>
                  
                  <div className="space-y-4">
                  <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Fichier du Bordereau (PDF, JPG, PNG)
                      </label>
                      <div className="flex items-center gap-3">
                        <input
                          type="file"
                          accept=".pdf,.jpg,.jpeg,.png"
                          onChange={(e) => {
                            const file = e.target.files?.[0]
                            if (file) {
                              setReceptionFormData({
                                ...receptionFormData,
                                bordereauFile: file,
                                bordereauFileName: file.name
                              })
                            }
                          }}
                          className="flex-1 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-gray-500 focus:border-transparent"
                        />
                        {receptionFormData.bordereauFileName && (
                          <span className="inline-flex px-3 py-1 text-sm font-medium text-gray-800 bg-gray-100 rounded-full">
                            ✓ {receptionFormData.bordereauFileName}
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-gray-500 mt-1">
                        Formats acceptés: PDF, JPG, PNG (max 10MB)
                      </p>
                    </div>
                  </div>
                </div>

                {/* Observations */}
                <div className="bg-gray-50 p-4 rounded-lg">
                  <h4 className="text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2">
                    <DocumentTextIcon className="h-5 w-5 text-gray-700" />
                    Observations
                  </h4>
                  
                  <textarea
                    value={receptionFormData.observations}
                    onChange={(e) => setReceptionFormData({
                      ...receptionFormData,
                      observations: e.target.value
                    })}
                    placeholder="Observations sur la réception (optionnel)"
                    rows={3}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-gray-500 focus:border-transparent"
                  />
                </div>
              </div>

              {/* Actions */}
              <div className="flex items-center justify-between mt-6 pt-6 border-t border-orange-200 px-6 pb-6">
                <div className="flex gap-3">
                  <button
                    onClick={() => {
                      ;(async () => {
                        if (!receptionFormData.date_reception) {
                          toast.error("Veuillez saisir la date de réception")
                          return
                        }
                        if (selectedCatalogues.length === 0) {
                          toast.error("Aucun catalogue sélectionné")
                          return
                        }

                        try {
                          const receptionData: any = transformReceptionData()
                          receptionData.statut = receptionFormData.type === "EPP" ? "BROUILLON" : "SAISIE"
                          receptionData.catalogueMouvements = selectedCatalogues.map((catalogue: any) => ({
                            idCatalogue: catalogue.id,
                            matiereQuantites: (catalogue.quantitesSaisies || []).map((q: any) => ({
                              idMatiere: q.matiereId || 0,
                              quantiteRecue: q.quantite_recue || 0,
                              quantitePrevue: q.quantite_prevue || q.quantite_recue || 0,
                              idNiveauScolaire: q.idNiveauScolaire ?? catalogue.niveauId ?? catalogue.idNiveauScolaire,
                              niveauScolaireCode: q.niveauScolaireCode ?? catalogue.niveauCode,
                              niveauScolaireLibelle: q.niveauScolaireLibelle ?? catalogue.niveauScolaire
                            }))
                          }))

                          const saveResponse = await mouvementService.createMouvementComplete(receptionData)
                          if (!saveResponse.success || !saveResponse.data?.id) {
                            throw new Error(saveResponse.message || "Erreur lors de la sauvegarde brouillon")
                          }

                          if (receptionFormData.bordereauFile) {
                            try {
                              await receptionService.uploadReceptionFile(saveResponse.data.id, receptionFormData.bordereauFile, "BORDEREAU")
                            } catch (fileError) {
                              console.warn("⚠️ Erreur upload bordereau brouillon:", fileError)
                            }
                          }

                          await fetchReceptions()
                          closeReceptionModal()
                          toast.success("Brouillon sauvegardé avec succès.")
                        } catch (error: any) {
                          toast.error(error?.message || "Erreur lors de la sauvegarde brouillon")
                        }
                      })()
                    }}
                    className="px-4 py-2 text-gray-700 bg-gray-100 border border-gray-300 rounded-md hover:bg-gray-200 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2 transition-colors"
                    disabled={selectedCatalogues.length === 0 || consultationOnly}
                  >
                    💾 Sauvegarder en brouillon
                  </button>
                </div>
                
                <div className="flex gap-3">
                <button
                  onClick={() => closeReceptionModal()}
                  className="px-6 py-2 text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2 transition-colors"
                >
                  Annuler
                </button>
                <button
                  onClick={async () => {
                    const isSoumissionEPP = receptionFormData.type === "EPP"

                    if (isSoumissionEPP) {
                      const champsManquants: string[] = []
                      if (!receptionFormData.date_reception) champsManquants.push("Date de réception")
                      if (!String(receptionFormData.bordereau || "").trim()) champsManquants.push("Numéro de bordereau")
                      if (!receptionFormData.bordereauFile && !String(receptionFormData.bordereauFileName || "").trim()) {
                        champsManquants.push("Fichier du bordereau")
                      }
                      if (selectedCatalogues.length === 0) champsManquants.push("Au moins un catalogue")

                      const hasQuantites = selectedCatalogues.some((catalogue: any) =>
                        Array.isArray(catalogue.quantitesSaisies) &&
                        catalogue.quantitesSaisies.some((q: any) => (q.quantite_recue || 0) > 0)
                      )
                      if (!hasQuantites) {
                        champsManquants.push("Quantités reçues (au moins une > 0)")
                      }

                      if (champsManquants.length > 0) {
                        setErrorAlertMessage(
                          `Avant de soumettre à l’IEPP, veuillez remplir tous les champs obligatoires :\n- ${champsManquants.join("\n- ")}`
                        )
                        return
                      }
                    }

                    // Validation
                    if (!receptionFormData.date_reception) {
                      toast.error("Veuillez saisir la date de réception")
                      return
                    }

                    if (selectedCatalogues.length === 0) {
                      toast.error("Veuillez sélectionner au moins un catalogue")
                      return
                    }

                    // Validation des quantités saisies pour tous les catalogues
                    const hasQuantities = selectedCatalogues.some(catalogue => 
                      catalogue.quantitesSaisies && catalogue.quantitesSaisies.length > 0
                    )
                    if (!hasQuantities) {
                      toast.error("Veuillez saisir au moins une quantité pour un catalogue")
                      return
                    }

                    if (isSoumissionEPP) {
                      const cataloguesSansQuantite = selectedCatalogues.filter((catalogue: any) =>
                        !Array.isArray(catalogue.quantitesSaisies) ||
                        catalogue.quantitesSaisies.length === 0 ||
                        !catalogue.quantitesSaisies.some((q: any) => (q.quantite_recue || 0) > 0)
                      )
                      if (cataloguesSansQuantite.length > 0) {
                        setErrorAlertMessage("Avant de soumettre à l’IEPP, chaque catalogue ajouté doit contenir au moins une quantité reçue supérieure à 0.")
                        return
                      }
                    }
                    
                    // ✅ NOUVEAU : Validation quantite_prevue et quantite_recue pour réception directe
                    // Pour réception directe : quantite_prevue est obligatoire
                    // Pour réception depuis Besoin : quantite_prevue vient du Besoin (déjà validé)
                    const isReceptionDirecte = !receptionFormData.id || receptionFormData.id === 0
                    
                    if (isReceptionDirecte) {
                      // Vérifier que toutes les quantités ont quantite_prevue > 0
                      for (const catalogue of selectedCatalogues) {
                        if (catalogue.quantitesSaisies && catalogue.quantitesSaisies.length > 0) {
                          for (const q of catalogue.quantitesSaisies) {
                            if (!q.quantite_prevue || q.quantite_prevue <= 0) {
                              toast.error(`La quantité demandée est obligatoire pour "${q.libelle || q.code}" dans le catalogue ${catalogue.niveauScolaire}`)
                              return
                            }
                            
                            // Vérifier que quantite_recue ne dépasse pas quantite_prevue
                            if (q.quantite_recue > q.quantite_prevue) {
                              toast.error(`La quantité reçue (${q.quantite_recue}) ne peut pas dépasser la quantité demandée (${q.quantite_prevue}) pour "${q.libelle || q.code}"`)
                              return
                            }
                          }
                        }
                      }
                    }

                    try {
            // ✅ NOTE : La validation du stock pour EPP est maintenant gérée automatiquement par le backend
            // via l'endpoint createReceptionEPP qui utilise directement la table StockDisponible
            console.log('📊 Catalogues sélectionnés:', selectedCatalogues.length)
            console.log('📦 Quantités totales à enregistrer:', selectedCatalogues.reduce((total: number, cat: any) => 
              total + cat.quantitesSaisies.reduce((sum: number, q: any) => sum + q.quantite_recue, 0), 0
            ))
                      
                      // 2. Transformer les données pour le backend
                      const receptionData = transformReceptionData()
                      
                      // ✅ DÉCISION : Choisir le bon endpoint selon le type de réception
                      // - Réception EPP directe → createReceptionEPP (validation stock automatique)
                      // - Réception depuis Besoin → createMouvementComplete (mise à jour)
                      // - Réception IEPP → flow original (createMouvement + catalogues/quantités)
                      const isUpdateFromBesoin = receptionData.id != null && receptionData.id > 0
                      const isReceptionEPPDirecte = receptionFormData.type === "EPP" && !isUpdateFromBesoin
                      
                      let receptionId: number | undefined
                      
                      if (isReceptionEPPDirecte) {
                        // ✅ NOUVEAU : Flow Réception EPP Directe avec validation stock automatique
                        console.log('🔄 Flow Réception EPP Directe : utilisation de createReceptionEPP (validation stock automatique)')
                        
                        // Préparer les données avec CatalogueMouvements (format attendu par le backend)
                        receptionData.catalogueMouvements = selectedCatalogues.map((catalogue: any) => ({
                          idCatalogue: catalogue.id,
                          matiereQuantites: catalogue.quantitesSaisies
                            .filter((q: any) => q.quantite_recue > 0)
                            .map((q: any) => ({
                              idMatiere: q.matiereId || 0,
                              quantiteRecue: q.quantite_recue,
                              quantitePrevue: q.quantite_prevue || 0, // ✅ Toujours utiliser quantite_prevue (depuis besoin ou saisie manuelle)
                              // ✅ ID si disponible (pour compatibilité)
                              idNiveauScolaire: q.idNiveauScolaire ?? catalogue.niveauId ?? catalogue.idNiveauScolaire,
                              // ✅ NOUVEAU : envoyer aussi le code/libellé de niveau pour fallback backend
                              niveauScolaireCode: q.niveauScolaireCode ?? catalogue.niveauCode,
                              niveauScolaireLibelle: q.niveauScolaireLibelle ?? catalogue.niveauScolaire
                            }))
                        }))
                        
                        receptionData.statut = "EN_ATTENTE"
                        const receptionResponse = await mouvementService.createReceptionEPP(receptionData)
                        
                        if (!receptionResponse.success) {
                          const errorMessage = receptionResponse.message || 'Erreur lors de la création de la réception EPP'
                          console.error('❌ Erreur création réception EPP:', errorMessage)
                          const isStockError = errorMessage.includes('Stock insuffisant') || 
                                             errorMessage.includes('Disponible:') || 
                                             errorMessage.includes('Demandé:')
                          toast.error(
                            <div className="max-w-lg">
                              <div className="font-semibold text-red-800 mb-2">
                                {isStockError ? '❌ Stock IEPP insuffisant' : '❌ Erreur de création'}
                              </div>
                              <div className="text-sm text-red-700 whitespace-pre-line">
                                {errorMessage}
                              </div>
                              <div className="text-xs text-red-600 mt-2">
                                {isStockError 
                                  ? 'Veuillez réduire les quantités demandées ou contacter l\'administrateur.'
                                  : 'Veuillez vérifier vos données et réessayer.'
                                }
                              </div>
                            </div>,
                            {
                              duration: isStockError ? 10000 : 6000,
                              position: 'top-center',
                              style: {
                                background: '#fef2f2',
                                border: '1px solid #fecaca',
                                color: '#991b1b',
                                maxWidth: '500px'
                              }
                            }
                          )
                          setErrorAlertMessage(errorMessage)
                          return
                        }
                        
                        receptionId = receptionResponse.data?.id
                        if (!receptionId) {
                          throw new Error('ID de réception non retourné par le backend')
                        }
                        
                        console.log('✅ Réception EPP créée avec succès (stock IEPP validé), ID:', receptionId)
                        
                        // Upload du fichier bordereau si présent
                        if (receptionFormData.bordereauFile) {
                          try {
                            console.log('📎 Upload du fichier bordereau pour réception ID:', receptionId)
                            await receptionService.uploadReceptionFile(
                              receptionId,
                              receptionFormData.bordereauFile,
                              'BORDEREAU'
                            )
                            console.log('✅ Fichier bordereau uploadé avec succès')
                          } catch (fileError) {
                            console.warn('⚠️ Erreur lors de l\'upload du fichier (non bloquant):', fileError)
                            toast.warning('Réception créée avec succès, mais erreur lors de l\'upload du bordereau. Vous pourrez l\'ajouter plus tard.')
                          }
                        }
                        
                        // ✅ Code de succès pour flux EPP directe : message, rechargement, fermeture modal
                        toast.success(
                          <div className="max-w-md">
                            <div className="font-semibold text-green-800 mb-2">✅ Réception créée avec succès</div>
                            <div className="text-sm text-green-700">
                              La réception a été créée avec tous ses détails (catalogues, quantités, stocks).
                            </div>
                          </div>,
                          {
                            duration: 5000,
                            position: 'top-center'
                          }
                        )
                        
                        // Recharger les réceptions depuis le backend
                        await fetchReceptions()
                        setBesoinsApprouves([])
                        
                        // Fermer la modal
                        closeReceptionModal()
                      } else if (isUpdateFromBesoin) {
                        // ✅ Flow Expression des Besoins → Réception : utiliser createMouvementComplete
                        console.log('🔄 Flow Expression des Besoins → Réception : utilisation de createMouvementComplete')
                        
                        // Ajouter les catalogues et quantités au mouvementData
                        // ⚠️ IMPORTANT : la propriété attendue par le backend est "catalogueMouvements" (camelCase)
                        // et non "CatalogueMouvements", sinon dto.getCatalogueMouvements() sera null côté backend.
                        receptionData.catalogueMouvements = selectedCatalogues.map((catalogue: any) => ({
                          idCatalogue: catalogue.id,
                          matiereQuantites: catalogue.quantitesSaisies.map((q: any) => ({
                            idMatiere: q.matiereId,
                            quantiteRecue: q.quantite_recue,
                            quantitePrevue: q.quantite_prevue || 0, // ✅ Toujours utiliser quantite_prevue (depuis besoin ou saisie manuelle)
                            // ✅ Même fallback robuste pour le flux Besoin → Réception
                            idNiveauScolaire: q.idNiveauScolaire ?? catalogue.niveauId ?? catalogue.idNiveauScolaire,
                            // ✅ Et envoi systématique du code/libellé de niveau
                            niveauScolaireCode: q.niveauScolaireCode ?? catalogue.niveauCode,
                            niveauScolaireLibelle: q.niveauScolaireLibelle ?? catalogue.niveauScolaire
                          }))
                        }))
                        
                        let receptionResponse
                        if (receptionFormData.type === "EPP") {
                          receptionData.statut = "EN_ATTENTE"
                          // Soumission EPP finale : repasser par la validation stock IEPP
                          receptionResponse = await mouvementService.createReceptionEPP(receptionData)
                        } else {
                          receptionResponse = await mouvementService.createMouvementComplete(receptionData)
                        }
                        
                        if (!receptionResponse.success) {
                          const errorMessage = receptionResponse.message || 'Erreur lors de la mise à jour de la réception depuis le Besoin'
                          console.error('❌ Erreur mise à jour réception depuis Besoin:', errorMessage)
                          toast.error(errorMessage)
                          throw new Error(errorMessage)
                        }
                        
                        receptionId = receptionResponse.data?.id
                        if (!receptionId) {
                          throw new Error('ID de réception non retourné par le backend')
                        }
                        
                        console.log('✅ Réception mise à jour depuis Besoin avec succès, ID:', receptionId)
                        
                        // ✅ CORRECTION : Uploader le fichier bordereau si présent (comme dans le flux réception directe)
                        if (receptionFormData.bordereauFile) {
                          try {
                            console.log('📎 Upload du fichier bordereau pour réception ID:', receptionId)
                            await receptionService.uploadReceptionFile(
                              receptionId,
                              receptionFormData.bordereauFile,
                              'BORDEREAU'
                            )
                            console.log('✅ Fichier bordereau uploadé avec succès')
                          } catch (fileError) {
                            console.warn('⚠️ Erreur lors de l\'upload du fichier (non bloquant):', fileError)
                            // Ne pas bloquer la création de la réception si l'upload échoue
                            toast.warning('Réception créée avec succès, mais erreur lors de l\'upload du bordereau. Vous pourrez l\'ajouter plus tard.')
                          }
                        } else {
                          console.warn('⚠️ Aucun fichier bordereau à uploader')
                        }
                        
                        // ✅ Code commun pour les deux flux : message de succès, rechargement, fermeture modal, notification
                        // (Ce code sera aussi exécuté après le flux "réception directe" ci-dessous)
                      } else {
                        // ✅ Flow Réception Directe (ORIGINAL) : utiliser le flow qui fonctionne
                        console.log('🔄 Flow Réception Directe : utilisation du flow original')
                        
                        // 3. Créer la réception principale (Mouvement uniquement)
                        const receptionResponse = await mouvementService.createMouvement(receptionData)
                      
                      if (!receptionResponse.success) {
                        // Popup d'erreur pour la création de réception
                        const errorMessage = receptionResponse.message || 'Erreur lors de la création de la réception'
                        console.error('❌ Erreur création réception:', errorMessage)
                        
                        // Détecter si c'est une erreur de stock insuffisant (code 902)
                        const isStockError = errorMessage.includes('Stock insuffisant') || 
                                           errorMessage.includes('Disponible:') || 
                                           errorMessage.includes('Demandé:')
                        
                        toast.error(
                          <div className="max-w-lg">
                            <div className="font-semibold text-red-800 mb-2">
                              {isStockError ? '❌ Stock insuffisant' : '❌ Erreur de création'}
                            </div>
                            <div className="text-sm text-red-700 whitespace-pre-line">
                              {errorMessage}
                            </div>
                            <div className="text-xs text-red-600 mt-2">
                              {isStockError 
                                ? 'Veuillez réduire les quantités demandées ou contacter l\'administrateur.'
                                : 'Veuillez vérifier vos données et réessayer.'
                              }
                            </div>
                          </div>,
                          {
                            duration: isStockError ? 10000 : 6000, // Plus long pour les erreurs de stock
                            position: 'top-center',
                            style: {
                              background: '#fef2f2',
                              border: '1px solid #fecaca',
                              color: '#991b1b',
                              maxWidth: '500px'
                            }
                          }
                        )
                        throw new Error(errorMessage)
                      }
                      
                      receptionId = receptionResponse.data?.id
                      
                      if (!receptionId) {
                        toast.error(
                          <div className="max-w-md">
                            <div className="font-semibold text-red-800 mb-2">❌ Erreur technique</div>
                            <div className="text-sm text-red-700">
                              ID de réception non retourné par le backend
                            </div>
                            <div className="text-xs text-red-600 mt-2">
                              Veuillez contacter l'administrateur.
                            </div>
                          </div>,
                          {
                            duration: 6000,
                            position: 'top-center'
                          }
                        )
                        throw new Error('ID de réception non retourné par le backend')
                      }
                      
                      // ✅ Flow Réception Directe : Créer CatalogueMouvement, MatiereQuantite, MouvementStock
                      console.log('📦 Création des CatalogueMouvement et MatiereQuantite pour réception ID:', receptionId)
                      
                      // 3. Créer les CatalogueMouvement et MatiereQuantite pour chaque catalogue
                      for (const catalogue of selectedCatalogues) {
                        try {
                          // 3.1. Créer CatalogueMouvement
                          const catalogueMouvementResponse = await receptionService.createCatalogueReception(
                            receptionId,
                            catalogue.id
                          )
                          
                          if (!catalogueMouvementResponse.success) {
                            console.error('❌ Erreur création CatalogueMouvement pour catalogue:', catalogue.id, catalogueMouvementResponse.message)
                            throw new Error(`Erreur lors de la création de l'association catalogue-réception: ${catalogueMouvementResponse.message}`)
                          }
                          
                          const catalogueMouvementId = catalogueMouvementResponse.data?.id
                          if (!catalogueMouvementId) {
                            console.error('❌ ID CatalogueMouvement non retourné pour catalogue:', catalogue.id)
                            throw new Error('ID CatalogueMouvement non retourné par le backend')
                          }
                          
                          console.log('✅ CatalogueMouvement créé:', catalogueMouvementId, 'pour catalogue:', catalogue.id)
                          
                          // 3.2. Créer MatiereQuantite pour chaque matière du catalogue
                          if (catalogue.quantitesSaisies && catalogue.quantitesSaisies.length > 0) {
                            for (const quantite of catalogue.quantitesSaisies) {
                              try {
                                const matiereQuantiteResponse = await receptionService.createMatiereQuantite(
                                  catalogueMouvementId,
                                  quantite.matiereId,
                                  quantite.quantite_recue || 0,
                                  quantite.quantite_prevue || quantite.quantite_recue || 0,
                                  receptionData.idStructure,
                                  receptionFormData.type === 'IEPP' ? 'IEPP' : 'EPP',
                                  quantite.matiereCode
                                )
                                
                                if (!matiereQuantiteResponse.success) {
                                  console.error('❌ Erreur création MatiereQuantite pour matière:', quantite.matiereId, matiereQuantiteResponse.message)
                                  throw new Error(`Erreur lors de la création de la quantité de matière: ${matiereQuantiteResponse.message}`)
                                }
                                
                                console.log('✅ MatiereQuantite créée pour matière:', quantite.matiereId, 'quantité:', quantite.quantite_recue)
                              } catch (mqError) {
                                console.error('❌ Erreur création MatiereQuantite:', mqError)
                                throw mqError
                              }
                            }
                          }
                        } catch (catError) {
                          console.error('❌ Erreur traitement catalogue:', catalogue.id, catError)
                          throw catError
                        }
                      }
                      
                      // 4. Créer MouvementStock uniquement si réception non IEPP (IEPP direct = SAISIE, stock à la validation)
                      if (receptionFormData.type !== 'IEPP') {
                        console.log('📊 Création des MouvementStock pour réception ID:', receptionId)
                        try {
                          const stockMovementsResponse = await receptionService.createStockMovements(receptionId)
                          if (!stockMovementsResponse.success) {
                            console.warn('⚠️ Erreur création MouvementStock (non bloquant):', stockMovementsResponse.message)
                          } else {
                            console.log('✅ MouvementStock créés avec succès')
                          }
                        } catch (stockError) {
                          console.warn('⚠️ Erreur création MouvementStock (non bloquant):', stockError)
                        }
                      } else {
                        console.log('ℹ️ Réception IEPP en SAISIE - MouvementStock créés à la validation')
                      }
                      
                      // 5. Uploader le fichier bordereau si présent
                      if (receptionFormData.bordereauFile) {
                        try {
                          await receptionService.uploadReceptionFile(
                            receptionId,
                            receptionFormData.bordereauFile,
                            'BORDEREAU'
                          )
                          console.log('✅ Fichier bordereau uploadé avec succès')
                        } catch (fileError) {
                          console.warn('⚠️ Erreur lors de l\'upload du fichier (non bloquant):', fileError)
                          // Ne pas bloquer la création de la réception si l'upload échoue
                        }
                      }
                      
                      } // ✅ Fermeture du bloc else (Flow Réception Directe)
                      
                      // ✅ Code commun pour les deux flux (Besoin → Réception ET Réception Directe)
                      // Ce code s'exécute après les deux flux car receptionId est défini dans les deux cas
                      if (receptionId) {
                        // 6. Afficher le message de succès (IEPP = en saisie, à valider pour mettre à jour les stocks)
                        const isIEPPSaisie = receptionFormData.type === 'IEPP'
                        toast.success(
                          <div className="max-w-md">
                            <div className="font-semibold text-green-800 mb-2">✅ Réception créée avec succès</div>
                            <div className="text-sm text-green-700">
                              {isIEPPSaisie
                                ? 'Réception créée en saisie. Validez-la pour mettre à jour les stocks.'
                                : 'La réception a été créée avec tous ses détails (catalogues, quantités, stocks).'}
                            </div>
                          </div>,
                          {
                            duration: 5000,
                            position: 'top-center'
                          }
                        )
                        
                        // 7. Recharger les réceptions depuis le backend
                        await fetchReceptions()
                        // Invalider la liste « besoins approuvés » (évite une ligne obsolète / mauvais premier besoin après une autre EPP)
                        setBesoinsApprouves([])
                        
                        // 8. Fermer la modal
                        closeReceptionModal()
                        
                        // 9. Envoyer notification email de création
                        try {
                          const notificationResponse = await receptionService.sendNotificationEmail(
                            'RECEPTION_CREEE',
                            receptionId,
                            user.email || '',
                            { 
                              type: receptionFormData.type,
                              reference: `REC-${receptionFormData.type === "IEPP" ? "IEPP" : "EPP"}-${user.structure?.libelle?.split(" ")[1] || "COC"}-${new Date().getFullYear()}-${String(receptionId).slice(-3)}`,
                              catalogues: selectedCatalogues.length
                            }
                          )
                          
                          if (notificationResponse.success) {
                            console.log('📧 Notification de création envoyée')
                          } else {
                            console.warn('⚠️ Erreur envoi notification:', notificationResponse.message)
                          }
                        } catch (error) {
                          console.warn('⚠️ Erreur envoi notification email:', error)
                        }
                      }
                      
                    } catch (error: any) {
                      console.error('Erreur lors de la création de la réception:', error)
                      // Même extraction que la page users : message backend pour que l'utilisateur connaisse la cause
                      const backendMessage =
                        (error && typeof error === 'object' && 'message' in error && error.message) ||
                        (error?.details?.status?.message)
                      const displayMessage = backendMessage || 'Erreur lors de la création de la réception'
                      toast.error(
                        <div className="max-w-md">
                          <div className="font-semibold text-red-800 mb-2">❌ Erreur de création</div>
                          <div className="text-sm text-red-700 whitespace-pre-line">
                            {displayMessage}
                          </div>
                          <div className="text-xs text-red-600 mt-2">
                            Veuillez vérifier vos données et réessayer.
                          </div>
                        </div>,
                        {
                          duration: 10000,
                          position: 'top-center',
                          style: {
                            background: '#fef2f2',
                            border: '1px solid #fecaca',
                            color: '#991b1b'
                          }
                        }
                      )
                      setErrorAlertMessage(displayMessage)
                    }
                  }}
                  className="px-6 py-2 bg-gray-800 text-white rounded-md hover:bg-gray-900 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                  disabled={
                    consultationOnly ||
                    !receptionFormData.date_reception ||
                    selectedCatalogues.length === 0 ||
                    false
                  }
                >
                  {receptionFormData.type === "EPP"
                    ? "Soumettre à l’IEPP"
                    : (receptionFormData.id != null && receptionFormData.id > 0
                      ? "Mettre à jour la réception"
                      : "Créer la Réception")}
                </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Modal d'alerte erreur personnalisée (design cohérent avec l'app) */}
        {errorAlertMessage && (
          <div
            className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-[60] overflow-y-auto"
            onClick={() => setErrorAlertMessage(null)}
          >
            <div
              className="bg-white rounded-lg shadow-xl w-[95vw] max-w-md mx-4 p-0 overflow-hidden"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex items-center gap-3 pt-6 px-6 pb-4 border-b border-gray-200">
                <div className="flex-shrink-0 w-10 h-10 rounded-full bg-red-100 flex items-center justify-center">
                  <ExclamationTriangleIcon className="h-6 w-6 text-red-600" />
                </div>
                <h3 className="text-xl font-bold text-gray-900">Erreur de création</h3>
              </div>
              <div className="p-6">
                <p className="text-sm text-gray-700 whitespace-pre-line leading-relaxed">
                  {errorAlertMessage}
                </p>
                <p className="text-xs text-gray-500 mt-3">
                  Veuillez vérifier vos données et réessayer.
                </p>
              </div>
              <div className="px-6 pb-6 flex justify-end">
                <button
                  type="button"
                  onClick={() => setErrorAlertMessage(null)}
                  className="px-6 py-2 bg-gray-800 text-white rounded-md hover:bg-gray-900 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2 transition-colors"
                >
                  OK
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Modal Détails Réception */}
        {showDetailsModal && selectedReception && (
          <div className="modal-overlay" onClick={() => setShowDetailsModal(false)}>
            <div className="modal-content w-[90vw] max-w-none max-h-[95vh] overflow-y-auto" style={{width: '90vw', maxWidth: 'none'}} onClick={(e) => e.stopPropagation()}>
              <div className="px-6 py-4 border-b border-orange-200 flex justify-between items-center bg-orange-50/30">
                <h3 className="text-xl font-bold text-orange-800 flex items-center gap-3">
                  <DocumentTextIcon className="h-6 w-6 text-orange-600" />
                  Détails de la Réception - {selectedReception.reference}
                </h3>
                <button 
                  onClick={() => setShowDetailsModal(false)} 
                  className="text-gray-400 hover:text-gray-600 transition-colors"
                >
                  <XCircleIcon className="h-6 w-6" />
                </button>
              </div>

              <div className="p-6 space-y-6">
                {/* Informations Générales */}
                <div className="border-2 border-orange-200 rounded-lg p-4 bg-orange-50/50">
                  <h4 className="text-lg font-semibold text-orange-800 mb-4 flex items-center gap-2">
                    <DocumentTextIcon className="h-5 w-5 text-orange-600" />
                    Informations Générales
                  </h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Référence</label>
                      <p className="text-sm text-gray-900 font-medium">{selectedReception.reference}</p>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Type</label>
                      <span className="inline-flex px-2 py-1 text-xs font-semibold rounded-full bg-orange-100 text-orange-800">
                        {getReceptionTypeLabel(selectedReception.type)}
                      </span>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Date de Réception</label>
                      <p className="text-sm text-gray-900">{new Date(selectedReception.date_reception).toLocaleDateString('fr-FR')}</p>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Statut</label>
                      <div>{getStatusBadge(selectedReception.statut)}</div>
                    </div>
                    {selectedReception.type === "EPP" ? (
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">École</label>
                        <p className="text-sm text-gray-900">{selectedReception.ecole}</p>
                      </div>
                    ) : (
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Type de Réception</label>
                        <p className="text-sm text-gray-900">{getReceptionTypeLabel(selectedReception.type)}</p>
                      </div>
                    )}
                  <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Confirmé par</label>
                      <p className="text-sm text-gray-900">{selectedReception.confirme_par || "-"}</p>
                    </div>
                  </div>
                </div>

                {/* Détails des Manuels */}
                <div className="border-2 border-orange-200 rounded-lg p-4 bg-orange-50/50">
                  <h4 className="text-lg font-semibold text-orange-800 mb-4 flex items-center gap-2">
                    <ClipboardDocumentListIcon className="h-5 w-5 text-orange-600" />
                    Détails des Manuels
                  </h4>
                  
                  <div className="overflow-x-auto">
                    <table className="min-w-full bg-white border border-orange-200 rounded-lg">
                      <thead className="bg-orange-50">
                        <tr>
                          <th className="px-4 py-3 text-left text-xs font-medium text-orange-800 uppercase tracking-wider">
                            Code
                          </th>
                          <th className="px-4 py-3 text-left text-xs font-medium text-orange-800 uppercase tracking-wider">
                            Titre
                          </th>
                          <th className="px-4 py-3 text-left text-xs font-medium text-orange-800 uppercase tracking-wider">
                            Niveau
                          </th>
                          <th className="px-4 py-3 text-left text-xs font-medium text-orange-800 uppercase tracking-wider">
                            Quantité demandée
                          </th>
                          <th className="px-4 py-3 text-left text-xs font-medium text-orange-800 uppercase tracking-wider">
                            Quantité approuvée
                          </th>
                          <th className="px-4 py-3 text-left text-xs font-medium text-orange-800 uppercase tracking-wider">
                            Quantité reçue
                          </th>
                          <th className="px-4 py-3 text-left text-xs font-medium text-orange-800 uppercase tracking-wider">
                            Écart
                          </th>
                        </tr>
                      </thead>
                      <tbody className="bg-white divide-y divide-gray-200">
                        {selectedReception.manuels.map((manuel: any, index: number) => (
                          <tr key={index} className="hover:bg-orange-50/50 transition-colors">
                            <td className="px-4 py-3 text-sm font-medium text-gray-900">
                              {manuel.code}
                            </td>
                            <td className="px-4 py-3 text-sm text-gray-700">
                              {manuel.titre}
                            </td>
                            <td className="px-4 py-3 text-sm text-gray-700">
                              <span className="inline-flex px-2 py-1 text-xs font-semibold rounded-full bg-orange-100 text-orange-800">
                                {manuel.niveau}
                              </span>
                            </td>
                            <td className="px-4 py-3 text-sm text-gray-700 bg-orange-50/30 font-medium">
                              {manuel.quantite_prevue}
                            </td>
                            <td className="px-4 py-3 text-sm font-medium text-green-700 bg-green-50/40">
                              {manuel.quantite_approuvee ?? manuel.quantite_recue ?? 0}
                            </td>
                            <td className="px-4 py-3 text-sm text-gray-700 font-medium">
                              {manuel.quantite_recue ?? 0}
                            </td>
                            <td className="px-4 py-3 text-sm">
                              <span className={`font-medium ${manuel.ecart < 0 ? 'text-red-600' : manuel.ecart > 0 ? 'text-green-600' : 'text-gray-600'}`}>
                                {manuel.ecart > 0 ? '+' : ''}{manuel.ecart}
                              </span>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* Documents */}
                <div className="border-2 border-orange-200 rounded-lg p-4 bg-orange-50/50">
                  <h4 className="text-lg font-semibold text-orange-800 mb-4 flex items-center gap-2">
                    <DocumentTextIcon className="h-5 w-5 text-orange-600" />
                    Documents
                  </h4>
                  
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 bg-white border border-orange-200 rounded-lg">
                      <div className="flex items-center gap-3">
                        <DocumentTextIcon className="h-5 w-5 text-gray-700" />
                <div>
                          <p className="text-sm font-medium text-gray-900">Bordereau de Livraison</p>
                          <p className="text-xs text-gray-500">{selectedReception.documents.bordereau_livraison}</p>
                        </div>
                    </div>
                      <button 
                        onClick={() => handleDownloadFile(selectedReception.id)}
                        className="px-3 py-1 text-sm text-orange-700 bg-orange-100 rounded-md hover:bg-orange-200 transition-colors"
                      >
                        Télécharger
                      </button>
                    </div>
                    </div>
                  </div>
                </div>

              {/* Actions */}
              <div className="flex items-center justify-end gap-3 mt-6 pt-6 border-t border-orange-200">
                <button
                  onClick={() => setShowDetailsModal(false)}
                  className="px-6 py-2 bg-gray-800 text-white rounded-md hover:bg-gray-900 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2 transition-colors"
                >
                  Fermer
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Modal Charger depuis Besoin approuvé - même design que Expression des Besoins */}
        {showLoadFromBesoinModal && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 overflow-y-auto" onClick={() => setShowLoadFromBesoinModal(false)}>
            <div className="bg-white rounded-lg shadow-xl w-[95vw] max-w-6xl mx-4 my-8 max-h-[95vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
              {/* Header - identique BesoinForm */}
              <div className="sticky top-0 bg-white z-10 pb-4 pt-6 px-6 border-b border-gray-200">
                <div className="flex items-center justify-between">
                  <h3 className="text-xl font-bold text-gray-900 flex items-center gap-3">
                    <ClipboardDocumentListIcon className="h-6 w-6 text-orange-600" />
                    Charger depuis Besoin approuvé
                  </h3>
                  <button
                    onClick={() => setShowLoadFromBesoinModal(false)}
                    className="text-gray-400 hover:text-gray-600 transition-colors"
                  >
                    <XCircleIcon className="h-6 w-6" />
                  </button>
                </div>
              </div>

              <div className="p-6 space-y-6">
                {loadingBesoinsApprouves ? (
                  <div className="bg-white border border-gray-200 p-8 rounded-xl shadow-sm text-center">
                    <p className="text-gray-600">Chargement des Besoins approuvés...</p>
                  </div>
                ) : besoinsApprouves.length === 0 ? (
                  <div className="bg-gradient-to-br from-orange-50 to-white border-2 border-orange-200 p-8 rounded-xl shadow-md text-center">
                    <h4 className="text-lg font-semibold text-gray-900 mb-4 flex items-center justify-center gap-2">
                      <span className="text-orange-600">📋</span>
                      Besoins approuvés
                    </h4>
                    <p className="text-gray-700 mb-6">Cliquez sur Charger pour afficher la liste des besoins approuvés.</p>
                    <button
                      onClick={fetchBesoinsApprouves}
                      disabled={loadingBesoinsApprouves}
                      className="px-6 py-3 text-white bg-orange-600 rounded-lg hover:bg-orange-700 disabled:bg-gray-400 disabled:cursor-not-allowed font-medium shadow-sm hover:shadow-md transition-all duration-200"
                    >
                      Charger
                    </button>
                  </div>
                ) : (
                  <div className="bg-white border border-gray-200 p-6 rounded-xl shadow-sm">
                    <h4 className="text-lg font-semibold text-gray-900 mb-6 flex items-center gap-2">
                      <span className="text-orange-600">📋</span>
                      Liste des besoins approuvés
                    </h4>
                    <div className="w-full overflow-visible">
                      <table className="w-full min-w-full bg-white border border-orange-200 rounded-lg overflow-hidden">
                        <thead className="bg-gradient-to-r from-orange-50 to-orange-100">
                          <tr>
                            <th className="px-4 py-3 text-left text-xs font-medium text-orange-800 uppercase tracking-wider">
                              Référence
                            </th>
                            <th className="px-4 py-3 text-left text-xs font-medium text-orange-800 uppercase tracking-wider">
                              Structure
                            </th>
                            <th className="px-4 py-3 text-left text-xs font-medium text-orange-800 uppercase tracking-wider">
                              Année Scolaire
                            </th>
                            <th className="px-4 py-3 text-left text-xs font-medium text-orange-800 uppercase tracking-wider">
                              Date Approbation
                            </th>
                            <th className="px-4 py-3 text-left text-xs font-medium text-orange-800 uppercase tracking-wider">
                              Actions
                            </th>
                          </tr>
                        </thead>
                        <tbody className="bg-white divide-y divide-orange-100">
                          {besoinsGroupesParIepp.map((groupe: any, idx: number) => (
                            <tr key={idx} className="hover:bg-orange-50/50 transition-colors">
                              <td className="px-4 py-3 text-sm font-medium text-gray-900">
                                {groupe.besoins[0]?.reference || '-'}
                              </td>
                              <td className="px-4 py-3 text-sm text-gray-700">
                                {groupe.structure}
                              </td>
                              <td className="px-4 py-3 text-sm text-gray-700">
                                {groupe.annee}
                              </td>
                              <td className="px-4 py-3 text-sm text-gray-700">
                                {formatFrenchDate(groupe.dateApprobation)}
                              </td>
                              <td className="px-4 py-3 text-sm">
                                <button
                                  onClick={() => handleLoadFromBesoinGroup(groupe)}
                                  className="px-4 py-2 text-sm text-white bg-orange-600 rounded-lg hover:bg-orange-700 focus:outline-none focus:ring-2 focus:ring-orange-500 focus:ring-offset-2 transition-all duration-200 shadow-sm hover:shadow-md"
                                  title="Charger les détails (EPP, niveaux, matières) dans le formulaire pour créer le stock"
                                >
                                  Charger
                                </button>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}
              </div>

              <div className="flex items-center justify-end gap-3 px-6 py-4 border-t border-orange-200 bg-orange-50/30">
                <button
                  onClick={() => setShowLoadFromBesoinModal(false)}
                  className="px-6 py-2 bg-gray-800 text-white rounded-md hover:bg-gray-900 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2 transition-colors"
                >
                  Fermer
                </button>
              </div>
            </div>
          </div>
        )}

        {/* ✅ NOUVEAU : Modal de validation IEPP pour les réceptions EPP */}
        {showValidationModal && selectedReceptionForValidation && (
          <ValidationIEPPModal
            reception={selectedReceptionForValidation}
            onClose={() => {
              setShowValidationModal(false)
              setSelectedReceptionForValidation(null)
            }}
            onValidate={handleValidationSuccess}
          />
        )}
      </div>
    </MainLayout>
  )
} 