"use client"

import { useState } from "react"
import MainLayout from "../../components/layout/main-layout"
import { useAuth } from "../providers"
import {
  ServerIcon,
  ShieldCheckIcon,
  ChartBarIcon,
  DocumentTextIcon,
  UserGroupIcon,
  CogIcon,
  TruckIcon,
  CheckCircleIcon,
  ClockIcon,
  EyeIcon,
  PencilIcon,
  PlusIcon,
} from "@heroicons/react/24/outline"

// Données mockées des paramètres système DISMAS
const mockSystemParams = [
  {
    id: 1,
    cle: "SEUIL_STOCK_CRITIQUE_IEPP",
    valeur: "500",
    description: "Seuil critique de stock pour déclencher une alerte au niveau IEPP",
    type_valeur: "INTEGER",
    categorie: "STOCK",
  },
  {
    id: 2,
    cle: "DELAI_TRAITEMENT_PLAINTE_JOURS",
    valeur: "7",
    description: "Délai maximum pour traiter une plainte (en jours ouvrables)",
    type_valeur: "INTEGER",
    categorie: "PLAINTE",
  },
  {
    id: 3,
    cle: "ANNEE_SCOLAIRE_COURANTE",
    valeur: "2024-2025",
    description: "Année scolaire actuellement active dans le système",
    type_valeur: "STRING",
    categorie: "GENERAL",
  },
  {
    id: 4,
    cle: "WORKFLOW_DISTRIBUTION_ETAPES",
    valeur: "11",
    description: "Nombre d'étapes dans le processus de distribution",
    type_valeur: "INTEGER",
    categorie: "WORKFLOW",
  },
  {
    id: 5,
    cle: "DELAI_REMONTEE_BORDEREAU_IEPP_JOURS",
    valeur: "7",
    description: "Délai pour remonter les bordereaux IEPP vers DRENA",
    type_valeur: "INTEGER",
    categorie: "WORKFLOW",
  },
  {
    id: 6,
    cle: "DELAI_REMONTEE_FICHE_EMARGEMENT_JOURS",
    valeur: "7",
    description: "Délai pour remonter les fiches d'émargement vers IEPP",
    type_valeur: "INTEGER",
    categorie: "WORKFLOW",
  },
  {
    id: 7,
    cle: "NOTIFICATION_EMAIL_ACTIVE",
    valeur: "true",
    description: "Activation des notifications par email",
    type_valeur: "BOOLEAN",
    categorie: "NOTIFICATION",
  },
  {
    id: 8,
    cle: "NOTIFICATION_SMS_ACTIVE",
    valeur: "false",
    description: "Activation des notifications par SMS",
    type_valeur: "BOOLEAN",
    categorie: "NOTIFICATION",
  },
  {
    id: 9,
    cle: "COULEUR_PRIMAIRE_CI",
    valeur: "#FF6600",
    description: "Couleur primaire du thème (Orange Côte d'Ivoire)",
    type_valeur: "STRING",
    categorie: "THEME",
  },
  {
    id: 10,
    cle: "COULEUR_SECONDAIRE_CI",
    valeur: "#00A651",
    description: "Couleur secondaire du thème (Vert Côte d'Ivoire)",
    type_valeur: "STRING",
    categorie: "THEME",
  },
  {
    id: 11,
    cle: "CONTROLE_QUALITE_OBLIGATOIRE",
    valeur: "true",
    description: "Contrôle qualité obligatoire par le Contrôleur Financier",
    type_valeur: "BOOLEAN",
    categorie: "CONTROLE",
  },
  {
    id: 12,
    cle: "SIGNATURE_NUMERIQUE_BORDEREAUX",
    valeur: "true",
    description: "Signature numérique obligatoire pour les bordereaux",
    type_valeur: "BOOLEAN",
    categorie: "SECURITE",
  },
]

// Acteurs du système DISMAS selon l'organigramme ivoirien
const mockActeurs = [
  {
    id: 1,
    code: "MENA",
    libelle: "Ministère de l'Éducation Nationale",
    niveau: 0,
    parent: null,
    responsabilites: ["Supervision générale", "Politique éducative"],
    actif: true,
  },
  {
    id: 2,
    code: "CABINET",
    libelle: "Cabinet du Ministre",
    niveau: 1,
    parent: "MENA",
    responsabilites: ["Courriers aux préfets", "Notes circulaires", "Communication"],
    actif: true,
  },
  {
    id: 3,
    code: "DAF",
    libelle: "Direction des Affaires Financières",
    niveau: 1,
    parent: "MENA",
    responsabilites: ["Passation marchés", "Formation acteurs", "Supervision régulations", "Bilan distribution"],
    actif: true,
  },
  {
    id: 4,
    code: "DPFC",
    libelle: "Direction Pédagogie et Formation Continue",
    niveau: 1,
    parent: "MENA",
    responsabilites: ["Spécifications pédagogiques", "Contrôle conformité manuels"],
    actif: true,
  },
  {
    id: 5,
    code: "DESPS",
    libelle: "Direction Études, Stratégies, Planification, Statistiques",
    niveau: 1,
    parent: "MENA",
    responsabilites: ["Données statistiques élèves/enseignants", "Planification"],
    actif: true,
  },
  {
    id: 6,
    code: "CONTROLEUR_FINANCIER",
    libelle: "Contrôleur Financier",
    niveau: 1,
    parent: "MENA",
    responsabilites: ["Validation quantité/qualité", "Contrôle bordereaux"],
    actif: true,
  },
  {
    id: 7,
    code: "DRENA",
    libelle: "Direction Régionale",
    niveau: 2,
    parent: "MENA",
    responsabilites: ["Information acteurs locaux", "Collecte bordereaux", "Régulations internes", "Rapports"],
    actif: true,
  },
  {
    id: 8,
    code: "IEPP",
    libelle: "Inspection Enseignement Préscolaire et Primaire",
    niveau: 3,
    parent: "DRENA",
    responsabilites: ["Réception manuels", "Distribution EPP", "Collecte fiches", "Contrôles"],
    actif: true,
  },
  {
    id: 9,
    code: "EPP",
    libelle: "École Primaire Publique",
    niveau: 4,
    parent: "IEPP",
    responsabilites: ["Réception manuels", "Distribution classes", "Fiches émargement"],
    actif: true,
  },
  {
    id: 10,
    code: "COGES",
    libelle: "Comité de Gestion Scolaire",
    niveau: 4,
    parent: "EPP",
    responsabilites: ["Co-réception manuels", "Convocation parents", "Sensibilisation"],
    actif: true,
  },
]

// Workflow des 11 étapes
const mockWorkflowEtapes = [
  {
    id: 1,
    numero: 1,
    titre: "Stockage Entrepôt Banque Mondiale",
    description: "Stockage des manuels par éditeur dans l'entrepôt BM",
    acteur_responsable: "BANQUE_MONDIALE",
    duree_prevue: 0,
    documents_requis: ["Bons de livraison éditeurs"],
    actif: true,
  },
  {
    id: 2,
    numero: 2,
    titre: "Contrôle Qualité et Quantité",
    description: "Contrôle par le Contrôleur Financier, DAF et Direction PRSEB",
    acteur_responsable: "CONTROLEUR_FINANCIER",
    duree_prevue: 3,
    documents_requis: ["Procès-verbal contrôle", "Certificat qualité"],
    actif: true,
  },
  {
    id: 3,
    numero: 3,
    titre: "Déstockage par Libraire Distributeur",
    description: "Déstockage avec planning de distribution par DRENA/IEPP/EPP",
    acteur_responsable: "LIBRAIRE",
    duree_prevue: 2,
    documents_requis: ["Planning distribution", "Bons de sortie"],
    actif: true,
  },
  {
    id: 4,
    numero: 4,
    titre: "Pré-positionnement Magasins IEPP",
    description: "Livraison et stockage dans les magasins IEPP",
    acteur_responsable: "IEPP",
    duree_prevue: 5,
    documents_requis: ["Bordereau livraison IEPP signé"],
    actif: true,
  },
  {
    id: 5,
    numero: 5,
    titre: "Enlèvement vers EPP",
    description: "Directeurs d'école et COGES enlèvent les manuels en IEPP",
    acteur_responsable: "DIRECTEUR",
    duree_prevue: 7,
    documents_requis: ["Bordereau livraison EPP signé"],
    actif: true,
  },
  {
    id: 6,
    numero: 6,
    titre: "Distribution aux Classes",
    description: "Directeur remet les manuels aux maîtres de classe",
    acteur_responsable: "DIRECTEUR",
    duree_prevue: 2,
    documents_requis: ["Cahier matériel", "Décharge maîtres"],
    actif: true,
  },
  {
    id: 7,
    numero: 7,
    titre: "Remise aux Parents d'Élèves",
    description: "Distribution aux élèves en présence des parents",
    acteur_responsable: "MAITRE",
    duree_prevue: 3,
    documents_requis: ["Fiche émargement parents"],
    actif: true,
  },
  {
    id: 8,
    numero: 8,
    titre: "Acheminement Fiches vers IEPP",
    description: "EPP achemine fiches émargement et synthèse vers IEPP",
    acteur_responsable: "DIRECTEUR",
    duree_prevue: 7,
    documents_requis: ["Fiches émargement", "Fiche synthèse EPP"],
    actif: true,
  },
  {
    id: 9,
    numero: 9,
    titre: "Collecte et Scan IEPP",
    description: "IEPP collecte, scanne et relie les documents",
    acteur_responsable: "IEPP",
    duree_prevue: 7,
    documents_requis: ["Documents reliés", "Fichiers scannés"],
    actif: true,
  },
  {
    id: 10,
    numero: 10,
    titre: "Transmission vers DRENA",
    description: "IEPP transmet documents reliés vers DRENA",
    acteur_responsable: "IEPP",
    duree_prevue: 2,
    documents_requis: ["Fiche synthèse DRENA"],
    actif: true,
  },
  {
    id: 11,
    numero: 11,
    titre: "Consultation et Téléchargement DAF",
    description: "DAF consulte et télécharge tous les documents",
    acteur_responsable: "DAF",
    duree_prevue: 1,
    documents_requis: ["Bilan national distribution"],
    actif: true,
  },
]

export default function AdminPage() {
  const { user } = useAuth()
  const [selectedTab, setSelectedTab] = useState("dashboard")
  const [selectedParam, setSelectedParam] = useState<any>(null)
  const [showParamModal, setShowParamModal] = useState(false)
  const [selectedActeur, setSelectedActeur] = useState<any>(null)
  const [showActeurModal, setShowActeurModal] = useState(false)
  const [selectedEtape, setSelectedEtape] = useState<any>(null)
  const [showEtapeModal, setShowEtapeModal] = useState(false)

  if (!user || user.role.code.toUpperCase() !== "ADMIN") {
    return (
      <MainLayout>
        <div className="text-center py-12">
          <ShieldCheckIcon className="h-16 w-16 text-gray-400 mx-auto mb-4" />
          <h2 className="text-xl font-semibold text-gray-900 mb-2">Accès Restreint</h2>
          <p className="text-gray-600">Seuls les administrateurs peuvent accéder à cette section.</p>
        </div>
      </MainLayout>
    )
  }

  const tabs = [
    { id: "dashboard", name: "Vue d'Ensemble", icon: ChartBarIcon },
    { id: "acteurs", name: "Acteurs DISMAS", icon: UserGroupIcon },
    { id: "workflow", name: "Workflow (11 Étapes)", icon: TruckIcon },
    { id: "parametres", name: "Paramètres Système", icon: CogIcon },
    { id: "securite", name: "Sécurité", icon: ShieldCheckIcon },
    { id: "monitoring", name: "Monitoring", icon: ServerIcon },
  ]

  return (
    <MainLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="bg-gradient-to-r from-orange-500 to-green-500 rounded-lg p-6 text-white">
          <h1 className="text-2xl font-bold">Administration DISMAS</h1>
          <p className="text-orange-100">
            Configuration et monitoring du système de distribution des manuels scolaires
          </p>
          <p className="text-sm text-orange-100 mt-1">Côte d'Ivoire • Ministère de l'Éducation Nationale</p>
        </div>

        {/* Tabs */}
        <div className="border-b border-gray-200">
          <nav className="-mb-px flex space-x-8 overflow-x-auto">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setSelectedTab(tab.id)}
                className={`flex items-center py-2 px-1 border-b-2 font-medium text-sm whitespace-nowrap ${
                  selectedTab === tab.id
                    ? "border-orange-500 text-orange-600"
                    : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
                }`}
              >
                <tab.icon className="h-5 w-5 mr-2" />
                {tab.name}
              </button>
            ))}
          </nav>
        </div>

        {/* Dashboard Tab */}
        {selectedTab === "dashboard" && (
          <div className="space-y-6">
            {/* Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <div className="stat-card">
                <div className="flex items-center">
                  <div className="p-3 rounded-lg bg-blue-50 text-blue-600">
                    <UserGroupIcon className="h-6 w-6" />
                  </div>
                  <div className="ml-4">
                    <p className="stat-label">Acteurs Système</p>
                    <p className="stat-value text-lg">{mockActeurs.filter((a) => a.actif).length}</p>
                  </div>
                </div>
              </div>

              <div className="stat-card">
                <div className="flex items-center">
                  <div className="p-3 rounded-lg bg-green-50 text-green-600">
                    <TruckIcon className="h-6 w-6" />
                  </div>
                  <div className="ml-4">
                    <p className="stat-label">Étapes Workflow</p>
                    <p className="stat-value text-lg">{mockWorkflowEtapes.length}</p>
                  </div>
                </div>
              </div>

              <div className="stat-card">
                <div className="flex items-center">
                  <div className="p-3 rounded-lg bg-purple-50 text-purple-600">
                    <CogIcon className="h-6 w-6" />
                  </div>
                  <div className="ml-4">
                    <p className="stat-label">Paramètres</p>
                    <p className="stat-value text-lg">{mockSystemParams.length}</p>
                  </div>
                </div>
              </div>

              <div className="stat-card">
                <div className="flex items-center">
                  <div className="p-3 rounded-lg bg-orange-50 text-orange-600">
                    <CheckCircleIcon className="h-6 w-6" />
                  </div>
                  <div className="ml-4">
                    <p className="stat-label">Système</p>
                    <p className="stat-value text-lg text-green-600">Opérationnel</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Hiérarchie Administrative */}
            <div className="card">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Hiérarchie Administrative DISMAS</h3>
              <div className="space-y-4">
                {mockActeurs
                  .filter((acteur) => acteur.niveau <= 2)
                  .map((acteur) => (
                    <div key={acteur.id} className="flex items-center p-4 border rounded-lg">
                      <div
                        className={`w-3 h-3 rounded-full mr-4 ${
                          acteur.niveau === 0 ? "bg-red-500" : acteur.niveau === 1 ? "bg-orange-500" : "bg-green-500"
                        }`}
                      ></div>
                      <div className="flex-1">
                        <div className="flex items-center">
                          <h4 className="font-medium text-gray-900">{acteur.libelle}</h4>
                          <span className="ml-2 px-2 py-1 text-xs bg-gray-100 text-gray-600 rounded">
                            {acteur.code}
                          </span>
                        </div>
                        <p className="text-sm text-gray-600 mt-1">{acteur.responsabilites.slice(0, 2).join(" • ")}</p>
                      </div>
                      <span
                        className={`px-3 py-1 rounded-full text-xs font-medium ${
                          acteur.actif ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"
                        }`}
                      >
                        {acteur.actif ? "Actif" : "Inactif"}
                      </span>
                    </div>
                  ))}
              </div>
            </div>
          </div>
        )}

        {/* Acteurs Tab */}
        {selectedTab === "acteurs" && (
          <div className="space-y-6">
            <div className="card">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-gray-900">Acteurs du Système DISMAS</h3>
                <button onClick={() => setShowActeurModal(true)} className="btn-primary flex items-center">
                  <PlusIcon className="h-4 w-4 mr-2" />
                  Nouvel Acteur
                </button>
              </div>

              <div className="overflow-x-auto">
                <table className="table">
                  <thead>
                    <tr>
                      <th>Niveau</th>
                      <th>Code</th>
                      <th>Libellé</th>
                      <th>Parent</th>
                      <th>Responsabilités</th>
                      <th>Statut</th>
                      <th>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {mockActeurs.map((acteur) => (
                      <tr key={acteur.id}>
                        <td>
                          <span
                            className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                              acteur.niveau === 0
                                ? "bg-red-100 text-red-800"
                                : acteur.niveau === 1
                                  ? "bg-orange-100 text-orange-800"
                                  : acteur.niveau === 2
                                    ? "bg-green-100 text-green-800"
                                    : "bg-blue-100 text-blue-800"
                            }`}
                          >
                            Niveau {acteur.niveau}
                          </span>
                        </td>
                        <td className="font-mono text-sm">{acteur.code}</td>
                        <td className="font-medium">{acteur.libelle}</td>
                        <td className="text-sm text-gray-600">{acteur.parent || "-"}</td>
                        <td className="text-sm">
                          <div className="max-w-xs">
                            {acteur.responsabilites.slice(0, 2).map((resp, idx) => (
                              <div key={idx} className="text-gray-600">
                                • {resp}
                              </div>
                            ))}
                            {acteur.responsabilites.length > 2 && (
                              <div className="text-gray-400 text-xs">
                                +{acteur.responsabilites.length - 2} autres...
                              </div>
                            )}
                          </div>
                        </td>
                        <td>
                          <span className={`badge ${acteur.actif ? "badge-success" : "badge-danger"}`}>
                            {acteur.actif ? "Actif" : "Inactif"}
                          </span>
                        </td>
                        <td>
                          <div className="flex space-x-2">
                            <button
                              onClick={() => setSelectedActeur(acteur)}
                              className="text-blue-600 hover:text-blue-800"
                            >
                              <EyeIcon className="h-4 w-4" />
                            </button>
                            <button
                              onClick={() => setSelectedActeur(acteur)}
                              className="text-orange-600 hover:text-orange-800"
                            >
                              <PencilIcon className="h-4 w-4" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* Workflow Tab */}
        {selectedTab === "workflow" && (
          <div className="space-y-6">
            <div className="card">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-gray-900">Workflow de Distribution (11 Étapes)</h3>
                <button onClick={() => setShowEtapeModal(true)} className="btn-primary flex items-center">
                  <PlusIcon className="h-4 w-4 mr-2" />
                  Nouvelle Étape
                </button>
              </div>

              <div className="space-y-4">
                {mockWorkflowEtapes.map((etape) => (
                  <div key={etape.id} className="border rounded-lg p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center">
                        <div className="w-8 h-8 bg-orange-100 text-orange-600 rounded-full flex items-center justify-center font-bold text-sm mr-4">
                          {etape.numero}
                        </div>
                        <div>
                          <h4 className="font-medium text-gray-900">{etape.titre}</h4>
                          <p className="text-sm text-gray-600">{etape.description}</p>
                          <div className="flex items-center mt-2 space-x-4">
                            <span className="text-xs text-gray-500">
                              <UserGroupIcon className="h-3 w-3 inline mr-1" />
                              {etape.acteur_responsable}
                            </span>
                            <span className="text-xs text-gray-500">
                              <ClockIcon className="h-3 w-3 inline mr-1" />
                              {etape.duree_prevue} jours
                            </span>
                            <span className="text-xs text-gray-500">
                              <DocumentTextIcon className="h-3 w-3 inline mr-1" />
                              {etape.documents_requis.length} documents
                            </span>
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <span className={`badge ${etape.actif ? "badge-success" : "badge-danger"}`}>
                          {etape.actif ? "Active" : "Inactive"}
                        </span>
                        <button onClick={() => setSelectedEtape(etape)} className="text-blue-600 hover:text-blue-800">
                          <EyeIcon className="h-4 w-4" />
                        </button>
                        <button
                          onClick={() => setSelectedEtape(etape)}
                          className="text-orange-600 hover:text-orange-800"
                        >
                          <PencilIcon className="h-4 w-4" />
                        </button>
                      </div>
                    </div>

                    {etape.documents_requis.length > 0 && (
                      <div className="mt-3 pt-3 border-t">
                        <p className="text-xs font-medium text-gray-700 mb-2">Documents requis :</p>
                        <div className="flex flex-wrap gap-2">
                          {etape.documents_requis.map((doc, idx) => (
                            <span key={idx} className="px-2 py-1 bg-gray-100 text-gray-700 text-xs rounded">
                              {doc}
                            </span>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Paramètres Tab */}
        {selectedTab === "parametres" && (
          <div className="space-y-6">
            <div className="card">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-gray-900">Paramètres Système DISMAS</h3>
                <button onClick={() => setShowParamModal(true)} className="btn-primary flex items-center">
                  <PlusIcon className="h-4 w-4 mr-2" />
                  Nouveau Paramètre
                </button>
              </div>

              {/* Filtres par catégorie */}
              <div className="mb-4">
                <div className="flex flex-wrap gap-2">
                  {["TOUS", "GENERAL", "STOCK", "WORKFLOW", "NOTIFICATION", "CONTROLE", "SECURITE", "THEME"].map(
                    (cat) => (
                      <button key={cat} className="px-3 py-1 text-sm border rounded-lg hover:bg-gray-50">
                        {cat}
                      </button>
                    ),
                  )}
                </div>
              </div>

              <div className="overflow-x-auto">
                <table className="table">
                  <thead>
                    <tr>
                      <th>Catégorie</th>
                      <th>Clé</th>
                      <th>Valeur</th>
                      <th>Type</th>
                      <th>Description</th>
                      <th>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {mockSystemParams.map((param) => (
                      <tr key={param.id}>
                        <td>
                          <span
                            className={`badge ${
                              param.categorie === "GENERAL"
                                ? "badge-info"
                                : param.categorie === "STOCK"
                                  ? "badge-warning"
                                  : param.categorie === "WORKFLOW"
                                    ? "badge-success"
                                    : param.categorie === "NOTIFICATION"
                                      ? "badge-purple"
                                      : param.categorie === "CONTROLE"
                                        ? "badge-orange"
                                        : param.categorie === "SECURITE"
                                          ? "badge-danger"
                                          : "badge-gray"
                            }`}
                          >
                            {param.categorie}
                          </span>
                        </td>
                        <td className="font-mono text-sm">{param.cle}</td>
                        <td>
                          <span
                            className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                              param.type_valeur === "BOOLEAN"
                                ? param.valeur === "true"
                                  ? "bg-green-100 text-green-800"
                                  : "bg-red-100 text-red-800"
                                : "bg-gray-100 text-gray-800"
                            }`}
                          >
                            {param.valeur}
                          </span>
                        </td>
                        <td>
                          <span className="badge-info">{param.type_valeur}</span>
                        </td>
                        <td className="text-sm text-gray-600 max-w-xs">{param.description}</td>
                        <td>
                          <button
                            onClick={() => setSelectedParam(param)}
                            className="text-orange-600 hover:text-orange-800 font-medium"
                          >
                            <PencilIcon className="h-4 w-4" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* Modals */}
        {(showParamModal || selectedParam) && (
          <div
            className="modal-overlay"
            onClick={() => {
              setShowParamModal(false)
              setSelectedParam(null)
            }}
          >
            <div className="modal-content max-w-lg" onClick={(e) => e.stopPropagation()}>
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold">{selectedParam ? "Modifier Paramètre" : "Nouveau Paramètre"}</h3>
                <button
                  onClick={() => {
                    setShowParamModal(false)
                    setSelectedParam(null)
                  }}
                  className="text-gray-400 hover:text-gray-600"
                >
                  ×
                </button>
              </div>

              <form className="space-y-4">
                <div className="form-group">
                  <label className="form-label">Catégorie</label>
                  <select className="input-field" defaultValue={selectedParam?.categorie || ""} required>
                    <option value="">Sélectionner la catégorie</option>
                    <option value="GENERAL">Général</option>
                    <option value="STOCK">Stock</option>
                    <option value="WORKFLOW">Workflow</option>
                    <option value="NOTIFICATION">Notification</option>
                    <option value="CONTROLE">Contrôle</option>
                    <option value="SECURITE">Sécurité</option>
                    <option value="THEME">Thème</option>
                  </select>
                </div>

                <div className="form-group">
                  <label className="form-label">Clé</label>
                  <input
                    type="text"
                    className="input-field font-mono"
                    defaultValue={selectedParam?.cle || ""}
                    placeholder="EXEMPLE_CLE_PARAMETRE"
                    required
                  />
                </div>

                <div className="form-group">
                  <label className="form-label">Valeur</label>
                  <input type="text" className="input-field" defaultValue={selectedParam?.valeur || ""} required />
                </div>

                <div className="form-group">
                  <label className="form-label">Type</label>
                  <select className="input-field" defaultValue={selectedParam?.type_valeur || ""} required>
                    <option value="">Sélectionner le type</option>
                    <option value="STRING">Chaîne de caractères</option>
                    <option value="INTEGER">Nombre entier</option>
                    <option value="BOOLEAN">Booléen</option>
                    <option value="JSON">JSON</option>
                  </select>
                </div>

                <div className="form-group">
                  <label className="form-label">Description</label>
                  <textarea
                    className="input-field"
                    rows={3}
                    defaultValue={selectedParam?.description || ""}
                    placeholder="Description détaillée du paramètre..."
                  ></textarea>
                </div>

                <div className="flex justify-end space-x-3">
                  <button
                    type="button"
                    onClick={() => {
                      setShowParamModal(false)
                      setSelectedParam(null)
                    }}
                    className="btn-outline"
                  >
                    Annuler
                  </button>
                  <button type="submit" className="btn-primary">
                    {selectedParam ? "Modifier" : "Créer"}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
        {/* Modal Nouvel Acteur */}
        {(showActeurModal || selectedActeur) && (
          <div
            className="modal-overlay"
            onClick={() => {
              setShowActeurModal(false)
              setSelectedActeur(null)
            }}
          >
            <div className="modal-content max-w-2xl" onClick={(e) => e.stopPropagation()}>
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold">{selectedActeur ? "Modifier Acteur" : "Nouvel Acteur"}</h3>
                <button
                  onClick={() => {
                    setShowActeurModal(false)
                    setSelectedActeur(null)
                  }}
                  className="text-gray-400 hover:text-gray-600"
                >
                  ×
                </button>
              </div>

              <form className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="form-group">
                    <label className="form-label">Code Acteur</label>
                    <input
                      type="text"
                      className="input-field font-mono"
                      defaultValue={selectedActeur?.code || ""}
                      placeholder="ex: DRENA_ABIDJAN"
                      required
                    />
                  </div>

                  <div className="form-group">
                    <label className="form-label">Niveau Hiérarchique</label>
                    <select className="input-field" defaultValue={selectedActeur?.niveau || ""} required>
                      <option value="">Sélectionner le niveau</option>
                      <option value="0">Niveau 0 - Ministère</option>
                      <option value="1">Niveau 1 - Directions Centrales</option>
                      <option value="2">Niveau 2 - Directions Régionales</option>
                      <option value="3">Niveau 3 - Inspections</option>
                      <option value="4">Niveau 4 - Écoles</option>
                    </select>
                  </div>
                </div>

                <div className="form-group">
                  <label className="form-label">Libellé</label>
                  <input
                    type="text"
                    className="input-field"
                    defaultValue={selectedActeur?.libelle || ""}
                    placeholder="ex: Direction Régionale de l'Éducation Nationale d'Abidjan"
                    required
                  />
                </div>

                <div className="form-group">
                  <label className="form-label">Acteur Parent</label>
                  <select className="input-field" defaultValue={selectedActeur?.parent || ""}>
                    <option value="">Aucun parent (niveau racine)</option>
                    <option value="MENA">MENA - Ministère</option>
                    <option value="DAF">DAF - Direction des Affaires Financières</option>
                    <option value="DRENA">DRENA - Direction Régionale</option>
                    <option value="IEPP">IEPP - Inspection</option>
                    <option value="EPP">EPP - École Primaire</option>
                  </select>
                </div>

                <div className="form-group">
                  <label className="form-label">Responsabilités</label>
                  <textarea
                    className="input-field"
                    rows={4}
                    defaultValue={selectedActeur?.responsabilites?.join("\n") || ""}
                    placeholder="Une responsabilité par ligne&#10;ex: Supervision des IEPP&#10;Collecte des bordereaux&#10;Régulations internes"
                  ></textarea>
                  <p className="text-xs text-gray-500 mt-1">Séparez chaque responsabilité par une nouvelle ligne</p>
                </div>

                <div className="form-group">
                  <label className="flex items-center">
                    <input
                      type="checkbox"
                      className="rounded border-gray-300 text-orange-600 focus:ring-orange-500"
                      defaultChecked={selectedActeur?.actif !== false}
                    />
                    <span className="ml-2 text-sm font-medium text-gray-700">Acteur actif</span>
                  </label>
                </div>

                <div className="flex justify-end space-x-3">
                  <button
                    type="button"
                    onClick={() => {
                      setShowActeurModal(false)
                      setSelectedActeur(null)
                    }}
                    className="btn-outline"
                  >
                    Annuler
                  </button>
                  <button type="submit" className="btn-primary">
                    {selectedActeur ? "Modifier" : "Créer"}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    </MainLayout>
  )
}
