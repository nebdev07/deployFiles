"use client"

import { logger } from '@/lib/utils/logger'

import { useState, useEffect } from "react"
import MainLayout from "../../../components/layout/main-layout"
import { useAuth } from "../../providers"
import { ParametrageService } from "@/lib/services/parametrage.service"
import { RoleService } from "@/lib/services/role.service"
import { TypeOuvrage, Matiere, NiveauScolaire, StructureAdministrative, Role } from "@/lib/types/entities"
import {
  Cog6ToothIcon,
  PlusIcon,
  PencilIcon,
  TrashIcon,
  MagnifyingGlassIcon,
  ArrowPathIcon,
  XCircleIcon,
  CheckCircleIcon,
} from "@heroicons/react/24/outline"

type ParametrageType = 'typeOuvrage' | 'matiere' | 'niveauScolaire' | 'structure' | 'role'

interface ParametrageItem {
  id: number;
  code: string;
  libelle: string;
  description?: string;
  isActive?: boolean;
  type: ParametrageType;
}

export default function ParametragesPageIntegrated() {
  const { user } = useAuth()
  const [activeTab, setActiveTab] = useState<ParametrageType>('typeOuvrage')
  const [searchTerm, setSearchTerm] = useState("")
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  
  // Données des différents paramétrages
  const [typeOuvrages, setTypeOuvrages] = useState<TypeOuvrage[]>([])
  const [matieres, setMatieres] = useState<Matiere[]>([])
  const [niveauxScolaires, setNiveauxScolaires] = useState<NiveauScolaire[]>([])
  const [structures, setStructures] = useState<StructureAdministrative[]>([])
  const [roles, setRoles] = useState<Role[]>([])

  const parametrageService = new ParametrageService()
  const roleService = new RoleService()

  // Vérification des permissions
  if (!user || !["ADMIN", "DAF", "DPFC"].includes(user.role.code.toUpperCase())) {
    return (
      <MainLayout>
        <div className="flex items-center justify-center h-64">
          <div className="text-center">
            <Cog6ToothIcon className="mx-auto h-12 w-12 text-gray-400" />
            <h3 className="mt-2 text-sm font-medium text-gray-900">Accès Restreint</h3>
            <p className="mt-1 text-sm text-gray-500">
              Seuls les administrateurs peuvent accéder aux paramétrages
            </p>
          </div>
        </div>
      </MainLayout>
    )
  }

  // Charger les données selon l'onglet actif
  const loadData = async () => {
    setLoading(true)
    setError(null)
    
    try {
      switch (activeTab) {
        case 'typeOuvrage':
          const typeOuvrageResponse = await parametrageService.getAllTypeOuvrages()
          setTypeOuvrages(typeOuvrageResponse.items || [])
          break
        case 'matiere':
          const matiereResponse = await parametrageService.getAllMatieres()
          setMatieres(matiereResponse.items || [])
          break
        case 'niveauScolaire':
          const niveauResponse = await parametrageService.getAllNiveauxScolaires()
          setNiveauxScolaires(niveauResponse.items || [])
          break
        case 'structure':
          const structureResponse = await parametrageService.getAllStructuresAdministratives()
          setStructures(structureResponse.items || [])
          break
        case 'role':
          const roleResponse = await roleService.getAllRoles()
          setRoles(roleResponse.items || [])
          break
      }
    } catch (err) {
      setError('Erreur lors du chargement des données')
      logger.error('Erreur:', err)
    } finally {
      setLoading(false)
    }
  }

  // Charger les données au montage et lors du changement d'onglet
  useEffect(() => {
    loadData()
  }, [activeTab])

  // Obtenir les données de l'onglet actif
  const getCurrentData = (): ParametrageItem[] => {
    const baseData = {
      typeOuvrage: typeOuvrages,
      matiere: matieres,
      niveauScolaire: niveauxScolaires,
      structure: structures,
      role: roles,
    }[activeTab] as any[]

    return baseData.map(item => ({
      id: item.id,
      code: item.code,
      libelle: item.libelle,
      description: item.description,
      isActive: item.isActive,
      type: activeTab,
    }))
  }

  // Filtrer les données selon la recherche
  const getFilteredData = (): ParametrageItem[] => {
    const data = getCurrentData()
    if (!searchTerm.trim()) return data
    
    return data.filter(item =>
      item.code.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.libelle.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (item.description && item.description.toLowerCase().includes(searchTerm.toLowerCase()))
    )
  }

  const handleCreate = async () => {
    // TODO: Implémenter la création
    logger.log('Créer un nouvel élément:', activeTab)
  }

  const handleEdit = async (item: ParametrageItem) => {
    // TODO: Implémenter la modification
    logger.log('Modifier:', item)
  }

  const handleDelete = async (item: ParametrageItem) => {
    if (confirm(`Êtes-vous sûr de vouloir supprimer "${item.libelle}" ?`)) {
      try {
        switch (item.type) {
          case 'typeOuvrage':
            await parametrageService.deleteTypeOuvrage(item.id)
            break
          case 'matiere':
            await parametrageService.deleteMatiere(item.id)
            break
          case 'niveauScolaire':
            await parametrageService.deleteNiveauScolaire(item.id)
            break
          case 'structure':
            await parametrageService.deleteStructureAdministrative(item.id)
            break
          case 'role':
            await roleService.deleteRole(item.id)
            break
        }
        await loadData() // Recharger les données
      } catch (err) {
        logger.error('Erreur lors de la suppression:', err)
      }
    }
  }

  const tabs = [
    { id: 'typeOuvrage', name: 'Types d\'Ouvrages', count: typeOuvrages.length },
    { id: 'matiere', name: 'Matières', count: matieres.length },
    { id: 'niveauScolaire', name: 'Niveaux Scolaires', count: niveauxScolaires.length },
    { id: 'structure', name: 'Structures', count: structures.length },
    { id: 'role', name: 'Rôles', count: roles.length },
  ]

  const filteredData = getFilteredData()

  return (
    <MainLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Paramétrages Système</h1>
            <p className="text-gray-600">
              Configuration des données de référence du système
            </p>
          </div>
          <div className="flex items-center space-x-3">
            <button
              onClick={loadData}
              className="btn-secondary flex items-center"
              disabled={loading}
            >
              <ArrowPathIcon className={`h-4 w-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
              Actualiser
            </button>
            <button onClick={handleCreate} className="btn-primary flex items-center">
              <PlusIcon className="h-4 w-4 mr-2" />
              Nouveau
            </button>
          </div>
        </div>

        {/* Onglets */}
        <div className="border-b border-gray-200">
          <nav className="-mb-px flex space-x-8">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as ParametrageType)}
                className={`py-2 px-1 border-b-2 font-medium text-sm ${
                  activeTab === tab.id
                    ? 'border-orange-500 text-orange-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                {tab.name}
                <span className={`ml-2 px-2 py-1 text-xs rounded-full ${
                  activeTab === tab.id ? 'bg-orange-100 text-orange-600' : 'bg-gray-100 text-gray-600'
                }`}>
                  {tab.count}
                </span>
              </button>
            ))}
          </nav>
        </div>

        {/* Barre de recherche */}
        <div className="flex items-center space-x-4">
          <div className="flex-1 relative">
            <MagnifyingGlassIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
            <input
              type="text"
              placeholder={`Rechercher dans ${tabs.find(t => t.id === activeTab)?.name}...`}
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="input-field pl-10"
            />
          </div>
        </div>

        {/* Message d'erreur */}
        {error && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-4">
            <div className="flex">
              <XCircleIcon className="h-5 w-5 text-red-400" />
              <div className="ml-3">
                <h3 className="text-sm font-medium text-red-800">Erreur</h3>
                <p className="text-sm text-red-700 mt-1">{error}</p>
              </div>
            </div>
          </div>
        )}

        {/* Contenu de l'onglet */}
        <div className="bg-white shadow-sm rounded-lg border border-gray-200">
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Code
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Libellé
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Description
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Statut
                  </th>
                  <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {loading ? (
                  <tr>
                    <td colSpan={5} className="px-6 py-12 text-center">
                      <div className="flex items-center justify-center">
                        <ArrowPathIcon className="h-6 w-6 animate-spin text-gray-400" />
                        <span className="ml-2 text-gray-500">Chargement des données...</span>
                      </div>
                    </td>
                  </tr>
                ) : filteredData.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="px-6 py-12 text-center">
                      <Cog6ToothIcon className="mx-auto h-12 w-12 text-gray-400" />
                      <h3 className="mt-2 text-sm font-medium text-gray-900">Aucune donnée</h3>
                      <p className="mt-1 text-sm text-gray-500">
                        {searchTerm ? 'Aucun élément ne correspond à votre recherche.' : 'Aucun élément configuré pour ce paramétrage.'}
                      </p>
                    </td>
                  </tr>
                ) : (
                  filteredData.map((item) => (
                    <tr key={item.id} className="hover:bg-gray-50">
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm font-medium text-gray-900">{item.code}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-900">{item.libelle}</div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="text-sm text-gray-500 max-w-xs truncate">
                          {item.description || 'Aucune description'}
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center">
                          {item.isActive ? (
                            <CheckCircleIcon className="h-5 w-5 text-green-500" />
                          ) : (
                            <XCircleIcon className="h-5 w-5 text-red-500" />
                          )}
                          <span className={`ml-2 text-sm ${item.isActive ? 'text-green-700' : 'text-red-700'}`}>
                            {item.isActive ? 'Actif' : 'Inactif'}
                          </span>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                        <div className="flex items-center justify-end space-x-2">
                          <button
                            onClick={() => handleEdit(item)}
                            className="text-indigo-600 hover:text-indigo-800"
                            title="Modifier"
                          >
                            <PencilIcon className="h-4 w-4" />
                          </button>
                          <button
                            onClick={() => handleDelete(item)}
                            className="text-red-600 hover:text-red-800"
                            title="Supprimer"
                          >
                            <TrashIcon className="h-4 w-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Statistiques */}
        <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
          {tabs.map((tab) => (
            <div key={tab.id} className="bg-white p-4 rounded-lg border border-gray-200">
              <div className="flex items-center">
                <div className={`p-2 rounded-lg ${
                  activeTab === tab.id ? 'bg-orange-100' : 'bg-gray-100'
                }`}>
                  <Cog6ToothIcon className={`h-6 w-6 ${
                    activeTab === tab.id ? 'text-orange-600' : 'text-gray-600'
                  }`} />
                </div>
                <div className="ml-3">
                  <p className="text-sm font-medium text-gray-900">{tab.name}</p>
                  <p className="text-2xl font-bold text-gray-900">{tab.count}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </MainLayout>
  )
}