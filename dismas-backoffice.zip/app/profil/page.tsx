"use client"

import { FormEvent, useEffect, useMemo, useState } from "react"
import { useRouter } from "next/navigation"
import toast from "react-hot-toast"
import MainLayout from "@/components/layout/main-layout"
import { useAuth } from "@/app/providers"
import { useConsultationOnly } from "@/hooks/use-consultation-only"
import { usersService } from "@/lib/services/users.service"
import { authService, AuthService } from "@/lib/services/auth.service"
import type { LegacyUser } from "@/lib/types/entities"

export default function ProfilPage() {
  const router = useRouter()
  const { user, logout, refreshUserSession } = useAuth()
  const { consultationOnly } = useConsultationOnly()

  const [savingProfile, setSavingProfile] = useState(false)
  const [savingPassword, setSavingPassword] = useState(false)

  const [profileForm, setProfileForm] = useState({
    firstName: user?.prenoms || "",
    lastName: user?.nom || "",
    email: user?.email || "",
    login: user?.login || "",
    telephone: "",
  })

  useEffect(() => {
    if (!user) return
    setProfileForm({
      firstName: user.prenoms || "",
      lastName: user.nom || "",
      email: user.email || "",
      login: user.login || "",
      telephone: (user as unknown as { telephone?: string }).telephone || "",
    })
  }, [user])

  const [passwordForm, setPasswordForm] = useState({
    currentPassword: "",
    newPassword: "",
    confirmPassword: "",
  })

  const userInitials = useMemo(() => {
    const first = profileForm.firstName?.trim()?.charAt(0) || ""
    const last = profileForm.lastName?.trim()?.charAt(0) || ""
    return `${first}${last}`.toUpperCase()
  }, [profileForm.firstName, profileForm.lastName])

  const legacy = user ? (user as unknown as LegacyUser) : null
  const roleCode = (user?.role?.code || "").toUpperCase()
  const isIeppProfile = roleCode === "IEPP"
  const isEppProfile = roleCode === "DIRECTEUR" || !!legacy?.epp?.id

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p className="text-gray-600">Chargement...</p>
      </div>
    )
  }

  const handleProfileSubmit = async (e: FormEvent) => {
    e.preventDefault()
    if (consultationOnly) {
      toast.error("La modification du profil n’est pas disponible en mode consultation.")
      return
    }
    if (savingProfile || savingPassword) return

    if (!profileForm.firstName.trim() || !profileForm.lastName.trim() || !profileForm.login.trim()) {
      toast.error("Les champs Nom, Prénoms et Login sont obligatoires")
      return
    }

    setSavingProfile(true)
    try {
      const response = await usersService.updateUser(user.id, {
        firstName: profileForm.firstName.trim(),
        lastName: profileForm.lastName.trim(),
        email: profileForm.email.trim(),
        login: profileForm.login.trim(),
        telephone: profileForm.telephone.trim() || undefined,
      })

      if (response.hasError) {
        toast.error(response.status?.message || "Erreur lors de la mise à jour du profil")
        return
      }

      const currentAuthService = new AuthService()
      const session = currentAuthService.getUserSession()
      if (session?.user) {
        const updatedSessionUser = {
          ...session.user,
          firstName: profileForm.firstName.trim(),
          lastName: profileForm.lastName.trim(),
          email: profileForm.email.trim(),
          login: profileForm.login.trim(),
          telephone: profileForm.telephone.trim() || (session.user as any).telephone,
        }

        const patchedResponse = {
          hasError: false,
          items: [updatedSessionUser],
        } as any
        currentAuthService.saveUserSession(patchedResponse)
        refreshUserSession()
      }

      toast.success("Profil mis à jour avec succès")
    } catch (error: any) {
      toast.error(error?.message || "Erreur lors de la mise à jour du profil")
    } finally {
      setSavingProfile(false)
    }
  }

  const handlePasswordSubmit = async (e: FormEvent) => {
    e.preventDefault()
    if (savingPassword || savingProfile) return

    if (!passwordForm.currentPassword || !passwordForm.newPassword || !passwordForm.confirmPassword) {
      toast.error("Veuillez renseigner tous les champs du mot de passe")
      return
    }

    if (passwordForm.newPassword.length < 6) {
      toast.error("Le nouveau mot de passe doit contenir au moins 6 caractères")
      return
    }

    if (passwordForm.newPassword !== passwordForm.confirmPassword) {
      toast.error("La confirmation du mot de passe ne correspond pas")
      return
    }

    setSavingPassword(true)
    try {
      const response = await authService.changePasswordFirstLogin({
        login: user.login,
        currentPassword: passwordForm.currentPassword,
        newPassword: passwordForm.newPassword,
      })

      if (response.hasError) {
        toast.error(response.status?.message || "Erreur lors du changement du mot de passe")
        return
      }

      toast.success("Mot de passe modifié. Veuillez vous reconnecter.")
      await logout()
      router.push("/auth/login")
    } catch (error: any) {
      toast.error(error?.message || "Erreur lors du changement du mot de passe")
    } finally {
      setSavingPassword(false)
    }
  }

  return (
    <MainLayout>
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Mon profil</h1>
            <p className="text-gray-600">Gérez vos informations personnelles et votre mot de passe</p>
          </div>
        </div>

        <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
          <div className="card xl:col-span-1">
            <div className="flex flex-col items-center text-center">
              <div className="w-20 h-20 bg-gradient-to-r from-orange-500 to-green-500 rounded-full flex items-center justify-center text-white text-2xl font-bold">
                {userInitials || "U"}
              </div>
              <h2 className="mt-4 text-lg font-semibold text-gray-900">
                {profileForm.firstName} {profileForm.lastName}
              </h2>
              <p className="text-sm text-gray-500">{user.role?.libelle}</p>
              <div className="mt-4 w-full space-y-3 text-sm text-left">
                <div className="rounded-lg border border-gray-200 bg-white px-3 py-2.5 shadow-sm">
                  <p className="text-xs font-semibold uppercase tracking-wide text-gray-400">
                    {isIeppProfile
                      ? "Votre inspection (IEPP)"
                      : isEppProfile
                        ? "Votre établissement (EPP)"
                        : "Structure de rattachement"}
                  </p>
                  <p className="mt-1 font-medium text-gray-900 leading-snug">{user.structure?.libelle || "—"}</p>
                  {user.structure?.code ? (
                    <p className="text-xs text-gray-500 font-mono mt-0.5">{user.structure.code}</p>
                  ) : null}
                </div>

                {isIeppProfile && legacy?.drena && (
                  <div className="rounded-lg border border-emerald-200/90 bg-emerald-50/70 px-3 py-2.5 shadow-sm">
                    <div className="h-px w-full bg-gradient-to-r from-transparent via-emerald-300/80 to-transparent mb-2.5" aria-hidden />
                    <p className="text-xs font-semibold uppercase tracking-wide text-emerald-800/90">DRENA de rattachement</p>
                    <div className="mt-2 rounded-md border border-emerald-100 bg-white/90 px-2.5 py-2 shadow-sm">
                      <p className="font-medium text-gray-900 leading-snug">{legacy.drena.libelle}</p>
                      {legacy.drena.code ? (
                        <p className="text-xs text-gray-500 font-mono mt-1">{legacy.drena.code}</p>
                      ) : null}
                    </div>
                  </div>
                )}

                {isEppProfile && legacy && (legacy.iepp || legacy.drena) && (
                  <div className="rounded-lg border border-emerald-200/90 bg-emerald-50/70 px-3 py-2.5 shadow-sm">
                    <div className="h-px w-full bg-gradient-to-r from-transparent via-emerald-300/80 to-transparent mb-2.5" aria-hidden />
                    <p className="text-xs font-semibold uppercase tracking-wide text-emerald-800/90">
                      Rattachement (structures parentes)
                    </p>
                    <div className="mt-2 space-y-2">
                      {legacy.iepp && (
                        <div className="rounded-md border border-emerald-100 bg-white/90 px-2.5 py-2 shadow-sm">
                          <p className="text-[10px] font-bold uppercase tracking-wider text-emerald-800">IEPP</p>
                          <p className="font-medium text-gray-900 mt-0.5 leading-snug">{legacy.iepp.libelle}</p>
                          {legacy.iepp.code ? (
                            <p className="text-xs text-gray-500 font-mono mt-1">{legacy.iepp.code}</p>
                          ) : null}
                        </div>
                      )}
                      {legacy.drena && (
                        <>
                          {legacy.iepp && (
                            <div
                              className="flex items-center gap-2 py-0.5 text-emerald-700/70"
                              aria-hidden
                            >
                              <span className="h-px flex-1 border-t border-dashed border-emerald-300/90" />
                              <span className="text-[10px] uppercase tracking-wider shrink-0">puis</span>
                              <span className="h-px flex-1 border-t border-dashed border-emerald-300/90" />
                            </div>
                          )}
                          <div className="rounded-md border border-emerald-100 bg-white/90 px-2.5 py-2 shadow-sm">
                            <p className="text-[10px] font-bold uppercase tracking-wider text-emerald-800">DRENA</p>
                            <p className="font-medium text-gray-900 mt-0.5 leading-snug">{legacy.drena.libelle}</p>
                            {legacy.drena.code ? (
                              <p className="text-xs text-gray-500 font-mono mt-1">{legacy.drena.code}</p>
                            ) : null}
                          </div>
                        </>
                      )}
                    </div>
                  </div>
                )}
                <div className="flex items-center justify-between border rounded-lg px-3 py-2">
                  <span className="text-gray-500">Login</span>
                  <span className="font-medium text-gray-900">{profileForm.login || "N/A"}</span>
                </div>
                <div className="flex items-center justify-between border rounded-lg px-3 py-2">
                  <span className="text-gray-500">Email</span>
                  <span className="font-medium text-gray-900 break-all text-right max-w-[65%]">{profileForm.email || "N/A"}</span>
                </div>
              </div>
            </div>
          </div>

          <div className="xl:col-span-2 space-y-6">
            <div className="card">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Informations personnelles</h3>
              {consultationOnly && (
                <p className="mb-4 text-sm text-amber-800 bg-amber-50 border border-amber-200 rounded-lg px-3 py-2">
                  En mode consultation, les informations d’identité sont affichées en lecture seule. Le changement de
                  mot de passe reste disponible ci-dessous.
                </p>
              )}
              <form onSubmit={handleProfileSubmit} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="form-group">
                    <label className="form-label">Prénoms *</label>
                    <input
                      className="input-field"
                      value={profileForm.firstName}
                      onChange={(e) => setProfileForm((p) => ({ ...p, firstName: e.target.value }))}
                      required
                      readOnly={consultationOnly}
                      disabled={consultationOnly}
                    />
                  </div>
                  <div className="form-group">
                    <label className="form-label">Nom *</label>
                    <input
                      className="input-field"
                      value={profileForm.lastName}
                      onChange={(e) => setProfileForm((p) => ({ ...p, lastName: e.target.value }))}
                      required
                      readOnly={consultationOnly}
                      disabled={consultationOnly}
                    />
                  </div>
                  <div className="form-group">
                    <label className="form-label">Email</label>
                    <input
                      type="email"
                      className="input-field"
                      value={profileForm.email}
                      onChange={(e) => setProfileForm((p) => ({ ...p, email: e.target.value }))}
                      readOnly={consultationOnly}
                      disabled={consultationOnly}
                    />
                  </div>
                  <div className="form-group">
                    <label className="form-label">Téléphone</label>
                    <input
                      className="input-field"
                      placeholder="+225XXXXXXXXXX"
                      value={profileForm.telephone}
                      onChange={(e) => setProfileForm((p) => ({ ...p, telephone: e.target.value }))}
                      readOnly={consultationOnly}
                      disabled={consultationOnly}
                    />
                  </div>
                  <div className="form-group md:col-span-2">
                    <label className="form-label">Login *</label>
                    <input
                      className="input-field"
                      value={profileForm.login}
                      onChange={(e) => setProfileForm((p) => ({ ...p, login: e.target.value }))}
                      required
                      readOnly={consultationOnly}
                      disabled={consultationOnly}
                    />
                  </div>
                </div>
                <div className="flex justify-end">
                  <button
                    type="submit"
                    className="btn-primary"
                    disabled={savingProfile || savingPassword || consultationOnly}
                  >
                    {savingProfile ? "Enregistrement..." : "Enregistrer les modifications"}
                  </button>
                </div>
              </form>
            </div>

            <div className="card">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Changer le mot de passe</h3>
              <form onSubmit={handlePasswordSubmit} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="form-group md:col-span-2">
                    <label className="form-label">Mot de passe actuel *</label>
                    <input
                      type="password"
                      autoComplete="current-password"
                      className="input-field"
                      value={passwordForm.currentPassword}
                      onChange={(e) => setPasswordForm((p) => ({ ...p, currentPassword: e.target.value }))}
                      required
                    />
                  </div>
                  <div className="form-group">
                    <label className="form-label">Nouveau mot de passe *</label>
                    <input
                      type="password"
                      className="input-field"
                      value={passwordForm.newPassword}
                      onChange={(e) => setPasswordForm((p) => ({ ...p, newPassword: e.target.value }))}
                      required
                    />
                  </div>
                  <div className="form-group">
                    <label className="form-label">Confirmer le mot de passe *</label>
                    <input
                      type="password"
                      className="input-field"
                      value={passwordForm.confirmPassword}
                      onChange={(e) => setPasswordForm((p) => ({ ...p, confirmPassword: e.target.value }))}
                      required
                    />
                  </div>
                </div>
                <div className="flex justify-end">
                  <button type="submit" className="btn-primary" disabled={savingPassword || savingProfile}>
                    {savingPassword ? "Modification..." : "Modifier le mot de passe"}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </MainLayout>
  )
}

