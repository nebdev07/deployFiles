"use client"

import { useState, useEffect } from "react"
import MainLayout from "../../components/layout/main-layout"
import { useAuth } from "../providers"
import { useAnneesScolaires } from "@/hooks/use-annees-scolaires"
import { dashboardService } from "@/lib/services/dashboard.service"
import {
  CubeIcon,
  TruckIcon,
  AcademicCapIcon,
  ExclamationTriangleIcon,
  ChartBarIcon,
  DocumentTextIcon,
  UserGroupIcon,
  BuildingOfficeIcon,
  ClockIcon,
  CheckCircleIcon,
  FunnelIcon,
  ArrowPathIcon,
  BookOpenIcon,
  UsersIcon,
  MapPinIcon,
} from "@heroicons/react/24/outline"
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line,
} from "recharts"

// Types pour les données
interface StructureStats {
  drena: number
  iepp: number
  epp: number
}

interface ManuelStats {
  titre: string
  niveau: string
  quantite: number
  distribues: number
  enStock: number
  tauxCouverture: number
}

interface RetourManuel {
  titre: string
  niveau: string
  totalRetournes: number
  bonEtat: number
  moyennementEndommage: number
  horsUsage: number
}

interface RetourDetaille {
  titre: string
  niveau: string
  structure: string
  quantite_bon_etat: number
  quantite_moyen_etat: number
  quantite_mauvais_etat: number
  quantite_perdue: number
  total_retourne: number
}

interface DashboardData {
  // Structures
  totalStructures: StructureStats
  structuresParZone: Array<{
    zone: string
    iepp: number
    epp: number
  }>
  
  // Élèves et couverture
  totalEleves: number
  elevesParClasse: Array<{
    epp: string
    classe: string
    effectif: number
    manuelsRecus: number
  }>
  
  // Manuels
  totalManuelsRequis: number
  totalManuelsCommandes: number
  totalManuelsDistribues: number
  couvertureGlobale: number
  
  // Manuels par titre/niveau
  manuelsParTitre: ManuelStats[]
  
  // Retours
  retoursManuels: RetourManuel[]
  retoursDetaille: RetourDetaille[]
  
  // Distribution
  distribution: {
    planifiees: number
    enCours: number
    terminees: number
    retards: number
  }
  
  // Processus
  expressionBesoins: {
    eppSaisies: number
    eppEnAttente: number
    ieppConsolidees: number
    ieppEnAttente: number
    drenaConsolidees: number
    drenaEnAttente: number
  }
  
  // Commandes
  commandes: {
    commandesEnCours: number
    commandesTerminees: number
    montantTotal: number
    montantPaye: number
    montantRestant: number
  }
  

  
  // Workflow de distribution
  workflowDistribution: Array<{
    etape: number
    titre: string
    statut: "complete" | "current" | "pending"
    acteur: string
    description: string
    dateDebut?: string
    dateFin?: string
  }>
}

// Helpers de normalisation pour garantir les invariants métier
const clamp = (value: number, min: number, max: number): number => {
  if (value < min) return min
  if (value > max) return max
  return value
}

const normalizeElevesParClasse = (
  classes: Array<{ epp: string; classe: string; effectif: number; manuelsRecus: number }>,
): Array<{ epp: string; classe: string; effectif: number; manuelsRecus: number }> => {
  return classes.map((c) => ({
    ...c,
    manuelsRecus: Math.min(c.manuelsRecus, c.effectif),
  }))
}

const normalizeManuelsParTitre = (
  manuels: ManuelStats[],
): ManuelStats[] => {
  return manuels.map((m) => {
    const quantite = Math.max(0, Math.round(m.quantite))
    const distribues = clamp(Math.round(m.distribues), 0, quantite)
    const enStock = Math.max(0, quantite - distribues)
    const tauxCouverture = quantite > 0 ? Math.round((distribues / quantite) * 100) : 0
    return { ...m, quantite, distribues, enStock, tauxCouverture }
  })
}

const recomputeTotalsFromDetails = (
  manuels: ManuelStats[],
  existingCommandesTotal: number,
) => {
  const totalManuelsRequis = manuels.reduce((sum, m) => sum + m.quantite, 0)
  const totalManuelsDistribues = manuels.reduce((sum, m) => sum + m.distribues, 0)
  // S'assurer que les commandes ne dépassent pas les besoins
  const totalManuelsCommandes = Math.min(Math.max(0, Math.round(existingCommandesTotal)), totalManuelsRequis)
  const couvertureGlobale = totalManuelsRequis > 0
    ? Math.round((totalManuelsDistribues / totalManuelsRequis) * 100)
    : 0
  return { totalManuelsRequis, totalManuelsDistribues, totalManuelsCommandes, couvertureGlobale }
}

const normalizeDashboard = (data: DashboardData): DashboardData => {
  const elevesParClasse = normalizeElevesParClasse(data.elevesParClasse)
  const manuelsParTitre = normalizeManuelsParTitre(data.manuelsParTitre)
  /** Sans détail par titre, l’API /summary fournit déjà les agrégats — ne pas les écraser à zéro. */
  if (manuelsParTitre.length === 0) {
    return {
      ...data,
      elevesParClasse,
      manuelsParTitre,
    }
  }
  const totals = recomputeTotalsFromDetails(
    manuelsParTitre,
    data.commandes.montantTotal ? data.totalManuelsCommandes : data.totalManuelsCommandes,
  )
  return {
    ...data,
    elevesParClasse,
    manuelsParTitre,
    totalManuelsRequis: totals.totalManuelsRequis,
    totalManuelsDistribues: totals.totalManuelsDistribues,
    totalManuelsCommandes: totals.totalManuelsCommandes,
    couvertureGlobale: totals.couvertureGlobale,
  }
}

const buildEmptyDashboard = (
  userRole: string,
  structureLabel?: string,
): DashboardData => {
  // ✅ Pas de données mockées : uniquement des valeurs neutres/vides tant que l'API ne fournit pas la section
  return {
    totalStructures: { drena: 0, iepp: 0, epp: 0 },
    structuresParZone: [],
    totalEleves: 0,
    elevesParClasse: [],
    totalManuelsRequis: 0,
    totalManuelsCommandes: 0,
    totalManuelsDistribues: 0,
    couvertureGlobale: 0,
    manuelsParTitre: [],
    retoursManuels: [],
    retoursDetaille: [],
    distribution: { planifiees: 0, enCours: 0, terminees: 0, retards: 0 },
    expressionBesoins: {
      eppSaisies: 0,
      eppEnAttente: 0,
      ieppConsolidees: 0,
      ieppEnAttente: 0,
      drenaConsolidees: 0,
      drenaEnAttente: 0,
    },
    commandes: {
      commandesEnCours: 0,
      commandesTerminees: 0,
      montantTotal: 0,
      montantPaye: 0,
      montantRestant: 0,
    },
    workflowDistribution: [],
  }
}

export default function DashboardPage() {
  const { user } = useAuth()
  const [dashboardData, setDashboardData] = useState<DashboardData | null>(null)
  const [drenaActivites, setDrenaActivites] = useState<any | null>(null)
  const { anneesScolaires, loading: anneesLoading } = useAnneesScolaires()
  const [anneeScolaireId, setAnneeScolaireId] = useState<number | null>(null)
  const [selectedPeriodLabel, setSelectedPeriodLabel] = useState<string>("")
  const [selectedFilter, setSelectedFilter] = useState("all")
  const [selectedZone, setSelectedZone] = useState("all")

  useEffect(() => {
    if (anneesScolaires.length > 0 && anneeScolaireId === null) {
      const courante = anneesScolaires.find((a: any) => a.estCourante) || anneesScolaires[0]
      setAnneeScolaireId(courante?.id ?? null)
      setSelectedPeriodLabel(courante?.libelle ?? "")
    }
  }, [anneesScolaires, anneeScolaireId])

  useEffect(() => {
    const load = async () => {
      if (!user?.role?.code || !anneeScolaireId) return

      const base = buildEmptyDashboard(user.role.code, user.structure?.libelle)

      /** Périmètre national (MENA) : même convention que le backend (parentId racine = 1). */
      const nationalRootId = (() => {
        const raw = process.env.NEXT_PUBLIC_NATIONAL_ROOT_STRUCTURE_ID
        const n = raw != null && raw !== "" ? parseInt(raw, 10) : 1
        return Number.isFinite(n) && n > 0 ? n : 1
      })()
      const summaryStructureId =
        user.structure?.id ??
        (["ADMIN", "DAF", "CABINET"].includes(user.role.code) ? nationalRootId : undefined)

      try {
        if (summaryStructureId) {
          const resp = await dashboardService.getSummary(summaryStructureId, anneeScolaireId)
          const item = resp.items?.[0] as any
          if (item) {
            setDashboardData(
              normalizeDashboard({
                ...base,
                totalStructures: item.totalStructures || base.totalStructures,
                totalEleves: item.totalEleves || 0,
                totalManuelsRequis: item.totalManuelsRequis || 0,
                totalManuelsCommandes: item.totalManuelsCommandes || 0,
                totalManuelsDistribues: item.totalManuelsDistribues || 0,
                couvertureGlobale: item.couvertureGlobale || 0,
              }),
            )
          } else {
            setDashboardData(base)
          }

          // Si DRENA : charger la vue "activité" IEPP -> EPP
          if (user.role.code === "DRENA" && user.structure?.id) {
            try {
              const act = await dashboardService.getDrenaActivites(user.structure.id, anneeScolaireId)
              setDrenaActivites(act.items?.[0] ?? null)
            } catch (e) {
              console.error("Erreur chargement activités DRENA:", e)
              setDrenaActivites(null)
            }
          } else {
            setDrenaActivites(null)
          }
        } else {
          setDashboardData(base)
          setDrenaActivites(null)
        }
      } catch (e) {
        console.error("Erreur chargement dashboard stats:", e)
        setDashboardData(base)
        setDrenaActivites(null)
      }
    }

    load()
  }, [user, anneeScolaireId])

  // ✅ CORRECTION: Vérification après tous les hooks
  if (!user || !dashboardData) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <p className="text-gray-600">Chargement...</p>
        </div>
      </div>
    )
  }

  const getWelcomeMessage = () => {
    const hour = new Date().getHours()
    const greeting = hour < 12 ? "Bonjour" : hour < 18 ? "Bon après-midi" : "Bonsoir"
    return `${greeting}, ${user.prenoms} ${user.nom}`
  }

  // Couleurs pour les graphiques
  const colors = ["#ff6600", "#00a651", "#3b82f6", "#f59e0b", "#ef4444", "#8b5cf6", "#06b6d4", "#84cc16"]

  // Données pour les graphiques
  const chartDataIEPP = dashboardData.structuresParZone.map(zone => ({
    zone: zone.zone,
    IEPP: zone.iepp,
    EPP: zone.epp,
  }))

  const chartDataManuels = dashboardData.manuelsParTitre.map(manuel => ({
    titre: `${manuel.titre} ${manuel.niveau}`,
    Distribués: manuel.distribues,
    "En Stock": manuel.enStock,
    "Taux Couverture": manuel.tauxCouverture,
  }))

  const chartDataRetours = dashboardData.retoursManuels.map(retour => ({
    titre: retour.titre,
    "Bon État": retour.bonEtat,
    "Moyennement Endommagé": retour.moyennementEndommage,
    "Hors d'Usage": retour.horsUsage,
  }))

  const pieDataCouverture = [
    { name: "Distribués", value: dashboardData.totalManuelsDistribues, color: "#00a651" },
    { name: "En Stock", value: dashboardData.totalManuelsCommandes - dashboardData.totalManuelsDistribues, color: "#ff6600" },
    { name: "Manquants", value: dashboardData.totalManuelsRequis - dashboardData.totalManuelsCommandes, color: "#ef4444" },
  ]

  return (
    <MainLayout>
      <div className="space-y-6">
        {/* Header avec message personnalisé */}
        <div className="bg-gradient-to-r from-orange-500 to-green-500 rounded-lg p-6 text-white">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold">{getWelcomeMessage()}</h1>
              <p className="text-orange-100">
                {user.role.libelle} - {user.structure?.libelle || "MENAET"}
              </p>
              <p className="text-sm text-orange-100 mt-1">
                Année scolaire {selectedPeriodLabel || "—"} • Système DISMAS
              </p>
            </div>
            <div className="text-right">
              <div className="text-3xl font-bold">{new Date().toLocaleDateString("fr-FR")}</div>
              <div className="text-sm text-orange-100">Côte d'Ivoire</div>
            </div>
          </div>
        </div>

        {/* Contrôles de filtrage */}
        <div className="card">
          <div className="flex flex-wrap gap-4 items-center justify-between">
            <h2 className="text-xl font-semibold text-gray-900">Tableau de Bord Analytique</h2>
            <div className="flex gap-4">
              <select
                value={anneeScolaireId ?? ""}
                onChange={(e) => {
                  const id = e.target.value ? Number(e.target.value) : null
                  setAnneeScolaireId(id)
                  const an = anneesScolaires.find((a: any) => a.id === id)
                  setSelectedPeriodLabel(an?.libelle ?? "")
                }}
                className="input-field w-auto"
                disabled={anneesLoading || anneesScolaires.length === 0}
              >
                <option value="">Année —</option>
                {anneesScolaires.map((a: any) => (
                  <option key={a.id} value={a.id}>
                    {a.libelle ?? a.code ?? a.id}
                  </option>
                ))}
              </select>
              
              {user.role.code === "ADMIN" || user.role.code === "DAF" || user.role.code === "CABINET" ? (
                <select
                  value={selectedZone}
                  onChange={(e) => setSelectedZone(e.target.value)}
                  className="input-field w-auto"
                >
                  <option value="all">Toutes les zones</option>
                  {dashboardData.structuresParZone.map(zone => (
                    <option key={zone.zone} value={zone.zone}>{zone.zone}</option>
                  ))}
                </select>
              ) : null}
              
              <button className="btn-primary flex items-center gap-2">
                <ArrowPathIcon className="h-4 w-4" />
                Actualiser
              </button>
            </div>
          </div>
        </div>

        {/* Statistiques globales */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="stat-card">
            <div className="flex items-center justify-between">
              <div>
                <p className="stat-label">Total Structures</p>
                <p className="stat-value text-blue-600">
                  {dashboardData.totalStructures.drena + dashboardData.totalStructures.iepp + dashboardData.totalStructures.epp}
                </p>
                <p className="text-sm text-gray-500">
                  {dashboardData.totalStructures.drena} DRENA • {dashboardData.totalStructures.iepp} IEPP • {dashboardData.totalStructures.epp} EPP
                </p>
              </div>
              <div className="p-3 rounded-lg bg-blue-50 text-blue-600">
                <BuildingOfficeIcon className="h-6 w-6" />
              </div>
            </div>
          </div>

          <div className="stat-card">
            <div className="flex items-center justify-between">
              <div>
                <p className="stat-label">Total Élèves</p>
                <p className="stat-value text-green-600">
                  {dashboardData.totalEleves.toLocaleString()}
                </p>
                <p className="text-sm text-gray-500">
                  Couverture: {dashboardData.couvertureGlobale}%
                </p>
              </div>
              <div className="p-3 rounded-lg bg-green-50 text-green-600">
                <UsersIcon className="h-6 w-6" />
              </div>
            </div>
          </div>

          <div className="stat-card">
            <div className="flex items-center justify-between">
              <div>
                <p className="stat-label">Manuels Distribués</p>
                <p className="stat-value text-orange-600">
                  {dashboardData.totalManuelsDistribues.toLocaleString()}
                </p>
                <p className="text-sm text-gray-500">
                  Sur {dashboardData.totalManuelsRequis.toLocaleString()} requis
                </p>
              </div>
              <div className="p-3 rounded-lg bg-orange-50 text-orange-600">
                <BookOpenIcon className="h-6 w-6" />
              </div>
            </div>
          </div>

          <div className="stat-card">
            <div className="flex items-center justify-between">
              <div>
                <p className="stat-label">Distributions</p>
                <p className="stat-value text-purple-600">
                  {dashboardData.distribution.terminees}
                </p>
                <p className="text-sm text-gray-500">
                  {dashboardData.distribution.enCours} en cours • {dashboardData.distribution.retards} retards
                </p>
              </div>
              <div className="p-3 rounded-lg bg-purple-50 text-purple-600">
                <TruckIcon className="h-6 w-6" />
              </div>
            </div>
          </div>
        </div>

        {/* Graphiques dynamiques */}
        <div className={`grid gap-6 ${(user.role.code === "ADMIN" || user.role.code === "DAF" || user.role.code === "CABINET") ? "grid-cols-1 lg:grid-cols-2" : "grid-cols-1"}`}>
          {/* Graphique 1: Structures par zone - National */}
          {(user.role.code === "ADMIN" || user.role.code === "DAF" || user.role.code === "CABINET") && (
            <div className="card">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Structures par Zone</h3>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={chartDataIEPP}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="zone" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="IEPP" fill="#ff6600" />
                  <Bar dataKey="EPP" fill="#00a651" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          )}

          {/* Graphique 2: Couverture globale */}
          <div className="card">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Couverture Globale des Manuels</h3>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={pieDataCouverture}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) => `${name} ${percent ? (percent * 100).toFixed(0) : 0}%`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {pieDataCouverture.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Manuels par titre et niveau */}
        <div className="card">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Manuels par Titre et Niveau</h3>
          <ResponsiveContainer width="100%" height={400}>
            <BarChart data={chartDataManuels}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="titre" angle={-45} textAnchor="end" height={100} />
              <YAxis />
              <Tooltip />
              <Legend />
              <Bar dataKey="Distribués" fill="#00a651" />
              <Bar dataKey="En Stock" fill="#ff6600" />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Taux de couverture par niveau */}
        <div className="card">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Taux de Couverture par Niveau</h3>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={chartDataManuels}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="titre" angle={-45} textAnchor="end" height={100} />
              <YAxis />
              <Tooltip />
              <Legend />
              <Line type="monotone" dataKey="Taux Couverture" stroke="#3b82f6" strokeWidth={3} />
            </LineChart>
          </ResponsiveContainer>
        </div>

        {/* Récupérations de manuels - Affiché pour tous les profils avec données filtrées */}
        <div className="card">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">
            Récupérations de manuels par état
            {user.role.code === "DIRECTEUR" && " - Mon École"}
            {user.role.code === "IEPP" && " - Ma Circonscription"}
            {user.role.code === "DRENA" && " - Ma Région"}
          </h3>
          {dashboardData.retoursManuels.length > 0 ? (
            <ResponsiveContainer width="100%" height={400}>
              <BarChart data={chartDataRetours}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="titre" angle={-45} textAnchor="end" height={100} />
                <YAxis />
                <Tooltip />
                <Legend />
                <Bar dataKey="Bon État" fill="#00a651" stackId="a" />
                <Bar dataKey="Moyennement Endommagé" fill="#f59e0b" stackId="a" />
                <Bar dataKey="Hors d'Usage" fill="#ef4444" stackId="a" />
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <div className="text-center py-8 text-gray-500">
              <BookOpenIcon className="h-12 w-12 mx-auto mb-4 text-gray-300" />
              <p>Aucune récupération de manuels enregistrée pour le moment.</p>
            </div>
          )}
        </div>

        {/* Récupérations détaillées par titre et niveau */}
        <div className="card">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">
            Récupérations détaillées par titre et niveau
            {user.role.code === "DIRECTEUR" && " - Mon École"}
            {user.role.code === "IEPP" && " - Ma Circonscription"}
            {user.role.code === "DRENA" && " - Ma Région"}
          </h3>
          {dashboardData.retoursDetaille && dashboardData.retoursDetaille.length > 0 ? (
            <div className="overflow-x-auto">
              <table className="min-w-full table">
                <thead>
                  <tr>
                    <th>Titre</th>
                    <th>Niveau</th>
                    <th>Structure</th>
                    <th>Bon État</th>
                    <th>Moyen État</th>
                    <th>Mauvais État</th>
                    <th>Perdus</th>
                    <th>Total récupéré</th>
                  </tr>
                </thead>
                <tbody>
                  {dashboardData.retoursDetaille.map((retour, index) => (
                    <tr key={index}>
                      <td className="font-medium">{retour.titre}</td>
                      <td>{retour.niveau}</td>
                      <td>{retour.structure}</td>
                      <td className="text-green-600 font-medium">{retour.quantite_bon_etat}</td>
                      <td className="text-yellow-600 font-medium">{retour.quantite_moyen_etat}</td>
                      <td className="text-red-600 font-medium">{retour.quantite_mauvais_etat}</td>
                      <td className="text-gray-600 font-medium">{retour.quantite_perdue}</td>
                      <td className="font-bold text-blue-600">{retour.total_retourne}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="text-center py-8 text-gray-500">
              <BookOpenIcon className="h-12 w-12 mx-auto mb-4 text-gray-300" />
              <p>Aucune récupération détaillée enregistrée pour le moment.</p>
            </div>
          )}
        </div>

        {/* Élèves par classe (pour les directeurs) */}
        {user.role.code === "DIRECTEUR" && (
          <div className="card">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Effectifs par Classe</h3>
            <div className="overflow-x-auto">
              <table className="min-w-full table">
                <thead>
                  <tr>
                    <th>Classe</th>
                    <th>Effectif</th>
                    <th>Manuels Reçus</th>
                    <th>Couverture</th>
                    <th>Statut</th>
                  </tr>
                </thead>
                <tbody>
                  {dashboardData.elevesParClasse.map((classe, index) => (
                    <tr key={index}>
                      <td>{classe.classe}</td>
                      <td>{classe.effectif}</td>
                      <td>{classe.manuelsRecus}</td>
                      <td>{Math.round((classe.manuelsRecus / classe.effectif) * 100)}%</td>
                      <td>
                        {classe.manuelsRecus >= classe.effectif ? (
                          <span className="badge-success">Complet</span>
                        ) : (
                          <span className="badge-warning">Incomplet</span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* État des Distributions */}
        <div className="card">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">État des Distributions</h3>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="flex items-center p-4 bg-blue-50 rounded-lg">
              <ClockIcon className="h-8 w-8 text-blue-600 mr-3" />
              <div>
                <p className="text-sm font-medium text-blue-900">Planifiées</p>
                <p className="text-2xl font-bold text-blue-600">{dashboardData.distribution.planifiees}</p>
              </div>
            </div>

            <div className="flex items-center p-4 bg-yellow-50 rounded-lg">
              <TruckIcon className="h-8 w-8 text-yellow-600 mr-3" />
              <div>
                <p className="text-sm font-medium text-yellow-900">En Cours</p>
                <p className="text-2xl font-bold text-yellow-600">{dashboardData.distribution.enCours}</p>
              </div>
            </div>

            <div className="flex items-center p-4 bg-green-50 rounded-lg">
              <CheckCircleIcon className="h-8 w-8 text-green-600 mr-3" />
              <div>
                <p className="text-sm font-medium text-green-900">Terminées</p>
                <p className="text-2xl font-bold text-green-600">{dashboardData.distribution.terminees}</p>
              </div>
            </div>

            <div className="flex items-center p-4 bg-red-50 rounded-lg">
              <ExclamationTriangleIcon className="h-8 w-8 text-red-600 mr-3" />
              <div>
                <p className="text-sm font-medium text-red-900">Retards</p>
                <p className="text-2xl font-bold text-red-600">{dashboardData.distribution.retards}</p>
              </div>
            </div>
          </div>
        </div>

        {/* Actions rapides selon le rôle */}
        <div className="card">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Actions Rapides</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {user.role.code === "DAF" && (
              <>
                <button className="action-card">
                  <DocumentTextIcon className="h-6 w-6 text-blue-600 mb-2" />
                  <span className="font-medium">Générer Rapport National</span>
                </button>
                <button className="action-card">
                  <ChartBarIcon className="h-6 w-6 text-green-600 mb-2" />
                  <span className="font-medium">Analyser Couverture</span>
                </button>
                <button className="action-card">
                  <UserGroupIcon className="h-6 w-6 text-purple-600 mb-2" />
                  <span className="font-medium">Formation Acteurs</span>
                </button>
              </>
            )}

            {user.role.code === "DRENA" && (
              <>
                <button className="action-card">
                  <CubeIcon className="h-6 w-6 text-orange-600 mb-2" />
                  <span className="font-medium">Contrôler Stocks IEPP</span>
                </button>
                <button className="action-card">
                  <DocumentTextIcon className="h-6 w-6 text-blue-600 mb-2" />
                  <span className="font-medium">Rapport Régional</span>
                </button>
                <button className="action-card">
                  <ExclamationTriangleIcon className="h-6 w-6 text-red-600 mb-2" />
                  <span className="font-medium">Traiter Plaintes</span>
                </button>
              </>
            )}

            {user.role.code === "IEPP" && (
              <>
                <button className="action-card">
                  <TruckIcon className="h-6 w-6 text-green-600 mb-2" />
                  <span className="font-medium">Planifier Distribution</span>
                </button>
                <button className="action-card">
                  <CubeIcon className="h-6 w-6 text-orange-600 mb-2" />
                  <span className="font-medium">Gérer Stock</span>
                </button>
                <button className="action-card">
                  <ChartBarIcon className="h-6 w-6 text-purple-600 mb-2" />
                  <span className="font-medium">Contrôler EPP</span>
                </button>
              </>
            )}

            {user.role.code === "DIRECTEUR" && (
              <>
                <button className="action-card">
                  <AcademicCapIcon className="h-6 w-6 text-blue-600 mb-2" />
                  <span className="font-medium">Distribution Classes</span>
                </button>
                <button className="action-card">
                  <DocumentTextIcon className="h-6 w-6 text-green-600 mb-2" />
                  <span className="font-medium">Fiches Émargement</span>
                </button>
                <button className="action-card">
                  <UserGroupIcon className="h-6 w-6 text-purple-600 mb-2" />
                  <span className="font-medium">Convoquer Parents</span>
                </button>
              </>
            )}
          </div>
        </div>

                 {/* Workflow de Distribution (11 étapes détaillées) */}
         <div className="card">
           <div className="flex items-center justify-between mb-4">
             <h3 className="text-lg font-semibold text-gray-900">Processus de Distribution (11 Étapes)</h3>
             <div className="flex items-center gap-4 text-sm">
               <div className="flex items-center gap-2">
                 <div className="w-3 h-3 rounded-full bg-green-100 border border-green-300"></div>
                 <span className="text-gray-600">Terminé</span>
               </div>
               <div className="flex items-center gap-2">
                 <div className="w-3 h-3 rounded-full bg-orange-100 border border-orange-300"></div>
                 <span className="text-gray-600">En cours</span>
               </div>
               <div className="flex items-center gap-2">
                 <div className="w-3 h-3 rounded-full bg-gray-100 border border-gray-300"></div>
                 <span className="text-gray-600">En attente</span>
               </div>
             </div>
           </div>
           <div className="space-y-3">
            {dashboardData.workflowDistribution.map((step) => (
              <div key={step.etape} className="flex items-center p-4 rounded-lg border hover:bg-gray-50 transition-colors">
                <div
                  className={`w-10 h-10 rounded-full flex items-center justify-center text-sm font-bold mr-4 ${
                    step.statut === "complete"
                      ? "bg-green-100 text-green-600"
                      : step.statut === "current"
                        ? "bg-orange-100 text-orange-600"
                        : "bg-gray-100 text-gray-400"
                  }`}
                >
                  {step.etape}
                </div>
                <div className="flex-1">
                  <p className="font-medium text-gray-900">{step.titre}</p>
                  <p className="text-sm text-gray-500">{step.description}</p>
                  <p className="text-xs text-gray-400 mt-1">
                    <span className="font-medium">Acteur:</span> {step.acteur}
                    {step.dateDebut && (
                      <span className="ml-4">
                        <span className="font-medium">Début:</span> {new Date(step.dateDebut).toLocaleDateString("fr-FR")}
                      </span>
                    )}
                    {step.dateFin && (
                      <span className="ml-4">
                        <span className="font-medium">Fin:</span> {new Date(step.dateFin).toLocaleDateString("fr-FR")}
                      </span>
                    )}
                  </p>
                </div>
                <div
                  className={`px-3 py-1 rounded-full text-xs font-medium ${
                    step.statut === "complete"
                      ? "bg-green-100 text-green-800"
                      : step.statut === "current"
                        ? "bg-orange-100 text-orange-800"
                        : "bg-gray-100 text-gray-600"
                  }`}
                >
                  {step.statut === "complete" ? "Terminé" : step.statut === "current" ? "En cours" : "En attente"}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Alertes et Notifications */}
        <div className="card">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Alertes et Notifications</h3>
          <div className="p-4 bg-gray-50 border border-gray-200 rounded-lg text-sm text-gray-600">
            Ces alertes seront affichées lorsque l&apos;API “notifications / bordereaux / distribution” sera disponible.
          </div>
        </div>

        {/* Vue consultation DRENA : activités IEPP -> EPP */}
        {user.role.code === "DRENA" && (
          <div className="card">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Activités par IEPP et EPP</h3>
            {!drenaActivites ? (
              <div className="p-4 bg-gray-50 border border-gray-200 rounded-lg text-sm text-gray-600">
                Aucune donnée d&apos;activité disponible pour cette année scolaire.
              </div>
            ) : (
              <div className="space-y-4">
                {Array.isArray(drenaActivites.iepps) && drenaActivites.iepps.length > 0 ? (
                  drenaActivites.iepps.map((iepp: any) => (
                    <div key={iepp.ieppId} className="border border-gray-200 rounded-lg overflow-hidden">
                      <div className="bg-gray-50 px-4 py-3 flex items-center justify-between">
                        <div className="font-medium text-gray-900">
                          {iepp.ieppCode} — {iepp.ieppLibelle}
                        </div>
                        <div className="text-sm text-gray-600">
                          {Array.isArray(iepp.epps) ? iepp.epps.length : 0} EPP
                        </div>
                      </div>
                      <div className="overflow-x-auto">
                        <table className="min-w-full divide-y divide-gray-200">
                          <thead className="bg-white">
                            <tr>
                              <th className="px-4 py-2 text-left text-xs font-medium text-gray-600">EPP</th>
                              <th className="px-4 py-2 text-right text-xs font-medium text-gray-600">Élèves</th>
                              <th className="px-4 py-2 text-right text-xs font-medium text-gray-600">Requis</th>
                              <th className="px-4 py-2 text-right text-xs font-medium text-gray-600">Reçus</th>
                              <th className="px-4 py-2 text-right text-xs font-medium text-gray-600">Distribués</th>
                              <th className="px-4 py-2 text-right text-xs font-medium text-gray-600">Couverture</th>
                              <th className="px-4 py-2 text-right text-xs font-medium text-gray-600">Stock dispo.</th>
                              <th className="px-4 py-2 text-right text-xs font-medium text-gray-600">Ruptures</th>
                            </tr>
                          </thead>
                          <tbody className="bg-white divide-y divide-gray-200">
                            {(iepp.epps || []).map((epp: any) => (
                              <tr key={epp.eppId}>
                                <td className="px-4 py-2 text-sm text-gray-900">
                                  {epp.eppCode} — {epp.eppLibelle}
                                </td>
                                <td className="px-4 py-2 text-sm text-right">{epp.totalEleves ?? 0}</td>
                                <td className="px-4 py-2 text-sm text-right">{epp.totalManuelsRequis ?? 0}</td>
                                <td className="px-4 py-2 text-sm text-right">{epp.totalManuelsCommandes ?? 0}</td>
                                <td className="px-4 py-2 text-sm text-right">{epp.totalManuelsDistribues ?? 0}</td>
                                <td className="px-4 py-2 text-sm text-right font-medium">
                                  {epp.couvertureGlobale ?? 0}%
                                </td>
                                <td className="px-4 py-2 text-sm text-right">{epp.stockDisponibleTotal ?? 0}</td>
                                <td className="px-4 py-2 text-sm text-right text-red-700 font-medium">
                                  {epp.stocksEnRuptureCount ?? 0}
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="p-4 bg-gray-50 border border-gray-200 rounded-lg text-sm text-gray-600">
                    Aucun IEPP trouvé sous cette DRENA.
                  </div>
                )}
              </div>
            )}
          </div>
        )}
      </div>
    </MainLayout>
  )
}
