"use client"

import { useCallback, useEffect, useMemo, useState } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import MainLayout from "../../components/layout/main-layout"
import { useAuth } from "../providers"
import { useAnneesScolaires } from "@/hooks/use-annees-scolaires"
import { useNiveauxScolaires } from "@/hooks/use-niveaux-scolaires"
import {
  commandeFournisseurService,
  type CommandeFournisseurData,
  type CommandeFournisseurRow,
} from "@/lib/services/commande-fournisseur.service"
import { manuelService, type ManuelRow } from "@/lib/services/manuel.service"
import { matiereService } from "@/lib/services/matiere.service"
import type { Matiere } from "@/lib/types/entities"
import toast from "react-hot-toast"
import {
  PlusIcon,
  ShoppingCartIcon,
  CheckCircleIcon,
  ClockIcon,
  ExclamationTriangleIcon,
  EyeIcon,
  PencilIcon,
  XMarkIcon,
  TrashIcon,
  ArrowPathIcon,
  Square2StackIcon,
} from "@heroicons/react/24/outline"

const ST_BROUILLON = "BROUILLON"
const ST_VALIDEE = "VALIDEE"

function totalQuantiteCatalogue(c: CommandeFournisseurRow): number {
  return (c.lignes || []).reduce((s, l) => s + (Number(l.quantiteCommandee) || 0), 0)
}

/**
 * Indicateur de « couverture » affiché (placeholder UI).
 * Cible métier : comparer les quantités commandées (validées) aux besoins approuvés par la DAF
 * après consolidation des expressions de besoins — formule du type :
 *   min(100, round(100 × Σ quantités commande validée / Σ besoin approuvé DAF par matière·niveau))
 * Non branché tant qu’un agrégat API (besoins consolidés vs commandes) n’est pas exposé.
 */
function couverturePercent(c: CommandeFournisseurRow): number {
  return c.statut === ST_VALIDEE ? 100 : 85
}

function formatDateIso(d: string | Date | undefined): string {
  if (!d) return "—"
  const x = typeof d === "string" ? new Date(d) : d
  if (Number.isNaN(x.getTime())) return "—"
  return x.toISOString().slice(0, 10)
}

function CouvertureBar({ pct }: { pct: number }) {
  const p = Math.min(100, Math.max(0, pct))
  return (
    <div className="flex items-center gap-2 min-w-[140px]">
      <div className="flex-1 h-2 bg-gray-200 rounded-full overflow-hidden">
        <div className="h-full bg-emerald-500 rounded-full transition-all" style={{ width: `${p}%` }} />
      </div>
      <span className="text-sm text-gray-700 tabular-nums w-9 shrink-0">{p}%</span>
    </div>
  )
}

/**
 * PK `structure_administrative` côté session : préférer `structureAdministrativeId` (aligné localStorage / API),
 * car `structure.id` peut être un id métier (ex. DRENA) pour l’affichage — voir `convertUserToLegacyUser`.
 */
function getStructureAdministrativePk(user: {
  structureAdministrativeId?: number
  structure?: { id?: number }
} | null): number | undefined {
  if (!user) return undefined
  if (typeof user.structureAdministrativeId === "number" && user.structureAdministrativeId > 0) {
    return user.structureAdministrativeId
  }
  const sid = user.structure?.id
  if (typeof sid === "number" && sid > 0) return sid
  return undefined
}

/** Périmètre DAF pour l’API (liste / CRUD) : profil DAF ou ADMIN rattaché à une structure de type DAF. */
function getScopeStructureDafId(user: {
  role?: { code?: string }
  structure?: { id?: number; type?: string }
  structureAdministrativeId?: number
} | null): number | undefined {
  const sid = getStructureAdministrativePk(user)
  if (sid == null) return undefined
  const role = (user?.role?.code || "").toUpperCase()
  const typ = (user?.structure?.type || "").toUpperCase()
  if (role === "DAF") return sid
  if (role === "ADMIN" && typ === "DAF") return sid
  return undefined
}

export default function CommandesPage() {
  const pathname = usePathname()
  const { user } = useAuth()
  const { anneesScolaires, loading: loadingAnnees } = useAnneesScolaires()
  const { niveauxScolaires: niveaux } = useNiveauxScolaires()

  const [commandes, setCommandes] = useState<CommandeFournisseurRow[]>([])
  /** Libellés d’ouvrage (API `manuel`) pour enrichir l’affichage catalogue quand `manuelId` est présent. */
  const [ouvragesCatalogueLibelles, setOuvragesCatalogueLibelles] = useState<ManuelRow[]>([])
  const [matieres, setMatieres] = useState<Matiere[]>([])
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)

  const [showModal, setShowModal] = useState(false)
  const [modalMode, setModalMode] = useState<"new" | "edit" | "view">("view")
  const [selected, setSelected] = useState<CommandeFournisseurRow | null>(null)

  const [form, setForm] = useState<CommandeFournisseurData>({
    reference: "",
    fournisseur: "",
    dateLivraisonPrevue: "",
    anneeScolaireId: undefined,
    lignes: [{ niveauId: 0, matiereId: 0, quantiteCommandee: 0, prixUnitaire: 0, montant: 0 }],
  })

  const anneeCourante = useMemo(
    () => anneesScolaires.find((a) => a.estCourante) ?? anneesScolaires[0],
    [anneesScolaires]
  )

  /** Si la liste des années arrive après l’ouverture du modal, appliquer l’année courante par défaut. */
  useEffect(() => {
    if (!showModal || modalMode !== "new") return
    const id = anneeCourante?.id
    if (id == null) return
    setForm((f) => (f.anneeScolaireId != null ? f : { ...f, anneeScolaireId: id }))
  }, [showModal, modalMode, anneeCourante?.id])

  const refresh = useCallback(async () => {
    if (!user) return
    setLoading(true)
    try {
      const dafId = getScopeStructureDafId(user)
      const res = await commandeFournisseurService.list(
        typeof dafId === "number" ? { structureDafId: dafId } : {}
      )
      if (res.hasError) {
        toast.error(res.status?.message || "Erreur chargement commandes")
        setCommandes([])
        return
      }
      setCommandes((res.items as CommandeFournisseurRow[]) || [])
    } catch {
      toast.error("Erreur réseau (commandes)")
      setCommandes([])
    } finally {
      setLoading(false)
    }
  }, [user])

  const loadOuvragesCatalogueLibelles = useCallback(async () => {
    try {
      const res = await manuelService.listActifs()
      if (res.hasError) {
        toast.error(res.status?.message || "Impossible de charger le référentiel catalogue (ouvrages)")
        setOuvragesCatalogueLibelles([])
        return
      }
      setOuvragesCatalogueLibelles((res.items as unknown as ManuelRow[]) || [])
    } catch {
      toast.error("Erreur réseau (catalogue)")
      setOuvragesCatalogueLibelles([])
    }
  }, [])

  const loadMatieres = useCallback(async () => {
    try {
      const res = await matiereService.getActivesMatieres()
      if (res.hasError) {
        toast.error(res.status?.message || "Impossible de charger les matières")
        setMatieres([])
        return
      }
      setMatieres(((res.items ?? []) as unknown as Matiere[]) || [])
    } catch {
      toast.error("Erreur réseau (matières)")
      setMatieres([])
    }
  }, [])

  useEffect(() => {
    if (!user) return
    if (!["DAF", "ADMIN"].includes((user.role?.code || "").toUpperCase())) return
    void refresh()
    void loadOuvragesCatalogueLibelles()
    void loadMatieres()
  }, [user, refresh, loadOuvragesCatalogueLibelles, loadMatieres])

  const synthese = useMemo(() => {
    const volumeTotal = commandes.reduce((s, c) => s + totalQuantiteCatalogue(c), 0)
    const nEnCours = commandes.filter((c) => c.statut === ST_BROUILLON).length
    const nTerminees = commandes.filter((c) => c.statut === ST_VALIDEE).length
    return { volumeTotal, nEnCours, nTerminees }
  }, [commandes])

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p className="text-gray-600">Chargement…</p>
      </div>
    )
  }

  if (!["DAF", "ADMIN"].includes(user.role.code.toUpperCase())) {
    return (
      <MainLayout>
        <div className="text-center py-12">
          <ExclamationTriangleIcon className="h-12 w-12 text-yellow-500 mx-auto mb-4" />
          <h2 className="text-xl font-semibold text-gray-900 mb-2">Accès restreint</h2>
          <p className="text-gray-600">Réservé aux profils DAF et ADMIN.</p>
        </div>
      </MainLayout>
    )
  }

  const openNew = () => {
    setModalMode("new")
    setSelected(null)
    setForm({
      reference: "",
      fournisseur: "",
      dateCommande: new Date().toISOString().slice(0, 10),
      dateLivraisonPrevue: "",
      anneeScolaireId: anneeCourante?.id,
      lignes: [{ niveauId: 0, matiereId: 0, quantiteCommandee: 0, prixUnitaire: 0, montant: 0 }],
    })
    setShowModal(true)
  }

  const openEdit = (c: CommandeFournisseurRow) => {
    if (c.statut !== ST_BROUILLON) {
      toast.error("Seules les commandes en brouillon sont modifiables.")
      return
    }
    setModalMode("edit")
    setSelected(c)
    setForm({
      id: c.id,
      reference: c.reference,
      fournisseur: c.fournisseur,
      dateCommande: c.dateCommande,
      dateLivraisonPrevue: c.dateLivraisonPrevue,
      anneeScolaireId: c.anneeScolaireId,
      lignes: (c.lignes || []).map((l) => {
        const ouvrage = l.manuelId ? ouvragesCatalogueLibelles.find((m) => m.id === l.manuelId) : undefined
        const matiereId = l.matiereId ?? ouvrage?.matiereId ?? ouvrage?.matiere?.id ?? 0
        return {
          id: l.id,
          matiereId,
          niveauId: l.niveauId ?? 0,
          manuelId: l.manuelId,
          quantiteCommandee: l.quantiteCommandee!,
          prixUnitaire: l.prixUnitaire ?? 0,
          montant: l.montant ?? 0,
        }
      }),
    })
    setShowModal(true)
  }

  const openView = (c: CommandeFournisseurRow) => {
    setModalMode("view")
    setSelected(c)
    setForm({
      id: c.id,
      reference: c.reference,
      fournisseur: c.fournisseur,
      dateCommande: c.dateCommande,
      dateLivraisonPrevue: c.dateLivraisonPrevue,
      anneeScolaireId: c.anneeScolaireId,
      statut: c.statut,
      lignes: c.lignes,
    })
    setShowModal(true)
  }

  const recalcLignes = (lignes: NonNullable<CommandeFournisseurData["lignes"]>) =>
    lignes.map((l) => {
      const q = Number(l.quantiteCommandee) || 0
      return { ...l, prixUnitaire: 0, montant: 0, quantiteCommandee: q }
    })

  const handleSave = async () => {
    const anneeId = form.anneeScolaireId ?? anneeCourante?.id
    if (!anneeId) {
      toast.error("Choisissez une année scolaire.")
      return
    }
    const lignesBrutes = recalcLignes(form.lignes || []).filter(
      (l) => (l.matiereId ?? 0) > 0 && (l.niveauId ?? 0) > 0 && l.quantiteCommandee > 0
    )
    if (lignesBrutes.length === 0) {
      toast.error("Ajoutez au moins une ligne avec une matière, un niveau et une quantité.")
      return
    }
    setSaving(true)
    try {
      const lignesApi = lignesBrutes.map(({ id, matiereId, niveauId, quantiteCommandee }) => ({
        id,
        matiereId,
        niveauId,
        quantiteCommandee,
        prixUnitaire: 0,
        montant: 0,
      }))
      const basePayload: CommandeFournisseurData = {
        ...form,
        anneeScolaireId: anneeId,
        lignes: lignesApi,
      }
      /* Création : la référence est toujours générée côté backend — ne pas envoyer de valeur client. */
      const payload: CommandeFournisseurData =
        modalMode === "new"
          ? { ...basePayload, reference: undefined }
          : basePayload
      const scopeDaf = getScopeStructureDafId(user)
      if (scopeDaf != null) payload.structureDafId = scopeDaf
      const res =
        modalMode === "new"
          ? await commandeFournisseurService.create(payload)
          : await commandeFournisseurService.update(payload)
      if (res.hasError) {
        toast.error(res.status?.message || "Enregistrement impossible")
        return
      }
      toast.success(modalMode === "new" ? "Commande créée" : "Commande mise à jour")
      setShowModal(false)
      await refresh()
    } catch (e: unknown) {
      toast.error(e instanceof Error ? e.message : "Erreur")
    } finally {
      setSaving(false)
    }
  }

  const handleValider = async (c: CommandeFournisseurRow) => {
    if (!c.id || c.statut !== ST_BROUILLON) return
    if (!window.confirm("Valider cette commande ? Le stock DAF sera crédité (comme une entrée de réception).")) return
    setSaving(true)
    try {
      const res = await commandeFournisseurService.valider(c.id, getScopeStructureDafId(user))
      if (res.hasError) {
        toast.error(res.status?.message || "Validation impossible")
        return
      }
      toast.success(
        "Commande validée — le stock DAF est crédité. Vérifiez l’onglet Stocks (menu latéral) pour les quantités disponibles avant approbation des besoins."
      )
      await refresh()
    } catch (e: unknown) {
      toast.error(e instanceof Error ? e.message : "Erreur")
    } finally {
      setSaving(false)
    }
  }

  const handleDelete = async (c: CommandeFournisseurRow) => {
    if (!c.id) return
    const msg =
      c.statut === ST_VALIDEE
        ? "Supprimer cette commande validée ? Possible seulement si le stock DAF correspondant n’a pas encore été distribué."
        : "Supprimer cette commande brouillon ?"
    if (!window.confirm(msg)) return
    setSaving(true)
    try {
      const res = await commandeFournisseurService.remove(c.id, getScopeStructureDafId(user))
      if (res.hasError) {
        toast.error(res.status?.message || "Suppression impossible")
        return
      }
      toast.success("Commande supprimée")
      await refresh()
    } catch (e: unknown) {
      toast.error(e instanceof Error ? e.message : "Erreur")
    } finally {
      setSaving(false)
    }
  }

  const addLigne = () => {
    setForm((f) => ({
      ...f,
      lignes: [...(f.lignes || []), { niveauId: 0, matiereId: 0, quantiteCommandee: 0, prixUnitaire: 0, montant: 0 }],
    }))
  }

  const updateLigne = (idx: number, field: string, value: number) => {
    setForm((f) => {
      const lignes = [...(f.lignes || [])]
      const cur = { ...lignes[idx], [field]: value } as (typeof lignes)[0]
      lignes[idx] = cur
      return { ...f, lignes: recalcLignes(lignes) }
    })
  }

  const removeLigne = (idx: number) => {
    setForm((f) => {
      const lignes = [...(f.lignes || [])].filter((_, i) => i !== idx)
      return {
        ...f,
        lignes: lignes.length ? lignes : [{ niveauId: 0, matiereId: 0, quantiteCommandee: 0, prixUnitaire: 0, montant: 0 }],
      }
    })
  }

  /** Plusieurs lignes peuvent réutiliser la même combinaison catalogue (même matière / niveau). */
  const duplicateLigne = (idx: number) => {
    setForm((f) => {
      const lignes = [...(f.lignes || [])]
      const src = lignes[idx]
      if (!src) return f
      const copy = {
        niveauId: src.niveauId ?? 0,
        matiereId: (src as { matiereId?: number }).matiereId ?? 0,
        quantiteCommandee: src.quantiteCommandee,
        prixUnitaire: 0,
        montant: 0,
      }
      lignes.splice(idx + 1, 0, copy)
      return { ...f, lignes: recalcLignes(lignes) }
    })
  }

  return (
    <MainLayout>
      <div className="space-y-6">
        <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Gestion des Commandes</h1>
            <p className="text-gray-600 text-sm mt-1">Commande et suivi du catalogue — DAF</p>
            <nav className="mt-4 flex flex-wrap gap-1 border-b border-gray-200">
              <span
                className={`inline-block px-3 py-2 text-sm font-medium border-b-2 -mb-px ${
                  pathname === "/commandes" ? "border-orange-500 text-orange-600" : "border-transparent text-gray-500"
                }`}
              >
                Commandes
              </span>
              <Link
                href="/besoins"
                className={`inline-block px-3 py-2 text-sm font-medium border-b-2 -mb-px border-transparent text-gray-600 hover:text-gray-900`}
              >
                Synthèse des Besoins
              </Link>
              <Link
                href="/planification/repartition"
                className={`inline-block px-3 py-2 text-sm font-medium border-b-2 -mb-px border-transparent text-gray-600 hover:text-gray-900`}
              >
                Tableau de Répartition
              </Link>
            </nav>
          </div>
          <div className="flex gap-2 shrink-0">
            <button type="button" className="btn-outline inline-flex items-center gap-2" onClick={() => void refresh()} disabled={loading}>
              <ArrowPathIcon className={`h-5 w-5 ${loading ? "animate-spin" : ""}`} />
              Actualiser
            </button>
            <button type="button" className="btn-primary inline-flex items-center gap-2 bg-orange-500 hover:bg-orange-600 border-orange-500" onClick={openNew} disabled={loadingAnnees}>
              <PlusIcon className="h-5 w-5" />
              + Nouvelle Commande
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="stat-card">
            <p className="stat-label">Volume catalogue (quantités)</p>
            <p className="stat-value">{synthese.volumeTotal.toLocaleString("fr-FR")}</p>
          </div>
          <div className="stat-card">
            <p className="stat-label">Commandes en cours</p>
            <p className="stat-value text-blue-700">{synthese.nEnCours}</p>
          </div>
          <div className="stat-card">
            <p className="stat-label">Commandes terminées</p>
            <p className="stat-value text-emerald-700">{synthese.nTerminees}</p>
          </div>
        </div>

        <div className="card border-0 shadow-md ring-1 ring-gray-100 overflow-hidden">
          <div className="px-4 py-3 border-b border-gray-100">
            <h3 className="font-semibold text-gray-900">Commandes en Cours</h3>
          </div>
          <div className="overflow-x-auto">
            <table className="table min-w-[900px]">
              <thead className="bg-gray-50">
                <tr>
                  <th className="text-left uppercase text-xs tracking-wide text-gray-600">Référence</th>
                  <th className="text-left uppercase text-xs tracking-wide text-gray-600">Fournisseur</th>
                  <th className="text-left uppercase text-xs tracking-wide text-gray-600">Catalogue</th>
                  <th className="text-left uppercase text-xs tracking-wide text-gray-600">Couverture</th>
                  <th className="text-left uppercase text-xs tracking-wide text-gray-600">Statut</th>
                  <th className="text-right uppercase text-xs tracking-wide text-gray-600">Actions</th>
                </tr>
              </thead>
              <tbody>
                {loading ? (
                  <tr>
                    <td colSpan={6} className="text-center py-10 text-gray-500">
                      Chargement…
                    </td>
                  </tr>
                ) : commandes.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="text-center py-10 text-gray-500">
                      Aucune commande.
                    </td>
                  </tr>
                ) : (
                  commandes.map((c) => {
                    const qty = totalQuantiteCatalogue(c)
                    const cov = couverturePercent(c)
                    return (
                      <tr key={c.id}>
                        <td className="align-top">
                          <div className="font-mono text-sm font-medium text-gray-900">{c.reference || "—"}</div>
                          <div className="text-xs text-gray-500 mt-0.5">{formatDateIso(c.dateCommande)}</div>
                        </td>
                        <td className="text-gray-800">{c.fournisseur || "—"}</td>
                        <td className="tabular-nums text-gray-800">{qty.toLocaleString("fr-FR")} unités</td>
                        <td>
                          <CouvertureBar pct={cov} />
                        </td>
                        <td>
                          {c.statut === ST_VALIDEE ? (
                            <span className="inline-flex items-center gap-1 text-xs font-medium px-2.5 py-1 rounded-full bg-emerald-100 text-emerald-800">
                              <CheckCircleIcon className="h-4 w-4" /> Terminée
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1 text-xs font-medium px-2.5 py-1 rounded-full bg-blue-100 text-blue-800">
                              <ClockIcon className="h-4 w-4" /> En cours
                            </span>
                          )}
                        </td>
                        <td className="text-right whitespace-nowrap">
                          <button
                            type="button"
                            className="text-orange-600 hover:text-orange-800 text-sm font-medium mr-3"
                            onClick={() => openView(c)}
                          >
                            Voir
                          </button>
                          {c.statut === ST_BROUILLON && (
                            <>
                              <button
                                type="button"
                                className="text-blue-600 hover:text-blue-800 text-sm font-medium mr-3"
                                onClick={() => openEdit(c)}
                                disabled={saving}
                              >
                                Modifier
                              </button>
                              <button
                                type="button"
                                className="text-emerald-600 hover:text-emerald-800 text-sm font-medium mr-2"
                                onClick={() => void handleValider(c)}
                                disabled={saving}
                              >
                                Valider
                              </button>
                              <button
                                type="button"
                                className="text-gray-400 hover:text-red-600 p-1 align-middle"
                                title="Supprimer"
                                onClick={() => void handleDelete(c)}
                                disabled={saving}
                              >
                                <TrashIcon className="h-4 w-4 inline" />
                              </button>
                            </>
                          )}
                        </td>
                      </tr>
                    )
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40">
          <div className="bg-white rounded-xl shadow-xl max-w-3xl w-full max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between px-4 py-3 border-b">
              <h3 className="text-lg font-semibold">
                {modalMode === "new" && "Nouvelle commande"}
                {modalMode === "edit" && "Modifier la commande"}
                {modalMode === "view" && "Détails de la Commande"}
              </h3>
              <button type="button" className="p-2 rounded-lg hover:bg-gray-100" onClick={() => setShowModal(false)}>
                <XMarkIcon className="h-6 w-6" />
              </button>
            </div>
            <div className="p-4 space-y-4">
              {modalMode === "view" ? (
                <>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-8 gap-y-4 text-sm">
                    <div>
                      <span className="text-gray-500 text-xs block mb-0.5">Référence</span>
                      <span className="font-medium text-gray-900">{form.reference || "—"}</span>
                    </div>
                    <div>
                      <span className="text-gray-500 text-xs block mb-0.5">Editteur</span>
                      <span className="text-gray-900">{form.fournisseur || "—"}</span>
                    </div>
                    <div>
                      <span className="text-gray-500 text-xs block mb-0.5">Date de commande</span>
                      <span className="text-gray-900">{formatDateIso(form.dateCommande)}</span>
                    </div>
                    <div>
                      <span className="text-gray-500 text-xs block mb-0.5">Date de livraison prévue</span>
                      <span className="text-gray-900">
                        {form.dateLivraisonPrevue
                          ? formatDateIso(form.dateLivraisonPrevue)
                          : "—"}
                      </span>
                    </div>
                    <div className="sm:col-span-2">
                      <span className="text-gray-500 text-xs block mb-1">Statut</span>
                      {form.statut === ST_VALIDEE ? (
                        <span className="inline-flex items-center gap-1 text-xs font-medium px-2.5 py-1 rounded-full bg-emerald-100 text-emerald-800">
                          <CheckCircleIcon className="h-4 w-4" /> Terminée
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 text-xs font-medium px-2.5 py-1 rounded-full bg-blue-100 text-blue-800">
                          <ClockIcon className="h-4 w-4" /> En cours
                        </span>
                      )}
                    </div>
                  </div>

                  <div>
                    <h4 className="font-semibold text-gray-900 mb-2">Lignes catalogue</h4>
                    <div className="overflow-x-auto rounded-lg border border-gray-200">
                      <table className="table min-w-full text-sm">
                        <thead className="bg-gray-50">
                          <tr>
                            <th className="text-left uppercase text-xs text-gray-600">Catalogue</th>
                            <th className="text-left uppercase text-xs text-gray-600">Niveau</th>
                            <th className="text-right uppercase text-xs text-gray-600">Quantité</th>
                          </tr>
                        </thead>
                        <tbody>
                          {(form.lignes || []).map((l, i) => {
                            const lv = l as {
                              manuelTitre?: string
                              manuelCode?: string
                              niveauId?: number
                              niveauLibelle?: string
                              quantiteCommandee?: number
                            }
                            const nivCode =
                              niveaux.find((n) => n.id === lv.niveauId)?.code ?? lv.niveauLibelle ?? "—"
                            const matiereId = (l as { matiereId?: number }).matiereId
                            const matiereNom = matiereId != null ? matieres.find((m) => m.id === matiereId)?.libelle : undefined
                            const libelleCatalogue =
                              lv.manuelTitre ||
                              lv.manuelCode ||
                              ouvragesCatalogueLibelles.find((m) => m.id === l.manuelId)?.titre ||
                              matiereNom ||
                              "—"
                            return (
                              <tr key={i}>
                                <td className="text-gray-900">{libelleCatalogue}</td>
                                <td className="text-gray-800">{nivCode}</td>
                                <td className="text-right tabular-nums">
                                  {(lv.quantiteCommandee ?? 0).toLocaleString("fr-FR")}
                                </td>
                              </tr>
                            )
                          })}
                        </tbody>
                      </table>
                    </div>
                  </div>

                  {selected?.statut === ST_VALIDEE && selected.lignes && (
                    <p className="text-sm text-emerald-800 bg-emerald-50 border border-emerald-100 rounded-lg p-3">
                      Cette commande est terminée.
                    </p>
                  )}
                </>
              ) : (
                <>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    <div>
                      <label className="form-label">
                        Référence
                      </label>
                      <input
                        className="input-field"
                        disabled={modalMode === "new"}
                        placeholder={modalMode === "new" ? "—" : undefined}
                        value={modalMode === "new" ? "" : form.reference || ""}
                        onChange={(e) => setForm((f) => ({ ...f, reference: e.target.value }))}
                      />
                    </div>
                    <div>
                      <label className="form-label">Editteur</label>
                      <input
                        className="input-field"
                        value={form.fournisseur || ""}
                        onChange={(e) => setForm((f) => ({ ...f, fournisseur: e.target.value }))}
                      />
                    </div>
                    <div>
                      <label className="form-label">Date de commande</label>
                      <input
                        type="date"
                        className="input-field"
                        value={
                          typeof form.dateCommande === "string"
                            ? form.dateCommande.slice(0, 10)
                            : form.dateCommande
                              ? new Date(form.dateCommande as Date).toISOString().slice(0, 10)
                              : ""
                        }
                        onChange={(e) => setForm((f) => ({ ...f, dateCommande: e.target.value }))}
                      />
                    </div>
                    <div>
                      <label className="form-label">Livraison prévue</label>
                      <input
                        type="date"
                        className="input-field"
                        value={typeof form.dateLivraisonPrevue === "string" ? form.dateLivraisonPrevue.slice(0, 10) : ""}
                        onChange={(e) => setForm((f) => ({ ...f, dateLivraisonPrevue: e.target.value }))}
                      />
                    </div>
                    <div className="md:col-span-2">
                      <label className="form-label">Année scolaire *</label>
                      <select
                        className="input-field"
                        value={form.anneeScolaireId ?? anneeCourante?.id ?? ""}
                        onChange={(e) => setForm((f) => ({ ...f, anneeScolaireId: Number(e.target.value) }))}
                      >
                        <option value="">—</option>
                        {anneesScolaires.map((a) => (
                          <option key={a.id} value={a.id}>
                            {a.code || a.libelle || a.id}
                            {a.estCourante ? " (courante)" : ""}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <div>
                    <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 mb-2">
                      <div>
                        <span className="font-medium text-gray-800">Lignes catalogue (matière & niveau)</span>
                        <p className="text-xs text-gray-500 mt-0.5 max-w-xl">
                          Comme en réception / distribution : matière, niveau et quantité — sans montants.
                        </p>
                      </div>
                      <button type="button" className="text-sm text-orange-600 shrink-0" onClick={addLigne}>
                        + Ligne
                      </button>
                    </div>
                    <div className="space-y-2">
                      {(form.lignes || []).map((l, idx) => {
                        const niveauLigne = l.niveauId ?? 0
                        const matiereLigne = (l as { matiereId?: number }).matiereId ?? 0
                        return (
                          <div key={idx} className="grid grid-cols-12 gap-2 items-end border rounded-lg p-2 bg-gray-50/80">
                            <div className="col-span-12 sm:col-span-3">
                              <label className="text-xs text-gray-500">Niveau</label>
                              <select
                                className="input-field text-sm"
                                value={niveauLigne || ""}
                                onChange={(e) => updateLigne(idx, "niveauId", Number(e.target.value))}
                              >
                                <option value={0}>— Choisir</option>
                                {niveaux.map((n) => (
                                  <option key={n.id} value={n.id}>
                                    {n.code || n.libelle || n.id}
                                  </option>
                                ))}
                              </select>
                            </div>
                            <div className="col-span-12 sm:col-span-4">
                              <label className="text-xs text-gray-500">Matière</label>
                              <select
                                className="input-field text-sm"
                                value={matiereLigne || ""}
                                onChange={(e) => updateLigne(idx, "matiereId", Number(e.target.value))}
                              >
                                <option value={0}>—</option>
                                {matieres.map((m) =>
                                  m.id != null ? (
                                    <option key={m.id} value={m.id}>
                                      {(m.code || "").trim() || `#${m.id}`} — {m.libelle || ""}
                                    </option>
                                  ) : null
                                )}
                              </select>
                            </div>
                            <div className="col-span-12 sm:col-span-3">
                              <label className="text-xs text-gray-500">Quantité</label>
                              <input
                                type="number"
                                min={0}
                                className="input-field text-sm"
                                value={l.quantiteCommandee || 0}
                                onChange={(e) => updateLigne(idx, "quantiteCommandee", Number(e.target.value))}
                              />
                            </div>
                            <div className="col-span-12 sm:col-span-2 flex justify-end gap-1">
                              <button
                                type="button"
                                className="text-gray-600 p-2 rounded hover:bg-gray-100"
                                title="Dupliquer la ligne"
                                onClick={() => duplicateLigne(idx)}
                              >
                                <Square2StackIcon className="h-5 w-5" />
                              </button>
                              <button type="button" className="text-red-600 p-2 rounded hover:bg-red-50" onClick={() => removeLigne(idx)}>
                                <TrashIcon className="h-5 w-5" />
                              </button>
                            </div>
                          </div>
                        )
                      })}
                    </div>
                  </div>
                </>
              )}
            </div>
            <div className="px-4 py-3 border-t flex justify-end gap-2">
              <button type="button" className="btn-outline" onClick={() => setShowModal(false)}>
                {modalMode === "view" ? "Annuler" : "Fermer"}
              </button>
              {modalMode !== "view" && (
                <button type="button" className="btn-primary" onClick={() => void handleSave()} disabled={saving}>
                  {saving ? "Enregistrement…" : "Enregistrer"}
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </MainLayout>
  )
}
