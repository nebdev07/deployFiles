"use client"

import { useState } from "react"
import MainLayout from "../../../components/layout/main-layout"
import { useAuth } from "../../../app/providers"
import ImportModal from "../../../components/modals/ImportModal"
import { 
  exportToPDF, 
  exportToExcel, 
  formatNumber, 
  generateFileName, 
  validateExportData,
  type ExportData 
} from '../../../lib/export-utils'
import {
  DocumentTextIcon,
  CalculatorIcon,
  CheckCircleIcon,
  ClockIcon,
  ExclamationTriangleIcon,
  EyeIcon,
  PrinterIcon,
  ArrowDownTrayIcon,
  MapIcon,
  BuildingOfficeIcon,
  UserGroupIcon,
  XMarkIcon,
  CalendarIcon,
  ChevronDownIcon,
  ArrowUpTrayIcon,
} from "@heroicons/react/24/outline"

// Données mockées du tableau de répartition
const mockTableauRepartition = {
  annee_scolaire: "2024-2025",
  date_generation: "2024-10-25",
  generate_par: "KOUAME Jean-Baptiste",
  statut: "APPROUVE",
  total_manuels_commandes: 1455000,
  total_effectifs: 3200000,
  couverture_globale: 78,
  
  // Répartition par DRENA
  repartition_drena: [
    {
      drena: "DRENA Abidjan",
      effectifs: 850000,
      manuels_requis: 3400000,
      manuels_alloues: 2650000,
      couverture: 78,
      iepp_count: 5,
      statut: "DISTRIBUTION_EFFECTIVE",
      date_consolidation: "2024-10-20",
      repartition_iepp: [
        {
          iepp: "IEPP Cocody",
          effectifs: 120000,
          manuels_requis: 480000,
          manuels_alloues: 375000,
          couverture: 78,
          epp_count: 3,
          statut: "DISTRIBUTION_EFFECTIVE",
          date_consolidation: "2024-10-18",
          repartition_epp: [
            {
              epp: "EPP Cocody Centre",
              effectifs: 450,
              manuels_requis: 1800,
              manuels_alloues: 1400,
              couverture: 78,
              statut: "DISTRIBUTION_EFFECTIVE",
            },
            {
              epp: "EPP Cocody Riviera",
              effectifs: 380,
              manuels_requis: 1520,
              manuels_alloues: 1185,
              couverture: 78,
              statut: "REGULATION_EFFECTUEE",
            },
            {
              epp: "EPP Cocody Angré",
              effectifs: 520,
              manuels_requis: 2080,
              manuels_alloues: 1622,
              couverture: 78,
              statut: "DISTRIBUTION_EFFECTIVE",
            },
          ],
        },
        {
          iepp: "IEPP Yopougon",
          effectifs: 180000,
          manuels_requis: 720000,
          manuels_alloues: 562000,
          couverture: 78,
          epp_count: 4,
          statut: "APPROUVE",
          date_consolidation: "2024-10-22",
          repartition_epp: [
            {
              epp: "EPP Yopougon Maroc",
              effectifs: 680,
              manuels_requis: 2720,
              manuels_alloues: 2120,
              couverture: 78,
              statut: "APPROUVE",
            },
            {
              epp: "EPP Yopougon Niangon",
              effectifs: 590,
              manuels_requis: 2360,
              manuels_alloues: 1840,
              couverture: 78,
              statut: "REGULATION_EFFECTUEE",
            },
            {
              epp: "EPP Yopougon Selmer",
              effectifs: 720,
              manuels_requis: 2880,
              manuels_alloues: 2246,
              couverture: 78,
              statut: "VALIDE",
            },
            {
              epp: "EPP Yopougon Port-Bouët",
              effectifs: 480,
              manuels_requis: 1920,
              manuels_alloues: 1497,
              couverture: 78,
              statut: "VALIDE",
            },
          ],
        },
        {
          iepp: "IEPP Abobo",
          effectifs: 220000,
          manuels_requis: 880000,
          manuels_alloues: 686000,
          couverture: 78,
          epp_count: 6,
          statut: "CONSOLIDE",
          date_consolidation: "2024-10-19",
          repartition_epp: [
            {
              epp: "EPP Abobo Gare",
              effectifs: 750,
              manuels_requis: 3000,
              manuels_alloues: 2340,
              couverture: 78,
              statut: "CONSOLIDE",
            },
            {
              epp: "EPP Abobo Anonkoua",
              effectifs: 620,
              manuels_requis: 2480,
              manuels_alloues: 1934,
              couverture: 78,
              statut: "CONSOLIDE",
            },
            {
              epp: "EPP Abobo Samaké",
              effectifs: 580,
              manuels_requis: 2320,
              manuels_alloues: 1810,
              couverture: 78,
              statut: "CONSOLIDE",
            },
          ],
        },
      ],
    },
    {
      drena: "DRENA Bouaké",
      effectifs: 520000,
      manuels_requis: 2080000,
      manuels_alloues: 1620000,
      couverture: 78,
      iepp_count: 3,
      statut: "APPROUVE",
      date_consolidation: "2024-10-28",
      repartition_iepp: [
        {
          iepp: "IEPP Bouaké 1",
          effectifs: 280000,
          manuels_requis: 1120000,
          manuels_alloues: 874000,
          couverture: 78,
          epp_count: 2,
          statut: "DISTRIBUTION_EFFECTIVE",
          date_consolidation: "2024-10-25",
          repartition_epp: [
            {
              epp: "EPP Bouaké Centre",
              effectifs: 520,
              manuels_requis: 2080,
              manuels_alloues: 1622,
              couverture: 78,
              statut: "DISTRIBUTION_EFFECTIVE",
            },
            {
              epp: "EPP Bouaké Koko",
              effectifs: 460,
              manuels_requis: 1840,
              manuels_alloues: 1435,
              couverture: 78,
              statut: "REGULATION_EFFECTUEE",
            },
          ],
        },
        {
          iepp: "IEPP Bouaké 2",
          effectifs: 240000,
          manuels_requis: 960000,
          manuels_alloues: 748000,
          couverture: 78,
          epp_count: 1,
          statut: "APPROUVE",
          date_consolidation: "2024-10-26",
          repartition_epp: [
            {
              epp: "EPP Bouaké Dar-Es-Salam",
              effectifs: 580,
              manuels_requis: 2320,
              manuels_alloues: 1809,
              couverture: 78,
              statut: "APPROUVE",
            },
          ],
        },
        {
          iepp: "IEPP Sakassou",
          effectifs: 80000,
          manuels_requis: 320000,
          manuels_alloues: 249600,
          couverture: 78,
          epp_count: 1,
          statut: "CONSOLIDE",
          date_consolidation: "2024-10-17",
          repartition_epp: [
            {
              epp: "EPP Sakassou Centre",
              effectifs: 320,
              manuels_requis: 1280,
              manuels_alloues: 998,
              couverture: 78,
              statut: "VALIDE",
            },
          ],
        },
      ],
    },
    {
      drena: "DRENA San-Pédro",
      effectifs: 280000,
      manuels_requis: 1120000,
      manuels_alloues: 873600,
      couverture: 78,
      iepp_count: 2,
      statut: "BROUILLON",
      date_consolidation: null,
      repartition_iepp: [
        {
          iepp: "IEPP San-Pédro 1",
          effectifs: 150000,
          manuels_requis: 600000,
          manuels_alloues: 468000,
          couverture: 78,
          epp_count: 2,
          statut: "SAISI",
          date_consolidation: null,
          repartition_epp: [
            {
              epp: "EPP San-Pédro Centre",
              effectifs: 680,
              manuels_requis: 2720,
              manuels_alloues: 2122,
              couverture: 78,
              statut: "SAISI",
            },
            {
              epp: "EPP San-Pédro Port",
              effectifs: 420,
              manuels_requis: 1680,
              manuels_alloues: 1310,
              couverture: 78,
              statut: "SAISI",
            },
          ],
        },
        {
          iepp: "IEPP Grand-Béréby",
          effectifs: 130000,
          manuels_requis: 520000,
          manuels_alloues: 405600,
          couverture: 78,
          epp_count: 1,
          statut: "SAISI",
          date_consolidation: null,
          repartition_epp: [
            {
              epp: "EPP Grand-Béréby Centre",
              effectifs: 380,
              manuels_requis: 1520,
              manuels_alloues: 1185,
              couverture: 78,
              statut: "SAISI",
            },
          ],
        },
      ],
    },
  ],

  // Répartition par manuel
  repartition_manuels: [
    {
      manuel: "Livre de Français CP1",
      niveau: "CP1",
      quantite_commandee: 285000,
      quantite_repartie: 285000,
      couverture: 100,
      repartition_drena: [
        { drena: "DRENA Abidjan", quantite: 150000, pourcentage: 52.6 },
        { drena: "DRENA Bouaké", quantite: 85000, pourcentage: 29.8 },
        { drena: "DRENA San-Pédro", quantite: 50000, pourcentage: 17.6 },
      ],
    },
    {
      manuel: "Mathématiques CP1",
      niveau: "CP1",
      quantite_commandee: 285000,
      quantite_repartie: 285000,
      couverture: 100,
      repartition_drena: [
        { drena: "DRENA Abidjan", quantite: 150000, pourcentage: 52.6 },
        { drena: "DRENA Bouaké", quantite: 85000, pourcentage: 29.8 },
        { drena: "DRENA San-Pédro", quantite: 50000, pourcentage: 17.6 },
      ],
    },
    {
      manuel: "Français CP2",
      niveau: "CP2",
      quantite_commandee: 270000,
      quantite_repartie: 270000,
      couverture: 100,
      repartition_drena: [
        { drena: "DRENA Abidjan", quantite: 142000, pourcentage: 52.6 },
        { drena: "DRENA Bouaké", quantite: 80500, pourcentage: 29.8 },
        { drena: "DRENA San-Pédro", quantite: 47500, pourcentage: 17.6 },
      ],
    },
  ],
}

// Données pour différentes années
const mockDataByYear = {
  "2024-2025": mockTableauRepartition,
  "2023-2024": {
    ...mockTableauRepartition,
    annee_scolaire: "2023-2024",
    total_manuels_commandes: 1200000,
    total_effectifs: 2800000,
    couverture_globale: 75,
  },
  "2025-2026": {
    ...mockTableauRepartition,
    annee_scolaire: "2025-2026",
    total_manuels_commandes: 1600000,
    total_effectifs: 3500000,
    couverture_globale: 82,
  },
}

export default function TableauRepartitionPage() {
  const { user } = useAuth()
  const [activeTab, setActiveTab] = useState("vue-ensemble")
  const [selectedDRENA, setSelectedDRENA] = useState<any>(null)
  const [selectedIEPP, setSelectedIEPP] = useState<any>(null)
  const [showExportModal, setShowExportModal] = useState(false)
  const [exportType, setExportType] = useState<"pdf" | "excel" | null>(null)
  const [isPrinting, setIsPrinting] = useState(false)
  const [isExporting, setIsExporting] = useState(false)
  const [toast, setToast] = useState<{ type: "success" | "error"; message: string } | null>(null)
  const [selectedYear, setSelectedYear] = useState("2024-2025")
  const [showYearSelector, setShowYearSelector] = useState(false)
  const [showDetailsModal, setShowDetailsModal] = useState(false)
  const [detailsType, setDetailsType] = useState<"drena" | "iepp" | null>(null)
  const [selectedDetails, setSelectedDetails] = useState<any>(null)
  const [showImportModal, setShowImportModal] = useState(false)

  // ✅ CORRECTION: Vérification après tous les hooks
  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <p className="text-gray-600">Chargement...</p>
        </div>
      </div>
    )
  }

  // Obtenir les données pour l'année sélectionnée
  const currentData = mockDataByYear[selectedYear as keyof typeof mockDataByYear] || mockTableauRepartition

  const getStatusIcon = (statut: string) => {
    switch (statut) {
      case "SAISI":
        return <ClockIcon className="h-5 w-5 text-blue-600" />
      case "VALIDE":
        return <CheckCircleIcon className="h-5 w-5 text-green-600" />
      case "CONSOLIDE":
        return <DocumentTextIcon className="h-5 w-5 text-purple-600" />
      case "APPROUVE":
        return <CheckCircleIcon className="h-5 w-5 text-emerald-600" />
      case "DISTRIBUTION_EFFECTIVE":
        return <CheckCircleIcon className="h-5 w-5 text-teal-600" />
      case "REGULATION_EFFECTUEE":
        return <DocumentTextIcon className="h-5 w-5 text-indigo-600" />
      case "EN_COURS":
        return <ClockIcon className="h-5 w-5 text-orange-600" />
      case "BROUILLON":
        return <ExclamationTriangleIcon className="h-5 w-5 text-yellow-600" />
      default:
        return <ExclamationTriangleIcon className="h-5 w-5 text-gray-600" />
    }
  }

  const getStatusBadge = (statut: string) => {
    const baseClasses = "px-2 py-1 text-xs font-medium rounded-full"
    switch (statut) {
      case "SAISI":
        return <span className={`${baseClasses} bg-blue-100 text-blue-800`}>Saisi</span>
      case "VALIDE":
        return <span className={`${baseClasses} bg-green-100 text-green-800`}>Validé</span>
      case "CONSOLIDE":
        return <span className={`${baseClasses} bg-purple-100 text-purple-800`}>Consolidé</span>
      case "APPROUVE":
        return <span className={`${baseClasses} bg-emerald-100 text-emerald-800`}>Approuvé</span>
      case "DISTRIBUTION_EFFECTIVE":
        return <span className={`${baseClasses} bg-teal-100 text-teal-800`}>Distribution Effective</span>
      case "REGULATION_EFFECTUEE":
        return <span className={`${baseClasses} bg-indigo-100 text-indigo-800`}>Régulation Effectuée</span>
      case "EN_COURS":
        return <span className={`${baseClasses} bg-orange-100 text-orange-800`}>En cours</span>
      case "BROUILLON":
        return <span className={`${baseClasses} bg-yellow-100 text-yellow-800`}>Brouillon</span>
      default:
        return <span className={`${baseClasses} bg-gray-100 text-gray-800`}>Inconnu</span>
    }
  }

  // Utilise la fonction formatNumber importée de export-utils

  const handlePrint = async () => {
    setIsPrinting(true)
    try {
      // Simulation d'impression
      await new Promise(resolve => setTimeout(resolve, 2000))
      
      // Ouvrir la boîte de dialogue d'impression du navigateur
      window.print()
      
      setToast({ type: "success", message: "Impression lancée avec succès" })
    } catch (error) {
      setToast({ type: "error", message: "Erreur lors de l'impression" })
    } finally {
      setIsPrinting(false)
      setTimeout(() => setToast(null), 3000)
    }
  }

  const handleExport = () => {
    setShowExportModal(true)
  }

  // 🎯 NOUVELLE FONCTION: Préparer les données d'export basées sur l'état actuel
  const prepareExportData = (): ExportData => {
    // Récupérer les données actuellement affichées selon l'onglet actif
    let exportTables = []
    
    if (activeTab === "vue-ensemble") {
      // Vue d'ensemble - toutes les DRENA
      exportTables.push({
        title: 'Répartition par DRENA',
        headers: ['DRENA', 'Effectifs', 'Manuels Alloués', 'Couverture (%)'],
        data: currentData.repartition_drena.map(drena => [
          drena.drena,
          formatNumber(drena.effectifs),
          formatNumber(drena.manuels_alloues),
          `${drena.couverture}%`
        ])
      })
    } else if (activeTab === "repartition-drena") {
      // Détails par DRENA
      exportTables.push({
        title: 'Détails par DRENA',
        headers: ['DRENA', 'Effectifs', 'Manuels Alloués', 'Couverture (%)', 'Date Consolidation'],
        data: currentData.repartition_drena.map(drena => [
          drena.drena,
          formatNumber(drena.effectifs),
          formatNumber(drena.manuels_alloues),
          `${drena.couverture}%`,
          drena.date_consolidation || 'N/A'
        ])
      })
    } else if (activeTab === "repartition-iepp") {
      // Détails par IEPP
      exportTables.push({
        title: 'Détails par IEPP',
        headers: ['DRENA', 'IEPP', 'Effectifs', 'Manuels Alloués', 'Couverture (%)'],
        data: currentData.repartition_drena.flatMap(drena => 
          drena.repartition_iepp.map(iepp => [
            drena.drena,
            iepp.iepp,
            formatNumber(iepp.effectifs),
            formatNumber(iepp.manuels_alloues),
            `${iepp.couverture}%`
          ])
        )
      })
    } else if (activeTab === "repartition-epp") {
      // Détails par EPP
      exportTables.push({
        title: 'Détails par EPP',
        headers: ['DRENA', 'IEPP', 'EPP', 'Effectifs', 'Manuels Alloués', 'Couverture (%)'],
        data: currentData.repartition_drena.flatMap(drena => 
          drena.repartition_iepp.flatMap(iepp => 
            iepp.repartition_epp.map(epp => [
              drena.drena,
              iepp.iepp,
              epp.epp,
              formatNumber(epp.effectifs),
              formatNumber(epp.manuels_alloues),
              `${epp.couverture}%`
            ])
          )
        )
      })
    } else {
      // Par défaut, inclure toutes les données
      exportTables = [
        {
          title: 'Répartition par DRENA',
          headers: ['DRENA', 'Effectifs', 'Manuels Alloués', 'Couverture (%)'],
          data: currentData.repartition_drena.map(drena => [
            drena.drena,
            formatNumber(drena.effectifs),
            formatNumber(drena.manuels_alloues),
            `${drena.couverture}%`
          ])
        },
        {
          title: 'Détails par IEPP',
          headers: ['DRENA', 'IEPP', 'Effectifs', 'Manuels Alloués', 'Couverture (%)'],
          data: currentData.repartition_drena.flatMap(drena => 
            drena.repartition_iepp.map(iepp => [
              drena.drena,
              iepp.iepp,
              formatNumber(iepp.effectifs),
              formatNumber(iepp.manuels_alloues),
              `${iepp.couverture}%`
            ])
          )
        },
        {
          title: 'Détails par EPP',
          headers: ['DRENA', 'IEPP', 'EPP', 'Effectifs', 'Manuels Alloués', 'Couverture (%)'],
          data: currentData.repartition_drena.flatMap(drena => 
            drena.repartition_iepp.flatMap(iepp => 
              iepp.repartition_epp.map(epp => [
                drena.drena,
                iepp.iepp,
                epp.epp,
                formatNumber(epp.effectifs),
                formatNumber(epp.manuels_alloues),
                `${epp.couverture}%`
              ])
            )
          )
        }
      ]
    }

    return {
      title: 'TABLEAU DE RÉPARTITION',
      subtitle: `Année Scolaire ${currentData.annee_scolaire} - Vue: ${activeTab.replace('-', ' ').toUpperCase()}`,
      date: currentData.date_generation,
      generatedBy: currentData.generate_par,
      status: currentData.statut,
      statistics: [
        { label: 'Total Effectifs', value: formatNumber(currentData.total_effectifs) },
        { label: 'Total Manuels Commandés', value: formatNumber(currentData.total_manuels_commandes) },
        { label: 'Couverture Globale', value: `${currentData.couverture_globale}%` },
        { label: 'Vue Actuelle', value: activeTab.replace('-', ' ').toUpperCase() }
      ],
      tables: exportTables
    }
  }

  // 🎯 NOUVELLE FONCTION: Export PDF avec utilitaires
  const handleExportPDF = async () => {
    const exportData = prepareExportData()
    
    if (!validateExportData(exportData)) {
      throw new Error('Données d\'export invalides')
    }
    
    const fileName = generateFileName(`tableau_repartition_${currentData.annee_scolaire}`, 'pdf')
    exportToPDF(exportData, fileName)
  }

  // 📊 NOUVELLE FONCTION: Export Excel avec utilitaires
  const handleExportExcel = async () => {
    const exportData = prepareExportData()
    
    if (!validateExportData(exportData)) {
      throw new Error('Données d\'export invalides')
    }
    
    const fileName = generateFileName(`tableau_repartition_${currentData.annee_scolaire}`, 'xlsx')
    exportToExcel(exportData, fileName)
  }

  // 🎯 FONCTION PRINCIPALE: Export avec gestion d'erreurs robuste
  const handleExportConfirm = async (type: "pdf" | "excel") => {
    setIsExporting(true)
    setShowExportModal(false)
    
    try {
      // Afficher un message informatif sur les données exportées
      const exportInfo = `Export de la vue: ${activeTab.replace('-', ' ').toUpperCase()}`
      
      if (type === "pdf") {
        await handleExportPDF()
      } else {
        await handleExportExcel()
      }
      
      setToast({ 
        type: "success", 
        message: `✅ Export ${type.toUpperCase()} généré avec succès ! ${exportInfo}` 
      })
    } catch (error) {
      console.error('Erreur lors de l\'export:', error)
      setToast({
        type: "error",
        message: `❌ Erreur lors de l'export ${type.toUpperCase()}: ${error instanceof Error ? error.message : 'Erreur inconnue'}`
      })
    } finally {
      setIsExporting(false)
      setTimeout(() => setToast(null), 5000)
    }
  }

  const handleViewDRENADetails = (drena: any) => {
    setSelectedDetails(drena)
    setDetailsType("drena")
    setShowDetailsModal(true)
  }

  const handleViewIEPPDetails = (iepp: any) => {
    setSelectedDetails(iepp)
    setDetailsType("iepp")
    setShowDetailsModal(true)
  }

  const tabs = [
    { id: "vue-ensemble", name: "Vue d'Ensemble", icon: EyeIcon },
    { id: "repartition-drena", name: "Répartition DRENA", icon: BuildingOfficeIcon },
    { id: "repartition-iepp", name: "Répartition IEPP", icon: MapIcon },
    { id: "repartition-epp", name: "Répartition EPP", icon: UserGroupIcon },
    { id: "repartition-manuels", name: "Répartition Manuels", icon: DocumentTextIcon },
    { id: "export", name: "Export", icon: ArrowDownTrayIcon },
  ]

  // Obtenir toutes les IEPP de toutes les DRENA
  const allIEPP = currentData.repartition_drena.flatMap(drena => 
    drena.repartition_iepp.map(iepp => ({
      ...iepp,
      drena: drena.drena,
    }))
  )

  // Obtenir toutes les EPP de toutes les IEPP
  const allEPP = currentData.repartition_drena.flatMap(drena => 
    drena.repartition_iepp.flatMap(iepp => 
      iepp.repartition_epp.map(epp => ({
        ...epp,
        iepp: iepp.iepp,
        drena: drena.drena,
      }))
    )
  )

  return (
    <MainLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Tableau de Répartition</h1>
            <p className="text-gray-600">
              Répartition des manuels commandés selon les besoins consolidés
            </p>
          </div>
          
          <div className="flex items-center space-x-3">
            {/* Sélecteur d'année */}
            <div className="relative">
              <button
                onClick={() => setShowYearSelector(!showYearSelector)}
                className="flex items-center space-x-2 px-4 py-2 border border-gray-300 rounded-lg bg-white hover:bg-gray-50"
              >
                <CalendarIcon className="h-5 w-5 text-gray-500" />
                <span className="text-gray-700">{selectedYear}</span>
                <ChevronDownIcon className="h-4 w-4 text-gray-500" />
              </button>
              
              {showYearSelector && (
                <div className="absolute top-full left-0 mt-1 w-full bg-white border border-gray-300 rounded-lg shadow-lg z-10">
                  {Object.keys(mockDataByYear).map((year) => (
                    <button
                      key={year}
                      onClick={() => {
                        setSelectedYear(year)
                        setShowYearSelector(false)
                      }}
                      className={`w-full text-left px-4 py-2 hover:bg-gray-50 ${
                        selectedYear === year ? "bg-orange-50 text-orange-600" : "text-gray-700"
                      }`}
                    >
                      {year}
                    </button>
                  ))}
                </div>
              )}
            </div>
            
            <button 
              onClick={handlePrint}
              disabled={isPrinting}
              className={`flex items-center space-x-2 px-4 py-2 rounded-lg ${
                isPrinting 
                  ? "bg-gray-400 cursor-not-allowed" 
                  : "bg-blue-600 hover:bg-blue-700"
              } text-white`}
            >
              <PrinterIcon className="h-5 w-5" />
              <span>{isPrinting ? "Impression..." : "Imprimer"}</span>
            </button>
            <div className="flex flex-col items-center">
              <button 
                onClick={handleExport}
                disabled={isExporting}
                className={`flex items-center space-x-2 px-4 py-2 rounded-lg ${
                  isExporting 
                    ? "bg-gray-400 cursor-not-allowed" 
                    : "bg-green-600 hover:bg-green-700"
                } text-white`}
              >
                <ArrowDownTrayIcon className="h-5 w-5" />
                <span>{isExporting ? "Export..." : "Exporter"}</span>
              </button>
              <div className="text-xs text-gray-500 mt-1 text-center">
                Vue: {activeTab.replace('-', ' ').toUpperCase()}
              </div>
            </div>
            
            {/* Bouton Import pour ADMIN et DAF */}
            {(user.role.code === "ADMIN" || user.role.code === "DAF") && (
              <button 
                onClick={() => setShowImportModal(true)}
                className="flex items-center space-x-2 px-4 py-2 rounded-lg bg-orange-600 hover:bg-orange-700 text-white"
              >
                <ArrowUpTrayIcon className="h-5 w-5" />
                <span>Import Excel</span>
              </button>
            )}
          </div>
        </div>

        {/* Toast Notification */}
        {toast && (
          <div className={`fixed top-4 right-4 z-50 p-4 rounded-lg shadow-lg ${
            toast.type === "success" ? "bg-green-500 text-white" : "bg-red-500 text-white"
          }`}>
            {toast.message}
          </div>
        )}

        {/* Informations générales */}
        <div className="bg-white rounded-lg shadow p-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div className="text-center">
              <div className="text-2xl font-bold text-gray-900">
                {currentData.annee_scolaire}
              </div>
              <div className="text-sm text-gray-500">Année Scolaire</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-gray-900">
                {formatNumber(currentData.total_effectifs)}
              </div>
              <div className="text-sm text-gray-500">Effectifs Totaux</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-gray-900">
                {formatNumber(currentData.total_manuels_commandes)}
              </div>
              <div className="text-sm text-gray-500">Manuels Commandés</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-gray-900">
                {currentData.couverture_globale}%
              </div>
              <div className="text-sm text-gray-500">Couverture Globale</div>
            </div>
          </div>
          
          <div className="mt-6 pt-6 border-t border-gray-200">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <div className="flex items-center space-x-2">
                  {getStatusIcon(currentData.statut)}
                  {getStatusBadge(currentData.statut)}
                </div>
                <div className="text-sm text-gray-600">
                  Généré le {currentData.date_generation} par {currentData.generate_par}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Tabs */}
        <div className="border-b border-gray-200">
          <nav className="-mb-px flex space-x-8 overflow-x-auto">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`py-2 px-1 border-b-2 font-medium text-sm flex items-center space-x-2 whitespace-nowrap ${
                  activeTab === tab.id
                    ? "border-orange-500 text-orange-600"
                    : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
                }`}
              >
                <tab.icon className="h-4 w-4" />
                <span>{tab.name}</span>
              </button>
            ))}
          </nav>
        </div>

        {/* Content */}
        <div className="space-y-6">
          {activeTab === "vue-ensemble" && (
            <div className="space-y-6">
              {/* Carte de répartition géographique */}
              <div className="bg-white rounded-lg shadow">
                <div className="px-6 py-4 border-b border-gray-200">
                  <h3 className="text-lg font-medium text-gray-900">Répartition Géographique</h3>
                </div>
                <div className="p-6">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    {currentData.repartition_drena.map((drena) => (
                      <div key={drena.drena} className="bg-gray-50 rounded-lg p-4">
                        <div className="flex items-center justify-between mb-3">
                          <h4 className="font-medium text-gray-900">{drena.drena}</h4>
                          <span className="text-sm text-gray-500">{drena.couverture}%</span>
                        </div>
                        <div className="space-y-2">
                          <div className="flex justify-between text-sm">
                            <span className="text-gray-600">Effectifs:</span>
                            <span className="font-medium">{formatNumber(drena.effectifs)}</span>
                          </div>
                          <div className="flex justify-between text-sm">
                            <span className="text-gray-600">Manuels requis:</span>
                            <span className="font-medium">{formatNumber(drena.manuels_requis)}</span>
                          </div>
                          <div className="flex justify-between text-sm">
                            <span className="text-gray-600">Manuels alloués:</span>
                            <span className="font-medium">{formatNumber(drena.manuels_alloues)}</span>
                          </div>
                          <div className="flex justify-between text-sm">
                            <span className="text-gray-600">IEPP:</span>
                            <span className="font-medium">{drena.iepp_count}</span>
                          </div>
                        </div>
                        <div className="mt-3">
                          <div className="w-full bg-gray-200 rounded-full h-2">
                            <div 
                              className="bg-green-600 h-2 rounded-full" 
                              style={{ width: `${drena.couverture}%` }}
                            ></div>
                          </div>
                        </div>
                        <div className="mt-3">
                          <button
                            onClick={() => handleViewDRENADetails(drena)}
                            className="text-blue-600 hover:text-blue-800 text-sm"
                          >
                            Voir détails
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Graphique de couverture */}
              <div className="bg-white rounded-lg shadow">
                <div className="px-6 py-4 border-b border-gray-200">
                  <h3 className="text-lg font-medium text-gray-900">Couverture par Niveau</h3>
                </div>
                <div className="p-6">
                  <div className="space-y-4">
                    {currentData.repartition_manuels.map((manuel) => (
                      <div key={manuel.manuel} className="border rounded-lg p-4">
                        <div className="flex items-center justify-between mb-3">
                          <div>
                            <h4 className="font-medium text-gray-900">{manuel.manuel}</h4>
                            <p className="text-sm text-gray-500">Niveau {manuel.niveau}</p>
                          </div>
                          <span className="text-sm font-medium text-gray-900">
                            {formatNumber(manuel.quantite_repartie)} / {formatNumber(manuel.quantite_commandee)}
                          </span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div 
                            className="bg-blue-600 h-2 rounded-full" 
                            style={{ width: `${manuel.couverture}%` }}
                          ></div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === "repartition-drena" && (
            <div className="space-y-6">
              {currentData.repartition_drena.map((drena) => (
                <div key={drena.drena} className="bg-white rounded-lg shadow">
                  <div className="px-6 py-4 border-b border-gray-200">
                    <div className="flex items-center justify-between">
                      <h3 className="text-lg font-medium text-gray-900">{drena.drena}</h3>
                      <div className="flex items-center space-x-4">
                        <span className="text-sm text-gray-500">
                          {formatNumber(drena.manuels_alloues)} / {formatNumber(drena.manuels_requis)} manuels
                        </span>
                        <span className="text-sm font-medium text-gray-900">
                          {drena.couverture}% de couverture
                        </span>
                      </div>
                    </div>
                  </div>
                  <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-gray-200">
                      <thead className="bg-gray-50">
                        <tr>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            IEPP
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Effectifs
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Manuels Requis
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Manuels Alloués
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Couverture
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            EPP
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Actions
                          </th>
                        </tr>
                      </thead>
                      <tbody className="bg-white divide-y divide-gray-200">
                        {drena.repartition_iepp.map((iepp) => (
                          <tr key={iepp.iepp} className="hover:bg-gray-50">
                            <td className="px-6 py-4 whitespace-nowrap">
                              <div className="text-sm font-medium text-gray-900">{iepp.iepp}</div>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                              {formatNumber(iepp.effectifs)}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                              {formatNumber(iepp.manuels_requis)}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                              {formatNumber(iepp.manuels_alloues)}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <div className="flex items-center">
                                <div className="w-16 bg-gray-200 rounded-full h-2 mr-2">
                                  <div 
                                    className="bg-green-600 h-2 rounded-full" 
                                    style={{ width: `${iepp.couverture}%` }}
                                  ></div>
                                </div>
                                <span className="text-sm text-gray-900">{iepp.couverture}%</span>
                              </div>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                              {iepp.epp_count} écoles
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                              <button
                                onClick={() => handleViewIEPPDetails(iepp)}
                                className="text-blue-600 hover:text-blue-900"
                              >
                                Voir détails
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              ))}
            </div>
          )}

          {activeTab === "repartition-iepp" && (
            <div className="bg-white rounded-lg shadow">
              <div className="px-6 py-4 border-b border-gray-200">
                <h3 className="text-lg font-medium text-gray-900">Répartition par IEPP</h3>
                <p className="text-sm text-gray-600 mt-1">
                  Vue d'ensemble de toutes les IEPP avec leurs répartitions
                </p>
              </div>
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        IEPP
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        DRENA
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Effectifs
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Manuels Requis
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Manuels Alloués
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Couverture
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        EPP
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Actions
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {allIEPP.map((iepp) => (
                      <tr key={`${iepp.drena}-${iepp.iepp}`} className="hover:bg-gray-50">
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="text-sm font-medium text-gray-900">{iepp.iepp}</div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                          {iepp.drena}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                          {formatNumber(iepp.effectifs)}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                          {formatNumber(iepp.manuels_requis)}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                          {formatNumber(iepp.manuels_alloues)}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center">
                            <div className="w-16 bg-gray-200 rounded-full h-2 mr-2">
                              <div 
                                className="bg-green-600 h-2 rounded-full" 
                                style={{ width: `${iepp.couverture}%` }}
                              ></div>
                            </div>
                            <span className="text-sm text-gray-900">{iepp.couverture}%</span>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                          {iepp.epp_count} écoles
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                          <button
                            onClick={() => handleViewIEPPDetails(iepp)}
                            className="text-blue-600 hover:text-blue-900"
                          >
                            Voir détails
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {activeTab === "repartition-epp" && (
            <div className="bg-white rounded-lg shadow">
              <div className="px-6 py-4 border-b border-gray-200">
                <h3 className="text-lg font-medium text-gray-900">Répartition par EPP</h3>
                <p className="text-sm text-gray-600 mt-1">
                  Vue détaillée de toutes les EPP avec leurs allocations
                </p>
              </div>
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        EPP
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        IEPP
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        DRENA
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Effectifs
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Manuels Requis
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Manuels Alloués
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Couverture
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {allEPP.map((epp) => (
                      <tr key={`${epp.drena}-${epp.iepp}-${epp.epp}`} className="hover:bg-gray-50">
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="text-sm font-medium text-gray-900">{epp.epp}</div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                          {epp.iepp}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                          {epp.drena}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                          {formatNumber(epp.effectifs)}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                          {formatNumber(epp.manuels_requis)}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                          {formatNumber(epp.manuels_alloues)}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center">
                            <div className="w-16 bg-gray-200 rounded-full h-2 mr-2">
                              <div 
                                className="bg-green-600 h-2 rounded-full" 
                                style={{ width: `${epp.couverture}%` }}
                              ></div>
                            </div>
                            <span className="text-sm text-gray-900">{epp.couverture}%</span>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {activeTab === "repartition-manuels" && (
            <div className="space-y-6">
              {currentData.repartition_manuels.map((manuel) => (
                <div key={manuel.manuel} className="bg-white rounded-lg shadow">
                  <div className="px-6 py-4 border-b border-gray-200">
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="text-lg font-medium text-gray-900">{manuel.manuel}</h3>
                        <p className="text-sm text-gray-500">Niveau {manuel.niveau}</p>
                      </div>
                      <div className="flex items-center space-x-4">
                        <span className="text-sm text-gray-500">
                          {formatNumber(manuel.quantite_repartie)} / {formatNumber(manuel.quantite_commandee)}
                        </span>
                        <span className="text-sm font-medium text-gray-900">
                          {manuel.couverture}% de couverture
                        </span>
                      </div>
                    </div>
                  </div>
                  <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-gray-200">
                      <thead className="bg-gray-50">
                        <tr>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            DRENA
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Quantité Allouée
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Pourcentage
                          </th>
                        </tr>
                      </thead>
                      <tbody className="bg-white divide-y divide-gray-200">
                        {manuel.repartition_drena.map((repartition) => (
                          <tr key={repartition.drena} className="hover:bg-gray-50">
                            <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                              {repartition.drena}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                              {formatNumber(repartition.quantite)}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <div className="flex items-center">
                                <div className="w-16 bg-gray-200 rounded-full h-2 mr-2">
                                  <div 
                                    className="bg-blue-600 h-2 rounded-full" 
                                    style={{ width: `${repartition.pourcentage}%` }}
                                  ></div>
                                </div>
                                <span className="text-sm text-gray-900">{repartition.pourcentage}%</span>
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              ))}
            </div>
          )}

          {activeTab === "export" && (
            <div className="bg-white rounded-lg shadow">
              <div className="px-6 py-4 border-b border-gray-200">
                <h3 className="text-lg font-medium text-gray-900">Export du Tableau de Répartition</h3>
              </div>
              <div className="p-6">
                <div className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <button 
                      onClick={() => handleExportConfirm("pdf")}
                      disabled={isExporting}
                      className={`flex items-center justify-center space-x-2 p-4 border-2 border-dashed rounded-lg ${
                        isExporting 
                          ? "border-gray-200 cursor-not-allowed" 
                          : "border-gray-300 hover:border-gray-400"
                      }`}
                    >
                      <DocumentTextIcon className={`h-8 w-8 ${isExporting ? "text-gray-200" : "text-gray-400"}`} />
                      <span className={isExporting ? "text-gray-400" : "text-gray-600"}>
                        {isExporting ? "Export en cours..." : "Export PDF"}
                      </span>
                    </button>
                    <button 
                      onClick={() => handleExportConfirm("excel")}
                      disabled={isExporting}
                      className={`flex items-center justify-center space-x-2 p-4 border-2 border-dashed rounded-lg ${
                        isExporting 
                          ? "border-gray-200 cursor-not-allowed" 
                          : "border-gray-300 hover:border-gray-400"
                      }`}
                    >
                      <DocumentTextIcon className={`h-8 w-8 ${isExporting ? "text-gray-200" : "text-gray-400"}`} />
                      <span className={isExporting ? "text-gray-400" : "text-gray-600"}>
                        {isExporting ? "Export en cours..." : "Export Excel"}
                      </span>
                    </button>
                  </div>
                  <p className="text-sm text-gray-600">
                    Choisissez le format d'export pour télécharger le tableau de répartition.
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Modal d'export */}
        {showExportModal && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white rounded-lg shadow-xl max-w-md w-full mx-4">
              <div className="px-6 py-4 border-b border-gray-200 flex justify-between items-center">
                <h3 className="text-lg font-medium text-gray-900">Choisir le format d'export</h3>
                <button
                  onClick={() => setShowExportModal(false)}
                  className="text-gray-400 hover:text-gray-600"
                >
                  <XMarkIcon className="h-6 w-6" />
                </button>
              </div>
              <div className="p-6">
                <div className="space-y-4">
                  <button
                    onClick={() => handleExportConfirm("pdf")}
                    className="w-full flex items-center justify-center space-x-2 p-4 border-2 border-dashed border-gray-300 rounded-lg hover:border-gray-400"
                  >
                    <DocumentTextIcon className="h-8 w-8 text-gray-400" />
                    <span className="text-gray-600">Export PDF</span>
                  </button>
                  <button
                    onClick={() => handleExportConfirm("excel")}
                    className="w-full flex items-center justify-center space-x-2 p-4 border-2 border-dashed border-gray-300 rounded-lg hover:border-gray-400"
                  >
                    <DocumentTextIcon className="h-8 w-8 text-gray-400" />
                    <span className="text-gray-600">Export Excel</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Modal pour les détails */}
        {showDetailsModal && selectedDetails && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white rounded-lg shadow-xl max-w-4xl w-full mx-4 max-h-[90vh] overflow-y-auto">
              <div className="px-6 py-4 border-b border-gray-200">
                <div className="flex justify-between items-center">
                  <h3 className="text-lg font-medium text-gray-900">
                    {detailsType === "drena" ? "Détails DRENA" : "Détails IEPP"} - {selectedDetails.drena || selectedDetails.iepp}
                  </h3>
                  <button
                    onClick={() => setShowDetailsModal(false)}
                    className="text-gray-400 hover:text-gray-600"
                  >
                    <XMarkIcon className="h-6 w-6" />
                  </button>
                </div>
              </div>

              <div className="p-6">
                {detailsType === "drena" ? (
                  <div className="space-y-6">
                    <div className="grid grid-cols-2 gap-6">
                      <div>
                        <label className="block text-sm font-medium text-gray-700">DRENA</label>
                        <p className="mt-1 text-sm text-gray-900">{selectedDetails.drena}</p>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700">Statut</label>
                        <div className="mt-1">
                          {getStatusBadge(selectedDetails.statut)}
                        </div>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700">Date de Consolidation</label>
                        <p className="mt-1 text-sm text-gray-900">
                          {selectedDetails.date_consolidation || "Non consolidé"}
                        </p>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700">Nombre d'IEPP</label>
                        <p className="mt-1 text-sm text-gray-900">{selectedDetails.iepp_count}</p>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700">Total Effectifs</label>
                        <p className="mt-1 text-sm text-gray-900">{formatNumber(selectedDetails.effectifs)}</p>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700">Total Manuels</label>
                        <p className="mt-1 text-sm text-gray-900">{formatNumber(selectedDetails.manuels_alloues)}</p>
                      </div>
                    </div>

                    <div>
                      <h4 className="text-md font-medium text-gray-900 mb-4">Répartition par IEPP</h4>
                      <div className="overflow-x-auto">
                        <table className="min-w-full divide-y divide-gray-200">
                          <thead className="bg-gray-50">
                            <tr>
                              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                IEPP
                              </th>
                              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Effectifs
                              </th>
                              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Manuels Alloués
                              </th>
                              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Couverture
                              </th>
                              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Statut
                              </th>
                            </tr>
                          </thead>
                          <tbody className="bg-white divide-y divide-gray-200">
                            {selectedDetails.repartition_iepp?.map((iepp: any, index: number) => (
                              <tr key={index} className="hover:bg-gray-50">
                                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                                  {iepp.iepp}
                                </td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                  {formatNumber(iepp.effectifs)}
                                </td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                  {formatNumber(iepp.manuels_alloues)}
                                </td>
                                <td className="px-6 py-4 whitespace-nowrap">
                                  <div className="flex items-center">
                                    <div className="w-16 bg-gray-200 rounded-full h-2 mr-2">
                                      <div 
                                        className="bg-green-600 h-2 rounded-full" 
                                        style={{ width: `${iepp.couverture}%` }}
                                      ></div>
                                    </div>
                                    <span className="text-sm text-gray-900">{iepp.couverture}%</span>
                                  </div>
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-6">
                    <div className="grid grid-cols-2 gap-6">
                      <div>
                        <label className="block text-sm font-medium text-gray-700">IEPP</label>
                        <p className="mt-1 text-sm text-gray-900">{selectedDetails.iepp}</p>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700">DRENA</label>
                        <p className="mt-1 text-sm text-gray-900">{selectedDetails.drena}</p>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700">Statut</label>
                        <div className="mt-1">
                          {getStatusBadge(selectedDetails.statut)}
                        </div>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700">Date de Consolidation</label>
                        <p className="mt-1 text-sm text-gray-900">
                          {selectedDetails.date_consolidation || "Non consolidé"}
                        </p>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700">Nombre d'EPP</label>
                        <p className="mt-1 text-sm text-gray-900">{selectedDetails.epp_count}</p>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700">Total Effectifs</label>
                        <p className="mt-1 text-sm text-gray-900">{formatNumber(selectedDetails.effectifs)}</p>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700">Total Manuels</label>
                        <p className="mt-1 text-sm text-gray-900">{formatNumber(selectedDetails.manuels_alloues)}</p>
                      </div>
                    </div>

                    <div>
                      <h4 className="text-md font-medium text-gray-900 mb-4">Répartition par EPP</h4>
                      <div className="overflow-x-auto">
                        <table className="min-w-full divide-y divide-gray-200">
                          <thead className="bg-gray-50">
                            <tr>
                              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                EPP
                              </th>
                              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Effectifs
                              </th>
                              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Manuels Alloués
                              </th>
                              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Couverture
                              </th>
                              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Statut
                              </th>
                            </tr>
                          </thead>
                          <tbody className="bg-white divide-y divide-gray-200">
                            {selectedDetails.repartition_epp?.map((epp: any, index: number) => (
                              <tr key={index} className="hover:bg-gray-50">
                                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                                  {epp.epp}
                                </td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                  {formatNumber(epp.effectifs)}
                                </td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                  {formatNumber(epp.manuels_alloues)}
                                </td>
                                <td className="px-6 py-4 whitespace-nowrap">
                                  <div className="flex items-center">
                                    <div className="w-16 bg-gray-200 rounded-full h-2 mr-2">
                                      <div 
                                        className="bg-green-600 h-2 rounded-full" 
                                        style={{ width: `${epp.couverture}%` }}
                                      ></div>
                                    </div>
                                    <span className="text-sm text-gray-900">{epp.couverture}%</span>
                                  </div>
                                </td>
                                <td className="px-6 py-4 whitespace-nowrap">
                                  {getStatusBadge(epp.statut)}
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              <div className="px-6 py-4 border-t border-gray-200 flex justify-end">
                <button
                  onClick={() => setShowDetailsModal(false)}
                  className="px-4 py-2 bg-gray-600 hover:bg-gray-700 text-white rounded-md text-sm font-medium"
                >
                  Fermer
                </button>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Modal d'Import */}
      <ImportModal 
        isOpen={showImportModal}
        onClose={() => setShowImportModal(false)}
      />
    </MainLayout>
  )
} 