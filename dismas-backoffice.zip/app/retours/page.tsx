"use client"

import { useState, useEffect, useMemo } from "react"
import MainLayout from "../../components/layout/main-layout"
import { useAuth } from "../providers"
import { useMatieres } from "@/hooks/use-matieres"
import { useNiveauxScolaires } from "@/hooks/use-niveaux-scolaires"
import { useAnneesScolaires } from "@/hooks/use-annees-scolaires"
import { retourService, RetourManuelData, RetourManuelResponse } from "@/lib/services/retour.service"
import PaginationControls from "../../components/ui/pagination-controls"
import { 
  PlusIcon, 
  ArrowUturnLeftIcon, 
  CheckCircleIcon, 
  ClockIcon, 
  CalendarIcon,
  PencilIcon,
  TrashIcon,
  XMarkIcon
} from "@heroicons/react/24/outline"
import toast from "react-hot-toast"
import { displayNiveauCodeOnly } from "@/lib/utils/niveau-display"

export default function RetoursPage() {
  const { user } = useAuth()
  const { matieres, loading: matieresLoading } = useMatieres({ onlyActive: true })
  const { niveauxScolaires: niveaux, loading: niveauxLoading } = useNiveauxScolaires()
  const { anneesScolaires, loading: anneesLoading } = useAnneesScolaires()

  // 🔍 DEBUG : Logs pour vérifier le chargement des données
  useEffect(() => {
    console.log('📊 Matieres chargées:', matieres.length, matieres)
    console.log('📊 Niveaux chargés:', niveaux.length, niveaux)
    console.log('📊 Années scolaires chargées:', anneesScolaires.length, anneesScolaires)
  }, [matieres, niveaux, anneesScolaires])

  // États pour les retours
  const [retours, setRetours] = useState<RetourManuelResponse[]>([])
  const [loading, setLoading] = useState(false)
  const [selectedRetour, setSelectedRetour] = useState<RetourManuelResponse | null>(null)
  const [showModal, setShowModal] = useState(false)
  const [showDetailsModal, setShowDetailsModal] = useState(false)
  const [isEditing, setIsEditing] = useState(false)
  const [submitting, setSubmitting] = useState(false)
  const [deletingId, setDeletingId] = useState<number | null>(null)

  // États pour la pagination
  const [currentPage, setCurrentPage] = useState(0)
  const [pageSize, setPageSize] = useState(10)
  const [totalPages, setTotalPages] = useState(0)
  const [totalCount, setTotalCount] = useState(0)

  // État du formulaire
  const [formData, setFormData] = useState({
    niveauId: '',
    matiereId: '',
    anneeScolaireId: '',
    dateRetour: new Date().toISOString().split('T')[0],
    quantiteDistribuee: '',
    quantiteRetournee: '',
    effectifClasse: '',
    commentaire: ''
  })

  /** Aligné sur RetourManuelBusiness.validateRetourWriteAccess : saisie réservée directeur / profil EPP (pas maître). */
  const mutationBusy = loading || submitting || deletingId !== null

  const canManageRetours = useMemo(() => {
    const role = user?.role?.code?.toUpperCase() ?? ""
    const st = user?.structure?.type?.toUpperCase() ?? ""
    if (role === "MAITRE") return false
    return role === "DIRECTEUR" || role === "EPP" || st === "EPP"
  }, [user])

  const retourAnneeCible = useMemo(() => {
    const anneeCourante = (anneesScolaires || []).find((a: any) => a?.estCourante === true)
    if (!anneeCourante?.code) return null
    const parts = String(anneeCourante.code).split("-")
    if (parts.length !== 2) return null
    const start = Number(parts[0])
    if (Number.isNaN(start)) return null
    const previousCode = `${start - 1}-${start}`
    return (anneesScolaires || []).find((a: any) => a?.code === previousCode) || null
  }, [anneesScolaires])

  // Chargement initial des retours
  useEffect(() => {
    if (user?.structure?.id) {
      loadRetours()
    }
  }, [currentPage, pageSize, user])

  useEffect(() => {
    if (showModal && !isEditing && retourAnneeCible?.id) {
      setFormData((prev) => ({ ...prev, anneeScolaireId: String(retourAnneeCible.id) }))
    }
  }, [showModal, isEditing, retourAnneeCible?.id])

  // ✅ CORRECTION: Vérification après tous les hooks
  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <p className="text-gray-600">Chargement...</p>
        </div>
      </div>
    )
  }

  /**
   * Charge les retours depuis l'API
   */
  const loadRetours = async () => {
    if (!user?.structure?.id) return

    setLoading(true)
    try {
      console.log('📊 Chargement retours pour structure:', user.structure.id)
      
      const response = await retourService.getByStructure(
        user.structure.id,
        undefined, // Toutes les années
        currentPage,
        pageSize
      )

      if (response.success && response.data) {
        setRetours(response.data)
        setTotalPages(response.pagination?.totalPages || 0)
        setTotalCount(response.pagination?.totalCount || 0)
        console.log('✅ Retours chargés:', response.data.length)
      } else {
        console.warn('⚠️ Aucun retour trouvé')
        setRetours([])
      }
    } catch (error) {
      console.error('❌ Erreur chargement retours:', error)
      toast.error('Erreur lors du chargement des récupérations')
    } finally {
      setLoading(false)
    }
  }

  /**
   * Réinitialise le formulaire
   */
  const resetForm = () => {
    setFormData({
      niveauId: '',
      matiereId: '',
      anneeScolaireId: retourAnneeCible?.id ? String(retourAnneeCible.id) : '',
      dateRetour: new Date().toISOString().split('T')[0],
      quantiteDistribuee: '',
      quantiteRetournee: '',
      effectifClasse: '',
      commentaire: ''
    })
    setIsEditing(false)
    setSelectedRetour(null)
  }

  /**
   * Ouvre le modal pour créer un nouveau retour
   */
  const handleNouveauRetour = () => {
    if (!canManageRetours || mutationBusy) return
    resetForm()
    setShowModal(true)
  }

  /**
   * Ouvre le modal pour éditer un retour
   */
  const handleEditRetour = (retour: RetourManuelResponse) => {
    setSelectedRetour(retour)
    setFormData({
      niveauId: retour.niveauId?.toString() || '',
      matiereId: retour.matiereId?.toString() || '',
      anneeScolaireId: retour.anneeScolaireId?.toString() || '',
      dateRetour: retour.dateRetour ? new Date(retour.dateRetour.split('/').reverse().join('-')).toISOString().split('T')[0] : new Date().toISOString().split('T')[0],
      quantiteDistribuee:
        retour.quantiteDistribuee != null ? String(retour.quantiteDistribuee) : '',
      quantiteRetournee: retour.quantiteRetournee?.toString() || '',
      effectifClasse: retour.effectifClasse?.toString() || '',
      commentaire: retour.commentaire || ''
    })
    setIsEditing(true)
    setShowModal(true)
  }

  /**
   * Soumet le formulaire (création ou modification)
   */
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (submitting) return
    if (!canManageRetours) {
      toast.error("Consultation seule : vous ne pouvez pas enregistrer de récupération avec ce profil.")
      return
    }

    // Validation
    if (!formData.niveauId || !formData.matiereId || !formData.anneeScolaireId || !formData.quantiteRetournee || !formData.quantiteDistribuee) {
      toast.error('Veuillez remplir tous les champs obligatoires (Niveau, Matière, Année, quantités distribuée et récupérée)')
      return
    }

    const qDist = parseInt(formData.quantiteDistribuee, 10)
    const qRet = parseInt(formData.quantiteRetournee, 10)
    if (Number.isNaN(qDist) || qDist <= 0) {
      toast.error('La quantité distribuée doit être un nombre supérieur à 0')
      return
    }
    if (Number.isNaN(qRet) || qRet <= 0) {
      toast.error('La quantité récupérée doit être supérieure à 0')
      return
    }
    if (qRet > qDist) {
      toast.error('La quantité récupérée ne peut pas dépasser la quantité distribuée')
      return
    }

    if (!isEditing && !retourAnneeCible?.id) {
      const anneeCouranteCode = (anneesScolaires || []).find((a: any) => a?.estCourante === true)?.code
      const retourCode = typeof anneeCouranteCode === "string" && /^\d{4}-\d{4}$/.test(anneeCouranteCode)
        ? `${Number(anneeCouranteCode.slice(0, 4)) - 1}-${Number(anneeCouranteCode.slice(0, 4))}`
        : "N-1"
      toast.error(`Impossible d'enregistrer: l'année scolaire ${retourCode} est introuvable.`)
      return
    }

    setSubmitting(true)
    try {
      const retourData: RetourManuelData = {
        structureId: user.structure?.id || 0,
        anneeScolaireId: !isEditing && retourAnneeCible?.id ? retourAnneeCible.id : parseInt(formData.anneeScolaireId),
        niveauId: parseInt(formData.niveauId),
        matiereId: parseInt(formData.matiereId),
        dateRetour: formData.dateRetour,
        quantiteRetournee: parseInt(formData.quantiteRetournee, 10),
        quantiteDistribuee: parseInt(formData.quantiteDistribuee, 10),
        effectifClasse: formData.effectifClasse ? parseInt(formData.effectifClasse) : undefined,
        commentaire: formData.commentaire || undefined
      }

      if (isEditing && selectedRetour) {
        // Modification
        retourData.id = selectedRetour.id
        const response = await retourService.update(retourData)

        if (response.success) {
          toast.success('Récupération modifiée avec succès')
          setShowModal(false)
          resetForm()
          loadRetours()
        } else {
          toast.error(response.message || 'Erreur lors de la modification')
        }
      } else {
        // Création
        const response = await retourService.create(retourData)

        if (response.success) {
          toast.success('Récupération enregistrée avec succès')
          setShowModal(false)
          resetForm()
          loadRetours()
        } else {
          toast.error(response.message || 'Erreur lors de l\'enregistrement')
        }
      }
    } catch (error: any) {
      console.error('❌ Erreur soumission formulaire:', error)
      toast.error('Erreur lors de l\'enregistrement de la récupération')
    } finally {
      setSubmitting(false)
    }
  }

  /**
   * Supprime un retour
   */
  const handleDeleteRetour = async (id: number) => {
    if (!canManageRetours || deletingId !== null) return
    if (!confirm('Êtes-vous sûr de vouloir supprimer cette récupération ?')) return

    setDeletingId(id)
    try {
      const response = await retourService.deleteRetour(id)

      if (response.success) {
        toast.success('Récupération supprimée avec succès')
        loadRetours()
      } else {
        toast.error(response.message || 'Erreur lors de la suppression')
      }
    } catch (error: any) {
      console.error('❌ Erreur suppression retour:', error)
      toast.error('Erreur lors de la suppression de la récupération')
    } finally {
      setDeletingId(null)
    }
  }

  /**
   * Affiche les détails d'un retour
   */
  const handleShowDetails = (retour: RetourManuelResponse) => {
    setSelectedRetour(retour)
    setShowDetailsModal(true)
  }

  /**
   * Gestion de la pagination
   */
  const handlePageChange = (newPage: number) => {
    setCurrentPage(newPage)
  }

  const handlePageSizeChange = (newSize: number) => {
    setPageSize(newSize)
    setCurrentPage(0) // Reset à la première page
  }

  // Calcul des statistiques
  const totalRetours = retours.length
  const totalManuelsRetournes = retours.reduce((sum, r) => sum + (r.quantiteRetournee || 0), 0)

  return (
    <MainLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Récupération de manuels</h1>
            <p className="text-gray-600">
              {canManageRetours
                ? "Collecte et évaluation des manuels en fin d'année"
                : "Consultation des récupérations saisies par les établissements de votre ressort"}
            </p>
          </div>
          {canManageRetours && (
          <button 
            onClick={handleNouveauRetour} 
            className="btn-primary mt-4 sm:mt-0"
            disabled={mutationBusy}
          >
            <PlusIcon className="h-5 w-5 mr-2" />
            Nouvelle récupération
          </button>
          )}
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="stat-card">
            <div className="flex items-center">
              <div className="p-3 rounded-lg bg-blue-50 text-blue-600">
                <ArrowUturnLeftIcon className="h-6 w-6" />
              </div>
              <div className="ml-4">
                <p className="stat-label">Total récupérations</p>
                <p className="stat-value">{totalCount}</p>
              </div>
            </div>
          </div>

          <div className="stat-card">
            <div className="flex items-center">
              <div className="p-3 rounded-lg bg-green-50 text-green-600">
                <CheckCircleIcon className="h-6 w-6" />
              </div>
              <div className="ml-4">
                <p className="stat-label">Manuels récupérés</p>
                <p className="stat-value">{totalManuelsRetournes}</p>
              </div>
            </div>
          </div>

          <div className="stat-card">
            <div className="flex items-center">
              <div className="p-3 rounded-lg bg-purple-50 text-purple-600">
                <CalendarIcon className="h-6 w-6" />
              </div>
              <div className="ml-4">
                <p className="stat-label">Structure</p>
                <p className="stat-value text-sm">{user?.structure?.libelle || 'N/A'}</p>
              </div>
            </div>
          </div>
        </div>

        {/* Liste des retours */}
        <div className="card">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-gray-900">Récupérations récentes</h3>
            {loading && (
              <div className="flex items-center text-blue-600">
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-blue-600 mr-2"></div>
                Chargement...
              </div>
            )}
          </div>

          {retours.length === 0 && !loading ? (
            <div className="text-center py-8">
              <ArrowUturnLeftIcon className="h-12 w-12 mx-auto text-gray-300 mb-4" />
              <p className="text-gray-500">Aucune récupération trouvée</p>
              <p className="text-sm text-gray-400 mt-2">
                {canManageRetours
                  ? "Créez votre première récupération pour commencer"
                  : "Aucune récupération enregistrée pour le périmètre visible."}
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="table">
                <thead>
                  <tr>
                    <th>ID</th>
                    {!canManageRetours && <th>Établissement</th>}
                    <th>Niveau</th>
                    <th>Matière</th>
                    <th>Année Scolaire</th>
                    <th>Date de récupération</th>
                    <th>Distribué</th>
                    <th>Récupéré</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {retours.map((retour) => {
                    const niveauAffiche = displayNiveauCodeOnly(retour.niveauCode, retour.niveauLibelle)
                    return (
                    <tr key={retour.id}>
                      <td className="font-medium">
                        <span className="inline-flex px-2 py-1 text-xs font-semibold rounded-full bg-gray-100 text-gray-800">
                          RET-{retour.id}
                        </span>
                      </td>
                      {!canManageRetours && (
                        <td className="text-sm text-gray-700 max-w-[200px] truncate" title={retour.structureLibelle || ""}>
                          {retour.structureLibelle || "—"}
                        </td>
                      )}
                      <td>
                        <span
                          className="inline-flex px-2 py-1 text-xs font-semibold rounded-full bg-blue-100 text-blue-800"
                          title={niveauAffiche}
                        >
                          {niveauAffiche}
                        </span>
                      </td>
                      <td>
                        <span className="inline-flex px-2 py-1 text-xs font-semibold rounded-full bg-purple-100 text-purple-800">
                          {retour.matiereLibelle || 'N/A'}
                        </span>
                      </td>
                      <td>
                        <span className="inline-flex px-2 py-1 text-xs font-semibold rounded-full bg-green-100 text-green-800">
                          {retour.anneeScolaireLibelle || 'N/A'}
                        </span>
                      </td>
                      <td>{retour.dateRetour || 'N/A'}</td>
                      <td className="text-center">
                        <span className="font-medium text-gray-900">{retour.quantiteDistribuee ?? "—"}</span>
                      </td>
                      <td className="text-center">
                        <span className="font-medium text-gray-900">{retour.quantiteRetournee || 0}</span>
                      </td>
                      <td>
                        <div className="flex space-x-2">
                          <button
                            onClick={() => handleShowDetails(retour)}
                            className="btn-secondary btn-sm"
                            title="Voir détails"
                            disabled={mutationBusy}
                          >
                            Détails
                          </button>
                          {canManageRetours && (
                            <>
                          <button
                            onClick={() => handleEditRetour(retour)}
                            className="text-blue-600 hover:text-blue-800 p-1 disabled:opacity-50"
                            title="Modifier"
                            disabled={mutationBusy}
                          >
                            <PencilIcon className="h-4 w-4" />
                          </button>
                          <button
                            onClick={() => handleDeleteRetour(retour.id)}
                            className="text-red-600 hover:text-red-800 p-1 disabled:opacity-50"
                            title="Supprimer"
                            disabled={mutationBusy}
                          >
                            <TrashIcon className="h-4 w-4" />
                          </button>
                            </>
                          )}
                        </div>
                      </td>
                    </tr>
                    )
                  })}
                </tbody>
              </table>
            </div>
          )}

          {/* Pagination */}
          {retours.length > 0 && (
            <PaginationControls
              currentPage={currentPage}
              totalPages={totalPages}
              pageSize={pageSize}
              totalCount={totalCount}
              onPageChange={handlePageChange}
              onPageSizeChange={handlePageSizeChange}
              loading={mutationBusy}
            />
          )}
        </div>

        {/* Modal nouvelle / modification récupération — réservé aux profils autorisés à saisir */}
        {showModal && canManageRetours && (
          <div className="modal-overlay" onClick={() => !submitting && setShowModal(false)}>
            <div className="modal-content max-w-2xl" onClick={(e) => e.stopPropagation()}>
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold">
                  {isEditing ? 'Modifier la récupération' : 'Nouvelle récupération'}
                </h3>
                <button 
                  onClick={() => setShowModal(false)} 
                  className="text-gray-400 hover:text-gray-600"
                  disabled={submitting}
                  type="button"
                >
                  <XMarkIcon className="h-6 w-6" />
                </button>
              </div>
              {!isEditing && (
                      <p className="text-xs text-blue-600 mt-1">
                        Ces récupérations seront prises en compte pour les distributions futures programmées.
                      </p>
                    )}
                    <br />
              <form onSubmit={handleSubmit} className="space-y-4">
                {/* ⚠️ Alerte si données manquantes */}
                {(matieres.length === 0 || niveaux.length === 0 || anneesScolaires.length === 0) && 
                 !matieresLoading && !niveauxLoading && !anneesLoading && (
                  <div className="bg-yellow-50 border-l-4 border-yellow-500 p-4 mb-4">
                    <div className="flex items-start">
                      <div className="flex-shrink-0">
                        <svg className="h-5 w-5 text-yellow-400" viewBox="0 0 20 20" fill="currentColor">
                          <path fillRule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
                        </svg>
                      </div>
                      <div className="ml-3">
                        <h3 className="text-sm font-medium text-yellow-800">Données de référence manquantes</h3>
                        <div className="mt-2 text-sm text-yellow-700">
                          <p>Certaines données de référence ne sont pas disponibles :</p>
                          <ul className="list-disc list-inside mt-1">
                            {matieres.length === 0 && <li>Aucune matière configurée</li>}
                            {niveaux.length === 0 && <li>Aucun niveau scolaire configuré</li>}
                            {anneesScolaires.length === 0 && <li>Aucune année scolaire configurée</li>}
                          </ul>
                          <p className="mt-2">Veuillez configurer ces données dans les paramétrages avant d&apos;enregistrer une récupération.</p>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* Année Scolaire */}
                  <div className="form-group">
                    <label className="form-label">
                      Année Scolaire <span className="text-red-500">*</span>
                    </label>
                    <select
                      value={formData.anneeScolaireId}
                      onChange={(e) => setFormData({ ...formData, anneeScolaireId: e.target.value })}
                      className="input-field"
                      required
                      disabled={anneesLoading || !isEditing}
                    >
                      <option value="">
                        {anneesLoading ? 'Chargement...' : 
                         anneesScolaires.length === 0 ? 'Aucune année disponible' :
                         'Sélectionner une année'}
                      </option>
                      {anneesScolaires.map((annee: any) => (
                        <option key={annee.id} value={annee.id}>
                          {annee.libelle}
                        </option>
                      ))}
                    </select>                    
                    {anneesScolaires.length === 0 && !anneesLoading && (
                      <p className="text-xs text-red-500 mt-1">
                        ⚠️ Aucune année scolaire disponible
                      </p>
                    )}
                  </div>

                  {/* Niveau */}
                  <div className="form-group">
                    <label className="form-label">
                      Niveau <span className="text-red-500">*</span>
                    </label>
                    <select
                      value={formData.niveauId}
                      onChange={(e) => setFormData({ ...formData, niveauId: e.target.value })}
                      className="input-field"
                      required
                      disabled={niveauxLoading}
                    >
                      <option value="">
                        {niveauxLoading ? 'Chargement...' : 
                         niveaux.length === 0 ? 'Aucun niveau disponible' :
                         'Sélectionner un niveau'}
                      </option>
                      {niveaux.map((niveau: any) => (
                        <option key={niveau.id} value={niveau.id}>
                          {displayNiveauCodeOnly(niveau.code, niveau.libelle)}
                        </option>
                      ))}
                    </select>
                    {niveaux.length === 0 && !niveauxLoading && (
                      <p className="text-xs text-red-500 mt-1">
                        ⚠️ Aucun niveau scolaire disponible
                      </p>
                    )}
                  </div>

                  {/* Matière */}
                  <div className="form-group">
                    <label className="form-label">
                      Matière <span className="text-red-500">*</span>
                    </label>
                    <select
                      value={formData.matiereId}
                      onChange={(e) => setFormData({ ...formData, matiereId: e.target.value })}
                      className="input-field"
                      required
                      disabled={matieresLoading}
                    >
                      <option value="">
                        {matieresLoading ? 'Chargement...' : 
                         matieres.length === 0 ? 'Aucune matière disponible' :
                         'Sélectionner une matière'}
                      </option>
                      {matieres.map((matiere: any) => (
                        <option key={matiere.id} value={matiere.id}>
                          {matiere.libelle}
                        </option>
                      ))}
                    </select>
                    {matieres.length === 0 && !matieresLoading && (
                      <p className="text-xs text-red-500 mt-1">
                        ⚠️ Aucune matière disponible
                      </p>
                    )}
                  </div>

                  {/* Date de récupération */}
                  <div className="form-group">
                    <label className="form-label">
                      Date de récupération <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="date"
                      value={formData.dateRetour}
                      onChange={(e) => setFormData({ ...formData, dateRetour: e.target.value })}
                      className="input-field"
                      required
                    />
                  </div>

                  {/* Quantité distribuée (référence stat) */}
                  <div className="form-group">
                    <label className="form-label">
                      Quantité distribuée <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="number"
                      min="1"
                      value={formData.quantiteDistribuee}
                      onChange={(e) => setFormData({ ...formData, quantiteDistribuee: e.target.value })}
                      className="input-field"
                      placeholder="Ex: 50"
                      required
                    />                   
                  </div>

                  {/* Quantité récupérée */}
                  <div className="form-group">
                    <label className="form-label">
                      Quantité récupérée <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="number"
                      min="1"
                      value={formData.quantiteRetournee}
                      onChange={(e) => setFormData({ ...formData, quantiteRetournee: e.target.value })}
                      className="input-field"
                      placeholder="Ex: 45"
                      required
                    />
                  </div>

                  {/* Effectif Classe (Optionnel) */}
                  {/* <div className="form-group">
                    <label className="form-label">Effectif Classe (Optionnel)</label>
                    <input
                      type="number"
                      min="0"
                      value={formData.effectifClasse}
                      onChange={(e) => setFormData({ ...formData, effectifClasse: e.target.value })}
                      className="input-field"
                      placeholder="Ex: 50"
                    />
                  </div> */}
                </div>

                {/* Commentaire */}
                <div className="form-group">
                  <label className="form-label">Observations</label>
                  <textarea
                    value={formData.commentaire}
                    onChange={(e) => setFormData({ ...formData, commentaire: e.target.value })}
                    className="input-field"
                    rows={3}
                    placeholder="Observations sur l'état général des manuels..."
                  />
                </div>

                <div className="flex justify-end space-x-3 pt-4 border-t">
                  <button 
                    type="button" 
                    onClick={() => setShowModal(false)} 
                    className="btn-outline"
                    disabled={submitting}
                  >
                    Annuler
                  </button>
                  <button 
                    type="submit" 
                    className="btn-primary"
                    disabled={submitting || matieresLoading || niveauxLoading || anneesLoading}
                  >
                    {isEditing ? 'Mettre à jour' : 'Enregistrer la récupération'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* Modal détails récupération */}
        {showDetailsModal && selectedRetour && (
          <div className="modal-overlay" onClick={() => setShowDetailsModal(false)}>
            <div className="modal-content max-w-8xl" onClick={(e) => e.stopPropagation()}>
              <div className="flex items-start justify-between border-b pb-4 mb-6">
                <div>
                  <h3 className="text-xl font-semibold text-gray-900">Détails de la récupération</h3>
                  <p className="text-sm text-gray-500 mt-1">
                    Consultation des informations enregistrées
                  </p>
                </div>
                <button
                  onClick={() => setShowDetailsModal(false)}
                  className="text-gray-400 hover:text-gray-600"
                  aria-label="Fermer"
                >
                  <XMarkIcon className="h-6 w-6" />
                </button>
              </div>

              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                  <div className="rounded-lg border bg-gray-50 p-4">
                    <p className="text-xs uppercase tracking-wide text-gray-500">Référence</p>
                    <p className="text-base font-semibold text-gray-900 mt-1">RET-{selectedRetour.id}</p>
                  </div>
                  <div className="rounded-lg border bg-blue-50 p-4">
                    <p className="text-xs uppercase tracking-wide text-blue-700">Date de récupération</p>
                    <p className="text-base font-semibold text-blue-900 mt-1">{selectedRetour.dateRetour || "N/A"}</p>
                  </div>
                  <div className="rounded-lg border bg-amber-50 p-4">
                    <p className="text-xs uppercase tracking-wide text-amber-800">Quantité distribuée</p>
                    <p className="text-base font-semibold text-amber-900 mt-1">{selectedRetour.quantiteDistribuee ?? "—"}</p>
                  </div>
                  <div className="rounded-lg border bg-green-50 p-4">
                    <p className="text-xs uppercase tracking-wide text-green-700">Quantité récupérée</p>
                    <p className="text-base font-semibold text-green-900 mt-1">{selectedRetour.quantiteRetournee || 0}</p>
                  </div>
                </div>
                {selectedRetour.quantiteDistribuee != null && selectedRetour.quantiteRetournee != null && (
                  <div className="rounded-lg border border-orange-100 bg-orange-50/80 p-4 text-sm text-orange-950">
                    <span className="font-semibold">Écart (non récupéré / à analyser) : </span>
                    {Math.max(0, selectedRetour.quantiteDistribuee - selectedRetour.quantiteRetournee)} manuel(s)
                  </div>
                )}

                <div className="rounded-xl border p-4 md:p-5">
                  <h4 className="text-sm font-semibold text-gray-800 mb-4">Informations générales</h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="form-group">
                      <label className="form-label">Structure</label>
                      <input
                        type="text"
                        className="input-field bg-gray-50"
                        value={selectedRetour.structureLibelle || "N/A"}
                        readOnly
                      />
                    </div>
                    <div className="form-group">
                      <label className="form-label">Année Scolaire</label>
                      <input
                        type="text"
                        className="input-field bg-gray-50"
                        value={selectedRetour.anneeScolaireLibelle || "N/A"}
                        readOnly
                      />
                    </div>
                    <div className="form-group">
                      <label className="form-label">Niveau</label>
                      <input
                        type="text"
                        className="input-field bg-gray-50"
                        value={displayNiveauCodeOnly(selectedRetour.niveauCode, selectedRetour.niveauLibelle)}
                        readOnly
                      />
                    </div>
                    <div className="form-group">
                      <label className="form-label">Matière</label>
                      <input
                        type="text"
                        className="input-field bg-gray-50"
                        value={selectedRetour.matiereLibelle || "N/A"}
                        readOnly
                      />
                    </div>
                    <div className="form-group">
                      <label className="form-label">Date de récupération</label>
                      <input
                        type="text"
                        className="input-field bg-gray-50"
                        value={selectedRetour.dateRetour || "N/A"}
                        readOnly
                      />
                    </div>
                    {/* <div className="form-group">
                      <label className="form-label">Effectif Classe</label>
                      <input
                        type="text"
                        className="input-field bg-gray-50"
                        value={selectedRetour.effectifClasse ?? "N/A"}
                        readOnly
                      />
                    </div> */}
                  </div>
                </div>

                <div className="rounded-xl border p-4 md:p-5">
                  <h4 className="text-sm font-semibold text-gray-800 mb-3">Observations</h4>
                  <textarea
                    className="input-field bg-gray-50"
                    rows={4}
                    value={selectedRetour.commentaire || "Aucune observation renseignée."}
                    readOnly
                  />
                </div>
              </div>

              <div className="flex justify-end space-x-3 mt-6 pt-4 border-t">
                <button
                  onClick={() => setShowDetailsModal(false)}
                  className="btn-outline"
                  disabled={mutationBusy}
                  type="button"
                >
                  Fermer
                </button>
                <button
                  onClick={() => {
                    setShowDetailsModal(false)
                    handleEditRetour(selectedRetour)
                  }}
                  className="btn-primary"
                  disabled={mutationBusy}
                  type="button"
                >
                  Modifier
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </MainLayout>
  )
}
