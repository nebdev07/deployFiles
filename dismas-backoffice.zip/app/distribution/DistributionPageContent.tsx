"use client"

import React, { useState, useEffect, useMemo } from "react"
import ConfirmationEPPModal from "../../components/modals/ConfirmationEPPModal"
import ValidationIEPPModal from "../../components/modals/ValidationIEPPModal"
import DistributionForm from "../../components/forms/DistributionForm"
import { distributionService, DistributionData } from "../../lib/services/distribution.service"
import { receptionService, type ReceptionFileData } from "../../lib/services/reception.service"
import { catalogueService } from "../../lib/services/catalogue.service"
import PaginationControls from "../../components/ui/pagination-controls"
import {
  PlusIcon,
  TruckIcon,
  AcademicCapIcon,
  CalendarIcon,
  CheckCircleIcon,
  ClockIcon,
  XCircleIcon,
  CheckIcon,
  BookOpenIcon,
  EyeIcon,
} from "@heroicons/react/24/outline"
import toast from "react-hot-toast"
import { DistributionPageBody, type DistributionPageCtx } from "./DistributionPageBody"

// Types pour les distributions réelles basés sur la réponse du backend
interface DistributionItem {
  id: number;
  anneeScolaireCode?: string;
  anneeScolaireId?: number;
  anneeScolaireLibelle?: string;
  classe?: string;
  commentaire?: string;
  dateDistribution?: string;
  distribuePar?: number;
  effectifFilles?: number;
  effectifGarcons?: number;
  niveauCode?: string;
  niveauId?: number;
  niveauLibelle?: string;
  structureCode?: string;
  structureId?: number;
  structureLibelle?: string;
  structureType?: string;
  
  // ✅ NOUVEAUX CHAMPS POUR L'AFFICHAGE OPTIMISÉ
  totalManuelsDistribues?: number;
  statutDistribution?: string;
  
  // Propriétés legacy pour compatibilité
  reference?: string;
  structure?: {
    code: string;
    libelle: string;
    type: string;
  };
  niveau?: {
    id: number;
    libelle: string;
    code: string;
  };
  effectif_garcons?: number;
  effectif_filles?: number;
  effectif_total?: number;
  nombre_eleves?: number;
  date_distribution?: string;
  distribue_par?: string;
  statut?: string;
  manuels?: Array<{
    titre: string;
    quantite_prevue: number;
    quantite_distribuee: number;
  }>;
  matiereQuantites?: Array<{
    id: number;
    matiereLibelle?: string;
    matiere?: {
      libelle: string;
    };
    quantite?: number;
    quantiteDistribuee?: number;
  }>;
}

export function DistributionPageContent({ user }: { user: any }) {
  const [selectedDistribution, setSelectedDistribution] = useState<any>(null)
  const [showModal, setShowModal] = useState(false)
  const [isEditingDistribution, setIsEditingDistribution] = useState(false) // ✅ NOUVEAU : Mode édition
  const [editingDistributionData, setEditingDistributionData] = useState<any>(null) // ✅ NOUVEAU : Données en cours d'édition
  const [editGroupCatalogues, setEditGroupCatalogues] = useState<any[]>([])
  const [selectedEditGroupCatalogueId, setSelectedEditGroupCatalogueId] = useState<string>("")
  const [removedExistingGroupItems, setRemovedExistingGroupItems] = useState<any[]>([])
  const [uploadingFile, setUploadingFile] = useState(false) // ✅ NOUVEAU : État upload fichier
  const [distributionFiles, setDistributionFiles] = useState<any[]>([]) // ✅ NOUVEAU : Fichiers de la distribution
  const [showDistributionForm, setShowDistributionForm] = useState(false)
  const [showConfirmationModal, setShowConfirmationModal] = useState(false)
  const [confirmationNiveau, setConfirmationNiveau] = useState<'EPP' | 'IEPP'>('EPP')
  const [isCreatingDistribution, setIsCreatingDistribution] = useState(false)
  
  // ✅ NOUVEAU : États pour validation IEPP
  const [activeTab, setActiveTab] = useState<'distributions' | 'validations'>('distributions')
  /** Sous-onglet IEPP : file d'attente vs historique validé/rejeté */
  const [ieppValidationSubTab, setIeppValidationSubTab] = useState<'pending' | 'history'>('pending')
  const [receptionsEnAttente, setReceptionsEnAttente] = useState<any[]>([])
  const [receptionsHistorique, setReceptionsHistorique] = useState<any[]>([])
  const [loadingReceptionsHistorique, setLoadingReceptionsHistorique] = useState(false)
  const [receptionFilesForDetails, setReceptionFilesForDetails] = useState<ReceptionFileData[]>([])
  const [selectedReceptionForValidation, setSelectedReceptionForValidation] = useState<any>(null)
  const [showValidationModal, setShowValidationModal] = useState(false)
  const [loadingReceptions, setLoadingReceptions] = useState(false)
  const [selectedReceptionIds, setSelectedReceptionIds] = useState<number[]>([])
  const [isBulkValidating, setIsBulkValidating] = useState(false)
  
  // ✅ NOUVEAU : États pour modal détails réception
  const [selectedReceptionForDetails, setSelectedReceptionForDetails] = useState<any>(null)
  const [showReceptionDetailsModal, setShowReceptionDetailsModal] = useState(false)
  const [loadingDetails, setLoadingDetails] = useState(false)
  
  // ✅ SÉCURITÉ : État pour le statut de réception EPP validée IEPP
  const [receptionStatut, setReceptionStatut] = useState<string | null>(null)
  
  // États pour les données réelles
  const [distributions, setDistributions] = useState<DistributionItem[]>([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  // États pour la pagination
  const [currentPage, setCurrentPage] = useState(1)
  const [pageSize, setPageSize] = useState(10)
  const [totalCount, setTotalCount] = useState(0)
  const [totalPages, setTotalPages] = useState(0)

  // Chargement des données au montage et lors des changements de pagination
  useEffect(() => {
    if (user) {
      loadDistributions();
    }
  }, [currentPage, pageSize, user]);

  // ✅ Chargement des réceptions en attente ou historique pour IEPP
  useEffect(() => {
    if (user?.role.code !== "IEPP" || activeTab !== "validations") return;
    if (ieppValidationSubTab === "pending") {
      loadReceptionsEnAttente();
    } else {
      loadReceptionsHistorique();
    }
  }, [activeTab, ieppValidationSubTab, user]);

  /**
   * Charge les distributions depuis le backend avec pagination
   */
  const loadDistributions = async () => {
    setLoading(true);
    setError(null);

    try {
      console.log(`📊 Chargement des distributions - Page ${currentPage}, Taille ${pageSize}`);

      // Utiliser la nouvelle méthode avec pagination
      const response = await distributionService.getDistributionsPaginated(currentPage, pageSize);
      
      if (response.success && response.data) {
        setDistributions(response.data);
        
        // Mettre à jour les métadonnées de pagination si disponibles
        if ((response as any).pagination) {
          setTotalCount((response as any).pagination.totalCount);
          setTotalPages((response as any).pagination.totalPages);
        }
        
        console.log('✅ Distributions chargées:', response.data.length);
      } else {
        setDistributions([]);
        setTotalCount(0);
        setTotalPages(0);
        console.log('⚠️ Aucune distribution disponible');
      }
    } catch (error: any) {
      console.error('❌ Erreur lors du chargement des distributions:', error);
      setError(error.message);
      // En cas d'erreur, on utilise des données vides
      setDistributions([]);
    } finally {
      setLoading(false);
    }
  }

  /**
   * ✅ NOUVEAU : Charge les réceptions EPP en attente de validation IEPP
   */
  const loadReceptionsEnAttente = async () => {
    setLoadingReceptions(true);
    try {
      console.log('📋 Chargement des réceptions EPP en attente de validation IEPP...');
      
      const response = await receptionService.getReceptionsEPPEnAttenteIEPP(user?.structure?.id);
      
      if (response.success && response.data) {
        setReceptionsEnAttente(response.data);
        setSelectedReceptionIds([]);
        console.log(`✅ ${response.data.length} réceptions EPP en attente trouvées`);
      } else {
        setReceptionsEnAttente([]);
        setSelectedReceptionIds([]);
        console.log('⚠️ Aucune réception en attente');
      }
    } catch (error: any) {
      console.error('❌ Erreur chargement réceptions en attente:', error);
      setReceptionsEnAttente([]);
      setSelectedReceptionIds([]);
      toast.error('Erreur lors du chargement des réceptions en attente');
    } finally {
      setLoadingReceptions(false);
    }
  }

  const loadReceptionsHistorique = async () => {
    setLoadingReceptionsHistorique(true);
    try {
      const response = await receptionService.getReceptionsEPPHistoriqueIEPP(user?.structure?.id);
      if (response.success && response.data) {
        setReceptionsHistorique(response.data);
      } else {
        setReceptionsHistorique([]);
        if (response.message) {
          toast.error(response.message);
        }
      }
    } catch (e) {
      console.error(e);
      setReceptionsHistorique([]);
      toast.error("Erreur lors du chargement de l'historique des réceptions");
    } finally {
      setLoadingReceptionsHistorique(false);
    }
  };

  /**
   * ✅ NOUVEAU : Gère l'ouverture du modal de validation avec chargement des détails
   * 
   * Cette fonction charge d'abord les détails complets de la réception (catalogues, manuels)
   * avant d'ouvrir le modal de validation pour éviter l'affichage "Aucune matière trouvée"
   */
  const handleOpenValidationModal = async (reception: any) => {
    try {
      setLoadingDetails(true);
      console.log('🔍 Chargement détails réception pour validation ID:', reception.id);
      
      const detailsResponse = await receptionService.getReceptionDetails(reception.id);
      
      if (detailsResponse.success && detailsResponse.data) {
        const receptionDetails = detailsResponse.data;
        console.log('✅ Détails réception récupérés pour validation:', receptionDetails);
        
        // Construire l'objet complet pour le modal de validation
        const completeReception = {
          ...reception, // Infos de base du tableau
          ...receptionDetails, // Détails complets du backend (Mouvement avec relations)
          catalogueMouvements: receptionDetails.catalogueMouvements || [], // Liste des manuels
          matiereQuantites: receptionDetails.matiereQuantites || [] // Liste des matières si disponible
        };
        
        setSelectedReceptionForValidation(completeReception);
        setShowValidationModal(true);
      } else {
        toast.error('Erreur lors du chargement des détails: ' + detailsResponse.message);
      }
    } catch (error) {
      console.error('❌ Erreur chargement détails pour validation:', error);
      toast.error('Erreur lors du chargement des détails');
    } finally {
      setLoadingDetails(false);
    }
  };

  /**
   * ✅ Callback après validation réussie d'une réception EPP par IEPP
   */
  const handleValidateReception = () => {
    loadReceptionsEnAttente();
    loadReceptionsHistorique();
    toast.success('✅ Réception validée ! Stocks mis à jour.')
  }

  const handleToggleReceptionSelection = (receptionId: number) => {
    setSelectedReceptionIds((prev) =>
      prev.includes(receptionId) ? prev.filter((id) => id !== receptionId) : [...prev, receptionId]
    );
  };

  const handleToggleSelectAllReceptions = () => {
    if (selectedReceptionIds.length === receptionsEnAttente.length) {
      setSelectedReceptionIds([]);
      return;
    }
    setSelectedReceptionIds(receptionsEnAttente.map((r: any) => r.id));
  };

  const handleBulkValidateReceptions = async () => {
    if (isBulkValidating) return;
    if (selectedReceptionIds.length === 0) {
      toast.error("Aucune réception sélectionnée.");
      return;
    }

    const ok = window.confirm(
      `Valider ${selectedReceptionIds.length} réception(s) sélectionnée(s) ?`
    );
    if (!ok) return;

    setIsBulkValidating(true);
    try {
      // Séquentiel obligatoire : chaque validation met à jour les mêmes lignes StockDisponible (IEPP).
      // En parallèle (Promise.all), MySQL peut lever un deadlock et une transaction est annulée :
      // une EPP reçoit le stock, l'autre non, le stock IEPP reste incohérent.
      const results: { id: number; success: boolean; message: string }[] = [];
      for (const id of selectedReceptionIds) {
        const response = await receptionService.validateReception(id, "IEPP");
        results.push({ id, success: response.success, message: response.message });
      }

      const successCount = results.filter((r) => r.success).length;
      const failed = results.filter((r) => !r.success);

      if (successCount > 0) {
        toast.success(`${successCount} réception(s) validée(s) avec succès.`);
      }
      if (failed.length > 0) {
        const details = failed.slice(0, 3).map((f) => `#${f.id}: ${f.message}`).join(" | ");
        toast.error(
          `${failed.length} échec(s) de validation.${details ? ` (${details})` : ""}`
        );
      }

      await loadReceptionsEnAttente();
      await loadReceptionsHistorique();
    } catch (error) {
      console.error("❌ Erreur validation groupée:", error);
      toast.error("Erreur lors de la validation groupée.");
    } finally {
      setIsBulkValidating(false);
    }
  };

  // Callback après rejet IEPP d'une réception EPP
  const handleRejectReception = () => {
    loadReceptionsEnAttente();
    loadReceptionsHistorique();
    toast.success("✅ Réception rejetée et renvoyée en brouillon.")
  }

  // Rejet direct depuis la liste IEPP (bouton visible sans ouvrir la modal)
  const handleRejectReceptionFromList = async (reception: any) => {
    try {
      const motif = window.prompt("Motif du rejet (obligatoire) :")
      if (!motif || !motif.trim()) {
        toast.error("Le motif de rejet est obligatoire.")
        return
      }

      const ok = window.confirm("Confirmer le rejet de cette réception ? Elle sera renvoyée en brouillon pour l'EPP.")
      if (!ok) return

      const response = await receptionService.rejectReception(reception.id, motif.trim())
      if (response.success) {
        loadReceptionsEnAttente()
        loadReceptionsHistorique()
        toast.success("✅ Réception rejetée et renvoyée en brouillon.")
      } else {
        toast.error(response.message || "Erreur lors du rejet")
      }
    } catch (error: any) {
      console.error("❌ Erreur rejet depuis liste:", error)
      toast.error("Erreur lors du rejet")
    }
  }

  /**
   * Gère le changement de page
   */
  const handlePageChange = (page: number) => {
    setCurrentPage(page);
  };

  /**
   * Gère le changement de taille de page
   */
  const handlePageSizeChange = (size: number) => {
    setPageSize(size);
    setCurrentPage(1); // Retourner à la première page
  };

  const closeDistributionModal = () => {
    setShowModal(false);
    setDistributionFiles([]);
    setSelectedDistribution(null);
    setIsEditingDistribution(false);
  };

  const handleDownloadDistributionFile = async (fileId: number, fileName: string) => {
    const res = await distributionService.downloadDistributionFile(fileId);
    if (res.success && res.data) {
      const url = URL.createObjectURL(res.data);
      const a = document.createElement("a");
      a.href = url;
      a.download = fileName || "piece-jointe";
      a.click();
      URL.revokeObjectURL(url);
    } else {
      toast.error(res.message || "Téléchargement impossible");
    }
  };

  /**
   * Finalise une distribution (met à jour les effectifs, commentaire, upload fichier)
   */
  const handleFinalizeDistribution = async () => {
    if (!selectedDistribution) return;

    try {
      setLoadingDetails(true);

      const currentStatut = (selectedDistribution.statut || "").trim();
      if (currentStatut !== "EN_ATTENTE_VALIDATION_EPP") {
        toast.error(`Finalisation non autorisée pour le statut actuel: ${currentStatut || "N/A"}`);
        return;
      }

      const effectifGarcons = Number(editingDistributionData?.effectifGarcons ?? 0);
      const effectifFilles = Number(editingDistributionData?.effectifFilles ?? 0);
      if (effectifGarcons < 0 || effectifFilles < 0 || effectifGarcons + effectifFilles <= 0) {
        toast.error("Renseignez un effectif valide (garçons/filles) avant finalisation.");
        return;
      }

      const confirmFinalize = window.confirm(
        "Confirmer la finalisation de cette distribution ?\nCette action passera le statut à DISTRIBUE."
      );
      if (!confirmFinalize) return;

      // Mettre à jour la distribution
      const updateResponse = await distributionService.updateDistributionForFinalization(
        selectedDistribution.id,
        {
          effectifGarcons,
          effectifFilles,
          commentaire: (editingDistributionData?.commentaire || "").trim(),
          statut: "DISTRIBUE"
        }
      );

      if (updateResponse.success) {
        toast.success('Distribution finalisée avec succès !');
        setIsEditingDistribution(false);
        // Recharger les distributions pour mettre à jour le statut
        await loadDistributions();
        closeDistributionModal();
      } else {
        toast.error(updateResponse.message || 'Erreur lors de la finalisation');
      }
    } catch (error: any) {
      console.error('❌ Erreur lors de la finalisation:', error);
      toast.error('Erreur lors de la finalisation de la distribution');
    } finally {
      setLoadingDetails(false);
    }
  };

  /**
   * Upload un fichier (fiche d'émargement) pour une distribution
   */
  const handleFileUpload = async (file: File) => {
    if (!selectedDistribution) return;
    const sid = (selectedDistribution as any).id;
    if (sid == null) {
      toast.error("Sélectionnez une distribution unique pour joindre un fichier.");
      return;
    }

    try {
      setUploadingFile(true);

      const uploadResponse = await distributionService.uploadDistributionFile(
        sid,
        file,
        'FICHE_EMARGEMENT'
      );

      if (uploadResponse.success) {
        toast.success('Fichier uploadé avec succès !');
        // Recharger les fichiers
        const filesResponse = await distributionService.getDistributionFiles(sid);
        if (filesResponse.success && filesResponse.data) {
          setDistributionFiles(filesResponse.data);
        }
      } else {
        toast.error(uploadResponse.message || 'Erreur lors de l\'upload du fichier');
      }
    } catch (error: any) {
      console.error('❌ Erreur lors de l\'upload:', error);
      toast.error('Erreur lors de l\'upload du fichier');
    } finally {
      setUploadingFile(false);
    }
  };

  /**
   * Génère le résumé des matières pour une distribution
   */
  const getDistributionSummary = (distribution: any) => {
    if (distribution.matiereQuantites && distribution.matiereQuantites.length > 0) {
      return distribution.matiereQuantites.map((mq: any) => 
        `${mq.matiereLibelle || mq.matiere?.libelle || 'Matière'}: ${mq.quantiteDistribuee || mq.quantiteRecue || mq.quantite || 0}`
      ).join(' | ');
    }
    
    // Données de démonstration si pas de données réelles
    return 'Mathématiques: 25 | Français: 20 | Sciences: 15';
  };

  /**
   * Actualise les distributions
   */
  const refreshDistributions = () => {
    loadDistributions();
  };

  /**
   * Gère l'affichage des détails d'une réception
   */
  const handleShowReceptionDetails = async (reception: any) => {
    try {
      setLoadingDetails(true);
      setReceptionFilesForDetails([]);
      const [detailsResponse, filesResponse] = await Promise.all([
        receptionService.getReceptionDetails(reception.id),
        receptionService.getReceptionFiles(reception.id),
      ]);

      if (detailsResponse.success && detailsResponse.data) {
        const receptionDetails = detailsResponse.data;
        const completeReception = {
          ...reception,
          ...receptionDetails,
          catalogueMouvements: receptionDetails.catalogueMouvements || [],
        };
        setSelectedReceptionForDetails(completeReception);
        setReceptionFilesForDetails(filesResponse.success && filesResponse.data ? filesResponse.data : []);
        setShowReceptionDetailsModal(true);
      } else {
        toast.error("Erreur lors du chargement des détails: " + detailsResponse.message);
      }
    } catch (error) {
      console.error("❌ Erreur chargement détails:", error);
      toast.error("Erreur lors du chargement des détails");
    } finally {
      setLoadingDetails(false);
    }
  };

  const handleDownloadReceptionFile = async (fileId: number, fileName: string) => {
    const res = await receptionService.downloadReceptionFile(fileId);
    if (res.success && res.data) {
      const url = URL.createObjectURL(res.data);
      const a = document.createElement("a");
      a.href = url;
      a.download = fileName || "piece-jointe";
      a.click();
      URL.revokeObjectURL(url);
    } else {
      toast.error(res.message || "Téléchargement impossible");
    }
  };

  const closeReceptionDetailsModal = () => {
    setShowReceptionDetailsModal(false);
    setReceptionFilesForDetails([]);
  };

  /**
   * Regroupe les distributions par même date, année scolaire et structure (une ligne = une "distribution" logique).
   */
  const groupedDistributions = useMemo(() => {
    const map = new Map<string, {
      dateDistribution: string;
      anneeScolaireLibelle: string;
      structureId: number;
      structureLibelle: string;
      items: DistributionItem[];
      totalManuels: number;
      totalEleves: number;
      niveauxCount: number;
      statut: string;
      hasComplementaire: boolean;
    }>();
    for (const d of distributions) {
      const dateStr = (d.dateDistribution || (d as any).date_distribution)
        ? new Date((d.dateDistribution || (d as any).date_distribution) as string).toISOString().slice(0, 10)
        : "";
      const key = `${d.structureId ?? 0}_${d.anneeScolaireId ?? 0}_${dateStr}`;
      if (!map.has(key)) {
        map.set(key, {
          dateDistribution: (d.dateDistribution || (d as any).date_distribution) as string,
          anneeScolaireLibelle: d.anneeScolaireLibelle || "N/A",
          structureId: d.structureId ?? 0,
          structureLibelle: (d.structureLibelle || (d.structure as any)?.libelle) ?? "N/A",
          items: [],
          totalManuels: 0,
          totalEleves: 0,
          niveauxCount: 0,
          statut: (d as any).statut || (d as any).statutDistribution || "N/A",
          hasComplementaire: false,
        });
      }
      const g = map.get(key)!;
      g.items.push(d);
      if ((d as any).complementaire === true) {
        g.hasComplementaire = true;
      }
      const mq = (d as any).matiereQuantites || [];
      const sum = mq.reduce((s: number, m: any) => s + (m.quantiteRecue ?? m.quantite ?? 0), 0);
      g.totalManuels += sum > 0 ? sum : ((d as any).totalManuelsDistribues ?? 0);
      g.totalEleves += ((d.effectifGarcons ?? 0) + (d.effectifFilles ?? 0));
      g.niveauxCount = g.items.length;
    }
    return Array.from(map.values());
  }, [distributions]);

  /**
   * Ouvre le modal Détails pour un groupe de distributions (même date / année / EPP).
   */
  const handleShowDistributionGroupDetails = async (group: {
    dateDistribution: string;
    anneeScolaireLibelle: string;
    structureLibelle: string;
    statut: string;
    items: any[];
  }) => {
    try {
      setLoadingDetails(true);
      setDistributionFiles([]);
      const detailsResponses = await Promise.all(
        group.items.map((it: any) => distributionService.getDistributionDetails(it.id))
      );
      const itemsWithDetails = detailsResponses
        .map((r, i) => {
          if (!r.success || !r.data) return null;
          const item = group.items[i];
          const data = r.data as any;
          const mq = data.matiereQuantites || data.matiereQuantitesDtos || (item as any).matiereQuantites || [];
          return { ...item, ...data, matiereQuantites: mq };
        })
        .filter(Boolean) as any[];

      const fileLists = await Promise.all(
        itemsWithDetails.map(async (it) => {
          const id = it.id as number | undefined;
          if (id == null) return [] as any[];
          const fr = await distributionService.getDistributionFiles(id);
          const rows = fr.success && fr.data ? fr.data : [];
          const niveauLibelle = it.niveauLibelle || it.niveauCode || `Distribution #${id}`;
          return rows.map((f: any) => ({
            ...f,
            _distributionId: id,
            _niveauLibelle: niveauLibelle,
          }));
        })
      );
      setDistributionFiles(fileLists.flat());

      const builtGroup = {
        isGroup: true,
        dateDistribution: group.dateDistribution,
        anneeScolaireLibelle: group.anneeScolaireLibelle,
        structureLibelle: group.structureLibelle,
        statut: group.statut,
        items: itemsWithDetails,
      };
      setSelectedDistribution(builtGroup);
      // Mode détails = lecture seule
      setIsEditingDistribution(false);
      setShowModal(true);
      return builtGroup;
    } catch (err) {
      console.error("Erreur chargement détails groupe:", err);
      toast.error("Erreur lors du chargement des détails");
      return null;
    } finally {
      setLoadingDetails(false);
    }
  };

  /**
   * ✅ NOUVEAU : Gère l'affichage des détails d'une distribution
   *
   * Cette fonction est appelée lorsque l'utilisateur clique sur "Détails" dans le tableau des distributions.
   * Elle récupère les détails complets de la distribution (avec les matières) via `distributionService.getDistributionDetails`.
   * Cela permet d'afficher les vraies données BD dans le modal et pas uniquement les données résumées de la ligne.
   */
  const handleShowDistributionDetails = async (distribution: any) => {
    try {
      setLoadingDetails(true);
      setDistributionFiles([]);
      console.log('🔍 Chargement détails distribution ID:', distribution.id);

      const detailsResponse = await distributionService.getDistributionDetails(distribution.id);

      if (detailsResponse.success && detailsResponse.data) {
        const distributionDetails = detailsResponse.data;
        console.log('✅ Détails distribution récupérés:', distributionDetails);

        // Normaliser la liste des matières distribuées
        const matiereQuantites =
          distributionDetails.matiereQuantites ||
          (distributionDetails as any).matiereQuantitesDtos ||
          distribution.matiereQuantites ||
          [];

        // Construire l'objet complet pour le modal
        const completeDistribution = {
          ...distribution,          // Infos de base du tableau (structure, classe, etc.)
          ...distributionDetails,   // Détails complets renvoyés par le backend
          matiereQuantites          // Liste normalisée des matières distribuées
        };

        setSelectedDistribution(completeDistribution);
        setEditingDistributionData({
          effectifGarcons: completeDistribution.effectifGarcons || 0,
          effectifFilles: completeDistribution.effectifFilles || 0,
          commentaire: completeDistribution.commentaire || ''
        });
        // Mode détails = lecture seule. L'édition se fait via le bouton "Modifier".
        setIsEditingDistribution(false);
        
        // ✅ Charger les fichiers de la distribution
        try {
          const filesResponse = await distributionService.getDistributionFiles(distribution.id);
          if (filesResponse.success && filesResponse.data) {
            setDistributionFiles(filesResponse.data);
            console.log('✅ Fichiers récupérés:', filesResponse.data);
          } else {
            console.log('⚠️ Aucun fichier trouvé ou erreur:', filesResponse.message);
            setDistributionFiles([]);
          }
        } catch (error) {
          console.error('❌ Erreur lors du chargement des fichiers:', error);
          setDistributionFiles([]);
        }
        
        setShowModal(true);
      } else {
        toast.error('Erreur lors du chargement des détails distribution: ' + detailsResponse.message);
      }
    } catch (error) {
      console.error('❌ Erreur chargement détails distribution:', error);
      toast.error('Erreur lors du chargement des détails distribution');
    } finally {
      setLoadingDetails(false);
    }
  };

  /**
   * Ouvre le formulaire de distribution.
   * La validation métier bloquante est réalisée côté backend sur le stock disponible réel.
   */
  const handleNouvelleDistribution = async () => {
    try {
      console.log('📝 Ouverture formulaire de distribution (validation stock côté backend).');
      setReceptionStatut('N/A');
      setShowDistributionForm(true);
    } catch (error) {
      console.error('❌ Erreur lors de l’ouverture du formulaire de distribution:', error);
      toast.error(
        'Erreur lors de l’ouverture du formulaire.\n' +
        'Veuillez réessayer ou contacter le support.',
        { duration: 5000 }
      );
    }
  };

  const getStatusIcon = (statut: string) => {
    switch (statut) {
      case "TERMINEE":
        return <CheckCircleIcon className="h-5 w-5 text-green-600" />
      case "EN_COURS":
        return <ClockIcon className="h-5 w-5 text-yellow-600" />
      case "PLANIFIEE":
        return <CalendarIcon className="h-5 w-5 text-blue-600" />
      case "ANNULEE":
        return <XCircleIcon className="h-5 w-5 text-red-600" />
      default:
        return <ClockIcon className="h-5 w-5 text-gray-600" />
    }
  }

  const getStatusBadge = (statut: string) => {
    switch (statut) {
      case "TERMINEE":
        return "badge-success"
      case "EN_COURS":
        return "badge-warning"
      case "PLANIFIEE":
        return "badge-info"
      case "ANNULEE":
        return "badge-error"
      default:
        return "badge-info"
    }
  }

  /**
   * Gère la soumission du formulaire de distribution avec validation de stock.
   * Accepte une seule distribution ou un tableau (une par catalogue, effectifs par catalogue).
   */
  const handleDistributionSubmit = async (payload: DistributionData | DistributionData[]) => {
    setIsCreatingDistribution(true);
    const payloads: DistributionData[] = Array.isArray(payload) ? payload : [payload];

    try {
      console.log('🚀 Soumission distribution(s) avec validation de stock:', payloads.length, payloads);

      let firstCreatedId: number | null = null;
      let createdCount = 0;

      for (let i = 0; i < payloads.length; i++) {
        const distributionData = payloads[i];
        const fichiers = (distributionData as any).fichiers || [];
        const distributionDataWithoutFiles = { ...distributionData, fichiers: undefined };

        const response = await distributionService.createDistributionWithStockValidation(distributionDataWithoutFiles);

        if (!response.success) {
          const errorMessage = response.message || 'Erreur inconnue lors de la création de la distribution';
          toast.error(errorMessage, {
            duration: 6000,
            style: {
              background: '#fee2e2',
              color: '#dc2626',
              border: '1px solid #fecaca',
              fontSize: '14px',
              maxWidth: '500px'
            }
          });
          console.error('❌ Erreur création distribution:', response.message);
          return;
        }

        const createdDistributionId = response.data?.id;
        if (createdDistributionId) {
          createdCount++;
          if (firstCreatedId == null) firstCreatedId = createdDistributionId;
        }

        // Même pièces jointes sur chaque distribution créée (un niveau / catalogue = une ligne distribution_eleve)
        if (fichiers.length > 0 && createdDistributionId) {
          for (const file of fichiers) {
            try {
              const fileExtension = file.name.split('.').pop()?.toLowerCase();
              let fileType: 'FICHE_EMARGEMENT' | 'DOCUMENT' | 'PHOTO' = 'DOCUMENT';
              if (fileExtension === 'pdf' || fileExtension === 'doc' || fileExtension === 'docx') fileType = 'FICHE_EMARGEMENT';
              else if (['jpg', 'jpeg', 'png'].includes(fileExtension || '')) fileType = 'PHOTO';
              const up = await distributionService.uploadDistributionFile(createdDistributionId, file, fileType);
              if (!up.success) {
                console.warn("Upload fichier:", file.name, up.message);
                toast.error(`Échec envoi fichier : ${file.name}${up.message ? ` — ${up.message}` : ""}`);
              }
            } catch (err: unknown) {
              console.warn(err);
              toast.error(`Erreur envoi fichier : ${file.name}`);
            }
          }
        }
      }

      toast.success(createdCount > 1 ? `${createdCount} distributions créées avec succès !` : 'Distribution créée avec succès !');
      setShowDistributionForm(false);
      await refreshDistributions();
    } catch (error: any) {
      console.error('❌ Erreur lors de la soumission:', error);
      toast.error('Erreur lors de la création de la distribution');
    } finally {
      setIsCreatingDistribution(false);
    }
  };

  /**
   * Annule la création de distribution
   */
  const handleDistributionCancel = () => {
    setShowDistributionForm(false);
  };

  const handleFinalizeDistributionGroup = async (group: any) => {
    if (!group?.items || group.items.length === 0) return;

    try {
      setLoadingDetails(true);
      const pendingItems = group.items.filter((it: any) => (it.statut || "").trim() === "EN_ATTENTE_VALIDATION_EPP");
      if (pendingItems.length === 0) {
        toast.error("Aucune distribution finalisable dans ce groupe.");
        return;
      }

      const invalidItems = pendingItems.filter((it: any) => {
        const g = Number(it.effectifGarcons ?? 0);
        const f = Number(it.effectifFilles ?? 0);
        return g < 0 || f < 0 || (g + f) <= 0;
      });
      if (invalidItems.length > 0) {
        toast.error(
          `Finalisation bloquée: ${invalidItems.length} niveau(x) incomplet(s) (effectifs invalides). Ouvrez les détails pour compléter.`
        );
        return;
      }

      const confirmFinalize = window.confirm(
        `Confirmer la finalisation de ${pendingItems.length} niveau(x) ?\nCette action passera le statut à DISTRIBUE.`
      );
      if (!confirmFinalize) return;

      const results: Array<{ id: number; success: boolean; message: string }> = [];
      for (const it of pendingItems) {
        const resp = await distributionService.updateDistributionForFinalization(it.id, {
          effectifGarcons: Number(it.effectifGarcons ?? 0),
          effectifFilles: Number(it.effectifFilles ?? 0),
          commentaire: (it.commentaire || "").trim(),
          statut: "DISTRIBUE",
        });
        results.push({ id: it.id, success: resp.success, message: resp.message });
      }

      const successCount = results.filter((r) => r.success).length;
      const failCount = results.length - successCount;
      if (successCount > 0) toast.success(`${successCount} distribution(s) finalisée(s).`);
      if (failCount > 0) toast.error(`${failCount} distribution(s) non finalisée(s).`);

      await loadDistributions();
      if (successCount > 0 && failCount === 0) {
        closeDistributionModal();
      }
    } catch (error) {
      console.error("❌ Erreur finalisation groupée:", error);
      toast.error("Erreur lors de la finalisation groupée.");
    } finally {
      setLoadingDetails(false);
    }
  };

  const handleSaveDistributionGroupEdits = async () => {
    if (!selectedDistribution || !(selectedDistribution as any).isGroup) return;
    const groupItems = (selectedDistribution as any).items || [];
    const editableItems = groupItems.filter((it: any) => (it.statut || "").trim() === "EN_ATTENTE_VALIDATION_EPP");
    if (editableItems.length === 0) {
      toast.error("Aucune distribution modifiable dans ce groupe.");
      return;
    }

    try {
      setLoadingDetails(true);
      const existingItems = editableItems.filter((it: any) => !it.__isNew && it.id);
      const newItems = editableItems.filter((it: any) => it.__isNew);

      const updateResults: Array<{ id: any; success: boolean; message: string }> = [];
      for (const it of existingItems) {
          const matiereQuantites = ((it.matiereQuantites || []) as any[])
            .map((mq: any) => ({
              idMatiere: Number(mq.idMatiere ?? mq.matiereId ?? mq.id),
              matiereCode: mq.matiereCode ?? "",
              quantiteRecue: Number(mq.quantiteRecue ?? mq.quantite ?? 0),
            }))
            .filter((mq: any) => Number.isFinite(mq.idMatiere) && mq.idMatiere > 0);

          const resp = await distributionService.updateDistributionForFinalization(it.id, {
            effectifGarcons: Number(it.effectifGarcons ?? 0),
            effectifFilles: Number(it.effectifFilles ?? 0),
            commentaire: (it.commentaire || "").trim(),
            matiereQuantites,
          });
          updateResults.push({ id: it.id, success: resp.success, message: resp.message });
      }

      const baseItem = groupItems.find((it: any) => !it.__isNew) || {};
      const createResults: Array<{ id: any; success: boolean; message: string }> = [];
      for (let idx = 0; idx < newItems.length; idx++) {
          const it: any = newItems[idx];
          const matiereQuantites = ((it.matiereQuantites || []) as any[])
            .map((mq: any) => ({
              matiereId: Number(mq.idMatiere ?? mq.matiereId ?? mq.id),
              matiereCode: mq.matiereCode ?? "",
              quantite: Number(mq.quantiteRecue ?? mq.quantite ?? 0),
            }))
            .filter((mq: any) => Number.isFinite(mq.matiereId) && mq.matiereId > 0 && mq.quantite > 0);

          const effectifGarcons = Number(it.effectifGarcons ?? 0);
          const effectifFilles = Number(it.effectifFilles ?? 0);
          if (effectifGarcons + effectifFilles <= 0) {
            createResults.push({ id: `new-${idx}`, success: false, message: "Effectif invalide pour le nouveau niveau." });
            continue;
          }

          const currentUserId = Number(user?.id || 1);
          const payload: DistributionData = {
            eppId: Number(baseItem.structureId ?? user?.structure?.id ?? 0),
            userId: currentUserId,
            matiereQuantites,
            distributionData: {
              structureId: Number(baseItem.structureId ?? user?.structure?.id ?? 0),
              anneeScolaireId: Number(baseItem.anneeScolaireId ?? 0),
              niveauId: Number(it.niveauId ?? 0),
              classe: "DISTRIBUTION",
              dateDistribution: baseItem.dateDistribution || new Date().toISOString().slice(0, 10),
              effectifGarcons,
              effectifFilles,
              distribuePar: currentUserId,
              commentaire: (it.commentaire || "").trim() || "Distribution de matériel"
            }
          };

          const resp = await distributionService.createDistributionWithStockValidation(payload);
          createResults.push({ id: `new-${idx}`, success: resp.success, message: resp.message });
      }

      const deleteResults: Array<{ id: any; success: boolean; message: string }> = [];
      for (let idx = 0; idx < removedExistingGroupItems.length; idx++) {
          const it: any = removedExistingGroupItems[idx];
          const resp = await distributionService.updateDistributionForFinalization(it.id, {
            isdeleted: true,
            matiereQuantites: [],
          });
          deleteResults.push({ id: `del-${idx}`, success: resp.success, message: resp.message });
      }

      const results = [...updateResults, ...createResults, ...deleteResults];
      const successCount = results.filter((r) => r.success).length;
      const failCount = results.length - successCount;
      if (successCount > 0) toast.success(`${successCount} distribution(s) mise(s) à jour.`);
      if (failCount > 0) toast.error(`${failCount} échec(s) de mise à jour.`);
      setSelectedEditGroupCatalogueId("");
      setEditGroupCatalogues([]);
      setRemovedExistingGroupItems([]);
      await loadDistributions();
    } catch (error) {
      console.error("❌ Erreur enregistrement modifications groupe:", error);
      toast.error("Erreur lors de l'enregistrement des modifications.");
    } finally {
      setLoadingDetails(false);
    }
  };

  const handleOpenEditDistributionGroup = async (group: any) => {
    const selected = await handleShowDistributionGroupDetails(group);
    try {
      const groupItems = selected?.items || [];
      if (!selected?.isGroup || groupItems.length === 0) {
        setIsEditingDistribution(true);
        return;
      }

      const anneeForCatalogues =
        groupItems.length > 0
          ? Number(groupItems[0]?.anneeScolaireId) || undefined
          : undefined;
      const catalogues = await catalogueService.getCataloguesActifs(anneeForCatalogues);
      const cataloguesItems = (catalogues?.items as unknown as any[]) || [];

      const enrichedItems = await Promise.all(
        groupItems.map(async (it: any) => {
          const niveauId = Number(it.niveauId ?? 0);
          const anneeId = Number(it.anneeScolaireId ?? 0);

          const matchedCatalogue = cataloguesItems.find((c: any) => {
            const cNiveauId = Number(c.niveauScolaire?.id || c.niveauScolaireId || c.idNiveauScolaire || 0);
            const cAnneeId = Number(c.anneeScolaire?.id || c.anneeScolaireId || 0);
            return cNiveauId === niveauId && (!anneeId || cAnneeId === anneeId);
          });

          if (!matchedCatalogue?.id) {
            return it;
          }

          const matieresResponse = await catalogueService.getMatieresByCatalogue(matchedCatalogue.id);
          const catalogueMatieres = (matieresResponse?.items || []).map((m: any) => ({
            idMatiere: Number(m.matiereId),
            matiereCode: m.matiereCode || "",
            matiereLibelle: m.matiereLibelle || "",
          }));

          const existing = (it.matiereQuantites || []).map((mq: any) => ({
            ...mq,
            idMatiere: Number(mq.idMatiere ?? mq.matiereId ?? mq.id),
            quantiteRecue: Number(mq.quantiteRecue ?? mq.quantite ?? 0),
            quantite: Number(mq.quantiteRecue ?? mq.quantite ?? 0),
          }));
          const existingByMatiere = new Map<number, any>(
            existing
              .filter((mq: any) => Number.isFinite(mq.idMatiere) && mq.idMatiere > 0)
              .map((mq: any) => [mq.idMatiere, mq])
          );

          const mergedMatiereQuantites = catalogueMatieres.map((cm: any) => {
            const ex = existingByMatiere.get(cm.idMatiere);
            if (ex) return ex;
            return {
              idMatiere: cm.idMatiere,
              matiereCode: cm.matiereCode,
              matiereLibelle: cm.matiereLibelle,
              quantiteRecue: 0,
              quantite: 0,
            };
          });

          return {
            ...it,
            matiereQuantites: mergedMatiereQuantites,
          };
        })
      );

      setSelectedDistribution({
        ...selected,
        items: enrichedItems,
      });
      const existingNiveaux = new Set<number>(
        enrichedItems
          .map((it: any) => Number(it.niveauId ?? 0))
          .filter((v: number) => Number.isFinite(v) && v > 0)
      );
      const addableCatalogues = cataloguesItems
        .map((c: any) => ({
          id: c.id,
          code: c.code,
          libelle: c.libelle,
          niveauId: Number(c.niveauScolaire?.id || c.niveauScolaireId || c.idNiveauScolaire || 0),
          niveauCode: c.niveauScolaire?.code || c.niveauScolaireCode || "",
          niveauLibelle: c.niveauScolaire?.libelle || c.niveauScolaireLibelle || "",
          anneeScolaireId: Number(c.anneeScolaire?.id || c.anneeScolaireId || 0),
        }))
        .filter((c: any) => c.niveauId > 0 && !existingNiveaux.has(c.niveauId));
      setEditGroupCatalogues(addableCatalogues);
      setRemovedExistingGroupItems([]);
    } catch (error) {
      console.error("❌ Erreur enrichissement matières catalogue en édition:", error);
      toast.error("Impossible de charger toutes les matières du catalogue pour l'édition.");
    } finally {
      setIsEditingDistribution(true);
    }
  };

  const handleAddCatalogueToEditGroup = async () => {
    const selected = selectedDistribution as any;
    const selectedCatalogueKey = (selectedEditGroupCatalogueId || "").toString().trim();
    if (!selected?.isGroup || !selectedCatalogueKey) {
      toast.error("Sélectionnez un catalogue à ajouter.");
      return;
    }
    try {
      const catalogue = editGroupCatalogues.find((c: any) => String(c.id) === selectedCatalogueKey);
      if (!catalogue) {
        toast.error("Catalogue introuvable.");
        return;
      }
      if (catalogue.__reAddItem) {
        const reAddItem = { ...catalogue.__reAddItem };
        setSelectedDistribution((prev: any) => {
          const base = prev || selected;
          const baseItems = [...(base?.items || [])];
          const exists = baseItems.some((it: any) =>
            Number(it.niveauId ?? 0) === Number(reAddItem.niveauId ?? 0)
          );
          if (!exists) baseItems.push(reAddItem);
          return { ...base, items: baseItems };
        });
        setEditGroupCatalogues((prev) => prev.filter((c: any) => String(c.id) !== selectedCatalogueKey));
        setSelectedEditGroupCatalogueId("");
        if (reAddItem.id) {
          setRemovedExistingGroupItems((prev) => prev.filter((x: any) => x.id !== reAddItem.id));
        }
        toast.success("Niveau rajouté dans le lot.");
        return;
      }
      const catalogueNumericId = Number(catalogue.id);
      const matieresResponse = Number.isFinite(catalogueNumericId) && catalogueNumericId > 0
        ? await catalogueService.getMatieresByCatalogue(catalogueNumericId)
        : { items: [] as any[] };
      const matiereQuantites = (matieresResponse?.items || []).map((m: any) => ({
        idMatiere: Number(m.matiereId),
        matiereCode: m.matiereCode || "",
        matiereLibelle: m.matiereLibelle || "",
        quantiteRecue: 0,
        quantite: 0,
      }));
      const newItem = {
        __isNew: true,
        statut: "EN_ATTENTE_VALIDATION_EPP",
        niveauId: catalogue.niveauId,
        niveauCode: catalogue.niveauCode,
        niveauLibelle: catalogue.niveauLibelle,
        structureId: selected.items?.[0]?.structureId,
        anneeScolaireId: selected.items?.[0]?.anneeScolaireId,
        dateDistribution: selected.dateDistribution,
        effectifGarcons: 0,
        effectifFilles: 0,
        commentaire: "",
        matiereQuantites,
      };
      setSelectedDistribution((prev: any) => {
        const base = prev || selected;
        const baseItems = [...(base?.items || [])];
        const exists = baseItems.some((it: any) =>
          Number(it.niveauId ?? 0) === Number(newItem.niveauId ?? 0)
        );
        if (!exists) baseItems.push(newItem);
        return { ...base, items: baseItems };
      });
      setEditGroupCatalogues((prev) => prev.filter((c: any) => String(c.id) !== selectedCatalogueKey));
      setSelectedEditGroupCatalogueId("");
      toast.success("Catalogue ajouté. Vous pouvez saisir les données du niveau.");
    } catch (error) {
      console.error("❌ Erreur ajout catalogue en édition groupe:", error);
      toast.error("Impossible d'ajouter ce catalogue.");
    }
  };

  const handleRemoveNewEditGroupItem = (itemIndex: number) => {
    const selected = selectedDistribution as any;
    if (!selected?.isGroup) return;
    const items = [...(selected.items || [])];
    const target = items[itemIndex];
    if (!target?.__isNew) {
      toast.error("Seuls les niveaux nouvellement ajoutés peuvent être retirés ici.");
      return;
    }
    items.splice(itemIndex, 1);
    setSelectedDistribution((prev: any) => ({ ...(prev || selected), items }));
    const niveauId = Number(target.niveauId ?? 0);
    if (niveauId > 0) {
      const option = {
        id: -Math.abs(Date.now()),
        code: target.niveauCode || target.code || "",
        libelle: target.niveauLibelle || target.libelle || "",
        niveauId,
        niveauCode: target.niveauCode || "",
        niveauLibelle: target.niveauLibelle || "",
        anneeScolaireId: Number(target.anneeScolaireId ?? 0),
        __reAddItem: target,
      };
      setEditGroupCatalogues((prev) => {
        const exists = prev.some((c: any) => Number(c.niveauId) === niveauId);
        return exists ? prev : [...prev, option];
      });
    }
  };

  const handleRemoveExistingEditGroupItem = (itemIndex: number) => {
    const selected = selectedDistribution as any;
    if (!selected?.isGroup) return;
    const items = [...(selected.items || [])];
    const target = items[itemIndex];
    if (!target?.id || target?.__isNew) {
      toast.error("Niveau existant introuvable.");
      return;
    }
    const ok = window.confirm(
      "Retirer ce niveau du lot ? La suppression sera appliquée à l'enregistrement et le stock sera recalculé."
    );
    if (!ok) return;
    setRemovedExistingGroupItems((prev) => [...prev, target]);
    items.splice(itemIndex, 1);
    setSelectedDistribution((prev: any) => ({ ...(prev || selected), items }));
    const niveauId = Number(target.niveauId ?? 0);
    if (niveauId > 0) {
      const option = {
        id: -Math.abs(Date.now()),
        code: target.niveauCode || target.code || "",
        libelle: target.niveauLibelle || target.libelle || "",
        niveauId,
        niveauCode: target.niveauCode || "",
        niveauLibelle: target.niveauLibelle || "",
        anneeScolaireId: Number(target.anneeScolaireId ?? 0),
        __reAddItem: target,
      };
      setEditGroupCatalogues((prev) => {
        const exists = prev.some((c: any) => Number(c.niveauId) === niveauId);
        return exists ? prev : [...prev, option];
      });
    }
  };

  // Calculs des statistiques basés sur le statut BD
  const totalDistributions = distributions.length;
  const distributionsTerminees = distributions.filter(
    (d) => d.statut === "DISTRIBUE" || d.statut === "VALIDEE_EPP" || d.statut === "VALIDEE_IEPP"
  ).length;
  const distributionsEnCours = distributions.filter((d) => d.statut === "EN_ATTENTE_VALIDATION_EPP" || d.statut === "EN_ATTENTE_VALIDATION_IEPP").length;
  const totalEleves = distributions.reduce((sum, d) => sum + ((d.effectifGarcons || 0) + (d.effectifFilles || 0)), 0);

  const receptionsValideesAujourdhui = useMemo(() => {
    const today = new Date().toDateString();
    return receptionsHistorique.filter((r: any) => {
      if (r.statut !== "CONFIRMEE_IEPP") return false;
      const v = r.validatedAt;
      if (!v) return false;
      return new Date(v).toDateString() === today;
    }).length;
  }, [receptionsHistorique]);

  const eppSupervisionCount = useMemo(() => {
    const ids = new Set<number>();
    for (const r of [...receptionsEnAttente, ...receptionsHistorique]) {
      const sid = r?.structure?.id ?? r?.idStructure;
      if (sid != null && !Number.isNaN(Number(sid))) ids.add(Number(sid));
    }
    return ids.size;
  }, [receptionsEnAttente, receptionsHistorique]);

  const ctx: DistributionPageCtx = {
    user,
    activeTab,
    setActiveTab,
    distributions,
    groupedDistributions,
    loading,
    error,
    totalDistributions,
    distributionsTerminees,
    distributionsEnCours,
    totalEleves,
    receptionsEnAttente,
    ieppValidationSubTab,
    setIeppValidationSubTab,
    receptionsHistorique,
    loadingReceptionsHistorique,
    receptionsValideesAujourdhui,
    eppSupervisionCount,
    receptionFilesForDetails,
    loadingReceptions,
    selectedReceptionIds,
    isBulkValidating,
    loadingDetails,
    showDistributionForm,
    setShowDistributionForm,
    showModal,
    setShowModal,
    selectedDistribution,
    setSelectedDistribution,
    selectedReceptionForValidation,
    setSelectedReceptionForValidation,
    showValidationModal,
    setShowValidationModal,
    selectedReceptionForDetails,
    showReceptionDetailsModal,
    setShowReceptionDetailsModal,
    distributionFiles,
    editingDistributionData,
    setEditingDistributionData,
    isEditingDistribution,
    setIsEditingDistribution,
    uploadingFile,
    isCreatingDistribution,
    receptionStatut,
    currentPage,
    totalPages,
    pageSize,
    totalCount,
    showConfirmationModal,
    setShowConfirmationModal,
    confirmationNiveau,
    handleNouvelleDistribution,
    refreshDistributions,
    loadReceptionsEnAttente,
    loadReceptionsHistorique,
    handleDownloadReceptionFile,
    closeReceptionDetailsModal,
    handleOpenValidationModal,
    handleShowReceptionDetails,
    handleShowDistributionDetails,
    handleShowDistributionGroupDetails,
    closeDistributionModal,
    handleDownloadDistributionFile,
    handleDistributionSubmit,
    handleDistributionCancel,
    handleValidateReception,
    handleRejectReception,
    handleRejectReceptionFromList,
    handleToggleReceptionSelection,
    handleToggleSelectAllReceptions,
    handleBulkValidateReceptions,
    handleFinalizeDistribution,
    handleFinalizeDistributionGroup,
    handleSaveDistributionGroupEdits,
    handleOpenEditDistributionGroup,
    handleAddCatalogueToEditGroup,
    handleRemoveNewEditGroupItem,
    handleRemoveExistingEditGroupItem,
    handleFileUpload,
    handlePageChange,
    handlePageSizeChange,
    editGroupCatalogues,
    selectedEditGroupCatalogueId,
    setSelectedEditGroupCatalogueId,
  }

  return <DistributionPageBody ctx={ctx} />
}
