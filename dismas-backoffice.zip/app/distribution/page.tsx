"use client"

import React from "react"
import MainLayout from "../../components/layout/main-layout"
import { useAuth } from "../providers"
import { DistributionPageContent } from "./DistributionPageContent"

export default function DistributionPage() {
  const { user } = useAuth()

  if (!user) {
    return React.createElement(
      "div",
      { className: "min-h-screen flex items-center justify-center" },
      React.createElement(
        "div",
        { className: "text-center" },
        React.createElement("p", { className: "text-gray-600" }, "Chargement...")
      )
    )
  }

  return React.createElement(
    MainLayout,
    null,
    React.createElement(DistributionPageContent, { user })
  )
}
