"use client"

import React from "react"
import ConfirmationEPPModal from "../../components/modals/ConfirmationEPPModal"
import ValidationIEPPModal from "../../components/modals/ValidationIEPPModal"
import DistributionForm from "../../components/forms/DistributionForm"
import DistributionEditGroupForm from "../../components/forms/DistributionEditGroupForm"
import PaginationControls from "../../components/ui/pagination-controls"
import {
  PlusIcon,
  TruckIcon,
  AcademicCapIcon,
  CalendarIcon,
  CheckCircleIcon,
  ClockIcon,
  XCircleIcon,
  CheckIcon,
  BookOpenIcon,
  EyeIcon,
  ArrowDownTrayIcon,
  ArrowPathIcon,
} from "@heroicons/react/24/outline"

export type DistributionPageCtx = {
  user: any
  activeTab: "distributions" | "validations"
  setActiveTab: (t: "distributions" | "validations") => void
  distributions: any[]
  /** Regroupement par même date / année / EPP pour afficher une ligne par "distribution" logique */
  groupedDistributions?: { dateDistribution: string; anneeScolaireLibelle: string; structureLibelle: string; items: any[]; totalManuels: number; totalEleves: number; niveauxCount: number; statut: string }[]
  loading: boolean
  error: string | null
  totalDistributions: number
  distributionsTerminees: number
  distributionsEnCours: number
  totalEleves: number
  receptionsEnAttente: any[]
  ieppValidationSubTab: "pending" | "history"
  setIeppValidationSubTab: (t: "pending" | "history") => void
  receptionsHistorique: any[]
  loadingReceptionsHistorique: boolean
  receptionsValideesAujourdhui: number
  eppSupervisionCount: number
  receptionFilesForDetails: { id?: number; fileName: string; fileType?: string; fileSize?: number }[]
  loadingReceptions: boolean
  selectedReceptionIds: number[]
  isBulkValidating: boolean
  loadingDetails: boolean
  showDistributionForm: boolean
  setShowDistributionForm: (v: boolean) => void
  showModal: boolean
  setShowModal: (v: boolean) => void
  selectedDistribution: any
  setSelectedDistribution?: (v: any) => void
  selectedReceptionForValidation: any
  setSelectedReceptionForValidation: (v: any) => void
  showValidationModal: boolean
  setShowValidationModal: (v: boolean) => void
  selectedReceptionForDetails: any
  showReceptionDetailsModal: boolean
  setShowReceptionDetailsModal: (v: boolean) => void
  distributionFiles: any[]
  editingDistributionData: any
  setEditingDistributionData: (v: any) => void
  isEditingDistribution: boolean
  setIsEditingDistribution: (v: boolean) => void
  uploadingFile: boolean
  isCreatingDistribution: boolean
  receptionStatut: string | null
  currentPage: number
  totalPages: number
  pageSize: number
  totalCount: number
  showConfirmationModal: boolean
  setShowConfirmationModal: (v: boolean) => void
  confirmationNiveau: "EPP" | "IEPP"
  handleNouvelleDistribution: () => void
  refreshDistributions: () => void
  loadReceptionsEnAttente: () => void
  loadReceptionsHistorique: () => void
  handleDownloadReceptionFile: (fileId: number, fileName: string) => void | Promise<void>
  closeReceptionDetailsModal: () => void
  handleOpenValidationModal: (r: any) => void
  handleShowReceptionDetails: (r: any) => void
  handleShowDistributionDetails: (d: any) => void
  handleShowDistributionGroupDetails: (group: any) => void
  closeDistributionModal: () => void
  handleDownloadDistributionFile: (fileId: number, fileName: string) => void | Promise<void>
  handleDistributionSubmit: (d: any) => void
  handleDistributionCancel: () => void
  handleValidateReception: () => void
  handleRejectReception: () => void
  handleRejectReceptionFromList: (r: any) => void
  handleToggleReceptionSelection: (id: number) => void
  handleToggleSelectAllReceptions: () => void
  handleBulkValidateReceptions: () => void
  handleFinalizeDistribution: () => void
  handleFinalizeDistributionGroup: (group: any) => void
  handleSaveDistributionGroupEdits: () => void
  handleOpenEditDistributionGroup: (group: any) => void
  handleAddCatalogueToEditGroup: () => void
  handleRemoveNewEditGroupItem: (itemIndex: number) => void
  handleRemoveExistingEditGroupItem: (itemIndex: number) => void
  handleFileUpload: (f: File) => void
  handlePageChange: (p: number) => void
  handlePageSizeChange: (s: number) => void
  editGroupCatalogues?: any[]
  selectedEditGroupCatalogueId?: string
  setSelectedEditGroupCatalogueId?: (v: string) => void
}

export function DistributionPageBody({ ctx }: { ctx: DistributionPageCtx }) {
  const formatFileSizeLabel = (n?: number | null) => {
    if (n == null || Number.isNaN(Number(n))) return "";
    const b = Number(n);
    if (b < 1024) return `${b} o`;
    if (b < 1024 * 1024) return `${(b / 1024).toFixed(1)} Ko`;
    return `${(b / (1024 * 1024)).toFixed(1)} Mo`;
  };

  const formatTraceDate = (s?: string | null) => {
    if (!s) return "—";
    const d = new Date(s);
    return Number.isNaN(d.getTime()) ? s : d.toLocaleString("fr-FR");
  };

  const formatDistributionStatus = (statut?: string) => {
    switch ((statut || "").trim()) {
      case "EN_ATTENTE_VALIDATION_EPP":
        return "En attente validation EPP";
      case "EN_ATTENTE_VALIDATION_IEPP":
        return "En attente validation IEPP";
      case "VALIDEE_EPP":
        return "Validee EPP";
      case "VALIDEE_IEPP":
        return "Validee IEPP";
      case "REJETEE_IEPP":
        return "Rejetee IEPP";
      case "DISTRIBUE":
        return "Distribuee";
      default:
        return statut || "N/A";
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">
            {ctx.user.role.code === "IEPP" ? "Distribution & Validation" : "Distribution des Manuels"}
          </h1>
          <p className="text-gray-600">
            {ctx.user.role.code === "IEPP"
              ? "Validez les réceptions EPP et suivez les distributions"
              : "Gestion des distributions par classe"}
          </p>
        </div>
        <div className="flex flex-col sm:flex-row gap-3 mt-4 sm:mt-0">
          {(ctx.user.role.code === "DIRECTEUR" || ctx.user.role.code === "MAITRE") && (
            <button onClick={ctx.handleNouvelleDistribution} className="btn-primary">
              <PlusIcon className="h-5 w-5 mr-2" />
              Nouvelle Distribution
            </button>
          )}
          <button
            onClick={ctx.refreshDistributions}
            className="btn-outline"
            disabled={ctx.loading}
          >
            {ctx.loading ? (
              <>
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-gray-600 mr-2"></div>
                Chargement...
              </>
            ) : (
              <>
                <TruckIcon className="h-5 w-5 mr-2" />
                Actualiser
              </>
            )}
          </button>
        </div>
      </div>
      {/* Onglets IEPP */}
      {ctx.user.role.code === "IEPP" && (
        <div className="border-b border-gray-200">
          <nav className="-mb-px flex space-x-8">
            <button
              onClick={() => ctx.setActiveTab("distributions")}
              className={`py-4 px-1 border-b-2 font-medium text-sm transition-colors ${
                ctx.activeTab === "distributions"
                  ? "border-blue-600 text-blue-600"
                  : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
              }`}
            >
              <div className="flex items-center gap-2">
                <BookOpenIcon className="h-5 w-5" />
                Distributions aux Élèves
              </div>
            </button>
            <button
              onClick={() => ctx.setActiveTab("validations")}
              className={`py-4 px-1 border-b-2 font-medium text-sm transition-colors ${
                ctx.activeTab === "validations"
                  ? "border-blue-600 text-blue-600"
                  : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
              }`}
            >
              <div className="flex items-center gap-2">
                <CheckCircleIcon className="h-5 w-5" />
                Validation Réceptions EPP
                {ctx.receptionsEnAttente.length > 0 && (
                  <span className="ml-2 px-2 py-0.5 text-xs font-bold rounded-full bg-red-500 text-white">
                    {ctx.receptionsEnAttente.length}
                  </span>
                )}
              </div>
            </button>
          </nav>
        </div>
      )}

      {ctx.user.role.code === "IEPP" && ctx.activeTab === "distributions" && (
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
          <div className="flex items-center">
            <AcademicCapIcon className="h-5 w-5 text-blue-600 mr-2" />
            <p className="text-blue-800 font-medium">Mode Consultation</p>
          </div>
          <p className="text-blue-700 mt-1">
            En tant qu&apos;IEPP, vous pouvez consulter et suivre les distributions effectuées par les EPP sous votre supervision.
            Les distributions sont créées uniquement par les directeurs d&apos;école (EPP).
          </p>
        </div>
      )}

      {ctx.error && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-4">
          <div className="flex items-center">
            <XCircleIcon className="h-5 w-5 text-red-600 mr-2" />
            <p className="text-red-800 font-medium">Erreur de chargement</p>
          </div>
          <p className="text-red-700 mt-1">{ctx.error}</p>
          <button onClick={ctx.refreshDistributions} className="mt-2 text-sm text-red-600 hover:text-red-800 underline">
            Réessayer
          </button>
        </div>
      )}

      {ctx.activeTab === "distributions" && (
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <div className="stat-card">
            <div className="flex items-center">
              <div className="p-3 rounded-lg bg-blue-50 text-blue-600">
                <TruckIcon className="h-6 w-6" />
              </div>
              <div className="ml-4">
                <p className="stat-label">Total Distributions</p>
                <p className="stat-value">{ctx.totalDistributions}</p>
              </div>
            </div>
          </div>
          <div className="stat-card">
            <div className="flex items-center">
              <div className="p-3 rounded-lg bg-green-50 text-green-600">
                <CheckCircleIcon className="h-6 w-6" />
              </div>
              <div className="ml-4">
                <p className="stat-label">Terminées</p>
                <p className="stat-value">{ctx.distributionsTerminees}</p>
              </div>
            </div>
          </div>
          <div className="stat-card">
            <div className="flex items-center">
              <div className="p-3 rounded-lg bg-yellow-50 text-yellow-600">
                <ClockIcon className="h-6 w-6" />
              </div>
              <div className="ml-4">
                <p className="stat-label">En Cours</p>
                <p className="stat-value">{ctx.distributionsEnCours}</p>
              </div>
            </div>
          </div>
          <div className="stat-card">
            <div className="flex items-center">
              <div className="p-3 rounded-lg bg-purple-50 text-purple-600">
                <AcademicCapIcon className="h-6 w-6" />
              </div>
              <div className="ml-4">
                <p className="stat-label">Élèves Concernés</p>
                <p className="stat-value">{ctx.totalEleves}</p>
              </div>
            </div>
          </div>
        </div>
      )}

      {ctx.activeTab === "validations" && ctx.user.role.code === "IEPP" && (
        <>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="stat-card">
              <div className="flex items-center">
                <div className="p-3 rounded-lg bg-yellow-50 text-yellow-600">
                  <ClockIcon className="h-6 w-6" />
                </div>
                <div className="ml-4">
                  <p className="stat-label">En Attente Validation</p>
                  <p className="stat-value">{ctx.receptionsEnAttente.length}</p>
                </div>
              </div>
            </div>
            <div className="stat-card">
              <div className="flex items-center">
                <div className="p-3 rounded-lg bg-green-50 text-green-600">
                  <CheckCircleIcon className="h-6 w-6" />
                </div>
                <div className="ml-4">
                  <p className="stat-label">Validées Aujourd&apos;hui</p>
                  <p className="stat-value">{ctx.receptionsValideesAujourdhui}</p>
                </div>
              </div>
            </div>
            <div className="stat-card">
              <div className="flex items-center">
                <div className="p-3 rounded-lg bg-blue-50 text-blue-600">
                  <TruckIcon className="h-6 w-6" />
                </div>
                <div className="ml-4">
                  <p className="stat-label">EPP Sous Supervision</p>
                  <p className="stat-value">{ctx.eppSupervisionCount}</p>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-4 flex flex-wrap gap-2 border-b border-gray-200 pb-2">
            <button
              type="button"
              onClick={() => ctx.setIeppValidationSubTab("pending")}
              disabled={ctx.isBulkValidating}
              className={`rounded-lg px-4 py-2 text-sm font-medium transition-colors ${
                ctx.ieppValidationSubTab === "pending"
                  ? "bg-amber-100 text-amber-900 ring-1 ring-amber-300"
                  : "bg-gray-50 text-gray-600 hover:bg-gray-100"
              } disabled:opacity-50 disabled:cursor-not-allowed`}
            >
              À valider
              {ctx.receptionsEnAttente.length > 0 && (
                <span className="ml-2 rounded-full bg-amber-600 px-2 py-0.5 text-xs text-white">
                  {ctx.receptionsEnAttente.length}
                </span>
              )}
            </button>
            <button
              type="button"
              onClick={() => ctx.setIeppValidationSubTab("history")}
              disabled={ctx.isBulkValidating}
              className={`rounded-lg px-4 py-2 text-sm font-medium transition-colors ${
                ctx.ieppValidationSubTab === "history"
                  ? "bg-slate-100 text-slate-900 ring-1 ring-slate-300"
                  : "bg-gray-50 text-gray-600 hover:bg-gray-100"
              } disabled:opacity-50 disabled:cursor-not-allowed`}
            >
              Historique (validées / rejetées)
              {ctx.receptionsHistorique.length > 0 && (
                <span className="ml-2 rounded-full bg-slate-600 px-2 py-0.5 text-xs text-white">
                  {ctx.receptionsHistorique.length}
                </span>
              )}
            </button>
          </div>

          <div
            className="card mt-6 relative"
            aria-busy={ctx.isBulkValidating}
          >
            {ctx.isBulkValidating && (
              <div
                className="absolute inset-0 z-20 flex flex-col items-center justify-center rounded-lg bg-white/75 backdrop-blur-[1px] px-4 text-center"
                role="status"
                aria-live="polite"
              >
                <ArrowPathIcon className="h-10 w-10 animate-spin text-amber-600" aria-hidden />
                <p className="mt-3 text-sm font-semibold text-amber-950">
                  Validation des réceptions en cours…
                </p>
                <p className="mt-1 text-xs text-gray-600 max-w-sm">
                  Merci de patienter. Ne fermez pas la page tant que l’opération n’est pas terminée.
                </p>
              </div>
            )}
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-gray-900">
                {ctx.ieppValidationSubTab === "pending"
                  ? "Réceptions EPP à valider"
                  : "Historique des réceptions EPP (votre périmètre IEPP)"}
              </h3>
              {ctx.ieppValidationSubTab === "pending" ? (
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={ctx.handleToggleSelectAllReceptions}
                  className="btn-outline btn-sm"
                  disabled={
                    ctx.loadingReceptions ||
                    ctx.receptionsEnAttente.length === 0 ||
                    ctx.isBulkValidating
                  }
                >
                  {ctx.selectedReceptionIds.length === ctx.receptionsEnAttente.length && ctx.receptionsEnAttente.length > 0
                    ? "Tout désélectionner"
                    : "Tout sélectionner"}
                </button>
                <button
                  type="button"
                  onClick={() => void ctx.handleBulkValidateReceptions()}
                  className="btn-primary btn-sm inline-flex items-center gap-2 disabled:opacity-60 disabled:cursor-not-allowed"
                  disabled={ctx.isBulkValidating || ctx.selectedReceptionIds.length === 0}
                >
                  {ctx.isBulkValidating ? (
                    <>
                      <ArrowPathIcon className="h-4 w-4 animate-spin shrink-0" />
                      Validation en cours…
                    </>
                  ) : (
                    `Valider la sélection (${ctx.selectedReceptionIds.length})`
                  )}
                </button>
                {ctx.loadingReceptions && (
                  <div className="flex items-center text-blue-600">
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-blue-600 mr-2"></div>
                    Chargement...
                  </div>
                )}
              </div>
              ) : (
                <button
                  type="button"
                  onClick={() => ctx.loadReceptionsHistorique()}
                  className="btn-outline btn-sm"
                  disabled={ctx.loadingReceptionsHistorique}
                >
                  {ctx.loadingReceptionsHistorique ? "Actualisation…" : "Actualiser l’historique"}
                </button>
              )}
            </div>
            {ctx.ieppValidationSubTab === "pending" &&
              (ctx.receptionsEnAttente.length === 0 && !ctx.loadingReceptions ? (
                <div className="text-center py-8">
                  <CheckCircleIcon className="h-12 w-12 mx-auto text-gray-300 mb-4" />
                  <p className="text-gray-500">Aucune réception EPP en attente de validation</p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="table">
                    <thead>
                      <tr>
                        <th>
                          <input
                            type="checkbox"
                            checked={
                              ctx.receptionsEnAttente.length > 0 &&
                              ctx.selectedReceptionIds.length === ctx.receptionsEnAttente.length
                            }
                            onChange={ctx.handleToggleSelectAllReceptions}
                            disabled={ctx.isBulkValidating || ctx.loadingReceptions}
                          />
                        </th>
                        <th>ID</th>
                        <th>EPP</th>
                        <th>Date réception</th>
                        <th>N° Bordereau</th>
                        <th>Année scolaire</th>
                        <th>Statut</th>
                        <th>Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {ctx.receptionsEnAttente.map((reception: any) => (
                        <tr key={reception.id}>
                          <td>
                            <input
                              type="checkbox"
                              checked={ctx.selectedReceptionIds.includes(reception.id)}
                              onChange={() => ctx.handleToggleReceptionSelection(reception.id)}
                              disabled={ctx.isBulkValidating || ctx.loadingReceptions}
                            />
                          </td>
                          <td className="font-medium">
                            <span className="inline-flex px-2 py-1 text-xs font-semibold rounded-full bg-gray-100 text-gray-800">
                              REC-{reception.id}
                            </span>
                          </td>
                          <td>{reception.structureLibelle || reception.structure?.libelle || "N/A"}</td>
                          <td>
                            {reception.dateMouvement
                              ? new Date(reception.dateMouvement).toLocaleDateString("fr-FR")
                              : "N/A"}
                          </td>
                          <td>{reception.numeroBordereau || "—"}</td>
                          <td>
                            <span className="inline-flex px-2 py-1 text-xs font-semibold rounded-full bg-green-100 text-green-800">
                              {reception.anneeScolaireLibelle || "N/A"}
                            </span>
                          </td>
                          <td>
                            <span className="inline-flex px-2 py-1 text-xs font-semibold rounded-full bg-yellow-100 text-yellow-800">
                              {reception.statut || "EN_ATTENTE"}
                            </span>
                          </td>
                          <td>
                            <div className="flex flex-wrap gap-2">
                              <button
                                type="button"
                                onClick={() => ctx.handleOpenValidationModal(reception)}
                                className="btn-primary btn-sm inline-flex items-center gap-1 disabled:opacity-50 disabled:cursor-not-allowed"
                                disabled={ctx.isBulkValidating}
                              >
                                <CheckIcon className="h-4 w-4" />
                                Valider
                              </button>
                              <button
                                type="button"
                                onClick={() => ctx.handleRejectReceptionFromList(reception)}
                                className="btn-danger btn-sm inline-flex items-center gap-1 disabled:opacity-50 disabled:cursor-not-allowed"
                                disabled={ctx.isBulkValidating}
                              >
                                <XCircleIcon className="h-4 w-4" />
                                Rejeter
                              </button>
                              <button
                                type="button"
                                onClick={() => ctx.handleShowReceptionDetails(reception)}
                                className="btn-secondary btn-sm inline-flex items-center gap-1 disabled:opacity-50 disabled:cursor-not-allowed"
                                disabled={ctx.isBulkValidating}
                              >
                                <EyeIcon className="h-4 w-4" />
                                Détails
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ))}

            {ctx.ieppValidationSubTab === "history" &&
              (ctx.loadingReceptionsHistorique ? (
                <div className="flex items-center justify-center py-12 text-slate-600">
                  <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-slate-600 mr-3" />
                  Chargement de l&apos;historique…
                </div>
              ) : ctx.receptionsHistorique.length === 0 ? (
                <div className="text-center py-8">
                  <ClockIcon className="h-12 w-12 mx-auto text-gray-300 mb-4" />
                  <p className="text-gray-500">Aucune réception validée ou rejetée pour le moment</p>
                  <p className="text-sm text-gray-400 mt-2">
                    Les décisions IEPP apparaîtront ici (bordereaux et détails disponibles via « Détails »).
                  </p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="table">
                    <thead>
                      <tr>
                        <th>ID</th>
                        <th>EPP</th>
                        <th>Date</th>
                        <th>N° Bordereau</th>
                        <th>Année</th>
                        <th>Décision IEPP</th>
                        <th>Validé le</th>
                        <th>Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {ctx.receptionsHistorique.map((reception: any) => {
                        const isValidee = reception.statut === "CONFIRMEE_IEPP";
                        const isRejet = reception.statut === "BROUILLON" && reception.validationLevel === "IEPP_REJET";
                        return (
                          <tr key={reception.id}>
                            <td className="font-medium">
                              <span className="inline-flex px-2 py-1 text-xs font-semibold rounded-full bg-gray-100 text-gray-800">
                                REC-{reception.id}
                              </span>
                            </td>
                            <td>{reception.structureLibelle || reception.structure?.libelle || "N/A"}</td>
                            <td>
                              {reception.dateMouvement
                                ? new Date(reception.dateMouvement).toLocaleDateString("fr-FR")
                                : "N/A"}
                            </td>
                            <td>{reception.numeroBordereau || "—"}</td>
                            <td>
                              <span className="inline-flex px-2 py-1 text-xs font-semibold rounded-full bg-green-100 text-green-800">
                                {reception.anneeScolaireLibelle || "N/A"}
                              </span>
                            </td>
                            <td>
                              {isValidee ? (
                                <span className="inline-flex px-2 py-1 text-xs font-semibold rounded-full bg-emerald-100 text-emerald-800">
                                  Validée IEPP
                                </span>
                              ) : isRejet ? (
                                <span className="inline-flex px-2 py-1 text-xs font-semibold rounded-full bg-rose-100 text-rose-800">
                                  Rejetée IEPP
                                </span>
                              ) : (
                                <span className="inline-flex px-2 py-1 text-xs font-semibold rounded-full bg-gray-100 text-gray-700">
                                  {reception.statut || "—"}
                                </span>
                              )}
                            </td>
                            <td className="text-sm text-gray-600">
                              {reception.validatedAt
                                ? new Date(reception.validatedAt).toLocaleString("fr-FR")
                                : "—"}
                            </td>
                            <td>
                              <button
                                type="button"
                                onClick={() => ctx.handleShowReceptionDetails(reception)}
                                className="btn-secondary btn-sm inline-flex items-center gap-1"
                              >
                                <EyeIcon className="h-4 w-4" />
                                Détails et fichiers
                              </button>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              ))}
          </div>
        </>
      )}

      {ctx.activeTab === "distributions" && (
        <div className="card">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-gray-900">Distributions Récentes</h3>
            {ctx.loading && (
              <div className="flex items-center text-blue-600">
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-blue-600 mr-2"></div>
                Chargement...
              </div>
            )}
          </div>
          {(ctx.groupedDistributions?.length ?? 0) === 0 && ctx.distributions.length === 0 && !ctx.loading ? (
            <div className="text-center py-8">
              <TruckIcon className="h-12 w-12 mx-auto text-gray-300 mb-4" />
              <p className="text-gray-500">Aucune distribution trouvée</p>
              <p className="text-sm text-gray-400 mt-2">Créez votre première distribution pour commencer</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="table">
                <thead>
                  <tr>
                    <th>Date Distribution</th>
                    <th>Structure</th>
                    <th>Année Scolaire</th>
                    <th>Niveaux</th>
                    <th>Effectif classe</th>
                    <th className="whitespace-nowrap" title="Total des manuels (tous niveaux)">
                      Manuels
                    </th>
                    <th>Statut</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {(ctx.groupedDistributions ?? []).map((group: any, idx: number) => (
                    <tr key={idx}>
                      <td>
                        <div className="flex flex-wrap items-center gap-2">
                          <span>
                            {group.dateDistribution
                              ? new Date(group.dateDistribution).toLocaleDateString("fr-FR")
                              : "N/A"}
                          </span>
                          {group.hasComplementaire && (
                            <span className="inline-flex rounded-full bg-amber-100 px-2 py-0.5 text-xs font-medium text-amber-900">
                              Complément
                            </span>
                          )}
                        </div>
                      </td>
                      <td>
                        <span className="font-medium text-gray-900">{group.structureLibelle || "N/A"}</span>
                      </td>
                      <td>
                        <span className="inline-flex px-2 py-1 text-xs font-semibold rounded-full bg-green-100 text-green-800">
                          {group.anneeScolaireLibelle || "N/A"}
                        </span>
                      </td>
                      <td>
                        <span className="inline-flex px-2 py-1 text-xs font-semibold rounded-full bg-blue-100 text-blue-800">
                          {group.niveauxCount ?? (group.items?.length ?? 0)}
                        </span>
                      </td>
                      <td className="text-center">
                        <span className="font-medium text-gray-900">{group.totalEleves ?? 0}</span>
                      </td>
                      <td className="text-center">
                        <span className="font-medium text-gray-900">{group.totalManuels ?? 0}</span>
                      </td>
                      <td>
                        <span className="inline-flex px-2 py-1 text-xs font-semibold rounded-full bg-purple-100 text-purple-800">
                          {formatDistributionStatus(group.statut)}
                        </span>
                      </td>
                      <td>
                        <div className="flex space-x-2">
                          <button onClick={() => ctx.handleShowDistributionGroupDetails(group)} className="btn-secondary btn-sm">
                            Détails
                          </button>
                          {ctx.user.role.code === "DIRECTEUR" && group.statut === "EN_ATTENTE_VALIDATION_EPP" && (
                            <button onClick={() => ctx.handleOpenEditDistributionGroup(group)} className="btn-outline btn-sm">
                              Modifier
                            </button>
                          )}
                          {ctx.user.role.code === "DIRECTEUR" && group.statut === "EN_ATTENTE_VALIDATION_EPP" && (
                            <button onClick={() => ctx.handleFinalizeDistributionGroup(group)} className="btn-primary btn-sm">
                              Finaliser
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
          {((ctx.groupedDistributions?.length ?? 0) > 0 || ctx.distributions.length > 0) && (
            <PaginationControls
              currentPage={ctx.currentPage}
              totalPages={ctx.totalPages}
              pageSize={ctx.pageSize}
              totalCount={ctx.totalCount}
              onPageChange={ctx.handlePageChange}
              onPageSizeChange={ctx.handlePageSizeChange}
              loading={ctx.loading}
            />
          )}
        </div>
      )}

      {ctx.showDistributionForm && (
        <div className="modal-overlay" onClick={() => ctx.setShowDistributionForm(false)}>
          <div className="modal-content !max-w-[50vw] w-[50vw] min-w-[32rem] max-h-[50vh] overflow-y-auto p-6" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold">Nouvelle Distribution</h3>
              <button
                onClick={() => ctx.setShowDistributionForm(false)}
                className="text-gray-400 hover:text-gray-600"
                disabled={ctx.isCreatingDistribution}
              >
                <XCircleIcon className="h-6 w-6" />
              </button>
            </div>
            <DistributionForm
              onSubmit={ctx.handleDistributionSubmit}
              onCancel={ctx.handleDistributionCancel}
              loading={ctx.isCreatingDistribution}
              userStructure={ctx.user.structure}
              receptionStatut={ctx.receptionStatut ?? undefined}
            />
          </div>
        </div>
      )}

      <ConfirmationEPPModal
        isOpen={ctx.showConfirmationModal}
        onClose={() => ctx.setShowConfirmationModal(false)}
        niveau={ctx.confirmationNiveau}
      />

      {ctx.showValidationModal && ctx.selectedReceptionForValidation && (
        <ValidationIEPPModal
          reception={ctx.selectedReceptionForValidation}
          onClose={() => {
            ctx.setShowValidationModal(false)
            ctx.setSelectedReceptionForValidation(null)
          }}
          onValidate={ctx.handleValidateReception}
          onReject={ctx.handleRejectReception}
        />
      )}

      {ctx.showReceptionDetailsModal && ctx.selectedReceptionForDetails && (
        <div className="modal-overlay bg-black/40 backdrop-blur-sm" onClick={() => ctx.closeReceptionDetailsModal()}>
          <div className="modal-content !max-w-[92vw] w-[92vw] min-w-[32rem] max-h-[92vh] overflow-y-auto rounded-xl shadow-2xl border border-orange-200 bg-white p-0" onClick={(e) => e.stopPropagation()}>
            <div className="sticky top-0 z-10 flex items-center justify-between px-6 py-5 bg-gradient-to-r from-orange-50/95 to-amber-50/70 border-b border-orange-100/70 rounded-t-xl">
              <h3 className="text-xl font-semibold text-gray-900 flex items-center gap-2">
                Détails Réception - {ctx.selectedReceptionForDetails.numeroBordereau || "N/A"}
              </h3>
              <button onClick={() => ctx.closeReceptionDetailsModal()} className="p-2 rounded-lg text-gray-500 hover:text-gray-700 hover:bg-white/80 transition-colors">
                <XCircleIcon className="h-7 w-7" />
              </button>
            </div>
            <div className="p-6 space-y-6">
              <div className="rounded-xl bg-orange-50/70 border border-orange-100 p-5">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-base">
                <p><span className="font-medium text-gray-600">EPP :</span> {ctx.selectedReceptionForDetails.structureLibelle || "N/A"}</p>
                <p><span className="font-medium text-gray-600">Date :</span> {ctx.selectedReceptionForDetails.dateMouvement ? new Date(ctx.selectedReceptionForDetails.dateMouvement).toLocaleDateString("fr-FR") : "N/A"}</p>
                <p><span className="font-medium text-gray-600">Année scolaire :</span> {ctx.selectedReceptionForDetails.anneeScolaireLibelle || "N/A"}</p>
                <p><span className="font-medium text-gray-600">Statut :</span> <span className="inline-flex px-2.5 py-1 text-sm font-medium rounded-full bg-yellow-100 text-yellow-800">{ctx.selectedReceptionForDetails.statut || "N/A"}</span></p>
              </div>
              </div>
              {ctx.selectedReceptionForDetails.observation && (
                <div className="rounded-xl bg-blue-50/70 border border-blue-100 p-4">
                  <p className="text-base"><span className="font-medium text-gray-600">Observation :</span> {ctx.selectedReceptionForDetails.observation}</p>
                </div>
              )}
              <div className="rounded-xl bg-orange-50/40 border border-orange-100/80 p-4">
                <h4 className="text-sm font-semibold text-stone-800 mb-3 flex items-center gap-2">
                  <ArrowDownTrayIcon className="h-5 w-5 text-orange-600/80" />
                  Pièces jointes (bordereau, photos…)
                </h4>
                {ctx.loadingDetails ? (
                  <p className="text-sm text-slate-500">Chargement des fichiers…</p>
                ) : (ctx.receptionFilesForDetails?.length ?? 0) === 0 ? (
                  <p className="text-sm text-slate-500">Aucun fichier joint pour cette réception.</p>
                ) : (
                  <ul className="space-y-2">
                    {ctx.receptionFilesForDetails.map((f, i) => (
                      <li
                        key={f.id ?? `${f.fileName}-${i}`}
                        className="flex flex-wrap items-center justify-between gap-2 rounded-lg bg-white px-3 py-2 border border-slate-100"
                      >
                        <span className="text-sm text-slate-800">
                          {f.fileName}
                          {f.fileType ? (
                            <span className="ml-2 text-xs text-slate-500">({f.fileType})</span>
                          ) : null}
                        </span>
                        {f.id != null ? (
                          <button
                            type="button"
                            className="btn-outline btn-sm inline-flex items-center gap-1"
                            onClick={() => void ctx.handleDownloadReceptionFile(f.id!, f.fileName)}
                          >
                            <ArrowDownTrayIcon className="h-4 w-4" />
                            Télécharger
                          </button>
                        ) : (
                          <span className="text-xs text-amber-700">ID fichier manquant</span>
                        )}
                      </li>
                    ))}
                  </ul>
                )}
              </div>
              {(ctx.selectedReceptionForDetails.catalogueMouvements?.length ?? 0) > 0 ? (
                <div className="space-y-8">
                  {ctx.selectedReceptionForDetails.catalogueMouvements.map((cat: any) => (
                    <div key={cat.id || cat.catalogueLibelle} className="rounded-xl border border-orange-200 overflow-hidden">
                      <h4 className="text-base font-semibold text-orange-900 px-4 py-3 bg-orange-50 border-b border-orange-200">
                        {cat.catalogueLibelle || cat.catalogueCode || "Catalogue"}
                      </h4>
                      <div className="overflow-x-auto">
                        <table className="table text-base w-full">
                          <thead>
                            <tr className="border-b border-gray-200 bg-gray-50/70">
                              <th className="text-left py-3 px-4 font-semibold text-gray-700">Matière</th>
                              <th className="text-left py-3 px-4 font-semibold text-gray-700">Niveau</th>
                              <th className="text-right py-3 px-4 font-semibold text-gray-700">Qté prévue</th>
                              <th className="text-right py-3 px-4 font-semibold text-gray-700">Qté reçue</th>
                              <th className="text-right py-3 px-4 font-semibold text-gray-700">Écart</th>
                            </tr>
                          </thead>
                          <tbody>
                            {(cat.matiereQuantites || []).map((mq: any) => (
                              <tr key={mq.id} className="border-b border-gray-100">
                                <td className="py-3 px-4">{mq.matiereLibelle || mq.matiereCode || "—"}</td>
                                <td className="py-3 px-4">{mq.niveauScolaireLibelle || mq.niveauScolaireCode || "—"}</td>
                                <td className="text-right py-3 px-4">{mq.quantitePrevue ?? "—"}</td>
                                <td className="text-right py-3 px-4">{mq.quantiteRecue ?? "—"}</td>
                                <td className={`text-right py-3 px-4 font-medium ${(mq.ecart ?? 0) < 0 ? "text-red-600" : (mq.ecart ?? 0) > 0 ? "text-green-600" : ""}`}>
                                  {mq.ecart != null ? mq.ecart : "—"}
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-gray-500 text-base">Aucun catalogue ou matière associé à cette réception.</p>
              )}
            </div>
          </div>
        </div>
      )}

      {ctx.showModal && ctx.selectedDistribution && (
        <div className="modal-overlay bg-black/40 backdrop-blur-sm" onClick={() => ctx.closeDistributionModal()}>
          <div className="modal-content !max-w-[92vw] w-[min(92vw,56rem)] max-h-[90vh] overflow-y-auto rounded-xl shadow-2xl border border-gray-200/80 bg-white p-0" onClick={(e) => e.stopPropagation()}>
            <div className="sticky top-0 z-10 flex items-center justify-between px-6 py-5 bg-gradient-to-r from-orange-50/95 to-amber-50/70 border-b border-orange-100/70 rounded-t-xl">
              <h3 className="text-lg font-semibold tracking-tight text-stone-900">Détails de la distribution</h3>
              <button
                onClick={() => ctx.closeDistributionModal()}
                className="p-2 rounded-lg text-gray-500 hover:text-gray-700 hover:bg-white/80 transition-colors"
                aria-label="Fermer"
              >
                <XCircleIcon className="h-5 w-5" />
              </button>
            </div>

            <div className="p-6 space-y-6">
              {(ctx.selectedDistribution as any).isGroup ? (
                <>
                  <div className="rounded-xl bg-gray-50/80 border border-gray-100 p-5">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-8 gap-y-4 text-sm">
                      <div className="flex flex-col gap-0.5">
                        <span className="text-xs font-medium uppercase tracking-wider text-gray-400">Structure</span>
                        <span className="font-medium text-gray-900">{(ctx.selectedDistribution as any).structureLibelle || "—"}</span>
                      </div>
                      <div className="flex flex-col gap-0.5">
                        <span className="text-xs font-medium uppercase tracking-wider text-gray-400">Date</span>
                        <span className="font-medium text-gray-900">{(ctx.selectedDistribution as any).dateDistribution ? new Date((ctx.selectedDistribution as any).dateDistribution).toLocaleDateString("fr-FR", { day: "numeric", month: "long", year: "numeric" }) : "—"}</span>
                      </div>
                      <div className="flex flex-col gap-0.5">
                        <span className="text-xs font-medium uppercase tracking-wider text-gray-400">Année scolaire</span>
                        <span className="font-medium text-gray-900">{(ctx.selectedDistribution as any).anneeScolaireLibelle || "—"}</span>
                      </div>
                      <div className="flex flex-col gap-0.5">
                        <span className="text-xs font-medium uppercase tracking-wider text-gray-400">Statut</span>
                        <span className="inline-flex w-fit items-center gap-1.5 rounded-full bg-emerald-50 px-3 py-1 text-xs font-medium text-emerald-700 ring-1 ring-emerald-200/60">{formatDistributionStatus((ctx.selectedDistribution as any).statut)}</span>
                      </div>
                      <div className="flex flex-col gap-0.5 sm:col-span-2">
                        <span className="text-xs font-medium uppercase tracking-wider text-gray-400">Lots complémentaires</span>
                        <span className="text-sm text-gray-800">
                          {(ctx.selectedDistribution as any).items?.some((x: any) => x.complementaire) ? "Oui (au moins un niveau)" : "Non"}
                        </span>
                      </div>
                    </div>
                  </div>
                  {ctx.user.role.code === "DIRECTEUR" && (ctx.selectedDistribution as any).statut === "EN_ATTENTE_VALIDATION_EPP" && (
                    <div className="rounded-xl border border-blue-200 bg-blue-50/50 p-4 flex items-center justify-between">
                      <p className="text-sm text-blue-900">
                        Cette distribution est en attente de finalisation EPP.
                      </p>
                      <button
                        type="button"
                        onClick={() => ctx.handleFinalizeDistributionGroup(ctx.selectedDistribution)}
                        className="btn-primary btn-sm"
                      >
                        Finaliser le groupe
                      </button>
                    </div>
                  )}
                  {ctx.isEditingDistribution ? (
                    <DistributionEditGroupForm
                      items={(ctx.selectedDistribution as any).items || []}
                      selectedCatalogueId={ctx.selectedEditGroupCatalogueId || ""}
                      addableCatalogues={ctx.editGroupCatalogues || []}
                      onChangeSelectedCatalogue={(v) => ctx.setSelectedEditGroupCatalogueId?.(v)}
                      onAddCatalogue={ctx.handleAddCatalogueToEditGroup}
                      onRemoveNewItem={ctx.handleRemoveNewEditGroupItem}
                      onRemoveExistingItem={ctx.handleRemoveExistingEditGroupItem}
                      onUpdateItemField={(itemIndex, field, value) => {
                        const items = [...((ctx.selectedDistribution as any).items || [])]
                        items[itemIndex] = { ...items[itemIndex], [field]: value }
                        ctx.setSelectedDistribution?.({ ...(ctx.selectedDistribution as any), items })
                      }}
                      onUpdateMatiereQty={(itemIndex, mqIndex, value) => {
                        const items = [...((ctx.selectedDistribution as any).items || [])]
                        const targetItem = { ...items[itemIndex] }
                        const nextMqs = [...(targetItem.matiereQuantites || [])]
                        nextMqs[mqIndex] = { ...nextMqs[mqIndex], quantiteRecue: value, quantite: value }
                        targetItem.matiereQuantites = nextMqs
                        items[itemIndex] = targetItem
                        ctx.setSelectedDistribution?.({ ...(ctx.selectedDistribution as any), items })
                      }}
                      onRemoveMatiere={(itemIndex, mqIndex) => {
                        const items = [...((ctx.selectedDistribution as any).items || [])]
                        const targetItem = { ...items[itemIndex] }
                        const nextMqs = [...(targetItem.matiereQuantites || [])]
                        nextMqs.splice(mqIndex, 1)
                        targetItem.matiereQuantites = nextMqs
                        items[itemIndex] = targetItem
                        ctx.setSelectedDistribution?.({ ...(ctx.selectedDistribution as any), items })
                      }}
                      onSave={ctx.handleSaveDistributionGroupEdits}
                    />
                  ) : (
                  ((ctx.selectedDistribution as any).items ?? []).map((item: any, itemIdx: number) => (
                    <div key={itemIdx} className="rounded-xl border border-gray-200 overflow-hidden">
                      <div className="px-4 py-3 bg-gradient-to-r from-orange-50/60 to-amber-50/40 border-b border-orange-100/60 flex items-center justify-between">
                        <div>
                          <h4 className="text-sm font-semibold text-gray-800">
                            Niveau : {item.niveauLibelle || item.niveauCode || "—"} | Effectif : {(item.effectifGarcons ?? 0) + (item.effectifFilles ?? 0)}
                          </h4>
                          <p className="mt-1 text-xs text-gray-600">
                            Annee scolaire : {(ctx.selectedDistribution as any).anneeScolaireLibelle || "N/A"}
                          </p>
                        </div>
                        {item.__isNew && (
                          <button
                            type="button"
                            onClick={() => ctx.handleRemoveNewEditGroupItem(itemIdx)}
                            className="btn-danger btn-sm"
                          >
                            Retirer
                          </button>
                        )}
                        {!item.__isNew && ctx.isEditingDistribution && item.statut === "EN_ATTENTE_VALIDATION_EPP" && (
                          <button
                            type="button"
                            onClick={() => ctx.handleRemoveExistingEditGroupItem(itemIdx)}
                            className="btn-danger btn-sm"
                          >
                            Supprimer niveau
                          </button>
                        )}
                      </div>
                      {ctx.isEditingDistribution && item.statut === "EN_ATTENTE_VALIDATION_EPP" && (
                        <div className="px-4 py-4 bg-gray-50/70 border-b border-gray-100">
                          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                            <div>
                              <label className="block text-xs font-medium text-gray-700 mb-1">Effectif garçons</label>
                              <input
                                type="number"
                                min={0}
                                value={item.effectifGarcons ?? 0}
                                onChange={(e) => {
                                  const value = parseInt(e.target.value) || 0;
                                  const items = [...((ctx.selectedDistribution as any).items || [])];
                                  items[itemIdx] = { ...items[itemIdx], effectifGarcons: value };
                                  ctx.setSelectedDistribution?.({ ...(ctx.selectedDistribution as any), items });
                                }}
                                className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                              />
                            </div>
                            <div>
                              <label className="block text-xs font-medium text-gray-700 mb-1">Effectif filles</label>
                              <input
                                type="number"
                                min={0}
                                value={item.effectifFilles ?? 0}
                                onChange={(e) => {
                                  const value = parseInt(e.target.value) || 0;
                                  const items = [...((ctx.selectedDistribution as any).items || [])];
                                  items[itemIdx] = { ...items[itemIdx], effectifFilles: value };
                                  ctx.setSelectedDistribution?.({ ...(ctx.selectedDistribution as any), items });
                                }}
                                className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                              />
                            </div>
                            <div>
                              <label className="block text-xs font-medium text-gray-700 mb-1">Commentaire</label>
                              <input
                                type="text"
                                value={item.commentaire ?? ""}
                                onChange={(e) => {
                                  const items = [...((ctx.selectedDistribution as any).items || [])];
                                  items[itemIdx] = { ...items[itemIdx], commentaire: e.target.value };
                                  ctx.setSelectedDistribution?.({ ...(ctx.selectedDistribution as any), items });
                                }}
                                className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                              />
                            </div>
                          </div>
                        </div>
                      )}
                      {(item.matiereQuantites?.length ?? 0) > 0 ? (
                        <div className="overflow-x-auto">
                          <table className="w-full text-sm">
                            <thead className="bg-gray-50">
                              <tr>
                                <th className="text-left py-3 px-4 text-xs font-semibold text-gray-500 uppercase tracking-wider">Matière</th>
                                <th className="text-left py-3 px-4 text-xs font-semibold text-gray-500 uppercase tracking-wider">Code</th>
                                <th className="text-right py-3 px-4 text-xs font-semibold text-gray-500 uppercase tracking-wider">Quantité</th>
                                {ctx.isEditingDistribution && item.statut === "EN_ATTENTE_VALIDATION_EPP" && (
                                  <th className="text-right py-3 px-4 text-xs font-semibold text-gray-500 uppercase tracking-wider">Action</th>
                                )}
                              </tr>
                            </thead>
                            <tbody className="divide-y divide-gray-100">
                              {(item.matiereQuantites || []).map((mq: any, mqIdx: number) => (
                                <tr key={mqIdx} className="hover:bg-gray-50/50 transition-colors">
                                  <td className="py-3 px-4 font-medium text-gray-900">{mq.matiereLibelle || mq.matiereCode || "—"}</td>
                                  <td className="py-3 px-4 text-gray-600">{mq.matiereCode || "—"}</td>
                                  <td className="py-3 px-4 text-right font-medium text-gray-900">
                                    {ctx.isEditingDistribution && item.statut === "EN_ATTENTE_VALIDATION_EPP" ? (
                                      <input
                                        type="number"
                                        min={0}
                                        value={mq.quantiteRecue ?? mq.quantite ?? 0}
                                        onChange={(e) => {
                                          const value = parseInt(e.target.value) || 0;
                                          const items = [...((ctx.selectedDistribution as any).items || [])];
                                          const targetItem = { ...items[itemIdx] };
                                          const nextMqs = [...(targetItem.matiereQuantites || [])];
                                          nextMqs[mqIdx] = {
                                            ...nextMqs[mqIdx],
                                            quantiteRecue: value,
                                            quantite: value,
                                          };
                                          targetItem.matiereQuantites = nextMqs;
                                          items[itemIdx] = targetItem;
                                          ctx.setSelectedDistribution?.({ ...(ctx.selectedDistribution as any), items });
                                        }}
                                        className="w-24 ml-auto px-2 py-1 border border-gray-300 rounded text-sm text-right"
                                      />
                                    ) : (
                                      <>{mq.quantiteRecue ?? mq.quantite ?? "—"}</>
                                    )}
                                  </td>
                                  {ctx.isEditingDistribution && item.statut === "EN_ATTENTE_VALIDATION_EPP" && (
                                    <td className="py-3 px-4 text-right">
                                      <button
                                        type="button"
                                        onClick={() => {
                                          const items = [...((ctx.selectedDistribution as any).items || [])];
                                          const targetItem = { ...items[itemIdx] };
                                          const nextMqs = [...(targetItem.matiereQuantites || [])];
                                          nextMqs.splice(mqIdx, 1);
                                          targetItem.matiereQuantites = nextMqs;
                                          items[itemIdx] = targetItem;
                                          ctx.setSelectedDistribution?.({ ...(ctx.selectedDistribution as any), items });
                                        }}
                                        className="btn-danger btn-sm"
                                      >
                                        Retirer
                                      </button>
                                    </td>
                                  )}
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      ) : (
                        <p className="text-sm text-gray-500 text-center py-4">Aucune matière pour ce niveau.</p>
                      )}
                    </div>
                  )))}
                </>
              ) : (
                <>
                  <div className="rounded-xl bg-gray-50/80 border border-gray-100 p-5">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-8 gap-y-4 text-sm">
                      <div className="flex flex-col gap-0.5">
                        <span className="text-xs font-medium uppercase tracking-wider text-gray-400">N° distribution</span>
                        <span className="font-mono font-medium text-gray-900">{(ctx.selectedDistribution as any).id ?? "—"}</span>
                      </div>
                      <div className="flex flex-col gap-0.5">
                        <span className="text-xs font-medium uppercase tracking-wider text-gray-400">Structure</span>
                        <span className="font-medium text-gray-900">{ctx.selectedDistribution.structure?.libelle || (ctx.selectedDistribution as any).structureLibelle || "—"}</span>
                      </div>
                      <div className="flex flex-col gap-0.5">
                        <span className="text-xs font-medium uppercase tracking-wider text-gray-400">Niveau</span>
                        <span className="font-medium text-gray-900">{ctx.selectedDistribution.niveauLibelle || (ctx.selectedDistribution as any).niveauCode || "—"}</span>
                      </div>
                      <div className="flex flex-col gap-0.5">
                        <span className="text-xs font-medium uppercase tracking-wider text-gray-400">Classe</span>
                        <span className="font-medium text-gray-900">{(ctx.selectedDistribution as any).classe ?? "—"}</span>
                      </div>
                      <div className="flex flex-col gap-0.5">
                        <span className="text-xs font-medium uppercase tracking-wider text-gray-400">Date</span>
                        <span className="font-medium text-gray-900">{ctx.selectedDistribution.dateDistribution ? new Date(ctx.selectedDistribution.dateDistribution).toLocaleDateString("fr-FR", { day: "numeric", month: "long", year: "numeric" }) : "—"}</span>
                      </div>
                      <div className="flex flex-col gap-0.5">
                        <span className="text-xs font-medium uppercase tracking-wider text-gray-400">Année scolaire</span>
                        <span className="font-medium text-gray-900">{ctx.selectedDistribution.anneeScolaireLibelle || "—"}</span>
                      </div>
                      <div className="flex flex-col gap-0.5">
                        <span className="text-xs font-medium uppercase tracking-wider text-gray-400">Lot complémentaire</span>
                        <span className="font-medium text-gray-900">{(ctx.selectedDistribution as any).complementaire ? "Oui" : "Non"}</span>
                      </div>
                      <div className="flex flex-col gap-0.5">
                        <span className="text-xs font-medium uppercase tracking-wider text-gray-400">Création</span>
                        <span className="font-medium text-gray-900">{formatTraceDate((ctx.selectedDistribution as any).createdat || (ctx.selectedDistribution as any).createdAt)}</span>
                      </div>
                      <div className="flex flex-col gap-0.5">
                        <span className="text-xs font-medium uppercase tracking-wider text-gray-400">Dernière modification</span>
                        <span className="font-medium text-gray-900">{formatTraceDate((ctx.selectedDistribution as any).updatedat || (ctx.selectedDistribution as any).updatedAt)}</span>
                      </div>
                      <div className="flex flex-col gap-0.5">
                        <span className="text-xs font-medium uppercase tracking-wider text-gray-400">Distribué par (ID)</span>
                        <span className="font-mono font-medium text-gray-900">{(ctx.selectedDistribution as any).distribuePar ?? "—"}</span>
                      </div>
                      <div className="flex flex-col gap-0.5 sm:col-span-2">
                        <span className="text-xs font-medium uppercase tracking-wider text-gray-400">Fiche d&apos;émargement (URL)</span>
                        {(ctx.selectedDistribution as any).ficheEmargementUrl ? (
                          <a
                            href={(ctx.selectedDistribution as any).ficheEmargementUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-orange-700 hover:underline break-all text-sm"
                          >
                            {(ctx.selectedDistribution as any).ficheEmargementUrl}
                          </a>
                        ) : (
                          <span className="text-gray-500">—</span>
                        )}
                      </div>
                      <div className="flex flex-col gap-0.5 sm:col-span-2">
                        <span className="text-xs font-medium uppercase tracking-wider text-gray-400">Statut</span>
                        <span className="inline-flex w-fit items-center gap-1.5 rounded-full bg-emerald-50 px-3 py-1 text-xs font-medium text-emerald-700 ring-1 ring-emerald-200/60">{formatDistributionStatus(ctx.selectedDistribution.statut)}</span>
                      </div>
                    </div>
                  </div>
                  {ctx.isEditingDistribution && (
                    <div className="rounded-xl border border-blue-200 bg-blue-50/50 p-4 space-y-4">
                      <h4 className="text-sm font-semibold text-blue-900">Finalisation de la distribution</h4>
                      <p className="text-xs text-blue-800">
                        Vérifier et compléter les informations. La finalisation fera passer le statut à <strong>DISTRIBUE</strong>.
                      </p>
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                        <div>
                          <label className="block text-xs font-medium text-gray-700 mb-1">Effectif garçons</label>
                          <input
                            type="number"
                            min={0}
                            value={ctx.editingDistributionData?.effectifGarcons ?? 0}
                            onChange={(e) => ctx.setEditingDistributionData({
                              ...ctx.editingDistributionData,
                              effectifGarcons: parseInt(e.target.value) || 0
                            })}
                            className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                          />
                        </div>
                        <div>
                          <label className="block text-xs font-medium text-gray-700 mb-1">Effectif filles</label>
                          <input
                            type="number"
                            min={0}
                            value={ctx.editingDistributionData?.effectifFilles ?? 0}
                            onChange={(e) => ctx.setEditingDistributionData({
                              ...ctx.editingDistributionData,
                              effectifFilles: parseInt(e.target.value) || 0
                            })}
                            className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                          />
                        </div>
                        <div>
                          <label className="block text-xs font-medium text-gray-700 mb-1">Effectif classe (lecture seule)</label>
                          <input
                            type="number"
                            value={(ctx.editingDistributionData?.effectifGarcons ?? 0) + (ctx.editingDistributionData?.effectifFilles ?? 0)}
                            readOnly
                            className="w-full px-3 py-2 border border-gray-200 bg-gray-100 rounded-md text-sm text-gray-700"
                          />
                        </div>
                      </div>
                      <div>
                        <label className="block text-xs font-medium text-gray-700 mb-1">Commentaire de finalisation</label>
                        <textarea
                          rows={3}
                          value={ctx.editingDistributionData?.commentaire ?? ""}
                          onChange={(e) => ctx.setEditingDistributionData({
                            ...ctx.editingDistributionData,
                            commentaire: e.target.value
                          })}
                          className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                          placeholder="Renseignez les informations finales de distribution..."
                        />
                      </div>
                      <div className="flex justify-end">
                        <button
                          type="button"
                          onClick={ctx.handleFinalizeDistribution}
                          className="btn-primary btn-sm"
                        >
                          Finaliser (statut: DISTRIBUE)
                        </button>
                      </div>
                    </div>
                  )}
                  {(() => {
                    const matiereQuantites = (ctx.selectedDistribution as any).matiereQuantites || [];
                    const totalManuelsSomme = matiereQuantites.reduce((s: number, mq: any) => s + (mq.quantiteRecue ?? mq.quantite ?? 0), 0);
                    const totalManuelsAffiché = totalManuelsSomme > 0 ? totalManuelsSomme : (ctx.selectedDistribution as any).totalManuelsDistribues ?? "—";
                    return (
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                        <div className="rounded-xl bg-sky-50/80 border border-sky-100 p-4 text-center">
                          <p className="text-2xl font-semibold text-sky-700">{(ctx.selectedDistribution as any).effectifGarcons ?? "—"}</p>
                          <p className="text-xs font-medium uppercase tracking-wider text-sky-600/90 mt-0.5">Garçons</p>
                        </div>
                        <div className="rounded-xl bg-rose-50/80 border border-rose-100 p-4 text-center">
                          <p className="text-2xl font-semibold text-rose-700">{(ctx.selectedDistribution as any).effectifFilles ?? "—"}</p>
                          <p className="text-xs font-medium uppercase tracking-wider text-rose-600/90 mt-0.5">Filles</p>
                        </div>
                        <div className="rounded-xl bg-amber-50/80 border border-amber-100 p-4 text-center">
                          <p className="text-2xl font-semibold text-amber-800">{totalManuelsAffiché}</p>
                          <p className="text-xs font-medium uppercase tracking-wider text-amber-700/90 mt-0.5">Manuels distribués</p>
                          {totalManuelsSomme > 0 && (
                            <p className="text-[10px] text-amber-600/80 mt-1">= somme des quantités ci-dessous</p>
                          )}
                        </div>
                      </div>
                    );
                  })()}
                  {(ctx.selectedDistribution as any).commentaire && (
                    <div className="rounded-xl bg-gray-50/80 border border-gray-100 p-4">
                      <p className="text-xs font-medium uppercase tracking-wider text-gray-400 mb-1">Commentaire</p>
                      <p className="text-sm text-gray-700 leading-relaxed">{(ctx.selectedDistribution as any).commentaire}</p>
                    </div>
                  )}
                  {((ctx.selectedDistribution as any).matiereQuantites?.length ?? 0) > 0 ? (
                    <div className="rounded-xl border border-gray-200 overflow-hidden">
                      <div className="px-4 py-3 bg-gray-50/90 border-b border-gray-200">
                        <h4 className="text-sm font-semibold text-gray-800">Matières distribuées</h4>
                      </div>
                      <div className="overflow-x-auto">
                        <table className="w-full text-sm">
                          <thead>
                            <tr className="bg-gray-50/70">
                              <th className="text-left py-3 px-4 font-medium text-gray-500 uppercase tracking-wider">Matière</th>
                              <th className="text-left py-3 px-4 font-medium text-gray-500 uppercase tracking-wider">Niveau</th>
                              <th className="text-right py-3 px-4 font-medium text-gray-500 uppercase tracking-wider">Quantité</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-gray-100">
                            {((ctx.selectedDistribution as any).matiereQuantites || []).map((mq: any, idx: number) => (
                              <tr key={mq.idMatiere || idx} className="hover:bg-gray-50/50 transition-colors">
                                <td className="py-3 px-4 font-medium text-gray-900">{mq.matiereLibelle || mq.matiereCode || "—"}</td>
                                <td className="py-3 px-4 text-gray-600">{mq.niveauScolaireLibelle || mq.niveauScolaireCode || "—"}</td>
                                <td className="py-3 px-4 text-right font-medium text-gray-900">{mq.quantiteRecue ?? mq.quantite ?? "—"}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  ) : (
                    <p className="text-sm text-gray-500 text-center py-6">Aucune matière associée à cette distribution.</p>
                  )}
                </>
              )}

              <div className="rounded-xl bg-orange-50/35 border border-orange-100/90 p-4 shadow-sm shadow-orange-950/5">
                <h4 className="text-sm font-semibold text-stone-800 mb-3 flex items-center gap-2">
                  <ArrowDownTrayIcon className="h-5 w-5 text-orange-600/75 shrink-0" />
                  Pièces jointes (fiche d&apos;émargement, photos, documents)
                </h4>
                {ctx.loadingDetails ? (
                  <p className="text-sm text-stone-500">Chargement des fichiers…</p>
                ) : (ctx.distributionFiles?.length ?? 0) === 0 ? (
                  <p className="text-sm text-stone-500">Aucun fichier enregistré pour cette distribution.</p>
                ) : (
                  <ul className="space-y-2">
                    {ctx.distributionFiles.map((f: any, i: number) => {
                      const fid = f.id ?? f.fileId;
                      const name = f.fileName || f.file_name || `fichier-${fid ?? i}`;
                      return (
                        <li
                          key={fid != null ? String(fid) : `${name}-${i}`}
                          className="flex flex-wrap items-center justify-between gap-2 rounded-lg bg-white/90 px-3 py-2 border border-orange-100/70"
                        >
                          <span className="text-sm text-stone-800">
                            {name}
                            {f.fileType ? <span className="ml-2 text-xs text-stone-500">({f.fileType})</span> : null}
                            {f._niveauLibelle ? (
                              <span className="ml-2 text-xs font-medium text-orange-800/80">· {f._niveauLibelle}</span>
                            ) : null}
                            {f.fileSize != null ? (
                              <span className="ml-2 text-xs text-stone-400">{formatFileSizeLabel(f.fileSize)}</span>
                            ) : null}
                          </span>
                          {fid != null ? (
                            <button
                              type="button"
                              className="btn-outline btn-sm inline-flex items-center gap-1"
                              onClick={() => void ctx.handleDownloadDistributionFile(Number(fid), name)}
                            >
                              <ArrowDownTrayIcon className="h-4 w-4" />
                              Télécharger
                            </button>
                          ) : (
                            <span className="text-xs text-amber-700">ID fichier manquant</span>
                          )}
                        </li>
                      );
                    })}
                  </ul>
                )}
              </div>

              {(ctx.selectedDistribution as any).isGroup && ((ctx.selectedDistribution as any).items?.length ?? 0) > 0 && (
                <div className="rounded-xl border border-stone-200/80 bg-stone-50/50 p-4 shadow-sm shadow-stone-900/5">
                  <h4 className="text-sm font-semibold text-stone-800 mb-3">Traçabilité par niveau</h4>
                  <div className="overflow-x-auto">
                    <table className="w-full text-xs sm:text-sm">
                      <thead>
                        <tr className="text-left text-stone-600 border-b border-orange-100/70">
                          <th className="py-2 pr-2">N° dist.</th>
                          <th className="py-2 pr-2">Niveau</th>
                          <th className="py-2 pr-2">Classe</th>
                          <th className="py-2 pr-2">Compl.</th>
                          <th className="py-2 pr-2">Création</th>
                          <th className="py-2 pr-2">Modif.</th>
                          <th className="py-2 pr-2">Par (ID)</th>
                          <th className="py-2 pr-2">Fiche URL</th>
                          <th className="py-2">Commentaire</th>
                        </tr>
                      </thead>
                      <tbody>
                        {((ctx.selectedDistribution as any).items as any[]).map((it: any, idx: number) => (
                          <tr key={it.id ?? idx} className="border-b border-stone-100 align-top">
                            <td className="py-2 pr-2 font-mono">{it.id ?? "—"}</td>
                            <td className="py-2 pr-2">{it.niveauLibelle || it.niveauCode || "—"}</td>
                            <td className="py-2 pr-2">{it.classe ?? "—"}</td>
                            <td className="py-2 pr-2">{it.complementaire ? "Oui" : "—"}</td>
                            <td className="py-2 pr-2 whitespace-nowrap">{formatTraceDate(it.createdat || it.createdAt)}</td>
                            <td className="py-2 pr-2 whitespace-nowrap">{formatTraceDate(it.updatedat || it.updatedAt)}</td>
                            <td className="py-2 pr-2 font-mono">{it.distribuePar ?? "—"}</td>
                            <td className="py-2 pr-2">
                              {it.ficheEmargementUrl ? (
                                <a
                                  href={it.ficheEmargementUrl}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className="text-orange-700 underline"
                                >
                                  Ouvrir
                                </a>
                              ) : (
                                "—"
                              )}
                            </td>
                            <td className="py-2 text-slate-700 max-w-[220px]">
                              {it.commentaire ? (
                                <span className="line-clamp-3" title={it.commentaire}>
                                  {it.commentaire}
                                </span>
                              ) : (
                                "—"
                              )}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
