import type { ComponentType, SVGProps } from "react"
import {
  CalculatorIcon,
  CheckCircleIcon,
  DocumentTextIcon,
  EyeIcon,
  PencilIcon,
  Squares2X2Icon,
} from "@heroicons/react/24/outline"

export type BesoinsNavIcon = ComponentType<SVGProps<SVGSVGElement>>

export type BesoinsNavTab = {
  id: string
  name: string
  icon: BesoinsNavIcon
  /** Si défini : lien vers une autre route (ex. synthèse catalogue) */
  href?: string
}

/**
 * Onglets du module Expression des besoins (menu horizontal partagé).
 */
export function buildBesoinsNavTabs(roleCode: string): BesoinsNavTab[] {
  const tabs: BesoinsNavTab[] = []

  if (roleCode === "DIRECTEUR") {
    tabs.push({ id: "saisie", name: "Saisie des Besoins", icon: PencilIcon })
  }

  if (["IEPP", "DAF", "ADMIN", "CABINET"].includes(roleCode)) {
    tabs.push({ id: "consolidation", name: "Consolidation", icon: CalculatorIcon })
  }

  if (["DAF", "ADMIN", "CABINET"].includes(roleCode)) {
    tabs.push({ id: "validation", name: "Validation", icon: CheckCircleIcon })
  }

  tabs.push({ id: "suivi", name: "Suivi", icon: EyeIcon })
  // Cohérence : rôles avec périmètre métier pris en charge par /dashboard/coherence
  if (["ADMIN", "DAF", "DRENA", "IEPP", "DIRECTEUR", "EPP", "CABINET"].includes(roleCode)) {
    tabs.push({ id: "coherence", name: "Cohérence Données", icon: DocumentTextIcon })
  }

  if (["ADMIN", "DAF", "IEPP", "DRENA", "CABINET"].includes(roleCode)) {
    tabs.push({
      id: "synthese-catalogue",
      name: "Synthèse catalogue",
      icon: Squares2X2Icon,
      href: "/besoins/synthese-catalogue",
    })
  }

  return tabs
}

export function resolveBesoinsActiveTab(
  roleCode: string,
  tabQuery: string | null
): string {
  const tabs = buildBesoinsNavTabs(roleCode)
  if (tabQuery && tabs.some((t) => t.id === tabQuery && !t.href)) {
    return tabQuery
  }
  return tabs[0]?.id ?? "saisie"
}
