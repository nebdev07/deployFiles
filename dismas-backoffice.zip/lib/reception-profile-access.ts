/** Aligné sur `components/layout/sidebar.tsx` (entrée menu Réceptions). */
export const RECEPTION_MENU_ROLE_CODES = [
  "ADMIN",
  "DAF",
  "DRENA",
  "IEPP",
  "DIRECTEUR",
  "CABINET",
] as const

/**
 * Accès à la page `/receptions` (garde UI + cohérence menu).
 */
export function canAccessReceptionsModule(roleCode: string | undefined): boolean {
  if (!roleCode) return false
  return (RECEPTION_MENU_ROLE_CODES as readonly string[]).includes(roleCode)
}

/**
 * Conditions de chargement initial des réceptions (hooks page).
 * DRENA/DAF : dès que l'utilisateur est connu (synthèse territoriale).
 * Autres rôles : lorsque `structure.id` est disponible.
 */
export function shouldFetchReceptionsOnUserReady(
  roleCode: string | undefined,
  structureId: number | undefined
): boolean {
  // Doit rester aligné avec `hasReceptionSyntheseTerritoriale` dans reception-flow.ts
  if (roleCode === "DRENA" || roleCode === "DAF" || roleCode === "CABINET") return true
  return structureId != null && structureId > 0
}

/**
 * Liste affichée selon le rôle (ex. directeur : flux EPP uniquement).
 */
export function filterReceptionsListForRole(roleCode: string | undefined, receptions: any[]): any[] {
  if (!receptions?.length) return []
  if (roleCode === "DIRECTEUR") {
    return receptions.filter((r: any) => r.type === "EPP")
  }
  return receptions
}
