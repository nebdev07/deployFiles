/**
 * Configuration API pour l'intégration avec le backend Spring Boot DISMAS.
 *
 * Best practice : aucun host en dur. En production (navigateur), l'URL de l'API
 * est dérivée de l'origine de la page (même serveur → même host + /dismas-api).
 * Ainsi, en changeant de serveur, on ne modifie pas le code : Apache sert le front
 * (Next.js) et l'API (Tomcat) sur le même host ; le front appelle toujours
 * origin + API_PATH.
 *
 * - En local (localhost) : NEXT_PUBLIC_API_URL ou défaut http://localhost:8081.
 * - Côté serveur (SSR) : NEXT_PUBLIC_API_URL (fallback).
 *
 * Régulation multi-niveaux (hubs DRENA/DAF) et exploration territoire stocks :
 * définir NEXT_PUBLIC_REGULATION_MULTI_LEVEL=false pour masquer ces blocs (défaut : activé).
 * Déploiement backend : appliquer la migration SQL rendant regulation.iepp_id nullable
 * (fichier sql/migration-20260411-regulation-iepp-nullable.sql dans le dépôt backend) avant
 * d’activer les transferts DAF→DRENA en production. Tests manuels : matrice profils du plan
 * produit (IEPP→EPP inchangé ; DRENA→IEPP ; DAF→DRENA ; vues territoire lecture seule).
 */

export interface ApiConfig {
  baseUrl: string;
  timeout: number;
  headers: Record<string, string>;
}

/** Chemin de l'API sur le serveur (Apache proxy /dismas-api → backend). Une seule source de vérité. */
export const API_PATH = '/dismas-api';

const DEFAULT_DEV_API = 'http://localhost:8081';

/**
 * Retourne l'URL de base de l'API (sans slash final).
 * - Navigateur, origine ≠ localhost : même host que la page + API_PATH (pas d'env à changer en prod).
 * - Navigateur localhost ou exécution serveur (SSR) : NEXT_PUBLIC_API_URL ou défaut dev.
 */
export function getApiBaseUrl(): string {
  if (typeof window !== 'undefined') {
    const origin = window.location.origin;
    const isLocalhost = /^https?:\/\/localhost(:\d+)?$/i.test(origin);
    if (isLocalhost) {
      return (process.env.NEXT_PUBLIC_API_URL || DEFAULT_DEV_API).replace(/\/$/, '');
    }
    return `${origin}${API_PATH}`.replace(/([^/])\/$/, '$1');
  }
  return (process.env.NEXT_PUBLIC_API_URL || DEFAULT_DEV_API).replace(/\/$/, '');
}

const staticConfig: Omit<ApiConfig, 'baseUrl'> = {
  timeout: process.env.NODE_ENV === 'production' ? 15000 : 10000,
  headers: { 'Content-Type': 'application/json' },
};

/** Config utilisée par les services : baseUrl est résolu à la lecture (getter) pour rester dynamique. */
export const apiConfig: ApiConfig = {
  get baseUrl(): string {
    return getApiBaseUrl();
  },
  ...staticConfig,
};

// Endpoints selon l'architecture backend (chemins relatifs à baseUrl)
export const API_ENDPOINTS = {
  LOGIN: '/user/connexion',
  USERS: '/user',
  ROLES: '/role',
  FUNCTIONALITIES: '/functionality',
  ROLE_FUNCTIONALITIES: '/roleFunctionality',
  TYPE_OUVRAGE: '/typeOuvrage',
  MATIERE: '/matiere',
  NIVEAU_SCOLAIRE: '/niveauScolaire',
  STRUCTURE_ADMINISTRATIVE: '/structureAdministrative',
  PARAMETRE_SYSTEME: '/parametreSysteme',
  ANNEE_SCOLAIRE: '/anneeScolaire',
  STOCKS: '/stock',
  /** Commandes fournisseur DAF (CRUD + /valider) — préférer commandeFournisseur.service.ts */
  COMMANDES: '/commandeFournisseur',
  DISTRIBUTION: '/distribution',
  RAPPORTS: '/rapport',
  /** Enquêtes de satisfaction (table enquete_satisfaction) */
  ENQUETES: '/enqueteSatisfaction',
  PLAINTES: '/plainte',
  RETOURS: '/retour',
  REGULATION: '/regulation',
  BESOINS: '/besoin',
  RECEPTIONS: '/reception',
  PLANIFICATION: '/planification',
} as const;

export type Environment = 'development' | 'production';

export default apiConfig;
