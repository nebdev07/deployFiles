/**
 * Messages d'erreur API / fetch : les ApiError du base-api ne sont pas des instances de Error,
 * et console.error(obj) peut afficher "{}" si l'objet est mal formé ou non sérialisable.
 */

export function getApiErrorMessage(error: unknown, fallback = ''): string {
  if (error == null) return fallback;
  if (typeof error === 'string') {
    const t = error.trim();
    return t || fallback;
  }
  if (error instanceof Error) {
    const m = error.message?.trim();
    if (m) return m;
  }
  if (typeof error !== 'object') {
    return String(error) || fallback;
  }

  const o = error as Record<string, unknown>;
  const direct = o.message;
  if (typeof direct === 'string' && direct.trim()) return direct.trim();

  const details = o.details as Record<string, unknown> | undefined;
  const status = details?.status as Record<string, unknown> | undefined;
  const fromStatus = status?.message;
  if (typeof fromStatus === 'string' && fromStatus.trim()) return fromStatus.trim();

  const code = o.code != null ? String(o.code) : '';
  if (code && code !== 'UNKNOWN_ERROR') {
    const base = fallback || 'Erreur';
    return `${base} (code ${code})`;
  }

  return fallback;
}

/** Pour logger sans "{}" vide : extrait code / message / status backend */
export function formatErrorForLog(error: unknown): string {
  try {
    if (error instanceof Error) {
      return error.stack ?? `${error.name}: ${error.message}`;
    }
    if (error && typeof error === 'object') {
      const o = error as Record<string, any>;
      const slim = {
        code: o.code,
        message: o.message,
        status: o.details?.status ?? o.status,
      };
      return JSON.stringify(slim, null, 2);
    }
    return String(error);
  } catch {
    return String(error);
  }
}
