/**
 * Utilitaires de mapping pour les données utilisateurs
 * Conversion entre les formats backend (UserDto) et frontend
 */

import { User } from '@/lib/types/entities';

/** Ligne structure IEPP / EPP (liste hiérarchique) */
export type StructureRowRef = {
  code?: string;
  libelle?: string;
  drenaCode?: string;
  ieppCode?: string;
};

// Interface pour les données utilisateur affichées dans la liste
export interface UserListItem {
  id: number;
  firstName: string;
  lastName: string;
  email: string;
  telephone?: string;
  login: string;
  role: {
    id: number;
    code: string;
    libelle: string;
  };
  structure: {
    code: string;
    libelle: string;
    type: string;
  };
  isActive: boolean;
  /** Compte verrouillé (trop de tentatives échouées, etc.) */
  isLocked?: boolean;
  /** Tentatives de connexion échouées (si exposé par l’API) */
  loginAttempts?: number;
  lastConnectionDate?: string;
  createdAt?: string;
  // Champs spécifiques pour l'affichage hiérarchique
  drenaCode?: string;
  drenaLibelle?: string;
  ieppCode?: string;
  ieppLibelle?: string;
  eppCode?: string;
  eppLibelle?: string;
  /** Identifiants structures (API) — utiles en édition */
  drenaId?: number;
  ieppId?: number;
  eppId?: number;
}

/**
 * Convertit un User (backend UserDto) vers un UserListItem pour l'affichage
 */
export function mapUserToListItem(user: User): UserListItem {
  const u = user as any;
  // Déterminer la structure principale et son type
  let structureCode = '';
  let structureLibelle = '';
  let structureType = '';

  // Priorité: structureId > champs hiérarchiques directs
  if (u.structureCode && u.structureLibelle) {
    structureCode = u.structureCode;
    structureLibelle = u.structureLibelle;
    structureType = u.structureType || 'STRUCTURE';
  } else {
    // Fallback sur les champs hiérarchiques directs
    if (u.eppCode && u.eppLibelle) {
      structureCode = u.eppCode;
      structureLibelle = u.eppLibelle;
      structureType = 'EPP';
    } else if (u.ieppCode && u.ieppLibelle) {
      structureCode = u.ieppCode;
      structureLibelle = u.ieppLibelle;
      structureType = 'IEPP';
    } else if (u.drenaCode && u.drenaLibelle) {
      structureCode = u.drenaCode;
      structureLibelle = u.drenaLibelle;
      structureType = 'DRENA';
    } else {
      // Par défaut, structure ministérielle
      structureCode = 'MENA-CI';
      structureLibelle = 'Ministère de l\'Éducation Nationale';
      structureType = 'MENA';
    }
  }

  return {
    id: u.id || 0,
    firstName: u.firstName || '',
    lastName: u.lastName || '',
    email: u.email || '',
    telephone: u.telephone || '',
    login: (u.login ?? u.matricule ?? u.userName ?? "") as string,
    role: {
      id: u.roleId || 0,
      code: u.roleCode || '',
      libelle: getRoleLabel(u.roleCode || ''),
    },
    structure: {
      code: structureCode,
      libelle: structureLibelle,
      type: structureType,
    },
    isActive: u.isActive ?? true,
    isLocked: u.isLocked ?? false,
    loginAttempts: typeof u.loginAttempts === 'number' ? u.loginAttempts : undefined,
    lastConnectionDate: u.lastConnectionDate,
    createdAt: u.createdAt,
    // Informations hiérarchiques complètes
    drenaCode: u.drenaCode,
    drenaLibelle: u.drenaLibelle,
    ieppCode: u.ieppCode,
    ieppLibelle: u.ieppLibelle,
    eppCode: u.eppCode,
    eppLibelle: u.eppLibelle,
    drenaId: typeof u.drenaId === "number" ? u.drenaId : undefined,
    ieppId: typeof u.ieppId === "number" ? u.ieppId : undefined,
    eppId: typeof u.eppId === "number" ? u.eppId : undefined,
  };
}

/**
 * Convertit une liste d'utilisateurs backend vers des éléments d'affichage
 */
export function mapUsersToListItems(users: User[]): UserListItem[] {
  return users.map(mapUserToListItem);
}

/**
 * Obtient le libellé d'un rôle à partir de son code
 */
export function getRoleLabel(roleCode: string): string {
  switch (roleCode.toUpperCase()) {
    case 'ADMIN':
      return 'Administrateur Système';
    case 'DAF':
      return 'Directeur des Affaires Financières';
    case 'DRENA':
      return 'Directeur Régional';
    case 'IEPP':
      return 'Inspecteur Enseignement Primaire';
    case 'DIRECTEUR':
      return 'Directeur d\'École';
    default:
      return roleCode;
  }
}

/**
 * Obtient la couleur CSS pour un rôle
 */
export function getRoleColor(roleCode: string): string {
  switch (roleCode.toUpperCase()) {
    case 'ADMIN':
      return 'bg-red-100 text-red-800';
    case 'DAF':
      return 'bg-orange-100 text-orange-800';
    case 'DRENA':
      return 'bg-yellow-100 text-yellow-800';
    case 'IEPP':
      return 'bg-green-100 text-green-800';
    case 'DIRECTEUR':
      return 'bg-blue-100 text-blue-800';
    default:
      return 'bg-gray-100 text-gray-800';
  }
}

/**
 * Filtre les utilisateurs selon la hiérarchie et le rôle de l'utilisateur connecté
 */
export function filterUsersByHierarchy(
  users: UserListItem[],
  currentUser: UserListItem
): UserListItem[] {
  const currentUserRole = currentUser.role.code.toUpperCase();

  switch (currentUserRole) {
    case 'ADMIN':
    case 'DAF':
      // Admin et DAF voient tous les utilisateurs
      return users;

    case 'DRENA':
      // DRENA voit ses IEPP et EPP + lui-même
      return users.filter(user => {
        if (user.id === currentUser.id) return true; // Lui-même
        
        // Utilisateurs de ses structures
        return (
          (user.role.code === 'IEPP' && user.drenaCode === currentUser.drenaCode) ||
          (user.role.code === 'DIRECTEUR' && user.drenaCode === currentUser.drenaCode)
        );
      });

    case 'IEPP':
      // IEPP voit ses EPP + lui-même
      return users.filter(user => {
        if (user.id === currentUser.id) return true; // Lui-même
        
        // Directeurs de ses EPP
        return (
          user.role.code === 'DIRECTEUR' &&
          user.drenaCode === currentUser.drenaCode &&
          user.ieppCode === currentUser.ieppCode
        );
      });

    case 'DIRECTEUR':
      // Directeur ne voit que lui-même
      return users.filter(user => user.id === currentUser.id);

    default:
      return users;
  }
}

/**
 * Formate une date pour l'affichage
 */
export function formatDate(dateString?: string): string {
  if (!dateString) return 'Jamais';
  
  try {
    // Le backend envoie les dates au format "dd/MM/yyyy HH:mm:ss"
    const [datePart, timePart] = dateString.split(' ');
    if (datePart) {
      const [day, month, year] = datePart.split('/');
      const date = new Date(parseInt(year), parseInt(month) - 1, parseInt(day));
      
      if (!isNaN(date.getTime())) {
        return date.toLocaleDateString('fr-FR');
      }
    }
    
    // Fallback: essayer de parser directement
    const date = new Date(dateString);
    if (!isNaN(date.getTime())) {
      return date.toLocaleDateString('fr-FR');
    }
    
    return dateString;
  } catch (error) {
    console.warn('Erreur lors du formatage de la date:', dateString, error);
    return dateString || 'Jamais';
  }
}

/**
 * Formate une date et heure pour l'affichage détaillé
 */
export function formatDateTime(dateString?: string): string {
  if (!dateString) return 'Jamais';
  
  try {
    // Le backend envoie les dates au format "dd/MM/yyyy HH:mm:ss"
    const [datePart, timePart] = dateString.split(' ');
    if (datePart && timePart) {
      const [day, month, year] = datePart.split('/');
      const [hours, minutes, seconds] = timePart.split(':');
      const date = new Date(
        parseInt(year),
        parseInt(month) - 1,
        parseInt(day),
        parseInt(hours),
        parseInt(minutes),
        parseInt(seconds)
      );
      
      if (!isNaN(date.getTime())) {
        return date.toLocaleString('fr-FR');
      }
    }
    
    // Fallback: essayer de parser directement
    const date = new Date(dateString);
    if (!isNaN(date.getTime())) {
      return date.toLocaleString('fr-FR');
    }
    
    return dateString;
  } catch (error) {
    console.warn('Erreur lors du formatage de la date/heure:', dateString, error);
    return dateString || 'Jamais';
  }
}

/**
 * Chaîne DRENA → IEPP → EPP pour affichage fiche utilisateur.
 */
export function formatHierarchyCompoundCode(u: UserListItem): string | null {
  const parts = [u.drenaCode, u.ieppCode, u.eppCode].filter(
    (x): x is string => typeof x === "string" && x.trim().length > 0,
  )
  if (parts.length === 0) return null
  return parts.join(" → ")
}

/**
 * Recherche locale sur code / libellé (tableau structures hiérarchiques).
 */
export function matchesStructureHierarchySearch(row: StructureRowRef, search: string): boolean {
  const t = search.trim().toLowerCase()
  if (!t) return true
  const c = (row.code || "").toLowerCase()
  const l = (row.libelle || "").toLowerCase()
  return c.includes(t) || l.includes(t)
}

/**
 * Clés `drenaCode|ieppCode` pour les IEPP déjà dotés d’un compte inspecteur.
 */
export function collectIeppOccupiedKeys(users: User[]): Set<string> {
  const set = new Set<string>()
  for (const u of users || []) {
    if ((u.roleCode || "").toUpperCase() !== "IEPP") continue
    const dk = (u.drenaCode || "").trim()
    const ik = (u.ieppCode || "").trim()
    if (dk && ik) set.add(`${dk}|${ik}`)
  }
  return set
}

/**
 * Clés `drenaCode|ieppCode|eppCode` pour les EPP déjà dotées d’un directeur.
 */
export function collectEppOccupiedKeys(users: User[]): Set<string> {
  const set = new Set<string>()
  for (const u of users || []) {
    if ((u.roleCode || "").toUpperCase() !== "DIRECTEUR") continue
    const dk = (u.drenaCode || "").trim()
    const ik = (u.ieppCode || "").trim()
    const ek = (u.eppCode || "").trim()
    if (dk && ik && ek) set.add(`${dk}|${ik}|${ek}`)
  }
  return set
}

export function isIeppStructureOccupied(
  row: { code?: string; drenaCode?: string },
  occupied: Set<string>,
): boolean {
  const dk = (row.drenaCode || "").trim()
  const ck = (row.code || "").trim()
  if (!ck) return false
  if (dk && occupied.has(`${dk}|${ck}`)) return true
  return occupied.has(`|${ck}`)
}

export function isEppStructureOccupied(
  row: { code?: string; drenaCode?: string; ieppCode?: string },
  occupied: Set<string>,
): boolean {
  const dk = (row.drenaCode || "").trim()
  const ik = (row.ieppCode || "").trim()
  const ck = (row.code || "").trim()
  if (!dk || !ik || !ck) return false
  return occupied.has(`${dk}|${ik}|${ck}`)
}

/**
 * Périmètre DRENA / IEPP : lignes « enfants » gérables (hors compte connecté).
 */
export function isHierarchyManagedChildRow(
  managerRole: string | undefined,
  managerDrenaCode: string | undefined,
  managerIeppCode: string | undefined,
  connectedUserId: number | undefined,
  target: UserListItem,
): boolean {
  if (connectedUserId != null && target.id === connectedUserId) return false
  const rc = managerRole?.toUpperCase()
  if (rc === "DRENA") {
    return (
      (target.role.code === "IEPP" || target.role.code === "DIRECTEUR") &&
      !!managerDrenaCode &&
      target.drenaCode === managerDrenaCode
    )
  }
  if (rc === "IEPP") {
    return (
      target.role.code === "DIRECTEUR" &&
      !!managerDrenaCode &&
      !!managerIeppCode &&
      target.drenaCode === managerDrenaCode &&
      target.ieppCode === managerIeppCode
    )
  }
  return false
}
