/**
 * Service pour la gestion des utilisateurs
 * Intègre les nouvelles interfaces avec structures administratives
 */

import { BaseApiService } from './base-api.service';
import { ApiResponse } from '@/lib/types/api';
import { User, CreateUserRequest, UserFilters } from '@/lib/types/entities';
import { authService } from './auth.service';

class UsersService extends BaseApiService {
  private baseEndpoint = '/user';

  // Fonction utilitaire pour construire les requêtes selon le format backend
  private buildRequest(data: any, isCreateUpdate = false) {
    const userId = this.getCurrentUserId();
    const token = this.getAuthToken();
    
    // Vérifier si l'utilisateur est connecté
    if (!userId || !token) {
      console.warn('Utilisateur non connecté - impossible de charger les utilisateurs');
      throw new Error('Utilisateur non connecté');
    }
    
    const baseRequest = {
      user: userId,
      token: token,
      isSimpleLoading: false
    };
    
    if (isCreateUpdate) {
      // Pour CREATE/UPDATE/DELETE, utiliser "datas" avec un tableau
      return {
        ...baseRequest,
        datas: [data]
      };
    } else {
      // Pour GET/SEARCH, utiliser "data" avec un objet
      return {
        ...baseRequest,
        data
      };
    }
  }

  // Récupérer tous les utilisateurs avec filtres
  async getUsers(filters?: UserFilters): Promise<ApiResponse<User[]>> {
    const data = {
      id: "",
      idPersonnel: "",
      login: filters?.login || "",
      password: "",
      isActive: filters?.isActive || "",
      isConnected: "",
      isDefaultPassword: "",
      isDeleted: filters?.isDeleted || "",
      isLdapUser: "",
      isLocked: "",
      lastConnectionDate: "",
      lastLockDate: "",
      createdAt: "",
      createdBy: "",
      updatedAt: "",
      updatedBy: "",
      roleId: ""
    };
    
    return this.request<User[]>('POST', `${this.baseEndpoint}/getByCriteria`, this.buildRequest(data));
  }

  // Récupérer un utilisateur par ID
  async getUserById(id: number): Promise<ApiResponse<User[]>> {
    const data = {
      id: id.toString(),
      idPersonnel: "",
      login: "",
      password: "",
      isActive: "",
      isConnected: "",
      isDefaultPassword: "",
      isDeleted: "",
      isLdapUser: "",
      isLocked: "",
      lastConnectionDate: "",
      lastLockDate: "",
      createdAt: "",
      createdBy: "",
      updatedAt: "",
      updatedBy: "",
      roleId: ""
    };
    return this.request<User[]>('POST', `${this.baseEndpoint}/getByCriteria`, this.buildRequest(data));
  }

  // Créer un nouvel utilisateur
  async createUser(userData: CreateUserRequest): Promise<ApiResponse<User[]>> {
    // Construire la requête avec le format "datas" pour la création
    const requestData = this.buildRequest(userData, true);
    return this.request<User[]>('POST', `${this.baseEndpoint}/create`, requestData);
  }

  // Mettre à jour un utilisateur
  async updateUser(id: number, userData: Partial<CreateUserRequest>): Promise<ApiResponse<User[]>> {
    const data = { id, ...userData };
    // Construire la requête avec le format "datas" pour la mise à jour
    const requestData = this.buildRequest(data, true);
    return this.request<User[]>('POST', `${this.baseEndpoint}/update`, requestData);
  }

  // Supprimer un utilisateur (soft delete)
  async deleteUser(id: number): Promise<ApiResponse<User[]>> {
    const data = { id };
    // Construire la requête avec le format "datas" pour la suppression
    const requestData = this.buildRequest(data, true);
    return this.request<User[]>('POST', `${this.baseEndpoint}/delete`, requestData);
  }

  // Activer/Désactiver un utilisateur
  async toggleUserStatus(id: number, isActive: boolean): Promise<ApiResponse<User[]>> {
    const data = { id, isActive };
    // Construire la requête avec le format "datas" pour la modification
    const requestData = this.buildRequest(data, true);
    return this.request<User[]>('POST', `${this.baseEndpoint}/toggleStatus`, requestData);
  }

  // Réinitialiser le mot de passe d'un utilisateur
  async resetPassword(id: number, newPassword?: string): Promise<ApiResponse<User[]>> {
    const data = { id, newPassword };
    // Construire la requête avec le format "datas" pour la modification
    const requestData = this.buildRequest(data, true);
    return this.request<User[]>('POST', `${this.baseEndpoint}/resetPassword`, requestData);
  }

  // Verrouiller un utilisateur (backend: POST /user/blockUser → isLocked = true, déconnexion Redis)
  async lockUser(id: number): Promise<ApiResponse<User[]>> {
    const data = { id };
    const requestData = this.buildRequest(data, true);
    return this.request<User[]>('POST', `${this.baseEndpoint}/blockUser`, requestData);
  }

  // Déverrouiller un utilisateur (backend: POST /user/unBlockUser)
  async unlockUser(id: number): Promise<ApiResponse<User[]>> {
    const data = { id };
    const requestData = this.buildRequest(data, true);
    return this.request<User[]>('POST', `${this.baseEndpoint}/unBlockUser`, requestData);
  }

  // Récupérer les utilisateurs par structure
  async getUsersByStructure(structureType: 'DRENA' | 'IEPP' | 'EPP', structureId: number): Promise<ApiResponse<User[]>> {
    const data = {
      [`${structureType.toLowerCase()}Id`]: structureId,
      isActive: true,
      isDeleted: false
    };
    
    return this.request<User[]>('POST', `${this.baseEndpoint}/getByCriteria`, this.buildRequest(data, false));
  }

  // Récupérer les utilisateurs par rôle
  async getUsersByRole(roleCode: string): Promise<ApiResponse<User[]>> {
    const data = {
      roleCode,
      isActive: true,
      isDeleted: false
    };
    
    return this.request<User[]>('POST', `${this.baseEndpoint}/getByCriteria`, this.buildRequest(data, false));
  }

  // Vérifier si un login existe déjà
  async checkLoginExists(login: string, excludeId?: number): Promise<boolean> {
    try {
      const data = {
        id: "",
        idPersonnel: "",
        login: login,
        password: "",
        isActive: "",
        isConnected: "",
        isDefaultPassword: "",
        isDeleted: "",
        isLdapUser: "",
        isLocked: "",
        lastConnectionDate: "",
        lastLockDate: "",
        createdAt: "",
        createdBy: "",
        updatedAt: "",
        updatedBy: "",
        roleId: ""
      };
      const response = await this.request<User[]>('POST', `${this.baseEndpoint}/getByCriteria`, this.buildRequest(data, false));
      
      const items = (response.items ?? []) as unknown as User[];
      if (items.length > 0) {
        // Si on exclut un ID (pour la mise à jour), vérifier que ce n'est pas le même utilisateur
        if (excludeId) {
          return items.some(user => user.id !== excludeId);
        }
        return true;
      }
      return false;
    } catch (error) {
      console.error('Erreur lors de la vérification du login:', error);
      return false;
    }
  }

  // Vérifier si un email existe déjà
  async checkEmailExists(email: string, excludeId?: number): Promise<boolean> {
    try {
      // Note: Le backend ne semble pas avoir de champ email dans UserDto
      // Cette méthode retourne false pour l'instant
      console.warn('Vérification email non implémentée - le backend ne semble pas avoir de champ email');
      return false;
    } catch (error) {
      console.error('Erreur lors de la vérification de l\'email:', error);
      return false;
    }
  }
}

export const usersService = new UsersService();