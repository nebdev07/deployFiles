/**
 * Service de base pour les appels API
 * Respecte l'architecture backend définie dans le prompt
 * Gère l'authentification, les erreurs et les patterns communs
 */

import { apiConfig } from '@/lib/config/api';
import { ApiResponse, ApiRequest, ApiError, RequestConfig, SearchOperator } from '@/lib/types/api';
import { cleanForBackend, cleanArrayForBackend, prepareCreateData, prepareUpdateData } from '@/lib/utils/api-helpers';

export class BaseApiService {
  private baseUrl: string;
  private defaultHeaders: Record<string, string>;

  constructor() {
    this.baseUrl = apiConfig.baseUrl;
    this.defaultHeaders = apiConfig.headers;
  }

  /**
   * Méthode générique pour les requêtes POST
   */
  protected async post<T>(
    endpoint: string,
    data?: any,
    config?: RequestConfig
  ): Promise<ApiResponse<T>> {
    return this.request<T>('POST', endpoint, data, config);
  }

  /**
   * Méthode générique pour les requêtes GET
   */
  protected async get<T>(
    endpoint: string,
    config?: RequestConfig
  ): Promise<ApiResponse<T>> {
    return this.request<T>('GET', endpoint, undefined, config);
  }

  /**
   * Méthode générique pour les requêtes PUT
   */
  protected async put<T>(
    endpoint: string,
    data?: any,
    config?: RequestConfig
  ): Promise<ApiResponse<T>> {
    return this.request<T>('PUT', endpoint, data, config);
  }

  /**
   * Méthode générique pour les requêtes DELETE
   */
  protected async delete<T>(
    endpoint: string,
    config?: RequestConfig
  ): Promise<ApiResponse<T>> {
    return this.request<T>('DELETE', endpoint, undefined, config);
  }

  /**
   * Méthode pour l'upload de fichiers (multipart/form-data)
   * Selon l'architecture backend : POST /entity/upload
   */
  protected async upload<T>(
    endpoint: string,
    formData: FormData,
    config?: RequestConfig
  ): Promise<ApiResponse<T>> {
    const headers = {
      ...this.defaultHeaders,
      ...config?.headers,
    };
    delete headers['Content-Type']; // Laisser le navigateur définir le Content-Type pour FormData

    return this.request<T>('POST', endpoint, formData, {
      ...config,
      headers,
    });
  }

  /**
   * Méthode principale pour les requêtes HTTP
   */
  protected async request<T>(
    method: string,
    endpoint: string,
    data?: any,
    config?: RequestConfig
  ): Promise<ApiResponse<T>> {
    const url = `${this.baseUrl}${endpoint}`;
    const token = this.getAuthToken();

    const requestConfig: RequestInit = {
      method,
      headers: {
        ...this.defaultHeaders,
        ...config?.headers,
        ...(token && { 
          Authorization: `Bearer ${token}`,
          'Session-Key': token // Ajout du token dans le header pour Redis
        }),
      },
      signal: config?.signal,
    };

    // Ajouter le body pour les méthodes qui le supportent
    if (data && ['POST', 'PUT', 'PATCH'].includes(method)) {
      if (data instanceof FormData) {
        requestConfig.body = data;
      } else {
        requestConfig.body = JSON.stringify(data);
      }
    }

    try {
      console.log('🔵 [BASE-API] request() - DÉBUT')
      console.log('🔵 [BASE-API] method:', method)
      console.log('🔵 [BASE-API] url:', url)
      console.log('🔵 [BASE-API] data:', data ? JSON.stringify(data, null, 2) : 'null')
      
      const response = await fetch(url, requestConfig);
      console.log('🟢 [BASE-API] Response HTTP reçue')
      console.log('🟢 [BASE-API] response.ok:', response.ok)
      console.log('🟢 [BASE-API] response.status:', response.status)
      console.log('🟢 [BASE-API] response.statusText:', response.statusText)
      console.log('🟢 [BASE-API] response.headers:', Object.fromEntries(response.headers.entries()))
      
      // Gérer les erreurs HTTP
      if (!response.ok) {
        console.log('🟡 [BASE-API] Response HTTP non OK')
        // Gérer les erreurs d'authentification
        if (response.status === 401 || response.status === 403) {
          console.log('🟡 [BASE-API] Erreur d\'authentification (401/403)')
          this.handleInvalidToken();
          throw new Error('Session expirée - Vous allez être redirigé vers la page de connexion');
        }
        
        const errorText = await response.text().catch(() => 'Impossible de lire le texte de l\'erreur');
        console.log('🟡 [BASE-API] Texte de l\'erreur:', errorText)
        throw new Error(`HTTP Error: ${response.status} ${response.statusText}`);
      }

      console.log('🔵 [BASE-API] Tentative de parsing JSON...')
      const responseText = await response.text();
      console.log('🟢 [BASE-API] Response text (premiers 500 chars):', responseText.substring(0, 500))
      console.log('🟢 [BASE-API] Response text (longueur):', responseText.length)
      
      let result: ApiResponse<T>;
      try {
        result = JSON.parse(responseText) as ApiResponse<T>;
        console.log('🟢 [BASE-API] JSON parsé avec succès')
        console.log('🟢 [BASE-API] result (type):', typeof result)
        console.log('🟢 [BASE-API] result (valeur):', result)
        console.log('🟢 [BASE-API] result (JSON):', JSON.stringify(result, null, 2))
        console.log('🟢 [BASE-API] result.hasError:', result?.hasError)
        console.log('🟢 [BASE-API] result.items:', result?.items)
        console.log('🟢 [BASE-API] result.status:', result?.status)
      } catch (parseError: any) {
        console.error('🔴 [BASE-API] Erreur lors du parsing JSON')
        console.error('🔴 [BASE-API] parseError:', parseError)
        console.error('🔴 [BASE-API] Response text complet:', responseText)
        throw new Error(`Erreur de parsing JSON: ${parseError?.message || 'Format invalide'}`);
      }

      // Gérer les erreurs métier du backend (selon l'architecture)
      if (result.hasError) {
        console.log('🟡 [BASE-API] Backend a retourné hasError: true')
        const error: ApiError = {
          code: result.status?.code || 'BACKEND_ERROR',
          message: result.status?.message || 'Erreur du serveur',
          details: result,
        };
        console.log('🟡 [BASE-API] Error object créé:', error)
        
        // Gérer les tokens invalides et sessions expirées uniquement si le message est explicitement auth/session.
        // Attention: le backend réutilise parfois le code 900 pour des erreurs métier/transaction (ex: rollback-only).
        const codeStr = String(result.status?.code ?? error.code ?? '');
        const msg = (error.message || '').toLowerCase();
        const isAuthMessage =
          msg.includes('token invalide') ||
          msg.includes('session expirée') ||
          msg.includes('session expirer') ||
          msg.includes('token expired') ||
          msg.includes('unauthorized');
        if (codeStr === '900' && isAuthMessage) {
          if (typeof window !== 'undefined') {
            console.warn('[BASE-API] Session expirée ou token invalide, déconnexion…');
          }
          this.handleInvalidToken();
        }
        
        throw error;
      }

      console.log('🟢 [BASE-API] Réponse OK, retour du result')
      return result;
    } catch (error) {
      const isBusinessError = !!(error && typeof error === 'object' && 'code' in error)
      const businessCode = isBusinessError ? String((error as any)?.code ?? '') : ''

      if (isBusinessError) {
        // Erreur métier backend (ex: 918 — utilisé pour plusieurs cas côté backend) :
        // on évite les logs "error" bruyants qui ressemblent à une panne technique.
        console.warn('🟡 [BASE-API] Erreur métier backend interceptée')
        console.warn('🟡 [BASE-API] error?.code:', businessCode)
        console.warn('🟡 [BASE-API] error?.message:', (error as any)?.message)
      } else {
        console.error('🔴 [BASE-API] Erreur technique dans request()')
        console.error('🔴 [BASE-API] error (type):', typeof error)
        console.error('🔴 [BASE-API] error (valeur):', error)
        console.error('🔴 [BASE-API] error (JSON):', JSON.stringify(error, null, 2))
        console.error('🔴 [BASE-API] error?.message:', (error as any)?.message)
        console.error('🔴 [BASE-API] error?.code:', (error as any)?.code)
        console.error(`API Error [${method} ${endpoint}]:`, error);
      }

      const handledError = this.handleError(error);
      if (isBusinessError) {
        console.warn('🟡 [BASE-API] Erreur métier transformée:', handledError)
      } else {
        console.error('🔴 [BASE-API] Erreur transformée:', handledError)
      }
      throw handledError;
    }
  }

  /**
   * Construire les paramètres de recherche selon l'architecture backend
   * Format: { field: { value: "criteria", operator: "EQ" } }
   */
  protected buildSearchParams(filters: Record<string, any>): Record<string, { value: any; operator: SearchOperator }> {
    const searchParams: Record<string, { value: any; operator: SearchOperator }> = {};

    Object.entries(filters).forEach(([key, value]) => {
      if (value !== undefined && value !== null && value !== '') {
        if (typeof value === 'string' && value.includes('%')) {
          searchParams[key] = { value, operator: 'LIKE' };
        } else {
          searchParams[key] = { value, operator: 'EQ' };
        }
      }
    });

    return searchParams;
  }

  /**
   * Construire une requête API selon l'architecture backend
   * Format: { datas: [DTO], searchParam: {...}, pagination: {...} }
   * Nettoie automatiquement les champs gérés par le backend
   */
  protected buildApiRequest<T>(
    data?: T | T[],
    filters?: Record<string, any>,
    pagination?: { index: number; size: number },
    cleanData: boolean = true
  ): ApiRequest<T> {
    const request: ApiRequest<T> = {
      isSimpleLoading: false,
    };

    const userId = this.getCurrentUserId();
    const token = this.getAuthToken();
    if (userId != null) {
      request.user = userId;
    }
    if (token) {
      request.token = token;
    }

    if (data !== undefined) {
      if (Array.isArray(data)) {
        request.datas = (cleanData ? (cleanArrayForBackend(data as Record<string, any>[]) as unknown as T[]) : (data as unknown as T[])) as T[];
      } else {
        request.datas = (cleanData ? [cleanForBackend(data as unknown as Record<string, any>)] : [data]) as T[];
      }
    }

    if (filters && Object.keys(filters).length > 0) {
      request.searchParam = this.buildSearchParams(filters);
    }

    if (pagination) {
      request.pagination = pagination;
    }

    return request;
  }

  /**
   * Construire une requête CREATE (exclut les champs gérés par le backend)
   */
  protected buildCreateRequest<T>(data: T): ApiRequest<T> {
    return this.buildApiRequest(data, undefined, undefined, true);
  }

  /**
   * Construire une requête UPDATE (garde l'ID, exclut les autres champs gérés)
   */
  protected buildUpdateRequest<T>(data: T): ApiRequest<T> {
    const cleanedData = prepareUpdateData(data as unknown as Record<string, any>);
    return this.buildApiRequest(cleanedData as unknown as T, undefined, undefined, false);
  }

  /**
   * Récupérer le token d'authentification depuis le localStorage
   */
  protected getAuthToken(): string | null {
    if (typeof window !== 'undefined') {
      return localStorage.getItem('auth_token');
    }
    return null;
  }

  /**
   * Récupérer l'ID de l'utilisateur connecté depuis le localStorage
   */
  protected getCurrentUserId(): number | null {
    if (typeof window !== 'undefined') {
      const userSession = localStorage.getItem('dismas_user') || localStorage.getItem('user_session');
      if (userSession) {
        try {
          const user = JSON.parse(userSession);
          return user.id || null;
        } catch (error) {
          console.error('Erreur lors du parsing de la session utilisateur:', error);
          return null;
        }
      }
    }
    return null;
  }

  /**
   * Gestion des erreurs
   */
  private handleError(error: any): ApiError {
    if (error instanceof Error) {
      // Détecter les erreurs de connexion au serveur
      if (error.message.includes('Failed to fetch') || 
          error.message.includes('NetworkError') ||
          error.message.includes('ERR_CONNECTION_REFUSED') ||
          error.message.includes('ERR_NETWORK_CHANGED') ||
          error.message.includes('ERR_INTERNET_DISCONNECTED')) {
        return {
          code: 'SERVER_UNAVAILABLE',
          message: 'Serveur indisponible. Veuillez vérifier votre connexion et réessayer.',
          details: error,
        };
      }
      
      return {
        code: 'NETWORK_ERROR',
        message: error.message,
        details: error,
      };
    }

    if (error != null && typeof error === 'object' && (error as any).code != null) {
      const mergedMessage =
        (typeof (error as any).message === 'string' && (error as any).message.trim()) ||
        (error as any)?.details?.status?.message ||
        '';
      const finalMessage = mergedMessage || 'Erreur du serveur';
      const code = String((error as any).code);
      const msg = finalMessage.toLowerCase();
      const isSessionExpired =
        code === '900' &&
        (msg.includes('token invalide') || msg.includes('session expirée') || msg.includes('session expirer') || msg.includes('token expired') || msg.includes('unauthorized'));
      const isNotConnected =
        msg.includes('utilisateur non connecté') ||
        msg.includes('utilisateur non connecte') ||
        msg.includes('non connecté') ||
        msg.includes('non connecte') ||
        msg.includes('not connected') ||
        msg.includes('not authenticated') ||
        msg.includes('forbidden') ||
        msg.includes('unauthorized');
      if (isSessionExpired || isNotConnected) {
        this.handleInvalidToken();
      }
      return {
        ...(error as ApiError),
        message: finalMessage,
      };
    }

    return {
      code: 'UNKNOWN_ERROR',
      message: 'Une erreur inattendue s\'est produite',
      details: error,
    };
  }

  /**
   * Gérer les tokens invalides en déconnectant l'utilisateur
   */
  private handleInvalidToken(): void {
    if (typeof window !== 'undefined') {
      // Afficher une notification
      this.showTokenExpiredNotification();
      
      // Nettoyer le localStorage
      localStorage.removeItem('auth_token');
      localStorage.removeItem('user_session');
      localStorage.removeItem('token_expiry');
      localStorage.removeItem('dismas_user');
      
      // Rediriger vers la page de connexion après un court délai
      setTimeout(() => {
        window.location.href = '/';
      }, 2000);
    }
  }

  /**
   * Afficher une notification d'expiration de session
   */
  private showTokenExpiredNotification(): void {
    if (typeof window !== 'undefined') {
      // Créer une notification toast
      const notification = document.createElement('div');
      notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: #dc3545;
        color: white;
        padding: 16px 24px;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        z-index: 9999;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        font-size: 14px;
        max-width: 400px;
        animation: slideIn 0.3s ease-out;
      `;
      
      notification.innerHTML = `
        <div style="display: flex; align-items: center; gap: 12px;">
          <div style="font-size: 20px;">⚠️</div>
          <div>
            <div style="font-weight: 600; margin-bottom: 4px;">Session expirée</div>
            <div style="opacity: 0.9;">Votre session a expiré. Vous allez être redirigé vers la page de connexion.</div>
          </div>
        </div>
      `;
      
      // Ajouter l'animation CSS
      const style = document.createElement('style');
      style.textContent = `
        @keyframes slideIn {
          from { transform: translateX(100%); opacity: 0; }
          to { transform: translateX(0); opacity: 1; }
        }
      `;
      document.head.appendChild(style);
      
      document.body.appendChild(notification);
      
      // Supprimer la notification après 3 secondes
      setTimeout(() => {
        if (notification.parentNode) {
          notification.parentNode.removeChild(notification);
        }
        if (style.parentNode) {
          style.parentNode.removeChild(style);
        }
      }, 3000);
    }
  }

  /**
   * Vérifier si le token est valide (non expiré)
   */
  protected isTokenValid(): boolean {
    const tokenExpiry = localStorage.getItem('token_expiry');
    if (!tokenExpiry) return false;

    const expiryDate = new Date(tokenExpiry);
    return expiryDate > new Date();
  }

  /**
   * Rafraîchir le token si nécessaire
   */
  protected async refreshTokenIfNeeded(): Promise<boolean> {
    if (this.isTokenValid()) {
      return true;
    }

    // Si le token a expiré, nettoyer le localStorage
    if (typeof window !== 'undefined') {
      localStorage.removeItem('auth_token');
      localStorage.removeItem('user_session');
      localStorage.removeItem('token_expiry');
    }
    return false;
  }
}