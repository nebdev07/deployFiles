/**
 * Enquêtes de satisfaction — CRUD (/enqueteSatisfaction).
 */

import { BaseApiService } from './base-api.service';
import type { ApiResponse } from '@/lib/types/api';

export type EnqueteSatisfactionPayload = {
  id?: number;
  anneeScolaireId?: number;
  typeRepondant?: string;
  structureId?: number;
  q1Processus?: string;
  q2EtatManuels?: string;
  q3DateMouvement?: string;
  q4ManuelsComplets?: boolean;
  q5Suggestions?: string;
  dateReponse?: string;
};

export type EnqueteSatisfactionRow = EnqueteSatisfactionPayload & {
  anneeScolaireCode?: string;
  structureCode?: string;
  structureLibelle?: string;
  createdat?: string;
  updatedat?: string;
  isdeleted?: boolean;
};

class EnqueteSatisfactionService extends BaseApiService {
  private base = '/enqueteSatisfaction';

  private buildRequest(data: unknown, isCreateUpdate = false) {
    const userId = this.getCurrentUserId();
    const token = this.getAuthToken();
    if (!userId || !token) throw new Error('Utilisateur non connecté');
    const baseRequest = { user: userId, token, isSimpleLoading: false };
    if (isCreateUpdate) return { ...baseRequest, datas: [data] };
    const payload = data != null && typeof data === 'object' ? { ...(data as object) } : {};
    return { ...baseRequest, data: payload };
  }

  async list(filters?: Partial<EnqueteSatisfactionPayload>): Promise<ApiResponse<EnqueteSatisfactionRow[]>> {
    const data: Record<string, unknown> = { isdeleted: false };
    if (filters?.anneeScolaireId) data.anneeScolaireId = filters.anneeScolaireId;
    if (filters?.structureId) data.structureId = filters.structureId;
    if (filters?.typeRepondant) data.typeRepondant = filters.typeRepondant;
    return this.request<EnqueteSatisfactionRow[]>('POST', `${this.base}/getByCriteria`, this.buildRequest(data));
  }

  async create(payload: EnqueteSatisfactionPayload): Promise<ApiResponse<EnqueteSatisfactionRow[]>> {
    return this.request<EnqueteSatisfactionRow[]>('POST', `${this.base}/create`, this.buildRequest(payload, true));
  }

  async update(payload: EnqueteSatisfactionPayload & { id: number }): Promise<ApiResponse<EnqueteSatisfactionRow[]>> {
    return this.request<EnqueteSatisfactionRow[]>('POST', `${this.base}/update`, this.buildRequest(payload, true));
  }

  async remove(id: number): Promise<ApiResponse<EnqueteSatisfactionRow[]>> {
    return this.request<EnqueteSatisfactionRow[]>('POST', `${this.base}/delete`, this.buildRequest({ id }, true));
  }
}

export const enqueteSatisfactionService = new EnqueteSatisfactionService();
