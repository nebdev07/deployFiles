/**
 * Liste des manuels (référentiel) pour les lignes de commande.
 */

import { BaseApiService } from './base-api.service';
import type { ApiResponse } from '@/lib/types/api';

export type ManuelRow = {
  id: number;
  code?: string;
  titre?: string;
  /** Libellés issus du référentiel (DTO complet, pas mode « lite »). */
  matiereLibelle?: string;
  niveauScolaireLibelle?: string;
  matiereId?: number;
  niveauScolaireId?: number;
  /** Code niveau (aligné référentiel) — utile si l’id ne matche pas entre listes. */
  niveauScolaireCode?: string;
  matiere?: { id?: number; libelle?: string };
  niveauScolaire?: { id?: number; libelle?: string; code?: string };
};

/** Accepte `ApiResponse<Row>` ou l’ancien `ApiResponse<Row[]>` (items toujours une liste d’éléments). */
function normalizeApiList<T>(res: ApiResponse<T> | ApiResponse<T[]>): T[] {
  let raw: unknown = res.items
  if (raw == null || (Array.isArray(raw) && raw.length === 0)) {
    const alt = (res as unknown as { datas?: T[] }).datas
    if (Array.isArray(alt)) raw = alt
  }
  if (!Array.isArray(raw)) return []
  if (raw.length > 0 && Array.isArray((raw as unknown[])[0])) {
    return (raw as unknown as T[][]).flat()
  }
  return raw as T[]
}

class ManuelService extends BaseApiService {
  /**
   * Critères minimaux : booléens JSON natifs (évite les filtres HQL incorrects avec des chaînes).
   * Non supprimés + actifs (voir backend : actif null ou true).
   */
  private buildActifsBody() {
    const userId = this.getCurrentUserId();
    const token = this.getAuthToken();
    if (!userId || !token) throw new Error('Utilisateur non connecté');
    return {
      user: userId,
      token,
      isSimpleLoading: false,
      data: {
        actif: true,
        isdeleted: false,
      },
    };
  }

  /** Manuels actifs avec matière et niveau (référentiel BD). */
  async listActifs(): Promise<ApiResponse<ManuelRow[]>> {
    const res = await this.request<ManuelRow[]>('POST', '/manuel/getByCriteria', this.buildActifsBody())
    const items = normalizeApiList<ManuelRow>(res)
    return { ...res, items }
  }
}

export const manuelService = new ManuelService();
