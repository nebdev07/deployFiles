/**
 * Service pour la gestion des années scolaires avec CRUD complet
 * Suit le même pattern que matiere.service.ts et niveau-scolaire.service.ts
 */

import { BaseApiService } from './base-api.service';
import { ApiResponse } from '@/lib/types/api';
import { AnneeScolaire, CreateAnneeScolaireRequest, AnneeScolaireFilters } from '@/lib/types/entities';

class AnneeScolaireService extends BaseApiService {
  private baseEndpoint = '/anneescolaire';

  // Fonction utilitaire pour construire les requêtes selon le format backend
  private buildRequest(data: any, isCreateUpdate = false) {
    const userId = this.getCurrentUserId();
    const token = this.getAuthToken();
    
    // Vérifier si l'utilisateur est connecté
    if (!userId || !token) {
      console.warn('Utilisateur non connecté - impossible de charger les années scolaires');
      throw new Error('Utilisateur non connecté');
    }
    
    const baseRequest = {
      user: userId,
      token: token,
      isSimpleLoading: false
    };
    
    if (isCreateUpdate) {
      // Pour CREATE/UPDATE/DELETE, utiliser "datas" avec un tableau
      return {
        ...baseRequest,
        datas: [data]
      };
    } else {
      // Pour GET/SEARCH, utiliser "data" avec un objet
      return {
        ...baseRequest,
        data
      };
    }
  }

  // Récupérer toutes les années scolaires avec filtres
  async getAnneesScolaires(filters?: AnneeScolaireFilters): Promise<ApiResponse<AnneeScolaire[]>> {
    const data = {
      id: "",
      code: filters?.code || "",
      libelle: filters?.libelle || "",
      dateDebut: "",
      dateFin: "",
      estCourante: filters?.estCourante !== undefined ? filters.estCourante.toString() : "",
      createdat: "",
      createdby: "",
      updatedat: "",
      updatedby: "",
      isdeleted: filters?.isDeleted !== undefined ? filters.isDeleted.toString() : ""
    };
    
    return this.request<AnneeScolaire[]>('POST', `${this.baseEndpoint}/getByCriteria`, this.buildRequest(data));
  }

  // Récupérer une année scolaire par ID
  async getAnneeScolaireById(id: number): Promise<ApiResponse<AnneeScolaire[]>> {
    const data = {
      id: id.toString(),
      code: "",
      libelle: "",
      dateDebut: "",
      dateFin: "",
      estCourante: "",
      createdat: "",
      createdby: "",
      updatedat: "",
      updatedby: "",
      isdeleted: ""
    };
    return this.request<AnneeScolaire[]>('POST', `${this.baseEndpoint}/getByCriteria`, this.buildRequest(data));
  }

  // Créer une nouvelle année scolaire
  async createAnneeScolaire(anneeData: CreateAnneeScolaireRequest): Promise<ApiResponse<AnneeScolaire[]>> {
    // Construire la requête avec le format "datas" pour la création
    const requestData = this.buildRequest(anneeData, true);
    return this.request<AnneeScolaire[]>('POST', `${this.baseEndpoint}/create`, requestData);
  }

  // Mettre à jour une année scolaire
  async updateAnneeScolaire(id: number, anneeData: Partial<CreateAnneeScolaireRequest>): Promise<ApiResponse<AnneeScolaire[]>> {
    const data = { id, ...anneeData };
    // Construire la requête avec le format "datas" pour la mise à jour
    const requestData = this.buildRequest(data, true);
    return this.request<AnneeScolaire[]>('POST', `${this.baseEndpoint}/update`, requestData);
  }

  // Supprimer une année scolaire (soft delete)
  async deleteAnneeScolaire(id: number): Promise<ApiResponse<AnneeScolaire[]>> {
    const data = { id };
    // Construire la requête avec le format "datas" pour la suppression
    const requestData = this.buildRequest(data, true);
    return this.request<AnneeScolaire[]>('POST', `${this.baseEndpoint}/delete`, requestData);
  }

  // Rechercher des années scolaires par terme
  async searchAnneesScolaires(searchTerm: string): Promise<ApiResponse<AnneeScolaire[]>> {
    const data = {
      id: "",
      code: searchTerm,
      libelle: searchTerm,
      dateDebut: "",
      dateFin: "",
      estCourante: "",
      createdat: "",
      createdby: "",
      updatedat: "",
      updatedby: "",
      isdeleted: ""
    };
    
    return this.request<AnneeScolaire[]>('POST', `${this.baseEndpoint}/getByCriteria`, this.buildRequest(data));
  }

  // Vérifier si un code année scolaire existe déjà
  async checkCodeExists(code: string, excludeId?: number): Promise<boolean> {
    try {
      const data = {
        id: "",
        code: code,
        libelle: "",
        dateDebut: "",
        dateFin: "",
        estCourante: "",
        createdat: "",
        createdby: "",
        updatedat: "",
        updatedby: "",
        isdeleted: ""
      };
      const response = await this.request<AnneeScolaire[]>('POST', `${this.baseEndpoint}/getByCriteria`, this.buildRequest(data));
      
      if (response.items && response.items.length > 0) {
        // Si on exclut un ID (pour la mise à jour), vérifier que ce n'est pas la même année
        if (excludeId) {
          const items = Array.isArray(response.items) ? (Array.isArray(response.items[0]) ? (response.items as unknown as any[]).flat() : response.items) : [];
          return items.some((annee: any) => annee.id !== excludeId);
        }
        return true;
      }
      return false;
    } catch (error) {
      console.error('Erreur lors de la vérification du code année scolaire:', error);
      return false;
    }
  }

  // Vérifier si un libellé existe déjà
  async checkLibelleExists(libelle: string, excludeId?: number): Promise<boolean> {
    try {
      const data = {
        id: "",
        code: "",
        libelle: libelle,
        dateDebut: "",
        dateFin: "",
        estCourante: "",
        createdat: "",
        createdby: "",
        updatedat: "",
        updatedby: "",
        isdeleted: ""
      };
      const response = await this.request<AnneeScolaire[]>('POST', `${this.baseEndpoint}/getByCriteria`, this.buildRequest(data));
      
      if (response.items && response.items.length > 0) {
        // Si on exclut un ID (pour la mise à jour), vérifier que ce n'est pas la même année
        if (excludeId) {
          const items = Array.isArray(response.items) ? (Array.isArray(response.items[0]) ? (response.items as unknown as any[]).flat() : response.items) : [];
          return items.some((annee: any) => annee.id !== excludeId);
        }
        return true;
      }
      return false;
    } catch (error) {
      console.error('Erreur lors de la vérification du libellé année scolaire:', error);
      return false;
    }
  }

  // Récupérer l'année scolaire courante
  async getAnneeScolaireCourante(): Promise<ApiResponse<AnneeScolaire[]>> {
    const data = {
      id: "",
      code: "",
      libelle: "",
      dateDebut: "",
      dateFin: "",
      estCourante: "true",
      createdat: "",
      createdby: "",
      updatedat: "",
      updatedby: "",
      isdeleted: "false"
    };
    
    return this.request<AnneeScolaire[]>('POST', `${this.baseEndpoint}/getByCriteria`, this.buildRequest(data));
  }

  // Récupérer les années scolaires actives (non supprimées)
  async getAnneesScolairesActives(): Promise<ApiResponse<AnneeScolaire[]>> {
    const data = {
      id: "",
      code: "",
      libelle: "",
      dateDebut: "",
      dateFin: "",
      estCourante: "",
      createdat: "",
      createdby: "",
      updatedat: "",
      updatedby: "",
      isdeleted: "false"
    };
    
    return this.request<AnneeScolaire[]>('POST', `${this.baseEndpoint}/getByCriteria`, this.buildRequest(data));
  }

  /**
   * ✅ NOUVEAU : Méthode getByCriteria pour compatibilité avec les modals
   * Récupère les années scolaires avec pagination
   */
  async getByCriteria(filters?: any, page: number = 0, size: number = 100): Promise<ApiResponse<AnneeScolaire[]>> {
    const data = {
      id: "",
      code: filters?.code || "",
      libelle: filters?.libelle || "",
      dateDebut: "",
      dateFin: "",
      estCourante: filters?.estCourante !== undefined ? filters.estCourante.toString() : "",
      createdat: "",
      createdby: "",
      updatedat: "",
      updatedby: "",
      isdeleted: "false" // Par défaut, ne récupérer que les années non supprimées
    };
    
    const request = this.buildRequest(data);
    // Ajouter la pagination si nécessaire
    if (page !== undefined && size !== undefined) {
      (request as any).index = page;
      (request as any).size = size;
    }
    
    return this.request<AnneeScolaire[]>('POST', `${this.baseEndpoint}/getByCriteria`, request);
  }
}

export const anneeScolaireService = new AnneeScolaireService();
