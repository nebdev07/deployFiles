/**
 * Commandes fournisseur DAF — CRUD + validation (stock DAF via COMMANDE_DAF).
 */

import { BaseApiService } from './base-api.service';
import type { ApiResponse } from '@/lib/types/api';

export type LigneCommandeFournisseurInput = {
  id?: number;
  /** Saisie principale : matière + niveau (lignes « catalogue », comme réception / distribution). */
  matiereId?: number;
  niveauId?: number;
  /** Référentiel technique backend (`manuel`) — optionnel si la ligne est matière + niveau seuls. */
  manuelId?: number;
  quantiteCommandee: number;
  prixUnitaire?: number;
  montant?: number;
};

export type CommandeFournisseurData = {
  id?: number;
  reference?: string;
  fournisseur?: string;
  dateCommande?: string | Date;
  dateLivraisonPrevue?: string | Date;
  anneeScolaireId?: number;
  structureDafId?: number;
  statut?: string;
  montantTotal?: number;
  lignes?: LigneCommandeFournisseurInput[];
};

export type CommandeFournisseurRow = CommandeFournisseurData & {
  anneeScolaireCode?: string;
  lignes?: Array<
    LigneCommandeFournisseurInput & {
      manuelTitre?: string;
      manuelCode?: string;
      matiereId?: number;
      niveauId?: number;
      niveauLibelle?: string;
      mouvementStockId?: number;
    }
  >;
};

class CommandeFournisseurService extends BaseApiService {
  private base = '/commandeFournisseur';

  private buildRequest(data: unknown, isCreateUpdate = false) {
    const userId = this.getCurrentUserId();
    const token = this.getAuthToken();
    if (!userId || !token) throw new Error('Utilisateur non connecté');
    const baseRequest = { user: userId, token, isSimpleLoading: false };
    if (isCreateUpdate) return { ...baseRequest, datas: [data] };
    // Toujours envoyer un objet `data` (Validate côté API exige une requête structurée pour getByCriteria)
    const payload = data != null && typeof data === 'object' ? { ...(data as object) } : {};
    return { ...baseRequest, data: payload };
  }

  async list(filters: { anneeScolaireId?: number; structureDafId?: number }): Promise<ApiResponse<CommandeFournisseurRow[]>> {
    return this.request<CommandeFournisseurRow[]>('POST', `${this.base}/getByCriteria`, this.buildRequest(filters ?? {}));
  }

  async create(payload: CommandeFournisseurData): Promise<ApiResponse<CommandeFournisseurRow[]>> {
    return this.request<CommandeFournisseurRow[]>('POST', `${this.base}/create`, this.buildRequest(payload, true));
  }

  async update(payload: CommandeFournisseurData): Promise<ApiResponse<CommandeFournisseurRow[]>> {
    return this.request<CommandeFournisseurRow[]>('POST', `${this.base}/update`, this.buildRequest(payload, true));
  }

  async remove(id: number, structureDafId?: number): Promise<ApiResponse<CommandeFournisseurRow[]>> {
    const body = structureDafId != null && structureDafId > 0 ? { id, structureDafId } : { id };
    return this.request<CommandeFournisseurRow[]>('POST', `${this.base}/delete`, this.buildRequest(body, true));
  }

  /**
   * Le backend lit `Request.data` (pas `datas` comme create/update/delete).
   * @see CommandeFournisseurController#valider
   */
  async valider(id: number, structureDafId?: number): Promise<ApiResponse<CommandeFournisseurRow[]>> {
    const body = structureDafId != null && structureDafId > 0 ? { id, structureDafId } : { id };
    return this.request<CommandeFournisseurRow[]>('POST', `${this.base}/valider`, this.buildRequest(body, false));
  }
}

export const commandeFournisseurService = new CommandeFournisseurService();
