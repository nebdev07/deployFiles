/**
 * Rapports — liste (/rapport/getByCriteria) et génération (/rapport/generate).
 * Période : année scolaire uniquement (pas de plage de dates).
 */

import { BaseApiService } from './base-api.service';
import type { ApiResponse } from '@/lib/types/api';

export type RapportCodeType =
  | 'DISTRIBUTION'
  | 'STOCK'
  | 'PLAINTES'
  | 'ENQUETE'
  | 'REGULATION'
  | 'RETOURS'
  | 'SYNTHESE';

export type RapportRow = {
  id?: number;
  reference?: string;
  titre?: string;
  typeRapport?: string;
  niveauRapport?: string;
  anneeScolaireId?: number;
  anneeScolaireLibelle?: string;
  structureId?: number;
  fichierUrl?: string;
  dateCreation?: string;
  creePar?: number;
  valide?: boolean;
  commentaire?: string;
  /** Réponse /generate uniquement */
  fichierBase64?: string;
  nomFichier?: string;
  mimeType?: string;
};

export const RAPPORT_TYPE_OPTIONS: { code: RapportCodeType; label: string; description: string }[] = [
  { code: 'SYNTHESE', label: 'Synthèse annuelle', description: 'Indicateurs agrégés (distribution, stock, plaintes, enquêtes, régulations, récupérations de manuels).' },
  { code: 'DISTRIBUTION', label: 'Distributions', description: 'Lignes de distribution par établissement et date.' },
  { code: 'STOCK', label: 'Mouvements de stock', description: 'Mouvements rattachés à l’année scolaire sélectionnée.' },
  { code: 'PLAINTES', label: 'Plaintes', description: 'Plaintes dont la date d’émission est dans l’année scolaire.' },
  { code: 'ENQUETE', label: 'Enquêtes satisfaction', description: 'Réponses aux enquêtes pour l’année scolaire.' },
  { code: 'REGULATION', label: 'Régulations', description: 'Transferts / régulations pour l’année scolaire.' },
  { code: 'RETOURS', label: 'Récupérations de manuels', description: 'Récupérations enregistrées pour l’année scolaire.' },
];

class RapportService extends BaseApiService {
  private base = '/rapport';

  async list(filters?: {
    anneeScolaireId?: number;
    typeRapport?: string;
    index?: number;
    size?: number;
  }): Promise<ApiResponse<RapportRow[]>> {
    const userId = this.getCurrentUserId();
    const token = this.getAuthToken();
    if (!userId || !token) throw new Error('Utilisateur non connecté');
    const data: Record<string, unknown> = {
      isdeleted: false,
    };
    if (filters?.anneeScolaireId != null) data.anneeScolaireId = filters.anneeScolaireId;
    if (filters?.typeRapport) data.typeRapport = filters.typeRapport;
    const req: Record<string, unknown> = {
      user: userId,
      token,
      isSimpleLoading: true,
      data,
    };
    if (filters?.index != null && filters?.size != null) {
      req.pagination = { index: filters.index, size: filters.size };
    }
    return this.request<RapportRow[]>('POST', `${this.base}/getByCriteria`, req);
  }

  /**
   * Génère un fichier (Excel ou CSV) et enregistre une entrée dans l’historique.
   */
  async generate(params: {
    codeType: RapportCodeType;
    anneeScolaireId: number;
    structureId?: number | null;
    format?: 'XLSX' | 'CSV';
  }): Promise<ApiResponse<RapportRow[]>> {
    const userId = this.getCurrentUserId();
    const token = this.getAuthToken();
    if (!userId || !token) throw new Error('Utilisateur non connecté');
    const body = {
      user: userId,
      token,
      data: {
        codeType: params.codeType,
        anneeScolaireId: params.anneeScolaireId,
        structureId: params.structureId ?? undefined,
        format: params.format ?? 'XLSX',
      },
    };
    return this.request<RapportRow[]>('POST', `${this.base}/generate`, body);
  }
}

export const rapportService = new RapportService();

/** Déclenche le téléchargement d’un fichier à partir du base64 renvoyé par /generate. */
export function downloadRapportFile(row: RapportRow): void {
  if (!row.fichierBase64 || !row.nomFichier) return;
  const bin = atob(row.fichierBase64);
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  const mime = row.mimeType?.split(';')[0]?.trim() || 'application/octet-stream';
  const blob = new Blob([bytes], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = row.nomFichier;
  a.click();
  URL.revokeObjectURL(url);
}
