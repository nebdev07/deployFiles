/**
 * Service pour la gestion des besoins (Expression des Besoins)
 * Gère la création, modification, validation, consolidation et approbation des besoins
 */

import { BaseApiService } from './base-api.service';

// Interface pour les réponses du backend Spring Boot
interface BackendResponse<T> {
  item?: T;
  items?: T[];
  hasError: boolean;
  message?: string;
  status?: {
    code: string;
    message: string;
  };
  count?: number;
}

// Types pour les besoins
export interface BesoinData {
  id?: number;
  reference?: string;
  structureId: number;
  niveauScolaireId: number;
  anneeScolaireId: number;
  effectifGarcons?: number;
  effectifFilles?: number;
  effectifTotal: number;
  statut?: string; // SAISI, VALIDE, CONSOLIDE, APPROUVE
  commentaire?: string;
  besoinDetails?: BesoinDetailData[];
}

export interface BesoinDetailData {
  id?: number;
  besoinId?: number;
  matiereId: number;
  niveauScolaireId?: number;
  /** Effectif total saisi pour ce niveau (préféré côté API à G/F sur le détail) */
  effectifTotalNiveau?: number;
  effectifGarcons?: number;
  effectifFilles?: number;
  quantiteBrute: number;
  quantiteRetourAnneePrecedente?: number;
  quantiteNet?: number;
  quantiteConsolidee?: number;
  quantiteApprouvee?: number;
  observations?: string;
}

export interface BesoinResponse {
  id: number;
  reference: string;
  structureId: number;
  structureAdministrativeId?: number;
  structureAdministrativeCode?: string;
  structureAdministrativeLibelle?: string;
  structureType?: string; // "IEPP", "EPP", "DRENA", "MENA"
  niveauScolaireId: number;
  niveauScolaireCode?: string;
  niveauScolaireLibelle?: string;
  anneeScolaireId: number;
  anneeScolaireCode?: string;
  anneeScolaireLibelle?: string;
  effectifGarcons: number;
  effectifFilles: number;
  effectifTotal: number;
  statut: string;
  dateSaisie?: string;
  saisiPar?: number;
  saisiParFirstName?: string;
  saisiParLastName?: string;
  dateValidation?: string;
  validePar?: number;
  valideParFirstName?: string;
  valideParLastName?: string;
  dateConsolidation?: string;
  consolidePar?: number;
  consolideParFirstName?: string;
  consolideParLastName?: string;
  dateApprobation?: string;
  approuvePar?: number;
  approuveParFirstName?: string;
  approuveParLastName?: string;
  commentaire?: string;
  besoinDetails?: BesoinDetailResponse[];
  createdat?: string;
  createdby?: number;
  updatedat?: string;
  updatedby?: number;
  isdeleted?: boolean;
}

export interface BesoinDetailResponse {
  id: number;
  besoinId: number;
  matiereId: number;
  niveauScolaireId?: number;
  niveauScolaireCode?: string;
  niveauScolaireLibelle?: string;
  /** Total élèves pour ce niveau (API : aligné sur G+F en base) */
  effectifTotalNiveau?: number;
  effectifGarcons?: number;
  effectifFilles?: number;
  matiereCode?: string;
  matiereLibelle?: string;
  quantiteBrute: number;
  quantiteRetourAnneePrecedente: number;
  quantiteNet: number;
  quantiteConsolidee?: number;
  quantiteApprouvee?: number;
  observations?: string;
  createdat?: string;
  createdby?: number;
  updatedat?: string;
  updatedby?: number;
  isdeleted?: boolean;
}

export class BesoinsService extends BaseApiService {
  private serviceBaseUrl = `/besoin`;

  /**
   * Construit la requête selon le pattern du backend
   * @param data - Les données à envoyer
   * @param isCreateUpdate - Si true, utilise "datas" (tableau), sinon "data" (objet)
   * @param userId - ID utilisateur optionnel (si non fourni, récupéré depuis localStorage)
   * @param token - Token optionnel (si non fourni, récupéré depuis localStorage)
   */
  private buildRequest<T>(data: T | T[], isCreateUpdate: boolean = true, userId?: number, token?: string): any {
    // Si userId et token ne sont pas fournis, les récupérer depuis localStorage
    const finalUserId = userId ?? this.getCurrentUserId();
    const finalToken = token ?? this.getAuthToken();
    
    // Vérifier si l'utilisateur est connecté
    if (!finalUserId || !finalToken) {
      console.warn('Utilisateur non connecté - impossible de gérer les besoins', {
        userId: finalUserId,
        token: finalToken ? 'présent' : 'absent',
        localStorageKeys: typeof window !== 'undefined' ? {
          dismas_user: localStorage.getItem('dismas_user'),
          user_session: localStorage.getItem('user_session'),
          auth_token: localStorage.getItem('auth_token')
        } : 'N/A (SSR)'
      });
      throw new Error('Utilisateur non connecté. Veuillez vous reconnecter.');
    }
    
    const baseRequest = {
      user: finalUserId,
      token: finalToken,
      isSimpleLoading: false
    };
    
    if (isCreateUpdate) {
      // Pour CREATE/UPDATE/DELETE, utiliser "datas" avec un tableau
      return {
        ...baseRequest,
        datas: Array.isArray(data) ? data : [data]
      };
    } else {
      // Pour GET/SEARCH, utiliser "data" avec un objet
      return {
        ...baseRequest,
        data: data
      };
    }
  }

  /**
   * Crée un nouveau besoin
   * @param besoinData - Les données du besoin à créer
   * @param userId - ID utilisateur optionnel (si non fourni, récupéré depuis localStorage)
   * @param token - Token optionnel (si non fourni, récupéré depuis localStorage)
   */
  async create(besoinData: BesoinData, userId?: number, token?: string): Promise<{ success: boolean; data?: BesoinResponse; message: string }> {
    console.log('🔵 [SERVICE] create() - DÉBUT')
    console.log('🔵 [SERVICE] besoinData:', JSON.stringify(besoinData, null, 2))
    console.log('🔵 [SERVICE] userId:', userId)
    console.log('🔵 [SERVICE] token présent:', !!token)
    
    try {
      console.log('🔵 [SERVICE] Construction de la requête...')
      const requestData = this.buildRequest(besoinData, true, userId, token);
      console.log('🔵 [SERVICE] requestData:', JSON.stringify(requestData, null, 2))
      
      console.log('🔵 [SERVICE] Appel this.post()...')
      const response = await this.post<BackendResponse<BesoinResponse>>(
        `${this.serviceBaseUrl}/create`,
        requestData
      );
      console.log('🟢 [SERVICE] Réponse reçue du backend')
      console.log('🟢 [SERVICE] response (type):', typeof response)
      console.log('🟢 [SERVICE] response (valeur):', response)
      console.log('🟢 [SERVICE] response (JSON):', JSON.stringify(response, null, 2))
      console.log('🟢 [SERVICE] response.hasError:', response?.hasError)
      console.log('🟢 [SERVICE] response.items:', response?.items)
      console.log('🟢 [SERVICE] response.items?.length:', response?.items?.length)
      console.log('🟢 [SERVICE] response.status:', response?.status)

      if (response.hasError || !response.items || response.items.length === 0) {
        console.log('🟡 [SERVICE] Réponse avec erreur ou items vides')
        console.log('🟡 [SERVICE] hasError:', response.hasError)
        console.log('🟡 [SERVICE] items:', response.items)
        const errorMsg = response.status?.message || 'Erreur lors de la création du besoin';
        console.log('🟡 [SERVICE] Message d\'erreur:', errorMsg)
        return {
          success: false,
          message: errorMsg,
        };
      }

      console.log('🟢 [SERVICE] Réponse OK, retour du succès')
      const result = {
        success: true,
        data: response.items[0] as unknown as BesoinResponse,
        message: 'Besoin créé avec succès',
      };
      console.log('🟢 [SERVICE] Résultat à retourner:', JSON.stringify(result, null, 2))
      return result;
    } catch (error: any) {
      console.error('🔴 [SERVICE] Erreur dans create()');
      console.error('🔴 [SERVICE] error (type):', typeof error);
      console.error('🔴 [SERVICE] error (valeur):', error);
      console.error('🔴 [SERVICE] error (JSON):', JSON.stringify(error, null, 2));
      console.error('🔴 [SERVICE] error?.message:', error?.message);
      console.error('🔴 [SERVICE] error?.toString():', error?.toString());
      console.error('🔴 [SERVICE] error?.code:', error?.code);
      console.error('🔴 [SERVICE] error?.details:', error?.details);
      console.error('🔴 [SERVICE] error?.details?.status:', error?.details?.status);
      console.error('🔴 [SERVICE] error?.details?.status?.message:', error?.details?.status?.message);
      
      // ✅ CORRECTION : S'assurer de toujours retourner un objet valide
      // Si l'erreur est "Utilisateur non connecté", retourner un message clair
      if (error?.message && error.message.includes('Utilisateur non connecté')) {
        console.log('🟡 [SERVICE] Erreur: Utilisateur non connecté');
        return {
          success: false,
          message: 'Session expirée. Veuillez vous reconnecter.',
        };
      }
      
      // ✅ CORRECTION : Extraire le message depuis error.details.status.message si disponible
      // (car base-api.service.ts lance une erreur avec details contenant la réponse complète)
      let errorMessage = error?.message;
      if (!errorMessage && error?.details?.status?.message) {
        errorMessage = error.details.status.message;
        console.log('🟡 [SERVICE] Message extrait depuis error.details.status.message:', errorMessage);
      }
      if (!errorMessage && error?.details?.message) {
        errorMessage = error.details.message;
        console.log('🟡 [SERVICE] Message extrait depuis error.details.message:', errorMessage);
      }
      if (!errorMessage) {
        errorMessage = error?.toString() || 'Erreur inconnue lors de la création du besoin';
      }
      
      console.log('🟡 [SERVICE] Message d\'erreur final:', errorMessage);
      const errorResult = {
        success: false,
        message: errorMessage,
      };
      console.log('🟡 [SERVICE] Résultat d\'erreur à retourner:', JSON.stringify(errorResult, null, 2));
      return errorResult;
    }
  }

  /**
   * Met à jour un besoin existant
   * @param besoinData - Les données du besoin à mettre à jour
   * @param userId - ID utilisateur optionnel (si non fourni, récupéré depuis localStorage)
   * @param token - Token optionnel (si non fourni, récupéré depuis localStorage)
   */
  async update(besoinData: BesoinData, userId?: number, token?: string): Promise<{ success: boolean; data?: BesoinResponse; message: string }> {
    console.log('🔵 [SERVICE] update() - DÉBUT')
    console.log('🔵 [SERVICE] besoinData:', JSON.stringify(besoinData, null, 2))
    console.log('🔵 [SERVICE] userId:', userId)
    console.log('🔵 [SERVICE] token présent:', !!token)
    
    try {
      if (!besoinData.id) {
        console.log('🟡 [SERVICE] ID manquant')
        return {
          success: false,
          message: 'ID du besoin requis pour la mise à jour',
        };
      }

      console.log('🔵 [SERVICE] Construction de la requête...')
      const requestData = this.buildRequest(besoinData, true, userId, token);
      console.log('🔵 [SERVICE] requestData:', JSON.stringify(requestData, null, 2))
      
      console.log('🔵 [SERVICE] Appel this.post()...')
      const response = await this.post<BackendResponse<BesoinResponse>>(
        `${this.serviceBaseUrl}/update`,
        requestData
      );
      console.log('🟢 [SERVICE] Réponse reçue du backend')
      console.log('🟢 [SERVICE] response (type):', typeof response)
      console.log('🟢 [SERVICE] response (valeur):', response)
      console.log('🟢 [SERVICE] response (JSON):', JSON.stringify(response, null, 2))
      console.log('🟢 [SERVICE] response.hasError:', response?.hasError)
      console.log('🟢 [SERVICE] response.items:', response?.items)
      console.log('🟢 [SERVICE] response.items?.length:', response?.items?.length)

      if (response.hasError || !response.items || response.items.length === 0) {
        console.log('🟡 [SERVICE] Réponse avec erreur ou items vides')
        const errorMsg = response.status?.message || 'Erreur lors de la mise à jour du besoin';
        return {
          success: false,
          message: errorMsg,
        };
      }

      console.log('🟢 [SERVICE] Réponse OK, retour du succès')
      const result: { success: boolean; data?: BesoinResponse; message: string } = {
        success: true,
        data: response.items[0] as unknown as BesoinResponse,
        message: 'Besoin mis à jour avec succès',
      };
      console.log('🟢 [SERVICE] Résultat à retourner:', JSON.stringify(result, null, 2))
      return result;
    } catch (error: any) {
      console.error('🔴 [SERVICE] Erreur dans update()');
      console.error('🔴 [SERVICE] error (type):', typeof error);
      console.error('🔴 [SERVICE] error (valeur):', error);
      console.error('🔴 [SERVICE] error (JSON):', JSON.stringify(error, null, 2));
      console.error('🔴 [SERVICE] error?.message:', error?.message);
      console.error('🔴 [SERVICE] error?.toString():', error?.toString());
      console.error('🔴 [SERVICE] error?.details?.status?.message:', error?.details?.status?.message);
      
      // ✅ CORRECTION : S'assurer de toujours retourner un objet valide
      if (error?.message && error.message.includes('Utilisateur non connecté')) {
        return {
          success: false,
          message: 'Session expirée. Veuillez vous reconnecter.',
        };
      }
      
      // ✅ CORRECTION : Extraire le message depuis error.details.status.message si disponible
      let errorMessage = error?.message;
      if (!errorMessage && error?.details?.status?.message) {
        errorMessage = error.details.status.message;
        console.log('🟡 [SERVICE] Message extrait depuis error.details.status.message:', errorMessage);
      }
      if (!errorMessage && error?.details?.message) {
        errorMessage = error.details.message;
        console.log('🟡 [SERVICE] Message extrait depuis error.details.message:', errorMessage);
      }
      if (!errorMessage) {
        errorMessage = error?.toString() || 'Erreur inconnue lors de la mise à jour du besoin';
      }
      
      const errorResult = {
        success: false,
        message: errorMessage,
      };
      console.log('🟡 [SERVICE] Résultat d\'erreur à retourner:', JSON.stringify(errorResult, null, 2));
      return errorResult;
    }
  }

  /**
   * Supprime un besoin (nommé deleteBesoin pour ne pas écraser BaseApiService.delete)
   */
  async deleteBesoin(besoinId: number): Promise<{ success: boolean; message: string }> {
    try {
      const requestData = this.buildRequest({ id: besoinId }, true);
      const response = await this.post<BackendResponse<BesoinResponse>>(
        `${this.serviceBaseUrl}/delete`,
        requestData
      );

      if (response.hasError) {
        return {
          success: false,
          message: response.status?.message || 'Erreur lors de la suppression du besoin',
        };
      }

      return {
        success: true,
        message: 'Besoin supprimé avec succès',
      };
    } catch (error: any) {
      console.error('❌ Erreur lors de la suppression du besoin:', error);
      return {
        success: false,
        message: error.message || 'Erreur lors de la suppression du besoin',
      };
    }
  }

  /**
   * ✅ NOUVEAU : Récupère les Besoins approuvés pour une structure
   * Utilisé pour charger un Mouvement depuis un Besoin approuvé
   */
  /**
   * ✅ NOUVEAU : Récupère les besoins approuvés pour la réception
   * Utilise le nouvel endpoint dédié /besoin/getForReception
   * Respecte le pattern standard avec Request<BesoinDto>
   * 
   * @param structureId ID de la StructureAdministrative (optionnel)
   * @param anneeScolaireId ID de l'année scolaire (optionnel)
   * @param structureType Type de structure ("IEPP" ou "EPP") - requis pour identifier la vraie structure
   * @returns Promise avec les besoins approuvés enrichis avec besoinDetails
   */
  async getBesoinsApprouves(structureId?: number, anneeScolaireId?: number, structureType?: string): Promise<{ success: boolean; data?: BesoinResponse[]; message: string }> {
    try {
      console.log('🔵 [SERVICE] getBesoinsApprouves() - DÉBUT');
      console.log('🔵 [SERVICE] structureId:', structureId);
      console.log('🔵 [SERVICE] anneeScolaireId:', anneeScolaireId);
      console.log('🔵 [SERVICE] structureType:', structureType);

      // Construire la requête avec le pattern standard Request<BesoinDto>
      // data doit être un BesoinDto avec structureId, anneeScolaireId et structureType
      // structureType est nécessaire pour récupérer la vraie valeur de l'ID de la structure
      const baseRequest = this.buildRequest({}, false);
      const requestData = {
        ...baseRequest,
        isSimpleLoading: false,
        data: {
          structureId: structureId || undefined,
          anneeScolaireId: anneeScolaireId || undefined,
          structureType: structureType || undefined,
        } as BesoinResponse,
      };

      console.log('🔵 [SERVICE] requestData:', requestData);
      console.log('🔵 [SERVICE] Appel this.post()...');
      
      // Utiliser POST avec Request<BesoinDto> (pattern standard comme getByCriteria)
      const response = await this.post<BackendResponse<BesoinResponse>>(
        `${this.serviceBaseUrl}/getForReception`,
        requestData
      )

      console.log('🟢 [SERVICE] Réponse reçue')
      console.log('🟢 [SERVICE] response (type):', typeof response)
      console.log('🟢 [SERVICE] response (valeur):', response)
      console.log('🟢 [SERVICE] response.hasError:', response?.hasError)
      console.log('🟢 [SERVICE] response.items:', response?.items)

      if (!response || response === null || response === undefined) {
        console.error('❌ [SERVICE] Réponse null/undefined du backend')
        return {
          success: false,
          message: 'Réponse invalide du serveur',
        }
      }

      if (response.hasError) {
        console.log('🟡 [SERVICE] Réponse avec erreur')
        return {
          success: false,
          message: response.status?.message || 'Erreur lors de la récupération des besoins approuvés',
        }
      }

      const successResult: { success: boolean; data?: BesoinResponse[]; message: string } = {
        success: true,
        data: (response.items || []) as unknown as BesoinResponse[],
        message: response.status?.message || 'Besoins approuvés récupérés avec succès',
      }
      
      console.log('🟢 [SERVICE] Retour succès:', successResult)
      console.log('🟢 [SERVICE] Nombre de besoins:', successResult.data?.length || 0)
      
      return successResult
    } catch (error: any) {
      console.error('❌ [SERVICE] Erreur lors de la récupération des Besoins approuvés:', error)
      let errorMessage = 'Erreur lors de la récupération des Besoins approuvés'
      if (error?.details?.status?.message) {
        errorMessage = error.details.status.message
      } else if (error?.message) {
        errorMessage = error.message
      }
      return {
        success: false,
        message: errorMessage,
      }
    }
  }

  /**
   * Récupère les besoins selon des critères
   */
  async getByCriteria(criteria: any, index: number = 0, size: number = 100): Promise<{
    success: boolean;
    data?: BesoinResponse[];
    count?: number;
    message: string;
  }> {
    console.log('🔵 [SERVICE] getByCriteria() - DÉBUT')
    console.log('🔵 [SERVICE] criteria:', JSON.stringify(criteria, null, 2))
    console.log('🔵 [SERVICE] index:', index, 'size:', size)
    
    try {
      const userId = this.getCurrentUserId();
      const token = this.getAuthToken();
      console.log('🔵 [SERVICE] userId:', userId, 'token présent:', !!token)
      
      // Vérifier si l'utilisateur est connecté
      if (!userId || !token) {
        console.log('🟡 [SERVICE] Utilisateur non connecté')
        return {
          success: false,
          message: 'Utilisateur non connecté',
        };
      }

      // Retirer isdeleted du critère (géré en backend)
      const { isdeleted, ...cleanCriteria } = criteria;
      console.log('🔵 [SERVICE] cleanCriteria:', JSON.stringify(cleanCriteria, null, 2))

      const requestData = {
        user: userId,
        token: token,
        isSimpleLoading: false,
        index: index,
        size: size,
        data: cleanCriteria,
      };
      console.log('🔵 [SERVICE] requestData:', JSON.stringify(requestData, null, 2))

      console.log('🔵 [SERVICE] Appel this.post()...')
      const response = await this.post<BackendResponse<BesoinResponse>>(
        `${this.serviceBaseUrl}/getByCriteria`,
        requestData
      );
      console.log('🟢 [SERVICE] Réponse reçue')
      console.log('🟢 [SERVICE] response.hasError:', response?.hasError)
      console.log('🟢 [SERVICE] response.items:', response?.items)
      console.log('🟢 [SERVICE] response.items?.length:', response?.items?.length)

      if (response.hasError) {
        console.log('🟡 [SERVICE] Réponse avec erreur')
        const errorMsg = response.status?.message || 'Erreur lors de la récupération des besoins';
        return {
          success: false,
          message: errorMsg,
        };
      }

      console.log('🟢 [SERVICE] Réponse OK, retour du succès')
      const resp = response as unknown as BackendResponse<BesoinResponse>
      const result = {
        success: true,
        data: (resp.items || []) as unknown as BesoinResponse[],
        count: resp.count ?? 0,
        message: 'Besoins récupérés avec succès',
      };
      console.log('🟢 [SERVICE] Résultat à retourner:', JSON.stringify(result, null, 2))
      return result;
    } catch (error: any) {
      console.error('🔴 [SERVICE] Erreur dans getByCriteria()');
      console.error('🔴 [SERVICE] error (type):', typeof error);
      console.error('🔴 [SERVICE] error (valeur):', error);
      console.error('🔴 [SERVICE] error (JSON):', JSON.stringify(error, null, 2));
      console.error('🔴 [SERVICE] error?.message:', error?.message);
      const errorMessage = error?.message || error?.toString() || 'Erreur lors de la récupération des besoins';
      const errorResult = {
        success: false,
        message: errorMessage,
      };
      console.log('🟡 [SERVICE] Résultat d\'erreur à retourner:', JSON.stringify(errorResult, null, 2));
      return errorResult;
    }
  }

  /**
   * ✅ NOUVEAU : Récupère les détails complets d'un besoin (avec BesoinDetail)
   * Utilise le nouvel endpoint /besoin/details/{id} pour garantir le chargement des détails
   * Cohérent avec /mouvement/getWithDetails/{id} qui retourne items (array)
   */
  async getDetails(besoinId: number): Promise<{ success: boolean; data?: BesoinResponse; message: string }> {
    try {
      console.log(`📋 Récupération détails besoin ${besoinId}`);

      // ✅ NOUVEAU : appel direct du nouvel endpoint de détails
      const response: any = await this.get(
        `${this.serviceBaseUrl}/details/${besoinId}`
      );
      
      // ✅ COHÉRENT : Utiliser items (array) comme getMouvementWithDetails
      if (!response.hasError && response.items && response.items.length > 0) {
        const besoinComplet = response.items[0];
        console.log('✅ Détails besoin récupérés:', besoinComplet);
        console.log('  - BesoinDetails:', besoinComplet.besoinDetails?.length || 0);
        return {
          success: true,
          data: besoinComplet,
          message: 'Détails du besoin récupérés avec succès',
        };
      } else {
        console.warn('⚠️ Aucun détail trouvé:', response.status?.message);
        return {
          success: false,
          message: response.status?.message || 'Besoin non trouvé',
        };
      }
    } catch (error: any) {
      console.error('❌ Erreur lors de la récupération des détails du besoin:', error);
      return {
        success: false,
        message: error.message || 'Erreur lors de la récupération des détails du besoin',
      };
    }
  }

  /**
   * ✅ NOUVEAU : Récupère les détails de consolidation IEPP
   * Utilise le nouvel endpoint /besoin/consolidationDetails/{ieppId}
   * Retourne tous les besoins EPP validés avec leurs matières et quantités pour un IEPP
   * 
   * @param ieppId ID de l'IEPP
   * @returns Liste des besoins EPP avec leurs BesoinDetails
   */
  async getConsolidationDetails(ieppId: number): Promise<{ success: boolean; data?: BesoinResponse[]; message: string }> {
    console.log('🔵 [SERVICE-CONSOLIDATION] ========== getConsolidationDetails DÉBUT ==========')
    console.log('🔵 [SERVICE-CONSOLIDATION] ieppId:', ieppId)
    console.log('🔵 [SERVICE-CONSOLIDATION] typeof ieppId:', typeof ieppId)
    console.log('🔵 [SERVICE-CONSOLIDATION] this.serviceBaseUrl:', this.serviceBaseUrl)
    console.log('🔵 [SERVICE-CONSOLIDATION] URL complète:', `${this.serviceBaseUrl}/consolidationDetails/${ieppId}`)
    
    try {
      console.log(`📋 [SERVICE-CONSOLIDATION] Récupération détails consolidation IEPP ${ieppId}`);

      // ✅ NOUVEAU : appel direct du nouvel endpoint de détails de consolidation
      console.log('🔵 [SERVICE-CONSOLIDATION] Appel this.get()...')
      const response: any = await this.get(
        `${this.serviceBaseUrl}/consolidationDetails/${ieppId}`
      );
      console.log('🟢 [SERVICE-CONSOLIDATION] ✅ Réponse reçue de this.get()')
      
      console.log('🔵 [SERVICE] getConsolidationDetails - Réponse reçue');
      console.log('🔵 [SERVICE] response.hasError:', response.hasError);
      console.log('🔵 [SERVICE] response.items:', response.items);
      console.log('🔵 [SERVICE] response.items?.length:', response.items?.length);
      
      // ✅ COHÉRENT : Utiliser items (array) comme getDetails
      if (!response.hasError && response.items) {
        console.log('✅ Détails consolidation IEPP récupérés:', response.items.length, 'besoins');
        // Logger les détails de chaque besoin
        response.items.forEach((besoin: any, index: number) => {
          console.log(`  - Besoin ${index + 1}:`, besoin.structureAdministrativeLibelle, '- BesoinDetails:', besoin.besoinDetails?.length || 0);
        });
        return {
          success: true,
          data: (response.items || []) as unknown as BesoinResponse[],
          message: 'Détails de consolidation IEPP récupérés avec succès',
        };
      } else {
        console.warn('⚠️ Aucun détail de consolidation trouvé:', response.status?.message);
        return {
          success: false,
          data: [],
          message: response.status?.message || 'Aucun besoin validé trouvé pour cet IEPP',
        };
      }
    } catch (error: any) {
      console.error('❌ Erreur lors de la récupération des détails de consolidation IEPP:', error);
      return {
        success: false,
        data: [],
        message: error.message || 'Erreur lors de la récupération des détails de consolidation IEPP',
      };
    }
  }

  /**
   * Récupère la quantité retournée pour l'année N-1
   */
  async getQuantiteRetourAnneeN1(
    structureId: number,
    niveauId: number,
    matiereId: number,
    anneeScolaireId: number
  ): Promise<{ success: boolean; data?: number; message: string }> {
    try {
      const response = await this.get<BackendResponse<number>>(
        `/retourManuel/getQuantiteRetourAnneeN1?structureId=${structureId}&niveauId=${niveauId}&matiereId=${matiereId}&anneeScolaireId=${anneeScolaireId}`
      );

      if (response.hasError) {
        return {
          success: false,
          message: response.status?.message || 'Erreur lors de la récupération des retours N-1',
        };
      }

      const resp = response as unknown as BackendResponse<number>
      return {
        success: true,
        data: resp.item ?? resp.items?.[0] ?? 0,
        message: 'Quantité retournée année N-1 récupérée avec succès',
      };
    } catch (error: any) {
      console.error('❌ Erreur lors de la récupération des retours N-1:', error);
      return {
        success: false,
        message: error.message || 'Erreur lors de la récupération des retours N-1',
      };
    }
  }

  /**
   * Consolide les besoins EPP d'un IEPP
   */
  async consolidate(
    ieppId: number,
    anneeScolaireId: number,
    consolidePar: number
  ): Promise<{ success: boolean; data?: BesoinResponse[]; message: string }> {
    console.log('🔵 [SERVICE-CONSOLIDATE] Début de consolidate()');
    try {
      // Le backend attend les paramètres dans l'URL
      console.log('🔵 [SERVICE-CONSOLIDATE] Appel this.post()...');
      const response = await this.post<BackendResponse<BesoinResponse>>(
        `${this.serviceBaseUrl}/consolidate?ieppId=${ieppId}&anneeScolaireId=${anneeScolaireId}&consolidePar=${consolidePar}`,
        this.buildRequest({}, false)
      );

      console.log('🔵 [SERVICE-CONSOLIDATE] Réponse reçue');
      console.log('🔵 [SERVICE-CONSOLIDATE] response (type):', typeof response);
      console.log('🔵 [SERVICE-CONSOLIDATE] response (valeur):', response);
      console.log('🔵 [SERVICE-CONSOLIDATE] response === null:', response === null);
      console.log('🔵 [SERVICE-CONSOLIDATE] response === undefined:', response === undefined);

      // ✅ CORRECTION : Vérifier que la réponse n'est pas null/undefined
      if (!response) {
        console.error('❌ [SERVICE-CONSOLIDATE] Réponse null/undefined du backend');
        return {
          success: false,
          message: 'Réponse invalide du serveur',
        };
      }

      if (response.hasError) {
        console.log('🟡 [SERVICE-CONSOLIDATE] Réponse avec erreur');
        const errorResult = {
          success: false,
          message: response.status?.message || 'Erreur lors de la consolidation',
        };
        console.log('🟡 [SERVICE-CONSOLIDATE] Retour:', errorResult);
        return errorResult;
      }

      const successResult: { success: boolean; data?: BesoinResponse[]; message: string } = {
        success: true,
        data: (response.items || []) as unknown as BesoinResponse[],
        message: 'Consolidation réussie',
      };
      console.log('🟢 [SERVICE-CONSOLIDATE] Retour succès:', successResult);
      return successResult;
    } catch (error: any) {
      console.error('❌ [SERVICE-CONSOLIDATE] Erreur dans catch:', error);
      let errorMessage = 'Erreur lors de la consolidation';
      if (error?.details?.status?.message) {
        errorMessage = error.details.status.message;
      } else if (error?.message) {
        errorMessage = error.message;
      }
      const errorResult = {
        success: false,
        message: errorMessage,
      };
      console.log('🔴 [SERVICE-CONSOLIDATE] Retour erreur:', errorResult);
      return errorResult;
    }
  }

  /**
   * Approuve des besoins consolidés (DAF)
   * @param besoinIds - Liste des IDs des besoins à approuver
   * @param approuvePar - ID de l'utilisateur qui approuve
   * @param tauxGlobal - Taux global à appliquer (optionnel, entre 0 et 1, ex: 0.8 pour 80%)
   * @param quantitesApprouvees - Map<besoinDetailId, quantiteApprouvee> pour modifications manuelles (optionnel)
   * @param userId - ID utilisateur optionnel (si non fourni, récupéré depuis localStorage)
   * @param token - Token optionnel (si non fourni, récupéré depuis localStorage)
   */
  async approve(
    besoinIds: number[],
    approuvePar: number,
    tauxGlobal?: number,
    quantitesApprouvees?: Map<number, number>,
    exceptionsEpp?: Map<number, Map<number, number>>,
    userId?: number,
    token?: string
  ): Promise<{ success: boolean; data?: BesoinResponse[]; message: string }> {
    console.log('🔵 [SERVICE-APPROVE] ========== approve() DÉBUT ==========')
    console.log('🔵 [SERVICE-APPROVE] besoinIds:', besoinIds)
    console.log('🔵 [SERVICE-APPROVE] approuvePar:', approuvePar)
    console.log('🔵 [SERVICE-APPROVE] tauxGlobal:', tauxGlobal)
    console.log('🔵 [SERVICE-APPROVE] quantitesApprouvees:', quantitesApprouvees)
    console.log('🔵 [SERVICE-APPROVE] exceptionsEpp:', exceptionsEpp)
    console.log('🔵 [SERVICE-APPROVE] userId:', userId)
    console.log('🔵 [SERVICE-APPROVE] token présent:', !!token)
    
    try {
      // ✅ CORRECTION: Passer userId et token explicitement à buildRequest
      const baseRequest = this.buildRequest({}, false, userId, token);
      
      // ✅ NOUVEAU : Convertir Map en objet pour l'envoi au backend
      const quantitesApprouveesObj: { [key: number]: number } | undefined = quantitesApprouvees 
        ? Object.fromEntries(quantitesApprouvees) 
        : undefined;
      
      // ✅ NOUVEAU : Convertir Map<eppId, Map<matiereId, quantite>> en objet imbriqué
      const exceptionsEppObj: { [eppId: number]: { [matiereId: number]: number } } | undefined = exceptionsEpp && exceptionsEpp.size > 0
        ? Object.fromEntries(
            Array.from(exceptionsEpp.entries()).map(([eppId, matiereMap]) => [
              eppId,
              Object.fromEntries(matiereMap)
            ])
          )
        : undefined;
      
      const requestData = {
        ...baseRequest,
        besoinIds: besoinIds,
        approuvePar: approuvePar,
        tauxGlobal: tauxGlobal,
        quantitesApprouvees: quantitesApprouveesObj,
        exceptionsEpp: exceptionsEppObj,
      };
      
      console.log('🔵 [SERVICE-APPROVE] requestData:', requestData)
      console.log('🔵 [SERVICE-APPROVE] Appel this.post()...')
      const response = await this.post<BackendResponse<BesoinResponse>>(
        `${this.serviceBaseUrl}/approve`,
        requestData
      );
      
      console.log('🟢 [SERVICE-APPROVE] Réponse reçue')
      console.log('🟢 [SERVICE-APPROVE] response (type):', typeof response)
      console.log('🟢 [SERVICE-APPROVE] response (valeur):', response)
      console.log('🟢 [SERVICE-APPROVE] response === null:', response === null)
      console.log('🟢 [SERVICE-APPROVE] response === undefined:', response === undefined)
      console.log('🟢 [SERVICE-APPROVE] response.hasError:', response?.hasError)
      console.log('🟢 [SERVICE-APPROVE] response.items:', response?.items)

      // ✅ CORRECTION: Vérifier que response n'est pas null/undefined
      if (!response || response === null || response === undefined) {
        console.error('❌ [SERVICE-APPROVE] Réponse null/undefined du backend')
        return {
          success: false,
          message: 'Réponse invalide du serveur',
        };
      }

      if (response.hasError) {
        console.log('🟡 [SERVICE-APPROVE] Réponse avec erreur')
        return {
          success: false,
          message: response.status?.message || 'Erreur lors de l\'approbation',
        };
      }

      const successResult: { success: boolean; data?: BesoinResponse[]; message: string } = {
        success: true,
        data: (response.items || []) as unknown as BesoinResponse[],
        message: 'Approbation réussie',
      };
      console.log('🟢 [SERVICE-APPROVE] Retour succès:', successResult)
      return successResult;
    } catch (error: any) {
      console.error('❌ [SERVICE-APPROVE] Erreur dans catch:', error);
      let errorMessage = 'Erreur lors de l\'approbation';
      if (error?.details?.status?.message) {
        errorMessage = error.details.status.message;
      } else if (error?.message) {
        errorMessage = error.message;
      }
      const errorResult = { success: false, message: errorMessage };
      console.log('🔴 [SERVICE-APPROVE] Retour erreur:', errorResult);
      return errorResult;
    } finally {
      console.log('🔵 [SERVICE-APPROVE] ========== approve() FIN ==========')
    }
  }

  /**
   * ✅ NOUVEAU : Prévisualise l'approbation DAF avec taux global et modifications manuelles
   * Retourne un récapitulatif avant validation
   * @param besoinIds - Liste des IDs des besoins à prévisualiser
   * @param tauxGlobal - Taux global à appliquer (optionnel, entre 0 et 1)
   * @param quantitesApprouvees - Map<besoinDetailId, quantiteApprouvee> pour modifications manuelles (optionnel)
   */
  async previewApprove(
    besoinIds: number[],
    tauxGlobal?: number,
    quantitesApprouvees?: Map<number, number>,
    exceptionsEpp?: Map<number, Map<number, number>>
  ): Promise<{ success: boolean; data?: any; message: string }> {
    console.log('🔵 [SERVICE-PREVIEW] ========== previewApprove() DÉBUT ==========')
    console.log('🔵 [SERVICE-PREVIEW] besoinIds:', besoinIds)
    console.log('🔵 [SERVICE-PREVIEW] tauxGlobal:', tauxGlobal)
    console.log('🔵 [SERVICE-PREVIEW] quantitesApprouvees:', quantitesApprouvees)
    console.log('🔵 [SERVICE-PREVIEW] exceptionsEpp:', exceptionsEpp)
    
    try {
      const baseRequest = this.buildRequest({}, false);
      
      // Convertir Map en objet pour l'envoi au backend
      const quantitesApprouveesObj: { [key: number]: number } | undefined = quantitesApprouvees 
        ? Object.fromEntries(quantitesApprouvees) 
        : undefined;
      
      // ✅ NOUVEAU : Convertir Map<eppId, Map<matiereId, quantite>> en objet imbriqué
      const exceptionsEppObj: { [eppId: number]: { [matiereId: number]: number } } | undefined = exceptionsEpp && exceptionsEpp.size > 0
        ? Object.fromEntries(
            Array.from(exceptionsEpp.entries()).map(([eppId, matiereMap]) => [
              eppId,
              Object.fromEntries(matiereMap)
            ])
          )
        : undefined;
      
      const requestData = {
        ...baseRequest,
        besoinIds: besoinIds,
        tauxGlobal: tauxGlobal,
        quantitesApprouvees: quantitesApprouveesObj,
        exceptionsEpp: exceptionsEppObj,
      };
      
      console.log('🔵 [SERVICE-PREVIEW] requestData:', requestData)
      console.log('🔵 [SERVICE-PREVIEW] Appel this.post()...')
      const response = await this.post<any>(
        `${this.serviceBaseUrl}/previewApprove`,
        requestData
      );
      
      console.log('🟢 [SERVICE-PREVIEW] Réponse reçue')
      console.log('🟢 [SERVICE-PREVIEW] response.hasError:', response?.hasError)
      console.log('🟢 [SERVICE-PREVIEW] response.items:', response?.items)

      if (!response || response === null || response === undefined) {
        console.error('❌ [SERVICE-PREVIEW] Réponse null/undefined du backend')
        return {
          success: false,
          message: 'Réponse invalide du serveur',
        };
      }

      if (response.hasError) {
        console.log('🟡 [SERVICE-PREVIEW] Réponse avec erreur')
        return {
          success: false,
          message: response.status?.message || 'Erreur lors de la prévisualisation',
        };
      }

      const respPreview = response as unknown as BackendResponse<BesoinResponse>
      const successResult = {
        success: true,
        data: respPreview.items?.[0] ?? respPreview.item,
        message: 'Prévisualisation générée avec succès',
      };
      console.log('🟢 [SERVICE-PREVIEW] Retour succès:', successResult)
      return successResult;
    } catch (error: any) {
      console.error('❌ [SERVICE-PREVIEW] Erreur dans catch:', error);
      let errorMessage = 'Erreur lors de la prévisualisation';
      if (error?.details?.status?.message) {
        errorMessage = error.details.status.message;
      } else if (error?.message) {
        errorMessage = error.message;
      }
      const errorResult = { success: false, message: errorMessage };
      console.log('🔴 [SERVICE-PREVIEW] Retour erreur:', errorResult);
      return errorResult;
    } finally {
      console.log('🔵 [SERVICE-PREVIEW] ========== previewApprove() FIN ==========')
    }
  }
}

// Export d'une instance unique du service
export const besoinsService = new BesoinsService();

