/**
 * Hook personnalisé pour la gestion des utilisateurs
 * Intègre le service UsersService avec l'état React et la pagination
 */

import { useState, useEffect, useCallback } from 'react';
import { usersService } from '@/lib/services/users.service';
import { User, UserFilters } from '@/lib/types/entities';
import { ApiError } from '@/lib/types/api';
import toast from 'react-hot-toast';

interface UseUsersState {
  /** Liste complète renvoyée par l’API (la pagination s’applique après filtrage sur la page) */
  users: User[];
  loading: boolean;
  error: string | null;
  /** @deprecated Utiliser le total après filtrage côté page ; conservé pour compat = users.length */
  totalCount: number;
  currentPage: number;
  pageSize: number;
  /** @deprecated Toujours 0 — totalPages se calcule sur la liste filtrée dans la page */
  totalPages: number;
}

interface UseUsersActions {
  loadUsers: (filters?: UserFilters, page?: number, size?: number) => Promise<void>;
  setPage: (page: number) => void;
  setPageSize: (size: number) => void;
  searchUsers: (searchTerm: string) => Promise<void>;
  refreshUsers: () => Promise<void>;
  resetFilters: () => Promise<void>;
}

export function useUsers(): UseUsersState & UseUsersActions {
  const [state, setState] = useState<UseUsersState>({
    users: [],
    loading: false,
    error: null,
    totalCount: 0,
    currentPage: 1,
    pageSize: 10,
    totalPages: 0,
  });

  const [currentFilters, setCurrentFilters] = useState<UserFilters | undefined>();

  const loadUsers = useCallback(async (
    filters?: UserFilters,
    page: number = 1,
    _sizeIgnored?: number
  ) => {
    setState(prev => ({ ...prev, loading: true, error: null }));
    setCurrentFilters(filters);
    
    try {
      const response = await usersService.getUsers(filters);
      
      if (response.items && response.items.length > 0) {
        // S'assurer que response.items est un tableau plat (liste complète, pas de découpe ici)
        let itemsTemp: any[] = [];
        if (Array.isArray(response.items)) {
          if (response.items.length > 0 && Array.isArray(response.items[0])) {
            itemsTemp = (response.items as unknown as any[]).flat();
          } else {
            itemsTemp = (response.items as unknown as any[]);
          }
        }
        
        const allUsers: User[] = itemsTemp as unknown as User[];
        
        setState(prev => ({
          ...prev,
          users: allUsers,
          totalCount: allUsers.length,
          currentPage: page,
          totalPages: 0,
          loading: false,
        }));
      } else {
        setState(prev => ({
          ...prev,
          users: [],
          totalCount: 0,
          totalPages: 0,
          loading: false,
        }));
      }
    } catch (error) {
      console.error('Erreur lors du chargement des utilisateurs:', error);
      const errorMessage = 'Erreur lors du chargement des utilisateurs';
      
      setState(prev => ({
        ...prev,
        error: errorMessage,
        loading: false,
      }));
      
      toast.error(errorMessage);
    }
  }, []);

  const setPage = useCallback((page: number) => {
    setState(prev => ({ ...prev, currentPage: Math.max(1, page) }));
  }, []);

  const setPageSize = useCallback((size: number) => {
    setState(prev => ({ ...prev, pageSize: size, currentPage: 1 }));
  }, []);

  const searchUsers = useCallback(async (searchTerm: string) => {
    const filters: UserFilters = {};
    
    if (searchTerm.trim()) {
      filters.login = searchTerm;
      filters.firstName = searchTerm;
      filters.lastName = searchTerm;
      filters.email = searchTerm;
    }
    
    await loadUsers(filters, 1);
  }, [loadUsers]);

  const refreshUsers = useCallback(async () => {
    await loadUsers(currentFilters, state.currentPage, state.pageSize);
  }, [loadUsers, currentFilters, state.currentPage, state.pageSize]);

  const resetFilters = useCallback(async () => {
    setCurrentFilters(undefined);
    await loadUsers(undefined, 1);
  }, [loadUsers]);

  // Charger les utilisateurs au montage du composant
  useEffect(() => {
    loadUsers();
  }, []);

  return {
    ...state,
    loadUsers,
    setPage,
    setPageSize,
    searchUsers,
    refreshUsers,
    resetFilters,
  };
}